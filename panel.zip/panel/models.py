"""面板数据模型（dataclass）"""
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class TaskEntry:
    """快捷指令条目"""
    label: str
    cwd: str
    command: str
    mode: str = "inline"  # "inline" | "popup"


@dataclass
class ServiceConfig:
    """服务配置"""
    service_name: str
    type: str = "service"  # "service" | "process"
    script_path: Optional[str] = None
    exe_path: Optional[str] = None
    args: Optional[str] = None
    bat_path: Optional[str] = None
    port: Optional[int] = None    # process 模式用，检测端口是否在监听
