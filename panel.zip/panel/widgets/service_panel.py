"""服务托管卡片组件"""
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QLabel, QFrame
)
from PySide6.QtCore import Qt
from PySide6.QtGui import QFont

from src.panel.config import SERVICES_CONFIG
from src.panel.theme import Theme


class ServicePanel(QWidget):
    """服务托管 Tab 内容：服务列表展示"""

    def __init__(self, main_win, parent=None):
        super().__init__(parent)
        self.main_win = main_win
        self._rows: list[dict] = []
        self._init_ui()

    def _init_ui(self):
        lo = QVBoxLayout(self)
        lo.setSpacing(Theme.SPACING["md"])
        lo.setContentsMargins(Theme.SPACING["xl"], Theme.SPACING["xl"],
                               Theme.SPACING["xl"], Theme.SPACING["xl"])

        for idx, cfg in enumerate(SERVICES_CONFIG):
            row = self._build_row(idx, cfg["service_name"])
            self._rows.append(row)
            lo.addWidget(row["card"])

        lo.addStretch()

    def _build_row(self, idx: int, name: str) -> dict:
        card = QFrame()
        card.setObjectName("service_card")
        card.setStyleSheet(f"""
            QFrame#service_card {{
                background-color: {Theme.C['card_bg']};
                border: 1px solid {Theme.C['border']};
                border-radius: 10px;
            }}
        """)
        card_lo = QHBoxLayout(card)
        card_lo.setContentsMargins(Theme.SPACING["lg"], Theme.SPACING["md"],
                                    Theme.SPACING["lg"], Theme.SPACING["md"])
        card_lo.setSpacing(Theme.SPACING["sm"])

        # 服务名
        lbl_name = QLabel(name)
        lbl_name.setFont(QFont("Segoe UI", 11, QFont.Bold))
        lbl_name.setStyleSheet(f"color: {Theme.C['text']};")
        lbl_name.setMinimumWidth(120)
        card_lo.addWidget(lbl_name)

        # 状态
        status_label = QLabel("读取中...")
        status_label.setFont(QFont("Segoe UI", 10))
        status_label.setAlignment(Qt.AlignVCenter | Qt.AlignLeft)
        status_label.setStyleSheet(
            f"color: {Theme.C['text_dim']}; background: transparent; border: none; padding: 0 8px;")
        card_lo.addWidget(status_label)

        card_lo.addStretch()

        # 控制按钮
        btn_start = QPushButton("启动")
        btn_start.setCursor(Qt.PointingHandCursor)
        btn_start.setFixedSize(58, 30)
        btn_start.setStyleSheet(Theme.control_button("start"))
        btn_start.clicked.connect(lambda _=None, i=idx: self.main_win._start_service(i))
        card_lo.addWidget(btn_start)

        btn_stop = QPushButton("停止")
        btn_stop.setCursor(Qt.PointingHandCursor)
        btn_stop.setFixedSize(58, 30)
        btn_stop.setStyleSheet(Theme.control_button("stop"))
        btn_stop.clicked.connect(lambda _=None, i=idx: self.main_win._stop_service(i))
        card_lo.addWidget(btn_stop)

        btn_refresh = QPushButton("刷新")
        btn_refresh.setCursor(Qt.PointingHandCursor)
        btn_refresh.setFixedSize(58, 30)
        btn_refresh.setStyleSheet(Theme.control_button("refresh"))
        btn_refresh.clicked.connect(lambda _=None, i=idx: self.main_win.refresh_status(i))
        card_lo.addWidget(btn_refresh)

        # 分隔线
        sep = QFrame()
        sep.setFrameShape(QFrame.VLine)
        sep.setStyleSheet(f"color: {Theme.C['border']};")
        sep.setFixedWidth(1)
        card_lo.addWidget(sep)

        # 管理按钮
        btn_install = QPushButton("注册")
        btn_install.setCursor(Qt.PointingHandCursor)
        btn_install.setFixedSize(58, 30)
        btn_install.setStyleSheet(Theme.control_button("install"))
        btn_install.clicked.connect(lambda _=None, i=idx: self.main_win._install_service(i))
        card_lo.addWidget(btn_install)

        btn_remove = QPushButton("卸载")
        btn_remove.setCursor(Qt.PointingHandCursor)
        btn_remove.setFixedSize(58, 30)
        btn_remove.setStyleSheet(Theme.control_button("remove"))
        btn_remove.clicked.connect(lambda _=None, i=idx: self.main_win._remove_service(i))
        card_lo.addWidget(btn_remove)

        return {
            "idx": idx,
            "card": card,
            "status_label": status_label,
            "btn_start": btn_start,
            "btn_stop": btn_stop,
        }

    def current_row(self) -> dict:
        return self._rows[0]

    def set_row_status(self, idx: int, text: str, style: str, enable_start: bool, enable_stop: bool):
        if 0 <= idx < len(self._rows):
            row = self._rows[idx]
            row["status_label"].setText(text)
            row["status_label"].setStyleSheet(
                f"{style} background: transparent; border: none; padding: 0 8px;")
            row["btn_start"].setEnabled(enable_start)
            row["btn_stop"].setEnabled(enable_stop)
