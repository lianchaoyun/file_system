"""快捷指令网格组件 — 提供分组页面生成，不再持有内部 Tab"""
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QGridLayout, QPushButton, QLabel,
    QScrollArea, QFrame
)
from PySide6.QtCore import Qt
from PySide6.QtGui import QFont

from src.panel.theme import Theme


class ShortcutGrid(QWidget):
    """快捷指令分组容器：不嵌套 Tab，每个分组由外部 TabWidget 管理"""

    COLS = 3

    def __init__(self, main_win, parent=None):
        super().__init__(parent)
        self.main_win = main_win
        self.grid_buttons = []
        self.setStyleSheet("background: transparent;")

    @staticmethod
    def _make_scroll_page(content: QWidget) -> QScrollArea:
        """把内容页包装成带滚动条的区域"""
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        scroll.setStyleSheet("""
            QScrollArea { background: transparent; border: none; }
            QScrollBar:vertical {
                background: transparent;
                width: 8px;
                border-radius: 4px;
            }
            QScrollBar::handle:vertical {
                background: rgba(255, 255, 255, 0.15);
                border-radius: 4px;
                min-height: 30px;
            }
            QScrollBar::handle:vertical:hover {
                background: rgba(255, 255, 255, 0.25);
            }
            QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
                height: 0px;
            }
        """)
        scroll.setWidget(content)
        return scroll

    def build_group_page(self, group_title: str, entries: list) -> QScrollArea:
        """生成一个分组的滚动页面，返回 QScrollArea 供外部 Tab 使用。
        entries: [(title_text, cwd_dir, command, mode), ...]"""
        page = QWidget()
        page.setStyleSheet("background: transparent;")
        gl = QGridLayout(page)
        gl.setSpacing(Theme.SPACING["md"])
        gl.setContentsMargins(Theme.SPACING["lg"], Theme.SPACING["lg"],
                               Theme.SPACING["lg"], Theme.SPACING["lg"])

        for idx, (title_text, cwd_dir, command, mode) in enumerate(entries):
            row, col = divmod(idx, self.COLS)
            btn = self._create_grid_button(title_text, mode)
            btn.clicked.connect(
                lambda checked=False, t=title_text, c=cwd_dir, cmd=command, m=mode:
                self.main_win._exec_grid_cmd(t, c, cmd, m))
            gl.addWidget(btn, row, col)
            self.grid_buttons.append(btn)

        gl.setRowStretch((len(entries) + self.COLS - 1) // self.COLS, 1)
        return self._make_scroll_page(page)

    def build_empty_page(self, message: str = "暂无快捷指令，请在管理后台配置 task 任务",
                         refresh_callback=None) -> QScrollArea:
        """生成空数据占位页面，可选刷新按钮"""
        c = Theme.C
        page = QWidget()
        page.setStyleSheet("background: transparent;")
        pl = QVBoxLayout(page)
        pl.setAlignment(Qt.AlignCenter)
        pl.setSpacing(Theme.SPACING["md"])

        placeholder = QLabel(message)
        placeholder.setAlignment(Qt.AlignCenter)
        placeholder.setStyleSheet(f"color: {c['text_dim']}; font-size: 14px; background: transparent;")
        pl.addWidget(placeholder)

        if refresh_callback is not None:
            btn_refresh = QPushButton("刷新")
            btn_refresh.setCursor(Qt.PointingHandCursor)
            btn_refresh.setFixedHeight(32)
            btn_refresh.setStyleSheet(Theme.small_button())
            btn_refresh.clicked.connect(refresh_callback)
            pl.addWidget(btn_refresh, alignment=Qt.AlignCenter)

        return self._make_scroll_page(page)

    def _create_grid_button(self, title_text: str, mode: str) -> QPushButton:
        btn = QPushButton(title_text)
        btn.setFont(QFont("Segoe UI", 10))
        btn.setMinimumHeight(46)
        btn.setCursor(Qt.PointingHandCursor)

        c = Theme.C
        if "强杀" in title_text or "强清" in title_text:
            border_color = c["danger_border"]
            hover_color = c["danger_hover"]
        elif mode == "popup":
            border_color = "rgba(96, 165, 250, 0.4)"
            hover_color = c["accent_hover"]
        else:
            border_color = c["border"]
            hover_color = c["accent"]

        btn.setStyleSheet(Theme.grid_button(border_color, hover_color))
        return btn
