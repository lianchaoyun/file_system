"""日志控制台组件"""
import os

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QLabel, QTextEdit
)
from PySide6.QtCore import Qt
from PySide6.QtGui import QFont

from src.panel.config import SERVER_DIR
from src.panel.theme import Theme


class LogConsole(QWidget):
    """终端回显流组件：日志文本区 + 操作栏"""

    def __init__(self, main_win, parent=None):
        super().__init__(parent)
        self.main_win = main_win
        self._init_ui()

    def _init_ui(self):
        self.setStyleSheet(Theme.log_box())

        lo = QVBoxLayout(self)
        lo.setContentsMargins(Theme.SPACING["lg"], Theme.SPACING["md"],
                               Theme.SPACING["lg"], Theme.SPACING["lg"])
        lo.setSpacing(Theme.SPACING["sm"])

        # ── 日志操作栏 ──
        self.log_bar = QHBoxLayout()
        lbl_term = QLabel("日志输出")
        lbl_term.setStyleSheet(
            f"color: {Theme.C['text_dim']}; font-weight: bold; font-size: 12px; border: none;")
        self.log_bar.addWidget(lbl_term)
        self.log_bar.addStretch()

        btn_log = QPushButton("日志目录")
        btn_log.setCursor(Qt.PointingHandCursor)
        btn_log.setFixedHeight(24)
        btn_log.setStyleSheet(Theme.small_button())
        btn_log.clicked.connect(self._open_log_dir)
        self.log_bar.addWidget(btn_log)

        btn_clear = QPushButton("清空")
        btn_clear.setCursor(Qt.PointingHandCursor)
        btn_clear.setFixedHeight(24)
        btn_clear.setStyleSheet(Theme.small_button())
        btn_clear.clicked.connect(lambda: self.log_text.clear())
        self.log_bar.addWidget(btn_clear)
        lo.addLayout(self.log_bar)

        # ── 日志文本区 ──
        self.log_text = QTextEdit()
        self.log_text.setReadOnly(True)
        self.log_text.setFont(QFont("Consolas", 10))
        self.log_text.setStyleSheet(Theme.log_text_edit())
        lo.addWidget(self.log_text)

    def _open_log_dir(self):
        log_path = os.path.join(SERVER_DIR, "data", "logs", "panel")
        os.makedirs(log_path, exist_ok=True)
        os.startfile(log_path)
        self.main_win._log(f"日志目录: {log_path}")

    def append(self, text: str):
        self.log_text.append(text)
        self.log_text.verticalScrollBar().setValue(
            self.log_text.verticalScrollBar().maximum())

    def clear(self):
        self.log_text.clear()
