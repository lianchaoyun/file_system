"""面板全局配置"""
import os

from src.common.paths import PROJECT_ROOT_STR as SERVER_DIR, VENV_PYTHON_STR
from src.claw.server.config import get_server_config

_PYTHON_EXE_PATH = os.path.join(SERVER_DIR, ".venv", "Scripts", "python.exe")
PYTHON_EXE = f'"{_PYTHON_EXE_PATH}"'

_CLAW_CONFIG = get_server_config()
CLAW_PORT = str(_CLAW_CONFIG["port"])
PANEL_API_BASE = f"http://localhost:{CLAW_PORT}"

SERVICES_CONFIG = [
    {
        "type": "service",
        "service_name": "claw",
        "script_path": os.path.join(SERVER_DIR, "src", "claw", "run.py"),
    },
]
