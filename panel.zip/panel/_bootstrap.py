"""面板启动引导：提权 + 启动 Qt 窗口"""
import sys
import os
import ctypes


def is_admin():
    try:
        return ctypes.windll.shell32.IsUserAnAdmin()
    except:
        return False


def run():
    """统一的启动入口，处理提权后启动 Qt 窗口"""
    if not is_admin():
        from src.common.paths import PROJECT_ROOT_STR
        pythonw = os.path.join(PROJECT_ROOT_STR, ".venv", "Scripts", "pythonw.exe")
        params = f'"{sys.argv[0]}"'
        ctypes.windll.shell32.ShellExecuteW(None, "runas", pythonw, params, PROJECT_ROOT_STR, 1)
        sys.exit()

    from PySide6.QtWidgets import QApplication
    from src.panel.main_window import ClawUnifiedPanel

    app = QApplication(sys.argv)
    app.setStyle("Fusion")
    window = ClawUnifiedPanel()
    window.show()
    sys.exit(app.exec())
