"""主窗口：纯布局编排，业务逻辑委托给 Controller"""
import threading

from PySide6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QMessageBox, QPushButton,
    QStackedWidget, QLabel, QSplitter
)
from PySide6.QtCore import Qt
from PySide6.QtCore import Signal, QObject

from src.panel.config import SERVICES_CONFIG
from src.panel.theme import Theme
from src.panel.api import fetch_panel_groups
from src.panel.controllers import ServiceController
from src.panel.controllers.command_runner import CommandRunner
from src.panel.widgets.service_panel import ServicePanel
from src.panel.widgets.shortcut_grid import ShortcutGrid
from src.panel.widgets.log_console import LogConsole


class Signals(QObject):
    log_signal = Signal(str)
    status_signal = Signal(int, str, str, bool, bool)
    lock_signal = Signal(bool)
    shortcuts_refreshed_signal = Signal(dict)


def _set_dark_titlebar(win_id: int):
    """Windows: 将原生标题栏设为暗色模式"""
    try:
        import ctypes
        from ctypes import wintypes

        DWMWA_USE_IMMERSIVE_DARK_MODE = 20
        uBool = wintypes.BOOL(True)
        ctypes.windll.dwmapi.DwmSetWindowAttribute(
            win_id, DWMWA_USE_IMMERSIVE_DARK_MODE,
            ctypes.byref(uBool), ctypes.sizeof(uBool)
        )
    except Exception:
        pass


class ClawUnifiedPanel(QMainWindow):
    """云管理面板 — 只做布局编排与信号协调"""

    def __init__(self):
        super().__init__()
        self.setWindowTitle("云管理面板")
        self.setMinimumSize(720, 550)
        self.setStyleSheet(Theme.main_window())

        # ── 信号总线 ──
        self.signals = Signals()
        self.signals.log_signal.connect(self._safe_log)
        self.signals.status_signal.connect(self._safe_set_status)
        self.signals.lock_signal.connect(self._safe_lock_grid)
        self.signals.shortcuts_refreshed_signal.connect(self._on_shortcuts_refreshed)

        # ── 控制器 ──
        self.service_ctrl = ServiceController(
            log_callback=self._log,
            status_callback=lambda idx, text, style, en_start, en_stop:
                self.signals.status_signal.emit(idx, text, style, en_start, en_stop)
        )
        self.cmd_runner = CommandRunner(
            log_callback=self._log,
            lock_callback=lambda locked: self.signals.lock_signal.emit(locked)
        )

        # ── 数据拉取（UI 创建前，缓存日志） ──
        _pending_logs = []
        self._panel_groups = fetch_panel_groups(
            log_callback=lambda msg: _pending_logs.append(msg))

        # ── 构建 UI ──
        self._init_ui()

        # ── 回放缓存日志 ──
        for msg in _pending_logs:
            self._log(msg)
        if not self._panel_groups:
            self._log("未加载到任务分组，快捷指令为空")
        self._log("面板就绪")

        # ── 初始状态 ──
        self.refresh_status()

    # ═══════════════════════════════════════════════════════════════
    #  UI 构建
    # ═══════════════════════════════════════════════════════════════

    def showEvent(self, event):
        super().showEvent(event)
        if self.winId():
            _set_dark_titlebar(int(self.winId()))

    def _init_ui(self):
        c = Theme.C
        central = QWidget()
        self.setCentralWidget(central)
        ml = QVBoxLayout(central)
        ml.setSpacing(Theme.SPACING["lg"])
        ml.setContentsMargins(Theme.SPACING["xl"], Theme.SPACING["xl"],
                               Theme.SPACING["xl"], Theme.SPACING["xl"])

        # ── 自定义 Tab 栏 ──
        tab_bar = QWidget()
        tab_bar.setStyleSheet(f"""
            QWidget {{
                background-color: transparent;
                border-bottom: 2px solid {c['border']};
            }}
        """)
        tab_bar_layout = QHBoxLayout(tab_bar)
        tab_bar_layout.setContentsMargins(0, 0, 0, 0)
        tab_bar_layout.setSpacing(0)

        # Tab 标签容器
        self._tab_labels = []
        self._tab_labels_layout = QHBoxLayout()
        self._tab_labels_layout.setContentsMargins(0, 0, 0, 0)
        self._tab_labels_layout.setSpacing(6)
        tab_bar_layout.addLayout(self._tab_labels_layout)
        tab_bar_layout.addStretch()

        # 刷新按钮
        self.btn_refresh_shortcuts = QPushButton("刷新")
        self.btn_refresh_shortcuts.setCursor(Qt.PointingHandCursor)
        self.btn_refresh_shortcuts.setFixedHeight(24)
        self.btn_refresh_shortcuts.setStyleSheet(Theme.small_button())
        self.btn_refresh_shortcuts.clicked.connect(self._refresh_shortcuts)
        tab_bar_layout.addWidget(self.btn_refresh_shortcuts)

        ml.addWidget(tab_bar, 0)

        # ── 页面栈 ──
        self._page_stack = QStackedWidget()
        self._page_stack.setStyleSheet(f"""
            QStackedWidget {{
                background-color: {c['bg']};
                border: 1px solid {c['border']};
                border-top: none;
                border-radius: 0 0 12px 12px;
            }}
        """)

        # 服务托管页（始终第一个）
        self.service_panel = ServicePanel(self)
        self._page_stack.addWidget(self.service_panel)
        self._add_tab_label("基础服务", 0)

        # 快捷指令
        self.shortcut_grid = ShortcutGrid(self)
        self._rebuild_shortcut_tabs()

        # 可拖拽分割：上方页面栈 + 下方日志
        splitter = QSplitter(Qt.Vertical)
        splitter.addWidget(self._page_stack)
        self.log_console = LogConsole(self)
        splitter.addWidget(self.log_console)
        splitter.setStretchFactor(0, 3)
        splitter.setStretchFactor(1, 1)
        splitter.setSizes([400, 150])

        ml.addWidget(splitter, 1)

    # ═══════════════════════════════════════════════════════════════
    #  日志
    # ═══════════════════════════════════════════════════════════════

    def _safe_log(self, text: str):
        self.log_console.append(text)

    def _log(self, msg: str):
        if msg and msg.strip():
            self.signals.log_signal.emit(msg)

    # ═══════════════════════════════════════════════════════════════
    #  服务管理（委托 Controller）
    # ═══════════════════════════════════════════════════════════════

    def _safe_set_status(self, idx: int, text: str, style: str, enable_start: bool, enable_stop: bool):
        self.service_panel.set_row_status(int(idx), text, style, enable_start, enable_stop)

    def _safe_lock_grid(self, locked: bool):
        for btn in self.shortcut_grid.grid_buttons:
            btn.setDisabled(locked)

    def _add_tab_label(self, text: str, page_index: int):
        """添加一个 Tab 标签到自定义标签栏"""
        c = Theme.C
        label = QLabel(text)
        label.setCursor(Qt.PointingHandCursor)
        label.setStyleSheet(f"""
            QLabel {{
                color: {c['text_dim']};
                font-family: 'Segoe UI', 'Microsoft YaHei';
                font-size: 13px;
                font-weight: 500;
                padding: 8px 20px;
                border-bottom: 2px solid transparent;
                background: transparent;
            }}
        """)
        label.mousePressEvent = lambda e, i=page_index: self._switch_page(i)
        self._tab_labels_layout.addWidget(label)
        self._tab_labels.append((label, page_index))
        if page_index == 0:
            self._update_active_tab(0)

    def _update_active_tab(self, active_index: int):
        """高亮当前激活的 Tab 标签"""
        c = Theme.C
        for label, idx in self._tab_labels:
            if idx == active_index:
                label.setStyleSheet(f"""
                    QLabel {{
                        color: {c['accent']};
                        font-family: 'Segoe UI', 'Microsoft YaHei';
                        font-size: 13px;
                        font-weight: 500;
                        padding: 8px 20px;
                        border-bottom: 2px solid {c['accent']};
                        background: transparent;
                    }}
                """)
            else:
                label.setStyleSheet(f"""
                    QLabel {{
                        color: {c['text_dim']};
                        font-family: 'Segoe UI', 'Microsoft YaHei';
                        font-size: 13px;
                        font-weight: 500;
                        padding: 8px 20px;
                        border-bottom: 2px solid transparent;
                        background: transparent;
                    }}
                    QLabel:hover {{
                        color: {c['text']};
                        background-color: {c['btn_hover']};
                        border-radius: 8px;
                    }}
                """)

    def _switch_page(self, index: int):
        """切换页面"""
        self._page_stack.setCurrentIndex(index)
        self._update_active_tab(index)

    def _rebuild_shortcut_tabs(self):
        """根据 self._panel_groups 重建快捷指令 Tab（必须在主线程调用）"""
        # 1. 彻底清空旧标签：先从布局中移除，再销毁非基础标签，保留基础服务标签
        base_label = None
        for label, idx in self._tab_labels:
            self._tab_labels_layout.removeWidget(label)
            if idx == 0:
                base_label = label
            else:
                label.deleteLater()
        self._tab_labels = []

        # 2. 把"基础服务"标签重新放回布局最前面
        if base_label is not None:
            self._tab_labels_layout.addWidget(base_label)
            self._tab_labels.append((base_label, 0))

        # 3. 移除旧的快捷指令页面（索引 1+），保留"基础服务"在索引 0
        while self._page_stack.count() > 1:
            widget = self._page_stack.widget(1)
            self._page_stack.removeWidget(widget)
            widget.deleteLater()
        self.shortcut_grid.grid_buttons.clear()

        # 4. 按 self._panel_groups 顺序重建快捷指令标签和页面
        page_idx = 1
        if self._panel_groups:
            for group_title, entries in self._panel_groups.items():
                scroll = self.shortcut_grid.build_group_page(group_title, entries)
                self._page_stack.addWidget(scroll)
                self._add_tab_label(group_title, page_idx)
                page_idx += 1
        else:
            scroll = self.shortcut_grid.build_empty_page()
            self._page_stack.addWidget(scroll)
            self._add_tab_label("快捷指令", page_idx)

    def _on_shortcuts_refreshed(self, groups: dict):
        """主线程中更新数据并重建 Tab"""
        self._panel_groups = groups
        self._rebuild_shortcut_tabs()
        self.btn_refresh_shortcuts.setEnabled(True)
        if not groups:
            self._log("未加载到任务分组，快捷指令为空")
        else:
            self._log(f"已加载 {len(groups)} 个快捷指令分组")

    def _refresh_shortcuts(self):
        """重新拉取快捷指令分组（后台线程拉取，主线程更新 UI）"""
        self.btn_refresh_shortcuts.setEnabled(False)
        self._log("正在刷新快捷指令...")

        def do_refresh():
            try:
                groups = fetch_panel_groups(log_callback=self._log)
                self.signals.shortcuts_refreshed_signal.emit(groups)
            except Exception as e:
                self._log(f"刷新快捷指令失败: {e}")
                self.signals.shortcuts_refreshed_signal.emit({})

        threading.Thread(target=do_refresh, daemon=True).start()

    def refresh_status(self, idx: int = 0):
        self._safe_set_status(
            idx,
            "⏳  读取中...",
            f"color: {Theme.C['status_wait_txt']};",
            False, False)
        threading.Thread(
            target=lambda: self.service_ctrl.refresh_status(idx),
            daemon=True
        ).start()

    def _start_service(self, idx: int = 0):
        threading.Thread(
            target=lambda: self.service_ctrl.start_service(idx),
            daemon=True
        ).start()

    def _stop_service(self, idx: int = 0):
        threading.Thread(
            target=lambda: self.service_ctrl.stop_service(idx),
            daemon=True
        ).start()

    def _install_service(self, idx: int = 0):
        threading.Thread(
            target=lambda: self.service_ctrl.install_service(idx),
            daemon=True
        ).start()

    def _remove_service(self, idx: int = 0):
        cfg = SERVICES_CONFIG[idx]
        svc = cfg["service_name"]

        if cfg.get("type") == "process":
            self.refresh_status(idx)
            return

        reply = QMessageBox.question(
            self, "确认卸载",
            f"确定要卸载服务 [{svc}] 吗？",
            QMessageBox.Yes | QMessageBox.No)
        if reply == QMessageBox.Yes:
            threading.Thread(
                target=lambda i=idx: self.service_ctrl.remove_service(i),
                daemon=True
            ).start()

    # ═══════════════════════════════════════════════════════════════
    #  快捷指令（委托 CommandRunner）
    # ═══════════════════════════════════════════════════════════════

    def _exec_grid_cmd(self, title: str, cwd_dir: str, command: str, mode: str = "inline"):
        self.cmd_runner.exec_grid_cmd(title, cwd_dir, command, mode)
