"""黑金暗黑美学色盘 + QSS 工厂"""


class Theme:
    """集中管理所有颜色 token 和 QSS 片段，消除散落各处的硬编码颜色字符串。"""

    # ── 色盘 ──
    C = {
        "bg": "#12141c",
        "card_bg": "#181b24",
        "border": "#232733",
        "text": "#efefef",
        "text_dim": "#7e8494",
        "text_dark": "#3c404f",

        "btn_bg": "rgba(255, 255, 255, 0.03)",
        "btn_hover": "rgba(255, 255, 255, 0.08)",
        "btn_text": "#efefef",
        "accent_blue": "#3b82f6",
        "accent_blue_hover": "#2563eb",
        "accent": "#60a5fa",
        "accent_hover": "#93c5fd",

        "status_run_txt": "#10b981",
        "status_stop_txt": "#ef4444",
        "status_wait_txt": "#f59e0b",

        # 危险操作
        "danger_border": "rgba(239, 68, 68, 0.4)",
        "danger_hover": "#f87171",
    }

    # ── 间距/圆角 token ──
    SPACING = {
        "xs": 4,
        "sm": 8,
        "md": 10,
        "lg": 14,
        "xl": 16,
    }

    RADIUS = {
        "sm": 6,
        "md": 8,
        "lg": 10,
        "xl": 12,
        "pill": 18,
    }

    # ── QSS 工厂 ──

    @classmethod
    def main_window(cls) -> str:
        return f"QMainWindow {{ background-color: {cls.C['bg']}; }}"

    @classmethod
    def tab_widget(cls) -> str:
        c = cls.C
        return f"""
            QTabWidget::pane {{
                border: 1px solid {c['border']};
                border-radius: 12px;
                background-color: {c['bg']};
                top: -1px;
            }}
            QTabBar::tab {{
                background-color: transparent;
                color: {c['text_dim']};
                font-family: 'Segoe UI', 'Microsoft YaHei';
                font-size: 13px;
                font-weight: 500;
                padding: 8px 20px;
                margin-right: 6px;
                border: none;
                border-bottom: 2px solid transparent;
            }}
            QTabBar::tab:selected {{
                color: {c['accent']};
                border-bottom: 2px solid {c['accent']};
            }}
            QTabBar::tab:hover:!selected {{
                color: {c['text']};
                background-color: {c['btn_hover']};
                border-radius: 8px;
            }}
        """

    @classmethod
    def sub_tab_widget(cls) -> str:
        c = cls.C
        return f"""
            QTabWidget::pane {{
                border: none;
                background: transparent;
            }}
            QTabBar::tab {{
                background: transparent;
                color: {c['text_dim']};
                font-family: 'Segoe UI', 'Microsoft YaHei';
                font-size: 12px;
                font-weight: 500;
                padding: 6px 16px;
                margin-right: 4px;
                border: 1px solid transparent;
                border-radius: 8px;
            }}
            QTabBar::tab:selected {{
                color: {c['accent']};
                background-color: rgba(96, 165, 250, 0.08);
                border-color: rgba(96, 165, 250, 0.3);
            }}
            QTabBar::tab:hover:!selected {{
                color: {c['text']};
                background-color: {c['btn_hover']};
            }}
        """

    @classmethod
    def combo_box(cls) -> str:
        c = cls.C
        return f"""
            QComboBox {{
                padding: 5px 12px;
                border: 1px solid {c['border']};
                border-radius: 8px;
                background-color: {c['bg']};
                color: {c['text']};
                font-family: 'Segoe UI', 'Microsoft YaHei';
                font-size: 13px;
                min-height: 26px;
            }}
            QComboBox:hover {{ border-color: {c['text_dim']}; }}
            QComboBox::drop-down {{ border: none; width: 24px; }}
            QComboBox QAbstractItemView {{
                border: 1px solid {c['border']};
                border-radius: 8px;
                background-color: #181b24;
                color: {c['text']};
                selection-background-color: {c['btn_hover']};
                selection-color: {c['accent']};
                outline: none;
            }}
            QComboBox QAbstractItemView::item {{
                min-height: 32px;
                padding-left: 12px;
                color: {c['text']};
            }}
        """

    @classmethod
    def primary_button(cls) -> str:
        c = cls.C
        return f"""
            QPushButton {{
                background-color: {c['accent_blue']};
                color: white;
                padding: 0 16px;
                border-radius: 17px;
                font-size: 12px;
                font-weight: bold;
                border: none;
            }}
            QPushButton:hover {{ background-color: {c['accent_blue_hover']}; }}
        """

    @classmethod
    def ghost_button(cls) -> str:
        c = cls.C
        return f"""
            QPushButton {{
                background-color: transparent;
                color: {c['text_dim']};
                border: 1px solid {c['border']};
                padding: 0 16px;
                border-radius: 17px;
                font-size: 12px;
            }}
            QPushButton:hover {{
                background-color: rgba(239, 68, 68, 0.12);
                color: {c['danger_hover']};
                border-color: transparent;
            }}
        """

    @classmethod
    def outline_button(cls) -> str:
        c = cls.C
        return f"""
            QPushButton {{
                background-color: {c['btn_bg']};
                color: {c['btn_text']};
                border: 1px solid {c['border']};
                border-radius: 18px;
                padding: 0 16px;
            }}
            QPushButton:hover {{
                background-color: {c['btn_hover']};
                color: white;
            }}
            QPushButton:disabled {{
                background-color: transparent;
                color: {c['text_dark']};
                border-color: {c['border']};
            }}
        """

    @classmethod
    def start_button(cls) -> str:
        c = cls.C
        return f"""
            QPushButton {{
                background-color: {c['btn_bg']};
                color: {c['btn_text']};
                border: 1px solid {c['border']};
                border-radius: 18px;
                padding: 0 16px;
            }}
            QPushButton:hover {{
                background-color: rgba(16, 185, 129, 0.12);
                color: {c['status_run_txt']};
                border-color: transparent;
            }}
            QPushButton:disabled {{
                background-color: transparent;
                color: {c['text_dark']};
                border-color: {c['border']};
            }}
        """

    @classmethod
    def stop_button(cls) -> str:
        c = cls.C
        return f"""
            QPushButton {{
                background-color: {c['btn_bg']};
                color: {c['btn_text']};
                border: 1px solid {c['border']};
                border-radius: 18px;
                padding: 0 16px;
            }}
            QPushButton:hover {{
                background-color: rgba(239, 68, 68, 0.12);
                color: {c['status_stop_txt']};
                border-color: transparent;
            }}
            QPushButton:disabled {{
                background-color: transparent;
                color: {c['text_dark']};
                border-color: {c['border']};
            }}
        """

    @classmethod
    def small_button(cls) -> str:
        c = cls.C
        return f"""
            QPushButton {{
                background-color: {c['btn_bg']};
                color: {c['text_dim']};
                border: 1px solid {c['border']};
                padding: 0 10px;
                border-radius: 6px;
                font-size: 11px;
            }}
            QPushButton:hover {{
                color: {c['text']};
                background-color: {c['btn_hover']};
            }}
        """

    @classmethod
    def grid_button(cls, border_color: str, hover_color: str) -> str:
        c = cls.C
        return f"""
            QPushButton {{
                background-color: {c['btn_bg']};
                color: {c['text']};
                border: 1px solid {border_color};
                border-radius: 10px;
            }}
            QPushButton:hover {{
                background-color: rgba(255,255,255,0.06);
                color: {hover_color};
                border-color: {hover_color};
            }}
            QPushButton:disabled {{
                color: {c['text_dark']};
                background-color: transparent;
                border-color: #1a1d26;
            }}
        """

    @classmethod
    def log_text_edit(cls) -> str:
        c = cls.C
        return f"""
            background-color: #08090d;
            color: {c['accent']};
            border: 1px solid {c['border']};
            border-radius: 8px;
            padding: 8px;
        """

    @classmethod
    def log_box(cls) -> str:
        c = cls.C
        return f"""
            background-color: transparent;
            border: 1px solid {c['border']};
            border-radius: 12px;
        """

    # ── 统一控制按钮工厂 ──
    @classmethod
    def control_button(cls, variant: str) -> str:
        """variant: 'start' | 'stop' | 'refresh' | 'install' | 'remove'"""
        c = cls.C
        base = f"""
            QPushButton {{
                background-color: transparent;
                color: {c['text_dim']};
                border: 1px solid {c['border']};
                border-radius: 6px;
                font-size: 11px;
                font-family: 'Segoe UI', 'Microsoft YaHei';
            }}
        """
        hover_map = {
            "start":   f"background-color: rgba(16, 185, 129, 0.12); color: {c['status_run_txt']}; border-color: {c['status_run_txt']};",
            "stop":    f"background-color: rgba(239, 68, 68, 0.12); color: {c['status_stop_txt']}; border-color: {c['status_stop_txt']};",
            "refresh": f"background-color: {c['btn_hover']}; color: {c['accent']}; border-color: {c['accent']};",
            "install": f"background-color: rgba(59, 130, 246, 0.15); color: {c['accent_blue']}; border-color: {c['accent_blue']};",
            "remove":  f"background-color: rgba(239, 68, 68, 0.12); color: {c['danger_hover']}; border-color: {c['danger_hover']};",
        }
        hover = hover_map.get(variant, hover_map["refresh"])
        disabled = f"""
            QPushButton:disabled {{
                background-color: transparent;
                color: {c['text_dark']};
                border-color: {c['border']};
            }}
        """
        return base + f"QPushButton:hover {{ {hover} }}" + disabled
