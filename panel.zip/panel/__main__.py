"""入口：python -m src.panel"""
from src.panel._bootstrap import run

if __name__ == "__main__":
    run()
