"""API 客户端：从 ClawServer 拉取 task 分组数据"""
import json
import urllib.request
import urllib.error
from typing import Callable

from src.panel.config import PANEL_API_BASE, SERVER_DIR


def fetch_panel_groups(log_callback: Callable[[str], None] = None) -> dict:
    """从 API 拉取 task 分组数据，返回 { group_title: [(label, cwd, command, mode), ...] }"""

    def _unwrap(payload):
        if isinstance(payload, dict) and "data" in payload:
            return payload["data"]
        return payload

    groups: dict = {}
    url = f"{PANEL_API_BASE}/terms?group=task"
    try:
        req = urllib.request.Request(url)
        req.add_header("User-Agent", "YunPanel/1.0")
        with urllib.request.urlopen(req, timeout=5) as resp:
            body = resp.read().decode("utf-8")
            terms = _unwrap(json.loads(body))
    except Exception:
        return groups

    if not isinstance(terms, list):
        return groups

    for term in terms:
        term_id = term.get("term_id")
        group_name = term.get("name", str(term_id))
        entries = []

        task_url = f"{PANEL_API_BASE}/tasks?term_id={term_id}&hidden=0"
        try:
            req = urllib.request.Request(task_url)
            req.add_header("User-Agent", "YunPanel/1.0")
            with urllib.request.urlopen(req, timeout=5) as resp:
                body = resp.read().decode("utf-8")
                data = _unwrap(json.loads(body))
        except Exception:
            continue

        items = data if isinstance(data, list) else data.get("items", data.get("data", []))
        for task in items:
            label = task.get("name", "")
            cwd = task.get("working_dir", SERVER_DIR) or SERVER_DIR
            command = task.get("command", "")
            mode = "popup" if task.get("run_mode") == "external" else "inline"
            if label and command:
                entries.append((label, cwd, command, mode))

        if entries:
            groups[group_name] = entries

    return groups
