"""云管理面板 - VSCode 右键运行入口"""
from src.panel._bootstrap import run

if __name__ == "__main__":
    run()
