"""服务控制器：nssm 注册/启停/卸载，进程模式检测"""
import locale
import os
import time
import subprocess

from src.panel.config import SERVICES_CONFIG, CLAW_PORT, SERVER_DIR, VENV_PYTHON_STR
from src.panel.theme import Theme


def _win_encoding() -> str:
    """获取 Windows 控制台真实编码（cp936 / gbk 等）"""
    enc = locale.getpreferredencoding(False)
    return enc if enc else "gbk"


class ServiceController:
    """封装所有服务管理逻辑，与 UI 解耦。"""

    def __init__(self, log_callback, status_callback):
        self._log = log_callback
        self._set_status = status_callback

    @staticmethod
    def current_cfg(combo_index: int) -> dict:
        return SERVICES_CONFIG[combo_index]

    @staticmethod
    def _clean_nssm_output(text: str) -> str:
        import re
        text = re.sub(r'\?{3,}', '', text)
        return text.strip()

    @staticmethod
    def _run_nssm(args: list) -> tuple:
        try:
            res = subprocess.run(
                ["nssm"] + args,
                capture_output=True, text=True, encoding="utf-8", errors="replace",
                creationflags=subprocess.CREATE_NO_WINDOW, timeout=4
            )
            out = ServiceController._clean_nssm_output(res.stdout)
            err = ServiceController._clean_nssm_output(res.stderr)
            return out, err
        except Exception as e:
            return "", str(e)

    # ── 进程检测（按端口或按进程名） ──

    def _is_port_listening(self, port: str) -> bool:
        enc = _win_encoding()
        try:
            res = subprocess.run(
                ["netstat", "-ano", "|", "findstr", f":{port}"],
                capture_output=True, text=True, encoding=enc, errors="replace",
                shell=True, creationflags=subprocess.CREATE_NO_WINDOW, timeout=4
            )
            return "LISTENING" in res.stdout
        except Exception:
            return False

    def _get_pid_by_port(self, port: str) -> str:
        enc = _win_encoding()
        try:
            res = subprocess.run(
                ["netstat", "-ano", "|", "findstr", f":{port}"],
                capture_output=True, text=True, encoding=enc, errors="replace",
                shell=True, creationflags=subprocess.CREATE_NO_WINDOW, timeout=4
            )
            for line in res.stdout.splitlines():
                if "LISTENING" in line:
                    return line.split()[-1]
        except Exception:
            pass
        return ""

    @staticmethod
    def _proc_running(name: str) -> bool:
        try:
            res = subprocess.run(
                ["tasklist", "/FI", f"IMAGENAME eq {name}"],
                capture_output=True, text=True, encoding="utf-8", errors="replace",
                creationflags=subprocess.CREATE_NO_WINDOW, timeout=4
            )
            return name.lower() in res.stdout.lower()
        except Exception:
            return False

    @staticmethod
    def _kill_proc(name: str) -> bool:
        try:
            subprocess.run(
                ["taskkill", "/IM", name, "/F"],
                capture_output=True,
                creationflags=subprocess.CREATE_NO_WINDOW, timeout=5
            )
            return True
        except Exception:
            return False

    def _check_process(self, cfg: dict) -> bool:
        """检测进程是否运行：优先 process_name，其次 port"""
        name = cfg.get("process_name", "")
        if name:
            return self._proc_running(name)
        port = str(cfg.get("port", CLAW_PORT))
        return self._is_port_listening(port)

    def _stop_process(self, cfg: dict) -> bool:
        name = cfg.get("process_name", "")
        if name:
            return self._kill_proc(name)
        port = str(cfg.get("port", CLAW_PORT))
        pid = self._get_pid_by_port(port)
        if pid:
            subprocess.run(
                ["taskkill", "/PID", pid, "/F"],
                capture_output=True,
                creationflags=subprocess.CREATE_NO_WINDOW, timeout=5
            )
            return True
        return False

    # ── 状态刷新 ──

    def refresh_status(self, combo_index: int):
        cfg = self.current_cfg(combo_index)
        svc = cfg["service_name"]
        c = Theme.C

        if cfg.get("type") == "process":
            if self._check_process(cfg):
                self._set_status(
                    combo_index,
                    f"●  运行中 ({svc})",
                    f"color: {c['status_run_txt']};",
                    False, True)
            else:
                self._set_status(
                    combo_index,
                    f"○  已停止 ({svc})",
                    f"color: {c['status_stop_txt']};",
                    True, False)
        else:
            out, _ = self._run_nssm(["status", svc])
            if "SERVICE_RUNNING" in out:
                self._set_status(
                    combo_index,
                    f"●  运行中 ({svc})",
                    f"color: {c['status_run_txt']};",
                    False, True)
            elif "SERVICE_STOPPED" in out:
                self._set_status(
                    combo_index,
                    f"○  已停止 ({svc})",
                    f"color: {c['status_stop_txt']};",
                    True, False)
            else:
                self._set_status(
                    combo_index,
                    f"⚠  未注册 ({svc})",
                    f"color: {c['status_wait_txt']};",
                    True, True)

    # ── 启停 ──

    def start_service(self, combo_index: int):
        cfg = self.current_cfg(combo_index)
        svc = cfg["service_name"]
        c = Theme.C
        self._set_status(
            combo_index,
            f"⏳  启动中...",
            f"color: {c['status_wait_txt']};",
            False, False)

        if cfg.get("type") == "process":
            self._log(f"启动 {svc} ...")
            exe = cfg["exe_path"]
            args = cfg.get("args", "")
            log_path = os.path.join(SERVER_DIR, "data", "logs", "claw")
            os.makedirs(log_path, exist_ok=True)
            try:
                stdout_f = open(os.path.join(log_path, "stdout.log"), "a", encoding="utf-8")
                stderr_f = open(os.path.join(log_path, "stderr.log"), "a", encoding="utf-8")
                cmd = [exe]
                if args:
                    cmd.extend(args.split())
                si = subprocess.STARTUPINFO()
                si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
                si.wShowWindow = subprocess.SW_HIDE
                subprocess.Popen(
                    cmd,
                    cwd=os.path.dirname(exe),
                    stdout=stdout_f, stderr=stderr_f,
                    startupinfo=si,
                )
            except Exception as e:
                self._log(f"启动失败: {e}")
        else:
            out, err = self._run_nssm(["start", svc])
            if out:
                self._log(out)
            if err:
                self._log(err)

        time.sleep(3)
        self.refresh_status(combo_index)

    def stop_service(self, combo_index: int):
        cfg = self.current_cfg(combo_index)
        svc = cfg["service_name"]
        c = Theme.C
        self._set_status(
            combo_index,
            f"⏳  停止中...",
            f"color: {c['status_wait_txt']};",
            False, False)

        if cfg.get("type") == "process":
            if self._stop_process(cfg):
                self._log(f"{svc} 已停止")
            else:
                self._log(f"{svc} 未在运行")
        else:
            out, err = self._run_nssm(["stop", svc])
            if out:
                self._log(out)
            if err:
                self._log(err)

        time.sleep(1.5)
        self.refresh_status(combo_index)

    # ── 注册 / 卸载 ──

    def install_service(self, combo_index: int):
        cfg = self.current_cfg(combo_index)
        svc = cfg["service_name"]
        log_path = os.path.join(SERVER_DIR, "data", "logs", "claw")
        os.makedirs(log_path, exist_ok=True)

        if cfg.get("type") == "process":
            self._log(f"{svc} 为进程模式，无需注册")
            self.refresh_status(combo_index)
            return

        self._log(f"注册 {svc} ...")

        if "bat_path" in cfg:
            bat = cfg["bat_path"]
            self._run_nssm(["install", svc, r"C:\Windows\System32\cmd.exe", "/c", bat])
            self._run_nssm(["set", svc, "AppDirectory", os.path.dirname(bat)])
            self._run_nssm(["set", svc, "AppEnvironmentExtra",
                            f"USERPROFILE={os.environ.get('USERPROFILE', '')}"])
        elif "exe_path" in cfg:
            exe_path = cfg["exe_path"]
            args = cfg.get("args", "")
            install_args = ["install", svc, exe_path]
            if args:
                install_args.extend(args.split())
            self._run_nssm(install_args)
            self._run_nssm(["set", svc, "AppDirectory", os.path.dirname(exe_path)])
        else:
            self._run_nssm(["remove", svc, "confirm"])
            self._run_nssm(["install", svc, VENV_PYTHON_STR, cfg["script_path"]])
            self._run_nssm(["set", svc, "AppDirectory", SERVER_DIR])

        self._run_nssm(["set", svc, "AppStdout", os.path.join(log_path, "stdout.log")])
        self._run_nssm(["set", svc, "AppStderr", os.path.join(log_path, "stderr.log")])
        self._run_nssm(["set", svc, "AppThrottle", "1000"])
        self._log(f"{svc} 注册完成")
        self.refresh_status(combo_index)

    def remove_service(self, combo_index: int):
        cfg = self.current_cfg(combo_index)
        svc = cfg["service_name"]

        if cfg.get("type") == "process":
            self._log(f"{svc} 为进程模式，无需卸载")
            self.refresh_status(combo_index)
            return

        self._run_nssm(["stop", svc])
        self._run_nssm(["remove", svc, "confirm"])
        self._log(f"{svc} 已卸载")
        self.refresh_status(combo_index)
