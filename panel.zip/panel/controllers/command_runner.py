"""命令执行器：inline 回显 / popup 弹窗"""
import os
import subprocess
import threading


class CommandRunner:
    """封装快捷指令执行逻辑。"""

    def __init__(self, log_callback, lock_callback):
        self._log = log_callback
        self._lock = lock_callback

    def exec_grid_cmd(self, title: str, cwd_dir: str, command: str, mode: str = "inline"):
        self._log(f"[{title}] {command}")

        if not os.path.exists(cwd_dir):
            self._log(f"目录不存在: {cwd_dir}")
            return

        if mode == "popup":
            self._exec_popup(title, cwd_dir, command)
        else:
            self._exec_inline(title, cwd_dir, command)

    def _exec_popup(self, title: str, cwd_dir: str, command: str):
        try:
            new_cmd = (
                f'start "Claw - {title}" cmd /k '
                f'"cd /d {cwd_dir} && {command} && echo. && '
                f'echo ===== 完成，按任意键关闭 ==== && pause >nul"'
            )
            subprocess.Popen(new_cmd, shell=True, creationflags=subprocess.CREATE_NO_WINDOW)
            self._log(f"新窗口已启动: {title}")
        except Exception as e:
            self._log(f"启动失败: {e}")

    def _exec_inline(self, title: str, cwd_dir: str, command: str):
        self._lock(True)

        def _run():
            try:
                proc = subprocess.Popen(
                    command, cwd=cwd_dir, shell=True,
                    stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                    creationflags=subprocess.CREATE_NO_WINDOW
                )
                while True:
                    line = proc.stdout.readline()
                    if not line:
                        break
                    self._log(line.decode("utf-8", errors="replace").rstrip())
                proc.wait()
                self._log(f"完成 (exit={proc.returncode})")
            except Exception as e:
                self._log(f"执行失败: {e}")
            finally:
                self._lock(False)

        threading.Thread(target=_run, daemon=True).start()
