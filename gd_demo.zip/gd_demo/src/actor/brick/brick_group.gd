extends Node2D
class_name  BrickGroup

const SHAPES = {
	"I": [Vector2i(-1, 0), Vector2i(0, 0), Vector2i(1, 0), Vector2i(2, 0)],
	"T": [Vector2i(0, -1), Vector2i(-1, 0), Vector2i(0, 0), Vector2i(1, 0)],
	"O": [Vector2i(0, 0), Vector2i(1, 0), Vector2i(0, 1), Vector2i(1, 1)],
}
var brick_scene = preload("res://src/actor/brick/brick.tscn")
var brick_rect:Vector2 = Vector2(49,49)
var current_cells: Array[Vector2i] = []
@onready var fall_timer: Timer = $FallTimer
@onready var brick_group: Node2D = $brick_group

@export var type:String = "":   # I T O
	set(new_type):
		if type != "":
			return
		type = new_type
		if is_node_ready():
			init_group()
		
@export var direction:Vector2 = Vector2(0,0):
	set(new_direction):
		direction = new_direction
		if is_node_ready():
			init_group()


@export var state:int = 0:   # 0 待命  1 控制中  2 已静止
	set(new_state):
		pass

func _ready() -> void:
	fall_timer.timeout.connect(_on_fall_timer_timeout)
	fall_timer.start()

func _on_fall_timer_timeout():
	move_down()
	
func move_down():
	if can_move(Vector2i(0, 1)):
		position.y += brick_rect.y
	else:
		lock_and_spawn_next()


func _input(event):
	if event.is_action_pressed("ui_down"):
		# 玩家按下下键，缩短计时器时间实现加速
		fall_timer.wait_time = 0.05
	if event.is_action_released("ui_down"):
		# 松开后恢复正常速度（假设正常速度是 0.5 秒一格）
		fall_timer.wait_time = 0.5

# 假设你有一个记录所有静止方块位置的网格系统（如 TileMapLayer）
func can_move(direction: Vector2i) -> bool:
	for cell_logic_pos in current_cells:
		# 计算下落后的逻辑位置
		# 当前容器位置(网格化) + 小方块相对位置 + 移动方向
		var current_grid_pos = Vector2i(position / brick_rect)
		var target_pos = current_grid_pos + cell_logic_pos + direction
		
		# 1. 检查是否超出底部边界 (假设高度 20)
		if target_pos.y >= 20:
			return false
		
		# 2. 检查是否超左右边界 (假设宽度 10)
		if target_pos.x < 0 or target_pos.x >= 10:
			return false
			
		# 3. 检查是否撞到了 TileMap 上已经存在的方块
		# if tilemap.get_cell_source_id(target_pos) != -1: return false
		
	return true


func lock_and_spawn_next():
	fall_timer.stop()
	# 等待一小会儿，给玩家最后的微调机会
	await get_tree().create_timer(0.2).timeout
	
	# 再次检查是否真的不能下落了
	if not can_move(Vector2i(0, 1)):
		# 执行固化逻辑：将当前 BrickGroup 的子方块坐标转录到全局 TileMap 中
		# 然后删除当前的 BrickGroup 并生成下一个
		#emit_signal("locked")
		pass
	else:
		fall_timer.start() # 如果玩家刚才的操作让方块又能动了，继续下落

func change_direction():
	if type == "O": return # O型不需要旋转
	# 1. 计算旋转后的新坐标数据
	var new_cells: Array[Vector2i] = []
	for cell in current_cells:
		# 顺时针旋转公式: (x, y) -> (-y, x)
		# 注意：通常以 (1, 1) 或 (2, 1) 作为中心点旋转效果更好
		# 这里我们先用原点旋转
		new_cells.append(Vector2i(-cell.y, cell.x))
	current_cells = new_cells
	# 2. 更新场景中子节点的位置
	var bricks = brick_group.get_children()
	for i in range(bricks.size()):
		var target_pos = Vector2(current_cells[i].x * brick_rect.x, current_cells[i].y * brick_rect.y)
		# 使用 Tween 让旋转变平滑
		var tween = create_tween()
		tween.tween_property(bricks[i], "position", target_pos, 0.001).set_trans(Tween.TRANS_SINE)

func init_group():
	var node_count = brick_group.get_child_count()
	if node_count < 1:
		var raw_data = SHAPES.get(type, [])
		var brick_data: Array[Vector2i] = []
		brick_data.assign(raw_data)
		for bd in brick_data:
			var brick = brick_scene.instantiate()
			brick.position = Vector2(bd.x * brick_rect.x,bd.y * brick_rect.y)
			brick_group.add_child(brick)
		current_cells = brick_data
	
	
