extends Node


#卡片数据
var sugars_dict = [
	{
		"id":1,
		"texture":"1.png",
	},
	{
		"id":2,
		"texture":"2.png",
	},
	{
		"id":3,
		"texture":"3.png",
	},
	{
		"id":4,
		"texture":"4.png",
	},
	{
		"id":5,
		"texture":"5.png",
	},
	{
		"id":6,
		"texture":"6.png",
	},
	{
		"id":7,
		"texture":"7.png",
	},
	{
		"id":8,
		"texture":"8.png",
	},
	{
		"id":9,
		"texture":"9.png",
	},
	{
		"id":10,
		"texture":"10.png",
	},
	{
		"id":11,
		"texture":"11.png",
	},
	{
		"id":12,
		"texture":"12.png",
	},
	{
		"id":13,
		"texture":"13.png",
	},
	{
		"id":14,
		"texture":"14.png",
	},
	{
		"id":15,
		"texture":"15.png",
	},
	{
		"id":16,
		"texture":"16.png",
	},
]

@export var sugarResList : Array[CardRes] = []:
	set(new_sugarResList):
		sugarResList = new_sugarResList
	get:
		return sugarResList
		
		
#初始化卡片资源
func init_sugarResList():
	var resource_path_card = "res://assets/textures/cards/yang/"
	for sugar in sugars_dict:
		var id = sugar["id"]
		var texture = resource_path_card+sugar["texture"]
		var sugarRes = CardRes.new()
		sugarRes.id = id
		sugarRes.card_texture = load(texture)
		sugarResList.append(sugarRes)
	print("SugarRes Init Count: ",sugarResList.size())
	
