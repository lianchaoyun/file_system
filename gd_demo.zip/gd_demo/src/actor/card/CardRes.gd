extends Resource

class_name CardRes

@export var id:int
@export var card_texture:CompressedTexture2D
