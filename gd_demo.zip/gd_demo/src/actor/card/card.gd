extends Node2D
class_name  Card


@onready var area_2d: Area2D = $Area2D
@onready var bg: Sprite2D = $bg
@onready var sprite_2d: Sprite2D = $bg/Sprite2D
signal card_click(cd:Node2D)
signal card_change
var is_click:bool=false
var last_child_index: int = -1   #上一次，在父节点的位置
var normal_scale: float = 0.8  #默认缩放
var pressed_scale: float = 1.0 # 按下缩放
var card_rect:Vector2 = Vector2(120,135) *  normal_scale  #卡片大小
var move_state:int = 0 #移动状态 0 静止  1 需要移动 2 移动中

@export var card_res : CardRes:
	set(new_item):
		card_res = new_item
		$bg/Sprite2D.texture =card_res.card_texture
	get:
		return card_res

@export var light : bool:
	set(new_light):
		light = new_light
		if  light:
			modulate =  Color8(255, 255, 255, 255)
			set_process_input(true)	
		else:
			modulate =  Color8(100, 100, 100, 255)
			set_process_input(false)
	get:
		return light


@export var state:int = 0:   # 0  在Cards中   1 在Stage中
	set(new_state):
		if state == 0 and new_state == 1:
			state = new_state
			area_2d.monitoring = false
			area_2d.monitorable = false
			move_state = 1
			move_to_stage()
		


func _ready() -> void:
	#var a = sprite_2d.get_rect().size*scale
	#print(a,scale)
	pass

func _input(event: InputEvent) -> void:
	if state != 0:return
	if event is InputEventMouseButton  and event.button_index == MOUSE_BUTTON_LEFT:
		if event.pressed:
			if bg.get_rect().has_point(bg.to_local(event.position)):
				var tween:Tween = get_tree().create_tween()
				tween.tween_property(bg, "scale", Vector2(1,1), 0.1)
				get_viewport().set_input_as_handled()
				is_click = true
		elif event.is_released():
				if is_click:
					emit_signal("card_click",self)
				else:
					var tween:Tween = get_tree().create_tween()
					tween.tween_property(bg, "scale", Vector2(0.8,0.8), 0.1)
				
				is_click = false

func reset_scale(val:int):
	bg.scale = Vector2(val,val)
	sprite_2d.scale = Vector2(val,val)

func move_to_stage():
	if move_state != 1:return
	move_state = 2
	var index = get_index()
	if index != last_child_index:
		var x = card_rect.x * index
		if position.x != x:
			var tween:Tween = get_tree().create_tween()
			tween.set_parallel(true)
			tween.tween_property(bg, "scale", Vector2(normal_scale, normal_scale), 0.2)
			tween.tween_property(self, "position", Vector2(x,0), 0.2).set_trans(Tween.TRANS_SINE)
			await tween.finished
			move_state = 0
		last_child_index = index




func die():
	queue_free()

func update_state():
	if state == 0:
		var overlapping_nodes = area_2d.get_overlapping_areas()
		var tmp_index:int = -1
		for node in overlapping_nodes:
			if node is Area2D:
				var card = node.get_parent()
				if card.has_method("update_state"):
					if card.get_index() > tmp_index:
						tmp_index= card.get_index()		
		light = tmp_index < get_index()
	elif state == 1:
		light = true

func _on_area_2d_area_entered(area: Area2D) -> void:
	if state == 0:
		update_state()
		
func _on_area_2d_area_exited(area: Area2D) -> void:
	if state == 0:
		update_state()
