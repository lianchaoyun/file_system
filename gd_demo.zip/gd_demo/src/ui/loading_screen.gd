extends Control


@onready var progress_bar: ProgressBar = $ProgressBar
@onready var load_delay_timer: Timer = $LoadDelayTimer


func _ready() -> void:
	progress_bar.value = 10
	load_delay_timer.timeout.connect(_on_load_delay_timer_timeout)
	load_delay_timer.start()

func _on_load_delay_timer_timeout():
	progress_bar.value+=10
	if progress_bar.value >= 100:
		load_delay_timer.stop()
		Gamestate.transition_to(Gamestate.State.MAIN_MENU)
		
	
	
	
