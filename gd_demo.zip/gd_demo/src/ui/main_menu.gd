extends Control

@onready var start: TextureButton = $BoxContainer/Start

func _ready() -> void:
	start.pressed.connect(on_start_game)
	pass


func on_start_game():
	Gamestate.transition_to(Gamestate.State.GAME_RUNNING)
