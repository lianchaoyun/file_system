extends Node2D


var brickgroup_scene = preload("res://src/actor/brick/brick_group.tscn")
@onready var pos_1: Node2D = $Pos/Pos1
@onready var pos_2: Node2D = $Pos/Pos2

var current_brickgroup:BrickGroup = null

func _ready() -> void:
	pass


func init_level():
	var brick_group = brickgroup_scene.instantiate()
	brick_group.position = pos_1.position
	current_brickgroup = brick_group
	add_child(brick_group)
	brick_group.type = "T"

	

func _on_button_pressed() -> void:
	init_level()


func _on_button_2_pressed() -> void:
	if current_brickgroup:
		current_brickgroup.change_direction()
