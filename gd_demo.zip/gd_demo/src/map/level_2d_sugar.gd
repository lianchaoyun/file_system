extends Node2D

@onready var sugar: Node2D = $Sugar/Sugar
@onready var sugar_2: Node2D = $Sugar/Sugar2

var selected_node: Node2D = null
var mouse_start_pos: Vector2 = Vector2.ZERO
var threshold: float = 30.0 # 拖动超过30像素判定为意图滑动

func _input(event: InputEvent) -> void:
	if event is InputEventMouseButton:
		if event.pressed:
			# 1. 检测点击了哪颗糖果 (简单矩形碰撞判断)
			var mouse_pos = get_local_mouse_position()
			if _get_rect(sugar).has_point(mouse_pos):
				selected_node = sugar
				mouse_start_pos = mouse_pos
			elif _get_rect(sugar_2).has_point(mouse_pos):
				selected_node = sugar_2
				mouse_start_pos = mouse_pos
				
		elif not event.pressed and selected_node:
			# 2. 松开时判定方向
			var drag_vector = get_local_mouse_position() - mouse_start_pos
			if drag_vector.length() > threshold:
				_handle_swipe(selected_node, drag_vector)
			selected_node = null

# 获取节点的点击区域 (假设糖果大小是 128x128)
func _get_rect(node: Node2D) -> Rect2:
	return Rect2(node.position - Vector2(64, 64), Vector2(128, 128))

func _handle_swipe(active_node: Node2D, drag_vec: Vector2):
	# 判定滑动是偏向水平还是垂直
	var is_horizontal = abs(drag_vec.x) > abs(drag_vec.y)
	
	# 这里简化逻辑：只要发生了有效滑动，就让 sugar 和 sugar_2 交换
	# 在正式游戏中，你会根据 is_horizontal 寻找那个方向上的邻居
	if (active_node == sugar and is_horizontal) or (active_node == sugar_2 and is_horizontal):
		swap_nodes(sugar, sugar_2)

# 执行交换动画
func swap_nodes(n1: Node2D, n2: Node2D):
	var p1 = n1.position
	var p2 = n2.position
	
	var tween = create_tween().set_parallel(true).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	
	# 糖果传奇的特色是带有一点点弹性的动画 (TRANS_BACK)
	tween.tween_property(n1, "position", p2, 0.4)
	tween.tween_property(n2, "position", p1, 0.4)
	
	# 动画结束后的处理
	tween.chain().tween_callback(func():
		print("交换完成，检查三消逻辑...")
	)
	
func swap_and_check(n1, n2):
	# 1. 换过去
	swap_nodes(n1, n2)
	# 2. 检查是否匹配（伪代码）
	if not check_match():
		# 3. 如果没匹配，0.4秒后换回来
		await get_tree().create_timer(0.4).timeout
		swap_nodes(n1, n2)

func check_match():
	return false
