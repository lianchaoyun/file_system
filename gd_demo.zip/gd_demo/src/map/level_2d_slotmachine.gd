extends Node2D

@onready var tile_map_layer: TileMapLayer = $TileMapLayer

@onready var effect_tile_map_layer: TileMapLayer = $EffectTileMapLayer

func _ready() -> void:
	pass
	var pos = Vector2i(3, 1) # 目标格子坐标
	tile_map_layer.set_cell(pos, 1, Vector2i(2, 2))
	highlight_cell(Vector2i(5, 5), Color.RED)


func highlight_cell(pos: Vector2i, color: Color):
	effect_tile_map_layer.modulate = color
	effect_tile_map_layer.set_cell(pos, 1,  Vector2i(4, 0))
