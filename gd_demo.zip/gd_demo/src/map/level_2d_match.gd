extends Node2D

@onready var cards_manager: Node = $CardsManager
@onready var game_over_dialog: ConfirmationDialog = $GameOverDialog
@onready var cards: Node2D = $Cards
@onready var stage: Node2D = $Stage
var card_count:int = 100
var card_scene = preload("res://src/actor/card/card.tscn")
@onready var pos_1: Node2D = $Poss/Pos1
@onready var pos_2: Node2D = $Poss/Pos2
@onready var pos_3: Node2D = $Poss/Pos3
@onready var pos_4: Node2D = $Poss/Pos4

var stage_max_count: int = 7 # stage最大存放数量

func _ready() -> void:
	init_level()


func _on_button_pressed() -> void:
	restart_game()
	
func init_level() -> void:
	cards_manager.init_cardResList()
	var cardResList:Array[CardRes] = cards_manager.cardResList
	for i in range(card_count):
		var card_instance = card_scene.instantiate()
		card_instance.position = Vector2(randf_range(pos_1.position.x, pos_2.position.x), randf_range(pos_1.position.y, pos_2.position.y))
		card_instance.card_res =  cardResList[randi_range(0,cardResList.size()-1)]
		cards.add_child(card_instance)
		card_instance.card_click.connect(_on_card_click)
		await get_tree().create_timer(0.02).timeout
		
func _on_card_click(cd: Node2D):
	var card_count:int  = stage.get_child_count()
	if card_count + 1 > stage_max_count:
		return
	var cd_index = - 1  
	var cd_res: CardRes = cd.card_res
	#计算存放的位置
	for i in range(card_count - 1, -1, -1):
		var child = stage.get_child(i)
		var child_card := child as Card
		if child_card:
			if child_card.card_res.id == cd_res.id:
				cd_index = i + 1
				break
		
	cd.reparent(stage)
	stage.move_child(cd, cd_index)
	#移动已有节点
	var card_id_count = 0
	for child in stage.get_children():
		var child_card := child as Card
		child_card.move_state = 1
		child_card.move_to_stage()
		if child_card.card_res.id == cd_res.id:
			card_id_count+=1

	cd.state = 1
	# 消除大于3个的节点
	if card_id_count >= 3:
		await get_tree().create_timer(0.2).timeout
		for child in stage.get_children():
			var child_card := child as Card
			if child_card.card_res.id == cd_res.id:
				stage.remove_child(child)
				child_card.die()
				
		for child in stage.get_children():
			var child_card := child as Card
			child_card.move_state = 1
			child_card.move_to_stage()
	
	#判断是否游戏结束
	var card_count_final:int  = stage.get_child_count()
	if card_count_final >= 7:
		game_over_dialog.show()


func restart_game():
	for child in cards.get_children():
		child.queue_free()
	for child in stage.get_children():
		child.queue_free()
	await get_tree().create_timer(3.0).timeout
	init_level()

func _on_game_over_dialog_canceled() -> void:
	get_tree().quit()


func _on_game_over_dialog_confirmed() -> void:
	restart_game() 
