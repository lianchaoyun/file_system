res://
├── .godot/                # 引擎自动生成的缓存（不要手动修改）
├── assets/                # 原始资源（不带逻辑的外部文件）
│   ├── audio/             # 音乐 (.ogg) 与 音效 (.wav)
│   ├── textures/          # 贴图与环境贴图
│   ├── models/            # 3D 模型 (.glb/fbx)
│   └── fonts/             # 字体文件
│
├── src/                   # 核心源代码与场景（按功能模块划分）
│   ├── common/            # 全局通用组件（如：着色器库、UI 基础类）
│   ├── entities/          # 游戏实体
│   │   ├── player/        # 玩家模块（包含 .tscn, .gd, 以及专用资源）
│   │   └── enemies/       # 敌人模块
│   ├── maps/            # 关卡
│   │   ├── level_01/
│   │   └── level_02/
│   └── ui/                # 用户界面（主菜单、HUD、设置等）
│
├── core/                  # 框架层（非游戏业务逻辑）
│   ├── autoloads/         # 单例脚本 (Global.gd, GameState.gd)
│   ├── systems/           # 独立系统（存档系统、成就系统）
│   └── utilities/         # 静态工具类或插件脚本
│
├── data/             # 游戏数据资源 (Custom Resources .tres)
│   ├── items/             # 道具数据
│   └── stats/             # 数值配置
│
├── addons/                # 第三方插件
└── export/                # 导出后的二进制文件（通常在 .gitignore 中忽略）
