extends Node

# 定义游戏状态枚举
enum State {
	NONE,
	MAIN_MENU,
	GAME_RUNNING,
	PAUSED,
	GAME_OVER,
	LOADING,
}

var current_state: State = State.NONE:
	set(new_state):
		if current_state == new_state:
			return
		print("Changing game state from %s to %s" % [State.keys()[current_state], State.keys()[new_state]])
		_exit_state(current_state)
		current_state = new_state
		_enter_state(current_state)
		emit_signal("game_state_changed", current_state)

# 定义一个信号，用于通知其他节点游戏状态已改变
signal game_state_changed(new_state)

func _ready():
	# 游戏启动时，通常从主菜单开始
	#self.current_state = State.MAIN_MENU
	pass

# 进入某个状态时执行的逻辑
func _enter_state(state: State):
	match state:
		State.MAIN_MENU:
			# 加载主菜单场景
			get_tree().change_scene_to_file("res://src/ui/main_menu.tscn")
			pass
		State.GAME_RUNNING:
			# 开始游戏逻辑，可能加载游戏场景
			if get_tree().current_scene.name != "GameScene": # 避免重复加载
				get_tree().change_scene_to_file("res://src/map/level_2d_platform.tscn")
			get_tree().paused = false # 确保游戏未暂停
			#Input.set_mouse_mode(Input.MOUSE_MODE_CAPTURED) # 锁定鼠标
			pass
		State.PAUSED:
			# 暂停游戏，显示暂停菜单
			get_tree().paused = true
			# 假设暂停菜单是已加载场景的子节点或通过其他方式显示
			# get_tree().get_root().find_node("PauseMenu", true, false).show()
			#Input.set_mouse_mode(Input.MOUSE_MODE_VISIBLE) # 显示鼠标
			pass
		State.GAME_OVER:
			# 游戏结束逻辑，显示结束画面
			get_tree().paused = true
			get_tree().change_scene_to_file("res://src/ui/game_over_screen.tscn")
			#Input.set_mouse_mode(Input.MOUSE_MODE_VISIBLE)
			pass
		State.LOADING:
			# 显示加载屏幕
			get_tree().change_scene_to_file("res://src/ui/loading_screen.tscn")
			pass
		_:
			pass # 未定义的状态

# 退出某个状态时执行的逻辑
func _exit_state(state: State):
	match state:
		State.MAIN_MENU:
			# 移除主菜单相关UI
			pass
		State.GAME_RUNNING:
			pass
		State.PAUSED:
			get_tree().paused = false # 解除游戏暂停
			# 隐藏暂停菜单
			# get_tree().get_root().find_node("PauseMenu", true, false).hide()
			#Input.set_mouse_mode(Input.MOUSE_MODE_CAPTURED) # 再次锁定鼠标
			pass
		State.GAME_OVER:
			pass
		State.LOADING:
			pass
		_:
			pass # 未定义的状态

# 外部调用函数，用于改变游戏状态
func transition_to(new_state: State):
	self.current_state = new_state

# 辅助函数，判断当前是否处于某个状态
func is_in_state(state: State) -> bool:
	return current_state == state
