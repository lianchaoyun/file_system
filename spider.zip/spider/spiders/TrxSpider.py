import scrapy


class QuotesSpider(scrapy.Spider):
    name = "trx"
    start_urls = [
        "https://www.blockchain.com/explorer/addresses/btc/bc1q0ss2zcfaxsvl5pf6uktk8xet9m82w4dcd96j5d",
    ]

    def parse(self, response):
        print(response.body)