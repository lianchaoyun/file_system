//获取cookie
function getCookie(cname,defaultVal="")
{
    var name = cname + "=";
    var ca = document.cookie.split(';');
    for(var i=0; i<ca.length; i++)
    {
        var c = ca[i].trim();
        if (c.indexOf(name)==0) return c.substring(name.length,c.length);
    }
    return defaultVal;
}
//设置cookie
function setCookie(cname, cvalue, exdays) {
    const d = new Date();
    d.setTime(d.getTime() + (exdays * 60 * 60 * 1000));
    let expires = "expires="+d.toUTCString();
    document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
}


//设置url参数
function setParams(paramName, paramValue,isReload = 1) {
   const urlParams = new URLSearchParams(window.location.search);
   if(paramValue){
       urlParams.set(paramName, paramValue);
   }else{
       urlParams.delete(paramName);
   }
    window.history.replaceState({}, '', `${window.location.pathname}?${urlParams}`);
    if(isReload == 1){ //是否重新刷新页面
        window.location.reload();
    }
}
//获取url参数isObject:1 对象 2 url参数 3 单个value
function getParams(params1,isObject=1){
    const urlParams = new URLSearchParams(window.location.search);
    if(isObject == 3){
        urlParams.get(key);
    }
    let datasParams = {};
    if(isObject==1){
        datasParams["token"] =  getUser("user_token");
    }
    for (const [key, value] of urlParams.entries()) {
        datasParams[key] = value;
    }
    const mergedObject = Object.assign({}, datasParams, params1);
    if(isObject == 1){//返回key=value,object形式
        return mergedObject;
    }

    const queryParams = Object.entries(mergedObject).map(([key, value]) => {
        return `${encodeURIComponent(key)}=${encodeURIComponent(value)}`;
    });
    return queryParams.join('&'); //返回key=value参数形式
}

//获取当前登录用户属性
function getUser(key){
    let userData = localStorage.getItem("user");
    let user = userData ? JSON.parse(userData) : null;
    return user && key ? user[key] : user;
}
//退出
function signout() {
    localStorage.removeItem("user");
    window.location.reload();
}

//创建分页第几页
function createPaginationElement(url,text,active){
    let li = document.createElement('li');
    let a = document.createElement('a');
    a.textContent = text;
    a.setAttribute("href",url);
    if(active){
        a.classList.add("active");
    }
    li.appendChild(a);
    return li;
}

//创建分页
function createPagination(path,total,pageSize,currentPage,paginationId){
    let last_page=currentPage > 1 ? currentPage-1 : currentPage;
    let last_page_url=path+'?'+getParams({"page":last_page},0)+"  ";
    const totalPages = Math.ceil(total / pageSize);

    let next_page = currentPage < totalPages ? currentPage+1 : currentPage;
    let next_page_url=path+'?'+getParams({"page":next_page},0);

    const pagination = document.getElementById(paginationId);
    let first = createPaginationElement(last_page_url,'«',false);
    pagination.appendChild(first);
    for (let i = 1; i <= totalPages; i++) {
        let e = createPaginationElement(path+"?"+getParams({"page":i},0),i,currentPage === i);
        pagination.appendChild(e);
    }

    let last = createPaginationElement(next_page_url,"»",false);
    pagination.appendChild(last);
}
