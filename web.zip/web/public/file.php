<?php
require '../vendor/autoload.php';
use Intervention\Image\Image;
use Intervention\Image\ImageManager;
use Intervention\Image\Drivers\GD\Driver;

function getDataPath($key, $filePath = '../.env') {
    //$lines = file($filePath, FILE_IGNORE_NEW_LINES);
    $file = fopen($filePath, "r");
    fseek($file, 0);
    $line = fgets($file);
    fclose($file);
    $dataPathArr = explode('=', $line, 2);
    return trim($dataPathArr[1]);
}
function get_mime_by_extension($extension) {
    $mimeTypes = array(
        'jpg' => 'image/jpeg',
        'png' => 'image/png',
        'gif' => 'image/gif',
    );
    return isset($mimeTypes[$extension]) ? $mimeTypes[$extension] : null;
}

$width = null;
$height = null;

$requestUri = $_SERVER['REQUEST_URI'];
#$queryString = $_SERVER['QUERY_STRING'];
$pathParts = explode('/', $requestUri);
$subPath = array_slice($pathParts, 2);

$joinedSubPath = "";
foreach ($subPath as $key => $value) {
   if($key == 0 && str_contains($value, "x")){
       $path1Arr = explode('x', $value);
       $width = is_numeric($path1Arr[0])?$path1Arr[0]:null;
       $height = is_numeric($path1Arr[1])?$path1Arr[1]:null;
       if($width > 0 || $height > 0){
           continue;
       }
   }
    $joinedSubPath=$joinedSubPath."/". $value;
}

$realPath = getDataPath('DATA_PATH').$joinedSubPath;

if (file_exists($realPath)) {
    if($width > 0 || $height > 0){
        $manager = new ImageManager(new Driver());
        $image = $manager->read($realPath);
        $image->scaleDown($width,$height);
       // $image->place('image/avatar.png');
        $encoded  = $image->encode();
        $mimeType = $encoded->mimetype();
        header('Content-Type: '.$mimeType);
        echo $encoded;
    }else{
        $type = pathinfo($realPath, PATHINFO_EXTENSION);
        $mime = get_mime_by_extension($type);
         header('Content-Type: ' . $mime);
         readfile($realPath);
    }
} else {
    echo 'File does not exist.';
}


