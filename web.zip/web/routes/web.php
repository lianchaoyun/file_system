<?php

use App\Http\Controllers\DiscuzController;
use App\Http\Controllers\MoneyController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\IndexController;
use App\Http\Controllers\MediaController;
use App\Http\Controllers\PostsController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\LinksController;
use App\Http\Controllers\QuantController;

use Illuminate\Http\Request;



Route::get('/', [IndexController::class, 'index']);


Route::get('/randombg/', [MediaController::class, 'randombg']);
Route::any('/upload', [MediaController::class, 'upload']);
Route::any('/media', [MediaController::class, 'media']);



Route::any('/login', [UserController::class, 'login']);
Route::any('/register', [UserController::class, 'register']);
Route::any('/terms_resource', [UserController::class, 'terms_resource']);
Route::any('/user', [UserController::class, 'user']);


Route::get('/links', [LinksController::class, 'links']);
Route::get('/favicon', [LinksController::class, 'favicon']);


Route::get('/article/latest', [DiscuzController::class, 'getLatestThreads']);
Route::get('/article/hot-views', [DiscuzController::class, 'getHotThreadsByViews']);
Route::get('/article/hot-replies', [DiscuzController::class, 'getHotThreadsByReplies']);


