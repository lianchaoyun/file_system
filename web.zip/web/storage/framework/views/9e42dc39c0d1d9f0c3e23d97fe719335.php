<?php $__env->startSection('title',config('app.name').' - 春天来啦!'); ?>
<?php $__env->startSection('content'); ?>

<?php echo $__env->make('webnav', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('article', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('media', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('base', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /mnt/hgfs/project/yun/web/resources/views/index.blade.php ENDPATH**/ ?>