<div class="webnav" id="webnav">
        <ul class="webnav-tabs">
            <li class="webnav-tab" v-for="item in terms">
                <a :href="'#term_id_'+item.term_id">{{ item.name }}</a>
            </li>
        </ul>
        <div class="webnav-content">
            <div :id="'term_id_'+item.term_id" class="webnav-pane" v-for="item in terms">
                <a :href="link.url" class="webnav-link" v-for="link in item.links" target="_blank">
                    <span class="webnav-icon-wrap">
                        <img :src="'/favicon?domain=' + link.url"
                             class="webnav-icon" :alt="link.name"
                             v-on:error="handleFaviconError($event)"
                             v-on:load="handleFaviconLoad($event)">
                        <span class="webnav-icon-fallback">{{ link.name.charAt(0) }}</span>
                    </span>
                    <span class="webnav-link-name">{{ link.name }}</span>
                </a>
            </div>
        </div>
</div>

<script>
    Vue.createApp({
        data() {
            let user = {};
            try {
                let userData = localStorage.getItem("user");
                if (userData) user = JSON.parse(userData);
            } catch(e) {}
            return {
                user: user,
                terms:[],
                currentTabNav: -1,
            }
        },
        methods: {
            handleFaviconError(event) {
                const wrap = event.target.closest('.webnav-icon-wrap');
                if (wrap) {
                    event.target.style.display = 'none';
                }
            },
            handleFaviconLoad(event) {
                const wrap = event.target.closest('.webnav-icon-wrap');
                if (wrap) {
                    event.target.classList.add('loaded');
                    const fallback = wrap.querySelector('.webnav-icon-fallback');
                    if (fallback) fallback.style.display = 'none';
                }
            },
            initTab() {
                let tabNavLinks = document.querySelectorAll('.webnav-tab a');
                let tabPanes = document.querySelectorAll('.webnav-pane');
                let links_index = localStorage.getItem("links_index");
                let firstLink = undefined;
                tabNavLinks.forEach(link => {
                    let targetPaneId = link.getAttribute('href');
                    link.addEventListener('click', function (event) {
                        event.preventDefault();
                        const targetPane = document.querySelector(targetPaneId);
                        tabNavLinks.forEach(link => link.classList.remove('is-active'));
                        this.classList.add('is-active');
                        tabPanes.forEach(pane => pane.classList.remove('is-active'));
                        targetPane.classList.add('is-active');
                        localStorage.setItem("links_index", targetPaneId);
                    });
                    if (links_index === targetPaneId) {
                        firstLink = link
                    }
                    if (!firstLink) {
                        firstLink = link;
                    }
                });
                if (firstLink) {
                    firstLink.click();
                }
            },
            getLinks() {
                const _this = this;
                axios.get('/links', {
                    params: { token: this.user.token }
                }).then(function (response) {
                    _this.terms = response.data.data;
                    if (_this.terms && _this.terms.length) {
                        _this.currentTabNav = _this.terms[0].term_id;
                    }
                    setTimeout(function () {
                        _this.initTab();
                    }, 100)
                }).catch(function (error) {
                    console.log(error);
                });
            },
            getUser() {
                const _this = this;
                axios.get('/user', {
                    params: { token: this.user.token }
                }).then(function (response) {
                    if (response.data.errcode === 2) {
                        localStorage.removeItem("user")
                    } else {
                        localStorage.setItem("user", JSON.stringify(response.data.data));
                    }
                }).catch(function (error) {
                    console.log(error);
                });
            },
        },
        mounted() {
            this.getUser();
            this.getLinks();
        },
    }).mount('#webnav')
</script>
<?php /**PATH /mnt/d/project/yun/web/resources/views/webnav.blade.php ENDPATH**/ ?>