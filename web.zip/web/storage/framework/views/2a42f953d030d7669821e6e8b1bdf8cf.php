<div class="form-group">
    <label class="col-sm-2 control-label"> <?php echo e($label, false); ?></label>
    <div class="col-sm-8">
        <?php echo $__env->make($presenter->view(), array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>
</div><?php /**PATH /mnt/hgfs/project/yun/web/vendor/encore/laravel-admin/src/../resources/views/filter/where.blade.php ENDPATH**/ ?>