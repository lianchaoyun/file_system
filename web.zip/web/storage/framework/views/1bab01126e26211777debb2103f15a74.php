<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale()), false); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0,user-scalable=no, maximum-scale=1.0, minimum-scale=1.0">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <META HTTP-EQUIV="Pragma" CONTENT="no-cache">
    <META HTTP-EQUIV="Cache-Control" CONTENT="no-cache, must-revalidate">
    <META HTTP-EQUIV="Expires" CONTENT="0">

    <!-- CSS -->
    <link rel="stylesheet" href="/css/base.css"/>
    <link rel="stylesheet" href="/css/header.css"/>
    <link rel="stylesheet" href="/css/webnav.css"/>
    <link rel="stylesheet" href="/css/media.css"/>
    <link rel="stylesheet" href="/css/article.css"/>
    <!-- CSS: 页面扩展 -->
    <?php echo $__env->yieldContent('css'); ?>

    <script src="/js/base.js"></script>
    <script src="/js/vue.global.js"></script>
    <script src="/js/axios.min.js"></script>
</head>
<body id="body">
<!-- 页头 -->
<?php echo $__env->make('header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<!-- 页头结束 -->

<!-- 内容 -->
<?php echo $__env->yieldContent('content'); ?>
<!-- 内容结束 -->

<footer>
    <p>©2024-2025 yun.com </p>
    <address>
        123 Main Street Anytown, CA 12345
        <a href="mailto:mengyunv@gmail.com">mengyunv@gmail.com</a>
    </address>
</footer>


<?php echo $__env->yieldContent('js'); ?>
</body>
</html>
<?php /**PATH /mnt/hgfs/project/yun/web/resources/views/base.blade.php ENDPATH**/ ?>