<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>注册账号</title>
    <link rel="stylesheet" href="/css/user.css">
    <script src="/js/vue.global.js"></script>
    <script src="/js/axios.min.js"></script>
</head>
<body class="user-page">
<div class="user-bg">
    <div class="user-container" id="app">
        <div class="user-header">
            <div class="user-logo">YunHub</div>
            <p class="user-subtitle">加入我们</p>
        </div>

        <form class="user-form" @submit.prevent="register">
            <div class="user-field">
                <label class="user-label">
                    <svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor">
                        <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/>
                    </svg>
                    <span>用户名</span>
                </label>
                <input type="text" class="user-input" v-model="username" @input="clearError" autocomplete="off" placeholder="请输入用户名">
            </div>

            <div class="user-field">
                <label class="user-label">
                    <svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor">
                        <path d="M18 8h-1V6c0-2.76-2.24-5-5-5S7 3.24 7 6v2H6c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V10c0-1.1-.9-2-2-2zm-6 9c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2zm3.1-9H8.9V6c0-1.71 1.39-3.1 3.1-3.1 1.71 0 3.1 1.39 3.1 3.1v2z"/>
                    </svg>
                    <span>密码</span>
                </label>
                <input type="password" class="user-input" v-model="password" @input="clearError" autocomplete="off" placeholder="请输入密码">
            </div>

            <div class="user-field">
                <label class="user-label">
                    <svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor">
                        <path d="M18 8h-1V6c0-2.76-2.24-5-5-5S7 3.24 7 6v2H6c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V10c0-1.1-.9-2-2-2zm-6 9c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2zm3.1-9H8.9V6c0-1.71 1.39-3.1 3.1-3.1 1.71 0 3.1 1.39 3.1 3.1v2z"/>
                    </svg>
                    <span>确认密码</span>
                </label>
                <input type="password" class="user-input" v-model="password2" @input="clearError" autocomplete="off" placeholder="请再次输入密码">
            </div>

            <div class="user-alert" v-if="message">
                <svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor">
                    <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"/>
                </svg>
                <span>{{ message }}</span>
            </div>

            <button type="submit" class="user-btn" :class="{ loading: loading }">
                <span v-if="!loading">注 册</span>
                <span v-else class="user-btn-loader"></span>
            </button>
        </form>

        <div class="user-footer">
            <span>已有账号？</span>
            <a href="/login" class="user-link">立即登录</a>
        </div>
    </div>
</div>
</body>
<script>
    const {createApp, ref} = Vue
    const app = createApp({
        data() {
            return {
                username: "",
                password: "",
                password2: "",
                message: "",
                loading: false
            }
        },
        methods: {
            clearError() {
                this.message = "";
            },
            register() {
                if (!this.username) {
                    this.message = "用户名不能为空";
                    return;
                }
                if (!this.password) {
                    this.message = "密码不能为空";
                    return;
                }
                if (this.password !== this.password2) {
                    this.message = "两次密码不一致";
                    return;
                }
                this.loading = true;
                this.message = "";
                const _this = this;
                axios.post('/register', {
                    username: this.username,
                    password: this.password,
                    password2: this.password2,
                }).then(function (response) {
                    _this.loading = false;
                    if (response.data.errcode !== 0) {
                        _this.message = response.data.errmsg
                    } else {
                        localStorage.setItem("user", JSON.stringify(response.data.data));
                        window.location = "/"
                    }
                }).catch(function (error) {
                    _this.loading = false;
                    _this.message = "网络错误，请稍后重试";
                });
            },
        },
    })
    app.mount('#app')
</script>
</html>
<?php /**PATH /mnt/hgfs/project/yun/web/resources/views/user/register.blade.php ENDPATH**/ ?>