<div class="media" id="media">
    <!-- 刷新按钮 -->
    <div class="masonry-refresh" :class="{ spinning: loading }" @click="refresh" title="刷新">
        <svg viewBox="0 0 24 24" width="20" height="20" fill="currentColor">
            <path d="M17.65 6.35A7.958 7.958 0 0012 4c-4.42 0-7.99 3.58-7.99 8s3.57 8 7.99 8c3.73 0 6.84-2.55 7.73-6h-2.08A5.99 5.99 0 0112 18c-3.31 0-6-2.69-6-6s2.69-6 6-6c1.66 0 3.14.69 4.22 1.78L13 11h7V4l-2.35 2.35z"/>
        </svg>
    </div>

    <!-- 加载中骨架屏 -->
    <div class="masonry-skeleton" v-if="loading && medias.length === 0">
        <div class="masonry-skeleton-card" v-for="i in 10" :key="i" :class="'h'+[i%4+1]"></div>
    </div>

    <!-- 瀑布流主体 -->
    <div class="masonry" v-else-if="medias.length > 0">
        <div class="masonry-column" v-for="col in columns" :key="col">
            <div class="masonry-card" v-for="item in getColumnItems(col)" :key="item.id" @click="preview(item)">
                <div class="masonry-card-img-wrap">
                    <img v-if="item.type == 'image'" :src="item.url" alt="图片"
                         class="masonry-card-img" loading="lazy"
                         @load="$event.target.classList.add('is-loaded')">

                    <img v-else-if="item.type == 'video' && item.cover_url !== null"
                         :src="item.cover_url" alt="视频封面"
                         class="masonry-card-img" loading="lazy"
                         @load="$event.target.classList.add('is-loaded')">
                    <img v-else-if="item.type == 'video'" src="/i/image/place/video.png" alt="视频封面"
                         class="masonry-card-img" loading="lazy"
                         @load="$event.target.classList.add('is-loaded')">

                    <!-- 类型标签 -->
                    <span class="masonry-card-badge">
                        <span v-if="item.type == 'image'">图片</span>
                        <span v-else-if="item.type == 'video'">视频</span>
                    </span>

                    <!-- 视频播放标识 -->
                    <div v-if="item.type == 'video'" class="masonry-card-overlay">
                        <div class="masonry-card-play"></div>
                    </div>
                </div>

                <!-- 视频信息区域 -->
                <div v-if="item.type == 'video'" class="masonry-card-body">
                    <div class="masonry-card-title">{{ item.title }}</div>
                    <div class="masonry-card-desc">{{ item.group_name }}</div>
                </div>
            </div>
        </div>
    </div>

    <!-- 空状态 -->
    <div class="masonry-empty" v-else-if="!loading">
        <div class="masonry-empty-icon">📭</div>
        <div class="masonry-empty-text">暂无内容</div>
    </div>

    <!-- 加载更多 -->
    <div class="masonry-footer" v-if="hasMore && medias.length > 0">
        <span class="masonry-load-more" :class="{ loading: loading }" @click="loadMore">
            {{ loading ? '加载中...' : '加载更多' }}
        </span>
    </div>
</div>

<script>
    Vue.createApp({
        data() {
            let user = {};
            try {
                let userData = localStorage.getItem("user");
                if (userData) user = JSON.parse(userData);
            } catch(e) {}
            return {
                user: user,
                medias: [],
                loading: false,
                columnCount: 4,
                hasMore: true,
                size: 20
            }
        },
        computed: {
            columns() {
                return Array.from({ length: this.columnCount }, (_, i) => i);
            }
        },
        methods: {
            getColumnItems(colIndex) {
                return this.medias.filter((_, index) => index % this.columnCount === colIndex);
            },
            updateColumnCount() {
                const width = window.innerWidth;
                if (width <= 600) this.columnCount = 2;
                else if (width <= 900) this.columnCount = 3;
                else if (width <= 1200) this.columnCount = 4;
                else this.columnCount = 5;
            },
            getMedias(append = false) {
                let interestArray = [], formatArray = [];
                try { let d = localStorage.getItem("interest"); if(d) interestArray = JSON.parse(d); } catch(e) {}
                try { let d = localStorage.getItem("format"); if(d) formatArray = JSON.parse(d); } catch(e) {}

                this.loading = true;
                const _this = this;
                axios.get('/media', {
                    params: {
                        token: this.user.token,
                        size: this.size,
                        interests: interestArray,
                        formats: formatArray,
                    }
                }).then(function (response) {
                    let data = response.data.data;
                    if (append) {
                        _this.medias = [..._this.medias, ...data];
                    } else {
                        _this.medias = data;
                    }
                    _this.hasMore = data.length === _this.size;
                    _this.loading = false;
                }).catch(function (error) {
                    console.log(error);
                    _this.loading = false;
                });
            },
            refresh() {
                this.hasMore = true;
                this.getMedias();
            },
            loadMore() {
                this.getMedias(true);
            },
            preview(item) {
                window.open(item.url, '_blank');
            }
        },
        mounted() {
            this.updateColumnCount();
            window.addEventListener('resize', this.updateColumnCount);
            this.getMedias();
            this.intervalId = setInterval(() => {
                this.getMedias();
            }, 300000);
        },
        unmounted() {
            window.removeEventListener('resize', this.updateColumnCount);
            clearInterval(this.intervalId);
        }
    }).mount('#media')
</script>
<?php /**PATH /mnt/hgfs/project/yun/web/resources/views/media.blade.php ENDPATH**/ ?>