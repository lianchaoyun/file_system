<div class="article" id="article">
    <!-- 论坛文章区块 -->
    <section class="article-section article-section--main">
        <header class="article-header">
            <h2 class="article-title">
                <svg class="article-title-icon" width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M21 6h-2v9H6v2c0 .55.45 1 1 1h11l4 4V7c0-.55-.45-1-1-1zm-4 6V3c0-.55-.45-1-1-1H3c-.55 0-1 .45-1 1v14l4-4h10c.55 0 1-.45 1-1z"/>
                </svg>
                论坛热帖
            </h2>
            <nav class="article-tabs">
                <button class="article-tab" data-target="#articles_latest">最新</button>
                <button class="article-tab" data-target="#articles_hot_views">热门</button>
                <button class="article-tab" data-target="#articles_hot_replies">热议</button>
            </nav>
        </header>

        <!-- 最新 -->
        <div class="topic-list" id="articles_latest">
            <a v-for="(item,index) in articles_latest" 
               :href="'/x/forum.php?mod=viewthread&tid='+item.tid" 
               class="topic-card">
                <div class="topic-card-left">
                    <span class="topic-rank" :class="{'topic-rank--top': index < 3}">{{ index + 1 }}</span>
                    <span class="topic-subject">{{ item.subject }}</span>
                </div>
                <div class="topic-card-right">
                    <span class="topic-meta topic-meta--time">{{ formatDate(item.dateline) }}</span>
                    <span class="topic-meta">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M12 4.5C7 4.5 2.73 7.61 1 12c1.73 4.39 6 7.5 11 7.5s9.27-3.11 11-7.5c-1.73-4.39-6-7.5-11-7.5zM12 17c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5zm0-8c-1.66 0-3 1.34-3 3s1.34 3 3 3 3-1.34 3-3-1.34-3-3-3z"/>
                        </svg>
                        {{ item.views }}
                    </span>
                    <span class="topic-meta">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M21.99 4c0-1.1-.89-2-1.99-2H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h14l4 4-.01-18z"/>
                        </svg>
                        {{ item.replies }}
                    </span>
                </div>
            </a>
        </div>

        <!-- 热门浏览 -->
        <div class="topic-list" id="articles_hot_views">
            <a v-for="(item,index) in articles_hot_views" 
               :href="'/x/forum.php?mod=viewthread&tid='+item.tid" 
               class="topic-card">
                <div class="topic-card-left">
                    <span class="topic-rank" :class="{'topic-rank--top': index < 3}">{{ index + 1 }}</span>
                    <span class="topic-subject">{{ item.subject }}</span>
                </div>
                <div class="topic-card-right">
                    <span class="topic-meta topic-meta--highlight">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M12 4.5C7 4.5 2.73 7.61 1 12c1.73 4.39 6 7.5 11 7.5s9.27-3.11 11-7.5c-1.73-4.39-6-7.5-11-7.5zM12 17c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5z"/>
                        </svg>
                        {{ item.views }}
                    </span>
                </div>
            </a>
        </div>

        <!-- 热门回复 -->
        <div class="topic-list" id="articles_hot_replies">
            <a v-for="(item,index) in articles_hot_replies" 
               :href="'/x/forum.php?mod=viewthread&tid='+item.tid" 
               class="topic-card">
                <div class="topic-card-left">
                    <span class="topic-rank" :class="{'topic-rank--top': index < 3}">{{ index + 1 }}</span>
                    <span class="topic-subject">{{ item.subject }}</span>
                </div>
                <div class="topic-card-right">
                    <span class="topic-meta topic-meta--highlight">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M21.99 4c0-1.1-.89-2-1.99-2H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h14l4 4-.01-18z"/>
                        </svg>
                        {{ item.replies }}
                    </span>
                </div>
            </a>
        </div>
    </section>

    <!-- 诗词区块 -->
    <section class="article-section article-section--poetry">
        <header class="article-header">
            <h2 class="article-title">
                <svg class="article-title-icon" width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M12 22c4.97 0 9-4.03 9-9-4.97 0-9 4.03-9 9zM5.6 10.25c0 1.38 1.12 2.5 2.5 2.5.53 0 1.01-.16 1.42-.44l-.02.19c0 1.38 1.12 2.5 2.5 2.5s2.5-1.12 2.5-2.5l-.02-.19c.4.28.89.44 1.42.44 1.38 0 2.5-1.12 2.5-2.5 0-1-.59-1.85-1.43-2.25.84-.4 1.43-1.25 1.43-2.25 0-1.38-1.12-2.5-2.5-2.5-.53 0-1.01.16-1.42.44l.02-.19C14.5 3.62 13.38 2.5 12 2.5S9.5 3.62 9.5 5l.02.19c-.4-.28-.89-.44-1.42-.44-1.38 0-2.5 1.12-2.5 2.5 0 1 .59 1.85 1.43 2.25-.84.4-1.43 1.25-1.43 2.25zM12 5.5c1.38 0 2.5 1.12 2.5 2.5s-1.12 2.5-2.5 2.5S9.5 9.38 9.5 8s1.12-2.5 2.5-2.5zM3 13c0 4.97 4.03 9 9 9 0-4.97-4.03-9-9-9z"/>
                </svg>
                每日诗词
            </h2>
            <button class="poetry-refresh" @click="refreshPoetry" title="换一首">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M17.65 6.35C16.2 4.9 14.21 4 12 4c-4.42 0-7.99 3.58-7.99 8s3.57 8 7.99 8c3.73 0 6.84-2.55 7.73-6h-2.08c-.82 2.33-3.04 4-5.65 4-3.31 0-6-2.69-6-6s2.69-6 6-6c1.66 0 3.14.69 4.22 1.78L13 11h7V4l-2.35 2.35z"/>
                </svg>
            </button>
        </header>
        
        <div class="poetry-content" v-if="poetry">
            <div class="poetry-header">
                <h3 class="poetry-title">《{{ poetry.title }}》</h3>
                <span class="poetry-author">
                    <span class="poetry-dynasty">{{ poetry.dynasty }}</span>
                    <span class="poetry-author-name">{{ poetry.author }}</span>
                </span>
            </div>
            <p class="poetry-text">{{ poetry.content }}</p>
            <p class="poetry-translation" v-if="poetry.translation">{{ poetry.translation }}</p>
        </div>
        <div class="poetry-content poetry-content--loading" v-else>
            <div class="poetry-skeleton"></div>
            <div class="poetry-skeleton poetry-skeleton--short"></div>
        </div>
    </section>
</div>

<script>
    Vue.createApp({
        data() {
            let user = null;
            try {
                let userData = localStorage.getItem("user");
                if (userData) user = JSON.parse(userData);
            } catch(e) {}
            return {
                user: user,
                articles_latest: [],
                articles_hot_views: [],
                articles_hot_replies: [],
                poetry: null,
                poetryList: [
                    { title: '静夜思', dynasty: '唐', author: '李白', content: '床前明月光，疑是地上霜。举头望明月，低头思故乡。', translation: '明亮的月光洒在床前，好像地上泛起了一层霜。抬头望着天上的明月，低头不觉想起了自己的家乡。' },
                    { title: '春晓', dynasty: '唐', author: '孟浩然', content: '春眠不觉晓，处处闻啼鸟。夜来风雨声，花落知多少。', translation: '春天的夜晚睡得很沉，连天亮了都不知道。到处都能听到鸟鸣声。想起夜里刮风下雨的声音，不知道有多少花瓣被打落了。' },
                    { title: '登鹳雀楼', dynasty: '唐', author: '王之涣', content: '白日依山尽，黄河入海流。欲穷千里目，更上一层楼。', translation: '太阳沿着山脉沉落，黄河向着大海奔流。想要看得更远，就要再登上一层楼。' },
                    { title: '相思', dynasty: '唐', author: '王维', content: '红豆生南国，春来发几枝。愿君多采撷，此物最相思。', translation: '红豆生长在南方，春天来了萌发了新枝。希望你能多采摘一些，因为它最能表达相思之情。' },
                    { title: '出塞', dynasty: '唐', author: '王昌龄', content: '秦时明月汉时关，万里长征人未还。但使龙城飞将在，不教胡马度阴山。', translation: '秦汉时的明月和边关依然如故，远征万里的将士还没有回来。如果有像李广那样的将军在，就绝不会让敌人的战马越过阴山。' },
                    { title: '枫桥夜泊', dynasty: '唐', author: '张继', content: '月落乌啼霜满天，江枫渔火对愁眠。姑苏城外寒山寺，夜半钟声到客船。', translation: '月亮落下，乌鸦啼叫，寒霜弥漫天空。江边的枫树和渔火陪伴着满怀愁思的旅客难以入眠。苏州城外寒山寺的钟声，半夜时分传到了客船上。' },
                    { title: '望庐山瀑布', dynasty: '唐', author: '李白', content: '日照香炉生紫烟，遥看瀑布挂前川。飞流直下三千尺，疑是银河落九天。', translation: '阳光照射下，香炉峰升起紫色的云烟。远远望去，瀑布像一条白绢挂在山前。水流从高处飞泻而下三千尺高，真像是银河从天上落到了人间。' },
                    { title: '黄鹤楼送孟浩然之广陵', dynasty: '唐', author: '李白', content: '故人西辞黄鹤楼，烟花三月下扬州。孤帆远影碧空尽，唯见长江天际流。', translation: '老朋友在黄鹤楼向我辞别，在繁花似锦的三月前往扬州。孤船的影子渐渐消失在碧蓝的天空尽头，只看见长江水向天边流去。' },
                    { title: '赋得古原草送别', dynasty: '唐', author: '白居易', content: '离离原上草，一岁一枯荣。野火烧不尽，春风吹又生。', translation: '草原上的草长得非常茂盛，每年都会枯萎一次又茂盛一次。野火无法烧尽它们，春风一吹又会重新生长。' },
                    { title: '江雪', dynasty: '唐', author: '柳宗元', content: '千山鸟飞绝，万径人踪灭。孤舟蓑笠翁，独钓寒江雪。', translation: '所有的山上都没有鸟在飞，所有的路上都没有人的踪迹。只有一个穿着蓑衣戴着斗笠的老翁，独自在寒冷的江上钓鱼。' }
                ]
            }
        },
        methods: {
            formatDate(timestamp) {
                if (!timestamp) return '';
                const date = new Date(timestamp * 1000);
                const now = new Date();
                const diff = Math.floor((now - date) / 1000);

                if (diff < 60) return '刚刚';
                if (diff < 3600) return Math.floor(diff / 60) + '分钟前';
                if (diff < 86400) return Math.floor(diff / 3600) + '小时前';
                if (diff < 604800) return Math.floor(diff / 86400) + '天前';

                const year = date.getFullYear();
                const month = String(date.getMonth() + 1).padStart(2, '0');
                const day = String(date.getDate()).padStart(2, '0');
                if (year === now.getFullYear()) {
                    return month + '-' + day;
                }
                return year + '-' + month + '-' + day;
            },
            initTab() {
                const tabs = document.querySelectorAll('.article-tab');
                const lists = document.querySelectorAll('.topic-list');
                const savedTab = localStorage.getItem("article_tab");
                
                tabs.forEach(tab => {
                    tab.addEventListener('click', () => {
                        const target = tab.dataset.target;
                        tabs.forEach(t => t.classList.remove('is-active'));
                        lists.forEach(l => l.classList.remove('is-active'));
                        tab.classList.add('is-active');
                        document.querySelector(target).classList.add('is-active');
                        localStorage.setItem("article_tab", target);
                    });
                });
                
                // 恢复上次选择
                if (savedTab) {
                    const savedTabEl = document.querySelector(`[data-target="${savedTab}"]`);
                    if (savedTabEl) savedTabEl.click();
                } else {
                    tabs[0]?.click();
                }
            },
            refreshPoetry() {
                const randomIndex = Math.floor(Math.random() * this.poetryList.length);
                this.poetry = this.poetryList[randomIndex];
            },
            getLast() {
                const _this = this;
                let user = null;
                try { let d = localStorage.getItem("user"); if(d) user = JSON.parse(d); } catch(e) {}
                axios.get('/article/latest', {
                    params: { token: user ? user.token : "" }
                }).then(function (response) {
                    _this.articles_latest = response.data.data;
                }).catch(function (error) {
                    console.log(error);
                });
            },
            getHotViews() {
                const _this = this;
                let user = null;
                try { let d = localStorage.getItem("user"); if(d) user = JSON.parse(d); } catch(e) {}
                axios.get('/article/hot-views', {
                    params: { token: user ? user.token : "" }
                }).then(function (response) {
                    _this.articles_hot_views = response.data.data;
                }).catch(function (error) {
                    console.log(error);
                });
            },
            getHotReplies() {
                const _this = this;
                let user = null;
                try { let d = localStorage.getItem("user"); if(d) user = JSON.parse(d); } catch(e) {}
                axios.get('/article/hot-replies', {
                    params: { token: user ? user.token : "" }
                }).then(function (response) {
                    _this.articles_hot_replies = response.data.data;
                }).catch(function (error) {
                    console.log(error);
                });
            }
        },
        mounted() {
            this.initTab();
            this.getLast();
            this.getHotViews();
            this.getHotReplies();
            this.refreshPoetry();
        },
    }).mount('#article')
</script>
<?php /**PATH D:\project\yun\web\resources\views/article.blade.php ENDPATH**/ ?>