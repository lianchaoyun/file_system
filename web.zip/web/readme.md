## [laravel项目]
* 启动过程:入口文件 -> 应用程序引导 -> 路由解析 -> 控制器处理 -> 响应发送 -> 应用程序终止
* 创建 composer create-project laravel/laravel o
* 启动 php artisan serve --port=80
* http服务 python -m http.server 9090
* 启动 php -S localhost:80 -t D:\\project\\yun\\web\\public  server.php
* 迁移 php artisan migrate
* 模型 php artisan make:model ModelName

## 全局函数定义
* /app/Helpers.php   添加文件
* /app/Providers/AppServiceProvider.php  boot()方法中添加"require\_once **DIR** . '/../Helpers.php';"

## laravel与vue标签冲突
* @ 前缀
* @verbatim 内容 @endverbatim 指令