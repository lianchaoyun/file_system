<?php

namespace App\Models;

// use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class User extends Authenticatable
{
    use HasFactory, Notifiable;

    // 如果表名不是模型名的复数形式，需要手动指定表名
    protected $table = 'users';

    // 如果你的主键不是id，需要手动指定主键
    protected $primaryKey = 'id';

    // 如果你的主键是自增的UUID或其他非自增类型，需要手动指定主键类型
    // protected $keyType = 'string';

    // 禁用时间戳（created_at和updated_at）
    public $timestamps = false;

    public const CREATED_AT = 'register_time'; //create_time
    public const UPDATED_AT = 'update_time';

    // 如果你想要自定义时间戳格式，可以这样设置
    // protected $dateFormat = 'U';
    /**
     * 定义可批量赋值的字段
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'id',
        'account',
        'password',
        'nickname',
        'email',
        'avatar_url',
        'register_time',
        'activation_key',
        'status',
    ];

    // 定义不可批量赋值的字段，与$fillable不共存
    // protected $guarded = ['user_pass'];


    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = [
  
    ];

    /**
     * Get the attributes that should be cast.
     *
     * @return array<string, string>
     */
    protected function casts(): array
    {
        return [
           // 'user_registered' => 'datetime',
           // 'user_pass' => 'hashed',  // Hash::check($attemptPassword, $hashedPassword)
        ];
    }




}
