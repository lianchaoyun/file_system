<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Thread extends Model
{
    use HasFactory;

    // 指定使用 'discuz_db' 连接
    protected $connection = 'discuz_db';

    // 指定表名（由于在配置中设置了前缀，这里可以只写表名）
    protected $table = 'forum_thread';

    // 指定主键
    protected $primaryKey = 'tid';

    // 禁用时间戳
    public $timestamps = false;
}
