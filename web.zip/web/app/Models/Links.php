<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Links extends Model
{
    use HasFactory;
    protected $table = 'links';
    public const CREATED_AT = 'create_at';
    public const UPDATED_AT = 'update_time';
    protected $hidden = [
          'create_at','update_time','desc','target','image'
    ];


}
