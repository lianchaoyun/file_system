<?php

use App\Admin\Controllers\LinksController;
use App\Admin\Controllers\TermsController;
use App\Admin\Controllers\UsersController;
use Illuminate\Routing\Router;

Admin::routes();

Route::group([
    'prefix'        => config('admin.route.prefix'),
    'namespace'     => config('admin.route.namespace'),
    'middleware'    => config('admin.route.middleware'),
    'as'            => config('admin.route.prefix') . '.',
], function (Router $router) {

    $router->get('/', 'HomeController@index')->name('home');
    $router->resource('jwhu/users', UsersController::class);
    $router->resource('jwhu/terms', TermsController::class);
    $router->resource('jwhu/links', LinksController::class);
    $router->get('api/terms', 'TermsController@apiIndex');

});
