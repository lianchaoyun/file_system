<?php

namespace App\Admin\Controllers;

use App\Models\Example;
use App\Models\Terms;
use Encore\Admin\Controllers\AdminController;
use Encore\Admin\Form;
use Encore\Admin\Grid;
use Encore\Admin\Show;

class TermsController extends AdminController
{
    /**
     * API接口：下拉选择数据
     */
    public function apiIndex()
    {
        $q = request()->get('q', '');
        $terms = Terms::where('status', 0)
            ->where('group', 'moegirl')
            ->when($q, function ($query) use ($q) {
                $query->where('name', 'like', "%{$q}%");
            })
            ->get(['term_id', 'name']);

        $result = $terms->map(function ($term) {
            return ['id' => $term->term_id, 'text' => $term->name . '-' . $term->term_id];
        });

        return response()->json($result);
    }

    /**
     * Title for current resource.
     *
     * @var string
     */
    protected $title = '分类管理';

    /**
     * Make a grid builder.
     *
     * @return Grid
     */
    protected function grid()
    {
        $grid = new Grid(new Terms());
        $grid->column('term_id', __('term_id'))->sortable();
        $grid->column('name', __('name'))->editable()->sortable();;
        $grid->column('group', __('group'))->editable()->sortable();;
        $grid->column('slug', __('slug'))->editable()->sortable();;
        $grid->column('sort', __('sort'))->editable()->sortable();;
        $grid->column('status', __('status'))->editable()->sortable();;
        return $grid;
    }

    /**
     * Make a show builder.
     *
     * @param mixed   $id
     * @return Show
     */
    protected function detail($id)
    {
        $show = new Show(Terms::findOrFail($id));
        $show->field('term_id', __('term_id'));
        return $show;
    }

    /**
     * Make a form builder.
     *
     * @return Form
     */
    protected function form()
    {
        $form = new Form(new Terms);
        $form->display('term_id', __('term_id'));
        $form->text('name', __('name'));
        $form->text('group', __('group'))->default('universe');
        $form->text('slug', __('slug'));
        $form->text('sort', __('sort'))->default('1');
        $form->text('status', __('status'))->default('1');
        $form->confirm('确定更新吗？', 'edit');
        return $form;
    }
}
