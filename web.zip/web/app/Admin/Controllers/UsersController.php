<?php

namespace App\Admin\Controllers;

use App\Models\Example;
use App\Models\User;
use Encore\Admin\Controllers\AdminController;
use Encore\Admin\Form;
use Encore\Admin\Grid;
use Encore\Admin\Show;

class UsersController extends AdminController
{
    /**
     * Title for current resource.
     *
     * @var string
     */
    protected $title = '用户管理';

    /**
     * Make a grid builder.
     *
     * @return Grid
     */
    protected function grid()
    {
        $grid = new Grid(new User());

        $grid->column('id', __('id'))->sortable();
        $grid->column('account', __('account'))->editable();
        $grid->column('password', __('password'))->editable();;
        $grid->column('nickname', __('nickname'))->editable();
        $grid->column('email', __('email'))->editable();
        $grid->column('avatar_url', __('avatar_url'))->editable();
        $grid->column('status', __('status'))->editable();
        $grid->column('register_ip', __('register_ip'));

        return $grid;
    }

    /**
     * Make a show builder.
     *
     * @param mixed   $id
     * @return Show
     */
    protected function detail($id)
    {
        $show = new Show(User::findOrFail($id));
        $show->field('id', __('id'));
        return $show;
    }

    /**
     * Make a form builder.
     *
     * @return Form
     */
    protected function form()
    {
        $form = new Form(new User);

        $form->display('id', __('id'));
        $form->text('account', __('account'));
        $form->text('password', __('password'));
        $form->text('nickname', __('nickname'));
        $form->text('email', __('email'));
        $form->text('avatar_url', __('avatar_url'));
        $form->text('user_status', __('user_status'));
        $form->display('register_time', __('register_time'));
        $form->display('update_time', __('update_time At'));
        $form->confirm('确定更新吗？', 'edit');
        return $form;
    }
}
