<?php

namespace App\Admin\Controllers;

use App\Models\Example;
use App\Models\Links;
use App\Models\Terms;
use Encore\Admin\Controllers\AdminController;
use Encore\Admin\Form;
use Encore\Admin\Grid;
use Encore\Admin\Show;
use function App\writelog;

class LinksController extends AdminController
{

    protected $title = '网址管理';

    protected function grid()
    {
        $grid = new Grid(new Links());

        $grid->model()->orderBy('create_at', 'desc');

        $grid->column('id', __('id'))->sortable();

        $grid->column('fid', __('fid'))->display(function($fid) {
            if(!$fid){
                return "";
            }
             $terms = Terms::find($fid);
            return $terms->name."-".$terms->term_id;
        });;

        $grid->column('name', __('name'))->editable();
        $grid->column('url', __('url'))->editable();
        $grid->column('group', __('group'))->sortable()->editable();
        $grid->column('sort', __('sort'))->sortable()->editable();
        $grid->column('status', __('status'))->editable();


        $grid->filter(function($filter){
            $terms = Terms::where("status","=",0)->where("group","=","moegirl")->get();
            $termsArr = [];
            foreach ($terms as $term){
                $termsArr[$term['term_id']] = $term['name']."-". $term['term_id'];
            }
            $filter->equal('fid', 'fid')->select($termsArr);
        });

        return $grid;
    }

    protected function detail($id)
    {
        $show = new Show(Links::findOrFail($id));
        $show->field('id', __('id'));
        return $show;
    }

    protected function form()
    {
        $form = new Form(new Links);
        $form->display('id', __('id'));
        $terms = Terms::where("status","=",0)->where("group","=","moegirl")->get();
        $termsArr = [];
        foreach ($terms as $term){
            $termsArr[$term['term_id']] = $term['name']."-". $term['term_id'];
        }
        $form->select('fid', 'fid')
            ->options($termsArr);
        $form->text('name', __('name'));
        $form->url('url', __('url'));
        $form->text('group', __('group'));
        $form->number('sort', __('sort'));
        $form->number('status', __('status'));
        $form->confirm('确定更新吗？', 'edit');
        return $form;
    }
}
