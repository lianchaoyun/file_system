<?php

namespace App\Http;

class Kernel
{
    protected $routeMiddleware = [
        'logRequests' => \App\Http\Middleware\LogRequests::class,

    ];

}

