<?php

namespace App\Http\Controllers;

use App\Helpers;
use Illuminate\Http\Request;
use App\Models\Thread; // 引入刚刚创建的模型

class DiscuzController extends Controller
{
    /**
     * 获取最新主题列表
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function getLatestThreads()
    {
        $threads = Thread::orderBy('dateline', 'desc')
            ->limit(10)
            ->get();

        return response()->json([
            "errcode"=>Helpers::$Success,
            "errmsg"=>Helpers::$SuccessMsg,
            'data' => $threads
        ]);
    }

    /**
     * 获取热门主题列表 (按回复数)
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function getHotThreadsByReplies()
    {
        $threads = Thread::orderBy('replies', 'desc')
            ->limit(10)
            ->get();

        return response()->json([
            "errcode"=>Helpers::$Success,
            "errmsg"=>Helpers::$SuccessMsg,
            'data' => $threads
        ]);
    }

    /**
     * 获取热门主题列表 (按浏览数)
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function getHotThreadsByViews()
    {
        $threads = Thread::orderBy('views', 'desc')
            ->limit(10)
            ->get();

        return response()->json([
            "errcode"=>Helpers::$Success,
            "errmsg"=>Helpers::$SuccessMsg,
            'data' => $threads
        ]);
    }
}
