<?php

namespace App\Http\Controllers;
use App\Helpers;
use App\Http\Controllers\Controller;
use App\Models\Resource;
use App\Models\Links;
use App\Models\Posts;
use App\Models\Terms;
use App\Models\User;
use App\Models\Usermeta;
use Illuminate\View\View;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Intervention\Image\Drivers\Gd\Driver;
use Intervention\Image\ImageManager;
use function App\writelog;
use Intervention\Image\Laravel\Facades\Image;
use Illuminate\Support\Facades\Hash;

class UserController extends Controller
{
    public function login(Request $request)
    {
        if ($request->isMethod('POST')) {
            $username = $request->post("username");
            $user = User::where("account", "=", $username)->first();
            if (!$user) {
                return response()->json([
                    "errcode" => Helpers::$Failure,
                    "errmsg" => "用户不存在"
                ]);
            }
            $password = $request->post("password");
            if ($user->password != $password ) {          //    !Hash::check($password,  $user->password)
                return response()->json([
                    "errcode" => Helpers::$Failure,
                    "errmsg" => "密码错误"
                ]);
            }
            $privateKey = bin2hex(openssl_random_pseudo_bytes(32));
            $user["token"] = $privateKey;
            User::where('id', $user["id"])->update(['token' => $privateKey]);
            return response()->json([
                "errcode" => Helpers::$Success,
                "errmsg" => Helpers::$SuccessMsg,
                "data" => $user
            ]);
        } else {
            return view('user/login', []);
        }
    }
    public function register(Request $request)
    {
        if ($request->isMethod('POST')) {
            $username = $request->post("username");

            if (!preg_match('/^[a-zA-Z_][a-zA-Z0-9-_]{5,19}$/', $username)) {
                return response()->json([
                    "errcode" => Helpers::$Failure,
                    "errmsg" => "用户名长度6-20位字符，必须以字母开头，只能包含数字、字母、下划线，不区分大小写",
                ]);
            }

            $user = User::where("account", "=", $username)->first();
            if ($user) {
                return response()->json([
                    "errcode" => Helpers::$Failure,
                    "errmsg" => "用户名已经存在",
                ]);
            }
            $password = $request->post("password");

            if (!preg_match('/^(?![0-9]+$)(?![a-z]+$)(?![A-Z]+$)(?!([^(0-9a-zA-Z)])+$).{6,20}$/', $password)) {
                return response()->json([
                    "errcode" => Helpers::$Failure,
                    "errmsg" => "密码长度6-20位字符，需包括数字与英文字母",
                ]);
            }
            $password2 = $request->post("password2");
            if ($password != $password2) {
                return response()->json([
                    "errcode" => Helpers::$Failure,
                    "errmsg" => "两次密码不一致",
                ]);
            }
            $privateKey = bin2hex(openssl_random_pseudo_bytes(32));
            $user = new User();
            $user->account = $username;
            $user ->token = $privateKey;
            $user->password =  $password ;  // bcrypt('password')     Hash::make($password, ['rounds' => 12,])
            $user->save();
            return response()->json([
                "errcode" => Helpers::$Success,
                "errmsg" => Helpers::$SuccessMsg,
                "data" => $user
            ]);
        } else {
            return view('user/register', []);
        }
    }

    //资源分类配置
    public function terms_resource(Request $request)
    {
        $resource_type = Terms::where("group", "resource_type")->get();


        $resources = Terms::where("group", "resource")->get();
        $resourcesData = $resources->groupBy('slug');

        return response()->json([
            "errcode" => Helpers::$Success,
            "errmsg" => Helpers::$SuccessMsg,
            'resource' => $resourcesData,
            'resource_type' => $resource_type
        ]);
    }


    public function user(Request $request)
    {
        $token  = $request->get("token","visitor");
        $user = User::where("token", $token)->first();
        if ($user) {
            return response()->json([
                "errcode" => Helpers::$Success,
                "errmsg" => Helpers::$SuccessMsg,
                "data" => $user
            ]);

        }
        return response()->json([
            "errcode" => Helpers::$UnAuth,
            "errmsg" => Helpers::$UnAuthMsg,
        ]);
    }

}
