<?php

namespace App\Http\Controllers;
use App\Helpers;
use App\Http\Controllers\Controller;
use App\Models\Resource;
use App\Models\Links;
use App\Models\Posts;
use App\Models\Terms;
use App\Models\User;
use App\Models\Usermeta;
use Illuminate\View\View;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Intervention\Image\Drivers\Gd\Driver;
use Intervention\Image\ImageManager;
use function App\writelog;
use Intervention\Image\Laravel\Facades\Image;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;

class LinksController extends Controller
{
    /**
     * 获取 favicon（带本地缓存）
     */
    public function favicon(Request $request)
    {
        $domain = $request->get('domain', '');
        if (empty($domain)) {
            return response()->json(['error' => 'Missing domain'], 400);
        }

        // 清理域名 - 从 URL 或直接传入的域名中提取主域名
        $domain = trim($domain);

        // 如果包含协议，先提取 host
        if (strpos($domain, '://') !== false) {
            $parts = parse_url($domain);
            $domain = $parts['host'] ?? '';
        }

        // 如果还包含路径/查询等，手动提取域名部分
        if (empty($domain) || strpos($domain, '.') === false) {
            // 尝试正则提取：匹配域名模式
            if (preg_match('/https?:\/\/([a-zA-Z0-9\-\.]+\.[a-zA-Z]{2,})/', $domain, $matches)) {
                $domain = $matches[1];
            } elseif (preg_match('/([a-zA-Z0-9\-\.]+\.[a-zA-Z]{2,})/', $domain, $matches)) {
                $domain = $matches[1];
            }
        }

        // 去除 www. 前缀
        $domain = preg_replace('/^www\./', '', $domain);

        // 如果域名仍然无效，返回默认图标
        if (empty($domain) || strlen($domain) < 3) {
            return response('', 204); // 空响应，让前端处理 fallback
        }

        // 生成缓存文件名（MD5 确保证券一性）
        $hash = md5($domain);
        $cacheDir = 'favicons';
        $cachePath = $cacheDir . '/' . $hash . '.png';
        $fullPath = storage_path('app/public/' . $cachePath);

        // 检查本地缓存
        if (file_exists($fullPath)) {
            return response()->file($fullPath, [
                'Content-Type' => 'image/png',
                'Cache-Control' => 'public, max-age=86400'
            ]);
        }

        // 从 Google API 获取 favicon
        $googleUrl = "https://www.google.com/s2/favicons?domain={$domain}&sz=64";

        try {
            $context = stream_context_create([
                'http' => [
                    'timeout' => 5,
                    'user_agent' => 'Mozilla/5.0'
                ]
            ]);
            $imageData = @file_get_contents($googleUrl, false, $context);

            if ($imageData && strlen($imageData) > 100) { // 有效图片通常 > 100 bytes
                // 确保目录存在
                $dir = dirname($fullPath);
                if (!is_dir($dir)) {
                    mkdir($dir, 0755, true);
                }

                // 保存到本地
                file_put_contents($fullPath, $imageData);

                return response($imageData, 200, [
                    'Content-Type' => 'image/png',
                    'Cache-Control' => 'public, max-age=86400'
                ]);
            }
        } catch (\Exception $e) {
            // 获取失败，返回默认图标或 404
        }

        // 返回空响应，让前端显示 fallback 占位符
        return response('', 204);
    }

    public function get_links($token) {
        // 1. 获取用户并判断权限
        $user = User::where("token", $token)->first();
        $isAuthSe = $user && $user->role === 'se';
        $fidMe = 1;
        $fidaiai = 9;
        // 2. 获取分类并过滤
        $terms = Terms::where("group", "moegirl")
            ->where("status", 0)
            ->orderBy("sort", "desc")
            ->get();

        $termsMap = [];
        foreach ($terms as $term) {
            if ($term->auth === 'se' && !$isAuthSe) {
                continue;
            }
            $item = $term->toArray();
            $item['links'] = []; // 初始化链接容器
            $termsMap[$item['term_id']] = $item;
        }
        // 3. 获取所有链接并归类
        $links = Links::where("status", 0)->orderBy("sort", "desc")->get();
        foreach ($links as $link) {
            $fid = $link->fid;
            if (isset($termsMap[$fid])) {
                $termsMap[$fid]['links'][] = $link->toArray();
            }
        }

        // 4. 特殊处理：[精品] 链接合并
        $linksMe = Links::where("status", 0)
            ->where("group", "[精品]")
            ->orderBy("sort", "desc")
            ->get()
            ->toArray();

        if (isset($termsMap[$fidMe])) {
            $termsMap[$fidMe]['links'] = array_merge($termsMap[$fidMe]['links'], $linksMe);
        }

        // 5. 将测试链接追加到 term_id=1 的分类中
        $testLinks = $this->get_test_links();
        if (!empty($testLinks) && isset($termsMap[$fidaiai])) {
            $termsMap[$fidaiai]['links'] = array_merge($termsMap[$fidaiai]['links'], $testLinks);
        }

        return array_values($termsMap);
    }

    /**
     * 扫描 public/apps/test 目录下的 .html 文件（不含子目录），
     * 动态生成链接数据
     */
    private function get_test_links()
    {
        $dir = public_path('apps/test');
        $links = [];

        if (!is_dir($dir)) {
            return $links;
        }

        $files = scandir($dir);
        foreach ($files as $file) {
            if ($file === '.' || $file === '..') {
                continue;
            }
            $fullPath = $dir . DIRECTORY_SEPARATOR . $file;
            // 仅处理 .html/.htm 文件，跳过子目录
            if (!is_file($fullPath)) {
                continue;
            }
            if (!preg_match('/\.html?$/i', $file)) {
                continue;
            }

            $name = pathinfo($file, PATHINFO_FILENAME);
            $links[] = [
                'link_id'   => null,
                'fid'       => 1,
                'name'      => $name,
                'url'       => '/apps/test/' . $file,
                'sort'      => 0,
                'status'    => 0,
                'group'     => '',
                'auth'      => '',
                'icon'      => '',
            ];
        }

        return $links;
    }


    public function  links(Request $request){
        $token  = $request->get("token","visitor");
        $respData=[
            "data"=>array_values($this->get_links($token)),
            "errcode"=>Helpers::$Success,
            "errmsg"=>Helpers::$SuccessMsg
        ];
        return response()->json($respData);
    }


}
