<?php

namespace App\Http\Controllers;

use App\Helpers;
use App\Http\Controllers\Controller;
use App\Models\Resource;
use App\Models\Links;
use App\Models\Posts;
use App\Models\Terms;
use App\Models\User;
use App\Models\Usermeta;
use Illuminate\View\View;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Intervention\Image\Drivers\Gd\Driver;
use Intervention\Image\ImageManager;
use function App\writelog;
use Intervention\Image\Laravel\Facades\Image;
use Illuminate\Support\Facades\Hash;

class MediaController extends Controller
{
    public function randombg(Request $request)
    {
        $imagepath = public_path('i' . DIRECTORY_SEPARATOR . $request->get("type", "moe") . DIRECTORY_SEPARATOR);
        $imageFiles = scandir($imagepath);
        $imageFiles = array_diff($imageFiles, array('..', '.'));
        $randomImage = $imagepath . $imageFiles[array_rand($imageFiles)];
        if (!file_exists($randomImage)) {
            return "文件不存在";
        }
        return response()->stream(function () use ($randomImage) {
            echo file_get_contents($randomImage);
        }, 200, ['Content-Type' => 'image/jpeg']);
    }

    public function upload(Request $request)
    {
        $image = $request->file('file');
        if (!$image->isValid()) {
            return redirect()->back()->withErrors('上传文件无效');
        }
        // 保存图片
        $path = $image->store('images', 'public');
        $respData = [
            "data" => asset($path),
            "errcode" => Helpers::$Success,
            "errmsg" => Helpers::$SuccessMsg
        ];
        return response()->json($respData);
        //return view('image-view', ['imagePath' => $path]);
    }

    public function media(Request $request)
    {
        $token = $request->get("token", "visitor");
        $user = User::where("token", $token)->first();
        $isAuthSe = $user && $user->role === 'se';


        $size = $request->get("size");
        $size = $size > 0 ? $size : 12;
        $interests = $request->get("interests");

        //se权限
        $terms_query = Terms::where("group", "resource")->whereIn("name", $interests);

        if (!$isAuthSe) {
            $terms_query->where(function ($query) {
                $query->where("auth", "!=", "se")->orWhereNull("auth");
            });
        }
        $terms_real = $terms_query->pluck('name')->toArray();


        $formats = $request->get("formats");
        if (is_array($formats) && !empty($formats)) {
            $resource_types_real = $formats;
        } else {
            $resource_types_real = ["image", "video"];
        }

    
        if (is_array($terms_real) && !empty($terms_real)) {

            $resource = Resource::whereIn("type", $resource_types_real)
                ->whereIn("group_name", $terms_real)
                ->orderBy(DB::raw('RAND()'))
                ->limit($size)
                ->get();
        } else {
            $resource = Resource::whereIn("type", $resource_types_real)
                ->orderBy(DB::raw('RAND()'))
                ->limit($size)
                ->get();
        }

        $respData = [
            "data" => $resource,
            "errcode" => Helpers::$Success,
            "errmsg" => Helpers::$SuccessMsg
        ];
        return response()->json($respData);
    }


    function getVideoCover1($input, $output)
    {
        $command = "ffmpeg -v 0 -y -i $input -vframes 1 -ss 5 -vcodec mjpeg -f rawvideo -s 286x160 -aspect 16:9 $output "; // 视频a.mp4 第一帧导出为a.jpg
        shell_exec($command);
    }

    function getVideoCover2($input, $output)
    {
        $image = imagecreatefromjpeg($input); // 打开视频文件
        imagejpeg(imagegrabframe($image, 5), $output); // 提取第5帧并保存为图像文件
        imagedestroy($image);
    }

    public function test(Request $request)
    {
        $this->getVideoCover2('C:\project\data\moe\Pinterest.mp4', 'C:\project\data\moe\test.jpg');
        $imagePath = 'C:\project\data\moe\1.jpg';
        $manager = new ImageManager(new Driver());
        $image = $manager->read($imagePath);
        $a = $image->pad(300, 200, 'ccc')->encode();
        return response($a, 200, [
            'Content-Type' => $a->mimetype(),
            'Content-Disposition' => 'inline; filename="photo.jpg"',
        ]);
    }

}
