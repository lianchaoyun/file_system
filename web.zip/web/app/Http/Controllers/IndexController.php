<?php

namespace App\Http\Controllers;
use App\Helpers;
use App\Http\Controllers\Controller;
use App\Models\Resource;
use App\Models\Links;
use App\Models\Posts;
use App\Models\Terms;
use App\Models\User;
use App\Models\Usermeta;
use Illuminate\View\View;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Intervention\Image\Drivers\Gd\Driver;
use Intervention\Image\ImageManager;
use function App\writelog;
use Intervention\Image\Laravel\Facades\Image;
use Illuminate\Support\Facades\Hash;

class IndexController extends Controller
{

    public function index(Request $request)
    {
        return view('index', []);
    }
}
