<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use function App\writelog;

class LogRequests
{
    /**
     * Handle an incoming HTTP request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle(Request $request, Closure $next)
    {
        // 记录请求详细信息
        $logData = [
            'method' => $request->getMethod(),
            'uri' => $request->getUri(),
            'headers' => $request->headers->all(),
            'body' => $request->getContent(),
        ];

        // 使用您喜欢的日志记录方法，例如：
       // \Log::info(json_encode($logData));

        // 或者：
        //file_put_contents('request_log.txt', json_encode($logData) . "\n", FILE_APPEND);

        writelog($logData);
        return $next($request);
    }
}
