<?php

namespace App;

const CORE_VERSION = "5.2.0";
function me(): string
{
   return "--- ChaoYun & WuZhen @ ".CORE_VERSION." ---";
}

//写日志
function writelog(...$data): void
{
    $printData = '';
    foreach ($data as $item) {
        if (is_array($item)) {
            $printData = $printData . json_encode($item, JSON_UNESCAPED_UNICODE) . "\r\n";
        } elseif (is_object($item)) {
            $printData = $printData . json_encode($item, JSON_UNESCAPED_UNICODE) . "\r\n";
        } else {
            $printData = $printData . $item . "\r\n";
        }
    }

    $file = storage_path('logs/web_' . date('Y-m-d') . '.log');
    if (!is_file($file)) {
        file_put_contents($file, '', FILE_APPEND); //如果文件不存在，则创建一个新文件。
        // $myfile = fopen($file, "w") or die("Unable to open file!");
        // fclose($myfile);
    }
    $contents = date('Y-m-d h:i:s ') . $printData;
    file_put_contents($file, $contents, FILE_APPEND);
}


class Helpers{
    public static int $SysBusy = -1;
    public static string $SysBusyMsg = "系统繁忙";
    public static int $Success = 0;
    public static string|int $SuccessMsg = "成功";

    public static int $Failure = 1;
    public static string|int $FailureMsg = "失败";

    public static int $UnAuth = 2;
    public static string|int $UnAuthMsg = "未登录";

    public static string $Sql_terms = 'select term_id,name,slug from terms where `group`="moegirl" and `status` = 0';

}

