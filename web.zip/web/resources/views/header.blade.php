<header class="header" id="header">
    <div class="header-inner">
        <div class="header-logo">YunHub</div>
        <nav class="header-nav">
            <a class="header-link is-active"><span>首页</span></a>
            <a class="header-link" href="/x/forum.php"><span>论坛</span></a>
            <a class="header-link" id="setup"><span>设置</span></a>
        </nav>
        <div class="header-search">
            <div class="header-search-inner">
                <select class="header-search-engine">
                    <option value="google">谷歌</option>
                    <option value="bing">必应</option>
                    <option value="baidu">百度</option>
                </select>
                <input type="text" class="header-search-input" placeholder="搜索">
                <ul class="header-suggestions"></ul>
                <button class="header-search-btn" type="button">
                    <svg aria-label="搜索" height="20" viewBox="0 0 24 24" width="20">
                        <path d="M15.5 14h-.79l-.28-.27A6.471 6.471 0 0 0 16 9.5 6.5 6.5 0 1 0 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z" fill="currentColor"></path>
                    </svg>
                </button>
            </div>
        </div>
        <div class="header-user" id="header-user">
            <a v-if="user" id="user" href="javascript:" class="header-user-link">
                <img v-if="user.avatar_url" :src="user.avatar_url" class="header-avatar" fetchpriority="high"/>
                <img v-else src="/i/image/girl.jpg" class="header-avatar" loading="eager"/>
                <span class="header-username">@{{ user.nickname }}</span>
            </a>
            <div v-if="user" class="header-dropdown">
                <div class="header-dropdown-header">
                    <div class="header-dropdown-name">@{{ user.nickname }}</div>
                    <div class="header-dropdown-account">@{{ user.account }}</div>
                </div>
                <ul class="header-dropdown-list">
                    <li class="header-dropdown-item"><a href="javascript:signout();">退出登录</a></li>
                </ul>
            </div>
            <a v-else href="/login" class="header-login-btn">登录</a>
        </div>
        <button class="header-menu-btn" id="header-menu-btn" type="button">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <line x1="3" y1="6" x2="21" y2="6"></line>
                <line x1="3" y1="12" x2="21" y2="12"></line>
                <line x1="3" y1="18" x2="21" y2="18"></line>
            </svg>
        </button>
    </div>
</header>
<div id="header-line"></div>
<div class="header-mobile-nav" id="header-mobile-nav">
    <div class="header-mobile-nav-content">
        <div class="header-mobile-nav-header">
            <span>导航</span>
            <button class="header-mobile-nav-close" id="header-mobile-nav-close">&times;</button>
        </div>
        <nav class="header-mobile-nav-links">
            <a class="header-mobile-link is-active"><span>首页</span></a>
            <a class="header-mobile-link" href="/x/forum.php"><span>论坛</span></a>
            <a class="header-mobile-link" id="mobile-setup"><span>设置</span></a>
        </nav>
    </div>
</div>
<div class="modal" id="terms-resource-modal">
    <div class="modal-content">
        <div class="modal-header">
            <div class="modal-header-title">
                <div class="modal-header-icon">⚙</div>
                <span>偏好设置</span>
            </div>
            <button class="modal-close">&times;</button>
        </div>
        <div class="modal-body">
            <div id="terms-resource-list"></div>
        </div>
        <div class="modal-footer">
            <button class="btn-secondary" id="reset-btn">重置</button>
            <button class="btn-primary" id="save-btn">保存设置</button>
        </div>
    </div>
</div>
<div id="particle-div"></div>
<script>
    Vue.createApp({
        data() {
            let user = null;
            try {
                let userData = localStorage.getItem("user");
                if (userData) user = JSON.parse(userData);
            } catch(e) {}
            return {
                user: user,
                terms_resource_type:[],
                terms_resource:[],
            }
        },
        methods: {
            initSearch() {
                const searchWrapper = document.querySelector('.header-search');
                const engineSelect = searchWrapper.querySelector('.header-search-engine');
                const inputEl = searchWrapper.querySelector('.header-search-input');
                const searchBtn = searchWrapper.querySelector('.header-search-btn');
                const suggestionsEl = searchWrapper.querySelector('.header-suggestions');

                searchBtn.addEventListener('click', () => {
                    event.preventDefault();
                    const engine = engineSelect.value;
                    const val = inputEl.value;
                    const urls = {
                        google: 'https://www.google.com/search?q=',
                        bing: 'https://www.bing.com/search?q=',
                        baidu: 'https://www.baidu.com/s?wd='
                    };
                    if (val) {
                        window.open(urls[engine] + encodeURIComponent(val), '_blank');
                        localStorage.setItem("engine", engine);
                        localStorage.setItem("keyword", val);
                    }
                });

                engineSelect.value = localStorage.getItem("engine") || "google";
                inputEl.value = localStorage.getItem("keyword") || "";

                document.addEventListener('keydown', (e) => {
                    if (e.key === 'Enter' && document.activeElement === inputEl) {
                        searchBtn.click();
                    }
                    suggestionsEl.innerHTML = '';
                });

                let debounceTimer;
                inputEl.addEventListener('input', () => {
                    clearTimeout(debounceTimer);
                    debounceTimer = setTimeout(() => {
                        const query = inputEl.value.trim();
                        if (!query) {
                            suggestionsEl.innerHTML = '';
                            return;
                        }
                        const oldScript = document.getElementById('suggestion-script');
                        if (oldScript) oldScript.remove();
                        const script = document.createElement("script");
                        script.id = "suggestion-script";
                        script.src = "http://suggestion.baidu.com/su?cb=window.baidu.sug&wd=" + encodeURIComponent(query);
                        document.head.appendChild(script);
                    }, 400);
                });

                suggestionsEl.addEventListener('click', (e) => {
                    if (e.target.tagName === 'LI') {
                        inputEl.value = e.target.textContent.replace(/<\/?b>/g, '');
                        suggestionsEl.innerHTML = '';
                        searchBtn.click();
                    }
                });

                document.addEventListener('click', (e) => {
                    if (!searchWrapper.contains(e.target)) {
                        suggestionsEl.innerHTML = '';
                    }
                });

                window.baidu = {
                    sug: function(json) {
                        const query = json.q;
                        suggestionsEl.innerHTML = json.s.map(s => {
                            const highlighted = s.replace(new RegExp(query, 'gi'), m => `<b>${m}</b>`);
                            return `<li>${highlighted}</li>`;
                        }).join('');
                    }
                };
            },
            termsResource() {
                const _this = this;
                axios.get('/terms_resource', {
                    params: {}
                }).then(function(response) {
                    let data = response.data;
                    _this.terms_resource = data.resource;
                    _this.terms_resource_type = data.resource_type;
                    localStorage.setItem("terms_resource_type", JSON.stringify(_this.terms_resource_type));
                    localStorage.setItem("terms_resource", JSON.stringify(_this.terms_resource));
                }).catch(function(error) {
                    console.log(error);
                });
            },
        },
        mounted() {
            this.initSearch();
            // termsResource 延迟加载，确保 links 接口优先
            setTimeout(() => this.termsResource(), 500);
        },
    }).mount('#header')

    // 移动端导航菜单
    document.addEventListener('DOMContentLoaded', () => {
        const menuBtn = document.getElementById('header-menu-btn');
        const mobileNav = document.getElementById('header-mobile-nav');
        const closeBtn = document.getElementById('header-mobile-nav-close');
        const mobileSetup = document.getElementById('mobile-setup');
        const setup = document.getElementById('setup');

        if (menuBtn && mobileNav) {
            menuBtn.addEventListener('click', () => {
                mobileNav.style.display = 'block';
                document.body.style.overflow = 'hidden';
            });

            closeBtn.addEventListener('click', () => {
                mobileNav.style.display = 'none';
                document.body.style.overflow = '';
            });

            mobileNav.addEventListener('click', (e) => {
                if (e.target === mobileNav) {
                    mobileNav.style.display = 'none';
                    document.body.style.overflow = '';
                }
            });

            mobileSetup.addEventListener('click', () => {
                mobileNav.style.display = 'none';
                document.body.style.overflow = '';
                if (setup) setup.click();
            });
        }
    });

    // 设置 header 下方间距
    function updateHeaderMargin() {
        const header = document.querySelector('.header');
        const headerLine = document.getElementById('header-line');
        
        if (header && headerLine) {
            if (window.innerWidth > 640) {
                // 桌面端：动态计算 header 高度，header-line 占位
                const headerHeight = header.offsetHeight;
                const spacing = 24; // 24px 间距
                headerLine.style.marginTop = (headerHeight + spacing) + 'px';
                headerLine.style.height = '0';
            }
            // 移动端：使用 CSS 固定高度 (72px)
        }
    }
    document.addEventListener('DOMContentLoaded', updateHeaderMargin);
    window.addEventListener('resize', updateHeaderMargin);
    setTimeout(updateHeaderMargin, 100);

    // 偏好设置弹窗
    document.addEventListener('DOMContentLoaded', () => {
        const termsResourceTypeStr = localStorage.getItem("terms_resource_type");
        const termsResourceStr = localStorage.getItem("terms_resource");
        if (!termsResourceTypeStr || !termsResourceStr) return;

        let terms_resource_type = null, terms_resource = null;
        try { terms_resource_type = JSON.parse(termsResourceTypeStr); } catch(e) {}
        try { terms_resource = JSON.parse(termsResourceStr); } catch(e) {}
        if (!terms_resource_type || !terms_resource) return;

        const openModalBtn = document.getElementById('setup');
        const modal = document.getElementById('terms-resource-modal');
        const closeBtn = modal.querySelector('.modal-close');
        const saveBtn = document.getElementById('save-btn');
        const termsResourceList = document.getElementById("terms-resource-list");

        function loadInterests(key) {
            try { return JSON.parse(localStorage.getItem(key)) || []; } catch(e) { return []; }
        }

        function saveInterests(arr, key) {
            try { localStorage.setItem(key, JSON.stringify(arr)); } catch(e) {}
        }

        function createInterestOptions(arr, slug, name) {
            const selected = loadInterests(slug);
            const h4 = document.createElement('h4');
            h4.className = 'modal-title';
            h4.textContent = name;
            termsResourceList.appendChild(h4);

            const list = document.createElement('div');
            list.className = 'interest-list';
            list.id = slug;
            arr.forEach(item => {
                const el = document.createElement('div');
                el.className = 'interest-item';
                el.textContent = item;
                el.dataset.value = item;
                if (selected.includes(item)) el.classList.add('is-selected');
                el.addEventListener('click', () => el.classList.toggle('is-selected'));
                list.appendChild(el);
            });
            termsResourceList.appendChild(list);
        }

        function openModal() {
            termsResourceList.innerHTML = '';
            terms_resource_type.forEach(term => {
                if (terms_resource[term.slug]) {
                    createInterestOptions(
                        terms_resource[term.slug].map(i => i.name),
                        term.slug,
                        term.name
                    );
                }
            });
            modal.style.display = 'block';
            document.body.style.overflow = 'hidden';
        }

        function closeModal() {
            modal.style.display = 'none';
            document.body.style.overflow = '';
        }

        function resetSettings() {
            const items = termsResourceList.querySelectorAll('.interest-item');
            items.forEach(el => el.classList.remove('is-selected'));
        }

        openModalBtn.addEventListener('click', openModal);
        closeBtn.addEventListener('click', closeModal);
        modal.addEventListener('click', (e) => { if (e.target === modal) closeModal(); });
        document.getElementById('reset-btn').addEventListener('click', resetSettings);
        saveBtn.addEventListener('click', () => {
            terms_resource_type.forEach(term => {
                const items = document.querySelectorAll(`#${term.slug} .interest-item.is-selected`);
                saveInterests(Array.from(items).map(i => i.dataset.value), term.slug);
            });
            closeModal();
        });
    });

    // 用户下拉菜单
    document.addEventListener('DOMContentLoaded', () => {
        const headerUser = document.getElementById('header-user');
        if (!headerUser) return;

        let hideTimeout;
        let isDropdownHovered = false;

        headerUser.addEventListener('mouseenter', () => {
            clearTimeout(hideTimeout);
            headerUser.classList.add('is-open');
        });

        headerUser.addEventListener('mouseleave', () => {
            hideTimeout = setTimeout(() => {
                if (!isDropdownHovered) {
                    headerUser.classList.remove('is-open');
                }
            }, 150);
        });

        const dropdown = headerUser.querySelector('.header-dropdown');
        if (dropdown) {
            dropdown.addEventListener('mouseenter', () => {
                isDropdownHovered = true;
                clearTimeout(hideTimeout);
            });
            dropdown.addEventListener('mouseleave', () => {
                isDropdownHovered = false;
                headerUser.classList.remove('is-open');
            });
        }
    });

    // 落花效果
    document.addEventListener('DOMContentLoaded', () => {
        let userInterestsHeart = [];
        try { if (localStorage.getItem("particle")) userInterestsHeart = JSON.parse(localStorage.getItem("particle")); } catch(e) {}
        if (!userInterestsHeart || !userInterestsHeart.includes("爱心")) return;

        const heartContainer = document.getElementById('particle-div');
        const symbols = ['❤', '💖', '💗', '💓', '💞', '💕', '⭐', '🌟', '✨'];

        function createHeart() {
            const heart = document.createElement('div');
            heart.className = 'heart';
            heart.textContent = symbols[Math.floor(Math.random() * symbols.length)];
            heart.style.left = Math.random() * 100 + 'vw';
            heart.style.fontSize = (Math.random() * 15 + 15) + 'px';
            heart.style.animationDuration = (Math.random() * 8 + 8) + 's';
            heartContainer.appendChild(heart);
            setTimeout(() => heart.remove(), 16000);
        }

        let intervalId = setInterval(createHeart, 2000);
        document.addEventListener('visibilitychange', () => {
            clearInterval(intervalId);
            if (!document.hidden) intervalId = setInterval(createHeart, 2000);
        });
    });
</script>
