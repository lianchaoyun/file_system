<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0,user-scalable=no, maximum-scale=1.0, minimum-scale=1.0">
    <title>@yield('title')</title>
    <META HTTP-EQUIV="Pragma" CONTENT="no-cache">
    <META HTTP-EQUIV="Cache-Control" CONTENT="no-cache, must-revalidate">
    <META HTTP-EQUIV="Expires" CONTENT="0">

    <!-- CSS -->
    <link rel="stylesheet" href="/css/base.css"/>
    <link rel="stylesheet" href="/css/header.css"/>
    <link rel="stylesheet" href="/css/webnav.css"/>
    <link rel="stylesheet" href="/css/media.css"/>
    <link rel="stylesheet" href="/css/article.css"/>
    <!-- CSS: 页面扩展 -->
    @yield('css')

    <script src="/js/base.js"></script>
    <script src="/js/vue.global.js"></script>
    <script src="/js/axios.min.js"></script>
</head>
<body id="body">
<!-- 页头 -->
@include('header')
<!-- 页头结束 -->

<!-- 内容 -->
@yield('content')
<!-- 内容结束 -->

<footer>
    <p>©2024-2025 yun.com </p>
    <address>
        123 Main Street Anytown, CA 12345
        <a href="mailto:mengyunv@gmail.com">mengyunv@gmail.com</a>
    </address>
</footer>


@yield('js')
</body>
</html>
