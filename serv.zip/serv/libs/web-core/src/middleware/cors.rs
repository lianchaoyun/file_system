//! CORS 跨域中间件

use tower_http::cors::CorsLayer;

/// 创建宽松的 CORS 中间件（允许所有来源/方法/头）
pub fn layer() -> CorsLayer {
    CorsLayer::permissive()
}
