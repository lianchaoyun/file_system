//! JWT 认证中间件
//!
//! TODO: 实现 JWT Token 校验，从 Authorization header 提取并验证

use axum::{
    extract::Request,
    middleware::Next,
    response::Response,
};

/// JWT 认证中间件 — 校验请求中的 Bearer Token
pub async fn jwt_auth(req: Request, next: Next) -> Response {
    // TODO: 从 Authorization header 提取 token 并校验
    // let token = req.headers().get("Authorization")...;
    // if invalid { return StatusCode::UNAUTHORIZED.into_response(); }
    next.run(req).await
}
