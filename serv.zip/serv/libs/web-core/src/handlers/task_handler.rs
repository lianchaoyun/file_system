//! 任务请求处理

use axum::{
    extract::Query,
    Json,
};
use serde::Deserialize;
use serde_json::Value;

use crate::dal::task_dal;
use crate::services::task_service;

// ── 请求参数 ────────────────────────────────────────────

#[derive(Debug, Deserialize)]
pub struct TaskListQuery {
    pub search: Option<String>,
    pub page: Option<u32>,
    pub limit: Option<u32>,
}

#[derive(Debug, Deserialize)]
pub struct IdQuery {
    pub id: u64,
}

#[derive(Debug, Deserialize)]
pub struct LogListQuery {
    pub task_id: Option<u64>,
    pub page: Option<u32>,
    pub limit: Option<u32>,
}

#[derive(Debug, Deserialize)]
pub struct TaskIdQuery {
    pub task_id: u64,
}

// ── 接口 ────────────────────────────────────────────────

/// GET /api/tasks?search=&page=1&limit=20
pub async fn list(Query(p): Query<TaskListQuery>) -> Json<Value> {
    let page = p.page.unwrap_or(1).max(1);
    let limit = p.limit.unwrap_or(20).min(100);
    wrap_json(task_service::get_task_list(p.search.as_deref(), page, limit).await)
}

/// GET /api/tasks/detail?id=1
pub async fn detail(Query(p): Query<IdQuery>) -> Json<Value> {
    wrap_json(task_service::get_task_detail(p.id).await)
}

/// POST /api/tasks/create
pub async fn create(Json(body): Json<task_dal::TaskCreate>) -> Json<Value> {
    wrap_json(task_service::create_task(body).await)
}

/// POST /api/tasks/update?id=1
pub async fn update(Query(p): Query<IdQuery>, Json(body): Json<task_dal::TaskUpdate>) -> Json<Value> {
    wrap_json(task_service::update_task(p.id, body).await)
}

/// GET /api/tasks/delete?id=1
pub async fn delete(Query(p): Query<IdQuery>) -> Json<Value> {
    wrap_json(task_service::delete_task(p.id).await)
}

/// GET /api/tasks/toggle?id=1
pub async fn toggle(Query(p): Query<IdQuery>) -> Json<Value> {
    wrap_json(task_service::toggle_task(p.id).await)
}

/// GET /api/tasks/toggle-hidden?id=1
pub async fn toggle_hidden(Query(p): Query<IdQuery>) -> Json<Value> {
    wrap_json(task_service::toggle_hidden_task(p.id).await)
}

/// GET /api/tasks/execute?id=1
pub async fn execute(Query(p): Query<IdQuery>) -> Json<Value> {
    wrap_json(task_service::execute_task(p.id).await)
}

// ── 任务日志接口 ────────────────────────────────────────

/// GET /api/task-logs?task_id=1&page=1&limit=20
pub async fn log_list(Query(p): Query<LogListQuery>) -> Json<Value> {
    let page = p.page.unwrap_or(1).max(1);
    let limit = p.limit.unwrap_or(20).min(100);
    wrap_json(task_service::get_log_list(p.task_id, page, limit).await)
}

/// GET /api/task-logs/detail?id=1
pub async fn log_detail(Query(p): Query<IdQuery>) -> Json<Value> {
    wrap_json(task_service::get_log_detail(p.id).await)
}

/// GET /api/task-logs/delete?id=1
pub async fn log_delete(Query(p): Query<IdQuery>) -> Json<Value> {
    wrap_json(task_service::delete_log(p.id).await)
}

/// GET /api/task-logs/clear?task_id=1
pub async fn log_clear(Query(p): Query<TaskIdQuery>) -> Json<Value> {
    wrap_json(task_service::clear_task_logs(p.task_id).await)
}

// ── 辅助 ────────────────────────────────────────────────

fn wrap_json(result: Result<Value, String>) -> Json<Value> {
    match result {
        Ok(v) => Json(v),
        Err(e) => Json(serde_json::json!({ "code": 500, "msg": e })),
    }
}
