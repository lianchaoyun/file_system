//! 认证请求处理

use axum::{extract::State, Json};
use serde_json::{json, Value};

use crate::services::auth_service;
use crate::state::AppState;

/// POST /api/v1/auth/login
pub async fn login(
    State(state): State<AppState>,
    Json(body): Json<Value>,
) -> Json<Value> {
    // TODO: 提取 username / password
    match auth_service::login(&state, &body).await {
        Ok(token) => Json(json!({ "code": 0, "msg": "ok", "data": { "token": token } })),
        Err(e) => Json(json!({ "code": 401, "msg": e })),
    }
}

/// POST /api/v1/auth/register
pub async fn register(
    State(state): State<AppState>,
    Json(body): Json<Value>,
) -> Json<Value> {
    // TODO: 校验注册参数
    match auth_service::register(&state, &body).await {
        Ok(user_id) => Json(json!({ "code": 0, "msg": "ok", "data": { "id": user_id } })),
        Err(e) => Json(json!({ "code": 400, "msg": e })),
    }
}
