//! 持仓请求处理

use axum::{extract::Query, Json};
use serde::Deserialize;
use serde_json::Value;

use crate::services::position_service;

// ── 请求参数 ────────────────────────────────────────────

#[derive(Debug, Deserialize)]
pub struct PositionQuery {
    pub market_code: Option<String>,
}

// ── 接口 ────────────────────────────────────────────────

/// GET /api/positions?market_code=CN
pub async fn positions(Query(p): Query<PositionQuery>) -> Json<Value> {
    let market_code = p.market_code.as_deref().unwrap_or("CN");
    match position_service::get_positions(market_code).await {
        Ok(v) => Json(v),
        Err(e) => Json(serde_json::json!({ "code": 500, "msg": e })),
    }
}
