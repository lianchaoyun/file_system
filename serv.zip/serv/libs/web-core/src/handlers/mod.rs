//! 处理器层：HTTP 请求接入，参数校验、权限预检

pub mod auth_handler;
pub mod chart_handler;
pub mod position_handler;
pub mod scan_handler;
pub mod settings_handler;
pub mod stock_handler;
pub mod task_handler;
pub mod user_handler;
pub mod watch_handler;
