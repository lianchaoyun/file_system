//! 股票通用请求处理（东财打开等）

use axum::{extract::Json as AxumJson, Json};
use serde::Deserialize;
use serde_json::Value;

// ── 请求参数 ────────────────────────────────────────────

#[derive(Debug, Deserialize)]
pub struct OpenDcBody {
    pub symbol: String,
}

// ── 接口 ────────────────────────────────────────────────

/// POST /api/open/dc
/// 在东方财富终端中打开指定股票的 K 线
#[cfg(windows)]
pub async fn open_in_dc(AxumJson(body): AxumJson<OpenDcBody>) -> Json<Value> {
    let symbol = body.symbol;
    // 使用 spawn_blocking 避免阻塞工作线程
    tokio::task::spawn_blocking(move || {
        common::stock_opener::open_in_dc(&symbol);
    });
    Json(serde_json::json!({ "code": 0, "msg": "ok" }))
}

/// 非 Windows 平台返回不支持
#[cfg(not(windows))]
pub async fn open_in_dc(AxumJson(_body): AxumJson<OpenDcBody>) -> Json<Value> {
    Json(serde_json::json!({ "code": -1, "msg": "仅支持 Windows 平台" }))
}
