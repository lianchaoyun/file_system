//! 图表请求处理 — TradingView Charting Library 数据接口

use axum::{
    extract::{Query, State},
    Json,
};
use serde_json::Value;

use crate::services::chart_service;
use crate::state::AppState;

/// GET /config — 图表配置
pub async fn config(State(state): State<AppState>) -> Json<Value> {
    Json(chart_service::get_config(&state).await)
}

/// GET /symbols?symbol=xxx — 交易对信息
pub async fn symbols(
    State(state): State<AppState>,
    Query(params): Query<Value>,
) -> Json<Value> {
    let raw = match params.get("symbol").and_then(|v| v.as_str()) {
        Some(s) => s.to_string(),
        None => return Json(serde_json::json!({"code": 400, "msg": "缺少 symbol 参数"})),
    };

    match chart_service::get_symbol_info(&state, &raw).await {
        Ok(data) => Json(data),
        Err(e) => Json(serde_json::json!({"code": 404, "msg": e})),
    }
}

/// GET /history?symbol=xxx&from=xxx&to=xxx&resolution=xxx — K线数据
pub async fn history(
    State(state): State<AppState>,
    Query(params): Query<chart_service::HistoryParams>,
) -> Json<Value> {
    Json(chart_service::get_history(&state, &params))
}

/// GET /search?query=xxx&limit=xx — 搜索交易对
pub async fn search(
    State(state): State<AppState>,
    Query(params): Query<chart_service::SearchParams>,
) -> Json<Value> {
    match chart_service::search(&state, &params).await {
        Ok(data) => Json(data),
        Err(e) => Json(serde_json::json!({"code": 500, "msg": e})),
    }
}

/// GET /symbol_info?group=xxx — 占位接口：返回固定测试标的列表
pub async fn symbol_info(
    State(state): State<AppState>,
    Query(params): Query<chart_service::SymbolInfoParams>,
) -> Json<Value> {
    Json(chart_service::get_symbol_infos(&state, &params).await)
}

/// GET /marks?symbol=xxx&from=xxx&to=xxx — 图表标记
pub async fn marks(
    State(state): State<AppState>,
    Query(params): Query<chart_service::MarksParams>,
) -> Json<Value> {
    Json(chart_service::get_marks(&state, &params))
}
