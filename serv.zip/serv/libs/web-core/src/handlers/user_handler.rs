//! 用户请求处理

use axum::{extract::{Path, State}, Json};
use serde_json::{json, Value};

use crate::services::user_service;
use crate::state::AppState;

/// GET /api/v1/users
pub async fn list(
    State(state): State<AppState>,
) -> Json<Value> {
    // TODO: 参数校验（分页、筛选）
    match user_service::list_users(&state).await {
        Ok(data) => Json(json!({ "code": 0, "msg": "ok", "data": data })),
        Err(e) => Json(json!({ "code": 500, "msg": e })),
    }
}

/// GET /api/v1/users/:id
pub async fn get_by_id(
    State(state): State<AppState>,
    Path(id): Path<i64>,
) -> Json<Value> {
    // TODO: 参数校验
    match user_service::get_user_by_id(&state, id).await {
        Ok(user) => Json(json!({ "code": 0, "msg": "ok", "data": user })),
        Err(e) => Json(json!({ "code": 404, "msg": e })),
    }
}
