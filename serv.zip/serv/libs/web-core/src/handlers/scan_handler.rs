//! 扫描结果请求处理

use axum::{extract::Query, Json};
use serde::Deserialize;
use serde_json::Value;

use crate::services::scan_service;

// ── 请求参数 ────────────────────────────────────────────

#[derive(Debug, Deserialize)]
pub struct ResultsQuery {
    pub strategy_id: Option<i64>,
    pub date: Option<String>,
    pub keyword: Option<String>,
}

// ── 接口 ────────────────────────────────────────────────

/// 获取策略列表
pub async fn strategies() -> Json<Value> {
    wrap_json(scan_service::get_strategies().await)
}

/// 获取扫描结果（支持筛选）
pub async fn results(Query(p): Query<ResultsQuery>) -> Json<Value> {
    wrap_json(
        scan_service::get_results(
            p.strategy_id,
            p.date.as_deref(),
            p.keyword.as_deref(),
        )
        .await,
    )
}

/// 获取可用扫描日期列表
pub async fn dates() -> Json<Value> {
    wrap_json(scan_service::get_dates().await)
}

// ── 辅助 ────────────────────────────────────────────────

fn wrap_json(result: Result<Value, String>) -> Json<Value> {
    match result {
        Ok(v) => Json(v),
        Err(e) => Json(serde_json::json!({ "code": 500, "msg": e })),
    }
}
