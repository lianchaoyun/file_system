//! 设置请求处理 — rawdata 键值读写

use axum::{
    extract::{Query, Json as AxumJson},
    Json,
};
use serde::Deserialize;
use serde_json::{json, Value};

use common;

// ── 请求参数 ────────────────────────────────────────────

#[derive(Debug, Deserialize)]
pub struct SettingsQuery {
    pub key: String,
}

#[derive(Debug, Deserialize)]
pub struct SettingsSetBody {
    pub key: String,
    pub value: String,
}

// ── 接口 ────────────────────────────────────────────────

/// GET /api/settings/get?key=xxx
pub async fn get(Query(p): Query<SettingsQuery>) -> Json<Value> {
    let pool = common::db::get_pool();
    match crate::dal::rawdata_dal::get_setting(pool, &p.key).await {
        Ok(Some(value)) => Json(json!({ "code": 0, "msg": "ok", "data": { "key": p.key, "value": value } })),
        Ok(None) => Json(json!({ "code": 0, "msg": "ok", "data": { "key": p.key, "value": null } })),
        Err(e) => Json(json!({ "code": 500, "msg": e.to_string() })),
    }
}

/// POST /api/settings/set
pub async fn set(AxumJson(body): AxumJson<SettingsSetBody>) -> Json<Value> {
    let pool = common::db::get_pool();
    match crate::dal::rawdata_dal::set_setting(pool, &body.key, &body.value).await {
        Ok(()) => Json(json!({ "code": 0, "msg": "ok" })),
        Err(e) => Json(json!({ "code": 500, "msg": e.to_string() })),
    }
}


