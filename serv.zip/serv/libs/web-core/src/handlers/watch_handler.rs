//! 关注分组请求处理（全部 GET + query 参数，路径全部静态）

use axum::{extract::Query, Json};
use serde::Deserialize;
use serde_json::Value;

use crate::services::watch_service;

// ── 请求参数 ────────────────────────────────────────────

#[derive(Debug, Deserialize)]
pub struct GroupsQuery {
    pub name: Option<String>,
    pub icon: Option<String>,
    pub color: Option<String>,
}

#[derive(Debug, Deserialize)]
pub struct UpdateGroupQuery {
    pub id: i64,
    pub name: Option<String>,
    pub icon: Option<String>,
    pub color: Option<String>,
}

#[derive(Debug, Deserialize)]
pub struct ItemsQuery {
    pub symbol: Option<String>,
    pub group_id: Option<i64>,
    pub keyword: Option<String>,
    pub note: Option<String>,
}

#[derive(Debug, Deserialize)]
pub struct UpdateItemQuery {
    pub id: i64,
    pub group_id: Option<i64>,
    pub note: Option<String>,
}

#[derive(Debug, Deserialize)]
pub struct DeleteQuery {
    pub id: i64,
}

#[derive(Debug, Deserialize)]
pub struct SymbolQuery {
    pub symbol: String,
}

// ── 分组接口 ─────────────────────────────────────────────

/// 有 name → 创建；无 name → 查列表
pub async fn groups(Query(p): Query<GroupsQuery>) -> Json<Value> {
    if let Some(name) = p.name {
        wrap_json(watch_service::create_group(&name, p.icon.as_deref(), p.color.as_deref()).await)
    } else {
        wrap_json(watch_service::get_groups().await)
    }
}

/// 更新分组（传了哪些字段就更新哪些）
pub async fn update_group(Query(p): Query<UpdateGroupQuery>) -> Json<Value> {
    wrap_json(watch_service::update_group(p.id, p.name.as_deref(), p.icon.as_deref(), p.color.as_deref()).await)
}

/// 删除分组
pub async fn delete_group(Query(q): Query<DeleteQuery>) -> Json<Value> {
    wrap_json(watch_service::delete_group(q.id).await)
}

// ── 关注项接口 ───────────────────────────────────────────

/// 有 symbol → 添加；无 symbol → 查列表
pub async fn items(Query(p): Query<ItemsQuery>) -> Json<Value> {
    if let Some(symbol) = &p.symbol {
        wrap_json(watch_service::add_item(symbol, p.group_id.unwrap_or(0), p.note.as_deref()).await)
    } else {
        wrap_json(watch_service::get_items(p.group_id, p.keyword.as_deref()).await)
    }
}

/// 更新关注项（传了哪些字段就更新哪些）
pub async fn update_item(Query(p): Query<UpdateItemQuery>) -> Json<Value> {
    wrap_json(watch_service::update_item(p.id, p.group_id, p.note.as_deref()).await)
}

/// 删除关注项
pub async fn delete_item(Query(q): Query<DeleteQuery>) -> Json<Value> {
    wrap_json(watch_service::delete_item(q.id).await)
}

/// 检查是否关注
pub async fn check_watched(Query(q): Query<SymbolQuery>) -> Json<Value> {
    wrap_json(watch_service::check_watched(&q.symbol).await)
}

/// 获取某股票的所有关注记录 id
pub async fn get_ids_by_symbol(Query(q): Query<SymbolQuery>) -> Json<Value> {
    wrap_json(watch_service::get_ids_by_symbol(&q.symbol).await)
}

// ── 辅助函数 ────────────────────────────────────────────

fn wrap_json(result: Result<Value, String>) -> Json<Value> {
    match result {
        Ok(v) => Json(v),
        Err(e) => Json(serde_json::json!({ "code": 500, "msg": e })),
    }
}
