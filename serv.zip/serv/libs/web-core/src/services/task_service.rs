//! 任务业务逻辑

use common;
use crate::dal::task_dal;
use serde_json::{json, Value};

/// 获取任务列表
pub async fn get_task_list(search: Option<&str>, page: u32, limit: u32) -> Result<Value, String> {
    let pool = common::db::get_pool();
    match task_dal::task_list(pool, search, page, limit).await {
        Ok((items, total)) => Ok(json!({
            "code": 0, "msg": "ok",
            "data": { "items": items, "total": total, "page": page, "limit": limit }
        })),
        Err(e) => Err(e.to_string()),
    }
}

/// 获取任务详情
pub async fn get_task_detail(id: u64) -> Result<Value, String> {
    let pool = common::db::get_pool();
    match task_dal::task_detail(pool, id).await {
        Ok(Some(row)) => Ok(json!({ "code": 0, "msg": "ok", "data": row })),
        Ok(None) => Err("任务不存在".into()),
        Err(e) => Err(e.to_string()),
    }
}

/// 新增任务
pub async fn create_task(body: task_dal::TaskCreate) -> Result<Value, String> {
    let pool = common::db::get_pool();
    // 校验
    if body.name.trim().is_empty() {
        return Err("任务名称不能为空".into());
    }
    if body.command.trim().is_empty() {
        return Err("执行命令不能为空".into());
    }

    match task_dal::task_create(pool, &body).await {
        Ok(id) => Ok(json!({ "code": 0, "msg": "ok", "data": { "id": id } })),
        Err(e) => Err(e.to_string()),
    }
}

/// 更新任务
pub async fn update_task(id: u64, body: task_dal::TaskUpdate) -> Result<Value, String> {
    let pool = common::db::get_pool();
    if body.name.trim().is_empty() {
        return Err("任务名称不能为空".into());
    }
    if body.command.trim().is_empty() {
        return Err("执行命令不能为空".into());
    }

    match task_dal::task_update(pool, id, &body).await {
        Ok(rows) if rows > 0 => Ok(json!({ "code": 0, "msg": "ok" })),
        Ok(_) => Err("任务不存在".into()),
        Err(e) => Err(e.to_string()),
    }
}

/// 删除任务（同时删除关联日志）
pub async fn delete_task(id: u64) -> Result<Value, String> {
    let pool = common::db::get_pool();
    // 先删 task_log
    if let Err(e) = task_dal::task_log_delete_by_task(pool, id).await {
        return Err(format!("删除日志失败: {}", e));
    }
    match task_dal::task_delete(pool, id).await {
        Ok(rows) if rows > 0 => Ok(json!({ "code": 0, "msg": "ok" })),
        Ok(_) => Err("任务不存在".into()),
        Err(e) => Err(e.to_string()),
    }
}

/// 切换启用状态
pub async fn toggle_task(id: u64) -> Result<Value, String> {
    let pool = common::db::get_pool();
    match task_dal::task_toggle(pool, id).await {
        Ok(Some(new_val)) => Ok(json!({ "code": 0, "msg": "ok", "data": { "enabled": new_val } })),
        Ok(None) => Err("任务不存在".into()),
        Err(e) => Err(e.to_string()),
    }
}

/// 切换隐藏状态
pub async fn toggle_hidden_task(id: u64) -> Result<Value, String> {
    let pool = common::db::get_pool();
    match task_dal::task_toggle_hidden(pool, id).await {
        Ok(Some(new_val)) => Ok(json!({ "code": 0, "msg": "ok", "data": { "hidden": new_val } })),
        Ok(None) => Err("任务不存在".into()),
        Err(e) => Err(e.to_string()),
    }
}

/// 获取任务日志列表
pub async fn get_log_list(task_id: Option<u64>, page: u32, limit: u32) -> Result<Value, String> {
    let pool = common::db::get_pool();
    match task_dal::task_log_list(pool, task_id, page, limit).await {
        Ok((items, total)) => Ok(json!({
            "code": 0, "msg": "ok",
            "data": { "items": items, "total": total, "page": page, "limit": limit }
        })),
        Err(e) => Err(e.to_string()),
    }
}

/// 获取日志详情
pub async fn get_log_detail(id: u64) -> Result<Value, String> {
    let pool = common::db::get_pool();
    match task_dal::task_log_detail(pool, id).await {
        Ok(Some(row)) => Ok(json!({ "code": 0, "msg": "ok", "data": row })),
        Ok(None) => Err("日志不存在".into()),
        Err(e) => Err(e.to_string()),
    }
}

/// 清空某任务的全部日志
pub async fn clear_task_logs(task_id: u64) -> Result<Value, String> {
    let pool = common::db::get_pool();
    match task_dal::task_log_delete_by_task(pool, task_id).await {
        Ok(rows) => Ok(json!({ "code": 0, "msg": "ok", "data": { "deleted": rows } })),
        Err(e) => Err(e.to_string()),
    }
}

/// 删除日志
pub async fn delete_log(id: u64) -> Result<Value, String> {
    let pool = common::db::get_pool();
    match task_dal::task_log_delete(pool, id).await {
        Ok(rows) if rows > 0 => Ok(json!({ "code": 0, "msg": "ok" })),
        Ok(_) => Err("日志不存在".into()),
        Err(e) => Err(e.to_string()),
    }
}

/// 手动执行任务（后台异步，立即返回）
pub async fn execute_task(id: u64) -> Result<Value, String> {
    let pool = common::db::get_pool();

    // 1. 获取任务信息
    let task = task_dal::task_detail(pool, id)
        .await
        .map_err(|e| e.to_string())?
        .ok_or("任务不存在".to_string())?;

    // 2. 标记为运行中（允许重复执行，新进程会替代旧状态）
    task_dal::task_set_run_status(pool, id, "running", None)
        .await
        .map_err(|e| e.to_string())?;

    // 4. 创建日志记录
    let log_id = task_dal::task_log_start(pool, id)
        .await
        .map_err(|e| e.to_string())?;

    // 5. 异步执行
    let task_name = task.name.clone();
    let task_id = id;
    let exec_type = task.exec_type.clone();
    let command = task.command.clone();
    let working_dir = task.working_dir.clone();
    let run_mode = task.run_mode.clone();

    tokio::spawn(async move {
        let pool = common::db::get_pool();
        let (status, output, error) = run_task(&exec_type, &command, working_dir.as_deref(), &run_mode).await;

        // 写回日志
        let _ = task_dal::task_log_finish(
            pool, log_id, &status,
            output.as_deref(), error.as_deref(),
        ).await;

        // 更新任务状态
        let _ = task_dal::task_set_run_status(
            pool, task_id, &status, None,
        ).await;

        tracing::info!("[task] {} (#{}) => {}", task_name, task_id, status);
    });

    Ok(json!({ "code": 0, "msg": "ok", "data": { "status": "running" } }))
}

/// 后台执行任务
async fn run_task(
    exec_type: &str,
    command: &str,
    working_dir: Option<&str>,
    run_mode: &str,
) -> (String, Option<String>, Option<String>) {
    match exec_type {
        "http" => run_http(command).await,
        _ => run_shell(command, working_dir, run_mode).await,
    }
}

/// 执行 shell 命令
async fn run_shell(
    command: &str,
    working_dir: Option<&str>,
    run_mode: &str,
) -> (String, Option<String>, Option<String>) {
    let is_external = run_mode == "external";

    let mut cmd = if cfg!(windows) {
        let mut c = tokio::process::Command::new("cmd");
        if is_external {
            // 外部弹窗执行：start "" cmd /K 弹出独立窗口
            c.args(["/C", "start", "", "cmd", "/K", command]);
        } else {
            // 内部执行：直接 /C 不弹窗
            c.args(["/C", command]);
        }
        c
    } else {
        let mut c = tokio::process::Command::new("sh");
        c.args(["-c", command]);
        c
    };

    if let Some(dir) = working_dir {
        cmd.current_dir(dir);
    }

    match cmd.output().await {
        Ok(output) => {
            let stdout = String::from_utf8_lossy(&output.stdout).to_string();
            let stderr = String::from_utf8_lossy(&output.stderr).to_string();
            let status = if output.status.success() { "success" } else { "failed" };
            let out = if stdout.is_empty() { None } else { Some(stdout) };
            let err = if stderr.is_empty() { None } else { Some(stderr) };
            (status.to_string(), out, err)
        }
        Err(e) => {
            ("failed".to_string(), None, Some(e.to_string()))
        }
    }
}

/// 执行 HTTP 请求
async fn run_http(
    url: &str,
) -> (String, Option<String>, Option<String>) {
    let client = reqwest::Client::new();
    match client.get(url).timeout(std::time::Duration::from_secs(30)).send().await {
        Ok(resp) => {
            let status_code = resp.status().as_u16();
            let body = resp.text().await.unwrap_or_default();
            let status = if (200..300).contains(&status_code) { "success" } else { "failed" };
            let out = format!("HTTP {} {}", status_code, if body.len() > 5000 { &body[..5000] } else { &body });
            let err = if status == "failed" { Some(format!("HTTP {}", status_code)) } else { None };
            (status.to_string(), Some(out), err)
        }
        Err(e) => {
            ("failed".to_string(), None, Some(e.to_string()))
        }
    }
}
