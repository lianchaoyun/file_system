//! 关注分组业务逻辑

use common;
use crate::dal::stock_watch_dal;
use serde_json::{json, Value};

// ──────────────────────────────────────────────────────────
//  分组服务
// ──────────────────────────────────────────────────────────

pub async fn get_groups() -> Result<Value, String> {
    let pool = common::db::get_pool();
    match stock_watch_dal::get_groups(pool).await {
        Ok(data) => Ok(json!({ "code": 0, "msg": "ok", "data": data })),
        Err(e) => Err(e.to_string()),
    }
}

pub async fn create_group(name: &str, icon: Option<&str>, color: Option<&str>) -> Result<Value, String> {
    let pool = common::db::get_pool();
    match stock_watch_dal::create_group(pool, name, icon, color).await {
        Ok(id) => Ok(json!({ "code": 0, "msg": "ok", "data": { "id": id } })),
        Err(e) => Err(e.to_string()),
    }
}

pub async fn update_group(id: i64, name: Option<&str>, icon: Option<&str>, color: Option<&str>) -> Result<Value, String> {
    let pool = common::db::get_pool();
    match stock_watch_dal::update_group(pool, id, name, icon, color).await {
        Ok(_) => Ok(json!({ "code": 0, "msg": "ok" })),
        Err(e) => Err(e.to_string()),
    }
}

pub async fn delete_group(id: i64) -> Result<Value, String> {
    let pool = common::db::get_pool();
    match stock_watch_dal::delete_group(pool, id).await {
        Ok(_) => Ok(json!({ "code": 0, "msg": "ok" })),
        Err(e) => Err(e.to_string()),
    }
}

// ──────────────────────────────────────────────────────────
//  关注项服务
// ──────────────────────────────────────────────────────────

pub async fn get_items(group_id: Option<i64>, keyword: Option<&str>) -> Result<Value, String> {
    let pool = common::db::get_pool();
    match stock_watch_dal::get_items(pool, group_id, keyword).await {
        Ok(data) => Ok(json!({ "code": 0, "msg": "ok", "data": data })),
        Err(e) => Err(e.to_string()),
    }
}

pub async fn add_item(symbol: &str, group_id: i64, note: Option<&str>) -> Result<Value, String> {
    let pool = common::db::get_pool();
    match stock_watch_dal::add_item(pool, symbol, group_id, note).await {
        Ok(id) => Ok(json!({ "code": 0, "msg": "ok", "data": { "id": id } })),
        Err(e) => Err(e.to_string()),
    }
}

pub async fn update_item(id: i64, group_id: Option<i64>, note: Option<&str>) -> Result<Value, String> {
    let pool = common::db::get_pool();
    match stock_watch_dal::update_item(pool, id, group_id, note, None).await {
        Ok(_) => Ok(json!({ "code": 0, "msg": "ok" })),
        Err(e) => Err(e.to_string()),
    }
}

pub async fn delete_item(id: i64) -> Result<Value, String> {
    let pool = common::db::get_pool();
    match stock_watch_dal::delete_item(pool, id).await {
        Ok(_) => Ok(json!({ "code": 0, "msg": "ok" })),
        Err(e) => Err(e.to_string()),
    }
}

pub async fn check_watched(symbol: &str) -> Result<Value, String> {
    let pool = common::db::get_pool();
    match stock_watch_dal::is_watched(pool, symbol).await {
        Ok(v) => Ok(json!({ "code": 0, "msg": "ok", "data": { "watched": v } })),
        Err(e) => Err(e.to_string()),
    }
}

/// 获取某股票所有关注项 id（用于取消关注时查找）
pub async fn get_ids_by_symbol(symbol: &str) -> Result<Value, String> {
    let pool = common::db::get_pool();
    match stock_watch_dal::get_watch_item_ids(pool, symbol).await {
        Ok(ids) => Ok(json!({ "code": 0, "msg": "ok", "data": ids })),
        Err(e) => Err(e.to_string()),
    }
}
