//! 图表业务逻辑：TradingView Charting Library 数据接口

use chrono::NaiveDate;
use common::db;
use common::tdx_data::AdjType;
use serde::{Deserialize, Serialize};
use serde_json::{json, Value};

use crate::dal::{stock_basic_dal, stock_markets_dal};
use crate::state::AppState;

// ── 数据模型 ──────────────────────────────────────────────

/// /history 请求参数
#[derive(Debug, Deserialize)]
pub struct HistoryParams {
    pub symbol: String,
    pub from: i64,
    pub to: i64,
    pub resolution: String,
    #[serde(default)]
    pub countback: Option<u32>,
}

/// /search 请求参数
#[derive(Debug, Deserialize)]
pub struct SearchParams {
    pub query: String,
    #[serde(default = "default_search_limit")]
    pub limit: u32,
    #[serde(default)]
    pub r#type: Option<String>,
    #[serde(default)]
    pub exchange: Option<String>,
}

fn default_search_limit() -> u32 {
    30
}

/// /symbol_info 请求参数
#[derive(Debug, Deserialize)]
pub struct SymbolInfoParams {
    #[serde(default)]
    pub group: String,
}

/// /marks 请求参数
#[derive(Debug, Deserialize)]
pub struct MarksParams {
    pub symbol: String,
    #[serde(default)]
    pub from: i64,
    #[serde(default)]
    pub to: i64,
}

/// TradingView 标记项
#[derive(Debug, Serialize)]
pub struct Mark {
    pub id: u64,
    pub time: i64,
    pub color: &'static str,
    #[serde(rename = "text")]
    pub text: String,
    pub label: &'static str,
    #[serde(rename = "labelFontColor")]
    pub label_font_color: &'static str,
    #[serde(rename = "minSize")]
    pub min_size: u32,
}

/// 清洗 symbol：统一转为纯数字代码
/// 支持格式：SHSE:600519 / 600519.SH / 000001.SZ / 920008.BJ / 纯数字
pub fn clean_symbol(raw: &str) -> &str {
    let s = raw;
    // 处理冒号分隔（TradingView 格式：SHSE:600519 → 600519）
    let s = if let Some(pos) = s.rfind(':') { &s[pos + 1..] } else { s };
    // 处理点号后缀（TDX 格式：000001.SZ → 000001）
    if let Some(pos) = s.rfind('.') {
        let suffix = &s[pos + 1..];
        if suffix.eq_ignore_ascii_case("SH") || suffix.eq_ignore_ascii_case("SZ") || suffix.eq_ignore_ascii_case("BJ") {
            return &s[..pos];
        }
    }
    s
}

// ── 服务函数 ──────────────────────────────────────────────

/// GET /config — 返回图表配置（直接返回 stock_markets 表数据）
pub async fn get_config(_state: &AppState) -> Value {
    let pool = db::get_pool();
    let exchanges: Vec<Value> = match stock_markets_dal::find_all_enabled(pool).await {
        Ok(rows) => rows
            .into_iter()
            .map(|row| {
                json!({
                    "value": row.code,
                    "name": row.name,
                    "desc": row.name
                })
            })
            .collect(),
        Err(_) => Vec::new(),
    };

    json!({
        "supported_resolutions": ["1", "15","60", "1D"],
        "supports_group_request": false,  //支持一次拉大量历史
        "supports_marks": true,  //启用标记功能，前端会调 /marks
        "supports_search": true,  //启用搜索，前端会调 /search
        "supports_timescale_marks": false,  //时间轴底部显示标记，需实现 /timescale_marks 接口
        "supports_time": true,  // 前端定期轮询 /time 获取服务器时间
        "exchanges": exchanges
    })
}


/// 根据纯数字代码推断交易所代码和市场
fn guess_market(code: &str) -> Option<(&'static str, &'static str, &'static str)> {
    // (exchange_code, market_dir, currency)
    if code.starts_with("60") || code.starts_with("68") {
        Some(("SH", "sh", "CNY"))
    } else if code.starts_with("00") || code.starts_with("30") || code.starts_with("002") || code.starts_with("003") {
        Some(("SZ", "sz", "CNY"))
    } else if code.starts_with("8") || code.starts_with("4") || code.starts_with("920") {
        Some(("BJ", "bj", "CNY"))
    } else {
        None
    }
}

/// GET /symbols?symbol=xxx — 返回交易对信息
pub async fn get_symbol_info(_state: &AppState, raw_symbol: &str) -> Result<Value, String> {
    let symbol = clean_symbol(raw_symbol);
    let pool = db::get_pool();

    let stock = stock_basic_dal::find_by_symbol(pool, symbol)
        .await
        .map_err(|e| format!("数据库查询失败: {e}"))?;

    // 优先用数据库记录，否则根据代码前缀 fallback
    let (name, ticker, exchange, pricescale) = if let Some(s) = stock {
        let ps: u32 = match s.price_precision {
            Some(0) => 1,
            Some(1) => 10,
            Some(3) => 1000,
            _ => 100,
        };
        (s.name, s.symbol, s.market_code, ps)
    } else if let Some((ex, _dir, _curr)) = guess_market(symbol) {
        (symbol.to_string(), symbol.to_string(), ex.to_string(), 100u32)
    } else {
        return Err(format!("无法识别标的: {symbol}"));
    };

    Ok(json!({
        "name": name,
        "ticker": ticker,
        "description": name,
        "exchange-traded": exchange,
        "exchange-listed": exchange,
        "timezone": "Asia/Shanghai",
        "minmov": 1,
        "minmove2": 0,
        "pricescale": pricescale,
        "session": "0930-1130,1300-1500",
        "has_intraday": false,
        "has_daily": true,
        "has_weekly_and_monthly": true,
        "type": "stock",
        "supported_resolutions": ["1D"],
        "currency": "CNY"
    }))
}

/// GET /symbol_info?group=xxx — 从 stock_basic 表读取标的列表，支持按 market_code 过滤
pub async fn get_symbol_infos(_state: &AppState, params: &SymbolInfoParams) -> Value {
    let pool = db::get_pool();
    let market_filter = if params.group.is_empty() { None } else { Some(params.group.as_str()) };

    let rows = match stock_basic_dal::find_all_enabled(pool, market_filter).await {
        Ok(rows) => rows,
        Err(e) => {
            return json!({ "symbols": [], "msg": format!("查询失败: {e}") });
        }
    };

    let symbols: Vec<Value> = rows
        .into_iter()
        .map(|r| {
            let exchange = r.market_code.clone();
            let currency = match r.market_code.as_str() {
                "US" => "USD",
                "HK" => "HKD",
                _ => "CNY",
            };
            let typ = match r.market_code.as_str() {
                "CRYPTO" => "crypto",
                "FUTURE" => "futures",
                _ => "stock",
            };
            json!({
                "symbol": r.symbol,
                "full_name": r.name,
                "description": format!("{}:{}", r.market_code, r.symbol),
                "exchange": exchange,
                "currency": currency,
                "type": typ,
                "market_code": r.market_code,
            })
        })
        .collect();

    json!({ "symbols": symbols })
}

/// GET /history — 核心接口：返回 K 线数据 OHLCV
pub fn get_history(state: &AppState, params: &HistoryParams) -> Value {
    let symbol = clean_symbol(&params.symbol);

    // 只支持日线
    match params.resolution.as_str() {
        "1D" | "D" | "1" => {}
        _ => {
            return json!({ "s": "error", "errmsg": format!("不支持的周期: {}", params.resolution) });
        }
    }

    let tdx = state.tdx;

    // 读取日线数据（不复权）
    let data = match tdx.get_kline(symbol, AdjType::Forward, None) {
        Ok(d) => d,
        Err(e) => {
            return json!({ "s": "error", "errmsg": format!("读取K线数据失败: {e}") });
        }
    };

    if data.is_empty() {
        return json!({ "s": "no_data", "nextTime": params.to });
    }

    let from_timestamp = params.from;
    let to_timestamp = params.to;

    let mut t = Vec::new();
    let mut o = Vec::new();
    let mut h = Vec::new();
    let mut l = Vec::new();
    let mut c = Vec::new();
    let mut v = Vec::new();

    for item in &data {
        let ts = date_to_timestamp(item.date);
        if ts < from_timestamp || ts > to_timestamp {
            continue;
        }
        t.push(ts);
        o.push(item.open);
        h.push(item.high);
        l.push(item.low);
        c.push(item.close);
        v.push(item.vol);
    }

    // 如果请求了 countback，取最后 N 条
    if let Some(n) = params.countback {
        let len = t.len();
        if n > 0 && (n as usize) < len {
            let start = len - n as usize;
            t = t[start..].to_vec();
            o = o[start..].to_vec();
            h = h[start..].to_vec();
            l = l[start..].to_vec();
            c = c[start..].to_vec();
            v = v[start..].to_vec();
        }
    }

    let has_data = !t.is_empty();
    let next_time = if has_data {
        t.last().copied().unwrap_or(to_timestamp)
    } else {
        to_timestamp
    };

    if has_data {
        json!({
            "s": "ok",
            "t": t,
            "o": o,
            "h": h,
            "l": l,
            "c": c,
            "v": v,
            "nextTime": next_time
        })
    } else {
        json!({
            "s": "no_data",
            "nextTime": next_time
        })
    }
}

/// GET /search?query=xxx&limit=xx — 搜索交易对
pub async fn search(_state: &AppState, params: &SearchParams) -> Result<Value, String> {
    let pool = db::get_pool();
    let rows = stock_basic_dal::search(pool, &params.query, params.limit)
        .await
        .map_err(|e| format!("搜索失败: {e}"))?;

    let results: Vec<Value> = rows
        .into_iter()
        .map(|row| {
            let exchange = row.market_code;
            json!({
                "symbol": row.symbol,
                "full_name": if exchange.is_empty() { row.symbol.clone() } else { format!("{}:{}", exchange, row.symbol) },
                "description": row.name,
                "exchange": exchange,
                "type": "stock"
            })
        })
        .collect();

    Ok(json!(results))
}

/// GET /marks — 返回标记（随机测试数据）
pub fn get_marks(_state: &AppState, params: &MarksParams) -> Value {
    let from = params.from;
    let to = params.to;
    let range = to - from;
    if range <= 0 {
        return json!({ "id": [], "time": [], "color": [], "text": [], "label": [], "labelFontColor": [], "minSize": [] });
    }

    let marks = generate_demo_marks(from, to);

    let id: Vec<u64> = marks.iter().map(|m| m.id).collect();
    let time: Vec<i64> = marks.iter().map(|m| m.time).collect();
    let color: Vec<&str> = marks.iter().map(|m| m.color).collect();
    let text: Vec<String> = marks.iter().map(|m| m.text.clone()).collect();
    let label: Vec<&str> = marks.iter().map(|m| m.label).collect();
    let label_font_color: Vec<&str> = marks.iter().map(|m| m.label_font_color).collect();
    let min_size: Vec<u32> = marks.iter().map(|m| m.min_size).collect();

    json!({
        "id": id,
        "time": time,
        "color": color,
        "text": text,
        "label": label,
        "labelFontColor": label_font_color,
        "minSize": min_size
    })
}

fn generate_demo_marks(from: i64, to: i64) -> Vec<Mark> {
    let tips: [(&str, &str, &str); 10] = [
        ("🚀", "强势突破", "green"),
        ("📉", "放量下跌", "red"),
        ("💎", "金叉信号", "blue"),
        ("🔔", "连续阳线", "orange"),
        ("⚡", "MACD背离", "purple"),
        ("🔥", "涨停", "red"),
        ("⭐", "买入信号", "green"),
        ("⚠️", "注意回调", "orange"),
        ("✅", "支撑确认", "blue"),
        ("💡", "策略触发", "purple"),
    ];

    let range = (to - from) as u64;
    let count = 4;

    let seed = (from as u64).wrapping_add(to as u64);
    let mut marks = Vec::with_capacity(count);

    for i in 0..count {
        let idx = ((seed.wrapping_mul((i + 7) as u64).wrapping_add(13)) % range) as i64;
        let ts = from + idx;
        let tip = &tips[(seed.wrapping_add(i as u64) % 10) as usize];
        marks.push(Mark {
            id: seed.wrapping_add(i as u64),
            time: ts,
            color: match tip.2 {
                "red" => "#ef4444",
                "green" => "#22c55e",
                "blue" => "#3b82f6",
                "orange" => "#f97316",
                _ => "#a855f7",
            },
            text: format!("{} {}", tip.0, tip.1),
            label: tip.0,
            label_font_color: "white",
            min_size: 20,
        });
    }

    marks.sort_by_key(|m| m.time);
    marks
}

// ── 工具函数 ──────────────────────────────────────────────

/// 将 TDX 日期格式 (20260530) 转为 Unix 时间戳 (次日0点，确保日线对齐)
fn date_to_timestamp(date: u32) -> i64 {
    let s = date.to_string();
    if s.len() != 8 {
        return 0;
    }
    let year: i32 = s[0..4].parse().unwrap_or(1970);
    let month: u32 = s[4..6].parse().unwrap_or(1);
    let day: u32 = s[6..8].parse().unwrap_or(1);

    NaiveDate::from_ymd_opt(year, month, day)
        .and_then(|d| d.and_hms_opt(0, 0, 0))
        .map(|dt| dt.and_utc().timestamp())
        .unwrap_or(0)
}
