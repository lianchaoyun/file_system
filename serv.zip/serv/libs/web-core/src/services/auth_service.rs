//! 认证业务逻辑：JWT 签发/校验

use serde_json::Value;

use crate::state::AppState;

/// 用户登录，返回 JWT Token
pub async fn login(_state: &AppState, _body: &Value) -> Result<String, String> {
    // TODO: 校验用户名密码 → 签发 JWT
    Err("用户名或密码错误".into())
}

/// 用户注册，返回新用户 ID
pub async fn register(_state: &AppState, _body: &Value) -> Result<i64, String> {
    // TODO: 校验参数 → 写入 DB → 返回 ID
    Err("注册功能开发中".into())
}
