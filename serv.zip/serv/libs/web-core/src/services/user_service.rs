//! 用户业务逻辑：注册/登录/信息查询

use serde_json::Value;

use crate::state::AppState;

/// 获取用户列表
pub async fn list_users(_state: &AppState) -> Result<Vec<Value>, String> {
    // TODO: 调用 dal 层获取数据，组装业务模型
    Ok(vec![])
}

/// 根据 ID 获取用户
pub async fn get_user_by_id(_state: &AppState, id: i64) -> Result<Value, String> {
    // TODO: 调用 dal::user_dal::find_by_id
    Err(format!("用户 {id} 不存在"))
}
