//! 持仓业务逻辑

use common;
use crate::dal::stock_position_dal;
use serde_json::{json, Value};

/// Decimal → 保留 2 位小数字符串
fn d2s(v: &rust_decimal::Decimal) -> String {
    format!("{:.2}", v)
}

pub async fn get_positions(market_code: &str) -> Result<Value, String> {
    let pool = common::db::get_pool();

    let positions = stock_position_dal::get_positions_by_market(pool, market_code)
        .await
        .map_err(|e| e.to_string())?;

    let summary = stock_position_dal::get_position_summary(pool, market_code)
        .await
        .map_err(|e| e.to_string())?;

    // 将 Decimal 转成字符串，避免前端精度丢失
    let positions_json: Vec<Value> = positions
        .into_iter()
        .map(|p| {
            let cost = p.avg_price * p.quantity;
            let market_val = p.market_value.unwrap_or_else(|| rust_decimal::Decimal::ZERO);
            let profit_loss = market_val - cost;
            let profit_loss_pct = if cost.is_zero() {
                rust_decimal::Decimal::ZERO
            } else {
                (profit_loss.clone() / cost.clone()) * rust_decimal::Decimal::new(100, 2)
            };

            json!({
                "id": p.id,
                "market_code": p.market_code,
                "symbol": p.symbol,
                "name": p.name,
                "direction": p.direction,
                "quantity": d2s(&p.quantity),
                "avg_price": d2s(&p.avg_price),
                "current_price": p.current_price.map(|v| d2s(&v)),
                "market_value": p.market_value.map(|v| d2s(&v)),
                "profit_loss": d2s(&profit_loss),
                "profit_loss_pct": d2s(&profit_loss_pct),
                "first_buy_time": p.first_buy_time.map(|t| t.format("%Y-%m-%d %H:%M:%S").to_string()),
                "update_time": p.update_time.map(|t| t.format("%Y-%m-%d %H:%M:%S").to_string()),
            })
        })
        .collect();

    Ok(json!({
        "code": 0,
        "msg": "ok",
        "data": {
            "positions": positions_json,
            "summary": {
                "total_market_value": d2s(&summary.total_market_value),
                "total_profit_loss": d2s(&summary.total_profit_loss),
                "total_profit_loss_pct": d2s(&summary.total_profit_loss_pct),
            }
        }
    }))
}
