//! 扫描结果业务逻辑

use common;
use crate::dal::scan_dal;
use serde_json::{json, Value};

// ──────────────────────────────────────────────────────────
//  策略
// ──────────────────────────────────────────────────────────

pub async fn get_strategies() -> Result<Value, String> {
    let pool = common::db::get_pool();
    match scan_dal::get_strategies(pool).await {
        Ok(data) => Ok(json!({ "code": 0, "msg": "ok", "data": data })),
        Err(e) => Err(e.to_string()),
    }
}

// ──────────────────────────────────────────────────────────
//  扫描结果
// ──────────────────────────────────────────────────────────

pub async fn get_results(
    strategy_id: Option<i64>,
    date: Option<&str>,
    keyword: Option<&str>,
) -> Result<Value, String> {
    let pool = common::db::get_pool();
    match scan_dal::get_results(pool, strategy_id, date, keyword).await {
        Ok(data) => Ok(json!({ "code": 0, "msg": "ok", "data": data })),
        Err(e) => Err(e.to_string()),
    }
}

/// 获取可选日期列表
pub async fn get_dates() -> Result<Value, String> {
    let pool = common::db::get_pool();
    match scan_dal::get_scan_dates(pool).await {
        Ok(data) => {
            let dates: Vec<String> = data.iter().map(|d| d.format("%Y-%m-%d").to_string()).collect();
            Ok(json!({ "code": 0, "msg": "ok", "data": dates }))
        }
        Err(e) => Err(e.to_string()),
    }
}
