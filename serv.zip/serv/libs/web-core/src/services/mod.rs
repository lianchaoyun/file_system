//! 服务层：核心业务逻辑，不依赖 HTTP 上下文，可复用

pub mod auth_service;
pub mod chart_service;
pub mod position_service;
pub mod scan_service;
pub mod task_service;
pub mod user_service;
pub mod watch_service;
