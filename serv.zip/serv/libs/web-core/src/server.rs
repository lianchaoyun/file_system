//! 服务启动 / 优雅退出

use axum::Router;
use common::config::AppConfig;
use common::log::LogGuard;
use common::tdx_data::TdxDataProvider;
use common::{log, redis_pool};
use std::net::SocketAddr;
use std::path::PathBuf;
use tower_http::services::ServeDir;

use crate::middleware::cors;
use crate::routes;
use crate::routes::health_check;
use crate::state::AppState;

// ── 阶段 1：初始化配置 + 日志 ──────────────────────────

/// 同步初始化：加载配置 → 启动日志
/// 返回 LogGuard，保持存活直到进程结束
///
/// 启动入口统一走 `run()`，由 `run()` 负责调用本函数。
pub(crate) fn init() -> LogGuard {
    AppConfig::init_with_summary().expect("配置加载失败");
    log::init(Some("yun"))
}

// ── 阶段 2：启动 HTTP 服务 ─────────────────────────────

/// 解析静态目录路径（支持相对/绝对路径），返回规范化的绝对路径
fn resolve_static_dir(raw: &str) -> PathBuf {
    let p = PathBuf::from(raw);
    let abs = if p.is_absolute() {
        p
    } else {
        AppConfig::project_root().join(p)
    };
    // 规范化：解析 .. 和 .，得到干净的绝对路径
    let canonical = abs.canonicalize().unwrap_or(abs);
    // Windows 下 canonicalize 会加上 \\?\ 前缀，去掉它
    #[cfg(windows)]
    {
        let s = canonical.to_string_lossy();
        if let Some(stripped) = s.strip_prefix(r"\\?\") {
            return PathBuf::from(stripped);
        }
    }
    canonical
}

/// 启动 HTTP 监听（调用前需先完成 DB / Redis 初始化）
/// 阻塞直到连接关闭或外部取消
pub async fn start() -> Result<(), Box<dyn std::error::Error>> {
    let config = AppConfig::get();
    let addr: SocketAddr =
        format!("{}:{}", config.server.host, config.server.port).parse()?;
    let state = AppState {
        config: config.clone(),
        tdx: TdxDataProvider::new(),
    };

    let static_dir = resolve_static_dir(&config.server.static_dir);

    // 路由：API 优先 → 业务路由 → 静态文件兜底 → CORS 中间件
    let app = Router::new()
        .merge(health_check())
        .merge(routes::all())
        .fallback_service(ServeDir::new(&static_dir))
        .with_state(state)
        .layer(cors::layer());

    let listener = tokio::net::TcpListener::bind(addr).await?;
    tracing::info!("🚀 web启动: http://{} | 静态: {:?}", addr, static_dir);

    axum::serve(listener, app)
        .with_graceful_shutdown(shutdown_signal())
        .await?;

    tracing::info!("✅ 服务已关闭");
    Ok(())
}

// ── 一站式：init + start ───────────────────────────────

/// 一键启动：配置→日志→DB→Redis→HTTP 监听
pub async fn serve() -> Result<(), Box<dyn std::error::Error>> {
    let _guard = init();
    common::db::init().await?;
    redis_pool::init().await;
    let result = start().await;
    common::db::close().await;
    result
}

// ── WebCoreGuard：自管理生命周期 ────────────────────────

/// web-core 生命周期句柄。
///
/// 构造时完成：配置+日志初始化、Web 服务后台运行。
/// Drop 时自动：终止 Web 服务。
///
/// main.rs 只需持有此句柄即可，无需手动管理启停。
pub struct WebCoreGuard {
    server: tokio::task::JoinHandle<()>,
}

impl Drop for WebCoreGuard {
    fn drop(&mut self) {
        self.server.abort();
    }
}

/// 启动 web-core 并返回自管理句柄。
///
/// 内部顺序：`init()`（配置+日志）→ 后台启动 HTTP 服务。
/// 调用前需已完成数据库初始化。
pub async fn run(pool: &sqlx::Pool<sqlx::MySql>) -> WebCoreGuard {
    // 配置 + 日志初始化（LogGuard 泄漏到进程结束）
    let guard = init();
    std::mem::forget(guard);

    // 后台启动 Web 服务
    let server = tokio::spawn(async {
        if let Err(e) = start().await {
            tracing::error!("Web 服务异常: {}", e);
        }
    });

    WebCoreGuard { server }
}

// ── 优雅退出 ────────────────────────────────────────────

async fn shutdown_signal() {
    let ctrl_c = async {
        tokio::signal::ctrl_c()
            .await
            .expect("failed to install Ctrl+C handler");
    };

    #[cfg(unix)]
    let terminate = async {
        tokio::signal::unix::signal(tokio::signal::unix::SignalKind::terminate())
            .expect("failed to install signal handler")
            .recv()
            .await;
    };

    #[cfg(not(unix))]
    let terminate = std::future::pending::<()>();

    tokio::select! {
        _ = ctrl_c => {},
        _ = terminate => {},
    }

    tracing::info!("收到退出信号，正在优雅关闭...");
}
