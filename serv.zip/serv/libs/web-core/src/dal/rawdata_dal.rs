//! rawdata 数据访问层 — 键值存储
//!
//! 注意：raw_key 应保证唯一，需要对 raw_key 建唯一索引：
//!   CREATE UNIQUE INDEX uk_raw_key ON rawdata(raw_key);

use sqlx::MySqlPool;

/// 获取设置值（按 raw_key 查询，与自增 id 无关）
pub async fn get_setting(pool: &MySqlPool, key: &str) -> Result<Option<String>, sqlx::Error> {
    let row: Option<(String,)> = sqlx::query_as(
        "SELECT raw_value FROM rawdata WHERE raw_key = ? LIMIT 1"
    )
    .bind(key)
    .fetch_optional(pool)
    .await?;
    Ok(row.map(|r| r.0))
}

/// 设置键值（UPSERT，需要 raw_key 上有唯一索引）
///
/// 若未建唯一索引，回退为 DELETE + INSERT 方式。
pub async fn set_setting(pool: &MySqlPool, key: &str, value: &str) -> Result<(), sqlx::Error> {
    // 优先尝试 INSERT ON DUPLICATE KEY UPDATE（需唯一索引）
    let result = sqlx::query(
        "INSERT INTO rawdata (raw_key, raw_value) VALUES (?, ?)
         ON DUPLICATE KEY UPDATE raw_value = VALUES(raw_value)"
    )
    .bind(key)
    .bind(value)
    .execute(pool)
    .await?;

    // 若受影响行数为 0，说明 ON DUPLICATE KEY 未生效（无唯一索引），
    // 回退为 DELETE + INSERT
    if result.rows_affected() == 0 {
        sqlx::query("DELETE FROM rawdata WHERE raw_key = ?")
            .bind(key)
            .execute(pool)
            .await?;
        sqlx::query("INSERT INTO rawdata (raw_key, raw_value) VALUES (?, ?)")
            .bind(key)
            .bind(value)
            .execute(pool)
            .await?;
    }
    Ok(())
}
