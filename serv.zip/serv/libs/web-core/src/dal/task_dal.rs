//! 任务数据访问层

use serde::{Deserialize, Serialize};
use sqlx::MySqlPool;

// ──────────────────────────────────────────────────────────
//  数据模型 - task 表
// ──────────────────────────────────────────────────────────

#[derive(Debug, Clone, sqlx::FromRow, Serialize, Deserialize)]
pub struct TaskRow {
    pub id: u64,
    pub name: String,
    pub desc: Option<String>,
    pub exec_type: String,
    pub run_mode: String,
    pub command: String,
    pub working_dir: Option<String>,
    pub cron_expr: String,
    pub enabled: i8,
    pub hidden: i8,
    pub run_status: String,
    pub last_run: Option<chrono::NaiveDateTime>,
    pub last_result: Option<String>,
    pub updated_time: chrono::NaiveDateTime,
    pub created_at: chrono::NaiveDateTime,
}

// ──────────────────────────────────────────────────────────
//  数据模型 - task_log 表
// ──────────────────────────────────────────────────────────

#[derive(Debug, Clone, sqlx::FromRow, Serialize, Deserialize)]
pub struct TaskLogRow {
    pub id: u64,
    pub task_id: u64,
    pub status: String,
    pub output: Option<String>,
    pub error: Option<String>,
    pub start_time: chrono::NaiveDateTime,
    pub end_time: Option<chrono::NaiveDateTime>,
    pub duration_ms: Option<i32>,
}

// ──────────────────────────────────────────────────────────
//  数据模型 - 任务详情（含最近日志摘要）
// ──────────────────────────────────────────────────────────

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TaskDetail {
    #[serde(flatten)]
    pub task: TaskRow,
    /// 最近一次执行日志（用于列表页快速展示）
    pub latest_log: Option<TaskLogRow>,
}

// ──────────────────────────────────────────────────────────
//  task 增删改查
// ──────────────────────────────────────────────────────────

/// 任务列表（支持搜索、分页）
pub async fn task_list(
    pool: &MySqlPool,
    search: Option<&str>,
    page: u32,
    limit: u32,
) -> Result<(Vec<TaskRow>, u64), sqlx::Error> {
    let offset = (page.saturating_sub(1) * limit) as u64;

    // 拼 SQL：搜索关键词匹配 name / desc
    let (has_search, like) = match search {
        Some(s) if !s.is_empty() => (true, format!("%{}%", s)),
        _ => (false, String::new()),
    };

    let (items, total) = if has_search {
        let items: Vec<TaskRow> = sqlx::query_as(
            "SELECT id, name, `desc`, exec_type, run_mode, command, working_dir, cron_expr,
                    enabled, hidden, run_status, last_run, last_result, updated_time, created_at
             FROM task
             WHERE name LIKE ? OR `desc` LIKE ?
             ORDER BY id DESC
             LIMIT ? OFFSET ?",
        )
        .bind(&like)
        .bind(&like)
        .bind(limit as u64)
        .bind(offset)
        .fetch_all(pool)
        .await?;

        let row: (i64,) = sqlx::query_as(
            "SELECT COUNT(*) as cnt FROM task WHERE name LIKE ? OR `desc` LIKE ?",
        )
        .bind(&like)
        .bind(&like)
        .fetch_one(pool)
        .await?;
        (items, row.0 as u64)
    } else {
        let items: Vec<TaskRow> = sqlx::query_as(
            "SELECT id, name, `desc`, exec_type, run_mode, command, working_dir, cron_expr,
                    enabled, hidden, run_status, last_run, last_result, updated_time, created_at
             FROM task
             ORDER BY id DESC
             LIMIT ? OFFSET ?",
        )
        .bind(limit as u64)
        .bind(offset)
        .fetch_all(pool)
        .await?;

        let row: (i64,) = sqlx::query_as("SELECT COUNT(*) as cnt FROM task")
            .fetch_one(pool)
            .await?;
        (items, row.0 as u64)
    };

    Ok((items, total))
}

/// 任务详情
pub async fn task_detail(pool: &MySqlPool, id: u64) -> Result<Option<TaskRow>, sqlx::Error> {
    sqlx::query_as::<_, TaskRow>(
        "SELECT id, name, `desc`, exec_type, run_mode, command, working_dir, cron_expr,
                enabled, hidden, run_status, last_run, last_result, updated_time, created_at
         FROM task WHERE id = ?",
    )
    .bind(id)
    .fetch_optional(pool)
    .await
}

/// 新增任务
pub async fn task_create(pool: &MySqlPool, r: &TaskCreate) -> Result<u64, sqlx::Error> {
    let result = sqlx::query(
        "INSERT INTO task (name, `desc`, exec_type, run_mode, command, working_dir, cron_expr)
         VALUES (?, ?, ?, ?, ?, ?, ?)",
    )
    .bind(&r.name)
    .bind(&r.desc)
    .bind(&r.exec_type)
    .bind(&r.run_mode)
    .bind(&r.command)
    .bind(&r.working_dir)
    .bind(&r.cron_expr)
    .execute(pool)
    .await?;
    Ok(result.last_insert_id())
}

/// 更新任务
pub async fn task_update(pool: &MySqlPool, id: u64, r: &TaskUpdate) -> Result<u64, sqlx::Error> {
    let result = sqlx::query(
        "UPDATE task SET name=?, `desc`=?, exec_type=?, run_mode=?, command=?, working_dir=?, cron_expr=? WHERE id=?",
    )
    .bind(&r.name)
    .bind(&r.desc)
    .bind(&r.exec_type)
    .bind(&r.run_mode)
    .bind(&r.command)
    .bind(&r.working_dir)
    .bind(&r.cron_expr)
    .bind(id)
    .execute(pool)
    .await?;
    Ok(result.rows_affected())
}

/// 删除任务
pub async fn task_delete(pool: &MySqlPool, id: u64) -> Result<u64, sqlx::Error> {
    let result = sqlx::query("DELETE FROM task WHERE id = ?")
        .bind(id)
        .execute(pool)
        .await?;
    Ok(result.rows_affected())
}

/// 更新任务运行状态（executor 调用）
pub async fn task_set_run_status(
    pool: &MySqlPool,
    id: u64,
    run_status: &str,
    last_result: Option<&str>,
) -> Result<(), sqlx::Error> {
    sqlx::query(
        "UPDATE task SET run_status=?, last_run=NOW(), last_result=? WHERE id=?",
    )
    .bind(run_status)
    .bind(last_result)
    .bind(id)
    .execute(pool)
    .await?;
    Ok(())
}

/// 切换启用状态
pub async fn task_toggle(pool: &MySqlPool, id: u64) -> Result<Option<i8>, sqlx::Error> {
    // 先读取当前状态
    let row: Option<(i8,)> =
        sqlx::query_as("SELECT enabled FROM task WHERE id = ?")
            .bind(id)
            .fetch_optional(pool)
            .await?;
    if let Some((current,)) = row {
        let new_val = if current == 1 { 0i8 } else { 1i8 };
        sqlx::query("UPDATE task SET enabled=? WHERE id=?")
            .bind(new_val)
            .bind(id)
            .execute(pool)
            .await?;
        Ok(Some(new_val))
    } else {
        Ok(None)
    }
}

/// 切换隐藏状态
pub async fn task_toggle_hidden(pool: &MySqlPool, id: u64) -> Result<Option<i8>, sqlx::Error> {
    let row: Option<(i8,)> =
        sqlx::query_as("SELECT hidden FROM task WHERE id = ?")
            .bind(id)
            .fetch_optional(pool)
            .await?;
    if let Some((current,)) = row {
        let new_val = if current == 1 { 0i8 } else { 1i8 };
        sqlx::query("UPDATE task SET hidden=? WHERE id=?")
            .bind(new_val)
            .bind(id)
            .execute(pool)
            .await?;
        Ok(Some(new_val))
    } else {
        Ok(None)
    }
}

/// 获取一条任务
pub async fn task_get(pool: &MySqlPool, id: u64) -> Result<Option<TaskRow>, sqlx::Error> {
    task_detail(pool, id).await
}

// ──────────────────────────────────────────────────────────
//  task_log 增删查
// ──────────────────────────────────────────────────────────

/// 写入 task_log（开始执行时调用）
pub async fn task_log_start(pool: &MySqlPool, task_id: u64) -> Result<u64, sqlx::Error> {
    let result = sqlx::query(
        "INSERT INTO task_log (task_id, status, start_time) VALUES (?, 'running', NOW())",
    )
    .bind(task_id)
    .execute(pool)
    .await?;
    Ok(result.last_insert_id())
}

/// 更新 task_log 结果
pub async fn task_log_finish(
    pool: &MySqlPool,
    log_id: u64,
    status: &str,
    output: Option<&str>,
    error: Option<&str>,
) -> Result<(), sqlx::Error> {
    sqlx::query(
        "UPDATE task_log SET status=?, output=?, error=?, end_time=NOW(),
                duration_ms=TIMESTAMPDIFF(MICROSECOND, start_time, NOW()) / 1000
         WHERE id=?",
    )
    .bind(status)
    .bind(output)
    .bind(error)
    .bind(log_id)
    .execute(pool)
    .await?;
    Ok(())
}

/// 获取任务日志列表
pub async fn task_log_list(
    pool: &MySqlPool,
    task_id: Option<u64>,
    page: u32,
    limit: u32,
) -> Result<(Vec<TaskLogRow>, u64), sqlx::Error> {
    let offset = (page.saturating_sub(1) * limit) as u64;

    let (items, total) = if let Some(tid) = task_id {
        let items = sqlx::query_as::<_, TaskLogRow>(
            "SELECT id, task_id, status, output, error, start_time, end_time, duration_ms
             FROM task_log WHERE task_id = ? ORDER BY id DESC LIMIT ? OFFSET ?",
        )
        .bind(tid)
        .bind(limit as u64)
        .bind(offset)
        .fetch_all(pool)
        .await?;

        let row: (i64,) =
            sqlx::query_as("SELECT COUNT(*) as cnt FROM task_log WHERE task_id = ?")
                .bind(tid)
                .fetch_one(pool)
                .await?;
        (items, row.0 as u64)
    } else {
        let items = sqlx::query_as::<_, TaskLogRow>(
            "SELECT id, task_id, status, output, error, start_time, end_time, duration_ms
             FROM task_log ORDER BY id DESC LIMIT ? OFFSET ?",
        )
        .bind(limit as u64)
        .bind(offset)
        .fetch_all(pool)
        .await?;

        let row: (i64,) = sqlx::query_as("SELECT COUNT(*) as cnt FROM task_log")
            .fetch_one(pool)
            .await?;
        (items, row.0 as u64)
    };

    Ok((items, total))
}

/// 获取单条日志详情
pub async fn task_log_detail(pool: &MySqlPool, id: u64) -> Result<Option<TaskLogRow>, sqlx::Error> {
    sqlx::query_as::<_, TaskLogRow>(
        "SELECT id, task_id, status, output, error, start_time, end_time, duration_ms
         FROM task_log WHERE id = ?",
    )
    .bind(id)
    .fetch_optional(pool)
    .await
}

/// 删除单条日志
pub async fn task_log_delete(pool: &MySqlPool, id: u64) -> Result<u64, sqlx::Error> {
    let result = sqlx::query("DELETE FROM task_log WHERE id = ?")
        .bind(id)
        .execute(pool)
        .await?;
    Ok(result.rows_affected())
}

/// 删除某任务的全部日志
pub async fn task_log_delete_by_task(pool: &MySqlPool, task_id: u64) -> Result<u64, sqlx::Error> {
    let result = sqlx::query("DELETE FROM task_log WHERE task_id = ?")
        .bind(task_id)
        .execute(pool)
        .await?;
    Ok(result.rows_affected())
}

// ──────────────────────────────────────────────────────────
//  创建/更新请求体
// ──────────────────────────────────────────────────────────

#[derive(Debug, Deserialize)]
pub struct TaskCreate {
    pub name: String,
    pub desc: Option<String>,
    pub exec_type: Option<String>,
    pub run_mode: Option<String>,
    pub command: String,
    pub working_dir: Option<String>,
    pub cron_expr: Option<String>,
}

#[derive(Debug, Deserialize)]
pub struct TaskUpdate {
    pub name: String,
    pub desc: Option<String>,
    pub exec_type: Option<String>,
    pub run_mode: Option<String>,
    pub command: String,
    pub working_dir: Option<String>,
    pub cron_expr: Option<String>,
}
