//! 股票基本信息表 stock_basic 数据访问

use sqlx::MySqlPool;

/// stock_basic 行数据
#[derive(Debug, Clone, sqlx::FromRow)]
pub struct StockBasicRow {
    pub id: i32,
    pub symbol: String,
    pub name: String,
    pub market_code: String,
    pub price_precision: Option<i32>,
    pub qty_precision: Option<i32>,
    pub enabled: Option<bool>,
}

/// 根据 symbol 查询 stock_basic（不限制 market_code，取第一条启用的记录）
pub async fn find_by_symbol(pool: &MySqlPool, symbol: &str) -> Result<Option<StockBasicRow>, sqlx::Error> {
    sqlx::query_as::<_, StockBasicRow>(
        "SELECT id, symbol, name, market_code, price_precision, qty_precision, enabled
         FROM stock_basic
         WHERE symbol = ? AND enabled = 1
         LIMIT 1",
    )
    .bind(symbol)
    .fetch_optional(pool)
    .await
}

/// 获取所有启用的股票列表，可按 market_code 过滤，limit 500
pub async fn find_all_enabled(pool: &MySqlPool, market_code: Option<&str>) -> Result<Vec<StockBasicRow>, sqlx::Error> {
    if let Some(mc) = market_code {
        if !mc.is_empty() {
            return sqlx::query_as::<_, StockBasicRow>(
                "SELECT id, symbol, name, market_code, price_precision, qty_precision, enabled
                 FROM stock_basic
                 WHERE enabled = 1 AND market_code = ?
                 ORDER BY symbol
                 LIMIT 500",
            )
            .bind(mc)
            .fetch_all(pool)
            .await;
        }
    }
    sqlx::query_as::<_, StockBasicRow>(
        "SELECT id, symbol, name, market_code, price_precision, qty_precision, enabled
         FROM stock_basic
         WHERE enabled = 1
         ORDER BY symbol
         LIMIT 500",
    )
    .fetch_all(pool)
    .await
}

/// 模糊搜索（按 symbol 或 name，不限制 market_code）
pub async fn search(pool: &MySqlPool, query: &str, limit: u32) -> Result<Vec<StockBasicRow>, sqlx::Error> {
    let pattern = format!("%{}%", query);
    sqlx::query_as::<_, StockBasicRow>(
        "SELECT id, symbol, name, market_code, price_precision, qty_precision, enabled
         FROM stock_basic
         WHERE enabled = 1 AND (symbol LIKE ? OR name LIKE ?)
         ORDER BY symbol
         LIMIT ?",
    )
    .bind(&pattern)
    .bind(&pattern)
    .bind(limit)
    .fetch_all(pool)
    .await
}
