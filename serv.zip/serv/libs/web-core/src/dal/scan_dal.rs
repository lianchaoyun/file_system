//! 扫描结果 & 策略数据访问层

use serde::{Deserialize, Serialize};
use sqlx::{MySql, MySqlPool, QueryBuilder};

// ──────────────────────────────────────────────────────────
//  数据模型
// ──────────────────────────────────────────────────────────

/// stock_scan_strategies 行数据（含该策略股票数量）
#[derive(Debug, Clone, sqlx::FromRow, Serialize, Deserialize)]
pub struct ScanStrategyRow {
    pub id: i64,
    pub code: String,
    pub name: String,
    pub enabled: Option<i8>,
    /// 该策略在最近扫描日期下的股票数量
    pub count: Option<i64>,
}

/// stock_scan_result 行数据
#[derive(Debug, Clone, sqlx::FromRow, Serialize, Deserialize)]
pub struct ScanResultRow {
    pub id: i64,
    pub symbol: String,
    pub name: String,
    pub strategy_id: i64,
    pub price: Option<rust_decimal::Decimal>,
    pub change_pct: Option<rust_decimal::Decimal>,
    pub sharpe: Option<rust_decimal::Decimal>,
    pub annual_return: Option<rust_decimal::Decimal>,
    pub extra_data: Option<String>,
    pub scan_date: chrono::NaiveDate,
    pub created_at: Option<chrono::NaiveDateTime>,
    // JOIN stock_scan_strategies
    pub strategy_name: Option<String>,
}

// ──────────────────────────────────────────────────────────
//  策略查询
// ──────────────────────────────────────────────────────────

/// 获取所有启用的策略（含该策略在最近扫描日期的股票数量）
pub async fn get_strategies(pool: &MySqlPool) -> Result<Vec<ScanStrategyRow>, sqlx::Error> {
    sqlx::query_as::<_, ScanStrategyRow>(
        "SELECT CAST(s.id AS SIGNED) as id, s.code, s.name,
                CAST(s.enabled AS SIGNED) as enabled,
                CAST(COUNT(r.id) AS SIGNED) as count
         FROM stock_scan_strategies s
         LEFT JOIN stock_scan_result r
             ON s.id = r.strategy_id
             AND r.scan_date = (SELECT MAX(scan_date) FROM stock_scan_result)
         WHERE s.enabled = 1
         GROUP BY s.id, s.code, s.name, s.enabled
         ORDER BY s.id ASC",
    )
    .fetch_all(pool)
    .await
}

// ──────────────────────────────────────────────────────────
//  扫描结果查询
// ──────────────────────────────────────────────────────────

/// 获取扫描结果（支持 strategy_id / date / keyword 筛选）
pub async fn get_results(
    pool: &MySqlPool,
    strategy_id: Option<i64>,
    date: Option<&str>,
    keyword: Option<&str>,
) -> Result<Vec<ScanResultRow>, sqlx::Error> {
    let mut builder: QueryBuilder<MySql> = QueryBuilder::new(
        "SELECT CAST(r.id AS SIGNED) as id, r.symbol, r.name,
                CAST(r.strategy_id AS SIGNED) as strategy_id,
                r.price, r.change_pct, r.sharpe, r.annual_return,
                r.extra_data, r.scan_date, r.created_at,
                s.name as strategy_name
         FROM stock_scan_result r
         LEFT JOIN stock_scan_strategies s ON r.strategy_id = s.id",
    );

    let mut has_where = false;

    if let Some(v) = strategy_id {
        builder.push(" WHERE r.strategy_id = ").push_bind(v);
        has_where = true;
    }
    if let Some(v) = date {
        if has_where {
            builder.push(" AND ");
        } else {
            builder.push(" WHERE ");
        }
        builder.push("r.scan_date = ").push_bind(v);
        has_where = true;
    }
    if let Some(v) = keyword {
        let pattern = format!("%{}%", v);
        if has_where {
            builder.push(" AND ");
        } else {
            builder.push(" WHERE ");
        }
        builder
            .push("(r.symbol LIKE ")
            .push_bind(pattern.clone())
            .push(" OR r.name LIKE ")
            .push_bind(pattern)
            .push(")");
    }

    builder.push(" ORDER BY r.scan_date DESC, r.strategy_id ASC, r.symbol ASC LIMIT 500");

    builder.build_query_as::<ScanResultRow>().fetch_all(pool).await
}

/// 获取最近一次扫描的日期列表（去重，最多30天）
pub async fn get_scan_dates(pool: &MySqlPool) -> Result<Vec<chrono::NaiveDate>, sqlx::Error> {
    let rows: Vec<(chrono::NaiveDate,)> = sqlx::query_as(
        "SELECT DISTINCT scan_date
         FROM stock_scan_result
         ORDER BY scan_date DESC
         LIMIT 30",
    )
    .fetch_all(pool)
    .await?;
    Ok(rows.into_iter().map(|r| r.0).collect())
}

/// 获取最近扫描日期
pub async fn get_latest_scan_date(pool: &MySqlPool) -> Result<Option<chrono::NaiveDate>, sqlx::Error> {
    let row: Option<(chrono::NaiveDate,)> = sqlx::query_as(
        "SELECT MAX(scan_date) FROM stock_scan_result",
    )
    .fetch_optional(pool)
    .await?;
    Ok(row.map(|r| r.0))
}
