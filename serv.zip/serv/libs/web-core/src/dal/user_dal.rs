//! 用户表 SQL 操作

use serde_json::Value;
use sqlx::MySqlPool;

/// 查询所有用户
pub async fn find_all(_pool: &MySqlPool) -> Result<Vec<Value>, sqlx::Error> {
    // TODO: sqlx::query_as("SELECT * FROM users")
    Ok(vec![])
}

/// 根据 ID 查询用户
pub async fn find_by_id(_pool: &MySqlPool, _id: i64) -> Result<Option<Value>, sqlx::Error> {
    // TODO: sqlx::query_as("SELECT * FROM users WHERE id = ?")
    Ok(None)
}

/// 根据用户名查询用户
pub async fn find_by_username(_pool: &MySqlPool, _username: &str) -> Result<Option<Value>, sqlx::Error> {
    // TODO: sqlx::query_as("SELECT * FROM users WHERE username = ?")
    Ok(None)
}

/// 创建用户
pub async fn create(_pool: &MySqlPool, _data: &Value) -> Result<i64, sqlx::Error> {
    // TODO: sqlx::query("INSERT INTO users ...")
    Ok(0)
}
