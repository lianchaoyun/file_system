//! 持仓数据访问层

use serde::{Deserialize, Serialize};
use sqlx::MySqlPool;

// ──────────────────────────────────────────────────────────
//  数据模型
// ──────────────────────────────────────────────────────────

/// stock_positions 行数据
#[derive(Debug, Clone, sqlx::FromRow, Serialize, Deserialize)]
pub struct PositionRow {
    pub id: i64,
    pub market_code: String,
    pub symbol: String,
    pub name: Option<String>,
    pub direction: Option<String>,
    pub quantity: rust_decimal::Decimal,
    pub avg_price: rust_decimal::Decimal,
    pub current_price: Option<rust_decimal::Decimal>,
    pub market_value: Option<rust_decimal::Decimal>,
    pub first_buy_time: Option<chrono::NaiveDateTime>,
    pub update_time: Option<chrono::NaiveDateTime>,
}

/// 持仓汇总
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PositionSummary {
    pub total_market_value: rust_decimal::Decimal,
    pub total_profit_loss: rust_decimal::Decimal,
    pub total_profit_loss_pct: rust_decimal::Decimal,
}

// ──────────────────────────────────────────────────────────
//  数据查询
// ──────────────────────────────────────────────────────────

/// 获取某市场持仓列表（含盈亏计算）
pub async fn get_positions_by_market(
    pool: &MySqlPool,
    market_code: &str,
) -> Result<Vec<PositionRow>, sqlx::Error> {
    sqlx::query_as::<_, PositionRow>(
        r#"SELECT
            CAST(id AS SIGNED) as id,
            market_code,
            symbol,
            name,
            CAST(direction AS CHAR) as direction,
            quantity,
            CAST(avg_price AS DECIMAL(24,8)) as avg_price,
            CAST(current_price AS DECIMAL(24,8)) as current_price,
            CAST(market_value AS DECIMAL(24,8)) as market_value,
            first_buy_time,
            update_time
         FROM stock_positions
         WHERE market_code = ?
         ORDER BY COALESCE(market_value, 0) DESC"#,
    )
    .bind(market_code)
    .fetch_all(pool)
    .await
}

/// 获取某市场持仓汇总统计
pub async fn get_position_summary(
    pool: &MySqlPool,
    market_code: &str,
) -> Result<PositionSummary, sqlx::Error> {
    let row = sqlx::query_as::<_, (Option<rust_decimal::Decimal>, Option<rust_decimal::Decimal>)>(
        r#"SELECT
            COALESCE(SUM(quantity * avg_price), 0) as total_cost,
            COALESCE(SUM(market_value), 0) as total_market_value
         FROM stock_positions
         WHERE market_code = ?"#,
    )
    .bind(market_code)
    .fetch_one(pool)
    .await?;

    let total_cost = row.0.unwrap_or_else(|| rust_decimal::Decimal::ZERO);
    let total_market_value = row.1.unwrap_or_else(|| rust_decimal::Decimal::ZERO);

    let total_profit_loss = total_market_value - total_cost;
    let total_profit_loss_pct = if total_cost.is_zero() {
        rust_decimal::Decimal::ZERO
    } else {
        (total_profit_loss.clone() / total_cost.clone())
            * rust_decimal::Decimal::new(100, 2)
    };

    Ok(PositionSummary {
        total_market_value,
        total_profit_loss,
        total_profit_loss_pct,
    })
}
