//! 关注分组 & 关注股票数据访问层

use serde::{Deserialize, Serialize};
use sqlx::{MySql, MySqlPool, QueryBuilder};

// ──────────────────────────────────────────────────────────
//  数据模型
// ──────────────────────────────────────────────────────────

/// stock_watch_groups 行数据
#[derive(Debug, Clone, sqlx::FromRow, Serialize, Deserialize)]
pub struct WatchGroupRow {
    pub id: i64,
    pub name: String,
    pub icon: Option<String>,
    pub color: Option<String>,
    pub sort_order: Option<i32>,
    pub is_default: Option<i8>,
}

/// stock_watch_items 行数据（含 JOIN 的关联字段）
#[derive(Debug, Clone, sqlx::FromRow, Serialize, Deserialize)]
pub struct WatchItemRow {
    pub id: i64,
    pub symbol: String,
    pub group_id: i64,
    pub note: Option<String>,
    pub sort_order: Option<i32>,
    pub created_at: Option<chrono::NaiveDateTime>,
    // JOIN stock_watch_groups
    pub group_name: Option<String>,
    pub group_color: Option<String>,
    // JOIN stock_basic
    pub stock_name: Option<String>,
    pub market_code: Option<String>,
}

// ──────────────────────────────────────────────────────────
//  分组 CRUD
// ──────────────────────────────────────────────────────────

/// 获取所有分组
pub async fn get_groups(pool: &MySqlPool) -> Result<Vec<WatchGroupRow>, sqlx::Error> {
    sqlx::query_as::<_, WatchGroupRow>(
        "SELECT CAST(id AS SIGNED) as id, name, icon, color, sort_order,
                CAST(is_default AS SIGNED) as is_default
         FROM stock_watch_groups
         ORDER BY sort_order ASC, id ASC",
    )
    .fetch_all(pool)
    .await
}

/// 创建分组
pub async fn create_group(
    pool: &MySqlPool,
    name: &str,
    icon: Option<&str>,
    color: Option<&str>,
) -> Result<i64, sqlx::Error> {
    let result = sqlx::query(
        "INSERT INTO stock_watch_groups (name, icon, color) VALUES (?, ?, ?)",
    )
    .bind(name)
    .bind(icon)
    .bind(color)
    .execute(pool)
    .await?;
    Ok(result.last_insert_id() as i64)
}

/// 更新分组
pub async fn update_group(
    pool: &MySqlPool,
    id: i64,
    name: Option<&str>,
    icon: Option<&str>,
    color: Option<&str>,
) -> Result<(), sqlx::Error> {
    let mut builder: QueryBuilder<MySql> = QueryBuilder::new("UPDATE stock_watch_groups SET ");

    let mut first = true;
    if let Some(v) = name {
        if !first { builder.push(", "); }
        builder.push("name = ").push_bind(v);
        first = false;
    }
    if let Some(v) = icon {
        if !first { builder.push(", "); }
        builder.push("icon = ").push_bind(v);
        first = false;
    }
    if let Some(v) = color {
        if !first { builder.push(", "); }
        builder.push("color = ").push_bind(v);
        first = false;
    }

    if first {
        return Ok(()); // 没有要更新的字段
    }

    builder.push(" WHERE id = ").push_bind(id);
    builder.build().execute(pool).await?;
    Ok(())
}

/// 删除分组（同时删除该分组的关注项）
pub async fn delete_group(pool: &MySqlPool, id: i64) -> Result<(), sqlx::Error> {
    let mut tx = pool.begin().await?;
    sqlx::query("DELETE FROM stock_watch_items WHERE group_id = ?")
        .bind(id)
        .execute(&mut *tx)
        .await?;
    sqlx::query("DELETE FROM stock_watch_groups WHERE id = ?")
        .bind(id)
        .execute(&mut *tx)
        .await?;
    tx.commit().await?;
    Ok(())
}

// ──────────────────────────────────────────────────────────
//  关注项 CRUD
// ──────────────────────────────────────────────────────────

/// 获取关注列表（可按 group_id、keyword 过滤）
pub async fn get_items(
    pool: &MySqlPool,
    group_id: Option<i64>,
    keyword: Option<&str>,
) -> Result<Vec<WatchItemRow>, sqlx::Error> {
    let mut builder: QueryBuilder<MySql> = QueryBuilder::new(
        "SELECT CAST(wi.id AS SIGNED) as id, wi.symbol,
                CAST(wi.group_id AS SIGNED) as group_id,
                wi.note, wi.sort_order, wi.created_at,
                wg.name as group_name, wg.color as group_color,
                sb.name as stock_name, sb.market_code
         FROM stock_watch_items wi
         LEFT JOIN stock_watch_groups wg ON wi.group_id = wg.id
         LEFT JOIN stock_basic sb
             ON wi.symbol COLLATE utf8mb4_uca1400_ai_ci = sb.symbol
             AND sb.enabled = 1",
    );

    let mut has_where = false;

    if group_id.map_or(false, |v| v > 0) {
        builder.push(" WHERE wi.group_id = ").push_bind(group_id.unwrap());
        has_where = true;
    }
    if let Some(v) = keyword {
        let pattern = format!("%{}%", v);
        if has_where {
            builder.push(" AND ");
        } else {
            builder.push(" WHERE ");
        }
        builder
            .push("(wi.symbol LIKE ")
            .push_bind(pattern.clone())
            .push(" OR sb.name LIKE ")
            .push_bind(pattern)
            .push(")");
    }

    builder.push(" ORDER BY wi.sort_order ASC, wi.id ASC");

    builder.build_query_as::<WatchItemRow>().fetch_all(pool).await
}

/// 添加关注
pub async fn add_item(
    pool: &MySqlPool,
    symbol: &str,
    group_id: i64,
    note: Option<&str>,
) -> Result<i64, sqlx::Error> {
    let max_sort: Option<i32> = sqlx::query_scalar(
        "SELECT MAX(sort_order) FROM stock_watch_items WHERE group_id = ?",
    )
    .bind(group_id)
    .fetch_optional(pool)
    .await?
    .flatten();

    let sort_order = max_sort.map(|v| v + 1).unwrap_or(0);

    let result = sqlx::query(
        "INSERT IGNORE INTO stock_watch_items (symbol, group_id, note, sort_order) VALUES (?, ?, ?, ?)",
    )
    .bind(symbol)
    .bind(group_id)
    .bind(note)
    .bind(sort_order)
    .execute(pool)
    .await?;

    Ok(result.last_insert_id() as i64)
}

/// 更新关注项 (分组/备注)
pub async fn update_item(
    pool: &MySqlPool,
    id: i64,
    group_id: Option<i64>,
    note: Option<&str>,
    sort_order: Option<i32>,
) -> Result<(), sqlx::Error> {
    let mut builder: QueryBuilder<MySql> = QueryBuilder::new("UPDATE stock_watch_items SET ");

    let mut first = true;
    if let Some(v) = group_id {
        builder.push("group_id = ").push_bind(v);
        first = false;
    }
    if let Some(v) = note {
        if !first { builder.push(", "); }
        builder.push("note = ").push_bind(v);
        first = false;
    }
    if let Some(v) = sort_order {
        if !first { builder.push(", "); }
        builder.push("sort_order = ").push_bind(v);
    }

    if first {
        return Ok(());
    }

    builder.push(" WHERE id = ").push_bind(id);
    builder.build().execute(pool).await?;
    Ok(())
}

/// 删除关注项
pub async fn delete_item(pool: &MySqlPool, id: i64) -> Result<(), sqlx::Error> {
    sqlx::query("DELETE FROM stock_watch_items WHERE id = ?")
        .bind(id)
        .execute(pool)
        .await?;
    Ok(())
}

/// 检查股票是否已关注（任意分组）
pub async fn is_watched(pool: &MySqlPool, symbol: &str) -> Result<bool, sqlx::Error> {
    let count: Option<i64> = sqlx::query_scalar(
        "SELECT COUNT(*) FROM stock_watch_items WHERE symbol = ?",
    )
    .bind(symbol)
    .fetch_optional(pool)
    .await?
    .flatten();
    Ok(count.unwrap_or(0) > 0)
}

/// 获取某个股票的所有关注记录 id 列表
pub async fn get_watch_item_ids(
    pool: &MySqlPool,
    symbol: &str,
) -> Result<Vec<i64>, sqlx::Error> {
    let rows: Vec<(i64,)> = sqlx::query_as(
        "SELECT CAST(id AS SIGNED) as id FROM stock_watch_items WHERE symbol = ?",
    )
    .bind(symbol)
    .fetch_all(pool)
    .await?;
    Ok(rows.into_iter().map(|r| r.0).collect())
}
