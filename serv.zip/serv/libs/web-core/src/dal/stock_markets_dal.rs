//! 市场配置表 stock_markets 数据访问

use sqlx::MySqlPool;

/// stock_markets 行数据
#[derive(Debug, Clone, sqlx::FromRow)]
pub struct StockMarketRow {
    pub code: String,
    pub name: String,
    #[allow(dead_code)]
    pub timezone: Option<String>,
    #[allow(dead_code)]
    pub trading_sessions: Option<String>,
    pub currency: Option<String>,
    pub enabled: Option<bool>,
}

/// 查询所有启用的市场
pub async fn find_all_enabled(pool: &MySqlPool) -> Result<Vec<StockMarketRow>, sqlx::Error> {
    sqlx::query_as::<_, StockMarketRow>(
        "SELECT code, name, timezone, trading_sessions, currency, enabled
         FROM stock_markets
         WHERE enabled = 1
         ORDER BY sort_order DESC",
    )
    .fetch_all(pool)
    .await
}
