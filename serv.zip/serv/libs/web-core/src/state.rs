//! 应用全局状态

use common::config::AppConfig;
use common::tdx_data::TdxDataProvider;

/// 应用全局状态（handler 通过 `State<AppState>` 获取）
#[derive(Clone)]
pub struct AppState {
    pub config: AppConfig,
    pub tdx: TdxDataProvider,
}
