//! 图表相关路由 — TradingView Charting Library 数据接口

use axum::{routing::get, Router};

use crate::handlers::chart_handler;
use crate::state::AppState;

pub fn routes() -> Router<AppState> {
    Router::new()
        .route("/config", get(chart_handler::config))
        .route("/symbols", get(chart_handler::symbols))
        .route("/symbol_info", get(chart_handler::symbol_info))
        .route("/history", get(chart_handler::history))
        .route("/search", get(chart_handler::search))
        .route("/marks", get(chart_handler::marks))
}
