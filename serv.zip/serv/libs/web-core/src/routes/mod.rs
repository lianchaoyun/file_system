//! 路由层：路由注册 trait + 内置路由 + 业务路由聚合

pub mod auth;
pub mod chart;
pub mod position;
pub mod scan;
pub mod settings;
pub mod stock;
pub mod task;
pub mod user;
pub mod watch;
pub mod ws;

use axum::{routing::get, Json, Router};
use serde_json::{json, Value};

use crate::state::AppState;

// ── 路由注册 trait ─────────────────────────────────────

/// 业务模块实现此 trait 来注册自己的路由
///
/// ```ignore
/// use axum::{Router, routing::get};
/// use web_core::{AppState, RouteRegister};
///
/// struct UserModule;
/// impl RouteRegister for UserModule {
///     fn register_routes(router: Router<AppState>) -> Router<AppState> {
///         router.route("/api/users", get(get_users))
///     }
/// }
/// ```
pub trait RouteRegister {
    fn register_routes(router: Router<AppState>) -> Router<AppState>;
}

// ── 内置路由 ────────────────────────────────────────────

/// 健康检查
pub fn health_check() -> Router<AppState> {
    async fn handler() -> Json<Value> {
        Json(json!({
            "code": 0,
            "msg": "ok",
            "data": { "status": "running" },
        }))
    }

    Router::new().route("/health", get(handler))
}

// ── 业务路由聚合 ────────────────────────────────────────

/// 聚合所有业务路由，供 server 层调用
pub fn all() -> Router<AppState> {
    Router::new()
        .merge(user::routes())
        .merge(auth::routes())
        .merge(chart::routes())
        .merge(position::routes())
        .merge(scan::routes())
        .merge(settings::routes())
        .merge(stock::routes())
        .merge(task::routes())
        .merge(watch::routes())
        .merge(ws::routes())
}
