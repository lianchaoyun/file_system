//! 任务路由

use axum::{routing::{get, post}, Router};

use crate::handlers::task_handler;
use crate::state::AppState;

pub fn routes() -> Router<AppState> {
    Router::new()
        // task
        .route("/tasks", get(task_handler::list))
        .route("/tasks/detail", get(task_handler::detail))
        .route("/tasks/create", post(task_handler::create))
        .route("/tasks/update", post(task_handler::update))
        .route("/tasks/delete", get(task_handler::delete))
        .route("/tasks/toggle", get(task_handler::toggle))
        .route("/tasks/toggle-hidden", get(task_handler::toggle_hidden))
        .route("/tasks/execute", get(task_handler::execute))
        // task-logs
        .route("/task-logs", get(task_handler::log_list))
        .route("/task-logs/detail", get(task_handler::log_detail))
        .route("/task-logs/delete", get(task_handler::log_delete))
        .route("/task-logs/clear", get(task_handler::log_clear))
}
