//! 扫描结果路由

use axum::{routing::get, Router};

use crate::handlers::scan_handler;
use crate::state::AppState;

pub fn routes() -> Router<AppState> {
    Router::new()
        .route("/scan/strategies", get(scan_handler::strategies))
        .route("/scan/results", get(scan_handler::results))
        .route("/scan/dates", get(scan_handler::dates))
}
