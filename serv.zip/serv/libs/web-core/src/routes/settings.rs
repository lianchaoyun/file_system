//! 设置路由

use axum::{routing::{get, post}, Router};

use crate::handlers::settings_handler;
use crate::state::AppState;

pub fn routes() -> Router<AppState> {
    Router::new()
        .route("/settings/get", get(settings_handler::get))
        .route("/settings/set", post(settings_handler::set))
}
