//! 持仓路由

use axum::{routing::get, Router};

use crate::handlers::position_handler;
use crate::state::AppState;

pub fn routes() -> Router<AppState> {
    Router::new()
        .route("/positions", get(position_handler::positions))
}
