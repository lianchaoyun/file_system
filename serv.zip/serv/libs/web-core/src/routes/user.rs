//! 用户相关路由 `/api/v1/users/**`

use axum::{routing::get, Router};
use crate::handlers::user_handler;
use crate::state::AppState;

pub fn routes() -> Router<AppState> {
    Router::new()
        .route("/api/v1/users", get(user_handler::list))
        .route("/api/v1/users/{id}", get(user_handler::get_by_id))
}
