//! 股票通用路由（东财打开等）

use axum::{routing::post, Router};

use crate::handlers::stock_handler;
use crate::state::AppState;

pub fn routes() -> Router<AppState> {
    Router::new()
        .route("/open/dc", post(stock_handler::open_in_dc))
}
