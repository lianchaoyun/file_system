//! 认证相关路由 `/api/v1/auth/**`

use axum::{routing::post, Router};
use crate::handlers::auth_handler;
use crate::state::AppState;

pub fn routes() -> Router<AppState> {
    Router::new()
        .route("/api/v1/auth/login", post(auth_handler::login))
        .route("/api/v1/auth/register", post(auth_handler::register))
}
