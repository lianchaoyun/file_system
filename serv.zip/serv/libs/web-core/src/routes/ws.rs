//! WebSocket 命令执行路由

use axum::{
    extract::ws::{Message, WebSocket},
    extract::WebSocketUpgrade,
    response::Response,
    Router,
};
use futures::{SinkExt, StreamExt};
use serde::{Deserialize, Serialize};
use tracing::info;

use crate::state::AppState;

// ── 消息协议 ────────────────────────────────────────────

#[derive(Debug, Deserialize)]
pub struct CommandRequest {
    pub cmd: String,
    #[serde(default)]
    pub args: Vec<String>,
}

#[derive(Debug, Serialize)]
pub struct CommandResponse {
    pub code: i32,
    pub msg: String,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub data: Option<serde_json::Value>,
}

// ── WebSocket Handler ────────────────────────────────────

async fn handle_socket(socket: WebSocket) {
    let (mut sender, mut receiver) = socket.split();

    // 发送欢迎消息
    let welcome = CommandResponse {
        code: 0,
        msg: "connected".to_string(),
        data: Some(serde_json::json!({
            "supported_commands": ["ping", "echo", "time", "exec"]
        })),
    };
    if let Ok(msg) = serde_json::to_string(&welcome) {
        let _ = sender.send(Message::Text(msg.into())).await;
    }

    // 消息处理循环
    while let Some(Ok(msg)) = receiver.next().await {
        match msg {
            Message::Text(text) => {
                info!("WS 收到: {}", text);
                let response = match serde_json::from_str::<CommandRequest>(&text) {
                    Ok(req) => execute_command(req).await,
                    Err(e) => CommandResponse {
                        code: -1,
                        msg: format!("无效格式: {}", e),
                        data: None,
                    },
                };
                if let Ok(msg) = serde_json::to_string(&response) {
                    let _ = sender.send(Message::Text(msg.into())).await;
                }
            }
            Message::Close(_) => break,
            _ => {}
        }
    }
    info!("WS 连接关闭");
}

// ── 命令执行 ────────────────────────────────────────────

async fn execute_command(req: CommandRequest) -> CommandResponse {
    match req.cmd.as_str() {
        "ping" => CommandResponse {
            code: 0,
            msg: "success".to_string(),
            data: Some(serde_json::json!({"result": "pong"})),
        },
        "echo" => CommandResponse {
            code: 0,
            msg: "success".to_string(),
            data: Some(serde_json::json!({"result": req.args.join(" ")})),
        },
        "time" => {
            let now = chrono::Utc::now();
            CommandResponse {
                code: 0,
                msg: "success".to_string(),
                data: Some(serde_json::json!({"result": now.to_rfc3339()})),
            }
        }
        // ⚠️ 执行 shell 命令（需谨慎）
        "exec" => {
            if let Some(cmd) = req.args.first() {
                match tokio::process::Command::new(cmd)
                    .args(&req.args[1..])
                    .output()
                    .await
                {
                    Ok(output) => {
                        let stdout = String::from_utf8_lossy(&output.stdout).to_string();
                        let stderr = String::from_utf8_lossy(&output.stderr).to_string();
                        CommandResponse {
                            code: output.status.code().unwrap_or(-1),
                            msg: if output.status.success() {
                                "success"
                            } else {
                                "failed"
                            }
                            .to_string(),
                            data: Some(serde_json::json!({
                                "stdout": stdout,
                                "stderr": stderr,
                            })),
                        }
                    }
                    Err(e) => CommandResponse {
                        code: -1,
                        msg: format!("执行失败: {}", e),
                        data: None,
                    },
                }
            } else {
                CommandResponse {
                    code: -1,
                    msg: "缺少命令".to_string(),
                    data: None,
                }
            }
        }
        _ => CommandResponse {
            code: -1,
            msg: format!("未知命令: {}", req.cmd),
            data: None,
        },
    }
}

// ── 路由 ────────────────────────────────────────────────

async fn ws_handler(ws: WebSocketUpgrade) -> Response {
    ws.on_upgrade(handle_socket)
}

pub fn routes() -> Router<AppState> {
    Router::new().route("/ws/cmd", axum::routing::get(ws_handler))
}
