//! 关注分组路由（全部 GET，静态路径 + query 参数）

use axum::{routing::get, Router};

use crate::handlers::watch_handler;
use crate::state::AppState;

pub fn routes() -> Router<AppState> {
    Router::new()
        // 分组：查列表 / 创建
        .route("/watch/groups", get(watch_handler::groups))
        // 分组：更新
        .route("/watch/groups/update", get(watch_handler::update_group))
        // 分组：删除
        .route("/watch/groups/delete", get(watch_handler::delete_group))
        // 关注项：查列表 / 添加
        .route("/watch/items", get(watch_handler::items))
        // 关注项：更新
        .route("/watch/items/update", get(watch_handler::update_item))
        // 关注项：删除
        .route("/watch/items/delete", get(watch_handler::delete_item))
        // 检查是否关注
        .route("/watch/check", get(watch_handler::check_watched))
        // 获取某股票的所有关注记录 id
        .route("/watch/ids", get(watch_handler::get_ids_by_symbol))
}
