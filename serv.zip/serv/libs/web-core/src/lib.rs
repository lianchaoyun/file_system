//! web-core — Web 服务核心模块
//!
//! 分层架构: routes → handlers → services → dal
//!
//! 启动方式（选一个）：
//!   web_core::run(pool)  — 【推荐】完整启动：配置+日志+HTTP后台
//!   web_core::serve()    — 一站式同步启动：配置+日志+DB+Redis+HTTP阻塞
//!   web_core::start()    — 仅 HTTP 监听（需先完成 init + DB 初始化）

pub mod dal;
pub mod handlers;
pub mod middleware;
pub mod routes;
pub mod services;
pub mod utils;

mod server;
mod state;

pub use routes::RouteRegister;
pub use server::{run, serve, start, WebCoreGuard};
pub use state::AppState;
