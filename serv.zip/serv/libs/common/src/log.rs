//! 日志系统：控制台 + 文件双输出，配置驱动
//!
//! 使用：
//!   let _guard = common::log::init(Some("aiai"));
//!   log!("启动成功");
//!   wrn!("警告");
//!   err!("错误");

use tracing_appender::rolling::{Rotation, RollingFileAppender};
use tracing_subscriber::{fmt, prelude::*, EnvFilter};

// ── 时间格式 ──────────────────────────────────────────

struct LocalTimer;
impl fmt::time::FormatTime for LocalTimer {
    fn format_time(&self, w: &mut fmt::format::Writer<'_>) -> std::fmt::Result {
        write!(w, "{}", chrono::Local::now().format("%Y-%m-%d %H:%M:%S"))
    }
}

// ── 宏 ────────────────────────────────────────────────

#[macro_export]
macro_rules! log { ($($arg:tt)*) => { tracing::info!($($arg)*) }; }

#[macro_export]
macro_rules! dbg { ($($arg:tt)*) => { tracing::debug!($($arg)*) }; }

#[macro_export]
macro_rules! trc { ($($arg:tt)*) => { tracing::trace!($($arg)*) }; }

#[macro_export]
macro_rules! wrn { ($($arg:tt)*) => { tracing::warn!($($arg)*) }; }

#[macro_export]
macro_rules! err { ($($arg:tt)*) => { tracing::error!($($arg)*) }; }

// ── Guard ─────────────────────────────────────────────

/// 保持此值存活，否则日志文件停止写入
pub struct LogGuard {
    _guard: tracing_appender::non_blocking::WorkerGuard,
}

// ── 初始化 ────────────────────────────────────────────

/// 初始化日志（读取 config 中的 log 配置）
///
/// 配置项:
///   [log].level     → 日志级别（trace/debug/info/warn/error）
///   [log].output    → "stdout" / "file"（都输出）
///   [log].file_path → 日志路径，如 "data/logs/app.log"
///                     解析为: 目录=data/logs，前缀=app，后缀=.log（按天滚动）
pub fn init(log_name: Option<&str>) -> LogGuard {
    let cfg = crate::config::AppConfig::get().log;
    let name = log_name.unwrap_or("app");

    // 从 file_path 解析目录和文件名前缀
    //   "data/logs/app.log"  → dir=./data/logs  prefix=app
    let p = std::path::Path::new(&cfg.file_path);
    let dir = p.parent().unwrap_or(std::path::Path::new("logs")).to_path_buf();
    let prefix = p
        .file_stem()
        .and_then(|s| s.to_str())
        .unwrap_or(name)
        .to_string();

    let _ = std::fs::create_dir_all(&dir);

    // 文件输出
    let file_appender = RollingFileAppender::new(
        Rotation::DAILY,
        &dir,
        &format!("{prefix}.log"),
    );
    let (non_blocking, guard) = tracing_appender::non_blocking(file_appender);

    // 日志级别
    let env_filter = EnvFilter::try_from_default_env()
        .unwrap_or_else(|_| EnvFilter::new(&cfg.level));

    // 构建 subscriber
    let mut layers = Vec::new();

    // 控制台始终输出
    layers.push(
        fmt::layer()
            .with_writer(std::io::stdout)
            .with_ansi(true)
            .with_timer(LocalTimer)
            .with_filter(env_filter.clone())
            .boxed(),
    );

    // output = "file" 时追加文件层
    if cfg.output == "file" {
        layers.push(
            fmt::layer()
                .with_writer(non_blocking)
                .with_ansi(false)
                .with_timer(LocalTimer)
                .with_filter(env_filter.clone())
                .boxed(),
        );
    }

    let subscriber = tracing_subscriber::registry().with(layers);

    if let Err(e) = tracing::subscriber::set_global_default(subscriber) {
        eprintln!("⚠️ 日志已初始化，跳过: {e}");
        let (_nb, g) = tracing_appender::non_blocking(std::io::sink());
        return LogGuard { _guard: g };
    }

    tracing::info!(
        "日志系统已启动 | 级别: {} | 目录: {:?} | 模式: {}",
        cfg.level,
        dir,
        if cfg.output == "file" { format!("控制台 + 文件({prefix}.log)") } else { "仅控制台".into() },
    );
    LogGuard { _guard: guard }
}
