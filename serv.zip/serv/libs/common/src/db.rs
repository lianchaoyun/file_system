//! MySQL 连接池
//!
//! 使用：
//!   common::db::init().await?;   // main 开头调用一次
//!   let pool = common::db::get_pool();  // 任意地方获取

use once_cell::sync::OnceCell;
use sqlx::mysql::MySqlPoolOptions;

static POOL: OnceCell<sqlx::Pool<sqlx::MySql>> = OnceCell::new();

/// 从配置构建 MySQL 连接 URL
fn build_url(cfg: &crate::config::DatabaseConfig) -> String {
    format!(
        "mysql://{}:{}@{}:{}/{}",
        cfg.username, cfg.password, cfg.host, cfg.port, cfg.database,
    )
}

/// 初始化连接池（main 中必须先调用）
pub async fn init() -> sqlx::Result<()> {
    let cfg = crate::config::AppConfig::get().database;
    let url = build_url(&cfg);

    let pool = MySqlPoolOptions::new()
        .max_connections(10)
        .connect(&url)
        .await?;

    POOL.set(pool).expect("连接池已被初始化");
    tracing::info!("✅ MySQL 连接池已初始化: {}:{}", cfg.host, cfg.port);
    Ok(())
}

/// 获取全局连接池（必须先调用 init）
pub fn get_pool() -> &'static sqlx::Pool<sqlx::MySql> {
    POOL.get().expect("数据库连接池未初始化，请先调用 db::init()")
}

/// 关闭连接池（优雅退出时调用）
pub async fn close() {
    if let Some(pool) = POOL.get() {
        pool.close().await;
        tracing::info!("🔌 MySQL 连接池已关闭");
    }
}
