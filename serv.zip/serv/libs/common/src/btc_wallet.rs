// common/src/btc_wallet.rs
use std::collections::HashSet;
use std::time::Instant;
use bitcoin::{
    secp256k1::{Secp256k1, SecretKey},
    key::CompressedPublicKey,
    Address, Network, PrivateKey, PublicKey,
};
use rand::Rng;
use sqlx::{FromRow, MySqlPool};


/// 数据库中的地址记录（对应 address 表）
#[derive(Debug, Clone, FromRow)]
pub struct AddressRecord {
    pub id: u64,
    pub address: String,
    pub balance: f64,
    pub address_type: i32,
}

/// 密钥对
#[derive(Debug, Clone)]
pub struct KeyPair {
    pub secret_key: SecretKey,
    pub public_key: PublicKey,
    pub wif: String,
}

/// 生成的地址
#[derive(Debug, Clone)]
pub struct Addresses {
    pub p2pkh: String,
    pub p2wpkh: String,
}

/// BTC 钱包碰撞器
pub struct BtcWallet {
    network: Network,
    secp: Secp256k1<bitcoin::secp256k1::All>,
    address_set: HashSet<String>,
    pool: Option<MySqlPool>,
}

impl BtcWallet {
    /// 创建新实例（不连数据库，用于测试）
    pub fn new(network: Network) -> Self {
        Self {
            network,
            secp: Secp256k1::new(),
            address_set: HashSet::new(),
            pool: None,
        }
    }

    /// 从 address 表加载已知地址
    pub async fn load_from_db(pool: MySqlPool, network: Network) -> sqlx::Result<Self> {
        let rows = sqlx::query_as::<_, AddressRecord>(
            "SELECT id, address, balance, address_type
             FROM address
             WHERE address_type IN (1,2,3) AND balance != -1",
        )
        .fetch_all(&pool)
        .await?;

        let mut address_set = HashSet::with_capacity(rows.len());
        for row in &rows {
            address_set.insert(row.address.clone());
        }

        println!("✅ 已加载 {} 个已知地址", address_set.len());

        Ok(Self {
            network,
            secp: Secp256k1::new(),
            address_set,
            pool: Some(pool),
        })
    }

    /// 生成随机密钥对
    pub fn generate_keypair(&self) -> KeyPair {
        let mut rng = rand::rng();
        let mut key_bytes = [0u8; 32];
        rng.fill_bytes(&mut key_bytes);
        let secret_key = SecretKey::from_slice(&key_bytes)
            .expect("32字节私钥，应在曲线范围内");

        let inner_pubkey = secret_key.public_key(&self.secp);

        let public_key = PublicKey {
            compressed: true,
            inner: inner_pubkey,
        };

        let private_key = PrivateKey {
            compressed: true,
            network: self.network.into(),
            inner: secret_key,
        };

        KeyPair {
            secret_key,
            public_key,
            wif: private_key.to_wif(),
        }
    }

    /// 根据密钥对生成 P2PKH / P2WPKH 地址
    pub fn get_addresses(&self, kp: &KeyPair) -> Addresses {
        let p2pkh = Address::p2pkh(&kp.public_key, self.network).to_string();

        let compressed_pubkey = CompressedPublicKey::from_private_key(
            &self.secp,
            &PrivateKey {
                compressed: true,
                network: self.network.into(),
                inner: kp.secret_key,
            },
        )
        .expect("压缩公钥生成失败");

        let p2wpkh = Address::p2wpkh(&compressed_pubkey, self.network).to_string();

        Addresses { p2pkh, p2wpkh }
    }

    /// 碰撞检测
    pub fn check_collision(&self, addr: &Addresses) -> bool {
        self.address_set.contains(&addr.p2pkh) || self.address_set.contains(&addr.p2wpkh)
    }

    /// 单次碰撞尝试
    pub fn try_once(&self) -> Option<(KeyPair, Addresses)> {
        let kp = self.generate_keypair();
        let addr = self.get_addresses(&kp);
        if self.check_collision(&addr) {
            Some((kp, addr))
        } else {
            None
        }
    }

    /// 批量碰撞，返回碰撞成功的 (WIF, 地址) 列表
    pub async fn run(&self, times: u64) -> Vec<(String, Addresses)> {
        let start = Instant::now();
        let mut hits = Vec::new();

        for i in 0..times {
            if let Some((kp, addr)) = self.try_once() {
                println!(
                    "💥 碰撞成功! P2PKH={} P2WPKH={} WIF={}",
                    addr.p2pkh, addr.p2wpkh, kp.wif
                );

                // 存入 rawdata 表（raw_key 字段）
                if let Some(pool) = &self.pool {
                    let _ = sqlx::query("INSERT INTO rawdata (raw_key) VALUES (?)")
                        .bind(&kp.wif)
                        .execute(pool)
                        .await;
                }

                hits.push((kp.wif, addr));
            }

            if i % 100_000 == 0 && i > 0 {
                let elapsed = start.elapsed();
                println!(
                    "进度: {}/{} 耗时 {:?} 速率: {:.0}/s",
                    i,
                    times,
                    elapsed,
                    i as f64 / elapsed.as_secs_f64()
                );
            }
        }

        let duration = start.elapsed();
        println!(
            "✅ 完成: {} 次，碰撞 {} 次，速率: {:.0}/s",
            times,
            hits.len(),
            times as f64 / duration.as_secs_f64()
        );

        hits
    }
}
