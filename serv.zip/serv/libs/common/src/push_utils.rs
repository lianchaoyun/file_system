// common/src/push_utils.rs
// 消息推送工具 — 支持 Telegram / 企业微信 Webhook
//
// 对标 ai/src/common/push_utils.py

use std::sync::OnceLock;
use std::time::Duration;

use crate::config::AppConfig;

// ==================== 推送渠道 ====================

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Channel {
    Telegram,
    WeChat,
}

// ==================== 统一推送器 ====================

/// 通知推送器（统一入口，对标 Python `NotificationPusher`）
pub struct NotificationPusher {
    client: reqwest::Client,
    channel: Channel,
    /// TG: bot_token  /  WX: （未使用）
    token: String,
    /// TG: chat_id   /  WX: webhook key
    target: String,
    /// 是否启用
    enabled: bool,
}

impl NotificationPusher {
    // -------- 构造 --------

    /// 从配置文件 [telegram] 段读取参数创建
    pub fn from_config() -> Self {
        let cfg = AppConfig::get();
        let tg = &cfg.telegram;
        Self {
            client: reqwest::Client::new(),
            channel: Channel::Telegram,
            token: tg.bot_token.clone(),
            target: tg.chat_id.clone(),
            enabled: tg.enabled,
        }
    }

    /// 新建 Telegram 推送器
    pub fn new_telegram(bot_token: &str, chat_id: &str) -> Self {
        Self {
            client: reqwest::Client::new(),
            channel: Channel::Telegram,
            token: bot_token.to_string(),
            target: chat_id.to_string(),
            enabled: !bot_token.is_empty() && !chat_id.is_empty(),
        }
    }

    /// 新建企业微信推送器
    pub fn new_wechat(key: &str) -> Self {
        Self {
            client: reqwest::Client::new(),
            channel: Channel::WeChat,
            token: String::new(),
            target: key.to_string(),
            enabled: !key.is_empty(),
        }
    }

    // -------- 状态控制 --------

    pub fn set_enabled(&mut self, enabled: bool) {
        self.enabled = enabled;
    }

    pub fn is_enabled(&self) -> bool {
        self.enabled
    }

    // -------- 核心发送 --------

    /// 发送文本消息
    pub async fn send_text(&self, text: &str) -> bool {
        if !self.enabled || text.is_empty() {
            return false;
        }
        match self.channel {
            Channel::Telegram => self.send_tg_text(text).await,
            Channel::WeChat => self.send_wx_text(text).await,
        }
    }

    /// 发送通知（带标题和时间戳，对标 Python `notify()`）
    pub async fn notify(&self, content: &str, title: &str) -> bool {
        use chrono::Local;
        let ts = Local::now().format("%H:%M:%S");
        let msg = format!("<b>{title}</b>\n\n{content}\n\n<b>Time:</b> {ts}");
        self.send_text(&msg).await
    }

    // -------- Telegram ----------

    async fn send_tg_text(&self, text: &str) -> bool {
        let url = format!("https://api.telegram.org/bot{}/sendMessage", self.token);
        match self
            .client
            .post(&url)
            .json(&serde_json::json!({
                "chat_id": &self.target,
                "text": text,
                "parse_mode": "HTML",
            }))
            .timeout(Duration::from_secs(10))
            .send()
            .await
        {
            Ok(resp) => {
                if resp.status().is_success() {
                    tracing::info!("📤 TG 发送成功");
                    true
                } else {
                    tracing::warn!("📤 TG 发送失败: {}", resp.status());
                    false
                }
            }
            Err(e) => {
                tracing::warn!("📤 TG 请求失败: {e}");
                false
            }
        }
    }

    // -------- 企业微信 --------

    async fn send_wx_text(&self, text: &str) -> bool {
        let url = format!(
            "https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key={}",
            self.target
        );
        match self
            .client
            .post(&url)
            .header("Content-Type", "application/json")
            .json(&serde_json::json!({
                "msgtype": "text",
                "text": { "content": text },
            }))
            .timeout(Duration::from_secs(10))
            .send()
            .await
        {
            Ok(resp) => {
                if let Ok(body) = resp.json::<serde_json::Value>().await {
                    body.get("errcode").and_then(|v| v.as_i64()) == Some(0)
                } else {
                    false
                }
            }
            Err(e) => {
                tracing::warn!("📤 微信推送失败: {e}");
                false
            }
        }
    }
}

// ==================== 默认推送器（惰性单例） ====================

static DEFAULT: OnceLock<NotificationPusher> = OnceLock::new();

/// 获取默认推送器（从配置文件 [telegram] 段创建，惰性初始化，对标 Python `get_pusher()`）
pub fn get_pusher() -> &'static NotificationPusher {
    DEFAULT.get_or_init(NotificationPusher::from_config)
}
