// ==========================================
// 配置模块 — 基于 config crate + TOML
// 加载顺序: default.toml → local.toml（覆盖）→ 环境变量(APP_*)
// ==========================================

use config::{Config as ConfigBuilder, ConfigError, File, Environment};
use once_cell::sync::Lazy;
use serde::Deserialize;
use std::sync::RwLock;

// ==========================================
// 结构体定义 — 与 default.toml 一一对应
// ==========================================

/// 顶层配置
#[derive(Debug, Deserialize, Clone)]
pub struct AppConfig {
    pub server: ServerConfig,
    pub market_data: MarketDataConfig,
    pub log: LogConfig,
    pub database: DatabaseConfig,
    pub redis: RedisConfig,
    pub plugin: PluginConfig,
    /// Telegram 通知配置
    #[serde(default)]
    pub telegram: TelegramConfig,
    /// 东方财富终端程序路径
    #[serde(default)]
    pub dfcf_path: String,
    /// 通达信数据目录
    #[serde(default)]
    pub tdx_path: String,
    /// 通达信 gbbq 解密脚本路径
    #[serde(default)]
    pub decrypt_script: String,
    /// 通达信 gbbq 解密后的 JSON 文件路径
    #[serde(default)]
    pub decrypt_json: String,
}

/// [server]
#[derive(Debug, Deserialize, Clone)]
pub struct ServerConfig {
    pub host: String,
    pub port: u16,
    /// 静态文件目录（绝对路径或相对项目根目录）
    #[serde(default)]
    pub static_dir: String,
}

/// [market_data]
#[derive(Debug, Deserialize, Clone)]
pub struct MarketDataConfig {
    pub port: u16,
}

/// [log]
#[derive(Debug, Deserialize, Clone)]
pub struct LogConfig {
    pub level: String,
    pub output: String,
    /// output = "file" 时生效
    pub file_path: String,
}

/// [database]
#[derive(Debug, Deserialize, Clone)]
pub struct DatabaseConfig {
    pub host: String,
    pub port: u16,
    pub username: String,
    pub password: String,
    pub database: String,
}

/// [redis]
#[derive(Debug, Deserialize, Clone)]
pub struct RedisConfig {
    pub url: String,
    pub password: String,
}

/// [plugin] — 插件配置（含开关 + 列表）
#[derive(Debug, Deserialize, Clone)]
pub struct PluginConfig {
    /// 是否自动加载插件
    #[serde(default = "default_enabled")]
    pub enabled: bool,
    /// 插件列表
    #[serde(default)]
    pub plugins: Vec<PluginEntry>,
}

fn default_enabled() -> bool { true }

/// [[plugin.plugins]] 的每一项
#[derive(Debug, Deserialize, Clone)]
pub struct PluginEntry {
    /// 插件路径（相对于项目根目录）
    pub path: String,
    /// 插件类型: "dyn" | "wasm"
    pub r#type: String,
}

/// [telegram] — 碰撞成功时的 TG 通知
#[derive(Debug, Deserialize, Clone, Default)]
pub struct TelegramConfig {
    /// Bot Token（从 @BotFather 获取）
    #[serde(default)]
    pub bot_token: String,
    /// 目标 Chat ID（可以是个人 ID 或群组 ID）
    #[serde(default)]
    pub chat_id: String,
    /// 是否启用 TG 通知
    #[serde(default)]
    pub enabled: bool,
    /// 每轮碰撞次数
    #[serde(default = "default_round_times")]
    pub round_times: u64,
    /// 每轮间隔休息秒数
    #[serde(default = "default_rest_secs")]
    pub rest_secs: u64,
}

fn default_round_times() -> u64 { 200_000 }
fn default_rest_secs() -> u64 { 10 }

// ==========================================
// 实现
// ==========================================

static CONFIG: Lazy<RwLock<AppConfig>> =
    Lazy::new(|| RwLock::new(AppConfig::load().expect("加载配置文件失败")));

impl AppConfig {
    /// 加载配置：default.toml → local.toml → 环境变量(APP_*)
    fn load() -> Result<Self, ConfigError> {
        let project_root = Self::project_root();

        let cfg = ConfigBuilder::builder()
            // 1. 默认配置（提交到版本控制）
            .add_source(File::with_name(
                project_root.join("data/config/default.toml").to_str().unwrap(),
            ))
            // 2. 本地覆盖（不提交，可选）
            .add_source(
                File::with_name(
                    project_root.join("data/config/local.toml").to_str().unwrap(),
                )
                .required(false),
            )
            // 3. 环境变量覆盖（格式 APP_SERVER_PORT=9090）
            .add_source(
                Environment::with_prefix("APP")
                    .separator("_")
                    .prefix_separator("_"),
            )
            .build()?;

        cfg.try_deserialize()
    }

    /// 获取全局配置的克隆
    pub fn get() -> AppConfig {
        CONFIG.read().unwrap().clone()
    }

    /// 初始化（可在 main 开头调用，提前捕获错误）
    pub fn init() -> Result<(), ConfigError> {
        let cfg = Self::load()?;
        let mut w = CONFIG.write().unwrap();
        *w = cfg;
        Ok(())
    }

    /// 初始化并打印配置摘要
    pub fn init_with_summary() -> Result<(), ConfigError> {
        let cfg = Self::load()?;

        println!("---------- 配置加载 ----------");
        println!("服务地址:  {}:{}", cfg.server.host, cfg.server.port);
        println!("行情端口:  {}", cfg.market_data.port);
        println!("日志级别:  {}", cfg.log.level);
        println!("日志输出:  {}", cfg.log.output);
        if cfg.log.output == "file" {
            println!("日志路径:  {}", cfg.log.file_path);
        }
        println!(
            "数据库:    {}:{}@{}/{}",
            cfg.database.host,
            cfg.database.port,
            cfg.database.username,
            cfg.database.database,
        );
        println!("Redis:     {}", cfg.redis.url);
        for p in &cfg.plugin.plugins {
            println!("插件[{}]: {}", p.r#type, p.path);
        }
        println!("------------------------------\n");

        let mut w = CONFIG.write().unwrap();
        *w = cfg;
        Ok(())
    }

    /// 项目根目录（从 common crate 的 MANIFEST_DIR 往上两级到 workspace 根）
    pub fn project_root() -> std::path::PathBuf {
        std::path::PathBuf::from(env!("CARGO_MANIFEST_DIR"))
            .parent()
            .unwrap() // libs/
            .parent()
            .unwrap() // serv/ (workspace root)
            .to_path_buf()
    }

    /// 返回所有插件的绝对路径列表 (path, type)
    pub fn plugin_entries() -> Vec<(std::path::PathBuf, String)> {
        let root = Self::project_root();
        let cfg = Self::get();
        cfg.plugin
            .plugins
            .into_iter()
            .map(|p| (root.join(p.path), p.r#type))
            .collect()
    }
}
