//! Redis 连接池（基于 bb8）
//!
//! 使用：
//!   common::redis_pool::init().await;        // main 开头调用一次
//!   let pool = common::redis_pool::get_pool(); // 获取连接池
//!   let mut conn = pool.get().await?;          // 从池中取连接

use bb8_redis::{bb8, RedisConnectionManager};
use once_cell::sync::OnceCell;

static POOL: OnceCell<bb8::Pool<RedisConnectionManager>> = OnceCell::new();

/// 从配置构建 Redis URL（拼接密码）
fn build_url(cfg: &crate::config::RedisConfig) -> String {
    if cfg.password.is_empty() {
        cfg.url.clone()
    } else {
        cfg.url.replace("redis://", &format!("redis://:{}@", cfg.password))
    }
}

/// 初始化连接池（main 中必须先调用）
/// 失败时会记录详细错误日志，不会 panic
pub async fn init() {
    let cfg = crate::config::AppConfig::get().redis;

    // 检查是否已初始化
    if POOL.get().is_some() {
        tracing::warn!("Redis 连接池已经初始化，跳过");
        return;
    }

    let url = build_url(&cfg);

    let manager = match RedisConnectionManager::new(url) {
        Ok(m) => m,
        Err(e) => {
            tracing::error!("❌ Redis 连接地址无效: {} | 详情: {}", cfg.url, e);
            return;
        }
    };

    // 带超时的连接池构建（bb8 自带 connection_timeout）
    let pool = match bb8::Pool::builder()
        .max_size(15)
        .connection_timeout(std::time::Duration::from_secs(5))
        .build(manager)
        .await
    {
        Ok(p) => p,
        Err(e) => {
            tracing::error!(
                "❌ Redis 连接池创建失败: {} (host={})",
                e, cfg.url
            );
            return;
        }
    };

    if POOL.set(pool).is_err() {
        tracing::error!("❌ Redis 连接池设置失败（可能重复初始化）");
        return;
    }

    tracing::info!("✅ Redis 连接池已初始化: {}", cfg.url);
}

/// 获取全局连接池（必须先调用 init）
pub fn get_pool() -> &'static bb8::Pool<RedisConnectionManager> {
    POOL.get().expect("Redis 连接池未初始化，请先调用 redis_pool::init()")
}



/// Redis 基础功能测试（SET / GET / DEL）
pub async fn test() -> Result<(), Box<dyn std::error::Error>> {
    use redis::AsyncCommands;

    let pool = match POOL.get() {
        Some(p) => p,
        None => {
            tracing::warn!("Redis 未初始化，跳过测试");
            return Err("Redis 连接池未初始化".into());
        }
    };

    let mut conn = match pool.get().await {
        Ok(c) => c,
        Err(e) => {
            tracing::error!("❌ Redis 获取连接失败: {}", e);
            return Err(e.into());
        }
    };

    // SET
    if let Err(e) = conn.set::<&str, &str, ()>("yun:test:hello", "world").await {
        tracing::error!("❌ Redis SET 失败: {}", e);
        return Err(e.into());
    }

    // GET
    let val: String = match conn.get("yun:test:hello").await {
        Ok(v) => v,
        Err(e) => {
            tracing::error!("❌ Redis GET 失败: {}", e);
            return Err(e.into());
        }
    };
    tracing::info!("Redis SET/GET: yun:test:hello = {}", val);

    // DEL
    let _: () = conn.del("yun:test:hello").await?;

    tracing::info!("✅ Redis test passed");
    Ok(())
}
