//! 统一 HTTP 响应结构体

use serde::Serialize;

/// 统一 API 响应结构
#[derive(Debug, Serialize)]
pub struct ApiResponse<T: Serialize> {
    pub code: i32,
    pub msg: String,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub data: Option<T>,
}

impl<T: Serialize> ApiResponse<T> {
    /// 成功响应（带数据）
    pub fn ok(data: T) -> Self {
        Self {
            code: 0,
            msg: "ok".into(),
            data: Some(data),
        }
    }

    /// 成功响应（无数据）
    pub fn ok_msg(msg: &str) -> Self {
        Self {
            code: 0,
            msg: msg.into(),
            data: None,
        }
    }

    /// 错误响应
    pub fn err(code: i32, msg: &str) -> Self {
        Self {
            code,
            msg: msg.into(),
            data: None,
        }
    }
}

/// 常用错误码常量
pub mod err_code {
    /// 成功
    pub const OK: i32 = 0;
    /// 参数错误
    pub const BAD_REQUEST: i32 = 400;
    /// 未授权
    pub const UNAUTHORIZED: i32 = 401;
    /// 禁止访问
    pub const FORBIDDEN: i32 = 403;
    /// 资源不存在
    pub const NOT_FOUND: i32 = 404;
    /// 服务器内部错误
    pub const INTERNAL_ERROR: i32 = 500;
}
