// ==========================================
// 用户偏好模块 — JSON 动态读写
// 适用于频繁变化的用户状态：主题、当前页面等
// ==========================================

use serde::{Deserialize, Serialize};
use std::path::PathBuf;

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct UserPrefs {
    /// 主题: "light" | "dark"
    pub theme: String,
    /// 当前页面 key，如 "home"、"settings"
    pub current_page: String,
    /// 窗口宽度
    pub window_width: u32,
    /// 窗口高度
    pub window_height: u32,
}

impl Default for UserPrefs {
    fn default() -> Self {
        Self {
            theme: "light".to_string(),
            current_page: "home".to_string(),
            window_width: 1024,
            window_height: 768,
        }
    }
}

impl UserPrefs {
    /// 偏好文件路径：data/user/prefs.json
    fn file_path() -> PathBuf {
        std::env::current_dir()
            .unwrap_or_else(|_| PathBuf::from("."))
            .join("data/user/prefs.json")
    }

    /// 从文件加载，不存在则返回默认值
    pub fn load() -> Self {
        let path = Self::file_path();
        if path.exists() {
            std::fs::read_to_string(&path)
                .ok()
                .and_then(|s| serde_json::from_str(&s).ok())
                .unwrap_or_default()
        } else {
            Self::default()
        }
    }

    /// 保存到文件（自动创建目录）
    pub fn save(&self) -> Result<(), std::io::Error> {
        let path = Self::file_path();
        if let Some(parent) = path.parent() {
            std::fs::create_dir_all(parent)?;
        }
        let json = serde_json::to_string_pretty(self)?;
        std::fs::write(&path, json)
    }
}
