use rdev::{listen, EventType, Key};
use std::collections::HashSet;
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::mpsc::{self, Sender};
use std::sync::{Arc, Mutex, LazyLock, OnceLock};
use std::time::{Duration, Instant};
use std::thread;

static RUNNING: AtomicBool = AtomicBool::new(false);

// 全局按键状态：记录当前按下的所有键
static PRESSED_KEYS: LazyLock<Mutex<HashSet<Key>>> = LazyLock::new(|| Mutex::new(HashSet::new()));

// 组合键回调类型（用 Arc 以便跨线程发送）
type ComboCallback = Arc<dyn Fn() + Send + Sync + 'static>;

// 通道：钩子线程往这里发回调，工作线程负责执行
static CALLBACK_TX: OnceLock<Sender<ComboCallback>> = OnceLock::new();

// 注册的组合键列表：(id, 组合键集合, 回调, 是否已触发)
struct ComboBinding {
    id: String,
    keys: HashSet<Key>,
    callback: ComboCallback,
    triggered: bool,
}

// 全局组合键注册表
static COMBO_REGISTRY: LazyLock<Mutex<Vec<ComboBinding>>> = LazyLock::new(|| Mutex::new(Vec::new()));

/// 单键双击注册：(id, 要监听的键, 双击超时, 上次按下时间, 回调)
struct DoubleClickBinding {
    id: String,
    key: Key,
    timeout: Duration,
    last_press: Option<Instant>,
    callback: ComboCallback,
}

static DOUBLE_CLICK_REGISTRY: LazyLock<Mutex<Vec<DoubleClickBinding>>> =
    LazyLock::new(|| Mutex::new(Vec::new()));

/// 启动键盘监控（非阻塞），在后台线程监听按键
pub fn start() {
    if RUNNING.swap(true, Ordering::SeqCst) {
        tracing::warn!("按键监控已在运行");
        return;
    }

    // 创建通道：钩子线程 -> 工作线程
    let (tx, rx) = mpsc::channel::<ComboCallback>();
    CALLBACK_TX.set(tx).ok();

    // 工作线程：负责执行回调，不阻塞钩子线程
    thread::spawn(move || {
        while RUNNING.load(Ordering::SeqCst) {
            match rx.recv() {
                Ok(cb) => {
                    // 在独立线程中执行回调，不阻塞工作线程处理后续快捷键
                    thread::spawn(move || {
                        let result = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| cb()));
                        if let Err(e) = result {
                            let msg = e.downcast_ref::<String>()
                                .map(|s| s.as_str())
                                .or_else(|| e.downcast_ref::<&str>().copied())
                                .unwrap_or("unknown panic");
                            tracing::error!("快捷键回调 panic: {}", msg);
                        }
                    });
                }
                Err(_) => break,
            }
        }
        tracing::info!("回调工作线程已停止");
    });

    // 钩子线程：负责监听按键，只做轻量处理
    thread::spawn(move || {
        let callback = move |event: rdev::Event| {
            match event.event_type {
                EventType::KeyPress(key) => {
                    // 记录按下的键（归一化修饰键，减少无关的左右键状态）
                    let mut pressed = PRESSED_KEYS.lock().unwrap();
                    pressed.insert(normalize_modifier(key));

                    // 打印按键信息（可选）
                    let name = event.name.as_deref().unwrap_or("?");
                    tracing::debug!("[按键] {:?} -> {}", key, name);

                    // 检查是否匹配任何注册的组合键
                    check_combos(&pressed);

                    // 检查单键双击
                    drop(pressed);
                    check_double_clicks(key);
                }
                EventType::KeyRelease(key) => {
                    // 移除释放的键（同样归一化）
                    let mut pressed = PRESSED_KEYS.lock().unwrap();
                    pressed.remove(&normalize_modifier(key));

                    // 重置所有组合键的触发状态
                    let mut registry = COMBO_REGISTRY.lock().unwrap();
                    for binding in registry.iter_mut() {
                        binding.triggered = false;
                    }
                }
                _ => {}
            }
        };

        if let Err(e) = listen(callback) {
            tracing::error!("按键监控错误: {:?}", e);
        }

        RUNNING.store(false, Ordering::SeqCst);
        tracing::info!("按键监控已停止");
    });
}

/// 停止键盘监控
pub fn stop() {
    RUNNING.store(false, Ordering::SeqCst);
    tracing::info!("已发送停止信号");
}

/// 注册组合键监听
/// 
/// # 示例
/// ```rust
/// // 注册 Ctrl+C
/// register_combo(vec![Key::ControlLeft, Key::KeyC], || {
///     println!("触发了 Ctrl+C");
/// });
/// 
/// // 注册 Ctrl+Alt+Z
/// register_combo(vec![Key::ControlLeft, Key::Alt, Key::KeyZ], || {
///     println!("触发了 Ctrl+Alt+Z");
/// });
/// ```
pub fn register_combo(id: &str, keys: Vec<Key>, callback: ComboCallback) {
    let mut registry = COMBO_REGISTRY.lock().unwrap();
    // 如果已存在相同 id，先移除旧的
    registry.retain(|b| b.id != id);
    let key_set: HashSet<Key> = keys.into_iter().collect();
    registry.push(ComboBinding {
        id: id.to_string(),
        keys: key_set,
        callback,
        triggered: false,
    });
    tracing::info!("注册组合键 [{}]: {:?}", id, registry.last().unwrap().keys);
}

/// 注册组合键（支持左右修饰键）
/// 
/// 这个版本会自动处理左右 Ctrl/Alt/Shift，不需要调用方区分
/// 
/// # 示例
/// ```rust
/// // 注册 Ctrl+C（不区分左右Ctrl）
/// register_combo_flexible(vec![Key::ControlLeft, Key::KeyC], || {
///     println!("触发了 Ctrl+C");
/// });
/// ```
pub fn register_combo_flexible(id: &str, keys: Vec<Key>, callback: ComboCallback) {
    let normalized_keys: Vec<Key> = keys.into_iter().map(normalize_modifier).collect();
    register_combo(id, normalized_keys, callback);
}

/// 检查当前按下的键是否匹配任何注册的组合键
/// 匹配后通过通道异步派发回调，不阻塞钩子线程
fn check_combos(pressed: &HashSet<Key>) {
    let mut registry = COMBO_REGISTRY.lock().unwrap();
    
    for binding in registry.iter_mut() {
        // 检查是否所有需要的键都被按下
        let all_pressed = binding.keys.iter().all(|k| pressed.contains(k));
        
        if all_pressed && !binding.triggered {
            binding.triggered = true;
            // 把回调发给工作线程执行，钩子线程立即返回
            if let Some(tx) = CALLBACK_TX.get() {
                let _ = tx.send(binding.callback.clone());
            }
        }
    }
}

/// 检查单键双击
fn check_double_clicks(key: Key) {
    let mut registry = DOUBLE_CLICK_REGISTRY.lock().unwrap();
    let now = Instant::now();

    for binding in registry.iter_mut() {
        if normalize_modifier(key) == binding.key {
            match binding.last_press {
                Some(last) => {
                    let elapsed = now.duration_since(last);
                    if elapsed < binding.timeout {
                        // 双击成功！重置状态，派发回调
                        binding.last_press = None;
                        if let Some(tx) = CALLBACK_TX.get() {
                            let _ = tx.send(binding.callback.clone());
                        }
                        tracing::debug!("双击触发: {:?}", binding.key);
                    } else {
                        // 超时，重新开始计时
                        binding.last_press = Some(now);
                    }
                }
                None => {
                    // 第一次按下，记录时间
                    binding.last_press = Some(now);
                }
            }
        }
    }
}

/// 注册单键双击监听
///
/// # 示例
/// ```rust
/// // 双击 Alt 键触发（300ms 内）
/// register_key_double_click(Key::Alt, 300, || {
///     println!("双击了 Alt 键");
/// });
/// ```
pub fn register_key_double_click(id: &str, key: Key, timeout_ms: u64, callback: ComboCallback) {
    let mut registry = DOUBLE_CLICK_REGISTRY.lock().unwrap();
    // 如果已存在相同 id，先移除旧的
    registry.retain(|b| b.id != id);
    let normalized_key = normalize_modifier(key);
    registry.push(DoubleClickBinding {
        id: id.to_string(),
        key: normalized_key,
        timeout: Duration::from_millis(timeout_ms),
        last_press: None,
        callback,
    });
    tracing::info!("注册双击 [{}]: {:?} ({}ms)", id, normalized_key, timeout_ms);
}

/// 标准化修饰键（将左右修饰键统一）
fn normalize_modifier(key: Key) -> Key {
    match key {
        Key::ControlLeft | Key::ControlRight => Key::ControlLeft,
        Key::Alt | Key::AltGr => Key::Alt,
        Key::ShiftLeft | Key::ShiftRight => Key::ShiftLeft,
        Key::MetaLeft | Key::MetaRight => Key::MetaLeft,
        _ => key,
    }
}

/// 获取当前按下的所有键（只读）
pub fn get_pressed_keys() -> HashSet<Key> {
    let pressed = PRESSED_KEYS.lock().unwrap();
    pressed.clone()
}

/// 清除所有注册的组合键和双击
pub fn clear_combos() {
    let mut registry = COMBO_REGISTRY.lock().unwrap();
    registry.clear();
    let mut dc_registry = DOUBLE_CLICK_REGISTRY.lock().unwrap();
    dc_registry.clear();
    tracing::info!("已清除所有组合键和双击注册");
}

/// 按 id 注销注册项（组合键 + 双击都清除）
pub fn unregister(id: &str) {
    let mut registry = COMBO_REGISTRY.lock().unwrap();
    registry.retain(|b| b.id != id);

    let mut dc_registry = DOUBLE_CLICK_REGISTRY.lock().unwrap();
    dc_registry.retain(|b| b.id != id);

    tracing::info!("已注销快捷键: {}", id);
}
