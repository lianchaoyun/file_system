use windows::Win32::UI::WindowsAndMessaging::*;
use windows::Win32::UI::Input::KeyboardAndMouse::*;
use windows::Win32::System::Threading::GetCurrentThreadId;
use std::thread;
use std::time::Duration;

// windows 0.62 没有 AttachThreadInput 绑定，直接用 FFI
unsafe extern "system" {
    fn AttachThreadInput(idAttach: u32, idAttachTo: u32, fAttach: i32) -> i32;
}


/// 打开东方财富终端并输入股票代码
/// 使用 AttachThreadInput 绕过 Windows 前台窗口限制
pub fn open_in_dc(stock_code: &str) {
    use crate::config::AppConfig;

    let config = AppConfig::get();

    // 尝试多个可能的窗口标题
    let titles = ["东方财富终端", "东方财富", "eastmoney"];
    let mut hwnd = None;

    for title in &titles {
        let title_wide: Vec<u16> = format!("{}\0", title).encode_utf16().collect();
        let title_pcwstr = windows::core::PCWSTR(title_wide.as_ptr());
        let result = unsafe {
            FindWindowW(None, Some(&title_pcwstr))
        };
        if let Ok(h) = result {
            if !h.is_invalid() {
                hwnd = Some(h);
                break;
            }
        }
    }

    if hwnd.is_none() {
        // 没找到窗口，尝试启动程序
        if !config.dfcf_path.is_empty() {
            std::process::Command::new("cmd")
                .args(["/C", "start", "", &config.dfcf_path])
                .spawn()
                .ok();
        }
        thread::sleep(Duration::from_secs(5));

        // 再次尝试查找窗口
        for title in &titles {
            let title_wide: Vec<u16> = format!("{}\0", title).encode_utf16().collect();
            let title_pcwstr = windows::core::PCWSTR(title_wide.as_ptr());
            let result = unsafe {
                FindWindowW(None, Some(&title_pcwstr))
            };
            if let Ok(h) = result {
                if !h.is_invalid() {
                    hwnd = Some(h);
                    break;
                }
            }
        }
    }

    if let Some(hwnd) = hwnd {
        // 使用 AttachThreadInput 绕过 Windows 前台窗口限制
        unsafe {
            let mut target_process_id: u32 = 0;
            let target_thread_id = GetWindowThreadProcessId(hwnd, Some(&mut target_process_id));
            let current_thread_id = GetCurrentThreadId();

            // 附加当前线程到目标窗口的线程
            let _ = AttachThreadInput(current_thread_id, target_thread_id, 1);

            // 激活窗口但不改变最大化/最小化状态
            let _ = ShowWindow(hwnd, SW_SHOW);
            let _ = SetForegroundWindow(hwnd);

            // 取消附加
            let _ = AttachThreadInput(current_thread_id, target_thread_id, 0);
        }

        thread::sleep(Duration::from_millis(300));

        // 模拟键盘输入股票代码
        for c in stock_code.chars() {
            if let Some(vk) = char_to_vk(c) {
                unsafe {
                    keybd_event(vk, 0, Default::default(), 0);
                    keybd_event(vk, 0, KEYEVENTF_KEYUP, 0);
                }
            }
            thread::sleep(Duration::from_millis(50));
        }

        // 按回车
        unsafe {
            keybd_event(0x0D, 0, Default::default(), 0);
            keybd_event(0x0D, 0, KEYEVENTF_KEYUP, 0);
        }
    }
}

fn char_to_vk(c: char) -> Option<u8> {
    Some(match c {
        '0' => 0x30, '1' => 0x31, '2' => 0x32, '3' => 0x33, '4' => 0x34,
        '5' => 0x35, '6' => 0x36, '7' => 0x37, '8' => 0x38, '9' => 0x39,
        'A' | 'a' => 0x41, 'B' | 'b' => 0x42, 'C' | 'c' => 0x43, 'D' | 'd' => 0x44,
        'E' | 'e' => 0x45, 'F' | 'f' => 0x46, 'G' | 'g' => 0x47, 'H' | 'h' => 0x48,
        'I' | 'i' => 0x49, 'J' | 'j' => 0x4A, 'K' | 'k' => 0x4B, 'L' | 'l' => 0x4C,
        'M' | 'm' => 0x4D, 'N' | 'n' => 0x4E, 'O' | 'o' => 0x4F, 'P' | 'p' => 0x50,
        'Q' | 'q' => 0x51, 'R' | 'r' => 0x52, 'S' | 's' => 0x53, 'T' | 't' => 0x54,
        'U' | 'u' => 0x55, 'V' | 'v' => 0x56, 'W' | 'w' => 0x57, 'X' | 'x' => 0x58,
        'Y' | 'y' => 0x59, 'Z' | 'z' => 0x5A,
        '.' => 0xBE,
        _ => return None,
    })
}


