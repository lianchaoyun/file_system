// ==========================================
// shared — 主程序和插件之间的共享契约
// 主程序依赖此 crate 来了解插件接口
// 插件依赖此 crate 来实现相同的类型
// ==========================================

use serde::{Deserialize, Serialize};

// ==========================================
// 1. 插件元数据
// ==========================================
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PluginMeta {
    /// 插件名称
    pub name: String,
    /// 版本号
    pub version: String,
    /// 作者
    pub author: String,
    /// 描述
    pub description: String,
    /// 插件类型
    pub plugin_type: PluginType,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum PluginType {
    Wasm,
    Dyn,
}

// ==========================================
// 2. 插件输入 / 输出（通用数据结构）
// ==========================================
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PluginInput {
    /// 命令名称
    pub command: String,
    /// 输入数据（JSON）
    pub data: serde_json::Value,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PluginOutput {
    /// 是否成功
    pub success: bool,
    /// 输出数据（JSON）
    pub data: serde_json::Value,
    /// 错误信息
    pub error: Option<String>,
}

// ==========================================
// 3. 插件标准接口定义（C ABI 函数签名）
// ==========================================

/// 统一执行入口：接收 JSON 格式的 PluginInput，返回 JSON 格式的 PluginOutput
///
/// # 参数
/// - `input_ptr` : 指向输入 JSON 字节的指针
/// - `input_len` : 输入 JSON 的字节长度
/// - `output_len`: 输出参数，调用后写入输出 JSON 的字节长度
///
/// # 返回
/// 指向输出 JSON 字节的指针（由调用方通过 `free_string` 释放）
///
/// # 安全
/// 此函数通过 C FFI 调用，调用方必须保证输入指针有效
pub type ExecuteFunc = unsafe extern "C" fn(
    input_ptr: *const u8,
    input_len: u32,
    output_len: *mut u32,
) -> *mut u8;

/// 释放由 `execute` 返回的字符串缓冲区
///
/// # 参数
/// - `ptr`: 要释放的指针
/// - `len`: 缓冲区长度
pub type FreeStringFunc = unsafe extern "C" fn(ptr: *mut u8, len: u32);

/// 获取插件元数据（返回 JSON 格式的 PluginMeta）
///
/// # 返回
/// 指向 JSON 字节的指针（由调用方通过 `free_string` 释放）
pub type GetMetaFunc = unsafe extern "C" fn() -> *mut u8;

// ==========================================
// 4. 错误类型
// ==========================================
#[derive(Debug)]
pub enum PluginError {
    NotFound(String),
    AlreadyLoaded(String),
    LoadFailed(String),
    ExecutionFailed(String),
    UnsupportedType(String),
    InvalidFormat(String),
}

impl std::fmt::Display for PluginError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            PluginError::NotFound(name) => write!(f, "插件未找到: {}", name),
            PluginError::AlreadyLoaded(name) => write!(f, "插件已加载: {}", name),
            PluginError::LoadFailed(msg) => write!(f, "加载失败: {}", msg),
            PluginError::ExecutionFailed(msg) => write!(f, "执行失败: {}", msg),
            PluginError::UnsupportedType(t) => write!(f, "不支持的插件类型: {}", t),
            PluginError::InvalidFormat(msg) => write!(f, "格式无效: {}", msg),
        }
    }
}

impl std::error::Error for PluginError {}

// ==========================================
// 5. 插件发现信息
// ==========================================
#[derive(Debug, Clone)]
pub struct PluginInfo {
    pub name: String,
    pub plugin_type: PluginType,
    pub path: std::path::PathBuf,
}
