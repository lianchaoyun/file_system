use std::alloc::{alloc, dealloc, Layout};
use shared::{PluginInput, PluginOutput};

/// WASM 内存分配（供宿主通过 wasmtime 调用）
/// 注意：不能命名为 malloc/free，因为 wasm32-wasip1 的 dlmalloc 已经导出了这些符号
#[unsafe(no_mangle)]
pub extern "C" fn wasm_alloc(size: i32) -> i32 {
    let layout = match Layout::array::<u8>(size as usize) {
        Ok(l) => l,
        Err(_) => return 0,
    };
    let ptr = unsafe { alloc(layout) };
    ptr as i32
}

/// WASM 内存释放（带长度，与 dlmalloc 的 free(ptr) 不同）
#[unsafe(no_mangle)]
pub extern "C" fn wasm_dealloc(ptr: i32, size: i32) {
    if ptr != 0 && size > 0 {
        let layout = match Layout::array::<u8>(size as usize) {
            Ok(l) => l,
            Err(_) => return,
        };
        unsafe { dealloc(ptr as *mut u8, layout); }
    }
}

/// 统一执行入口（WASM 版本）
///
/// # 参数
/// - `input_ptr` : 输入数据在 WASM 线性内存中的偏移
/// - `input_len` : 输入数据的字节长度
///
/// # 返回
/// - 打包的 i64：低 32 位 = output_ptr，高 32 位 = output_len
///   宿主体读取后需调用 `free(output_ptr, output_len)` 释放
#[unsafe(no_mangle)]
pub extern "C" fn execute(input_ptr: i32, input_len: i32) -> i64 {
    // 1. 读取输入
    let input_bytes = unsafe {
        std::slice::from_raw_parts(input_ptr as *const u8, input_len as usize)
    };

    // 2. 反序列化
    let input: PluginInput = match serde_json::from_slice(input_bytes) {
        Ok(v) => v,
        Err(e) => {
            return pack_error(&format!("解析输入失败: {}", e));
        }
    };

    // 3. 命令分发
    let output = dispatch(&input);

    // 4. 打包输出
    pack_output(&output)
}

fn dispatch(input: &PluginInput) -> PluginOutput {
    match input.command.as_str() {
        "add" => {
            match serde_json::from_value::<(i32, i32)>(input.data.clone()) {
                Ok((a, b)) => PluginOutput {
                    success: true,
                    data: serde_json::json!(a + b),
                    error: None,
                },
                Err(e) => PluginOutput {
                    success: false,
                    data: serde_json::Value::Null,
                    error: Some(format!("add 参数错误: {}", e)),
                },
            }
        }
        "process" => {
            match serde_json::from_value::<i32>(input.data.clone()) {
                Ok(val) => PluginOutput {
                    success: true,
                    data: serde_json::json!(val * val + 1),
                    error: None,
                },
                Err(e) => PluginOutput {
                    success: false,
                    data: serde_json::Value::Null,
                    error: Some(format!("process 参数错误: {}", e)),
                },
            }
        }
        _ => PluginOutput {
            success: false,
            data: serde_json::Value::Null,
            error: Some(format!("未知命令: {}", input.command)),
        },
    }
}

fn pack_output(output: &PluginOutput) -> i64 {
    let json = match serde_json::to_vec(output) {
        Ok(v) => v,
        Err(e) => {
            let fallback = PluginOutput {
                success: false,
                data: serde_json::Value::Null,
                error: Some(format!("序列化输出失败: {}", e)),
            };
            serde_json::to_vec(&fallback).unwrap_or_default()
        }
    };

    if json.is_empty() {
        return 0;
    }

    // 在 WASM 堆上分配，宿主体负责调用 free 释放
    let layout = match Layout::array::<u8>(json.len()) {
        Ok(l) => l,
        Err(_) => return 0,
    };
    let ptr = unsafe { alloc(layout) };
    if ptr.is_null() {
        return 0;
    }

    unsafe {
        std::ptr::copy_nonoverlapping(json.as_ptr(), ptr, json.len());
    }

    let out_ptr = ptr as i32;
    let out_len = json.len() as i32;
    (((out_len as u32 as u64) << 32) | (out_ptr as u32 as u64)) as i64
}

fn pack_error(msg: &str) -> i64 {
    let output = PluginOutput {
        success: false,
        data: serde_json::Value::Null,
        error: Some(msg.to_string()),
    };
    pack_output(&output)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_add_via_dispatch() {
        let input = PluginInput {
            command: "add".into(),
            data: serde_json::json!([2, 3]),
        };
        let output = dispatch(&input);
        assert!(output.success);
        assert_eq!(output.data, serde_json::json!(5));
    }

    #[test]
    fn test_process_via_dispatch() {
        let input = PluginInput {
            command: "process".into(),
            data: serde_json::json!(5),
        };
        let output = dispatch(&input);
        assert!(output.success);
        assert_eq!(output.data, serde_json::json!(26));
    }

    #[test]
    fn test_unknown_command() {
        let input = PluginInput {
            command: "unknown".into(),
            data: serde_json::json!(42),
        };
        let output = dispatch(&input);
        assert!(!output.success);
        assert!(output.error.unwrap().contains("未知命令"));
    }
}
