/// 独立运行：直接调用插件逻辑（rlib 链接）

unsafe extern "Rust" {
    fn execute(input_ptr: i32, input_len: i32) -> (i32, i32);
    fn malloc(size: i32) -> i32;
    fn free(ptr: i32, size: i32);
}

fn main() {
    // test add: {"command":"add","data":[2,3]}
    let input = r#"{"command":"add","data":[2,3]}"#;
    let input_bytes = input.as_bytes();
    let input_len = input_bytes.len() as i32;

    let input_ptr = unsafe { malloc(input_len) };
    unsafe {
        std::ptr::copy_nonoverlapping(input_bytes.as_ptr(), input_ptr as *mut u8, input_bytes.len());
    }

    let (output_ptr, output_len) = unsafe { execute(input_ptr, input_len) };
    let output_bytes = unsafe { std::slice::from_raw_parts(output_ptr as *const u8, output_len as usize) };
    let output: serde_json::Value = serde_json::from_slice(output_bytes).unwrap();
    println!("add(2, 3) = {}", output["data"]);
    unsafe { free(input_ptr, input_len); }
    unsafe { free(output_ptr, output_len); }

    // test process: {"command":"process","data":5}
    let input = r#"{"command":"process","data":5}"#;
    let input_bytes = input.as_bytes();
    let input_len = input_bytes.len() as i32;

    let input_ptr = unsafe { malloc(input_len) };
    unsafe {
        std::ptr::copy_nonoverlapping(input_bytes.as_ptr(), input_ptr as *mut u8, input_bytes.len());
    }

    let (output_ptr, output_len) = unsafe { execute(input_ptr, input_len) };
    let output_bytes = unsafe { std::slice::from_raw_parts(output_ptr as *const u8, output_len as usize) };
    let output: serde_json::Value = serde_json::from_slice(output_bytes).unwrap();
    println!("process(5) = {}", output["data"]);
    unsafe { free(input_ptr, input_len); }
    unsafe { free(output_ptr, output_len); }
}
