//! MarketEvent → WS 客户端 JSON 序列化

use crate::types::MarketEvent;

/// 将 MarketEvent 转为 WS 客户端 JSON 格式
pub fn market_event_to_json(event: &MarketEvent) -> serde_json::Value {
    match event {
        MarketEvent::Kline(ke) => serde_json::json!({
            "type": "kline",
            "symbol": ke.symbol,
            "interval": ke.interval,
            "data": {
                "time": ke.kline.time,
                "open": ke.kline.open,
                "high": ke.kline.high,
                "low": ke.kline.low,
                "close": ke.kline.close,
                "volume": ke.kline.volume,
            }
        }),
        MarketEvent::Tick(te) => serde_json::json!({
            "type": "tick",
            "symbol": te.symbol,
            "data": {
                "time": te.tick.time,
                "price": te.tick.price,
                "volume": te.tick.volume,
                "bid": te.tick.bid,
                "ask": te.tick.ask,
            }
        }),
    }
}
