//! WS 协议层：命令处理 + 消息转发 + JSON 序列化

mod message;
mod protocol;

pub use message::market_event_to_json;
pub use protocol::handle_connection;
