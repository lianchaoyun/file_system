//! WS 协议层：命令解析 + 消息转发

use std::collections::HashMap;
use std::net::SocketAddr;
use std::sync::Arc;
use std::time::Duration;

use futures::{SinkExt, StreamExt};
use serde_json::Value;
use tokio::net::TcpStream;
use tokio::sync::Mutex;
use tokio_tungstenite::accept_async;
use tokio_tungstenite::tungstenite::Message;

use crate::manager::MarketDataManager;
use crate::types::{Market, MarketEvent};

use super::message::market_event_to_json;

use common::{log, wrn, dbg};

/// 处理单个 WS 连接：接收命令 → 管理订阅 → 转发事件
pub async fn handle_connection(
    stream: TcpStream,
    manager: Arc<MarketDataManager>,
    conn_subs: Arc<Mutex<HashMap<u64, Vec<String>>>>,
    conn_id: u64,
    peer: SocketAddr,
) -> Result<(), Box<dyn std::error::Error>> {
    let ws = accept_async(stream).await?;
    let (mut write, mut read) = ws.split();

    log!("📥 客户端连接: #{conn_id} {peer}");

    // ── 启动 WS 读取任务：解析命令 → channel ──
    let (cmd_tx, mut cmd_rx) = tokio::sync::mpsc::unbounded_channel::<(String, Value)>();

    let _read_handle = {
        let mgr = Arc::clone(&manager);
        let subs = Arc::clone(&conn_subs);
        tokio::spawn(async move {
            while let Some(Ok(msg)) = read.next().await {
                match msg {
                    Message::Text(text) => {
                        match serde_json::from_str::<Value>(&text) {
                            Ok(v) => {
                                let cmd = v["cmd"].as_str().unwrap_or("").to_string();
                                let _ = cmd_tx.send((cmd, v));
                            }
                            Err(e) => wrn!("JSON 解析失败 #{conn_id}: {e}"),
                        }
                    }
                    Message::Close(_) => break,
                    _ => {}
                }
            }
            // 断开清理订阅
            let to_unsub = subs.lock().await.remove(&conn_id).unwrap_or_default();
            if !to_unsub.is_empty() {
                log!("客户端断开 #{conn_id}，清理 {} 个订阅", to_unsub.len());
                mgr.unsubscribe(&to_unsub).await;
            }
        })
    };

    // ── 主循环：轮询 receiver → 转发 + 处理命令 ──
    let mut active_keys: Vec<String> = Vec::new();
    let mut active_receivers: Vec<tokio::sync::broadcast::Receiver<MarketEvent>> = Vec::new();
    let mut total_forwarded: u64 = 0;
    let mut last_log = tokio::time::Instant::now();

    loop {
        // 1) 非阻塞轮询所有 broadcast receiver，转发消息
        let mut forwarded: u64 = 0;
        let mut i = 0;
        while i < active_receivers.len() {
            match active_receivers[i].try_recv() {
                Ok(event) => {
                    let json = market_event_to_json(&event);
                    if let Ok(text) = serde_json::to_string(&json) {
                        if write.send(Message::Text(text.into())).await.is_err() {
                            return Ok(());
                        }
                        forwarded += 1;
                        total_forwarded += 1;
                    }
                    i += 1;
                }
                Err(tokio::sync::broadcast::error::TryRecvError::Closed) => {
                    if let Some(k) = active_keys.get(i) {
                        dbg!("#{conn_id} 流已关闭: {k}");
                    }
                    active_keys.remove(i);
                    active_receivers.remove(i);
                    // 不递增 i，因为当前索引已被下一个元素占据
                }
                Err(tokio::sync::broadcast::error::TryRecvError::Lagged(n)) => {
                    wrn!("#{conn_id} 丢帧: 跳过 {n} 条消息");
                    i += 1;
                }
                Err(tokio::sync::broadcast::error::TryRecvError::Empty) => {
                    i += 1;
                }
            }
        }

        // 日志
        if forwarded > 0 {
            if last_log.elapsed() >= Duration::from_secs(10) || total_forwarded % 50 < forwarded {
                log!("#{conn_id} 📤 已转发 {} 条 (本批 +{forwarded})", total_forwarded);
                last_log = tokio::time::Instant::now();
            }
        }

        // 2) 等待下一条命令（带超时循环）
        tokio::select! {
            cmd = cmd_rx.recv() => {
                match cmd {
                    Some((cmd, payload)) => {
                        handle_command(
                            &cmd, &payload,
                            &manager, &conn_subs,
                            &mut active_keys, &mut active_receivers,
                            &mut write, conn_id,
                        ).await?;
                    }
                    None => return Ok(()), // 通道关闭
                }
            }
            _ = tokio::time::sleep(Duration::from_millis(50)) => {
                // 超时，继续下一轮轮询
            }
        }
    }
}

// ── 命令处理 ───────────────────────────────────────────

async fn handle_command(
    cmd: &str,
    payload: &Value,
    manager: &Arc<MarketDataManager>,
    conn_subs: &Arc<Mutex<HashMap<u64, Vec<String>>>>,
    active_keys: &mut Vec<String>,
    active_receivers: &mut Vec<tokio::sync::broadcast::Receiver<MarketEvent>>,
    write: &mut futures::stream::SplitSink<
        tokio_tungstenite::WebSocketStream<tokio::net::TcpStream>,
        Message,
    >,
    conn_id: u64,
) -> Result<(), Box<dyn std::error::Error>> {
    match cmd {
        "subscribe_kline" | "subscribe_tick" => {
            let syms: Vec<String> = payload["symbols"]
                .as_array()
                .map(|a| a.iter().filter_map(|v| v.as_str().map(String::from)).collect())
                .unwrap_or_default();

            let result = if cmd == "subscribe_kline" {
                let intervals: Vec<String> = payload["intervals"]
                    .as_array()
                    .map(|a| a.iter().filter_map(|v| v.as_str().map(String::from)).collect())
                    .unwrap_or_default();
                manager.subscribe_kline(Market::Crypto, &syms, &intervals).await
            } else {
                manager.subscribe_tick(Market::Crypto, &syms).await
            };

            match result {
                Ok(sub) => {
                    let keys = sub.keys.clone();
                    for k in &keys {
                        if !active_keys.contains(k) {
                            if let Some(rx) = manager.receiver(k).await {
                                active_keys.push(k.clone());
                                active_receivers.push(rx);
                            }
                        }
                    }
                    conn_subs.lock().await
                        .entry(conn_id)
                        .or_default()
                        .extend(keys.clone());
                    log!("#{conn_id} 订阅: {keys:?}");
                }
                Err(e) => {
                    let _ = write.send(Message::Text(
                        serde_json::json!({"type":"error","msg":e.to_string()}).to_string().into(),
                    )).await;
                }
            }
        }

        "fetch_history" => {
            let syms: Vec<String> = payload["symbols"]
                .as_array()
                .map(|a| a.iter().filter_map(|v| v.as_str().map(String::from)).collect())
                .unwrap_or_default();
            let interval = payload["interval"].as_str().unwrap_or("1m").to_string();
            let limit: u16 = payload["limit"].as_u64().unwrap_or(100) as u16;

            log!("#{conn_id} 获取历史: {syms:?} {interval} x{limit}");

            match manager.fetch_history(Market::Crypto, &syms, &interval, limit).await {
                Ok(data) => {
                    let resp = serde_json::json!({
                        "type": "history",
                        "market": "crypto",
                        "interval": interval,
                        "data": data,
                    });
                    let _ = write.send(Message::Text(resp.to_string().into())).await;
                }
                Err(e) => {
                    let _ = write.send(Message::Text(
                        serde_json::json!({"type":"error","msg":e.to_string()}).to_string().into(),
                    )).await;
                }
            }
        }

        "unsubscribe" => {
            let keys: Vec<String> = payload["keys"]
                .as_array()
                .map(|a| a.iter().filter_map(|v| v.as_str().map(String::from)).collect())
                .unwrap_or_default();

            manager.unsubscribe(&keys).await;

            active_keys.retain(|k| !keys.contains(k));
            active_receivers.clear();
            for k in active_keys.iter() {
                if let Some(rx) = manager.receiver(k).await {
                    active_receivers.push(rx);
                }
            }

            if let Some(entry) = conn_subs.lock().await.get_mut(&conn_id) {
                entry.retain(|k| !keys.contains(k));
            }

            log!("#{conn_id} 取消订阅: {keys:?}");
        }

        "ping" => {
            let _ = write.send(Message::Text(
                serde_json::json!({"type":"pong"}).to_string().into(),
            )).await;
        }

        _ => {
            let _ = write.send(Message::Text(
                serde_json::json!({"type":"error","msg":format!("未知命令: {cmd}")}).to_string().into(),
            )).await;
        }
    }

    Ok(())
}
