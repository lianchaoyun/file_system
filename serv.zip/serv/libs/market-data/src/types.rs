//! 统一市场数据类型定义

use serde::{Deserialize, Serialize};

/// 市场类型枚举
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub enum Market {
    /// 加密货币
    Crypto,
    /// A股
    StockCN,
    /// 港股
    StockHK,
    /// 美股
    StockUS,
    /// 期货
    Future,
}

/// K线周期
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub enum Interval {
    /// 1分钟
    M1,
    /// 5分钟
    M5,
    /// 15分钟
    M15,
    /// 30分钟
    M30,
    /// 1小时
    H1,
    /// 4小时
    H4,
    /// 日线
    D1,
    /// 周线
    W1,
    /// 月线
    MN,
}

impl Interval {
    /// 转为各数据源通用的字符串格式
    pub fn as_str(&self) -> &'static str {
        match self {
            Interval::M1 => "1m",
            Interval::M5 => "5m",
            Interval::M15 => "15m",
            Interval::M30 => "30m",
            Interval::H1 => "1h",
            Interval::H4 => "4h",
            Interval::D1 => "1d",
            Interval::W1 => "1w",
            Interval::MN => "1M",
        }
    }
}

/// K线数据
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Kline {
    /// 开盘时间（毫秒时间戳）
    pub time: i64,
    /// 开盘价
    pub open: f64,
    /// 最高价
    pub high: f64,
    /// 最低价
    pub low: f64,
    /// 收盘价
    pub close: f64,
    /// 成交量
    pub volume: f64,
}

/// 实时逐笔/Tick 数据
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Tick {
    /// 时间戳（毫秒）
    pub time: i64,
    /// 最新价
    pub price: f64,
    /// 成交量
    pub volume: f64,
    /// 买一价
    pub bid: Option<f64>,
    /// 卖一价
    pub ask: Option<f64>,
}

// ── 实时事件类型 ────────────────────────────────────────

/// 实时 K 线事件，附带来源元信息
#[derive(Debug, Clone)]
pub struct KlineEvent {
    /// 品种代码
    pub symbol: String,
    /// K 线周期
    pub interval: String,
    /// K 线数据
    pub kline: Kline,
    /// 来源名称
    pub source: String,
}

/// 实时 Tick 事件
#[derive(Debug, Clone)]
pub struct TickEvent {
    /// 品种代码
    pub symbol: String,
    /// Tick 数据
    pub tick: Tick,
    /// 来源名称
    pub source: String,
}

/// 统一市场事件（K 线 / Tick 共用一个枚举）
#[derive(Debug, Clone)]
pub enum MarketEvent {
    /// K 线事件
    Kline(KlineEvent),
    /// Tick 逐笔事件
    Tick(TickEvent),
}

/// 订阅请求（调用者指定想要什么）
#[derive(Debug, Clone)]
pub struct SubscriptionRequest {
    /// 品种列表
    pub symbols: Vec<String>,
    /// 订阅的 K 线周期（空 = 不订阅 K 线）
    pub kline_intervals: Vec<String>,
    /// 是否订阅 Tick
    pub subscribe_tick: bool,
}

// ── 数据源状态 ──────────────────────────────────────────

/// 数据源状态
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SourceStatus {
    /// 数据源名称
    pub name: String,
    /// 是否已连接
    pub connected: bool,
    /// 订阅的品种数
    pub symbol_count: usize,
    /// 已接收 K 线总数
    pub kline_count: u64,
    /// 最后更新时间
    pub last_update: Option<i64>,
}

// ── 流 Key 工具函数 ─────────────────────────────────────

/// 构造 K 线流的唯一 key
pub fn kline_key(symbol: &str, interval: &str) -> String {
    format!("kline:{}:{}", symbol.to_lowercase(), interval)
}

/// 构造 Tick 流的唯一 key
pub fn tick_key(symbol: &str) -> String {
    format!("tick:{}", symbol.to_lowercase())
}
