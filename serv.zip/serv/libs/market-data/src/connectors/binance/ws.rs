//! Binance WebSocket 实时流

use futures::StreamExt;
use tokio::sync::{broadcast, oneshot};
use tokio::time::{sleep, Duration};
use tokio_tungstenite::connect_async;
use tokio_tungstenite::tungstenite::Message as WsMessage;

use crate::types::{Kline, KlineEvent, MarketEvent, SubscriptionRequest, Tick, TickEvent};

use super::types::*;

const WS_BASE_URL: &str = "wss://fstream.binance.com/market/stream";

// ── 解析器 ─────────────────────────────────────────────

/// 解析结果
enum ParseResult {
    /// 成功解析出事件
    Event(MarketEvent),
    /// 格式匹配但被跳过（如未闭合 K 线）——不要继续尝试其他解析器
    Skipped,
    /// 所有格式都不匹配
    Unmatched,
}

/// 尝试将原始 JSON 文本解析为 MarketEvent（先 K 线后 Tick）
fn try_parse_event(text: &str, source_name: &str) -> ParseResult {
    // 尝试 K 线
    if let Ok(wrapper) = serde_json::from_str::<BinanceKlineWrapper>(text) {
        let kd = &wrapper.data.k;
        if !kd.is_final {
            return ParseResult::Skipped; // 未闭合 K 线，格式正确但跳过
        }
        if let (Ok(o), Ok(h), Ok(l), Ok(c), Ok(v)) = (
            kd.open.parse::<f64>(),
            kd.high.parse::<f64>(),
            kd.low.parse::<f64>(),
            kd.close.parse::<f64>(),
            kd.volume.parse::<f64>(),
        ) {
            if c > 0.0 {
                return ParseResult::Event(MarketEvent::Kline(KlineEvent {
                    symbol: wrapper.data.symbol.to_lowercase(),
                    interval: kd.interval.clone(),
                    kline: Kline { time: kd.start_time, open: o, high: h, low: l, close: c, volume: v },
                    source: source_name.to_string(),
                }));
            }
        }
        return ParseResult::Skipped;
    }

    // 尝试 Tick（!ticker 流不含 bid/ask）
    if let Ok(ticker) = serde_json::from_str::<BinanceMiniTickerWrapper>(text) {
        if let (Ok(price), Ok(vol)) = (
            ticker.data.close_price.parse::<f64>(),
            ticker.data.volume.parse::<f64>(),
        ) {
            if price > 0.0 {
                return ParseResult::Event(MarketEvent::Tick(TickEvent {
                    symbol: ticker.data.symbol.to_lowercase(),
                    tick: Tick {
                        time: ticker.data.event_time,
                        price,
                        volume: vol,
                        bid: None,
                        ask: None,
                    },
                    source: source_name.to_string(),
                }));
            }
        }
        return ParseResult::Skipped;
    }

    ParseResult::Unmatched
}

// ── WebSocket 实时行情 ─────────────────────────────────

/// 启动 Binance WebSocket 流
pub(super) async fn start_stream(
    req: SubscriptionRequest,
    tx: broadcast::Sender<MarketEvent>,
    mut shutdown_rx: oneshot::Receiver<()>,
) {
    let mut streams: Vec<String> = Vec::new();

    for symbol in &req.symbols {
        let sym_lower = symbol.to_lowercase();
        for interval in &req.kline_intervals {
            let interval_lower = interval.to_lowercase();
            streams.push(format!("{}@kline_{}", sym_lower, interval_lower));
        }
        if req.subscribe_tick {
            streams.push(format!("{}@ticker", sym_lower));
        }
    }

    if streams.is_empty() {
        common::wrn!("Binance: nothing to subscribe");
        let _ = shutdown_rx.await;
        return;
    }

    let url = format!("{WS_BASE_URL}?streams={}", streams.join("/"));

    common::log!("🌐 币安联合流订阅就绪。完整 URL: {}", url);
    common::log!(
        "   {} symbols, kline intervals={:?}, tick={} → {} streams",
        req.symbols.len(),
        req.kline_intervals,
        req.subscribe_tick,
        streams.len(),
    );

    let source_name = "binance".to_string();

    loop {
        let ws_connect = connect_async(&url);
        tokio::select! {
            _ = &mut shutdown_rx => {
                common::log!("Binance WS shutdown");
                return;
            }
            result = ws_connect => {
                match result {
                    Ok((ws_stream, _)) => {
                        common::log!("✅ Binance WS connected");
                        let (_, mut read) = ws_stream.split();
                        let mut event_count: u64 = 0;
                        let mut raw_count: u64 = 0;
                        let mut last_stats = tokio::time::Instant::now();

                        loop {
                            tokio::select! {
                                _ = &mut shutdown_rx => {
                                    common::log!("Binance WS shutdown during read");
                                    return;
                                }
                                msg = read.next() => {
                                    match msg {
                                        Some(Ok(WsMessage::Text(text))) => {
                                            raw_count += 1;

                                            // 前 5 条打印预览
                                            if raw_count <= 5 {
                                                let preview: String = text.chars().take(300).collect();
                                                common::log!("Binance raw #{}: {}", raw_count, preview);
                                            }

                                            // 解析
                                            let handled = match try_parse_event(&text, &source_name) {
                                                ParseResult::Event(event) => {
                                                    let _ = tx.send(event);
                                                    event_count += 1;
                                                    true
                                                }
                                                ParseResult::Skipped => {
                                                    true
                                                }
                                                ParseResult::Unmatched => {
                                                    if raw_count <= 5 {
                                                        let preview: String = text.chars().take(300).collect();
                                                        common::wrn!("Binance parse failed. Raw: {}", preview);
                                                    }
                                                    false
                                                }
                                            };

                                            // 每 10 秒统计
                                            if handled {
                                                let elapsed = last_stats.elapsed();
                                                if elapsed >= Duration::from_secs(60) {
                                                    common::log!(
                                                        "📩 Binance 收到 {} 条消息，已解析 {} 条事件 ({:.0}/s)",
                                                        raw_count,
                                                        event_count,
                                                        event_count as f64 / elapsed.as_secs_f64(),
                                                    );
                                                    last_stats = tokio::time::Instant::now();
                                                }
                                            }
                                        }
                                        Some(Ok(WsMessage::Close(_))) => {
                                            common::wrn!("⚠️ Binance WS closed by server");
                                            break;
                                        }
                                        Some(Err(e)) => {
                                            common::err!("⚠️ Binance WS error: {e}");
                                            break;
                                        }
                                        None => {
                                            common::wrn!("⚠️ Binance WS stream ended");
                                            break;
                                        }
                                        _ => {}
                                    }
                                }
                            }
                        }
                    }
                    Err(e) => {
                        common::err!("Binance WS connect failed: {e}");
                    }
                }
            }
        }

        // 检查是否需要退出
        if shutdown_rx.try_recv().is_ok() {
            return;
        }

        // broadcast 无接收者时自动退出
        if tx.receiver_count() == 0 {
            common::log!("Binance WS: no receivers, exiting");
            return;
        }

        common::wrn!("🔁 Binance WS reconnecting in 5s...");
        tokio::select! {
            _ = &mut shutdown_rx => return,
            _ = sleep(Duration::from_secs(5)) => {}
        }
    }
}
