//! Binance WebSocket JSON 响应类型

// ── K 线 JSON 类型 ─────────────────────────────────────

#[derive(Debug, serde::Deserialize)]
#[allow(dead_code)]
pub(super) struct BinanceKlineWrapper {
    #[serde(default)]
    pub stream: String,
    pub data: BinanceKlineEvent,
}

#[derive(Debug, serde::Deserialize)]
#[allow(dead_code)]
pub(super) struct BinanceKlineEvent {
    #[serde(rename = "e")]
    pub event_type: String,
    #[serde(rename = "E")]
    pub event_time: i64,
    #[serde(rename = "s")]
    pub symbol: String,
    pub k: BinanceKlineData,
}

#[derive(Debug, serde::Deserialize)]
#[allow(dead_code)]
pub(super) struct BinanceKlineData {
    #[serde(rename = "t")]
    pub start_time: i64,
    #[serde(rename = "T")]
    pub end_time: i64,
    #[serde(rename = "i")]
    pub interval: String,
    #[serde(rename = "o")]
    pub open: String,
    #[serde(rename = "h")]
    pub high: String,
    #[serde(rename = "l")]
    pub low: String,
    #[serde(rename = "c")]
    pub close: String,
    #[serde(rename = "v")]
    pub volume: String,
    #[serde(rename = "x")]
    pub is_final: bool,
}

// ── Tick JSON 类型 ─────────────────────────────────────

#[derive(Debug, serde::Deserialize)]
#[allow(dead_code)]
pub(super) struct BinanceMiniTickerWrapper {
    #[serde(default)]
    pub stream: String,
    pub data: BinanceMiniTickerData,
}

#[derive(Debug, serde::Deserialize)]
#[allow(dead_code)]
pub(super) struct BinanceMiniTickerData {
    #[serde(rename = "e")]
    pub event_type: String,
    #[serde(rename = "E")]
    pub event_time: i64,
    #[serde(rename = "s")]
    pub symbol: String,
    #[serde(rename = "c")]
    pub close_price: String,
    #[serde(rename = "v")]
    pub volume: String,
    #[serde(rename = "h")]
    pub high_price: String,
    #[serde(rename = "l")]
    pub low_price: String,
    #[serde(rename = "o", default)]
    pub open_price: Option<String>,
    #[serde(rename = "q", default)]
    pub quote_volume: Option<String>,
}
