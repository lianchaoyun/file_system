//! Binance REST 历史 K 线数据

use std::collections::HashMap;

use crate::error::MarketError;
use crate::types::Kline;

pub(super) async fn fetch_history(
    symbols: &[String],
    interval: &str,
    limit: u16,
) -> Result<HashMap<String, Vec<Kline>>, MarketError> {
    let client = reqwest::Client::new();
    let mut result = HashMap::new();

    for symbol in symbols {
        let url = format!(
            "https://fapi.binance.com/fapi/v1/klines?symbol={}&interval={}&limit={}",
            symbol.to_uppercase(),
            interval,
            limit,
        );
        let resp = client.get(&url).send().await?;
        let raw: Vec<Vec<serde_json::Value>> = resp.json().await?;

        let klines: Vec<Kline> = raw
            .iter()
            .filter_map(|k| {
                let time = k.first()?.as_i64()?;
                let open = k.get(1)?.as_str()?.parse::<f64>().ok()?;
                let high = k.get(2)?.as_str()?.parse::<f64>().ok()?;
                let low = k.get(3)?.as_str()?.parse::<f64>().ok()?;
                let close = k.get(4)?.as_str()?.parse::<f64>().ok()?;
                let volume = k.get(5)?.as_str()?.parse::<f64>().ok()?;
                Some(Kline { time, open, high, low, close, volume })
            })
            .collect();

        common::log!(
            "📥 Binance history: {} {} × {} → {} candles",
            symbol, interval, limit, klines.len(),
        );
        result.insert(symbol.to_lowercase(), klines);
    }

    Ok(result)
}
