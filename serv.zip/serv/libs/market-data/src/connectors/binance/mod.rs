//! Binance 加密货币数据源

use std::collections::HashMap;
use std::sync::Arc;

use async_trait::async_trait;
use tokio::sync::{broadcast, oneshot};
use tokio::task::JoinHandle;

use crate::error::MarketError;
use crate::traits::DataSource;
use crate::types::{Kline, Market, MarketEvent, SubscriptionRequest};

mod types;
mod ws;
mod rest;

use ws::start_stream;
use rest::fetch_history;

/// Binance 数据源
#[derive(Clone)]
pub struct BinanceSource {
    /// 支持的品种列表（注册时指定）
    symbols: Vec<String>,
}

impl BinanceSource {
    pub fn new(symbols: Vec<String>) -> Self {
        Self { symbols }
    }
}

// ── DataSource trait 实现 ──────────────────────────────

#[async_trait]
impl DataSource for BinanceSource {
    fn name(&self) -> &str {
        "binance"
    }

    fn market(&self) -> Market {
        Market::Crypto
    }

    fn supported_symbols(&self) -> Vec<String> {
        self.symbols.clone()
    }

    async fn fetch_history(
        &self,
        symbols: &[String],
        interval: &str,
        limit: u16,
    ) -> Result<HashMap<String, Vec<Kline>>, MarketError> {
        fetch_history(symbols, interval, limit).await
    }

    async fn start_stream(
        &self,
        req: SubscriptionRequest,
        tx: broadcast::Sender<MarketEvent>,
        shutdown_rx: oneshot::Receiver<()>,
    ) -> JoinHandle<()> {
        tokio::spawn(async move {
            start_stream(req, tx, shutdown_rx).await;
        })
    }
}

/// 快速创建 Binance 数据源的 Arc
pub fn make_binance(symbols: Vec<String>) -> Arc<BinanceSource> {
    Arc::new(BinanceSource::new(symbols))
}
