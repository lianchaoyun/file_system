//! DataSource trait —— 所有数据源实现的统一接口

use std::collections::HashMap;

use async_trait::async_trait;
use tokio::sync::{broadcast, oneshot};
use tokio::task::JoinHandle;

use crate::error::MarketError;
use crate::types::{Kline, Market, MarketEvent, SubscriptionRequest};

/// 统一数据源 trait
///
/// 所有市场（A股、港股、美股、期货、加密）的数据源都实现此接口。
#[async_trait]
pub trait DataSource: Send + Sync {
    /// 数据源唯一名称，如 "binance", "tushare"
    fn name(&self) -> &str;

    /// 所属市场类型
    fn market(&self) -> Market;

    /// 支持的品种列表（全部大写或标准化格式）
    fn supported_symbols(&self) -> Vec<String>;

    /// 拉取历史 K 线
    ///
    /// - `symbols`: 品种列表
    /// - `interval`: K 线周期（如 "1m", "1h", "1d"）
    /// - `limit`: 最大条数
    async fn fetch_history(
        &self,
        symbols: &[String],
        interval: &str,
        limit: u16,
    ) -> Result<HashMap<String, Vec<Kline>>, MarketError>;

    /// 启动实时行情流（WebSocket / 长轮询）
    ///
    /// 数据推送到 `tx: broadcast::Sender<MarketEvent>`，支持多消费者共享。
    /// 返回 `JoinHandle`，外部可 await 或在需要时 abort。
    /// `shutdown_rx` 用于优雅关闭（oneshot 触发 → 退出循环）。
    async fn start_stream(
        &self,
        req: SubscriptionRequest,
        tx: broadcast::Sender<MarketEvent>,
        shutdown_rx: oneshot::Receiver<()>,
    ) -> JoinHandle<()>;
}
