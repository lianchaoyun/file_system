//! # market-data
//!
//! 统一市场数据源模块，提供一套抽象接口对接全球多市场行情。
//!
//! ## 支持的市场
//!
//! - **Crypto**    — 加密货币（Binance, OKX 等）
//! - **StockCN**   — A股（Tushare, AKShare 等）
//! - **StockHK**   — 港股
//! - **StockUS**   — 美股
//! - **Future**    — 期货
//!
//! ## 快速使用
//!
//! ```ignore
//! use market_data::prelude::*;
//! use market_data::connectors::binance::make_binance;
//!
//! let mut manager = MarketDataManager::new();
//! manager.register(make_binance(vec!["btcusdt".into(), "ethusdt".into()]));
//!
//! // 拉历史 K 线
//! let klines = manager
//!     .fetch_history(Market::Crypto, &["btcusdt".into()], "1h", 100)
//!     .await?;
//! ```
//!
//! ## 实时订阅（广播器模式，自动去重）
//!
//! ```ignore
//! // 模块 A 订阅 btcusdt 的 1m/1h K 线
//! let sub = manager
//!     .subscribe_kline(Market::Crypto, &["btcusdt".into()], &["1m".into(), "1h".into()])
//!     .await?;
//!
//! // 模块 B 也订阅 btcusdt:1m → 复用同一连接
//! let sub2 = manager
//!     .subscribe_kline(Market::Crypto, &["btcusdt".into()], &["1m".into()])
//!     .await?;
//!
//! // 接收事件
//! let mut rx = manager.receiver(&sub.keys[0]).await.unwrap();
//! while let Ok(event) = rx.recv().await {
//!     match event {
//!         MarketEvent::Kline(ke) => println!("K线: {} {}", ke.symbol, ke.interval),
//!         MarketEvent::Tick(te) => println!("Tick: {} 价格={}", te.symbol, te.tick.price),
//!     }
//! }
//! ```

// 核心模块
pub mod types;
pub mod error;
mod traits;
pub use traits::DataSource;
pub mod manager;
pub use manager::{MarketDataManager, Subscription};

// 协议层（WS 命令处理 + 消息转发）
pub mod server;

// 数据源实现
pub mod connectors;

/// prelude —— 常用类型一次性导入
pub mod prelude {
    pub use crate::error::MarketError;
    pub use crate::manager::{MarketDataManager, Subscription};
    pub use crate::traits::DataSource;
    pub use crate::types::{
        Interval, Kline, KlineEvent, Market, MarketEvent, SubscriptionRequest, Tick, TickEvent,
    };
}