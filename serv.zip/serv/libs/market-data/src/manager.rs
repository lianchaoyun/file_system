//! 市场数据管理器 —— 统一调度多个数据源
//!
//! ## 核心设计
//!
//! - **广播器模式**：每个 `(symbol, data_type, interval)` 对应一个 `broadcast::Sender`，
//!   多个订阅者共享同一数据流，避免重复 WebSocket 连接。
//! - **自动关闭**：后台 GC 任务每 30 秒扫描一次，当某流的 `receiver_count() == 0`
//!   时自动发送 shutdown 信号关闭 WebSocket。
//! - **取消订阅**：drop 接收端后 GC 自动回收；也可主动调用 `unsubscribe()` 加速回收。

use std::collections::HashMap;
use std::sync::Arc;
use std::time::Duration;

use tokio::sync::{broadcast, oneshot, Mutex};
use tokio::task::JoinHandle;

use crate::error::MarketError;
use crate::traits::DataSource;
use crate::types::{kline_key, tick_key, Kline, Market, MarketEvent, SourceStatus, SubscriptionRequest};

// ── 内部类型 ────────────────────────────────────────────

/// 流唯一标识
type StreamKey = String;

/// 活跃流：一个 WS 连接对应一个 broadcast 通道
struct ActiveStream {
    /// 广播发送端
    broadcast_tx: broadcast::Sender<MarketEvent>,
    /// 关闭信号（None 表示已关闭）
    shutdown_tx: Mutex<Option<oneshot::Sender<()>>>,
    /// 后台任务句柄
    _handle: Mutex<Option<JoinHandle<()>>>,
}

// ── 管理器 ──────────────────────────────────────────────

/// 市场数据管理器
pub struct MarketDataManager {
    /// 按市场分组的源列表
    sources: HashMap<Market, Vec<Arc<dyn DataSource>>>,
    /// 活跃流池（Arc 共享给 GC 任务）
    active: Arc<Mutex<HashMap<StreamKey, Arc<ActiveStream>>>>,
    /// GC 任务句柄
    _gc_handle: JoinHandle<()>,
}

impl MarketDataManager {
    const CHANNEL_CAP: usize = 2048;
    const GC_INTERVAL_SECS: u64 = 30;

    /// 创建空管理器，自动启动后台 GC
    pub fn new() -> Self {
        let active: Arc<Mutex<HashMap<StreamKey, Arc<ActiveStream>>>> =
            Arc::new(Mutex::new(HashMap::new()));

        // 启动后台 GC 任务
        let active_clone = Arc::clone(&active);
        let gc_handle = tokio::spawn(async move {
            loop {
                tokio::time::sleep(Duration::from_secs(Self::GC_INTERVAL_SECS)).await;

                let mut to_remove: Vec<StreamKey> = Vec::new();
                {
                    let map = active_clone.lock().await;
                    for (key, stream) in map.iter() {
                        if stream.broadcast_tx.receiver_count() == 0 {
                            to_remove.push(key.clone());
                        }
                    }
                }

                if !to_remove.is_empty() {
                    let mut map = active_clone.lock().await;
                    for key in &to_remove {
                        if let Some(stream) = map.remove(key) {
                            // 同一 stream 可能被多个 key 引用，只在最后引用移除时关闭
                            let still_ref = map.values().any(|s| Arc::ptr_eq(s, &stream));
                            if !still_ref {
                                let mut sd = stream.shutdown_tx.lock().await;
                                if let Some(tx) = sd.take() {
                                    let _ = tx.send(());
                                    common::dbg!(
                                        "♻️ GC: stream {key} recycled (0 receivers)",
                                    );
                                }
                            }
                        }
                    }
                }
            }
        });

        Self {
            sources: HashMap::new(),
            active,
            _gc_handle: gc_handle,
        }
    }

    // ── 数据源管理 ──────────────────────────────────────

    /// 注册一个数据源
    pub fn register(&mut self, source: Arc<dyn DataSource>) {
        let market = source.market();
        self.sources
            .entry(market)
            .or_insert_with(Vec::new)
            .push(source);
    }

    /// 获取指定市场的第一个数据源
    pub fn get_source(&self, market: Market) -> Option<&Arc<dyn DataSource>> {
        self.sources.get(&market)?.first()
    }

    /// 获取指定市场的所有数据源
    pub fn get_sources(&self, market: Market) -> Option<&Vec<Arc<dyn DataSource>>> {
        self.sources.get(&market)
    }

    /// 列出所有已注册的市场
    pub fn markets(&self) -> Vec<Market> {
        self.sources.keys().copied().collect()
    }

    /// 获取某数据源的状态信息
    pub async fn status(&self, name: &str) -> Option<SourceStatus> {
        for sources in self.sources.values() {
            for src in sources {
                if src.name() == name {
                    return Some(SourceStatus {
                        name: name.to_string(),
                        connected: false,
                        symbol_count: src.supported_symbols().len(),
                        kline_count: 0,
                        last_update: None,
                    });
                }
            }
        }
        None
    }

    // ── 历史数据 ────────────────────────────────────────

    /// 拉取指定市场的历史 K 线
    pub async fn fetch_history(
        &self,
        market: Market,
        symbols: &[String],
        interval: &str,
        limit: u16,
    ) -> Result<HashMap<String, Vec<Kline>>, MarketError> {
        let source = self
            .get_source(market)
            .ok_or_else(|| MarketError::SourceError(format!("市场 {market:?} 没有注册数据源")))?;
        source.fetch_history(symbols, interval, limit).await
    }

    // ── 实时订阅 ────────────────────────────────────────

    /// 订阅 K 线实时行情
    ///
    /// 返回 `Subscription` 句柄。同一 `(symbol, interval)` 被多处订阅时共享同一 WS 连接。
    ///
    /// # Arguments
    /// * `market` - 市场类型
    /// * `symbols` - 品种列表
    /// * `intervals` - K 线周期列表（如 `["1m", "1h"]`）
    pub async fn subscribe_kline(
        &self,
        market: Market,
        symbols: &[String],
        intervals: &[String],
    ) -> Result<Subscription, MarketError> {
        let source = self
            .get_source(market)
            .ok_or_else(|| MarketError::SourceError(format!("市场 {market:?} 没有注册数据源")))?;

        let mut new_requests: Vec<(StreamKey, SubscriptionRequest)> = Vec::new();

        {
            let active = self.active.lock().await;
            for symbol in symbols {
                for interval in intervals {
                    let key = kline_key(symbol, interval);
                    if !active.contains_key(&key) {
                        new_requests.push((
                            key,
                            SubscriptionRequest {
                                symbols: vec![symbol.clone()],
                                kline_intervals: vec![interval.clone()],
                                subscribe_tick: false,
                            },
                        ));
                    }
                }
            }
        }

        if !new_requests.is_empty() {
            self.create_streams(source, &new_requests).await?;
        }

        let keys: Vec<StreamKey> = symbols
            .iter()
            .flat_map(|s| intervals.iter().map(move |iv| kline_key(s, iv)))
            .collect();

        common::log!(
            "📡 subscribe_kline {market:?}: {} symbols × {} intervals → {} streams ({} new)",
            symbols.len(),
            intervals.len(),
            keys.len(),
            new_requests.len(),
        );

        Ok(Subscription { keys })
    }

    /// 订阅 Tick 实时行情
    pub async fn subscribe_tick(
        &self,
        market: Market,
        symbols: &[String],
    ) -> Result<Subscription, MarketError> {
        let source = self
            .get_source(market)
            .ok_or_else(|| MarketError::SourceError(format!("市场 {market:?} 没有注册数据源")))?;

        let mut new_requests: Vec<(StreamKey, SubscriptionRequest)> = Vec::new();

        {
            let active = self.active.lock().await;
            for symbol in symbols {
                let key = tick_key(symbol);
                if !active.contains_key(&key) {
                    new_requests.push((
                        key,
                        SubscriptionRequest {
                            symbols: vec![symbol.clone()],
                            kline_intervals: vec![],
                            subscribe_tick: true,
                        },
                    ));
                }
            }
        }

        if !new_requests.is_empty() {
            self.create_streams(source, &new_requests).await?;
        }

        let keys: Vec<StreamKey> = symbols.iter().map(|s| tick_key(s)).collect();

        common::log!(
            "📡 subscribe_tick {market:?}: {} symbols → {} new streams",
            symbols.len(),
            new_requests.len(),
        );

        Ok(Subscription { keys })
    }

    /// 接收事件：从已订阅的 key 获取新的 broadcast::Receiver
    ///
    /// 每个调用者应持有自己的 receiver。所有 receiver 共享同一数据流。
    pub async fn receiver(&self, key: &str) -> Option<broadcast::Receiver<MarketEvent>> {
        let active = self.active.lock().await;
        active.get(key).map(|s| s.broadcast_tx.subscribe())
    }

    /// 获取多个 key 的 receiver
    pub async fn receivers(&self, keys: &[StreamKey]) -> Vec<(StreamKey, broadcast::Receiver<MarketEvent>)> {
        let active = self.active.lock().await;
        keys.iter()
            .filter_map(|k| active.get(k).map(|s| (k.clone(), s.broadcast_tx.subscribe())))
            .collect()
    }

    /// 主动取消订阅：立即检查并关闭无接收者的流
    pub async fn unsubscribe(&self, keys: &[StreamKey]) {
        let mut active = self.active.lock().await;
        for key in keys {
            if let Some(stream) = active.remove(key) {
                let still_ref = active.values().any(|s| Arc::ptr_eq(s, &stream));
                if !still_ref {
                    let mut sd = stream.shutdown_tx.lock().await;
                    if let Some(tx) = sd.take() {
                        let _ = tx.send(());
                        common::dbg!("🔌 unsubscribe: stream {key} closed");
                    }
                }
            }
        }
    }

    /// 关闭所有流（应用退出时调用）
    pub async fn shutdown_all(&self) {
        let mut active = self.active.lock().await;
        let keys: Vec<StreamKey> = active.keys().cloned().collect();
        for key in &keys {
            if let Some(stream) = active.remove(key) {
                let still_ref = active.values().any(|s| Arc::ptr_eq(s, &stream));
                if !still_ref {
                    let mut sd = stream.shutdown_tx.lock().await;
                    if let Some(tx) = sd.take() {
                        let _ = tx.send(());
                    }
                }
            }
        }
        common::log!("🛑 All {} streams shut down", keys.len());
    }

    /// 查看当前活跃流数量
    pub async fn active_stream_count(&self) -> usize {
        self.active.lock().await.len()
    }

    // ── 内部方法 ────────────────────────────────────────

    /// 为待创建的 stream key 列表批量创建流
    ///
    /// 多个 key 的请求合并到一次 `source.start_stream()` 调用。
    async fn create_streams(
        &self,
        source: &Arc<dyn DataSource>,
        requests: &[(StreamKey, SubscriptionRequest)],
    ) -> Result<(), MarketError> {
        // 合并所有请求
        let mut merged = SubscriptionRequest {
            symbols: vec![],
            kline_intervals: vec![],
            subscribe_tick: false,
        };

        for (_, req) in requests {
            for sym in &req.symbols {
                if !merged.symbols.contains(sym) {
                    merged.symbols.push(sym.clone());
                }
            }
            for iv in &req.kline_intervals {
                if !merged.kline_intervals.contains(iv) {
                    merged.kline_intervals.push(iv.clone());
                }
            }
            if req.subscribe_tick {
                merged.subscribe_tick = true;
            }
        }

        let (broadcast_tx, _) = broadcast::channel::<MarketEvent>(Self::CHANNEL_CAP);
        let (shutdown_tx, shutdown_rx) = oneshot::channel::<()>();

        let handle = source
            .start_stream(merged.clone(), broadcast_tx.clone(), shutdown_rx)
            .await;

        let stream = Arc::new(ActiveStream {
            broadcast_tx: broadcast_tx.clone(),
            shutdown_tx: Mutex::new(Some(shutdown_tx)),
            _handle: Mutex::new(Some(handle)),
        });

        {
            let mut active = self.active.lock().await;
            for (key, _) in requests {
                active.insert(key.clone(), Arc::clone(&stream));
            }
        }

        common::log!(
            "✅ Stream created: {} symbols, {} intervals, tick={}",
            merged.symbols.len(),
            merged.kline_intervals.len(),
            merged.subscribe_tick,
        );

        Ok(())
    }
}

impl Default for MarketDataManager {
    fn default() -> Self {
        Self::new()
    }
}

// ── Subscription ────────────────────────────────────────

/// 订阅句柄
///
/// 持有活跃流的 key 列表。当所有 `broadcast::Receiver` 被 drop 后，
/// 后台 GC 会在 30 秒内自动关闭对应 WebSocket 流。
///
/// 如需主动释放，调用 `manager.unsubscribe(&sub.keys).await`。
#[derive(Debug, Clone)]
pub struct Subscription {
    /// 订阅的流 key 列表
    pub keys: Vec<StreamKey>,
}

impl Subscription {
    /// 获取所有订阅 key 的引用
    pub fn stream_keys(&self) -> &[StreamKey] {
        &self.keys
    }

    /// 是否为空（没有订阅任何流）
    pub fn is_empty(&self) -> bool {
        self.keys.is_empty()
    }

    /// 订阅的流数量
    pub fn len(&self) -> usize {
        self.keys.len()
    }
}