//! 统一错误类型

use thiserror::Error;

#[derive(Debug, Error)]
pub enum MarketError {
    /// 网络请求失败
    #[error("网络请求失败: {0}")]
    Network(#[from] reqwest::Error),

    /// JSON 解析失败
    #[error("数据解析失败: {0}")]
    Parse(#[from] serde_json::Error),

    /// WebSocket 连接失败
    #[error("WebSocket 连接失败: {0}")]
    WebSocket(String),

    /// 不支持的品种
    #[error("不支持的品种: {0}")]
    UnsupportedSymbol(String),

    /// 不支持的周期
    #[error("不支持的周期: {0}")]
    UnsupportedInterval(String),

    /// API 限流
    #[error("API 限流: {0}")]
    RateLimited(String),

    /// 数据源内部错误
    #[error("数据源错误: {0}")]
    SourceError(String),

    /// 配置错误
    #[error("配置错误: {0}")]
    Config(String),

    /// 通道关闭
    #[error("通道已关闭")]
    ChannelClosed,
}

impl From<tokio_tungstenite::tungstenite::Error> for MarketError {
    fn from(e: tokio_tungstenite::tungstenite::Error) -> Self {
        MarketError::WebSocket(e.to_string())
    }
}
