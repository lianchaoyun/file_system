fn main() {
    let lib_path = if cfg!(windows) {
        "target/debug/dyn_demo.dll"
    } else if cfg!(target_os = "macos") {
        "target/debug/libdyn_demo.dylib"
    } else {
        "target/debug/libdyn_demo.so"
    };

    let lib = unsafe { libloading::Library::new(lib_path) }.unwrap();

    unsafe {
        let execute: libloading::Symbol<
            unsafe extern "C" fn(*const u8, u32, *mut u32) -> *mut u8,
        > = lib.get(b"execute").unwrap();
        let free_string: libloading::Symbol<unsafe extern "C" fn(*mut u8, u32)> =
            lib.get(b"free_string").unwrap();

        // test add
        let input = serde_json::json!({"command": "add", "data": [2, 3]});
        let input_json = serde_json::to_vec(&input).unwrap();
        let mut out_len: u32 = 0;
        let ptr = execute(input_json.as_ptr(), input_json.len() as u32, &mut out_len);
        let out = std::slice::from_raw_parts(ptr, out_len as usize);
        let output: serde_json::Value = serde_json::from_slice(out).unwrap();
        println!("add(2, 3) = {}", output["data"]);
        free_string(ptr, out_len);

        // test process
        let input = serde_json::json!({"command": "process", "data": 5});
        let input_json = serde_json::to_vec(&input).unwrap();
        let mut out_len: u32 = 0;
        let ptr = execute(input_json.as_ptr(), input_json.len() as u32, &mut out_len);
        let out = std::slice::from_raw_parts(ptr, out_len as usize);
        let output: serde_json::Value = serde_json::from_slice(out).unwrap();
        println!("process(5) = {}", output["data"]);
        free_string(ptr, out_len);
    }
}
