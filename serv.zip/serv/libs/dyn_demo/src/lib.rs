use shared::{PluginInput, PluginOutput};

/// 统一执行入口
///
/// # 参数
/// - `input_ptr` : 指向输入 JSON（PluginInput 序列化）的指针
/// - `input_len` : 输入 JSON 的字节长度
/// - `output_len`: 输出参数，用于返回输出 JSON 的字节长度
///
/// # 返回
/// 指向输出 JSON（PluginOutput 序列化）的指针，由调用方通过 `free_string` 释放
#[unsafe(no_mangle)]
pub unsafe extern "C" fn execute(
    input_ptr: *const u8,
    input_len: u32,
    output_len: *mut u32,
) -> *mut u8 {
    // 解析输入
    let input_bytes = unsafe { std::slice::from_raw_parts(input_ptr, input_len as usize) };
    let input: PluginInput = match serde_json::from_slice(input_bytes) {
        Ok(v) => v,
        Err(e) => {
            let err_output = PluginOutput {
                success: false,
                data: serde_json::Value::Null,
                error: Some(format!("解析输入失败: {}", e)),
            };
            return unsafe { pack_output(err_output, output_len) };
        }
    };

    // 根据 command 分发
    let output = match input.command.as_str() {
        "add" => {
            // data 应为 [a, b] 数组
            match serde_json::from_value::<(i32, i32)>(input.data) {
                Ok((a, b)) => PluginOutput {
                    success: true,
                    data: serde_json::json!(a + b),
                    error: None,
                },
                Err(e) => PluginOutput {
                    success: false,
                    data: serde_json::Value::Null,
                    error: Some(format!("add 参数错误: {}", e)),
                },
            }
        }
        "process" => {
            match serde_json::from_value::<i32>(input.data) {
                Ok(val) => PluginOutput {
                    success: true,
                    data: serde_json::json!(val * val + 1),
                    error: None,
                },
                Err(e) => PluginOutput {
                    success: false,
                    data: serde_json::Value::Null,
                    error: Some(format!("process 参数错误: {}", e)),
                },
            }
        }
        _ => PluginOutput {
            success: false,
            data: serde_json::Value::Null,
            error: Some(format!("未知命令: {}", input.command)),
        },
    };

    unsafe { pack_output(output, output_len) }
}

/// 将 PluginOutput 序列化为 JSON 字节并返回给宿主
unsafe fn pack_output(output: PluginOutput, output_len: *mut u32) -> *mut u8 {
    let json = match serde_json::to_vec(&output) {
        Ok(v) => v,
        Err(e) => {
            let fallback = PluginOutput {
                success: false,
                data: serde_json::Value::Null,
                error: Some(format!("序列化输出失败: {}", e)),
            };
            serde_json::to_vec(&fallback).unwrap_or_default()
        }
    };

    let len = json.len() as u32;
    unsafe { *output_len = len; }

    if json.is_empty() {
        return std::ptr::null_mut();
    }

    // 使用 Box 分配，通过 Box::into_raw 转移所有权
    let boxed = json.into_boxed_slice();
    Box::into_raw(boxed) as *mut u8
}

/// 释放由 execute 返回的字符串缓冲区
#[unsafe(no_mangle)]
pub unsafe extern "C" fn free_string(ptr: *mut u8, len: u32) {
    if !ptr.is_null() && len > 0 {
        // 重建 Box 以正确释放内存
        unsafe {
            let _ = Box::from_raw(std::slice::from_raw_parts_mut(ptr, len as usize));
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    unsafe fn call_execute(input: &PluginInput) -> PluginOutput {
        let json = serde_json::to_vec(input).unwrap();
        let mut out_len: u32 = 0;
        let ptr = unsafe { execute(json.as_ptr(), json.len() as u32, &mut out_len) };
        assert!(!ptr.is_null());
        let out_bytes = unsafe { std::slice::from_raw_parts(ptr, out_len as usize) };
        let output: PluginOutput = serde_json::from_slice(out_bytes).unwrap();
        unsafe { free_string(ptr, out_len); }
        output
    }

    #[test]
    fn test_add() {
        let input = PluginInput {
            command: "add".into(),
            data: serde_json::json!([2, 3]),
        };
        let output = unsafe { call_execute(&input) };
        assert!(output.success);
        assert_eq!(output.data, serde_json::json!(5));
    }

    #[test]
    fn test_process() {
        let input = PluginInput {
            command: "process".into(),
            data: serde_json::json!(5),
        };
        let output = unsafe { call_execute(&input) };
        assert!(output.success);
        assert_eq!(output.data, serde_json::json!(26));
    }

    #[test]
    fn test_unknown_command() {
        let input = PluginInput {
            command: "unknown".into(),
            data: serde_json::json!(42),
        };
        let output = unsafe { call_execute(&input) };
        assert!(!output.success);
        assert!(output.error.unwrap().contains("未知命令"));
    }
}
