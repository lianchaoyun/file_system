use std::env;
use std::fs;
use std::path::Path;   


fn cp(src: &str, dst: &str) {
    let _ = fs::remove_dir_all(dst);
    let _ = fs::create_dir_all(dst);
    for entry in fs::read_dir(src).unwrap() {
        let src_path = entry.unwrap().path();
        let dst_path = Path::new(dst).join(src_path.file_name().unwrap());
        if src_path.is_dir() {
            cp(src_path.to_str().unwrap(), dst_path.to_str().unwrap());
        } else {
            fs::copy(&src_path, &dst_path).unwrap();
        }
    }
}

fn main() {
    let out = env::var("OUT_DIR").unwrap();
    let target = Path::new(&out).ancestors().nth(3).unwrap().to_path_buf();
    cp("data/config", target.join("data/config").to_str().unwrap());
    println!("cargo:rerun-if-changed=data/config");
}
