// main.rs — 极简启动入口，只做流程编排

mod startup;

use common::db;
use common::log;
use common::redis_pool;

#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    if let Err(e) = db::init().await {
        eprintln!("数据库连接失败: {}", e);
        return Err(e.into());
    }
    let pool = db::get_pool();
    sqlx::query("SELECT 1 as v").fetch_one(pool).await?;
    redis_pool::init().await;

    let _guard = startup::run_all(pool).await?;

    tokio::signal::ctrl_c().await?;
    log!("收到退出信号，正在关闭...");

    // _guard drop 时自动清理：停止 Web 服务 + 终止 market-data + 释放插件
    drop(_guard);

    db::close().await;
    log!("已关闭");

    Ok(())
}
