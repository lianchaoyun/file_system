mod market_data;
mod plugins_mgr;
mod web_core;

use sqlx::MySql;

/// 所有服务的生命周期句柄
/// main.rs 持有此值，drop 时自动清理
pub struct AppGuard {
    pub web: ::web_core::WebCoreGuard,
    pub market: Option<tokio::process::Child>,
    /// 插件管理器（None 表示插件已禁用）
    #[allow(dead_code)]
    pub plugin: Option<plugins_mgr::PluginGuard>,
}

/// 启动所有服务（web + market-data + plugin）
pub async fn run_all(
    pool: &sqlx::Pool<MySql>,
) -> Result<AppGuard, Box<dyn std::error::Error>> {
    let web = web_core::start(pool).await;
    let market = match market_data::spawn() {
        Ok(child) => Some(child),
        Err(e) => {
            common::wrn!("⚠️ market-data 启动失败（非致命）: {}", e);
            None
        }
    };
    let plugin = plugins_mgr::start().await;
    Ok(AppGuard { web, market, plugin })
}
