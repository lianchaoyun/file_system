/// 启动 market-data 独立服务作为子进程
///
/// 在目标目录查找 `market-data`（或 `market-data.exe`）并启动。
/// 设置 `kill_on_drop(true)`，当返回值被 drop 时自动终止子进程。
pub fn spawn() -> Result<tokio::process::Child, Box<dyn std::error::Error>> {
    let port = common::config::AppConfig::get().market_data.port;

    let exe_dir = std::env::current_exe()
        .ok()
        .and_then(|p| p.parent().map(std::path::PathBuf::from))
        .unwrap_or_else(|| std::path::PathBuf::from("."));

    let bin_name = if cfg!(windows) {
        "market-data.exe"
    } else {
        "market-data"
    };

    let bin_path = exe_dir.join(bin_name);

    if !bin_path.exists() {
        return Err(format!(
            "找不到 market-data 二进制文件: {}",
            bin_path.display()
        )
        .into());
    }

    let child = tokio::process::Command::new(&bin_path)
        .arg(port.to_string())
        .kill_on_drop(true)
        .stdout(std::process::Stdio::null())
        .stderr(std::process::Stdio::null())
        .spawn()?;

    common::log!(
        "✅ market-data 子进程已启动 (PID: {}, 端口: {})",
        child.id().unwrap_or(0),
        port
    );

    Ok(child)
}
