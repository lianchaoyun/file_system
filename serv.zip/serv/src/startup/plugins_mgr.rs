// ==========================================
// 插件启动管理器
// 负责：读取配置 → 创建 PluginManager → 发现/打印 → 返回
// ==========================================

use common::config::AppConfig;
use common::log;

/// 插件启动结果：持有 PluginManager 生命周期
#[allow(dead_code)]
pub struct PluginGuard {
    pub manager: yun::plugin::PluginManager,
}

/// 启动插件系统（根据配置决定是否加载）
pub async fn start() -> Option<PluginGuard> {
    let cfg = AppConfig::get();

    if !cfg.plugin.enabled {
        log!("[startup] 插件系统已禁用 (plugin.enabled = false)，跳过加载");
        return None;
    }

    log!("[startup] 正在初始化插件系统...");
    let pm = yun::plugin::PluginManager::new();

    // 发现并打印可用插件
    yun::plugin::demo::print_discovered(&pm);

    Some(PluginGuard { manager: pm })
}
