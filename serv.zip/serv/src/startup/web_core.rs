use web_core::WebCoreGuard;

/// 启动 web-core 服务，返回自管理生命周期句柄
pub async fn start(pool: &sqlx::Pool<sqlx::MySql>) -> WebCoreGuard {
    web_core::run(pool).await
}
