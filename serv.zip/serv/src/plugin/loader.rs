// ==========================================
// 插件加载器
// ==========================================

// ── WASM ──

use wasmtime::{Engine, Instance, Linker, Module, Store};
use wasmtime_wasi::p1::{self, WasiP1Ctx};
use wasmtime_wasi::WasiCtxBuilder;

/// 加载一个 WASM 模块，返回 (Store, Instance)
/// Store 中携带 WASIp1 上下文，以满足 wasm32-wasip1 编译目标的标准库导入需求
pub fn wasm_load(
    wasm_path: &str,
) -> Result<(Store<WasiP1Ctx>, Instance), Box<dyn std::error::Error>> {
    let engine = Engine::default();
    let module = Module::from_file(&engine, wasm_path)?;

    // 构建 WASIp1 上下文（继承标准 IO，允许 panic 信息等输出到宿主控制台）
    let wasi = WasiCtxBuilder::new().inherit_stdio().build_p1();
    let mut store = Store::new(&engine, wasi);

    // 使用 Linker 将 WASIp1 导入链接到模块
    let mut linker = Linker::new(&engine);
    p1::add_to_linker_sync(&mut linker, |ctx: &mut WasiP1Ctx| ctx)?;

    let instance = linker.instantiate(&mut store, &module)?;
    Ok((store, instance))
}

// ── 动态库 ──

use libloading::{Library, Symbol};

/// 加载动态库文件，返回 Library 句柄
pub fn dyn_load(lib_path: &str) -> Result<Library, Box<dyn std::error::Error>> {
    let lib = unsafe { Library::new(lib_path)? };
    Ok(lib)
}

/// 从已加载的动态库中获取指定名称的函数符号
///
/// # 泛型参数
/// - `T`: 函数签名类型（如 ExecuteFunc、FreeStringFunc 等）
pub unsafe fn dyn_get_function<'a, T>(
    lib: &'a Library,
    name: &[u8],
) -> Result<Symbol<'a, T>, Box<dyn std::error::Error>> {
    unsafe {
        let func: Symbol<T> = lib.get(name)?;
        Ok(func)
    }
}
