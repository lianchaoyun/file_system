// ==========================================
// 插件相关类型定义
// ==========================================

use wasmtime_wasi::p1::WasiP1Ctx;

/// 已加载的 WASM 插件实例（持有 Store 和 Instance）
/// Store 携带 WASIp1 上下文，以满足 wasm32-wasip1 编译目标的标准库导入需求
pub struct WasmPlugin {
    pub store: wasmtime::Store<WasiP1Ctx>,
    pub instance: wasmtime::Instance,
}

/// 已加载的动态库插件
pub struct DynPlugin {
    pub library: libloading::Library,
}

/// 已加载的插件（联合类型）
pub enum LoadedPlugin {
    Wasm(WasmPlugin),
    Dyn(DynPlugin),
}
