// ==========================================
// PluginManager — 插件系统核心管理器
// 负责：从 [[plugin.plugins]] 配置读取插件列表 → 加载 → 调用（execute）→ 卸载
// ==========================================

use std::collections::HashMap;
use std::path::{Path, PathBuf};

use shared::{PluginError, PluginInfo, PluginInput, PluginOutput, PluginType};
use shared::{ExecuteFunc, FreeStringFunc};

use common::config::{AppConfig, PluginEntry};
use common::log;
use crate::plugin::loader;

use super::types::{DynPlugin, LoadedPlugin, WasmPlugin};

pub struct PluginManager {
    /// 项目根目录（绝对路径）
    base_dir: PathBuf,

    /// 插件配置列表（来自 [[plugin.plugins]]）
    entries: Vec<PluginEntry>,

    /// 已加载的插件："{type}:{name}" -> LoadedPlugin
    plugins: HashMap<String, LoadedPlugin>,
}

impl PluginManager {
    // ==========================================
    // 内部工具
    // ==========================================
    /// 生成唯一 key（类型:名称），避免 WASM 和 dyn 同名冲突
    fn key(plugin_type: &PluginType, name: &str) -> String {
        match plugin_type {
            PluginType::Wasm => format!("wasm:{}", name),
            PluginType::Dyn => format!("dyn:{}", name),
        }
    }

    // ==========================================
    // 初始化
    // ==========================================
    pub fn new() -> Self {
        let cfg = AppConfig::get();
        log!("[PluginManager] 配置中共 {} 个插件条目", cfg.plugin.plugins.len());
        Self {
            base_dir: AppConfig::project_root(),
            entries: cfg.plugin.plugins,
            plugins: HashMap::new(),
        }
    }

    // ==========================================
    // 1. 插件发现（从 toml 配置读取）
    // ==========================================
    /// 返回所有配置的插件信息（路径转绝对路径，name 取自文件名）
    pub fn discover(&self) -> Vec<PluginInfo> {
        let mut result = Vec::new();
        for entry in &self.entries {
            let path = self.base_dir.join(&entry.path);
            let name = path
                .file_stem()
                .unwrap_or_default()
                .to_string_lossy()
                .to_string();

            let plugin_type = match entry.r#type.as_str() {
                "wasm" => PluginType::Wasm,
                "dyn" => PluginType::Dyn,
                other => {
                    log!("[PluginManager] 跳过未知类型插件: type={}, path={}", other, entry.path);
                    continue;
                }
            };

            log!("[PluginManager] 发现插件: {}:{} → {}", entry.r#type, name, path.display());
            result.push(PluginInfo { name, plugin_type, path });
        }
        result
    }

    // ==========================================
    // 2. 插件加载（直接使用配置路径）
    // ==========================================
    /// 加载 WASM 插件
    pub fn load_wasm(&mut self, name: &str, path: &Path) -> Result<(), PluginError> {
        let key = Self::key(&PluginType::Wasm, name);
        if self.plugins.contains_key(&key) {
            return Err(PluginError::AlreadyLoaded(name.to_string()));
        }

        let (store, instance) = loader::wasm_load(&path.to_string_lossy())
            .map_err(|e| PluginError::LoadFailed(e.to_string()))?;

        self.plugins.insert(
            key,
            LoadedPlugin::Wasm(WasmPlugin { store, instance }),
        );
        log!("[PluginManager] WASM 插件已加载: {} ({})", name, path.display());
        Ok(())
    }

    /// 加载动态库插件
    pub fn load_dyn(&mut self, name: &str, path: &Path) -> Result<(), PluginError> {
        let key = Self::key(&PluginType::Dyn, name);
        if self.plugins.contains_key(&key) {
            return Err(PluginError::AlreadyLoaded(name.to_string()));
        }

        let lib = loader::dyn_load(&path.to_string_lossy())
            .map_err(|e| PluginError::LoadFailed(format!("{}: {}", path.display(), e)))?;

        self.plugins.insert(
            key,
            LoadedPlugin::Dyn(DynPlugin { library: lib }),
        );
        log!("[PluginManager] 动态库插件已加载: {} ({})", name, path.display());
        Ok(())
    }

    /// 加载所有已配置的插件
    pub fn load_all(&mut self) -> Result<(), PluginError> {
        let discovered = self.discover();
        for info in discovered {
            match info.plugin_type {
                PluginType::Wasm => self.load_wasm(&info.name, &info.path)?,
                PluginType::Dyn => self.load_dyn(&info.name, &info.path)?,
            }
        }
        Ok(())
    }

    // ==========================================
    // 3. 统一插件调用 — execute()
    // ==========================================
    /// 统一调用入口：传入 PluginInput（JSON），返回 PluginOutput（JSON）
    ///
    /// 插件无需关心对方是 WASM 还是动态库 — 都走同一个 execute() 通道。
    pub fn execute(
        &mut self,
        plugin_type: &PluginType,
        name: &str,
        input: PluginInput,
    ) -> Result<PluginOutput, PluginError> {
        let key = Self::key(plugin_type, name);
        let plugin = self
            .plugins
            .get_mut(&key)
            .ok_or_else(|| PluginError::NotFound(name.to_string()))?;

        match plugin {
            LoadedPlugin::Dyn(dp) => {
                let lib = &dp.library;
                Self::execute_dyn(lib, input)
            }
            LoadedPlugin::Wasm(wp) => {
                Self::execute_wasm(&mut wp.store, &wp.instance, input)
            }
        }
    }

    /// 对动态库插件执行调用
    fn execute_dyn(
        lib: &libloading::Library,
        input: PluginInput,
    ) -> Result<PluginOutput, PluginError> {
        // 1. 序列化输入
        let input_json = serde_json::to_vec(&input)
            .map_err(|e| PluginError::ExecutionFailed(format!("序列化失败: {}", e)))?;

        // 2. 获取插件导出的 execute 函数
        let execute_fn = unsafe {
            loader::dyn_get_function::<ExecuteFunc>(lib, b"execute")
        }
        .map_err(|e| PluginError::ExecutionFailed(format!("函数 execute 未找到: {}", e)))?;

        // 3. 获取插件导出的 free_string 函数
        let free_fn = unsafe {
            loader::dyn_get_function::<FreeStringFunc>(lib, b"free_string")
        }
        .map_err(|e| PluginError::ExecutionFailed(format!("函数 free_string 未找到: {}", e)))?;

        let mut output_len: u32 = 0;

        // 4. 调用 execute
        let output_ptr = unsafe {
            execute_fn(input_json.as_ptr(), input_json.len() as u32, &mut output_len)
        };

        if output_ptr.is_null() {
            return Err(PluginError::ExecutionFailed("execute 返回空指针".into()));
        }

        // 5. 读取输出
        let output_bytes = unsafe { std::slice::from_raw_parts(output_ptr, output_len as usize) };

        let output: PluginOutput = serde_json::from_slice(output_bytes)
            .map_err(|e| PluginError::ExecutionFailed(format!("反序列化输出失败: {}", e)))?;

        // 6. 释放插件端分配的内存
        unsafe { free_fn(output_ptr, output_len); }

        Ok(output)
    }

    /// 对 WASM 插件执行调用
    fn execute_wasm(
        store: &mut wasmtime::Store<wasmtime_wasi::p1::WasiP1Ctx>,
        instance: &wasmtime::Instance,
        input: PluginInput,
    ) -> Result<PluginOutput, PluginError> {
        // 获取 WASM 内存
        let memory = instance
            .get_memory(&mut *store, "memory")
            .ok_or_else(|| PluginError::ExecutionFailed("WASM 模块缺少 memory 导出".into()))?;

        // 获取 wasm_alloc / wasm_dealloc / execute 函数
        let alloc_fn = instance
            .get_typed_func::<i32, i32>(&mut *store, "wasm_alloc")
            .map_err(|e| PluginError::ExecutionFailed(format!("wasm_alloc 未导出: {}", e)))?;
        let free = instance
            .get_typed_func::<(i32, i32), ()>(&mut *store, "wasm_dealloc")
            .map_err(|e| PluginError::ExecutionFailed(format!("wasm_dealloc 未导出: {}", e)))?;
        let execute_fn = instance
            .get_typed_func::<(i32, i32), i64>(&mut *store, "execute")
            .map_err(|e| PluginError::ExecutionFailed(format!("execute 未导出: {}", e)))?;

        // 1. 序列化输入
        let input_json = serde_json::to_vec(&input)
            .map_err(|e| PluginError::ExecutionFailed(format!("序列化失败: {}", e)))?;
        let input_len = input_json.len() as i32;

        // 2. 在 WASM 线性内存中分配空间
        let input_ptr = alloc_fn
            .call(&mut *store, input_len)
            .map_err(|e| PluginError::ExecutionFailed(format!("wasm_alloc 调用失败: {}", e)))?;

        // 3. 写入输入数据
        let mem_data = memory.data_mut(&mut *store);
        let start = input_ptr as usize;
        mem_data[start..start + input_len as usize].copy_from_slice(&input_json);

        // 4. 调用 execute（返回打包的 i64：低32位=ptr，高32位=len）
        let packed = execute_fn
            .call(&mut *store, (input_ptr, input_len))
            .map_err(|e| PluginError::ExecutionFailed(format!("execute 调用失败: {}", e)))?;

        let output_ptr = (packed as u32) as i32;
        let output_len = (packed >> 32) as i32;

        // 5. 读取输出数据
        let mem_data = memory.data(&mut *store);
        let start = output_ptr as usize;
        let end = start + output_len as usize;
        let output_bytes = &mem_data[start..end];

        // 6. 反序列化输出
        let output: PluginOutput = serde_json::from_slice(output_bytes)
            .map_err(|e| PluginError::ExecutionFailed(format!("反序列化输出失败: {}", e)))?;

        // 7. 释放 WASM 内存
        let _ = free.call(&mut *store, (input_ptr, input_len));
        let _ = free.call(&mut *store, (output_ptr, output_len));

        Ok(output)
    }

    // ==========================================
    // 4. 插件卸载
    // ==========================================
    pub fn unload(&mut self, plugin_type: &PluginType, name: &str) -> Result<(), PluginError> {
        let key = Self::key(plugin_type, name);
        self.plugins
            .remove(&key)
            .ok_or_else(|| PluginError::NotFound(name.to_string()))?;
        log!("[PluginManager] 插件已卸载: {}:{}", match plugin_type {
            PluginType::Wasm => "wasm",
            PluginType::Dyn => "dyn",
        }, name);
        Ok(())
    }

    // ==========================================
    // 5. 查询
    // ==========================================
    /// 列出已加载的插件
    pub fn list_loaded(&self) -> Vec<&str> {
        self.plugins.keys().map(|s| s.as_str()).collect()
    }

    /// 检查插件是否已加载
    pub fn is_loaded(&self, plugin_type: &PluginType, name: &str) -> bool {
        self.plugins.contains_key(&Self::key(plugin_type, name))
    }
}
