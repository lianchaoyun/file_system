// ==========================================
// plugin 模块 —— 主程序插件系统
// ==========================================

pub mod demo;
pub mod loader;
pub mod manager;
pub mod types;

// 重新导出，方便外部使用
pub use manager::PluginManager;
