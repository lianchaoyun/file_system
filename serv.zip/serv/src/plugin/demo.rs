// ==========================================
// plugin 演示
// 展示插件的发现、加载、调用（execute）、卸载流程
// 注意：测试代码已移至 tests/ 目录
// ==========================================

use common::log;
use common::wrn;
use shared::{PluginInput, PluginType};

use super::manager::PluginManager;

/// 发现并打印所有可用插件
pub fn print_discovered(pm: &PluginManager) {
    let available = pm.discover();
    if available.is_empty() {
        wrn!("未发现任何插件");
    } else {
        log!("发现 {} 个插件:", available.len());
        for info in &available {
            let prefix = match info.plugin_type {
                PluginType::Wasm => "wasm",
                PluginType::Dyn => "dyn",
            };
            log!("  • {}:{}  →  {}", prefix, info.name, info.path.display());
        }
    }
}

/// 完整演示流程：加载 → 调用 → 卸载
pub fn run_all(pm: &mut PluginManager) -> Result<(), Box<dyn std::error::Error>> {
    // 1) 加载所有插件
    assert!(!pm.is_loaded(&PluginType::Wasm, "wasm_demo"));
    assert!(!pm.is_loaded(&PluginType::Dyn, "dyn_demo"));
    pm.load_all()?;
    assert!(pm.is_loaded(&PluginType::Wasm, "wasm_demo"));
    assert!(pm.is_loaded(&PluginType::Dyn, "dyn_demo"));
    log!("已加载: {:?}\n", pm.list_loaded());

    // 2) 基本功能演示
    log!("=== WASM 插件演示 ===");
    demo_wasm(pm)?;

    log!("=== 原生动态库插件演示 ===");
    demo_dyn(pm)?;

    // 3) 卸载
    log!("=== 卸载 ===");
    pm.unload(&PluginType::Wasm, "wasm_demo")?;
    pm.unload(&PluginType::Dyn, "dyn_demo")?;
    log!("卸载后剩余: {:?}", pm.list_loaded());

    Ok(())
}

// ── 基础演示 ──────────────────────────────────

fn demo_wasm(pm: &mut PluginManager) -> Result<(), Box<dyn std::error::Error>> {
    let ty = &PluginType::Wasm;

    let result = pm.execute(ty, "wasm_demo", PluginInput {
        command: "add".into(),
        data: serde_json::json!([3, 5]),
    })?;
    log!("add(3, 5) = {}", result.data);

    let result = pm.execute(ty, "wasm_demo", PluginInput {
        command: "process".into(),
        data: serde_json::json!(10),
    })?;
    log!("process(10) = {}", result.data);

    Ok(())
}

fn demo_dyn(pm: &mut PluginManager) -> Result<(), Box<dyn std::error::Error>> {
    let ty = &PluginType::Dyn;

    let result = pm.execute(ty, "dyn_demo", PluginInput {
        command: "add".into(),
        data: serde_json::json!([3, 5]),
    })?;
    log!("add(3, 5) = {}", result.data);

    let result = pm.execute(ty, "dyn_demo", PluginInput {
        command: "process".into(),
        data: serde_json::json!(10),
    })?;
    log!("process(10) = {}", result.data);

    Ok(())
}
