-- Basic groups (messages.createChat) use the `chat` / `peerChat` TL types,
-- unlike the existing supergroup rows that are exposed as `channel`.
ALTER TABLE te_chats DROP CONSTRAINT IF EXISTS te_chats_kind_check;
ALTER TABLE te_chats DROP CONSTRAINT IF EXISTS te_chats_check;

ALTER TABLE te_chats
    ADD CONSTRAINT te_chats_kind_check
    CHECK (kind IN ('private', 'group', 'channel', 'basic_group'));

ALTER TABLE te_chats
    ADD CONSTRAINT te_chats_check
    CHECK (
        (kind = 'private'
            AND owner_user_id IS NULL
            AND private_user_a IS NOT NULL
            AND private_user_b IS NOT NULL
            AND private_user_a < private_user_b)
        OR (kind IN ('group', 'channel', 'basic_group')
            AND owner_user_id IS NOT NULL
            AND private_user_a IS NULL
            AND private_user_b IS NULL)
    );
