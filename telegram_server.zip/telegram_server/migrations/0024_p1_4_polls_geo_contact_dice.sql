-- P1-4: file-less message media (poll, geo point, contact card, dice).
-- These media keep their small payload directly in te_media_files instead of
-- pointing at a stored file; poll votes live in their own table.

ALTER TABLE te_media_files DROP CONSTRAINT IF EXISTS te_media_files_kind_check;
ALTER TABLE te_media_files
    ADD CONSTRAINT te_media_files_kind_check
    CHECK (kind IN ('photo', 'video', 'document', 'poll', 'geo', 'contact', 'dice'));

ALTER TABLE te_media_files
    ADD COLUMN IF NOT EXISTS media_payload jsonb NOT NULL DEFAULT '{}'::jsonb;

CREATE TABLE IF NOT EXISTS te_poll_votes (
    media_id bigint NOT NULL REFERENCES te_media_files (id) ON DELETE CASCADE,
    user_id bigint NOT NULL REFERENCES te_users (id) ON DELETE CASCADE,
    option bytea NOT NULL,
    voted_at bigint NOT NULL DEFAULT 0,
    PRIMARY KEY (media_id, user_id, option)
);

CREATE INDEX IF NOT EXISTS te_poll_votes_media_idx ON te_poll_votes (media_id);
