-- P2-3: session metadata needed by account.getAuthorizations.
ALTER TABLE te_sessions
    ADD COLUMN IF NOT EXISTS api_id integer NOT NULL DEFAULT 0,
    ADD COLUMN IF NOT EXISTS app_name text NOT NULL DEFAULT '',
    ADD COLUMN IF NOT EXISTS lang_code text NOT NULL DEFAULT '';
