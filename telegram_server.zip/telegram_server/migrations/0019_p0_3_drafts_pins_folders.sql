-- P0-3: drafts, pinned dialogs and dialog filters.

CREATE TABLE IF NOT EXISTS te_drafts (
    user_id bigint NOT NULL REFERENCES te_users(id) ON DELETE CASCADE,
    chat_id bigint NOT NULL REFERENCES te_chats(id) ON DELETE CASCADE,
    text text NOT NULL DEFAULT '',
    reply_to bigint NOT NULL DEFAULT 0,
    updated_at bigint NOT NULL DEFAULT 0,
    PRIMARY KEY (user_id, chat_id)
);

CREATE TABLE IF NOT EXISTS te_pinned_dialogs (
    user_id bigint NOT NULL REFERENCES te_users(id) ON DELETE CASCADE,
    chat_id bigint NOT NULL REFERENCES te_chats(id) ON DELETE CASCADE,
    sort_order integer NOT NULL DEFAULT 0,
    pinned_at bigint NOT NULL DEFAULT 0,
    PRIMARY KEY (user_id, chat_id)
);

CREATE INDEX IF NOT EXISTS te_pinned_dialogs_order_idx
    ON te_pinned_dialogs (user_id, sort_order);

CREATE TABLE IF NOT EXISTS te_dialog_filters (
    user_id bigint NOT NULL REFERENCES te_users(id) ON DELETE CASCADE,
    filter_id integer NOT NULL,
    filter bytea NOT NULL,
    updated_at bigint NOT NULL DEFAULT 0,
    PRIMARY KEY (user_id, filter_id)
);
