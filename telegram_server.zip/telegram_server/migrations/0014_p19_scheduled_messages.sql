-- P19: scheduled messages. scheduled_date > 0 means the message is pending and
-- must be hidden from normal history/dialogs until it is sent.
ALTER TABLE te_messages
    ADD COLUMN IF NOT EXISTS scheduled_date bigint NOT NULL DEFAULT 0;

CREATE INDEX IF NOT EXISTS te_messages_scheduled_idx
    ON te_messages (scheduled_date) WHERE scheduled_date > 0;
