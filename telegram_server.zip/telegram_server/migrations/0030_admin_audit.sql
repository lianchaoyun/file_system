-- 管理员操作审计：记录后台对账号/会话/消息的每一次写操作。
CREATE TABLE IF NOT EXISTS te_admin_audit (
    id bigserial PRIMARY KEY,
    actor text NOT NULL DEFAULT '',
    action text NOT NULL,
    target_user_id bigint NULL,
    target_chat_id bigint NULL,
    target_message_id bigint NULL,
    params jsonb NOT NULL DEFAULT '{}'::jsonb,
    success boolean NOT NULL,
    error text NULL,
    created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS te_admin_audit_user_idx
    ON te_admin_audit (target_user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS te_admin_audit_chat_idx
    ON te_admin_audit (target_chat_id, created_at DESC);
CREATE INDEX IF NOT EXISTS te_admin_audit_created_idx
    ON te_admin_audit (created_at DESC);
