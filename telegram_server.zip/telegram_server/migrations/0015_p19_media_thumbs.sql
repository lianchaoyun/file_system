-- P20: multi-tier media thumbnails (s/m/x). The legacy media_files thumb_*
-- columns keep the medium preview for backwards compatibility.
CREATE TABLE IF NOT EXISTS te_media_thumbs (
    media_id bigint NOT NULL REFERENCES te_media_files (id) ON DELETE CASCADE,
    kind text NOT NULL,
    storage_key text NOT NULL,
    width integer NOT NULL,
    height integer NOT NULL,
    size bigint NOT NULL,
    PRIMARY KEY (media_id, kind)
);
