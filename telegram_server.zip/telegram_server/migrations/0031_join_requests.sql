-- 入群申请审批：request_needed 邀请链接产生的待审批请求。
CREATE TABLE IF NOT EXISTS te_join_requests (
    id bigserial PRIMARY KEY,
    chat_id bigint NOT NULL REFERENCES te_chats (id) ON DELETE CASCADE,
    user_id bigint NOT NULL REFERENCES te_users (id) ON DELETE CASCADE,
    about text NOT NULL DEFAULT '',
    status text NOT NULL DEFAULT 'pending',
    requested_at bigint NOT NULL,
    reviewed_at bigint NOT NULL DEFAULT 0,
    reviewer text NOT NULL DEFAULT '',
    UNIQUE (chat_id, user_id)
);

CREATE INDEX IF NOT EXISTS te_join_requests_status_idx
    ON te_join_requests (chat_id, status);
