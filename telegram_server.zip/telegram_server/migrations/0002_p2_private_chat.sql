-- P2: per-user update state for private chats.
-- Applied to both dev and test schemas by the developer; the server does not
-- run migrations automatically yet.

ALTER TABLE te_users
    ADD COLUMN IF NOT EXISTS pts bigint NOT NULL DEFAULT 0;

CREATE INDEX IF NOT EXISTS te_messages_sender_idx ON te_messages (sender_user_id, id);
