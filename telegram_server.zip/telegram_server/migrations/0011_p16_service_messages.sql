-- P16: basic group service messages (group created / user added / user removed /
-- title changed). The TL payload is rebuilt from these columns when messages are
-- rendered, so the history keeps showing the same service actions.
ALTER TABLE te_messages
    ADD COLUMN IF NOT EXISTS action_kind text NOT NULL DEFAULT '';

ALTER TABLE te_messages
    ADD COLUMN IF NOT EXISTS action_user_id bigint NOT NULL DEFAULT 0;

ALTER TABLE te_messages
    ADD COLUMN IF NOT EXISTS action_title text NOT NULL DEFAULT '';
