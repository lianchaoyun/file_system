-- P7: persistent temporary auth key bindings.
-- expires_at: 0 = permanent key, > 0 = absolute unix expiry of a temporary
-- key created from p_q_inner_data_temp(_dc).
ALTER TABLE te_auth_keys
    ADD COLUMN IF NOT EXISTS expires_at bigint NOT NULL DEFAULT 0;

CREATE INDEX IF NOT EXISTS te_auth_keys_expires_at_idx
    ON te_auth_keys (expires_at)
    WHERE expires_at > 0;

CREATE TABLE IF NOT EXISTS te_temp_auth_key_bindings (
    temp_auth_key_id bigint PRIMARY KEY
        REFERENCES te_auth_keys(auth_key_id) ON DELETE CASCADE,
    perm_auth_key_id bigint NOT NULL
        REFERENCES te_auth_keys(auth_key_id) ON DELETE CASCADE,
    nonce bigint NOT NULL,
    temp_session_id bigint NOT NULL,
    expires_at bigint NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    CHECK (temp_auth_key_id <> perm_auth_key_id),
    CHECK (expires_at > 0)
);

CREATE INDEX IF NOT EXISTS te_temp_auth_key_bindings_perm_idx
    ON te_temp_auth_key_bindings (perm_auth_key_id);
