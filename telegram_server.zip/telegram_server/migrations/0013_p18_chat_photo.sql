-- P18: chat / channel profile photos.
ALTER TABLE te_chats
    ADD COLUMN IF NOT EXISTS photo_media_id bigint NOT NULL DEFAULT 0;
