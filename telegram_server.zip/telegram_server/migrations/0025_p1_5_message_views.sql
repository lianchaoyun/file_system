-- P1-5: per-message view counters (channel posts and megagroup messages).
ALTER TABLE te_messages
    ADD COLUMN IF NOT EXISTS views bigint NOT NULL DEFAULT 0;
