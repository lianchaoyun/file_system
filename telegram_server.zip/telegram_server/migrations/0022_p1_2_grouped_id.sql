-- P1-2: album / grouped media support.
-- Non-zero grouped_id means the message belongs to an album; the client merges
-- messages that share the same grouped_id into a single gallery bubble.
ALTER TABLE te_messages
    ADD COLUMN IF NOT EXISTS grouped_id bigint NOT NULL DEFAULT 0;

CREATE INDEX IF NOT EXISTS te_messages_chat_grouped_idx
    ON te_messages (chat_id, grouped_id)
    WHERE grouped_id <> 0;
