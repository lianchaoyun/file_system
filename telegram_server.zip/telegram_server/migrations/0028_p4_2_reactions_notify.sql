-- P4-2: per-user reaction notification settings.

CREATE TABLE IF NOT EXISTS te_reaction_notify_settings (
    user_id bigint PRIMARY KEY REFERENCES te_users (id) ON DELETE CASCADE,
    settings jsonb NOT NULL DEFAULT '{}'::jsonb,
    updated_at timestamptz NOT NULL DEFAULT now()
);
