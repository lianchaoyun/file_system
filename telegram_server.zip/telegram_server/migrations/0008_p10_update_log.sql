-- P10: durable per-user / per-channel update log for updates.getDifference
-- and updates.getChannelDifference.
CREATE TABLE IF NOT EXISTS te_update_log (
    id bigserial PRIMARY KEY,
    user_id bigint REFERENCES te_users(id) ON DELETE CASCADE,
    channel_id bigint REFERENCES te_chats(id) ON DELETE CASCADE,
    pts bigint NOT NULL,
    update_data bytea NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    CHECK ((user_id IS NOT NULL)::int + (channel_id IS NOT NULL)::int = 1)
);

CREATE INDEX IF NOT EXISTS te_update_log_user_pts_idx
    ON te_update_log (user_id, pts);

CREATE INDEX IF NOT EXISTS te_update_log_channel_pts_idx
    ON te_update_log (channel_id, pts);

-- Store only the recent difference window. Older events can be pruned by
-- maintenance without affecting current clients.
CREATE INDEX IF NOT EXISTS te_update_log_created_idx
    ON te_update_log (created_at);
