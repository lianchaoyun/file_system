-- P9: message reply / edit / forward / pin metadata.
ALTER TABLE te_messages
    ADD COLUMN IF NOT EXISTS reply_to_msg_id bigint;

ALTER TABLE te_messages
    ADD COLUMN IF NOT EXISTS edit_date bigint NOT NULL DEFAULT 0;

ALTER TABLE te_messages
    ADD COLUMN IF NOT EXISTS fwd_from_user_id bigint;

ALTER TABLE te_messages
    ADD COLUMN IF NOT EXISTS fwd_from_chat_id bigint;

ALTER TABLE te_messages
    ADD COLUMN IF NOT EXISTS fwd_from_msg_id bigint;

ALTER TABLE te_messages
    ADD COLUMN IF NOT EXISTS fwd_date bigint NOT NULL DEFAULT 0;

ALTER TABLE te_chats
    ADD COLUMN IF NOT EXISTS pinned_msg_id bigint NOT NULL DEFAULT 0;

CREATE INDEX IF NOT EXISTS te_messages_reply_idx
    ON te_messages (chat_id, reply_to_msg_id);
