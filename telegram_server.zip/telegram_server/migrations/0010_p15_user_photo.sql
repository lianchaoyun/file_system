-- Profile photos reuse the media_files table; `0` means no avatar.
ALTER TABLE te_users
    ADD COLUMN IF NOT EXISTS photo_media_id bigint NOT NULL DEFAULT 0;
