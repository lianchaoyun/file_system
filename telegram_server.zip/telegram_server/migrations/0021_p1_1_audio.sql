-- P1-1: audio / voice message metadata.
ALTER TABLE te_media_files ADD COLUMN IF NOT EXISTS audio_voice boolean NOT NULL DEFAULT false;
ALTER TABLE te_media_files ADD COLUMN IF NOT EXISTS audio_title text NOT NULL DEFAULT '';
ALTER TABLE te_media_files ADD COLUMN IF NOT EXISTS audio_performer text NOT NULL DEFAULT '';
ALTER TABLE te_media_files ADD COLUMN IF NOT EXISTS audio_waveform bytea;
