-- Admin: Telegram user ban flag.
-- `banned_at` is NULL for normal users, non-NULL when the admin panel banned
-- the account. Banning also revokes every session so the client is logged out.

ALTER TABLE te_users ADD COLUMN IF NOT EXISTS banned_at timestamptz NULL;
