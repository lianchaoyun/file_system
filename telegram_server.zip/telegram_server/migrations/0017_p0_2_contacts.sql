-- P0-2: real contact relationships, blocked users and privacy settings.

CREATE TABLE IF NOT EXISTS te_contacts (
    owner_user_id bigint NOT NULL REFERENCES te_users (id) ON DELETE CASCADE,
    contact_user_id bigint NOT NULL REFERENCES te_users (id) ON DELETE CASCADE,
    created_at timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (owner_user_id, contact_user_id)
);

CREATE INDEX IF NOT EXISTS te_contacts_contact_idx
    ON te_contacts (contact_user_id);

CREATE TABLE IF NOT EXISTS te_blocked_users (
    owner_user_id bigint NOT NULL REFERENCES te_users (id) ON DELETE CASCADE,
    blocked_user_id bigint NOT NULL REFERENCES te_users (id) ON DELETE CASCADE,
    created_at timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (owner_user_id, blocked_user_id)
);

CREATE INDEX IF NOT EXISTS te_blocked_users_blocked_idx
    ON te_blocked_users (blocked_user_id);

CREATE TABLE IF NOT EXISTS te_privacy_settings (
    user_id bigint NOT NULL REFERENCES te_users (id) ON DELETE CASCADE,
    key bigint NOT NULL,
    rules jsonb NOT NULL DEFAULT '[]'::jsonb,
    updated_at timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (user_id, key)
);

-- Seed existing users as mutual contacts once, so the desktop contact list is
-- not empty after the upgrade. Skip seeding on unusually large user tables to
-- avoid an N^2 insert; new accounts still get the system user as a contact.
DO $$
DECLARE
    user_count bigint;
BEGIN
    SELECT count(*) INTO user_count FROM te_users;
    IF user_count > 0 AND user_count <= 500 THEN
        INSERT INTO te_contacts (owner_user_id, contact_user_id)
        SELECT a.id, b.id
        FROM te_users a
        CROSS JOIN te_users b
        WHERE a.id <> b.id
        ON CONFLICT DO NOTHING;
    END IF;
END $$;
