-- P3: supergroups and broadcast channels.

ALTER TABLE te_chats
    ADD COLUMN IF NOT EXISTS access_hash bigint NOT NULL DEFAULT 0;

ALTER TABLE te_chats
    ADD COLUMN IF NOT EXISTS pts bigint NOT NULL DEFAULT 0;

CREATE INDEX IF NOT EXISTS te_chats_access_hash_idx ON te_chats (access_hash);
