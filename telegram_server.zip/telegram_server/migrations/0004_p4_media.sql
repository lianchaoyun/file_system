-- P4: uploaded media metadata.

ALTER TABLE te_media_files
    ADD COLUMN IF NOT EXISTS access_hash bigint NOT NULL DEFAULT 0;

ALTER TABLE te_media_files
    ADD COLUMN IF NOT EXISTS file_reference bytea NOT NULL DEFAULT '\x'::bytea;

ALTER TABLE te_media_files
    ADD COLUMN IF NOT EXISTS owner_user_id bigint REFERENCES te_users(id);

ALTER TABLE te_media_files
    ADD COLUMN IF NOT EXISTS file_name text NOT NULL DEFAULT '';

CREATE INDEX IF NOT EXISTS te_media_files_access_hash_idx ON te_media_files (access_hash);
