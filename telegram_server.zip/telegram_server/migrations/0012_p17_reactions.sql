-- P17: message reactions (one emoji reaction per user per message).
CREATE TABLE IF NOT EXISTS te_message_reactions (
    message_id bigint NOT NULL REFERENCES te_messages(id) ON DELETE CASCADE,
    user_id bigint NOT NULL REFERENCES te_users(id) ON DELETE CASCADE,
    emoticon text NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (message_id, user_id)
);

CREATE INDEX IF NOT EXISTS te_message_reactions_message_idx
    ON te_message_reactions (message_id, emoticon);
