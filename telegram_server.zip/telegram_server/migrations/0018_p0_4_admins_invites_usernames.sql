-- P0-4: group/channel administrators, bans, invite links and usernames.

ALTER TABLE te_chat_members DROP CONSTRAINT IF EXISTS te_chat_members_role_check;
ALTER TABLE te_chat_members
    ADD CONSTRAINT te_chat_members_role_check
    CHECK (role IN ('owner', 'admin', 'member'));

ALTER TABLE te_chat_members
    ADD COLUMN IF NOT EXISTS admin_rights jsonb NOT NULL DEFAULT '{}'::jsonb;
ALTER TABLE te_chat_members
    ADD COLUMN IF NOT EXISTS rank text NOT NULL DEFAULT '';
ALTER TABLE te_chat_members
    ADD COLUMN IF NOT EXISTS promoted_by bigint NOT NULL DEFAULT 0;

CREATE TABLE IF NOT EXISTS te_chat_bans (
    chat_id bigint NOT NULL REFERENCES te_chats(id) ON DELETE CASCADE,
    user_id bigint NOT NULL REFERENCES te_users(id) ON DELETE CASCADE,
    banned_rights jsonb NOT NULL DEFAULT '{}'::jsonb,
    until_date bigint NOT NULL DEFAULT 0,
    kicked_by bigint NOT NULL DEFAULT 0,
    created_at bigint NOT NULL DEFAULT 0,
    PRIMARY KEY (chat_id, user_id)
);

CREATE INDEX IF NOT EXISTS te_chat_bans_user_idx ON te_chat_bans (user_id);

CREATE TABLE IF NOT EXISTS te_chat_invites (
    token text PRIMARY KEY,
    chat_id bigint NOT NULL REFERENCES te_chats(id) ON DELETE CASCADE,
    creator_id bigint NOT NULL REFERENCES te_users(id) ON DELETE CASCADE,
    link text NOT NULL DEFAULT '',
    expires_at bigint NOT NULL DEFAULT 0,
    usage_limit integer NOT NULL DEFAULT 0,
    usage_count integer NOT NULL DEFAULT 0,
    request_needed boolean NOT NULL DEFAULT false,
    revoked boolean NOT NULL DEFAULT false,
    created_at bigint NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS te_chat_invites_chat_idx ON te_chat_invites (chat_id);

-- Usernames are case-insensitive and unique. Existing rows hold no public
-- usernames in production, so the indexes can be created directly.
CREATE UNIQUE INDEX IF NOT EXISTS te_users_username_lower_idx
    ON te_users (lower(username))
    WHERE username <> '';

CREATE UNIQUE INDEX IF NOT EXISTS te_chats_username_lower_idx
    ON te_chats (lower(username))
    WHERE username IS NOT NULL AND username <> '';

CREATE INDEX IF NOT EXISTS te_chats_owner_idx ON te_chats (owner_user_id);
