-- 机器人账号：bot 复用 te_users 作为账号主体，令牌只保存 SHA-256 摘要。
-- bot 的 phone 列用 `bot:<username>` 占位（phone 为 NOT NULL UNIQUE）。

ALTER TABLE te_users ADD COLUMN IF NOT EXISTS is_bot boolean NOT NULL DEFAULT false;
ALTER TABLE te_users ADD COLUMN IF NOT EXISTS bot_info_version integer NOT NULL DEFAULT 0;

CREATE TABLE IF NOT EXISTS te_bots (
    user_id bigint PRIMARY KEY REFERENCES te_users(id) ON DELETE CASCADE,
    token_prefix text NOT NULL DEFAULT '',
    token_hash text NOT NULL UNIQUE,
    owner_user_id bigint NULL REFERENCES te_users(id) ON DELETE SET NULL,
    disabled boolean NOT NULL DEFAULT false,
    created_by text NOT NULL DEFAULT '',
    created_at timestamptz NOT NULL DEFAULT now(),
    last_used_at timestamptz NULL
);

CREATE INDEX IF NOT EXISTS te_bots_owner_idx ON te_bots (owner_user_id);

-- 消息附带的 inline keyboard / reply keyboard（Bot API ReplyMarkup JSON）。
ALTER TABLE te_messages ADD COLUMN IF NOT EXISTS reply_markup jsonb NULL;

-- HTTP Bot API 的 getUpdates 队列（webhook 未启用时使用长轮询）。
CREATE TABLE IF NOT EXISTS te_bot_updates (
    bot_user_id bigint NOT NULL REFERENCES te_users(id) ON DELETE CASCADE,
    update_id bigserial,
    payload jsonb NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (bot_user_id, update_id)
);

