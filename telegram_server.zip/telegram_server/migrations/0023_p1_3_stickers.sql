-- P1-3: sticker / custom emoji document attributes.
-- Sticker documents keep their sticker set so the client can render them as
-- animated stickers instead of plain files.
ALTER TABLE te_media_files
    ADD COLUMN IF NOT EXISTS sticker boolean NOT NULL DEFAULT false;
ALTER TABLE te_media_files
    ADD COLUMN IF NOT EXISTS sticker_alt text NOT NULL DEFAULT '';
ALTER TABLE te_media_files
    ADD COLUMN IF NOT EXISTS sticker_set_id bigint NOT NULL DEFAULT 0;
ALTER TABLE te_media_files
    ADD COLUMN IF NOT EXISTS sticker_set_access_hash bigint NOT NULL DEFAULT 0;
ALTER TABLE te_media_files
    ADD COLUMN IF NOT EXISTS custom_emoji boolean NOT NULL DEFAULT false;
ALTER TABLE te_media_files
    ADD COLUMN IF NOT EXISTS custom_emoji_alt text NOT NULL DEFAULT '';
