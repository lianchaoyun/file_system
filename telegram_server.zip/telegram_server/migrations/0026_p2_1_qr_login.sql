-- P2-1: QR login tokens used by auth.exportLoginToken / auth.importLoginToken.
CREATE TABLE IF NOT EXISTS te_login_tokens (
    token bytea PRIMARY KEY,
    exporter_auth_key_id bigint NOT NULL,
    api_id integer NOT NULL DEFAULT 0,
    created_at bigint NOT NULL,
    expires_at bigint NOT NULL,
    confirmed_user_id bigint,
    confirmed_at bigint,
    used boolean NOT NULL DEFAULT false
);

CREATE INDEX IF NOT EXISTS te_login_tokens_exporter_idx
    ON te_login_tokens (exporter_auth_key_id, created_at DESC);
