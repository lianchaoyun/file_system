-- P21: real premium content, starting with a selectable emoji status.
ALTER TABLE te_users
    ADD COLUMN IF NOT EXISTS emoji_status_document_id bigint NOT NULL DEFAULT 0;
