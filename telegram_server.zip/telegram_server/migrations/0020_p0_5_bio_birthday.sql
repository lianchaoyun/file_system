-- P0-5: profile bio and birthday.
ALTER TABLE te_users ADD COLUMN IF NOT EXISTS bio text NOT NULL DEFAULT '';
ALTER TABLE te_users ADD COLUMN IF NOT EXISTS birthday_day integer NOT NULL DEFAULT 0;
ALTER TABLE te_users ADD COLUMN IF NOT EXISTS birthday_month integer NOT NULL DEFAULT 0;
ALTER TABLE te_users ADD COLUMN IF NOT EXISTS birthday_year integer NOT NULL DEFAULT 0;
