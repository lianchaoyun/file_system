-- 两步验证（SRP-6a）：账号的密码参数由客户端计算，服务器只保存盐与 verifier。
-- 未启用时 password_verifier 为 NULL。

ALTER TABLE te_users ADD COLUMN IF NOT EXISTS password_srp_id bigint NOT NULL DEFAULT 0;
ALTER TABLE te_users ADD COLUMN IF NOT EXISTS password_salt1 bytea NULL;
ALTER TABLE te_users ADD COLUMN IF NOT EXISTS password_salt2 bytea NULL;
ALTER TABLE te_users ADD COLUMN IF NOT EXISTS password_verifier bytea NULL;
ALTER TABLE te_users ADD COLUMN IF NOT EXISTS password_hint text NOT NULL DEFAULT '';
ALTER TABLE te_users ADD COLUMN IF NOT EXISTS password_g integer NOT NULL DEFAULT 3;
ALTER TABLE te_users ADD COLUMN IF NOT EXISTS password_updated_at bigint NOT NULL DEFAULT 0;
