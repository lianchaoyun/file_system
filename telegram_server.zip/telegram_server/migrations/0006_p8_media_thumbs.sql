-- P8: generated image thumbnails and file hash metadata.
-- thumb_storage_key already exists in 0001; these columns describe the
-- generated thumbnail bytes so RPC serialization does not need to reopen it.
ALTER TABLE te_media_files
    ADD COLUMN IF NOT EXISTS thumb_width integer NOT NULL DEFAULT 0;

ALTER TABLE te_media_files
    ADD COLUMN IF NOT EXISTS thumb_height integer NOT NULL DEFAULT 0;

ALTER TABLE te_media_files
    ADD COLUMN IF NOT EXISTS thumb_size bigint NOT NULL DEFAULT 0;
