$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
Set-Location $root

$env:TSRV_DB_DSN = "postgres://postgres:423522@127.0.0.1:5432/telegram_server"
$env:TSRV_DB_SCHEMA = "test"
$env:TSRV_REDIS_URL = "redis://127.0.0.1:6379/2"
$env:TSRV_MEDIA_DIR = "data/test-media"
$env:TSRV_LISTEN = "127.0.0.1:3801"
$env:TSRV_HEALTH_ADDR = "127.0.0.1:3802"
$env:RUST_LOG = "info"

cargo test --workspace
