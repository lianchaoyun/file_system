$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
Set-Location $root

$env:RUST_LOG = "info"
cargo run -p tsrv-server --bin tsrv-server
