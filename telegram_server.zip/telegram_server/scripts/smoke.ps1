$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
Set-Location $root

$env:TSRV_DB_DSN = "postgres://postgres:423522@127.0.0.1:5432/telegram_server"
$env:TSRV_DB_SCHEMA = "test"
$env:TSRV_REDIS_URL = "redis://127.0.0.1:6379/2"
$env:TSRV_MEDIA_DIR = "data/test-media"
$env:TSRV_LISTEN = "127.0.0.1:3801"
$env:TSRV_HEALTH_ADDR = "127.0.0.1:3802"
$env:RUST_LOG = "info"

New-Item -ItemType Directory -Force "data/test-media" | Out-Null
$outLog = Join-Path $root "data/test-server.out.log"
$errLog = Join-Path $root "data/test-server.err.log"

cargo build -p tsrv-server --bins
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

$exe = Join-Path $root "target\debug\tsrv-server.exe"
$process = Start-Process -FilePath $exe -WorkingDirectory $root -PassThru `
    -RedirectStandardOutput $outLog -RedirectStandardError $errLog

$failed = $true
try {
    $health = $null
    for ($i = 0; $i -lt 40; $i++) {
        Start-Sleep -Milliseconds 250
        try {
            $health = Invoke-RestMethod -Uri "http://127.0.0.1:3802/healthz" -TimeoutSec 2
            break
        } catch {
            if ($process.HasExited) { break }
        }
    }
    if (-not $health) {
        Write-Host "FAIL: health endpoint did not answer"
        Get-Content $errLog -Tail 20 -ErrorAction SilentlyContinue
        exit 1
    }
    if ($health.status -ne "ok" -or -not $health.db -or -not $health.redis) {
        Write-Host "FAIL: health status is not ok: $($health | ConvertTo-Json -Compress)"
        exit 1
    }
    if ($health.schema -ne "test") {
        Write-Host "FAIL: smoke test is not using the test schema: $($health.schema)"
        exit 1
    }

    $client = [System.Net.Sockets.TcpClient]::new()
    $connected = $client.ConnectAsync("127.0.0.1", 3801).Wait(1500)
    $client.Dispose()
    if (-not $connected) {
        Write-Host "FAIL: MTProto listener 3801 is not reachable"
        exit 1
    }

    $client = Join-Path $root "target\debug\tsrv-smoke-client.exe"
    & $client
    if ($LASTEXITCODE -ne 0) {
        Write-Host "FAIL: MTProto login smoke client failed"
        Get-Content $outLog -Tail 30 -ErrorAction SilentlyContinue
        Get-Content $errLog -Tail 30 -ErrorAction SilentlyContinue
        exit 1
    }

    Write-Host "PASS: health ok, db/redis ok, schema=test, MTProto 3801 reachable, login flow ok"
    $failed = $false
} finally {
    if (-not $process.HasExited) {
        Stop-Process -Id $process.Id -Force -ErrorAction SilentlyContinue
        $process.WaitForExit(3000) | Out-Null
    }
}

if ($failed) { exit 1 }
exit 0
