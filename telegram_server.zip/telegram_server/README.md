# telegram_server

Rust 版自建 Telegram 服务端实验项目。

当前状态：**P23 已完成**（P2 私聊、P3 群组/频道、P4 图片/视频、P5 客户端兼容、P6 多设备同步、P7 临时 auth key、P8 缩略图与文件哈希、P9 消息操作、P10 PTS 增量同步、P11 媒体 caption 编辑、P14-P17 基础群/搜索/头像/服务消息/反应/群头像、P18 计划消息、P19 多档缩略图、P20 语言包、P21 运维清理、P22 Premium 贴纸与 emoji 状态、P23 PTS 增量快照）。生产服务仍在 `../owpengram-232`，本项目不会直接修改或替换它。

已支持：

- TCP abridged / intermediate / padded intermediate
- Telegram Desktop / Android tgnet 使用的混淆传输（AES-CTR）
- RSA + DH auth key 握手
- 同一连接上的 persistent / temporary auth key 与 `auth.bindTempAuthKey`
- 临时 auth key 生命周期持久化到 `auth_keys.expires_at`
- temp→perm 绑定持久化到 `temp_auth_key_bindings`，绑定两侧共享 session / update_state
- 临时 key 过期返回 transport `-404`，Telegram Desktop 自动销毁并重建临时 key
- 图片 JPEG 缩略图、`photoSize` s/m/x 多档返回、缩略图下载
- 视频通过 ffmpeg 抽帧生成多档缩略图（`TSRV_FFMPEG` 可指定二进制）
- 消息反应 `messages.sendReaction` 与 `updateMessageReactions`
- 计划消息 `messages.getScheduledHistory` / `sendScheduledMessages` /
  `deleteScheduledMessages`，后台 worker 每 5 秒投递到期消息
- 群/频道头像编辑与 `inputPeerPhotoFileLocation` 下载
- 官方 `zh-hans` / `zh-hant` / `ru` 语言包
- Premium 贴纸集与自定义 emoji 状态（`messages.getStickerSet` /
  `messages.getCustomEmojiDocuments` / `account.updateEmojiStatus`）
- 运维清理 worker、`/admin/stats`、`/admin/maintenance`
- `upload.getFileHashes` 返回 1MB 范围 SHA-256
- 回复（`messageReplyHeader`）、编辑（`updateEditMessage` / `updateEditChannelMessage`）
- 媒体 caption 编辑，编辑保留原 photo/document
- 删除（`messages.deleteMessages` / `channels.deleteMessages`）
- 转发（私聊/频道来源，`messageFwdHeader`；支持 `reply_to`、`drop_media_captions`）
- 置顶（`messages.updatePinnedMessage`，`updatePinnedMessages` / `updatePinnedChannelMessages`）
- `updates.getState` / `updates.getDifference` / `updates.getChannelDifference`
- 持久化 `update_log`，支持离线后按 PTS 补齐更新
- 登录 / 注册、固定验证码
- `help.getConfig`、`help.getNearestDc`、语言包空结果
- 私聊 `messages.sendMessage`
- 会话列表 `messages.getDialogs` / `messages.getPeerDialogs` / `messages.getPinnedDialogs`
- 历史消息 `messages.getHistory`
- 已读 `messages.readHistory`
- `updates.getState` 与实时 `updateNewMessage` / `updateNewChannelMessage` 推送
- 同一账号多设备同步：自己发出的私聊/群组消息实时同步到其他在线 session
- 接收方所有在线 session 同时收到更新，发送连接通过 `exclude_session_id` 去重
- 超级群 `channels.createChannel`（megagroup）
- 广播频道 `channels.createChannel`（broadcast）
- `channels.inviteToChannel` / `joinChannel` / `leaveChannel`
- `channels.getFullChannel` / `getParticipants`
- 群组/频道会话列表、历史消息
- 频道权限：只有所有者可广播，普通成员只读
- 图片/视频：`upload.saveFilePart` / `saveBigFilePart` / `getFile`
- `messages.sendMedia` / `messages.uploadMedia`
- Photo / Document / MessageMedia，PNG/JPEG 尺寸检测，MP4 宽高与时长解析
- 媒体 sha256 校验、分片临时文件清理
- 常用可选 RPC 兼容空结果（主题、贴纸集、表情状态、聊天筛选、国家列表等）
- 会话 / auth key / 消息 / 媒体写入 PostgreSQL
- Telegram Desktop 与 Android 客户端同时在线并接收实时推送

数据库迁移：

```text
migrations/0001_init.sql
migrations/0002_p2_private_chat.sql   # users.pts + messages 索引
migrations/0003_p3_channels.sql       # chats.access_hash / chats.pts
migrations/0004_p4_media.sql          # media_files access_hash / file_reference / owner / file_name
migrations/0005_p7_temp_keys.sql      # auth_keys.expires_at + temp_auth_key_bindings
migrations/0006_p8_media_thumbs.sql   # media_files thumb width/height/size
migrations/0007_p9_message_actions.sql # reply/edit/forward 元数据 + chats.pinned_msg_id
migrations/0008_p10_update_log.sql     # update_log 增量同步日志
migrations/0009_p14_basic_groups.sql   # 基础群 kind + 成员角色
migrations/0010_p15_user_photo.sql     # users.photo_media_id
migrations/0011_p16_service_messages.sql # messages 服务消息字段
migrations/0012_p17_reactions.sql      # message_reactions
migrations/0013_p18_chat_photo.sql     # chats.photo_media_id
migrations/0014_p19_scheduled_messages.sql # messages.scheduled_date
migrations/0015_p19_media_thumbs.sql   # media_thumbs 多档缩略图
migrations/0016_p21_emoji_status.sql   # users.emoji_status_document_id
```

数据库当前使用 `yun` 库的 `public` schema，所有服务端表统一使用 `te_` 前缀
（如 `te_users` / `te_messages` / `te_chats`），不会和 `yun` 里原有的
`users` / `sessions` 等表冲突。旧 `telegram_server.dev` 作为迁移备份保留。

迁移运行器（`te_schema_migrations` 记录已应用版本）：

```powershell
# yun.public（开发/生产）
cargo run -p tsrv-server --bin tsrv-migrate

# telegram_server.test（冒烟测试）
$env:TSRV_DB_DSN = "postgres://postgres:423522@127.0.0.1:5432/telegram_server"
$env:TSRV_DB_SCHEMA = "test"
cargo run -p tsrv-server --bin tsrv-migrate
```

运维配置：

| 环境变量 | 默认值 | 说明 |
|---|---|---|
| `TSRV_UPDATE_LOG_RETENTION_HOURS` | 168 | `update_log` 保留小时数 |
| `TSRV_UPLOAD_PART_TTL_HOURS` | 24 | 残留上传分片保留小时数 |
| `TSRV_MAINTENANCE_INTERVAL_SECS` | 3600 | 清理 worker 间隔 |
| `TSRV_FFMPEG` | `ffmpeg` | 视频抽帧使用的 ffmpeg 路径 |
| `TSRV_STICKER_SEED_DIR` | `data/sticker-seed/status-pack` | Premium 贴纸种子目录 |

管理 / 运维接口（健康端口）：

- `GET /healthz`、`GET /readyz`
- `GET /admin/stats`：用户、会话、消息、媒体、待发送计划消息、update_log、
  auth key、临时绑定、反应数量
- `POST /admin/maintenance`：立即执行一轮清理
- `POST /admin/system-message`：系统助手给指定手机号发送一条私聊消息
- `POST /admin/telegram/send-message`：系统助手给指定 `user_id` 发私聊消息
- `POST /admin/telegram/delete-message`：删除指定会话中的一条消息
- `POST /admin/telegram/kick-user`：从基础群移除成员

设置 `TSRV_ADMIN_TOKEN` 后，所有 `/admin/*` 需要携带
`Authorization: Bearer <token>` 或 `X-Admin-Token: <token>`；未设置时保持本地开发
的开放行为。写操作复用正常 RPC 的 PTS、`te_update_log` 和在线推送。

## 目标

第一版实现：

- 手机号登录 / 注册（固定验证码 `12345`）
- 一对一文本聊天
- 基础群组
- 基础频道
- 图片上传 / 下载
- 视频作为普通文件上传 / 下载
- MTProto Layer 232，兼容现有桌面端和 Android 客户端

第一版不包含：

- 短信 / 邮件 / Passkey / QR 登录
- Bot API
- 音视频通话、直播、TURN/SFU
- 管理后台 UI
- 审核、认证、收藏用户名
- 多 DC、集群、水平扩展

## 技术栈

- Rust + Tokio
- PostgreSQL
- Redis
- 本地文件系统或 S3 兼容存储
- 独立测试端口 `3801`
- 独立数据库 `telegram_server`
- 开发 schema `dev`，测试 schema `test`
- Redis DB `1`（避免影响生产服务）

## 快速开始

```powershell
# 开发模式（读取 .env，schema=dev）
.\scripts\dev.ps1

# 单元测试（schema=test）
.\scripts\test.ps1

# AI 冒烟测试（启动服务、检查 DB/Redis/3801/3802、完整握手与登录）
.\scripts\smoke.ps1
```

健康检查：

```text
http://127.0.0.1:3802/healthz
```

测试账号：

```text
A：+1 415 555 0100
B：+1 415 555 0101
验证码：12345
```

真实桌面端测试配置目录：

```text
E:\game\Telegram\users\desktop-rust-test
```

该目录使用独立的 `tdata`，指向 `127.0.0.1:3801`，不影响 `users\desktop-main`。

Android 测试（LDPlayer14）：

```powershell
# 安装 APK
E:\game\leidian\LDPlayer14\adb.exe install -r E:\game\Telegram\ta_telegram\dist\telegram-afat-debug-selfhost.apk

# 将模拟器 localhost:3801 映射到主机
E:\game\leidian\LDPlayer14\adb.exe reverse tcp:3801 tcp:3801
```

在登录页点击“服务器”，填写 `127.0.0.1:3801`，然后使用测试手机号和验证码 `12345` 登录。

已知限制：LDPlayer14 Android 14 镜像在频繁 UI 操作后可能触发 `Too many Binders sent to SYSTEM`，导致 Telegram 进程被系统杀死；这是模拟器限制，不代表服务端崩溃。

## 文档

- [总体架构](docs/01-architecture.md)
- [第一版范围与 RPC](docs/02-mvp-scope.md)
- [数据模型](docs/03-data-model.md)
- [测试与冒烟方案](docs/04-test-plan.md)
- [实现路线图](docs/05-roadmap.md)
- [第一版发布说明](docs/06-release-notes.md)

## 目录

```text
telegram_server/
  Cargo.toml
  crates/
    tl/        TL 类型与序列化
    mtproto/   MTProto 握手、加密、session
    store/     PostgreSQL / Redis
    domain/    业务逻辑
    server/    TCP 服务与 RPC 分发
  migrations/
  docs/
  config/
  scripts/
```

## 开发原则

- 不碰生产 `2398`、不碰 `telesrv_main`、不碰 `users/desktop-main`
- 测试服务使用 `3801`
- 测试使用 `telegram_server` 的 `test` schema，开发使用 `dev` schema
- 每次阶段结束必须通过 `cargo test` 和 `scripts/smoke`（后续加入）
- 桌面端 / Android 真机测试在 AI 冒烟通过后进行
