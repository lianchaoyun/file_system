//! Group and broadcast channel services.
//!
//! Implemented in roadmap phase P3.
