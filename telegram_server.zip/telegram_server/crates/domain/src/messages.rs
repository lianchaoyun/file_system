//! Dialog and message services.
//!
//! Implemented in roadmap phase P2.
