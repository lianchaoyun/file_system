//! Business services: auth, users, dialogs, messages, channels and media.
//!
//! This crate is deliberately independent from TCP transport and TL encoding;
//! the server crate translates RPC requests into these service calls.

pub mod auth;
pub mod channels;
pub mod messages;
