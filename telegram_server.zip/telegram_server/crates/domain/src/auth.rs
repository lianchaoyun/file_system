//! Authentication services (phone code, sign-in, sign-up).
//!
//! Implemented in roadmap phase P1.
