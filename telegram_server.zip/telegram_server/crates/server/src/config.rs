use std::{env, net::SocketAddr, path::PathBuf};

use anyhow::{bail, Context, Result};

#[derive(Clone, Debug)]
pub struct Config {
    pub listen: SocketAddr,
    pub health_addr: SocketAddr,
    pub db_dsn: String,
    pub db_schema: String,
    pub redis_url: String,
    pub media_dir: PathBuf,
    pub langpack_dir: PathBuf,
    pub sticker_seed_dir: PathBuf,
    pub rsa_key: PathBuf,
    pub fixed_auth_code: String,
    /// When set, every `/admin/*` request must present this token.
    pub admin_token: Option<String>,
    pub update_log_retention_hours: i64,
    pub upload_part_ttl_hours: i64,
    pub maintenance_interval_secs: u64,
}

impl Config {
    pub fn from_env() -> Result<Self> {
        let listen = socket_from_env("TSRV_LISTEN", "127.0.0.1:3801")?;
        let health_addr = socket_from_env("TSRV_HEALTH_ADDR", "127.0.0.1:3802")?;
        let db_dsn = env::var("TSRV_DB_DSN").context("TSRV_DB_DSN is required")?;
        let db_schema = env::var("TSRV_DB_SCHEMA").unwrap_or_else(|_| "dev".to_owned());
        tsrv_store::validate_schema(&db_schema)?;
        let redis_url =
            env::var("TSRV_REDIS_URL").unwrap_or_else(|_| "redis://127.0.0.1:6379/1".to_owned());
        let media_dir =
            PathBuf::from(env::var("TSRV_MEDIA_DIR").unwrap_or_else(|_| "data/media".to_owned()));
        let langpack_dir = PathBuf::from(
            env::var("TSRV_LANGPACK_DIR").unwrap_or_else(|_| "data/langpacks".to_owned()),
        );
        let sticker_seed_dir = PathBuf::from(
            env::var("TSRV_STICKER_SEED_DIR")
                .unwrap_or_else(|_| "data/sticker-seed/status-pack".to_owned()),
        );
        let rsa_key = PathBuf::from(
            env::var("TSRV_RSA_KEY")
                .unwrap_or_else(|_| "../owpengram-232/data/server_rsa.pem".to_owned()),
        );
        let fixed_auth_code =
            env::var("TSRV_FIXED_AUTH_CODE").unwrap_or_else(|_| "12345".to_owned());
        let admin_token = env::var("TSRV_ADMIN_TOKEN")
            .ok()
            .map(|value| value.trim().to_owned())
            .filter(|value| !value.is_empty());
        let update_log_retention_hours =
            positive_u64_from_env("TSRV_UPDATE_LOG_RETENTION_HOURS", 168)?;
        let upload_part_ttl_hours = positive_u64_from_env("TSRV_UPLOAD_PART_TTL_HOURS", 24)?;
        let maintenance_interval_secs =
            positive_u64_from_env("TSRV_MAINTENANCE_INTERVAL_SECS", 3600)?;
        if fixed_auth_code.len() != 5 || !fixed_auth_code.chars().all(|c| c.is_ascii_digit()) {
            bail!("TSRV_FIXED_AUTH_CODE must be exactly 5 digits");
        }
        if !rsa_key.exists() {
            bail!("TSRV_RSA_KEY does not exist: {}", rsa_key.display());
        }

        Ok(Self {
            listen,
            health_addr,
            db_dsn,
            db_schema,
            redis_url,
            media_dir,
            langpack_dir,
            sticker_seed_dir,
            rsa_key,
            fixed_auth_code,
            admin_token,
            update_log_retention_hours: update_log_retention_hours as i64,
            upload_part_ttl_hours: upload_part_ttl_hours as i64,
            maintenance_interval_secs,
        })
    }
}

fn positive_u64_from_env(key: &str, default: u64) -> Result<u64> {
    let raw = env::var(key).unwrap_or_else(|_| default.to_string());
    let value = raw
        .parse::<u64>()
        .with_context(|| format!("invalid positive integer in {key}: {raw}"))?;
    if value == 0 {
        bail!("{key} must be greater than zero");
    }
    Ok(value)
}

fn socket_from_env(key: &str, default: &str) -> Result<SocketAddr> {
    let value = env::var(key).unwrap_or_else(|_| default.to_owned());
    value
        .parse()
        .with_context(|| format!("invalid socket address in {key}: {value}"))
}

#[cfg(test)]
mod tests {
    use super::socket_from_env;

    #[test]
    fn default_socket_is_valid() {
        // Use a key that is unlikely to be set by the developer environment.
        assert!(socket_from_env("TSRV_TEST_UNSET_SOCKET", "127.0.0.1:3801").is_ok());
    }

    #[test]
    fn invalid_socket_is_rejected() {
        assert!(socket_from_env("TSRV_TEST_UNSET_SOCKET", "not-a-socket").is_err());
    }
}
