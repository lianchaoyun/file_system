//! In-process presence tracking for online/offline status.
//!
//! Every authenticated MTProto connection registers its `(auth_key_id,
//! session_id)` pair. A user is online while at least one session is
//! registered. Because a single server process owns all connections, the
//! tracker lives in memory; `te_users.last_seen_at` persists the last
//! disconnect so clients still see a meaningful `userStatusOffline` after a
//! restart.

use std::collections::{HashMap, HashSet};
use std::sync::{Mutex, OnceLock};

pub type SessionKey = (i64, i64);

#[derive(Default)]
pub struct PresenceTracker {
    sessions: Mutex<HashMap<i64, HashSet<SessionKey>>>,
}

impl PresenceTracker {
    /// Registers a session. Returns `true` when the user became online (this
    /// was the first active session).
    pub fn mark_online(&self, user_id: i64, session: SessionKey) -> bool {
        let mut sessions = self.lock();
        let set = sessions.entry(user_id).or_default();
        let was_offline = set.is_empty();
        set.insert(session);
        was_offline
    }

    /// Removes a session. Returns `true` when the user became offline (the
    /// last active session was removed).
    pub fn mark_offline(&self, user_id: i64, session: SessionKey) -> bool {
        let mut sessions = self.lock();
        let Some(set) = sessions.get_mut(&user_id) else {
            return false;
        };
        if !set.remove(&session) {
            return false;
        }
        if set.is_empty() {
            sessions.remove(&user_id);
            true
        } else {
            false
        }
    }

    pub fn is_online(&self, user_id: i64) -> bool {
        self.lock()
            .get(&user_id)
            .is_some_and(|sessions| !sessions.is_empty())
    }

    fn lock(&self) -> std::sync::MutexGuard<'_, HashMap<i64, HashSet<SessionKey>>> {
        self.sessions.lock().unwrap_or_else(|poisoned| poisoned.into_inner())
    }
}

static PRESENCE: OnceLock<PresenceTracker> = OnceLock::new();

pub fn global() -> &'static PresenceTracker {
    PRESENCE.get_or_init(PresenceTracker::default)
}

pub fn is_online(user_id: i64) -> bool {
    global().is_online(user_id)
}
