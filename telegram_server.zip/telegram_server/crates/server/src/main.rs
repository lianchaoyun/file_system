mod config;
mod health;
mod bot_api;
mod langpack;
mod maintenance;
mod media;
mod mtproto_listener;
mod presence;
mod repo;
mod rpc;
mod srp;
mod stickers;
mod storage;
mod update_hub;

use std::sync::Arc;

use anyhow::Result;
use tokio::net::TcpListener;
use tokio::sync::watch;
use tracing_subscriber::EnvFilter;
use tsrv_mtproto::crypto::RsaKey;

use crate::config::Config;
use crate::langpack::LangPacks;
use crate::mtproto_listener::AppState;
use crate::update_hub::UpdateHub;

#[tokio::main]
async fn main() -> Result<()> {
    dotenvy::dotenv().ok();
    let config = Config::from_env()?;
    init_tracing();

    tracing::info!(
        listen = %config.listen,
        health = %config.health_addr,
        schema = %config.db_schema,
        admin_auth = config.admin_token.is_some(),
        "starting tsrv-server"
    );

    let db = tsrv_store::Db::connect(&config.db_dsn, &config.db_schema).await?;
    db.ping().await?;
    let cache = tsrv_store::Cache::connect(&config.redis_url).await?;
    cache.ping().await?;
    tokio::fs::create_dir_all(&config.media_dir).await?;
    let rsa = Arc::new(RsaKey::from_pkcs1_pem_file(&config.rsa_key)?);
    tracing::info!(fingerprint = rsa.fingerprint(), "loaded server RSA key");
    let langpacks = Arc::new(LangPacks::load(&config.langpack_dir)?);
    let system_user = repo::ensure_system_user(&db).await?;
    tracing::info!(id = system_user.id, phone = %system_user.phone, "system assistant ready");
    stickers::ensure_seeded(&db, &config.media_dir, &config.sticker_seed_dir).await?;

    let health_listener = TcpListener::bind(config.health_addr).await?;
    let mtproto_listener = TcpListener::bind(config.listen).await?;
    let (shutdown_tx, shutdown_rx) = watch::channel(false);
    let updates = UpdateHub::new();
    let maintenance_config = maintenance::MaintenanceConfig {
        update_log_retention_seconds: config.update_log_retention_hours * 3600,
        upload_part_ttl_seconds: config.upload_part_ttl_hours * 3600,
    };

    let maintenance_db = db.clone();
    let maintenance_media_dir = config.media_dir.clone();
    let maintenance_interval = config.maintenance_interval_secs;
    let mtproto_state = AppState {
        db,
        cache,
        config: Arc::new(config.clone()),
        rsa,
        langpacks,
        updates,
    };
    let health_state = health::HealthState {
        app: mtproto_state.clone(),
        db: mtproto_state.db.clone(),
        cache: mtproto_state.cache.clone(),
        schema: config.db_schema.clone(),
        updates: mtproto_state.updates.clone(),
        media_dir: config.media_dir.clone(),
        maintenance: maintenance_config.clone(),
    };
    let scheduled_state = mtproto_state.clone();
    let health_shutdown = shutdown_rx.clone();
    let health_task = tokio::spawn(async move {
        axum::serve(health_listener, health::router(health_state))
            .with_graceful_shutdown(wait_for_shutdown(health_shutdown))
            .await
    });
    let mtproto_task = tokio::spawn(mtproto_listener::run(
        mtproto_listener,
        mtproto_state,
        shutdown_rx,
    ));
    let scheduled_shutdown = shutdown_tx.subscribe();
    let scheduled_task = tokio::spawn(async move {
        let mut ticker = tokio::time::interval(std::time::Duration::from_secs(5));
        let mut shutdown = scheduled_shutdown;
        loop {
            tokio::select! {
                _ = ticker.tick() => {
                    if let Err(error) = rpc::deliver_due_scheduled(&scheduled_state).await {
                        tracing::warn!("scheduled message delivery failed: {error:?}");
                    }
                }
                _ = shutdown.changed() => break,
            }
        }
    });
    let maintenance_shutdown = shutdown_tx.subscribe();
    let maintenance_task = tokio::spawn(async move {
        let mut ticker =
            tokio::time::interval(std::time::Duration::from_secs(maintenance_interval));
        let mut shutdown = maintenance_shutdown;
        loop {
            tokio::select! {
                _ = ticker.tick() => {
                    if let Err(error) = maintenance::run_once(
                        &maintenance_db,
                        &maintenance_media_dir,
                        &maintenance_config,
                    )
                    .await
                    {
                        tracing::warn!("maintenance run failed: {error:?}");
                    }
                }
                _ = shutdown.changed() => break,
            }
        }
    });

    tracing::info!("health endpoint listening on http://{}", config.health_addr);
    tracing::info!("MTProto listening on {}", config.listen);
    tracing::info!("media directory: {}", config.media_dir.display());
    tracing::info!("langpack directory: {}", config.langpack_dir.display());
    tracing::info!("rsa key: {}", config.rsa_key.display());

    tokio::signal::ctrl_c().await?;
    let _ = shutdown_tx.send(true);
    let _ = health_task.await;
    let _ = mtproto_task.await;
    let _ = scheduled_task.await;
    let _ = maintenance_task.await;
    tracing::info!("tsrv-server stopped");
    Ok(())
}

fn init_tracing() {
    let filter = EnvFilter::try_from_default_env().unwrap_or_else(|_| EnvFilter::new("info"));
    tracing_subscriber::fmt()
        .with_env_filter(filter)
        .with_target(true)
        .init();
}

async fn wait_for_shutdown(mut shutdown: watch::Receiver<bool>) {
    let _ = shutdown.changed().await;
}
