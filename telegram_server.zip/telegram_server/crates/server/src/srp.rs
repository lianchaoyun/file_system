//! 两步验证使用的 Telegram SRP-6a 实现（SHA-256 + 2048 位 MODP 群）。
//!
//! 服务器不派生密码哈希：客户端在 `account.updatePasswordSettings` 中直接
//! 提交 `v = g^x mod p`（`new_password_hash`），登录时服务器用保存的 `v`
//! 校验客户端给出的 `M1`。会话级的 `b` 与待登录用户暂存在内存中，10 分钟
//! 内有效。

use std::collections::HashMap;
use std::sync::{Mutex, OnceLock};
use std::time::{SystemTime, UNIX_EPOCH};

use num_bigint::BigUint;
use num_traits::Zero;
use rand::Rng;
use sha2::{Digest, Sha256};

/// Telegram 两步验证使用的 2048 位安全素数。
const P_HEX: &str = concat!(
    "C71CAEB9C6B1C9048E6C522F70F13F73980D40238E3E21C1",
    "4934D037563D930F48198A0AA7C14058229493D22530F4DB",
    "FA336F6E0AC925139543AED44CCE7C3720FD51F69458705A",
    "C68CD4FE6B6B13ABDC9746512969328454F18FAF8C595F64",
    "2477FE96BB2A941D5BCD1D4AC8CC49880708FA9B378E3C4F",
    "3A9060BEE67CF9A4A4A695811051907E162753B56B0F6B41",
    "0DBA74D8A84B2A14B3144E0EF1284754FD17ED950D5965B4",
    "B9DD46582DB1178D169C6BC465B0D6FF9CA3928FEF5B9AE",
    "4E418FC15E83EBEA0F87FA9FF5EED70050DED2849F47BF95",
    "9D956850CE929851F0D8115F635B105EE2E4E15D04B2454B",
    "F6F4FADF034B10403119CD8E3B92FCC5B",
);

/// Telegram 客户端的固定盐值：新密码的 salt1 = `ALGO_SALT1 + 32 字节随机数`。
pub const ALGO_SALT1: &[u8] = &[0xEC, 0xF8, 0x73, 0x76, 0x65, 0xBC, 0x77, 0x5A];
/// 固定的 salt2。
pub const ALGO_SALT2: &[u8] = &[
    0xBE, 0xDE, 0x48, 0x88, 0x8C, 0x0F, 0x42, 0xAC, 0x34, 0xFF, 0xD1, 0xD4, 0x93, 0x5D, 0x8B, 0x21,
];
/// Passport（`new_secure_algo`）使用的固定盐值。
pub const SECURE_SALT: &[u8] = &[0x7D, 0x04, 0xB3, 0x4B, 0x94, 0x82, 0x8C, 0x3D];

const PAD_BYTES: usize = 256;
const STATE_TTL_SECS: u64 = 600;
const PENDING_TTL_SECS: u64 = 1800;
const DEFAULT_G: u32 = 3;

struct SrpState {
    user_id: i64,
    b: BigUint,
    /// `g_b = (k * v + g^b) mod p`，已补零到 256 字节。
    b_bytes: Vec<u8>,
    verifier: BigUint,
    salt1: Vec<u8>,
    salt2: Vec<u8>,
    g: u32,
    created: u64,
}

struct PendingLogin {
    user_id: i64,
    expires: u64,
}

fn states() -> &'static Mutex<HashMap<i64, SrpState>> {
    static STATES: OnceLock<Mutex<HashMap<i64, SrpState>>> = OnceLock::new();
    STATES.get_or_init(|| Mutex::new(HashMap::new()))
}

fn pending_logins() -> &'static Mutex<HashMap<i64, PendingLogin>> {
    static PENDING: OnceLock<Mutex<HashMap<i64, PendingLogin>>> = OnceLock::new();
    PENDING.get_or_init(|| Mutex::new(HashMap::new()))
}

fn lock<T>(mutex: &Mutex<T>) -> std::sync::MutexGuard<'_, T> {
    mutex.lock().unwrap_or_else(|error| error.into_inner())
}

fn now_secs() -> u64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|duration| duration.as_secs())
        .unwrap_or(0)
}

fn prime() -> &'static BigUint {
    static PRIME: OnceLock<BigUint> = OnceLock::new();
    PRIME.get_or_init(|| {
        BigUint::parse_bytes(P_HEX.as_bytes(), 16).expect("embedded SRP prime is valid hex")
    })
}

/// 2048 位素数 `p` 的字节表示（大端，256 字节）。
pub fn prime_bytes() -> Vec<u8> {
    padded_or(&prime().to_bytes_be())
}

/// 校验客户端提交的 `passwordKdfAlgo` 是否与服务器使用的参数一致。
/// 新密码的 salt1 必须是在 `ALGO_SALT1` 后追加 32 字节随机数。
pub fn supported_algo(salt1: &[u8], salt2: &[u8], g: i32, p: &[u8]) -> bool {
    salt2 == ALGO_SALT2
        && salt1.len() == ALGO_SALT1.len() + 32
        && salt1.starts_with(ALGO_SALT1)
        && p == prime_bytes().as_slice()
        && g == DEFAULT_G as i32
}

/// verifier 必须满足 `0 < v < p`。
pub fn valid_verifier(verifier: &[u8]) -> bool {
    if verifier.is_empty() || verifier.len() > PAD_BYTES {
        return false;
    }
    let value = BigUint::from_bytes_be(verifier);
    !value.is_zero() && &value < prime()
}

fn padded_or(value: &[u8]) -> Vec<u8> {
    pad256(value).unwrap_or_else(|| value.to_vec())
}

fn pad256(value: &[u8]) -> Option<Vec<u8>> {
    if value.len() > PAD_BYTES {
        return None;
    }
    let mut padded = vec![0u8; PAD_BYTES - value.len()];
    padded.extend_from_slice(value);
    Some(padded)
}

fn padded_g(g: u32) -> Vec<u8> {
    padded_or(&g.to_be_bytes())
}

fn normalize_g(g: i32) -> u32 {
    if (2..=7).contains(&g) {
        g as u32
    } else {
        DEFAULT_G
    }
}

fn sha256(parts: &[&[u8]]) -> [u8; 32] {
    let mut hasher = Sha256::new();
    for part in parts {
        hasher.update(part);
    }
    hasher.finalize().into()
}

fn xor_hashes(left: [u8; 32], right: [u8; 32]) -> [u8; 32] {
    let mut value = left;
    for (slot, other) in value.iter_mut().zip(right.iter()) {
        *slot ^= *other;
    }
    value
}

fn constant_time_eq(left: &[u8], right: &[u8]) -> bool {
    if left.len() != right.len() {
        return false;
    }
    let mut diff = 0u8;
    for (a, b) in left.iter().zip(right.iter()) {
        diff |= a ^ b;
    }
    diff == 0
}

fn random_2048() -> BigUint {
    let mut rng = rand::thread_rng();
    loop {
        let mut bytes = [0u8; PAD_BYTES];
        rng.fill(&mut bytes[..]);
        let value = BigUint::from_bytes_be(&bytes);
        if !value.is_zero() {
            return value;
        }
    }
}

/// 生成新的 `srp_id`（正数且非零）。
pub fn new_srp_id() -> i64 {
    let value = rand::random::<i64>() & i64::MAX;
    if value == 0 {
        1
    } else {
        value
    }
}

fn prune_states() {
    let cutoff = now_secs().saturating_sub(STATE_TTL_SECS);
    let mut guard = lock(states());
    guard.retain(|_, state| state.created >= cutoff);
}

/// 为一次 SRP 校验生成服务器端参数，返回 `(srp_id, g_b)`。
pub fn start(user_id: i64, salt1: &[u8], salt2: &[u8], g: i32, verifier: &[u8]) -> (i64, Vec<u8>) {
    let p = prime();
    let g = normalize_g(g);
    let verifier = BigUint::from_bytes_be(verifier);
    let k = BigUint::from_bytes_be(&sha256(&[&prime_bytes(), &padded_g(g)]));
    let b = random_2048();
    let kv = (k * &verifier) % p;
    let b_public = (kv + BigUint::from(g).modpow(&b, p)) % p;
    let b_bytes = padded_or(&b_public.to_bytes_be());
    let srp_id = new_srp_id();

    prune_states();
    lock(states()).insert(
        srp_id,
        SrpState {
            user_id,
            b,
            b_bytes: b_bytes.clone(),
            verifier,
            salt1: salt1.to_vec(),
            salt2: salt2.to_vec(),
            g,
            created: now_secs(),
        },
    );
    (srp_id, b_bytes)
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum CheckError {
    /// `srp_id` 已过期或与当前用户不匹配。
    SrpIdInvalid,
    /// M1 校验失败（密码错误）。
    PasswordInvalid,
}

/// 校验客户端提交的 `A` 与 `M1`。成功后该 `srp_id` 立即失效。
pub fn check(srp_id: i64, user_id: i64, a: &[u8], m1: &[u8]) -> Result<(), CheckError> {
    let p = prime();
    let mut guard = lock(states());
    let Some(state) = guard.get(&srp_id) else {
        return Err(CheckError::SrpIdInvalid);
    };
    if state.user_id != user_id {
        return Err(CheckError::SrpIdInvalid);
    }
    let Some(a_padded) = pad256(a) else {
        return Err(CheckError::PasswordInvalid);
    };
    let a_value = BigUint::from_bytes_be(&a_padded);
    if a_value.is_zero() || &a_value >= p {
        return Err(CheckError::PasswordInvalid);
    }
    let u = BigUint::from_bytes_be(&sha256(&[&a_padded, &state.b_bytes]));
    if u.is_zero() {
        return Err(CheckError::PasswordInvalid);
    }
    let v_u = state.verifier.modpow(&u, p);
    let base = (&a_value * v_u) % p;
    let shared = base.modpow(&state.b, p);
    let shared_padded = padded_or(&shared.to_bytes_be());
    let k_a = sha256(&[&shared_padded]);
    let xor_header = xor_hashes(sha256(&[&prime_bytes()]), sha256(&[&padded_g(state.g)]));
    let expected = sha256(&[
        xor_header.as_slice(),
        &sha256(&[state.salt1.as_slice()]),
        &sha256(&[state.salt2.as_slice()]),
        &a_padded,
        &state.b_bytes,
        &k_a,
    ]);
    let valid = constant_time_eq(&expected, m1);
    if valid {
        guard.remove(&srp_id);
        Ok(())
    } else {
        Err(CheckError::PasswordInvalid)
    }
}

/// 密码变更后让该用户所有旧的 SRP 会话失效。
pub fn invalidate_user(user_id: i64) {
    let mut guard = lock(states());
    guard.retain(|_, state| state.user_id != user_id);
}

/// 记录等待输入两步验证密码的登录（按 auth_key 关联）。
pub fn set_pending(auth_key_id: i64, user_id: i64) {
    let mut guard = lock(pending_logins());
    guard.retain(|_, entry| entry.expires > now_secs());
    guard.insert(
        auth_key_id,
        PendingLogin {
            user_id,
            expires: now_secs() + PENDING_TTL_SECS,
        },
    );
}

pub fn pending_user(auth_key_id: i64) -> Option<i64> {
    let mut guard = lock(pending_logins());
    match guard.get(&auth_key_id) {
        Some(entry) if entry.expires > now_secs() => Some(entry.user_id),
        Some(_) => {
            guard.remove(&auth_key_id);
            None
        }
        None => None,
    }
}

pub fn clear_pending(auth_key_id: i64) {
    lock(pending_logins()).remove(&auth_key_id);
}

#[cfg(test)]
mod tests {
    use super::*;

    /// Python `hashlib` 计算的参考值：
    /// password = "test-password", salt1 = ALGO_SALT1 + 32*0x11, salt2 = ALGO_SALT2。
    const X_HEX: &str = "fa289a79846c86ddccab96afb7f845e2a1dcc29417a702202487049c39e84678";

    fn test_salt1() -> Vec<u8> {
        let mut salt1 = ALGO_SALT1.to_vec();
        salt1.extend_from_slice(&[0x11u8; 32]);
        salt1
    }

    fn x_value() -> BigUint {
        BigUint::parse_bytes(X_HEX.as_bytes(), 16).expect("reference x is valid hex")
    }

    fn verifier(x: &BigUint) -> Vec<u8> {
        padded_or(&BigUint::from(3u32).modpow(x, prime()).to_bytes_be())
    }

    /// 模拟客户端的 SRP 计算，返回 `(A, M1)`。
    fn client_proof(
        salt1: &[u8],
        salt2: &[u8],
        b_bytes: &[u8],
        x: &BigUint,
    ) -> (Vec<u8>, [u8; 32]) {
        let g = 3u32;
        let p = prime();
        let k = BigUint::from_bytes_be(&sha256(&[&prime_bytes(), &padded_g(g)]));
        let v = BigUint::from(g).modpow(x, p);
        let kv = (k * &v) % p;
        let b = BigUint::from_bytes_be(b_bytes);
        let t = if b >= kv {
            (&b - &kv) % p
        } else {
            (&b + p - &kv) % p
        };
        let a = BigUint::from(0x0102_0304_0506_0708u64);
        let a_public = BigUint::from(g).modpow(&a, p);
        let a_public_padded = padded_or(&a_public.to_bytes_be());
        let u = BigUint::from_bytes_be(&sha256(&[&a_public_padded, b_bytes]));
        let shared = t.modpow(&(&a + &u * x), p);
        let shared_padded = padded_or(&shared.to_bytes_be());
        let k_a = sha256(&[&shared_padded]);
        let xor_header = xor_hashes(sha256(&[&prime_bytes()]), sha256(&[&padded_g(g)]));
        let m1 = sha256(&[
            xor_header.as_slice(),
            &sha256(&[salt1]),
            &sha256(&[salt2]),
            &a_public_padded,
            b_bytes,
            &k_a,
        ]);
        (a_public_padded, m1)
    }

    #[test]
    fn correct_password_is_accepted() {
        let salt1 = test_salt1();
        let salt2 = ALGO_SALT2;
        let x = x_value();
        let user_id = 700_001;
        invalidate_user(user_id);
        let (srp_id, b_bytes) = start(user_id, &salt1, salt2, 3, &verifier(&x));
        let (a, m1) = client_proof(&salt1, salt2, &b_bytes, &x);
        assert_eq!(check(srp_id, user_id, &a, &m1), Ok(()));
        // 成功校验后旧的 srp_id 必须失效。
        assert_eq!(
            check(srp_id, user_id, &a, &m1),
            Err(CheckError::SrpIdInvalid)
        );
    }

    #[test]
    fn wrong_password_is_rejected() {
        let salt1 = test_salt1();
        let salt2 = ALGO_SALT2;
        let user_id = 700_002;
        invalidate_user(user_id);
        let (srp_id, b_bytes) = start(user_id, &salt1, salt2, 3, &verifier(&x_value()));
        let (a, m1) = client_proof(&salt1, salt2, &b_bytes, &BigUint::from(123_456_789u64));
        assert_eq!(
            check(srp_id, user_id, &a, &m1),
            Err(CheckError::PasswordInvalid)
        );
    }

    #[test]
    fn unknown_srp_id_is_rejected() {
        let salt1 = test_salt1();
        let salt2 = ALGO_SALT2;
        let user_id = 700_003;
        invalidate_user(user_id);
        let x = x_value();
        let (srp_id, b_bytes) = start(user_id, &salt1, salt2, 3, &verifier(&x));
        let (a, m1) = client_proof(&salt1, salt2, &b_bytes, &x);
        assert_eq!(
            check(srp_id + 1, user_id, &a, &m1),
            Err(CheckError::SrpIdInvalid)
        );
    }

    #[test]
    fn supports_expected_algo() {
        let salt1 = test_salt1();
        assert!(supported_algo(&salt1, ALGO_SALT2, 3, &prime_bytes()));
        assert!(!supported_algo(ALGO_SALT1, ALGO_SALT2, 3, &prime_bytes()));
        assert!(!supported_algo(&salt1, ALGO_SALT2, 3, &[1, 2, 3]));
        assert!(!supported_algo(&salt1, ALGO_SALT2, 9, &prime_bytes()));
        assert!(!supported_algo(&salt1, &[1, 2], 3, &prime_bytes()));
    }

    #[test]
    fn verifier_bounds_are_checked() {
        assert!(valid_verifier(&verifier(&x_value())));
        assert!(!valid_verifier(&[]));
        assert!(!valid_verifier(&[0u8; 256]));
        assert!(!valid_verifier(&[0xFFu8; 256]));
    }
}
