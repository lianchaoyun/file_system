﻿//! Built-in premium sticker / custom-emoji pack seeded from
//! `data/sticker-seed/status-pack` (exported from Telegram's default
//! animated status pack).

use std::path::Path;
use std::sync::OnceLock;

use anyhow::{Context, Result};
use serde_json::Value;
use sha2::{Digest, Sha256};
use tsrv_store::Db;
use tsrv_tl::types;

#[derive(Debug, Clone)]
pub struct StickerDocument {
    pub id: i64,
    pub access_hash: i64,
    pub file_reference: Vec<u8>,
    pub mime_type: String,
    pub size: i64,
    pub alt: String,
    pub text_color: bool,
    pub custom_emoji: bool,
    pub width: i32,
    pub height: i32,
    pub file_name: String,
    pub date: i32,
}

#[derive(Debug, Clone)]
pub struct StickerPack {
    pub id: i64,
    pub access_hash: i64,
    pub title: String,
    pub short_name: String,
    pub hash: i32,
    pub emojis: bool,
    pub packs: Vec<(String, Vec<i64>)>,
    pub documents: Vec<StickerDocument>,
}

static SEED: OnceLock<StickerPack> = OnceLock::new();

pub fn pack() -> Option<&'static StickerPack> {
    SEED.get()
}

pub async fn ensure_seeded(db: &Db, media_dir: &Path, seed_dir: &Path) -> Result<()> {
    if SEED.get().is_some() {
        return Ok(());
    }
    let info_path = seed_dir.join("set_info.json");
    if !info_path.exists() {
        tracing::warn!(path = %info_path.display(), "sticker seed is missing, skipping");
        return Ok(());
    }
    let info: Value = serde_json::from_str(
        &std::fs::read_to_string(&info_path)
            .with_context(|| format!("read sticker seed {}", info_path.display()))?,
    )
    .context("parse sticker seed")?;
    let result = &info["result"];
    let set = &result["set"];
    let id = set["id"].as_i64().context("sticker set id")?;
    let access_hash = set["access_hash"].as_i64().context("sticker set access")?;
    let title = set["title"].as_str().unwrap_or("Status Pack").to_owned();
    let short_name = set["short_name"]
        .as_str()
        .unwrap_or("StatusPack")
        .to_owned();
    let hash = set["hash"].as_i64().unwrap_or(0) as i32;
    let emojis = set["emojis"].as_bool().unwrap_or(false);
    let mut packs = Vec::new();
    if let Some(items) = result["packs"].as_array() {
        for item in items {
            let emoticon = item["emoticon"].as_str().unwrap_or_default().to_owned();
            let ids = item["documents"]
                .as_array()
                .map(|ids| ids.iter().filter_map(Value::as_i64).collect())
                .unwrap_or_default();
            packs.push((emoticon, ids));
        }
    }
    let mut documents = Vec::new();
    if let Some(items) = result["documents"].as_array() {
        for item in items {
            let doc_id = item["id"].as_i64().context("sticker document id")?;
            let doc_access = item["access_hash"]
                .as_i64()
                .context("sticker document access")?;
            let mut alt = String::new();
            let mut text_color = false;
            let mut custom_emoji = false;
            let mut width = 512;
            let mut height = 512;
            let mut file_name = String::from("AnimatedSticker.tgs");
            if let Some(attributes) = item["attributes"].as_array() {
                for attribute in attributes {
                    match attribute["_"].as_str().unwrap_or_default() {
                        "DocumentAttributeCustomEmoji" => {
                            custom_emoji = true;
                            alt = attribute["alt"].as_str().unwrap_or_default().to_owned();
                            text_color = attribute["text_color"].as_bool().unwrap_or(false);
                        }
                        "DocumentAttributeSticker" => {
                            alt = attribute["alt"].as_str().unwrap_or_default().to_owned();
                        }
                        "DocumentAttributeImageSize" => {
                            width = attribute["w"].as_i64().unwrap_or(512) as i32;
                            height = attribute["h"].as_i64().unwrap_or(512) as i32;
                        }
                        "DocumentAttributeFilename" => {
                            if let Some(name) = attribute["file_name"].as_str() {
                                file_name = name.to_owned();
                            }
                        }
                        _ => {}
                    }
                }
            }
            documents.push(StickerDocument {
                id: doc_id,
                access_hash: doc_access,
                file_reference: document_reference(doc_id),
                mime_type: item["mime_type"]
                    .as_str()
                    .unwrap_or("application/x-tgsticker")
                    .to_owned(),
                size: item["size"].as_i64().unwrap_or(0),
                alt,
                text_color,
                custom_emoji,
                width,
                height,
                file_name,
                date: 0,
            });
        }
    }
    let seed_pack = StickerPack {
        id,
        access_hash,
        title,
        short_name,
        hash,
        emojis,
        packs,
        documents,
    };
    seed_documents(db, media_dir, seed_dir, &seed_pack).await?;
    let _ = SEED.set(seed_pack);
    tracing::info!(
        sticker_set_id = id,
        documents = SEED.get().map(|pack| pack.documents.len()).unwrap_or(0),
        "premium sticker pack ready"
    );
    Ok(())
}

async fn seed_documents(
    db: &Db,
    media_dir: &Path,
    seed_dir: &Path,
    pack: &StickerPack,
) -> Result<()> {
    let stickers_dir = media_dir.join("stickers");
    tokio::fs::create_dir_all(&stickers_dir)
        .await
        .context("create sticker directory")?;
    for document in &pack.documents {
        let source = seed_dir
            .join("stickers")
            .join(format!("{}.tgs", document.id));
        if !source.exists() {
            tracing::warn!(path = %source.display(), "sticker file is missing");
            continue;
        }
        let storage_key = format!("stickers/{}.tgs", document.id);
        let target = media_dir.join(&storage_key);
        if !target.exists() {
            tokio::fs::copy(&source, &target)
                .await
                .with_context(|| format!("copy sticker {}", source.display()))?;
        }
        let bytes = tokio::fs::read(&source)
            .await
            .context("read sticker seed")?;
        let mut hasher = Sha256::new();
        hasher.update(&bytes);
        let sha256 = hasher.finalize().to_vec();
        sqlx::query(
            "INSERT INTO te_media_files
                 (id, kind, storage_key, thumb_storage_key, sha256, mime_type, size,
                  width, height, duration, access_hash, file_reference, file_name,
                  sticker, sticker_alt, sticker_set_id, sticker_set_access_hash,
                  custom_emoji, custom_emoji_alt)
             VALUES ($1, 'document', $2, '', $3, $4, $5, $6, $7, 0, $8, $9, $10,
                     $11, $12, $13, $14, $15, $16)
             ON CONFLICT (id) DO UPDATE SET
                 sticker = EXCLUDED.sticker,
                 sticker_alt = EXCLUDED.sticker_alt,
                 sticker_set_id = EXCLUDED.sticker_set_id,
                 sticker_set_access_hash = EXCLUDED.sticker_set_access_hash,
                 custom_emoji = EXCLUDED.custom_emoji,
                 custom_emoji_alt = EXCLUDED.custom_emoji_alt",
        )
        .bind(document.id)
        .bind(&storage_key)
        .bind(&sha256)
        .bind(&document.mime_type)
        .bind(document.size)
        .bind(document.width)
        .bind(document.height)
        .bind(document.access_hash)
        .bind(&document.file_reference)
        .bind(&document.file_name)
        .bind(!document.custom_emoji)
        .bind(if document.custom_emoji {
            ""
        } else {
            &document.alt
        })
        .bind(pack.id)
        .bind(pack.access_hash)
        .bind(document.custom_emoji)
        .bind(if document.custom_emoji {
            &document.alt
        } else {
            ""
        })
        .execute(db.pool())
        .await
        .context("seed sticker media")?;
    }
    Ok(())
}

fn document_reference(document_id: i64) -> Vec<u8> {
    let mut hasher = Sha256::new();
    hasher.update(format!("tsrv-sticker-{document_id}").as_bytes());
    hasher.finalize()[..16].to_vec()
}

pub fn set_bytes(pack: &StickerPack) -> Vec<u8> {
    let mut flags = 0;
    if pack.emojis {
        flags |= 1 << 7;
    }
    types::sticker_set(
        pack.id,
        pack.access_hash,
        &pack.title,
        &pack.short_name,
        flags,
        pack.documents.len() as i32,
        pack.hash,
    )
}

pub fn document_bytes(pack: &StickerPack, document: &StickerDocument) -> Vec<u8> {
    let mut attributes = vec![types::document_attribute_image_size(
        document.width,
        document.height,
    )];
    if document.custom_emoji {
        attributes.push(types::document_attribute_custom_emoji(
            &document.alt,
            pack.id,
            pack.access_hash,
            document.text_color,
        ));
    } else {
        attributes.push(types::document_attribute_sticker(
            &document.alt,
            pack.id,
            pack.access_hash,
        ));
    }
    attributes.push(types::document_attribute_filename(&document.file_name));
    types::document(
        document.id,
        document.access_hash,
        &document.file_reference,
        document.date,
        &document.mime_type,
        document.size,
        &[],
        2,
        &attributes,
    )
}

pub fn pack_documents(pack: &StickerPack) -> Vec<Vec<u8>> {
    pack.documents
        .iter()
        .map(|document| document_bytes(pack, document))
        .collect()
}

pub fn messages_sticker_set(pack: &StickerPack) -> Vec<u8> {
    let packs: Vec<Vec<u8>> = pack
        .packs
        .iter()
        .map(|(emoticon, ids)| types::sticker_pack(emoticon, ids))
        .collect();
    types::messages_sticker_set(&set_bytes(pack), &packs, &pack_documents(pack))
}

pub fn documents_for_emoticon(pack: &StickerPack, emoticon: &str) -> Vec<Vec<u8>> {
    let ids: Vec<i64> = pack
        .packs
        .iter()
        .filter(|(item, _)| item == emoticon)
        .flat_map(|(_, ids)| ids.iter().copied())
        .collect();
    documents_by_ids(pack, &ids)
}

pub fn documents_by_ids(pack: &StickerPack, ids: &[i64]) -> Vec<Vec<u8>> {
    ids.iter()
        .filter_map(|id| {
            pack.documents
                .iter()
                .find(|document| document.id == *id)
                .map(|document| document_bytes(pack, document))
        })
        .collect()
}

pub fn default_statuses(pack: &StickerPack, limit: usize) -> Vec<Vec<u8>> {
    pack.documents
        .iter()
        .take(limit)
        .map(|document| types::emoji_status(document.id))
        .collect()
}

pub fn contains_document(pack: &StickerPack, document_id: i64) -> bool {
    pack.documents
        .iter()
        .any(|document| document.id == document_id)
}
