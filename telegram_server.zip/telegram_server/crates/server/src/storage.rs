//! Media directory inventory, orphan detection and safe cleanup.

use std::collections::{HashMap, HashSet};
use std::fs;
use std::path::Path;
use std::time::{SystemTime, UNIX_EPOCH};

use anyhow::{Context, Result};
use serde_json::{json, Value};
use sqlx::Row;
use tsrv_store::Db;

struct FileEntry {
    key: String,
    size: i64,
    modified: i64,
}

/// All storage keys that are referenced from the database. Anything on disk
/// outside this set is an orphan (ignoring recently modified files).
async fn referenced_keys(db: &Db) -> Result<HashSet<String>> {
    let rows = sqlx::query(
        "SELECT storage_key FROM te_media_files WHERE storage_key <> ''
         UNION
         SELECT thumb_storage_key FROM te_media_files WHERE thumb_storage_key <> ''
         UNION
         SELECT storage_key FROM te_media_thumbs WHERE storage_key <> ''
         UNION
         SELECT storage_key FROM te_upload_parts WHERE storage_key <> ''",
    )
    .fetch_all(db.pool())
    .await
    .context("load referenced media keys")?;
    let mut keys = HashSet::with_capacity(rows.len());
    for row in rows {
        let key: String = row.try_get("storage_key").context("read storage key")?;
        keys.insert(key);
    }
    Ok(keys)
}

fn walk_dir(base: &Path, dir: &Path, out: &mut Vec<FileEntry>) -> Result<()> {
    let entries = match fs::read_dir(dir) {
        Ok(entries) => entries,
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => return Ok(()),
        Err(error) => {
            return Err(error).with_context(|| format!("read directory {}", dir.display()))
        }
    };
    for entry in entries {
        let entry = entry.with_context(|| format!("read entry in {}", dir.display()))?;
        let path = entry.path();
        let metadata = entry
            .metadata()
            .with_context(|| format!("stat {}", path.display()))?;
        if metadata.is_dir() {
            walk_dir(base, &path, out)?;
            continue;
        }
        if !metadata.is_file() {
            continue;
        }
        let key = match path.strip_prefix(base) {
            Ok(relative) => relative
                .components()
                .map(|part| part.as_os_str().to_string_lossy())
                .collect::<Vec<_>>()
                .join("/"),
            Err(_) => continue,
        };
        let modified = metadata
            .modified()
            .ok()
            .and_then(|time| time.duration_since(UNIX_EPOCH).ok())
            .map(|duration| duration.as_secs() as i64)
            .unwrap_or(0);
        out.push(FileEntry {
            key,
            size: metadata.len() as i64,
            modified,
        });
    }
    Ok(())
}

fn walk(media_dir: &Path) -> Result<Vec<FileEntry>> {
    let mut out = Vec::new();
    walk_dir(media_dir, media_dir, &mut out)?;
    Ok(out)
}

fn top_group(key: &str) -> String {
    key.split('/').next().unwrap_or("").to_owned()
}

/// Builds the storage inventory shown in the admin panel.
pub async fn stats(db: &Db, media_dir: &Path) -> Result<Value> {
    let root = media_dir.to_path_buf();
    let files = tokio::task::spawn_blocking(move || walk(&root))
        .await
        .map_err(|error| anyhow::anyhow!("storage walk task failed: {error}"))??;
    let referenced = referenced_keys(db).await?;
    let now = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap_or_default()
        .as_secs() as i64;

    let mut groups: HashMap<String, (i64, i64)> = HashMap::new();
    let mut total_bytes = 0i64;
    let mut orphans: Vec<&FileEntry> = Vec::new();
    let mut orphan_bytes = 0i64;
    for file in &files {
        total_bytes += file.size;
        let group = groups.entry(top_group(&file.key)).or_insert((0, 0));
        group.0 += 1;
        group.1 += file.size;
        if !referenced.contains(&file.key) {
            orphan_bytes += file.size;
            orphans.push(file);
        }
    }

    let media_row = sqlx::query(
        "SELECT COUNT(*) AS count, COALESCE(SUM(size), 0)::bigint AS bytes,
                COALESCE(SUM(thumb_size), 0)::bigint AS thumb_bytes
         FROM te_media_files",
    )
    .fetch_one(db.pool())
    .await
    .context("media stats")?;
    let thumb_row = sqlx::query(
        "SELECT COUNT(*) AS count, COALESCE(SUM(size), 0)::bigint AS bytes
         FROM te_media_thumbs",
    )
    .fetch_one(db.pool())
    .await
    .context("thumb stats")?;
    let upload_row = sqlx::query(
        "SELECT COUNT(*) AS count, COALESCE(SUM(size), 0)::bigint AS bytes
         FROM te_upload_parts",
    )
    .fetch_one(db.pool())
    .await
    .context("upload stats")?;

    let media_count: i64 = media_row.try_get("count").unwrap_or(0);
    let media_bytes: i64 = media_row.try_get("bytes").unwrap_or(0);
    let media_thumb_bytes: i64 = media_row.try_get("thumb_bytes").unwrap_or(0);
    let thumb_count: i64 = thumb_row.try_get("count").unwrap_or(0);
    let thumb_bytes: i64 = thumb_row.try_get("bytes").unwrap_or(0);
    let upload_count: i64 = upload_row.try_get("count").unwrap_or(0);
    let upload_bytes: i64 = upload_row.try_get("bytes").unwrap_or(0);

    let mut groups: Vec<Value> = groups
        .into_iter()
        .map(|(name, (files, bytes))| json!({ "name": name, "files": files, "bytes": bytes }))
        .collect();
    groups.sort_by(|left, right| {
        right
            .get("bytes")
            .and_then(Value::as_i64)
            .cmp(&left.get("bytes").and_then(Value::as_i64))
    });

    orphans.sort_by_key(|right| std::cmp::Reverse(right.size));
    let orphan_items: Vec<Value> = orphans
        .iter()
        .take(200)
        .map(|file| {
            json!({
                "path": file.key,
                "size": file.size,
                "modified": file.modified,
                "recent": now - file.modified < 3600,
            })
        })
        .collect();

    let mut missing: Vec<String> = Vec::new();
    for key in &referenced {
        let path = media_dir.join(key);
        if !path.is_file() {
            missing.push(key.clone());
        }
    }
    missing.sort();
    let missing_count = missing.len();
    let missing_items: Vec<String> = missing.into_iter().take(100).collect();

    Ok(json!({
        "media_dir": media_dir.display().to_string(),
        "disk": {
            "total_bytes": total_bytes,
            "total_files": files.len(),
            "groups": groups,
        },
        "database": {
            "media": { "count": media_count, "bytes": media_bytes, "thumb_bytes": media_thumb_bytes },
            "thumbs": { "count": thumb_count, "bytes": thumb_bytes },
            "upload_parts": { "count": upload_count, "bytes": upload_bytes },
        },
        "orphans": {
            "files": orphans.len(),
            "bytes": orphan_bytes,
            "items": orphan_items,
        },
        "missing": {
            "count": missing_count,
            "items": missing_items,
        },
        "generated_at": now,
    }))
}

/// Deletes orphan files that are older than `min_age_secs`, keeping uploads
/// written during an in-flight request safe.
pub async fn cleanup(db: &Db, media_dir: &Path, min_age_secs: i64) -> Result<Value> {
    let root = media_dir.to_path_buf();
    let files = tokio::task::spawn_blocking(move || walk(&root))
        .await
        .map_err(|error| anyhow::anyhow!("storage walk task failed: {error}"))??;
    let referenced = referenced_keys(db).await?;
    let now = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap_or_default()
        .as_secs() as i64;
    let cutoff = now - min_age_secs.max(0);

    let mut deleted_files = 0i64;
    let mut deleted_bytes = 0i64;
    let mut skipped_recent = 0i64;
    let mut failed: Vec<Value> = Vec::new();
    for file in &files {
        if referenced.contains(&file.key) {
            continue;
        }
        if file.modified > cutoff {
            skipped_recent += 1;
            continue;
        }
        let path = media_dir.join(&file.key);
        match fs::remove_file(&path) {
            Ok(()) => {
                deleted_files += 1;
                deleted_bytes += file.size;
            }
            Err(error) => {
                if failed.len() < 20 {
                    failed.push(json!({ "path": file.key, "error": error.to_string() }));
                }
            }
        }
    }

    Ok(json!({
        "deleted_files": deleted_files,
        "deleted_bytes": deleted_bytes,
        "skipped_recent": skipped_recent,
        "failed": failed,
        "min_age_secs": min_age_secs,
    }))
}
