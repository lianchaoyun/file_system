//! MTProto connection handling: transport, handshake and encrypted RPC loop.

use std::collections::HashMap;
use std::net::SocketAddr;
use std::sync::Arc;

use anyhow::{Context, Result};
use rand::rngs::OsRng;
use tokio::net::{TcpListener, TcpStream};
use tokio::sync::watch;
use tsrv_mtproto::crypto::{RsaKey, Side};
use tsrv_mtproto::envelope::{decrypt_packet, encrypt_packet, peek_auth_key_id};
use tsrv_mtproto::handshake::{MessageIdGen, MessageIdKind, ServerHandshake};
use tsrv_mtproto::transport::Transport;
use tsrv_store::{Cache, Db};

use crate::config::Config;
use crate::langpack::LangPacks;
use crate::repo;
use crate::rpc::{self, ClientInfo, RpcContext};
use crate::update_hub::UpdateHub;

#[derive(Clone)]
pub struct AppState {
    pub db: Db,
    pub cache: Cache,
    pub config: Arc<Config>,
    pub rsa: Arc<RsaKey>,
    pub langpacks: Arc<LangPacks>,
    pub updates: UpdateHub,
}

struct AuthKeyState {
    id: i64,
    value: [u8; 256],
    salt: i64,
    expires_at: i64,
    user_id: Option<i64>,
}

/// Removes the connection's presence session on any exit path (read error,
/// protocol error or logout) and announces the user offline once the last
/// session disappears.
struct PresenceGuard {
    user_id: i64,
    session: (i64, i64),
    db: Db,
    updates: UpdateHub,
}

impl Drop for PresenceGuard {
    fn drop(&mut self) {
        let user_id = self.user_id;
        let session = self.session;
        let db = self.db.clone();
        let updates = self.updates.clone();
        tokio::spawn(async move {
            if crate::presence::global().mark_offline(user_id, session) {
                if let Err(error) = rpc::announce_presence(&db, &updates, user_id, false).await {
                    tracing::warn!(user_id, error = %error.message, "presence offline announce failed");
                }
            }
        });
    }
}

fn unix_time() -> i64 {
    std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .unwrap_or_default()
        .as_secs() as i64
}

/// Sends a 4-byte transport-level error frame. Telegram Desktop interprets this
/// as `AbstractConnection::error(-code)`; -404 tells it to drop and recreate the
/// temporary auth key instead of retrying forever.
async fn send_protocol_error(transport: &mut Transport, code: i32) -> Result<()> {
    transport
        .write_packet(&(-code).to_le_bytes())
        .await
        .context("write protocol error frame")
}

pub async fn run(
    listener: TcpListener,
    state: AppState,
    mut shutdown: watch::Receiver<bool>,
) -> Result<()> {
    loop {
        tokio::select! {
            _ = shutdown.changed() => break,
            accepted = listener.accept() => {
                let (stream, peer) = accepted?;
                let state = state.clone();
                tokio::spawn(async move {
                    if let Err(error) = handle_connection(stream, peer, state).await {
                        tracing::debug!(
                            %peer,
                            error = %format!("{error:#}"),
                            "MTProto connection closed"
                        );
                    }
                });
            }
        }
    }
    Ok(())
}

#[allow(clippy::map_entry)]
async fn handle_connection(stream: TcpStream, peer: SocketAddr, state: AppState) -> Result<()> {
    let mut transport = Transport::accept(stream)
        .await
        .context("accept MTProto transport")?;
    tracing::info!(%peer, transport = transport.kind().as_str(), "MTProto client connected");

    let mut handshake = ServerHandshake::new(state.rsa.as_ref().clone());
    // Telegram Desktop establishes a persistent and a temporary auth key on
    // the same TCP connection. Keep all keys seen on this connection and pick
    // the one named by each encrypted packet.
    let mut auth_keys: HashMap<i64, AuthKeyState> = HashMap::new();
    let mut message_ids = MessageIdGen::new();
    let mut content_seq = 1i32;
    let mut service_seq = 0i32;
    let mut active: Option<(i64, i64)> = None;
    let mut presence_guard: Option<PresenceGuard> = None;
    let mut update_rx = state.updates.subscribe();

    enum Event {
        Packet(Result<Vec<u8>>),
        Update(Option<crate::update_hub::UpdateEvent>),
    }

    loop {
        let event = tokio::select! {
            packet = transport.read_packet() => Event::Packet(packet),
            update = update_rx.recv() => Event::Update(update.ok()),
        };

        match event {
            Event::Packet(Ok(packet)) => {
                let key_id = peek_auth_key_id(&packet).unwrap_or(0);
                if key_id == 0 {
                    let response = handshake.handle(&packet).context("MTProto handshake")?;
                    if !response.reply.is_empty() {
                        transport
                            .write_packet(&response.reply)
                            .await
                            .context("write handshake reply")?;
                    }
                    if let Some(key) = response.auth_key {
                        repo::save_auth_key(
                            &state.db,
                            key.id,
                            &key.value,
                            key.salt,
                            key.expires_at,
                        )
                        .await
                        .context("persist auth key")?;
                        let user_id = repo::session_user(&state.db, key.id).await?;
                        tracing::info!(
                            %peer,
                            auth_key_id = key.id,
                            expires_at = key.expires_at,
                            "auth key established"
                        );
                        auth_keys.insert(
                            key.id,
                            AuthKeyState {
                                id: key.id,
                                value: key.value,
                                salt: key.salt,
                                expires_at: key.expires_at,
                                user_id,
                            },
                        );
                    }
                } else {
                    if !auth_keys.contains_key(&key_id) {
                        match repo::load_auth_key(&state.db, key_id).await? {
                            Some(record) => {
                                let now = unix_time();
                                if record.expires_at > 0 && record.expires_at <= now {
                                    tracing::warn!(
                                        %peer,
                                        auth_key_id = key_id,
                                        "expired temporary auth key"
                                    );
                                    send_protocol_error(&mut transport, 404).await?;
                                    return Ok(());
                                }
                                if let Some(binding) =
                                    repo::find_temp_auth_key_binding(&state.db, key_id).await?
                                {
                                    if binding.expires_at <= now {
                                        tracing::warn!(
                                            %peer,
                                            auth_key_id = key_id,
                                            "expired temporary auth key binding"
                                        );
                                        send_protocol_error(&mut transport, 404).await?;
                                        return Ok(());
                                    }
                                }
                                let user_id = repo::session_user(&state.db, key_id).await?;
                                tracing::debug!(%peer, auth_key_id = key_id, "resumed auth key");
                                auth_keys.insert(
                                    key_id,
                                    AuthKeyState {
                                        id: key_id,
                                        value: record.value,
                                        salt: record.salt,
                                        expires_at: record.expires_at,
                                        user_id,
                                    },
                                );
                            }
                            None => {
                                tracing::warn!(
                                    %peer,
                                    auth_key_id = key_id,
                                    "unknown auth_key_id"
                                );
                                send_protocol_error(&mut transport, 404).await?;
                                return Ok(());
                            }
                        }
                    }

                    let key = auth_keys
                        .get_mut(&key_id)
                        .expect("auth key was inserted above");
                    if key.expires_at > 0 && key.expires_at <= unix_time() {
                        tracing::warn!(
                            %peer,
                            auth_key_id = key_id,
                            "temporary auth key expired during connection"
                        );
                        send_protocol_error(&mut transport, 404).await?;
                        return Ok(());
                    }
                    let session_id = process_encrypted(
                        &mut transport,
                        &state,
                        key,
                        &mut message_ids,
                        &mut content_seq,
                        &mut service_seq,
                        peer,
                        &packet,
                    )
                    .await?;
                    match key.user_id {
                        Some(user_id) => {
                            if active != Some((key_id, session_id)) {
                                // Replacing an older session announces it offline
                                // through the dropped guard.
                                drop(presence_guard.take());
                                active = Some((key_id, session_id));
                                if crate::presence::global()
                                    .mark_online(user_id, (key_id, session_id))
                                {
                                    let db = state.db.clone();
                                    let updates = state.updates.clone();
                                    tokio::spawn(async move {
                                        if let Err(error) =
                                            rpc::announce_presence(&db, &updates, user_id, true)
                                                .await
                                        {
                                            tracing::warn!(
                                                user_id,
                                                error = %error.message,
                                                "presence online announce failed"
                                            );
                                        }
                                    });
                                }
                                presence_guard = Some(PresenceGuard {
                                    user_id,
                                    session: (key_id, session_id),
                                    db: state.db.clone(),
                                    updates: state.updates.clone(),
                                });
                            }
                        }
                        None => {
                            if active.take().is_some() {
                                // Logout: drop the guard so the account is
                                // announced offline immediately.
                                drop(presence_guard.take());
                            }
                        }
                    }
                }
            }
            Event::Packet(Err(error)) => {
                tracing::debug!(
                    %peer,
                    error = %format!("{error:#}"),
                    "MTProto read ended"
                );
                return Ok(());
            }
            Event::Update(Some(update)) => {
                let Some((key_id, session_id)) = active else {
                    continue;
                };
                let Some(key) = auth_keys.get(&key_id) else {
                    continue;
                };
                if key.user_id != Some(update.user_id) {
                    continue;
                }
                if update.exclude_session_id == Some(session_id) {
                    continue;
                }
                send_body(
                    &mut transport,
                    key,
                    session_id,
                    &mut message_ids,
                    &mut content_seq,
                    false,
                    &update.body,
                )
                .await?;
            }
            Event::Update(None) => {}
        }
    }
}

#[allow(clippy::too_many_arguments)]
async fn process_encrypted(
    transport: &mut Transport,
    state: &AppState,
    key: &mut AuthKeyState,
    message_ids: &mut MessageIdGen,
    content_seq: &mut i32,
    service_seq: &mut i32,
    peer: SocketAddr,
    packet: &[u8],
) -> Result<i64> {
    let message = match decrypt_packet(&key.value, packet, Side::Client) {
        Ok(message) => message,
        Err(error) => {
            let preview: Vec<String> = packet
                .iter()
                .take(32)
                .map(|byte| format!("{byte:02x}"))
                .collect();
            tracing::debug!(
                packet_len = packet.len(),
                preview = %preview.join(" "),
                %error,
                "failed to decrypt MTProto packet"
            );
            return Err(error).context("decrypt message");
        }
    };
    let body_constructor = if message.body.len() >= 4 {
        u32::from_le_bytes(message.body[..4].try_into().expect("four bytes"))
    } else {
        0
    };
    tracing::debug!(
        message_id = message.message_id,
        session_id = message.session_id,
        seq_no = message.seq_no,
        body_len = message.body.len(),
        body = format_args!("0x{body_constructor:08x}"),
        "decrypted MTProto message"
    );
    // Re-read the session on every message so a revoked authorization loses
    // access immediately without waiting for a reconnect.
    let session_user = repo::touch_session(&state.db, key.id).await.unwrap_or(None);
    let mut context = RpcContext {
        db: &state.db,
        cache: &state.cache,
        config: &state.config,
        langpacks: &state.langpacks,
        updates: &state.updates,
        auth_key_id: key.id,
        session_id: message.session_id,
        user_id: session_user,
        layer: 232,
        peer: peer.to_string(),
        client: ClientInfo::default(),
    };
    let outgoing = rpc::process_message(&mut context, message.message_id, &message.body).await;
    key.user_id = context.user_id;

    let service = matches!(
        body_constructor,
        tsrv_tl::ctor::MSGS_ACK
            | tsrv_tl::ctor::MSGS_STATE_REQ
            | tsrv_tl::ctor::PING
            | tsrv_tl::ctor::PING_DELAY_DISCONNECT
            | tsrv_tl::ctor::NEW_SESSION_CREATED
            | 0x7d86_1a08
            | 0x8cc0_d131
    );
    // Acknowledging a client acknowledgement creates an endless msgs_ack
    // ping-pong. Only content messages require an acknowledgement.
    if message.seq_no != 0 && !service {
        let ack = tsrv_tl::msgs_ack(&[message.message_id]);
        send_body(
            transport,
            key,
            message.session_id,
            message_ids,
            service_seq,
            true,
            &ack,
        )
        .await?;
    }

    for item in outgoing {
        send_body(
            transport,
            key,
            message.session_id,
            message_ids,
            if item.service {
                service_seq
            } else {
                content_seq
            },
            item.service,
            &item.body,
        )
        .await?;
    }
    Ok(message.session_id)
}

async fn send_body(
    transport: &mut Transport,
    key: &AuthKeyState,
    session_id: i64,
    message_ids: &mut MessageIdGen,
    sequence: &mut i32,
    service: bool,
    body: &[u8],
) -> Result<()> {
    let seq_no = *sequence;
    *sequence = sequence.wrapping_add(2);
    let message_id = message_ids.next(if service {
        MessageIdKind::Server
    } else {
        MessageIdKind::ServerResponse
    });
    let body_constructor = if body.len() >= 4 {
        u32::from_le_bytes(body[..4].try_into().expect("four bytes"))
    } else {
        0
    };
    tracing::debug!(
        message_id,
        seq_no,
        body_len = body.len(),
        body = format_args!("0x{body_constructor:08x}"),
        service,
        "sending encrypted MTProto message"
    );
    let packet = encrypt_packet(
        &key.value,
        key.salt,
        session_id,
        message_id,
        seq_no,
        body,
        Side::Server,
        &mut OsRng,
    )?;
    transport
        .write_packet(&packet)
        .await
        .context("write encrypted packet")
}
