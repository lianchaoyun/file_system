use std::collections::HashSet;
use std::path::PathBuf;

use axum::{
    extract::{Request, State},
    http::{header::AUTHORIZATION, HeaderMap, StatusCode},
    middleware::{self, Next},
    response::{IntoResponse, Response},
    routing::{get, post},
    Json, Router,
};
use serde::Deserialize;
use serde_json::json;
use tsrv_store::{Cache, Db};

use crate::maintenance::{self, MaintenanceConfig};
use crate::mtproto_listener::AppState;
use crate::repo;
use crate::rpc::{self, RpcFailure};
use crate::storage;
use crate::update_hub::UpdateHub;

#[derive(Clone)]
pub struct HealthState {
    /// Shared server state so admin write operations can reuse the same RPC
    /// code paths (PTS, update_log and online pushes).
    pub app: AppState,
    pub db: Db,
    pub cache: Cache,
    pub schema: String,
    pub updates: UpdateHub,
    pub media_dir: PathBuf,
    pub maintenance: MaintenanceConfig,
}

pub fn router(state: HealthState) -> Router {
    let admin = Router::new()
        .route("/admin/stats", get(admin_stats))
        .route("/admin/maintenance", post(admin_maintenance))
        .route("/admin/system-message", post(system_message))
        .route("/admin/telegram/send-message", post(telegram_send_message))
        .route("/admin/telegram/broadcast", post(telegram_broadcast))
        .route(
            "/admin/telegram/delete-message",
            post(telegram_delete_message),
        )
        .route(
            "/admin/telegram/delete-messages",
            post(telegram_delete_messages),
        )
        .route("/admin/telegram/kick-user", post(telegram_kick_user))
        .route("/admin/telegram/update-user", post(telegram_update_user))
        .route("/admin/telegram/ban-user", post(telegram_ban_user))
        .route("/admin/telegram/kick-session", post(telegram_kick_session))
        .route(
            "/admin/telegram/kick-all-sessions",
            post(telegram_kick_all_sessions),
        )
        .route("/admin/telegram/add-member", post(telegram_add_member))
        .route("/admin/telegram/remove-member", post(telegram_remove_member))
        .route(
            "/admin/telegram/promote-member",
            post(telegram_promote_member),
        )
        .route(
            "/admin/telegram/ban-chat-user",
            post(telegram_ban_chat_user),
        )
        .route(
            "/admin/telegram/create-invite",
            post(telegram_create_invite),
        )
        .route(
            "/admin/telegram/revoke-invite",
            post(telegram_revoke_invite),
        )
        .route("/admin/telegram/update-chat", post(telegram_update_chat))
        .route("/admin/telegram/edit-message", post(telegram_edit_message))
        .route("/admin/telegram/pin-message", post(telegram_pin_message))
        .route("/admin/telegram/create-chat", post(telegram_create_chat))
        .route("/admin/telegram/delete-chat", post(telegram_delete_chat))
        .route("/admin/telegram/delete-user", post(telegram_delete_user))
        .route("/admin/telegram/bot-create", post(telegram_bot_create))
        .route(
            "/admin/telegram/bot-reset-token",
            post(telegram_bot_reset_token),
        )
        .route("/admin/telegram/bot-disable", post(telegram_bot_disable))
        .route(
            "/admin/telegram/review-join-request",
            post(telegram_review_join_request),
        )
        .route(
            "/admin/telegram/storage-stats",
            post(telegram_storage_stats),
        )
        .route(
            "/admin/telegram/storage-cleanup",
            post(telegram_storage_cleanup),
        )
        .route_layer(middleware::from_fn_with_state(
            state.clone(),
            require_admin_token,
        ));
    Router::new()
        .route("/healthz", get(healthz))
        .route("/readyz", get(healthz))
        // Public HTTP Bot API: `/bot/<token>/<method>` (GET and POST)
        .route(
            "/bot/{token}/{method}",
            get(crate::bot_api::handle).post(crate::bot_api::handle),
        )
        .merge(admin)
        .with_state(state)
}

fn admin_authorized(state: &HealthState, headers: &HeaderMap) -> bool {
    let Some(expected) = state.app.config.admin_token.as_deref() else {
        // No token configured: keep the legacy open behaviour for local dev.
        return true;
    };
    let bearer = headers
        .get(AUTHORIZATION)
        .and_then(|value| value.to_str().ok())
        .and_then(|value| value.strip_prefix("Bearer "));
    let direct = headers
        .get("x-admin-token")
        .and_then(|value| value.to_str().ok());
    bearer == Some(expected) || direct == Some(expected)
}

async fn require_admin_token(
    State(state): State<HealthState>,
    request: Request,
    next: Next,
) -> Response {
    if admin_authorized(&state, request.headers()) {
        next.run(request).await
    } else {
        (
            StatusCode::UNAUTHORIZED,
            Json(json!({ "ok": false, "error": "UNAUTHORIZED" })),
        )
            .into_response()
    }
}

fn admin_error(error: RpcFailure) -> Response {
    let status = match error.code {
        400 => StatusCode::BAD_REQUEST,
        403 => StatusCode::FORBIDDEN,
        404 => StatusCode::NOT_FOUND,
        _ => StatusCode::INTERNAL_SERVER_ERROR,
    };
    (
        status,
        Json(json!({ "ok": false, "error": error.message })),
    )
        .into_response()
}

/// 后台操作者标识，由 yun 通过 `X-Admin-Actor` 传入（通常是管理员账号）。
fn admin_actor(headers: &HeaderMap) -> String {
    headers
        .get("x-admin-actor")
        .and_then(|value| value.to_str().ok())
        .map(str::trim)
        .filter(|value| !value.is_empty())
        .unwrap_or("admin")
        .chars()
        .take(64)
        .collect()
}

/// 执行一次管理写操作并写入 `te_admin_audit`，审计失败不影响主操作。
#[allow(clippy::too_many_arguments)]
async fn with_audit<T>(
    state: &HealthState,
    headers: &HeaderMap,
    action: &str,
    target_user_id: Option<i64>,
    target_chat_id: Option<i64>,
    target_message_id: Option<i64>,
    params: serde_json::Value,
    result: Result<T, RpcFailure>,
) -> Result<T, RpcFailure> {
    let actor = admin_actor(headers);
    let (success, error) = match &result {
        Ok(_) => (true, None),
        Err(failure) => (false, Some(failure.message.as_str())),
    };
    if let Err(err) = repo::insert_admin_audit(
        &state.app.db,
        &actor,
        action,
        target_user_id,
        target_chat_id,
        target_message_id,
        &params,
        success,
        error,
    )
    .await
    {
        tracing::warn!(action, "write admin audit failed: {err}");
    }
    result
}

#[derive(Deserialize)]
struct TelegramSendMessageRequest {
    user_id: i64,
    text: String,
}

async fn telegram_send_message(
    State(state): State<HealthState>,
    headers: HeaderMap,
    Json(request): Json<TelegramSendMessageRequest>,
) -> Response {
    let preview = request.text.chars().take(200).collect::<String>();
    let result = with_audit(
        &state,
        &headers,
        "send_message",
        Some(request.user_id),
        None,
        None,
        json!({ "text": preview, "text_length": request.text.chars().count() }),
        rpc::admin_send_message(&state.app, request.user_id, &request.text).await,
    )
    .await;
    match result {
        Ok((chat_id, message_id)) => (
            StatusCode::OK,
            Json(json!({
                "ok": true,
                "user_id": request.user_id,
                "chat_id": chat_id,
                "message_id": message_id,
            })),
        )
            .into_response(),
        Err(error) => admin_error(error),
    }
}

#[derive(Deserialize)]
struct TelegramBroadcastRequest {
    user_ids: Vec<i64>,
    text: String,
}

async fn telegram_broadcast(
    State(state): State<HealthState>,
    headers: HeaderMap,
    Json(request): Json<TelegramBroadcastRequest>,
) -> Response {
    let mut seen = HashSet::new();
    let targets: Vec<i64> = request
        .user_ids
        .into_iter()
        .filter(|user_id| *user_id > 0 && seen.insert(*user_id))
        .collect();
    let preview = request.text.chars().take(200).collect::<String>();
    let result = with_audit(
        &state,
        &headers,
        "broadcast_message",
        None,
        None,
        None,
        json!({
            "text": preview,
            "text_length": request.text.chars().count(),
            "user_ids": &targets,
        }),
        rpc::admin_broadcast_message(&state.app, &targets, &request.text).await,
    )
    .await;
    match result {
        Ok(outcome) => (
            StatusCode::OK,
            Json(json!({ "ok": true, "result": outcome })),
        )
            .into_response(),
        Err(error) => admin_error(error),
    }
}

#[derive(Deserialize)]
struct TelegramDeleteMessageRequest {
    chat_id: i64,
    message_id: i64,
}

async fn telegram_delete_message(
    State(state): State<HealthState>,
    headers: HeaderMap,
    Json(request): Json<TelegramDeleteMessageRequest>,
) -> Response {
    let result = with_audit(
        &state,
        &headers,
        "delete_message",
        None,
        Some(request.chat_id),
        Some(request.message_id),
        json!({ "chat_id": request.chat_id, "message_id": request.message_id }),
        rpc::admin_delete_message(&state.app, request.chat_id, request.message_id).await,
    )
    .await;
    match result {
        Ok(deleted) => (
            StatusCode::OK,
            Json(json!({ "ok": true, "deleted": deleted })),
        )
            .into_response(),
        Err(error) => admin_error(error),
    }
}

#[derive(Deserialize)]
struct TelegramDeleteMessagesRequest {
    chat_id: i64,
    message_ids: Vec<i64>,
}

async fn telegram_delete_messages(
    State(state): State<HealthState>,
    headers: HeaderMap,
    Json(request): Json<TelegramDeleteMessagesRequest>,
) -> Response {
    let result = with_audit(
        &state,
        &headers,
        "delete_messages",
        None,
        Some(request.chat_id),
        None,
        json!({ "chat_id": request.chat_id, "message_ids": request.message_ids }),
        rpc::admin_delete_messages(&state.app, request.chat_id, &request.message_ids).await,
    )
    .await;
    match result {
        Ok(deleted) => (
            StatusCode::OK,
            Json(json!({ "ok": true, "deleted": deleted })),
        )
            .into_response(),
        Err(error) => admin_error(error),
    }
}

#[derive(Deserialize)]
struct TelegramKickUserRequest {
    chat_id: i64,
    user_id: i64,
}

async fn telegram_kick_user(
    State(state): State<HealthState>,
    headers: HeaderMap,
    Json(request): Json<TelegramKickUserRequest>,
) -> Response {
    let result = with_audit(
        &state,
        &headers,
        "kick_user",
        Some(request.user_id),
        Some(request.chat_id),
        None,
        json!({ "chat_id": request.chat_id, "user_id": request.user_id }),
        rpc::admin_kick_user(&state.app, request.chat_id, request.user_id).await,
    )
    .await;
    match result {
        Ok(()) => (
            StatusCode::OK,
            Json(json!({ "ok": true, "chat_id": request.chat_id, "user_id": request.user_id })),
        )
            .into_response(),
        Err(error) => admin_error(error),
    }
}

#[derive(Deserialize)]
struct TelegramUpdateUserRequest {
    user_id: i64,
    first_name: Option<String>,
    last_name: Option<String>,
    username: Option<String>,
}

async fn telegram_update_user(
    State(state): State<HealthState>,
    headers: HeaderMap,
    Json(request): Json<TelegramUpdateUserRequest>,
) -> Response {
    let params = json!({
        "first_name": request.first_name,
        "last_name": request.last_name,
        "username": request.username,
    });
    let result = with_audit(
        &state,
        &headers,
        "update_user",
        Some(request.user_id),
        None,
        None,
        params,
        rpc::admin_update_user(
            &state.app,
            request.user_id,
            request.first_name.as_deref(),
            request.last_name.as_deref(),
            request.username.as_deref(),
        )
        .await,
    )
    .await;
    match result {
        Ok(()) => (
            StatusCode::OK,
            Json(json!({ "ok": true, "user_id": request.user_id })),
        )
            .into_response(),
        Err(error) => admin_error(error),
    }
}

#[derive(Deserialize)]
struct TelegramBanUserRequest {
    user_id: i64,
    banned: bool,
}

async fn telegram_ban_user(
    State(state): State<HealthState>,
    headers: HeaderMap,
    Json(request): Json<TelegramBanUserRequest>,
) -> Response {
    let result = with_audit(
        &state,
        &headers,
        "ban_user",
        Some(request.user_id),
        None,
        None,
        json!({ "banned": request.banned }),
        rpc::admin_ban_user(&state.app, request.user_id, request.banned).await,
    )
    .await;
    match result {
        Ok(()) => (
            StatusCode::OK,
            Json(json!({
                "ok": true,
                "user_id": request.user_id,
                "banned": request.banned,
            })),
        )
            .into_response(),
        Err(error) => admin_error(error),
    }
}

#[derive(Deserialize)]
struct TelegramKickSessionRequest {
    user_id: i64,
    auth_key_id: i64,
}

async fn telegram_kick_session(
    State(state): State<HealthState>,
    headers: HeaderMap,
    Json(request): Json<TelegramKickSessionRequest>,
) -> Response {
    let result = with_audit(
        &state,
        &headers,
        "kick_session",
        Some(request.user_id),
        None,
        None,
        json!({ "auth_key_id": request.auth_key_id }),
        rpc::admin_kick_session(&state.app, request.user_id, request.auth_key_id).await,
    )
    .await;
    match result {
        Ok(true) => (
            StatusCode::OK,
            Json(json!({
                "ok": true,
                "user_id": request.user_id,
                "auth_key_id": request.auth_key_id,
            })),
        )
            .into_response(),
        Ok(false) => (
            StatusCode::NOT_FOUND,
            Json(json!({ "ok": false, "error": "SESSION_NOT_FOUND" })),
        )
            .into_response(),
        Err(error) => admin_error(error),
    }
}

#[derive(Deserialize)]
struct TelegramKickAllSessionsRequest {
    user_id: i64,
}

async fn telegram_kick_all_sessions(
    State(state): State<HealthState>,
    headers: HeaderMap,
    Json(request): Json<TelegramKickAllSessionsRequest>,
) -> Response {
    let result = with_audit(
        &state,
        &headers,
        "kick_all_sessions",
        Some(request.user_id),
        None,
        None,
        json!({}),
        rpc::admin_kick_all_sessions(&state.app, request.user_id).await,
    )
    .await;
    match result {
        Ok(count) => (
            StatusCode::OK,
            Json(json!({ "ok": true, "user_id": request.user_id, "revoked": count })),
        )
            .into_response(),
        Err(error) => admin_error(error),
    }
}

#[derive(Deserialize)]
struct TelegramAddMemberRequest {
    chat_id: i64,
    user_id: i64,
}

async fn telegram_add_member(
    State(state): State<HealthState>,
    headers: HeaderMap,
    Json(request): Json<TelegramAddMemberRequest>,
) -> Response {
    let result = with_audit(
        &state,
        &headers,
        "add_member",
        Some(request.user_id),
        Some(request.chat_id),
        None,
        json!({ "chat_id": request.chat_id, "user_id": request.user_id }),
        rpc::admin_add_member(&state.app, request.chat_id, request.user_id).await,
    )
    .await;
    match result {
        Ok(()) => (
            StatusCode::OK,
            Json(json!({
                "ok": true,
                "chat_id": request.chat_id,
                "user_id": request.user_id,
            })),
        )
            .into_response(),
        Err(error) => admin_error(error),
    }
}

#[derive(Deserialize)]
struct TelegramRemoveMemberRequest {
    chat_id: i64,
    user_id: i64,
}

async fn telegram_remove_member(
    State(state): State<HealthState>,
    headers: HeaderMap,
    Json(request): Json<TelegramRemoveMemberRequest>,
) -> Response {
    let result = with_audit(
        &state,
        &headers,
        "remove_member",
        Some(request.user_id),
        Some(request.chat_id),
        None,
        json!({ "chat_id": request.chat_id, "user_id": request.user_id }),
        rpc::admin_remove_member(&state.app, request.chat_id, request.user_id).await,
    )
    .await;
    match result {
        Ok(()) => (
            StatusCode::OK,
            Json(json!({
                "ok": true,
                "chat_id": request.chat_id,
                "user_id": request.user_id,
            })),
        )
            .into_response(),
        Err(error) => admin_error(error),
    }
}

#[derive(Deserialize)]
struct TelegramPromoteMemberRequest {
    chat_id: i64,
    user_id: i64,
    #[serde(default)]
    rights_flags: u32,
    #[serde(default)]
    rank: String,
}

async fn telegram_promote_member(
    State(state): State<HealthState>,
    headers: HeaderMap,
    Json(request): Json<TelegramPromoteMemberRequest>,
) -> Response {
    let result = with_audit(
        &state,
        &headers,
        "promote_member",
        Some(request.user_id),
        Some(request.chat_id),
        None,
        json!({
            "chat_id": request.chat_id,
            "user_id": request.user_id,
            "rights_flags": request.rights_flags,
            "rank": request.rank,
        }),
        rpc::admin_promote_member(
            &state.app,
            request.chat_id,
            request.user_id,
            request.rights_flags,
            &request.rank,
        )
        .await,
    )
    .await;
    match result {
        Ok(()) => (
            StatusCode::OK,
            Json(json!({
                "ok": true,
                "chat_id": request.chat_id,
                "user_id": request.user_id,
                "rights_flags": request.rights_flags,
            })),
        )
            .into_response(),
        Err(error) => admin_error(error),
    }
}

#[derive(Deserialize)]
struct TelegramBanChatUserRequest {
    chat_id: i64,
    user_id: i64,
    banned: bool,
    #[serde(default)]
    rights_flags: u32,
    #[serde(default)]
    until_date: i64,
}

async fn telegram_ban_chat_user(
    State(state): State<HealthState>,
    headers: HeaderMap,
    Json(request): Json<TelegramBanChatUserRequest>,
) -> Response {
    let result = with_audit(
        &state,
        &headers,
        "ban_chat_user",
        Some(request.user_id),
        Some(request.chat_id),
        None,
        json!({
            "chat_id": request.chat_id,
            "user_id": request.user_id,
            "banned": request.banned,
            "rights_flags": request.rights_flags,
            "until_date": request.until_date,
        }),
        rpc::admin_ban_chat_user(
            &state.app,
            request.chat_id,
            request.user_id,
            request.banned,
            request.rights_flags,
            request.until_date,
        )
        .await,
    )
    .await;
    match result {
        Ok(()) => (
            StatusCode::OK,
            Json(json!({
                "ok": true,
                "chat_id": request.chat_id,
                "user_id": request.user_id,
                "banned": request.banned,
            })),
        )
            .into_response(),
        Err(error) => admin_error(error),
    }
}

#[derive(Deserialize)]
struct TelegramCreateInviteRequest {
    chat_id: i64,
    #[serde(default)]
    expires_at: i64,
    #[serde(default)]
    usage_limit: i32,
    #[serde(default)]
    request_needed: bool,
}

async fn telegram_create_invite(
    State(state): State<HealthState>,
    headers: HeaderMap,
    Json(request): Json<TelegramCreateInviteRequest>,
) -> Response {
    let result = with_audit(
        &state,
        &headers,
        "create_invite",
        None,
        Some(request.chat_id),
        None,
        json!({
            "chat_id": request.chat_id,
            "expires_at": request.expires_at,
            "usage_limit": request.usage_limit,
            "request_needed": request.request_needed,
        }),
        rpc::admin_create_invite(
            &state.app,
            request.chat_id,
            request.expires_at,
            request.usage_limit,
            request.request_needed,
        )
        .await,
    )
    .await;
    match result {
        Ok((link, expires_at, usage_limit)) => (
            StatusCode::OK,
            Json(json!({
                "ok": true,
                "chat_id": request.chat_id,
                "link": link,
                "expires_at": expires_at,
                "usage_limit": usage_limit,
                "request_needed": request.request_needed,
            })),
        )
            .into_response(),
        Err(error) => admin_error(error),
    }
}

#[derive(Deserialize)]
struct TelegramRevokeInviteRequest {
    chat_id: i64,
    token: String,
}

async fn telegram_revoke_invite(
    State(state): State<HealthState>,
    headers: HeaderMap,
    Json(request): Json<TelegramRevokeInviteRequest>,
) -> Response {
    let result = with_audit(
        &state,
        &headers,
        "revoke_invite",
        None,
        Some(request.chat_id),
        None,
        json!({ "chat_id": request.chat_id, "token": request.token }),
        rpc::admin_revoke_invite(&state.app, request.chat_id, &request.token).await,
    )
    .await;
    match result {
        Ok(()) => (
            StatusCode::OK,
            Json(json!({ "ok": true, "chat_id": request.chat_id, "token": request.token })),
        )
            .into_response(),
        Err(error) => admin_error(error),
    }
}

#[derive(Deserialize)]
struct TelegramUpdateChatRequest {
    chat_id: i64,
    #[serde(default)]
    title: Option<String>,
    #[serde(default)]
    photo_media_id: Option<i64>,
}

async fn telegram_update_chat(
    State(state): State<HealthState>,
    headers: HeaderMap,
    Json(request): Json<TelegramUpdateChatRequest>,
) -> Response {
    let result = with_audit(
        &state,
        &headers,
        "update_chat",
        None,
        Some(request.chat_id),
        None,
        json!({
            "chat_id": request.chat_id,
            "title": request.title,
            "photo_media_id": request.photo_media_id,
        }),
        rpc::admin_update_chat(
            &state.app,
            request.chat_id,
            request.title.as_deref(),
            request.photo_media_id,
        )
        .await,
    )
    .await;
    match result {
        Ok(()) => (
            StatusCode::OK,
            Json(json!({ "ok": true, "chat_id": request.chat_id })),
        )
            .into_response(),
        Err(error) => admin_error(error),
    }
}

#[derive(Deserialize)]
struct TelegramEditMessageRequest {
    chat_id: i64,
    message_id: i64,
    text: String,
}

async fn telegram_edit_message(
    State(state): State<HealthState>,
    headers: HeaderMap,
    Json(request): Json<TelegramEditMessageRequest>,
) -> Response {
    let preview = request.text.chars().take(200).collect::<String>();
    let result = with_audit(
        &state,
        &headers,
        "edit_message",
        None,
        Some(request.chat_id),
        Some(request.message_id),
        json!({
            "text": preview,
            "text_length": request.text.chars().count(),
        }),
        rpc::admin_edit_message(
            &state.app,
            request.chat_id,
            request.message_id,
            &request.text,
        )
        .await,
    )
    .await;
    match result {
        Ok(()) => (
            StatusCode::OK,
            Json(json!({
                "ok": true,
                "chat_id": request.chat_id,
                "message_id": request.message_id,
            })),
        )
            .into_response(),
        Err(error) => admin_error(error),
    }
}

#[derive(Deserialize)]
struct TelegramPinMessageRequest {
    chat_id: i64,
    message_id: i64,
}

async fn telegram_pin_message(
    State(state): State<HealthState>,
    headers: HeaderMap,
    Json(request): Json<TelegramPinMessageRequest>,
) -> Response {
    let result = with_audit(
        &state,
        &headers,
        "pin_message",
        None,
        Some(request.chat_id),
        Some(request.message_id.max(0)),
        json!({
            "chat_id": request.chat_id,
            "message_id": request.message_id,
        }),
        rpc::admin_pin_message(&state.app, request.chat_id, request.message_id).await,
    )
    .await;
    match result {
        Ok(()) => (
            StatusCode::OK,
            Json(json!({ "ok": true, "pinned": request.message_id > 0 })),
        )
            .into_response(),
        Err(error) => admin_error(error),
    }
}

#[derive(Deserialize)]
struct TelegramCreateChatRequest {
    kind: String,
    owner_user_id: i64,
    title: String,
    #[serde(default)]
    about: String,
    #[serde(default)]
    member_ids: Vec<i64>,
}

async fn telegram_create_chat(
    State(state): State<HealthState>,
    headers: HeaderMap,
    Json(request): Json<TelegramCreateChatRequest>,
) -> Response {
    let result = with_audit(
        &state,
        &headers,
        "create_chat",
        Some(request.owner_user_id),
        None,
        None,
        json!({
            "kind": request.kind,
            "owner_user_id": request.owner_user_id,
            "title": request.title,
            "about": request.about,
            "member_ids": request.member_ids,
        }),
        rpc::admin_create_chat(
            &state.app,
            &request.kind,
            request.owner_user_id,
            &request.title,
            &request.about,
            &request.member_ids,
        )
        .await,
    )
    .await;
    match result {
        Ok(chat_id) => (
            StatusCode::OK,
            Json(json!({ "ok": true, "chat_id": chat_id })),
        )
            .into_response(),
        Err(error) => admin_error(error),
    }
}

#[derive(Deserialize)]
struct TelegramDeleteChatRequest {
    chat_id: i64,
}

async fn telegram_delete_chat(
    State(state): State<HealthState>,
    headers: HeaderMap,
    Json(request): Json<TelegramDeleteChatRequest>,
) -> Response {
    let result = with_audit(
        &state,
        &headers,
        "delete_chat",
        None,
        Some(request.chat_id),
        None,
        json!({ "chat_id": request.chat_id }),
        rpc::admin_delete_chat(&state.app, request.chat_id).await,
    )
    .await;
    match result {
        Ok(deleted) => (
            StatusCode::OK,
            Json(json!({ "ok": true, "deleted_messages": deleted })),
        )
            .into_response(),
        Err(error) => admin_error(error),
    }
}

#[derive(Deserialize)]
struct TelegramDeleteUserRequest {
    user_id: i64,
    /// `dry_run` defaults to true so a missing flag can never delete data by
    /// accident; yun always sends it explicitly.
    #[serde(default = "default_true")]
    dry_run: bool,
}

fn default_true() -> bool {
    true
}

async fn telegram_delete_user(
    State(state): State<HealthState>,
    headers: HeaderMap,
    Json(request): Json<TelegramDeleteUserRequest>,
) -> Response {
    let outcome = rpc::admin_delete_user(&state.app, request.user_id, request.dry_run).await;
    let params = match &outcome {
        Ok(plan) => json!({
            "user_id": request.user_id,
            "dry_run": !plan.executed,
            "owned_chats": plan.owned_chats,
            "private_chats": plan.private_chats,
            "messages": plan.messages,
            "media": plan.media,
        }),
        Err(_) => json!({ "user_id": request.user_id, "dry_run": request.dry_run }),
    };
    let result = with_audit(
        &state,
        &headers,
        "delete_user",
        Some(request.user_id),
        None,
        None,
        params,
        outcome,
    )
    .await;
    match result {
        Ok(plan) => (
            StatusCode::OK,
            Json(json!({
                "ok": true,
                "user_id": plan.user_id,
                "dry_run": !plan.executed,
                "executed": plan.executed,
                "owned_chats": plan.owned_chats,
                "private_chats": plan.private_chats,
                "messages": plan.messages,
                "media": plan.media,
            })),
        )
            .into_response(),
        Err(error) => admin_error(error),
    }
}

#[derive(Deserialize)]
struct TelegramBotCreateRequest {
    username: String,
    #[serde(default)]
    first_name: String,
    #[serde(default)]
    last_name: String,
    #[serde(default)]
    owner_user_id: Option<i64>,
}

fn bot_username_error(raw: &str) -> Option<String> {
    let username = raw.trim().trim_start_matches('@');
    if !(5..=32).contains(&username.len()) {
        return Some("机器人用户名长度必须为 5-32 个字符".to_owned());
    }
    let mut chars = username.chars();
    let Some(first) = chars.next() else {
        return Some("机器人用户名不能为空".to_owned());
    };
    if !first.is_ascii_alphabetic() {
        return Some("机器人用户名必须以字母开头".to_owned());
    }
    if !chars.all(|c| c.is_ascii_alphanumeric() || c == '_') {
        return Some("机器人用户名只能包含字母、数字和下划线".to_owned());
    }
    None
}

fn repo_failure(error: anyhow::Error) -> RpcFailure {
    tracing::warn!(%error, "admin bot operation failed");
    RpcFailure::new(500, "INTERNAL_SERVER_ERROR")
}

async fn telegram_bot_create(
    State(state): State<HealthState>,
    headers: HeaderMap,
    Json(request): Json<TelegramBotCreateRequest>,
) -> Response {
    let username = request.username.trim().trim_start_matches('@').to_owned();
    if let Some(message) = bot_username_error(&username) {
        return (
            StatusCode::BAD_REQUEST,
            Json(json!({ "ok": false, "error": message })),
        )
            .into_response();
    }
    let first_name = if request.first_name.trim().is_empty() {
        username.clone()
    } else {
        request.first_name.trim().to_owned()
    };
    let created_by = admin_actor(&headers);
    let taken = match repo::username_taken(&state.app.db, &username).await {
        Ok(taken) => taken,
        Err(error) => return admin_error(repo_failure(error)),
    };
    if taken {
        return (
            StatusCode::BAD_REQUEST,
            Json(json!({ "ok": false, "error": "USERNAME_OCCUPIED" })),
        )
            .into_response();
    }
    let result = with_audit(
        &state,
        &headers,
        "bot_create",
        None,
        None,
        None,
        json!({ "username": username, "owner_user_id": request.owner_user_id }),
        repo::create_bot(
            &state.app.db,
            &username,
            &first_name,
            request.last_name.trim(),
            request.owner_user_id,
            &created_by,
        )
        .await
        .map_err(repo_failure),
    )
    .await;
    match result {
        Ok((user, token)) => (
            StatusCode::OK,
            Json(json!({
                "ok": true,
                "user_id": user.id,
                "username": user.username,
                "first_name": user.first_name,
                "token": token,
            })),
        )
            .into_response(),
        Err(error) => admin_error(error),
    }
}

#[derive(Deserialize)]
struct TelegramBotTokenRequest {
    user_id: i64,
}

async fn telegram_bot_reset_token(
    State(state): State<HealthState>,
    headers: HeaderMap,
    Json(request): Json<TelegramBotTokenRequest>,
) -> Response {
    let result = with_audit(
        &state,
        &headers,
        "bot_reset_token",
        Some(request.user_id),
        None,
        None,
        json!({ "user_id": request.user_id }),
        repo::reset_bot_token(&state.app.db, request.user_id)
            .await
            .map_err(repo_failure),
    )
    .await;
    match result {
        Ok(Some(token)) => (
            StatusCode::OK,
            Json(json!({ "ok": true, "user_id": request.user_id, "token": token })),
        )
            .into_response(),
        Ok(None) => (
            StatusCode::NOT_FOUND,
            Json(json!({ "ok": false, "error": "BOT_NOT_FOUND" })),
        )
            .into_response(),
        Err(error) => admin_error(error),
    }
}

#[derive(Deserialize)]
struct TelegramBotDisableRequest {
    user_id: i64,
    disabled: bool,
}

async fn telegram_bot_disable(
    State(state): State<HealthState>,
    headers: HeaderMap,
    Json(request): Json<TelegramBotDisableRequest>,
) -> Response {
    let result = with_audit(
        &state,
        &headers,
        "bot_disable",
        Some(request.user_id),
        None,
        None,
        json!({ "user_id": request.user_id, "disabled": request.disabled }),
        repo::set_bot_disabled(&state.app.db, request.user_id, request.disabled)
            .await
            .map_err(repo_failure),
    )
    .await;
    match result {
        Ok(true) => (
            StatusCode::OK,
            Json(json!({
                "ok": true,
                "user_id": request.user_id,
                "disabled": request.disabled,
            })),
        )
            .into_response(),
        Ok(false) => (
            StatusCode::NOT_FOUND,
            Json(json!({ "ok": false, "error": "BOT_NOT_FOUND" })),
        )
            .into_response(),
        Err(error) => admin_error(error),
    }
}

#[derive(Deserialize)]
struct TelegramReviewJoinRequestRequest {
    chat_id: i64,
    user_id: i64,
    approve: bool,
}

async fn telegram_review_join_request(
    State(state): State<HealthState>,
    headers: HeaderMap,
    Json(request): Json<TelegramReviewJoinRequestRequest>,
) -> Response {
    let reviewer = admin_actor(&headers);
    let result = with_audit(
        &state,
        &headers,
        "review_join_request",
        Some(request.user_id),
        Some(request.chat_id),
        None,
        json!({
            "chat_id": request.chat_id,
            "user_id": request.user_id,
            "approve": request.approve,
            "reviewer": reviewer,
        }),
        rpc::admin_review_join_request(
            &state.app,
            request.chat_id,
            request.user_id,
            request.approve,
            &reviewer,
        )
        .await,
    )
    .await;
    match result {
        Ok(()) => (
            StatusCode::OK,
            Json(json!({
                "ok": true,
                "chat_id": request.chat_id,
                "user_id": request.user_id,
                "status": if request.approve { "approved" } else { "rejected" },
            })),
        )
            .into_response(),
        Err(error) => admin_error(error),
    }
}

#[derive(Deserialize)]
struct TelegramStorageCleanupRequest {
    #[serde(default)]
    min_age_secs: Option<i64>,
}

async fn telegram_storage_stats(State(state): State<HealthState>) -> Response {
    match storage::stats(&state.db, &state.media_dir).await {
        Ok(stats) => (
            StatusCode::OK,
            Json(json!({ "ok": true, "stats": stats })),
        )
            .into_response(),
        Err(error) => {
            tracing::warn!("storage stats failed: {error}");
            (
                StatusCode::INTERNAL_SERVER_ERROR,
                Json(json!({ "ok": false, "error": "STORAGE_STATS_FAILED" })),
            )
                .into_response()
        }
    }
}

async fn telegram_storage_cleanup(
    State(state): State<HealthState>,
    headers: HeaderMap,
    Json(request): Json<TelegramStorageCleanupRequest>,
) -> Response {
    let min_age_secs = request.min_age_secs.unwrap_or(3600).clamp(0, 30 * 86_400);
    let cleanup = storage::cleanup(&state.db, &state.media_dir, min_age_secs)
        .await
        .map_err(|error| {
            tracing::warn!("storage cleanup failed: {error}");
            RpcFailure::new(500, "STORAGE_CLEANUP_FAILED")
        });
    let result = with_audit(
        &state,
        &headers,
        "storage_cleanup",
        None,
        None,
        None,
        json!({ "min_age_secs": min_age_secs }),
        cleanup,
    )
    .await;
    match result {
        Ok(outcome) => (
            StatusCode::OK,
            Json(json!({ "ok": true, "result": outcome })),
        )
            .into_response(),
        Err(error) => admin_error(error),
    }
}

#[derive(Deserialize)]
struct SystemMessageRequest {
    phone: String,
    text: String,
}

/// Development helper: the built-in system assistant sends a private message to
/// a user, so real client behaviour can be exercised without a second account.
async fn system_message(
    State(state): State<HealthState>,
    headers: HeaderMap,
    Json(request): Json<SystemMessageRequest>,
) -> impl IntoResponse {
    let phone = normalize_phone(&request.phone);
    let Some(user) = repo::find_user_by_phone(&state.db, &phone)
        .await
        .ok()
        .flatten()
    else {
        return (
            StatusCode::NOT_FOUND,
            Json(json!({ "error": format!("no user with phone {phone}") })),
        );
    };
    let preview = request.text.chars().take(200).collect::<String>();
    let result = with_audit(
        &state,
        &headers,
        "system_message",
        Some(user.id),
        None,
        None,
        json!({ "phone": phone, "text": preview }),
        rpc::send_system_message(&state.db, &state.updates, user.id, &request.text).await,
    )
    .await;
    match result {
        Ok(sent) => (
            StatusCode::OK,
            Json(json!({ "sent": sent, "user_id": user.id, "phone": phone })),
        ),
        Err(error) => (
            StatusCode::INTERNAL_SERVER_ERROR,
            Json(json!({ "error": error.message })),
        ),
    }
}

async fn admin_stats(State(state): State<HealthState>) -> impl IntoResponse {
    match repo::ops_stats(&state.db).await {
        Ok(stats) => (
            StatusCode::OK,
            Json(json!({
                "schema": state.schema,
                "users": stats.users,
                "chats": stats.chats,
                "messages": stats.messages,
                "media": stats.media,
                "pending_scheduled": stats.pending_scheduled,
                "update_log": stats.update_log,
                "auth_keys": stats.auth_keys,
                "temp_bindings": stats.temp_bindings,
                "reactions": stats.reactions,
                "update_log_retention_seconds": state.maintenance.update_log_retention_seconds,
                "upload_part_ttl_seconds": state.maintenance.upload_part_ttl_seconds,
            })),
        ),
        Err(error) => (
            StatusCode::INTERNAL_SERVER_ERROR,
            Json(json!({ "error": error.to_string() })),
        ),
    }
}

async fn admin_maintenance(State(state): State<HealthState>) -> impl IntoResponse {
    match maintenance::run_once(&state.db, &state.media_dir, &state.maintenance).await {
        Ok(outcome) => (
            StatusCode::OK,
            Json(json!({
                "pruned_updates": outcome.pruned_updates,
                "expired_auth_keys": outcome.expired_auth_keys,
                "stale_uploads": outcome.stale_uploads,
            })),
        ),
        Err(error) => (
            StatusCode::INTERNAL_SERVER_ERROR,
            Json(json!({ "error": error.to_string() })),
        ),
    }
}

fn normalize_phone(raw: &str) -> String {
    let digits: String = raw.chars().filter(|ch| ch.is_ascii_digit()).collect();
    format!("+{digits}")
}

async fn healthz(State(state): State<HealthState>) -> impl IntoResponse {
    let db_ok = state.db.ping().await.is_ok();
    let redis_ok = state.cache.ping().await.is_ok();
    let healthy = db_ok && redis_ok;
    let status = if healthy {
        StatusCode::OK
    } else {
        StatusCode::SERVICE_UNAVAILABLE
    };
    (
        status,
        Json(json!({
            "status": if healthy { "ok" } else { "degraded" },
            "db": db_ok,
            "redis": redis_ok,
            "schema": state.schema,
        })),
    )
}
