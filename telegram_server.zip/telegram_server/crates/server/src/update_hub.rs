//! In-process update fan-out for active MTProto connections.

use tokio::sync::broadcast;

#[derive(Debug, Clone)]
pub struct UpdateEvent {
    pub user_id: i64,
    /// Session that must not receive this event (usually the sender's own
    /// connection, which already received the RPC result).
    pub exclude_session_id: Option<i64>,
    pub body: Vec<u8>,
}

#[derive(Clone)]
pub struct UpdateHub {
    sender: broadcast::Sender<UpdateEvent>,
}

impl Default for UpdateHub {
    fn default() -> Self {
        Self::new()
    }
}

impl UpdateHub {
    pub fn new() -> Self {
        let (sender, _) = broadcast::channel(256);
        Self { sender }
    }

    pub fn subscribe(&self) -> broadcast::Receiver<UpdateEvent> {
        self.sender.subscribe()
    }

    pub fn publish(&self, user_id: i64, body: Vec<u8>) {
        self.publish_excluding(user_id, None, body);
    }

    pub fn publish_excluding(&self, user_id: i64, exclude_session_id: Option<i64>, body: Vec<u8>) {
        // No active receivers is a normal situation (user offline).
        let _ = self.sender.send(UpdateEvent {
            user_id,
            exclude_session_id,
            body,
        });
    }
}
