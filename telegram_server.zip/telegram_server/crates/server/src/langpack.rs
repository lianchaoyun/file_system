use std::collections::BTreeMap;
use std::path::Path;

use anyhow::{Context, Result};
use tsrv_tl::types;

const LANG_PACK_VERSION: i32 = 1;

#[derive(Debug, Default)]
struct PluralValues {
    one: Option<String>,
    other: Option<String>,
}

#[derive(Debug)]
pub struct LangPack {
    pub code: String,
    strings: BTreeMap<String, String>,
    encoded_strings: Vec<Vec<u8>>,
    language_entry: Vec<u8>,
}

impl LangPack {
    fn empty(code: &str) -> Self {
        let (name, native_name) = metadata(code);
        let language_entry = types::lang_pack_language(
            &name,
            &native_name,
            code,
            code,
            0,
            0,
            &translations_url(code),
        );
        Self {
            code: code.to_owned(),
            strings: BTreeMap::new(),
            encoded_strings: Vec::new(),
            language_entry,
        }
    }

    pub fn language_entry(&self) -> &[u8] {
        &self.language_entry
    }

    pub fn difference(&self, from_version: i32) -> Vec<u8> {
        if from_version >= LANG_PACK_VERSION {
            types::lang_pack_difference_strings(&self.code, from_version, LANG_PACK_VERSION, &[])
        } else {
            types::lang_pack_difference_strings(
                &self.code,
                0,
                LANG_PACK_VERSION,
                &self.encoded_strings,
            )
        }
    }

    pub fn strings_for_keys(&self, keys: &[String]) -> Vec<Vec<u8>> {
        keys.iter()
            .filter_map(|key| {
                self.strings
                    .get(key)
                    .map(|value| types::lang_pack_string(key, value))
            })
            .collect()
    }
}

pub struct LangPacks {
    packs: Vec<LangPack>,
}

impl LangPacks {
    /// Loads `*.strings` language files from `dir`. English is always available
    /// because Telegram Desktop ships its strings compiled in.
    pub fn load(dir: &Path) -> Result<Self> {
        let mut packs = Vec::new();
        if dir.is_dir() {
            let mut files = Vec::new();
            for entry in std::fs::read_dir(dir)
                .with_context(|| format!("read langpack dir {}", dir.display()))?
            {
                let path = entry?.path();
                if path.extension().and_then(|ext| ext.to_str()) == Some("strings") {
                    files.push(path);
                }
            }
            files.sort();
            for path in files {
                let code = path
                    .file_stem()
                    .and_then(|stem| stem.to_str())
                    .unwrap_or_default()
                    .to_owned();
                if code.is_empty() {
                    continue;
                }
                let pack = load_file(&code, &path)?;
                tracing::info!(
                    lang = %code,
                    strings = pack.encoded_strings.len(),
                    "loaded language pack"
                );
                packs.push(pack);
            }
        } else {
            tracing::warn!(dir = %dir.display(), "langpack directory is missing");
        }
        packs.push(LangPack::empty("en"));
        packs.sort_by(|a, b| a.code.cmp(&b.code));
        Ok(Self { packs })
    }

    pub fn find(&self, code: &str) -> Option<&LangPack> {
        self.packs.iter().find(|pack| pack.code == code)
    }

    pub fn languages(&self) -> Vec<Vec<u8>> {
        self.packs
            .iter()
            .map(|pack| pack.language_entry().to_vec())
            .collect()
    }
}

impl Default for LangPacks {
    fn default() -> Self {
        Self {
            packs: vec![LangPack::empty("en")],
        }
    }
}

fn load_file(code: &str, path: &Path) -> Result<LangPack> {
    let content = std::fs::read_to_string(path)
        .with_context(|| format!("read langpack {}", path.display()))?;
    let pairs =
        parse_strings(&content).with_context(|| format!("parse langpack {}", path.display()))?;

    let mut strings = BTreeMap::new();
    let mut plurals: BTreeMap<String, PluralValues> = BTreeMap::new();
    for (key, value) in pairs {
        match key.split_once('#') {
            Some((base, suffix)) if is_plural_suffix(suffix) => {
                let entry = plurals.entry(base.to_owned()).or_default();
                match suffix {
                    "one" => entry.one = Some(value),
                    "other" => entry.other = Some(value),
                    // Chinese only uses "other"; keep the first value as a
                    // fallback for the other forms so they never stay empty.
                    _ => {
                        if entry.other.is_none() {
                            entry.other = Some(value);
                        }
                    }
                }
            }
            _ => {
                strings.insert(key, value);
            }
        }
    }

    let mut encoded_strings = Vec::with_capacity(strings.len() + plurals.len());
    for (key, value) in &strings {
        encoded_strings.push(types::lang_pack_string(key, value));
    }
    for (key, values) in &plurals {
        if let Some(other) = values.other.clone().or_else(|| values.one.clone()) {
            encoded_strings.push(types::lang_pack_string_pluralized(
                key,
                values.one.as_deref(),
                &other,
            ));
        }
    }

    let (name, native_name) = metadata(code);
    let native_name = strings
        .get("lng_language_name")
        .cloned()
        .filter(|value| !value.is_empty())
        .unwrap_or(native_name);
    let entry_count = encoded_strings.len() as i32;
    let language_entry = types::lang_pack_language(
        &name,
        &native_name,
        code,
        code,
        entry_count,
        entry_count,
        &translations_url(code),
    );

    Ok(LangPack {
        code: code.to_owned(),
        strings,
        encoded_strings,
        language_entry,
    })
}

fn is_plural_suffix(suffix: &str) -> bool {
    matches!(suffix, "zero" | "one" | "two" | "few" | "many" | "other")
}

fn metadata(code: &str) -> (String, String) {
    match code {
        "en" => ("English".to_owned(), "English".to_owned()),
        "zh-hans" => ("Chinese (Simplified)".to_owned(), "简体中文".to_owned()),
        "zh-hant" => ("Chinese (Traditional)".to_owned(), "繁體中文".to_owned()),
        "ru" => ("Russian".to_owned(), "Русский".to_owned()),
        other => (other.to_owned(), other.to_owned()),
    }
}

fn translations_url(code: &str) -> String {
    format!("https://translations.telegram.org/{code}/tdesktop")
}

/// Parses Telegram Desktop `.strings` language files: block comments, then
/// `"key" = "value";` entries where values may contain `\"`, `\\` and `\n`.
fn parse_strings(content: &str) -> Result<Vec<(String, String)>> {
    let bytes = content.as_bytes();
    let mut index = 0usize;
    let mut pairs = Vec::new();

    skip_ignored(bytes, &mut index);
    while index < bytes.len() {
        let key = read_quoted(bytes, &mut index).context("read langpack key")?;
        skip_ignored(bytes, &mut index);
        if bytes.get(index) != Some(&b'=') {
            anyhow::bail!("expected '=' after key {key}");
        }
        index += 1;
        skip_ignored(bytes, &mut index);
        let value = read_quoted(bytes, &mut index).context("read langpack value")?;
        skip_ignored(bytes, &mut index);
        if bytes.get(index) != Some(&b';') {
            anyhow::bail!("expected ';' after value of key {key}");
        }
        index += 1;
        pairs.push((key, value));
        skip_ignored(bytes, &mut index);
    }
    Ok(pairs)
}

fn skip_ignored(bytes: &[u8], index: &mut usize) {
    loop {
        while *index < bytes.len() && bytes[*index].is_ascii_whitespace() {
            *index += 1;
        }
        if bytes.get(*index) == Some(&b'/') && bytes.get(*index + 1) == Some(&b'*') {
            *index += 2;
            while *index < bytes.len() {
                if bytes[*index] == b'*' && bytes.get(*index + 1) == Some(&b'/') {
                    *index += 2;
                    break;
                }
                *index += 1;
            }
            continue;
        }
        if bytes.get(*index) == Some(&b'/') && bytes.get(*index + 1) == Some(&b'/') {
            while *index < bytes.len() && bytes[*index] != b'\n' {
                *index += 1;
            }
            continue;
        }
        return;
    }
}

fn read_quoted(bytes: &[u8], index: &mut usize) -> Result<String> {
    if bytes.get(*index) != Some(&b'"') {
        anyhow::bail!("expected '\"' at byte {index}");
    }
    *index += 1;
    let mut value = String::new();
    let mut chunk_start = *index;
    while *index < bytes.len() {
        match bytes[*index] {
            b'"' => {
                value.push_str(std::str::from_utf8(&bytes[chunk_start..*index])?);
                *index += 1;
                return Ok(value);
            }
            b'\\' => {
                value.push_str(std::str::from_utf8(&bytes[chunk_start..*index])?);
                match bytes.get(*index + 1) {
                    Some(b'"') => value.push('"'),
                    Some(b'\\') => value.push('\\'),
                    Some(b'n') => value.push('\n'),
                    Some(other) => value.push(*other as char),
                    None => anyhow::bail!("unexpected end of file after '\\'"),
                }
                *index += 2;
                chunk_start = *index;
            }
            _ => *index += 1,
        }
    }
    anyhow::bail!("unterminated string")
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parses_langpack_file_with_comments_and_escapes() {
        let content = r#"/* header comment */
"lng_language_name" = "简体中文";
// line comment before the next key
"lng_test" = "line\nbreak \"quoted\"";
"lng_seconds#other" = "{count} 秒";
"#;
        let pairs = parse_strings(content).expect("parse");
        assert_eq!(pairs.len(), 3);
        assert_eq!(pairs[0].1, "简体中文");
        assert_eq!(pairs[1].1, "line\nbreak \"quoted\"");
    }

    #[test]
    fn loads_plural_entries_as_single_string() {
        let dir = std::env::temp_dir().join("tsrv-langpack-test");
        std::fs::create_dir_all(&dir).expect("create dir");
        let path = dir.join("zh-hans.strings");
        std::fs::write(
            &path,
            "\"lng_language_name\" = \"简体中文\";\n\"lng_seconds#one\" = \"{count} 秒\";\n\"lng_seconds#other\" = \"{count} 秒\";\n",
        )
        .expect("write");
        let packs = LangPacks::load(&dir).expect("load");
        let pack = packs.find("zh-hans").expect("zh-hans");
        let difference = pack.difference(0);
        // One plain string plus one pluralized entry: constructor + key + two
        // values for the pluralized entry, so the difference is not empty.
        assert!(!difference.is_empty());
        assert_eq!(
            pack.strings_for_keys(&["lng_language_name".to_owned()])
                .len(),
            1
        );
        assert!(packs.find("en").is_some());
        let _ = std::fs::remove_file(&path);
    }
}
