//! HTTP Bot API: `POST /bot/<token>/<method>`.
//!
//! The token is `<bot_user_id>:<secret>`; only its SHA-256 digest is stored,
//! so every request re-hashes the token and looks the bot up in `te_bots`.

use std::collections::HashMap;
use std::sync::{Mutex, OnceLock};
use std::time::{Duration, Instant};

use axum::{
    body::Bytes,
    extract::{Path, Query, State},
    http::{header::CONTENT_TYPE, HeaderMap, StatusCode},
    response::{IntoResponse, Response},
    Json,
};
use serde_json::{json, Map, Value};
use tsrv_store::Db;

use crate::health::HealthState;
use crate::repo::{self, BotRecord, MessageRecord, UserRecord};
use crate::rpc;

pub async fn handle(
    State(state): State<HealthState>,
    Path((token, method)): Path<(String, String)>,
    Query(query): Query<HashMap<String, String>>,
    headers: HeaderMap,
    body: Bytes,
) -> Response {
    let (bot_user, _bot) = match repo::find_bot_by_token(&state.app.db, &token).await {
        Ok(Some(found)) => found,
        Ok(None) => return api_error(401, "Unauthorized"),
        Err(error) => {
            tracing::warn!(%error, "bot token lookup failed");
            return api_error(500, "Internal Server Error");
        }
    };
    let params = parse_params(&headers, &body, &query);
    let _ = repo::touch_bot_used(&state.app.db, bot_user.id).await;

    match method.as_str() {
        "getMe" => api_ok(bot_json(&bot_user, &_bot)),
        "sendMessage" => send_message(&state, &bot_user, &params).await,
        "getUpdates" => get_updates(&state, &bot_user, &params).await,
        "answerCallbackQuery" => answer_callback_query(&params),
        "setWebhook" | "deleteWebhook" => api_error(
            501,
            "Not Implemented: webhook mode is unavailable, use getUpdates",
        ),
        other => api_error(
            404,
            format!("Not Found: method `{other}` is not supported"),
        ),
    }
}

/// Appends a private message received by a bot to its `getUpdates` queue.
pub async fn enqueue_incoming_message(
    db: &Db,
    bot_user_id: i64,
    record: &MessageRecord,
    sender: &UserRecord,
) -> anyhow::Result<()> {
    let payload = json!({
        "message": message_json(record, sender, sender),
    });
    repo::enqueue_bot_update(db, bot_user_id, &payload).await?;
    Ok(())
}

/// Answer passed back to the client that clicked an inline button.
#[derive(Debug, Clone, Default)]
pub struct CallbackAnswer {
    pub text: Option<String>,
    pub show_alert: bool,
    pub url: Option<String>,
    pub cache_time: i32,
}

type PendingSender = tokio::sync::oneshot::Sender<CallbackAnswer>;

fn pending() -> &'static Mutex<HashMap<i64, PendingSender>> {
    static PENDING: OnceLock<Mutex<HashMap<i64, PendingSender>>> = OnceLock::new();
    PENDING.get_or_init(|| Mutex::new(HashMap::new()))
}

/// Registers a waiting client before the callback update is queued, so a very
/// fast bot cannot answer before we start listening.
pub fn register_callback(query_id: i64) -> tokio::sync::oneshot::Receiver<CallbackAnswer> {
    let (sender, receiver) = tokio::sync::oneshot::channel();
    pending()
        .lock()
        .unwrap_or_else(|error| error.into_inner())
        .insert(query_id, sender);
    receiver
}

fn resolve_callback(query_id: i64, answer: CallbackAnswer) -> bool {
    let sender = pending()
        .lock()
        .unwrap_or_else(|error| error.into_inner())
        .remove(&query_id);
    match sender {
        Some(sender) => sender.send(answer).is_ok(),
        None => false,
    }
}

/// Queues a `callback_query` update for the bot that owns the inline keyboard.
pub async fn enqueue_callback_query(
    db: &Db,
    bot: &UserRecord,
    clicker: &UserRecord,
    record: &MessageRecord,
    data: Option<&str>,
    query_id: i64,
) -> anyhow::Result<()> {
    let mut query = Map::new();
    query.insert("id".to_owned(), json!(query_id.to_string()));
    query.insert("from".to_owned(), user_json(clicker));
    query.insert(
        "message".to_owned(),
        message_json(record, bot, clicker),
    );
    query.insert("chat_instance".to_owned(), json!(clicker.id.to_string()));
    if let Some(data) = data {
        query.insert("data".to_owned(), json!(data));
    }
    let payload = json!({ "callback_query": Value::Object(query) });
    repo::enqueue_bot_update(db, bot.id, &payload).await?;
    Ok(())
}

fn answer_callback_query(params: &Map<String, Value>) -> Response {
    let query_id = params
        .get("callback_query_id")
        .and_then(as_i64)
        .unwrap_or(0);
    if query_id == 0 {
        return api_error(400, "Bad Request: callback_query_id is missing");
    }
    let answer = CallbackAnswer {
        text: params
            .get("text")
            .and_then(Value::as_str)
            .map(str::to_owned),
        show_alert: params
            .get("show_alert")
            .and_then(Value::as_bool)
            .unwrap_or(false),
        url: params.get("url").and_then(Value::as_str).map(str::to_owned),
        cache_time: params
            .get("cache_time")
            .and_then(as_i64)
            .unwrap_or(0)
            .clamp(0, 3600) as i32,
    };
    if resolve_callback(query_id, answer) {
        api_ok(json!(true))
    } else {
        api_error(
            400,
            "Bad Request: query is too old or has no callback waiting",
        )
    }
}

async fn send_message(
    state: &HealthState,
    bot: &UserRecord,
    params: &Map<String, Value>,
) -> Response {
    let text = params
        .get("text")
        .and_then(Value::as_str)
        .unwrap_or_default()
        .to_owned();
    if text.is_empty() {
        return api_error(400, "Bad Request: message text is empty");
    }
    if text.chars().count() > 4096 {
        return api_error(400, "Bad Request: message is too long");
    }
    let chat_id = match resolve_chat_id(&state.app.db, params.get("chat_id")).await {
        Ok(Some(chat_id)) => chat_id,
        Ok(None) => return api_error(400, "Bad Request: chat not found"),
        Err(error) => {
            tracing::warn!(%error, "resolve bot chat id failed");
            return api_error(500, "Internal Server Error");
        }
    };
    let Some(chat) = (match repo::find_user_by_id(&state.app.db, chat_id).await {
        Ok(chat) => chat,
        Err(error) => {
            tracing::warn!(%error, "load bot chat failed");
            return api_error(500, "Internal Server Error");
        }
    }) else {
        return api_error(400, "Bad Request: chat not found");
    };
    if chat.is_bot {
        return api_error(403, "Forbidden: bots cannot message other bots");
    }

    let mut extras = repo::MessageExtras::default();
    extras.reply_markup = params
        .get("reply_markup")
        .filter(|value| value.is_object())
        .cloned();

    match rpc::bot_send_private_message(&state.app.db, &state.updates, bot, chat_id, &text, &extras)
        .await
    {
        Ok(record) => api_ok(message_json(&record, bot, &chat)),
        Err(failure) => {
            let description = match failure.message.as_str() {
                "USER_IS_BLOCKED" => "Forbidden: bot was blocked by the user",
                "PEER_ID_INVALID" => "Bad Request: chat not found",
                _ => "Internal Server Error",
            };
            api_error(failure.code.max(400) as u16, description)
        }
    }
}

async fn get_updates(
    state: &HealthState,
    bot: &UserRecord,
    params: &Map<String, Value>,
) -> Response {
    let offset = params
        .get("offset")
        .and_then(as_i64)
        .unwrap_or(0)
        .max(0);
    let limit = params
        .get("limit")
        .and_then(as_i64)
        .unwrap_or(100)
        .clamp(1, 100) as i32;
    let timeout = params
        .get("timeout")
        .and_then(as_i64)
        .unwrap_or(0)
        .clamp(0, 50);
    let deadline = Instant::now() + Duration::from_secs(timeout as u64);

    loop {
        match repo::list_bot_updates(&state.app.db, bot.id, offset, limit).await {
            Ok(updates) => {
                if !updates.is_empty() || timeout == 0 || Instant::now() >= deadline {
                    let result: Vec<Value> = updates
                        .into_iter()
                        .map(|(update_id, mut payload)| {
                            if let Some(object) = payload.as_object_mut() {
                                object.insert("update_id".to_owned(), json!(update_id));
                            }
                            payload
                        })
                        .collect();
                    return api_ok(Value::Array(result));
                }
            }
            Err(error) => {
                tracing::warn!(%error, "list bot updates failed");
                return api_error(500, "Internal Server Error");
            }
        }
        tokio::time::sleep(Duration::from_millis(400)).await;
    }
}

async fn resolve_chat_id(db: &Db, value: Option<&Value>) -> anyhow::Result<Option<i64>> {
    let Some(value) = value else {
        return Ok(None);
    };
    if let Some(number) = value.as_i64() {
        return Ok(Some(number.abs()));
    }
    let Some(text) = value.as_str() else {
        return Ok(None);
    };
    let text = text.trim();
    if let Ok(number) = text.parse::<i64>() {
        return Ok(Some(number.abs()));
    }
    let username = text.trim_start_matches('@');
    Ok(repo::find_user_by_username(db, username)
        .await?
        .map(|user| user.id))
}

fn bot_json(bot: &UserRecord, record: &BotRecord) -> Value {
    let mut object = Map::new();
    object.insert("id".to_owned(), json!(bot.id));
    object.insert("is_bot".to_owned(), json!(true));
    object.insert("first_name".to_owned(), json!(bot.first_name));
    if !bot.last_name.is_empty() {
        object.insert("last_name".to_owned(), json!(bot.last_name));
    }
    if !bot.username.is_empty() {
        object.insert("username".to_owned(), json!(bot.username));
    }
    object.insert("can_join_groups".to_owned(), json!(false));
    object.insert("can_read_all_group_messages".to_owned(), json!(false));
    object.insert("supports_inline_queries".to_owned(), json!(false));
    object.insert("token_disabled".to_owned(), json!(record.disabled));
    Value::Object(object)
}

fn user_json(user: &UserRecord) -> Value {
    let mut object = Map::new();
    object.insert("id".to_owned(), json!(user.id));
    object.insert("is_bot".to_owned(), json!(user.is_bot));
    object.insert("first_name".to_owned(), json!(user.first_name));
    if !user.last_name.is_empty() {
        object.insert("last_name".to_owned(), json!(user.last_name));
    }
    if !user.username.is_empty() {
        object.insert("username".to_owned(), json!(user.username));
    }
    Value::Object(object)
}

fn chat_json(user: &UserRecord) -> Value {
    let mut object = Map::new();
    object.insert("id".to_owned(), json!(user.id));
    object.insert("type".to_owned(), json!("private"));
    object.insert("first_name".to_owned(), json!(user.first_name));
    if !user.last_name.is_empty() {
        object.insert("last_name".to_owned(), json!(user.last_name));
    }
    if !user.username.is_empty() {
        object.insert("username".to_owned(), json!(user.username));
    }
    Value::Object(object)
}

fn message_json(record: &MessageRecord, from: &UserRecord, chat: &UserRecord) -> Value {
    let mut object = Map::new();
    object.insert("message_id".to_owned(), json!(record.id));
    object.insert("from".to_owned(), user_json(from));
    object.insert("chat".to_owned(), chat_json(chat));
    object.insert("date".to_owned(), json!(record.sent_at));
    object.insert("text".to_owned(), json!(record.text));
    if let Some(markup) = &record.reply_markup {
        object.insert("reply_markup".to_owned(), markup.clone());
    }
    if let Some(reply_to) = record.reply_to_msg_id {
        object.insert("reply_to_message".to_owned(), json!({ "message_id": reply_to }));
    }
    Value::Object(object)
}

fn api_ok(result: Value) -> Response {
    (
        StatusCode::OK,
        Json(json!({ "ok": true, "result": result })),
    )
        .into_response()
}

fn api_error(code: u16, description: impl Into<String>) -> Response {
    let status = StatusCode::from_u16(code).unwrap_or(StatusCode::BAD_REQUEST);
    (
        status,
        Json(json!({
            "ok": false,
            "error_code": code,
            "description": description.into(),
        })),
    )
        .into_response()
}

fn as_i64(value: &Value) -> Option<i64> {
    value.as_i64().or_else(|| value.as_str()?.parse().ok())
}

/// Accepts JSON, `application/x-www-form-urlencoded` bodies and query strings.
fn parse_params(
    headers: &HeaderMap,
    body: &[u8],
    query: &HashMap<String, String>,
) -> Map<String, Value> {
    let mut params = Map::new();
    for (key, value) in query {
        params.insert(key.clone(), Value::String(value.clone()));
    }
    if body.is_empty() {
        return params;
    }
    let content_type = headers
        .get(CONTENT_TYPE)
        .and_then(|value| value.to_str().ok())
        .unwrap_or("");
    if content_type.contains("application/json") {
        if let Ok(Value::Object(object)) = serde_json::from_slice::<Value>(body) {
            params.extend(object);
        }
        return params;
    }
    if content_type.contains("application/x-www-form-urlencoded") {
        for pair in String::from_utf8_lossy(body).split('&') {
            if pair.is_empty() {
                continue;
            }
            let (key, value) = pair.split_once('=').unwrap_or((pair, ""));
            params.insert(decode_component(key), Value::String(decode_component(value)));
        }
        return params;
    }
    if let Ok(Value::Object(object)) = serde_json::from_slice::<Value>(body) {
        params.extend(object);
    }
    params
}

fn decode_component(raw: &str) -> String {
    let raw = raw.replace('+', " ");
    let bytes = raw.as_bytes();
    let mut out = String::with_capacity(raw.len());
    let mut index = 0;
    while index < bytes.len() {
        if bytes[index] == b'%' && index + 2 < bytes.len() {
            if let (Some(high), Some(low)) = (
                char::from(bytes[index + 1]).to_digit(16),
                char::from(bytes[index + 2]).to_digit(16),
            ) {
                out.push(char::from_u32(high * 16 + low).unwrap_or('\u{0}'));
                index += 3;
                continue;
            }
        }
        out.push(char::from(bytes[index]));
        index += 1;
    }
    out
}
