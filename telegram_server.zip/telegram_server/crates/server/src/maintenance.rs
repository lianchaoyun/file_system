//! Periodic database / upload retention maintenance.

use std::path::Path;
use std::time::{SystemTime, UNIX_EPOCH};

use anyhow::Result;
use tsrv_store::Db;

use crate::media;
use crate::repo;

#[derive(Debug, Clone)]
pub struct MaintenanceConfig {
    pub update_log_retention_seconds: i64,
    pub upload_part_ttl_seconds: i64,
}

#[derive(Debug, Clone, Default)]
pub struct MaintenanceOutcome {
    pub pruned_updates: u64,
    pub expired_auth_keys: u64,
    pub stale_uploads: usize,
}

pub async fn run_once(
    db: &Db,
    media_dir: &Path,
    config: &MaintenanceConfig,
) -> Result<MaintenanceOutcome> {
    let now = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap_or_default()
        .as_secs() as i64;
    let pruned_updates = repo::prune_update_log(db, config.update_log_retention_seconds).await?;
    let expired_auth_keys = repo::delete_expired_auth_keys(db, now).await?;
    let stale_ids = repo::delete_stale_upload_parts(db, config.upload_part_ttl_seconds).await?;
    for upload_id in &stale_ids {
        media::remove_upload_directory(media_dir, *upload_id).await;
    }
    let outcome = MaintenanceOutcome {
        pruned_updates,
        expired_auth_keys,
        stale_uploads: stale_ids.len(),
    };
    tracing::info!(
        pruned_updates = outcome.pruned_updates,
        expired_auth_keys = outcome.expired_auth_keys,
        stale_uploads = outcome.stale_uploads,
        "maintenance completed"
    );
    Ok(outcome)
}
