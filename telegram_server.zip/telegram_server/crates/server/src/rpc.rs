//! RPC dispatch for the Layer 232 login subset.

use std::collections::{HashSet, VecDeque};
use std::fmt;
use std::io::Read;
use std::time::{Duration, SystemTime, UNIX_EPOCH};

use flate2::read::GzDecoder;
use tsrv_store::{Cache, Db};
use tsrv_tl::{ctor, types, MessageContainer, Reader, Writer};

use crate::config::Config;
use crate::langpack::LangPacks;
use crate::media;
use crate::presence;
use crate::repo::{self, UserRecord};
use crate::srp;
use crate::stickers;
use crate::update_hub::UpdateHub;

#[derive(Debug)]
pub struct RpcFailure {
    pub code: i32,
    pub message: String,
}

impl RpcFailure {
    pub fn new(code: i32, message: impl Into<String>) -> Self {
        Self {
            code,
            message: message.into(),
        }
    }

    fn internal(error: impl fmt::Display) -> Self {
        tracing::warn!(%error, "RPC failed");
        Self::new(500, "INTERNAL_SERVER_ERROR")
    }

    fn method_not_found(constructor: u32) -> Self {
        // Log each unsupported constructor once per process so a client loop
        // cannot flood the log while still surfacing missing methods.
        static LOGGED: std::sync::Mutex<Option<HashSet<u32>>> = std::sync::Mutex::new(None);
        let mut guard = LOGGED.lock().unwrap_or_else(|error| error.into_inner());
        if guard.get_or_insert_with(HashSet::new).insert(constructor) {
            tracing::warn!(
                constructor = %format_args!("0x{constructor:08X}"),
                "unsupported RPC method"
            );
        }
        Self::new(400, format!("METHOD_NOT_FOUND_0x{constructor:08X}"))
    }
}

impl From<tsrv_tl::Error> for RpcFailure {
    fn from(error: tsrv_tl::Error) -> Self {
        Self::new(400, format!("BAD_REQUEST: {error}"))
    }
}

#[derive(Default, Debug, Clone)]
pub struct ClientInfo {
    pub api_id: i32,
    pub device_model: String,
    pub system_version: String,
    pub app_version: String,
    pub lang_code: String,
}

pub struct RpcContext<'a> {
    pub db: &'a Db,
    pub cache: &'a Cache,
    pub config: &'a Config,
    pub langpacks: &'a LangPacks,
    pub updates: &'a UpdateHub,
    pub auth_key_id: i64,
    pub session_id: i64,
    pub user_id: Option<i64>,
    pub layer: i32,
    pub peer: String,
    pub client: ClientInfo,
}

pub struct Outgoing {
    pub body: Vec<u8>,
    pub service: bool,
}

pub async fn process_message(
    ctx: &mut RpcContext<'_>,
    message_id: i64,
    body: &[u8],
) -> Vec<Outgoing> {
    let mut outgoing = Vec::new();
    let mut queue = VecDeque::from([(message_id, body.to_vec())]);

    while let Some((current_id, current)) = queue.pop_front() {
        if current.len() < 4 {
            continue;
        }
        let constructor = u32::from_le_bytes(current[..4].try_into().expect("four bytes"));
        match constructor {
            ctor::MSG_CONTAINER => match MessageContainer::decode(&current) {
                Ok(container) => {
                    for message in container.messages {
                        let inner = message
                            .body
                            .get(..4)
                            .map(|bytes| u32::from_le_bytes(bytes.try_into().expect("four bytes")))
                            .unwrap_or(0);
                        tracing::debug!(
                            message_id = message.message_id,
                            seq_no = message.seq_no,
                            body_len = message.body.len(),
                            body = format_args!("0x{inner:08x}"),
                            "container message"
                        );
                        queue.push_back((message.message_id, message.body));
                    }
                }
                Err(error) => {
                    tracing::warn!(%error, "invalid msg_container");
                }
            },
            ctor::GZIP_PACKED => {
                let mut reader = Reader::new(&current);
                let _ = reader.constructor();
                match reader.bytes() {
                    Ok(compressed) => {
                        let mut decoder = GzDecoder::new(&compressed[..]);
                        let mut decompressed = Vec::new();
                        if decoder.read_to_end(&mut decompressed).is_ok() {
                            queue.push_back((current_id, decompressed));
                        } else {
                            tracing::warn!("invalid gzip_packed payload");
                        }
                    }
                    Err(error) => tracing::warn!(%error, "invalid gzip_packed"),
                }
            }
            ctor::MSGS_ACK | ctor::MSGS_STATE_REQ | 0x7d86_1a08 | 0x8cc0_d131 => {
                // Acknowledgements and state requests need no response for the
                // login subset.
            }
            ctor::PING | ctor::PING_DELAY_DISCONNECT => {
                let mut reader = Reader::new(&current);
                if reader.constructor().is_ok() {
                    if let Ok(ping_id) = reader.i64() {
                        outgoing.push(Outgoing {
                            body: tsrv_tl::pong(current_id, ping_id),
                            service: true,
                        });
                    }
                }
            }
            _ => {
                let response = match dispatch(ctx, &current).await {
                    Ok(response) => response,
                    Err(failure) => {
                        tracing::warn!(
                            code = failure.code,
                            message = %failure.message,
                            "RPC error"
                        );
                        tsrv_tl::rpc_error(failure.code, &failure.message)
                    }
                };
                outgoing.push(Outgoing {
                    body: tsrv_tl::rpc_result(current_id, &response),
                    service: false,
                });
            }
        }
        if outgoing.len() > 64 {
            tracing::warn!("too many outgoing messages in one packet");
            break;
        }
    }
    outgoing
}

async fn dispatch(ctx: &mut RpcContext<'_>, body: &[u8]) -> Result<Vec<u8>, RpcFailure> {
    let mut reader = Reader::new(body);
    let mut constructor = reader.constructor()?;
    loop {
        match constructor {
            ctor::INVOKE_WITH_LAYER => {
                ctx.layer = reader.i32()?;
                constructor = reader.constructor()?;
            }
            ctor::INVOKE_WITHOUT_UPDATES => {
                constructor = reader.constructor()?;
            }
            ctor::INVOKE_WITH_TAKEOUT => {
                let _takeout_id = reader.i64()?;
                constructor = reader.constructor()?;
            }
            ctor::INIT_CONNECTION => {
                read_init_connection(ctx, &mut reader)?;
                let next = reader.peek_raw(4)?;
                tracing::debug!(
                    next = format_args!(
                        "0x{:08x}",
                        u32::from_le_bytes(next.try_into().expect("four bytes"))
                    ),
                    remaining = reader.remaining(),
                    "initConnection query"
                );
                constructor = reader.constructor()?;
            }
            _ => break,
        }
    }

    tracing::debug!(
        method = format_args!("0x{constructor:08x}"),
        layer = ctx.layer,
        "dispatching RPC"
    );
    match constructor {
        ctor::AUTH_SEND_CODE => send_code(ctx, &mut reader).await,
        ctor::AUTH_EXPORT_LOGIN_TOKEN => export_login_token(ctx, &mut reader).await,
        ctor::AUTH_IMPORT_LOGIN_TOKEN => import_login_token(ctx, &mut reader).await,
        ctor::AUTH_SIGN_IN => sign_in(ctx, &mut reader).await,
        ctor::AUTH_SIGN_UP => sign_up(ctx, &mut reader).await,
        ctor::AUTH_CHECK_PASSWORD => auth_check_password(ctx, &mut reader).await,
        ctor::AUTH_IMPORT_BOT_AUTHORIZATION => import_bot_authorization(ctx, &mut reader).await,
        ctor::MESSAGES_GET_BOT_CALLBACK_ANSWER => {
            messages_get_bot_callback_answer(ctx, &mut reader).await
        }
        ctor::AUTH_LOG_OUT => {
            repo::delete_session(ctx.db, ctx.auth_key_id)
                .await
                .map_err(RpcFailure::internal)?;
            ctx.user_id = None;
            Ok(types::bool_true())
        }
        ctor::AUTH_RESET_AUTHORIZATIONS => auth_reset_authorizations(ctx).await,
        ctor::HELP_GET_CONFIG => {
            let listen = ctx.config.listen;
            let ip = if listen.ip().is_unspecified() {
                "127.0.0.1".to_owned()
            } else {
                listen.ip().to_string()
            };
            Ok(types::config(2, &ip, listen.port() as i32, now() as i32))
        }
        ctor::HELP_GET_NEAREST_DC => Ok(types::nearest_dc("CN", 2, 2)),
        ctor::HELP_GET_APP_CONFIG => Ok(types::app_config_not_modified()),
        ctor::HELP_GET_INVITE_TEXT => Ok(types::help_invite_text(
            "Welcome to the experimental server",
        )),
        ctor::HELP_GET_SUPPORT => {
            let user = ctx_user(ctx)
                .await?
                .map(user_bytes)
                .unwrap_or_else(|| types::user_empty(0));
            Ok(types::help_support(&user))
        }
        ctor::HELP_GET_TERMS_OF_SERVICE_UPDATE => Ok(types::terms_of_service_update_empty(0)),
        ctor::USERS_GET_USERS => users_get_users(ctx, &mut reader).await,
        ctor::USERS_GET_FULL_USER => users_get_full_user(ctx, &mut reader).await,
        ctor::CONTACTS_GET_CONTACTS => {
            let _hash = reader.i64()?;
            let Some(user_id) = ctx.user_id else {
                return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
            };
            let users = repo::list_contacts(ctx.db, user_id)
                .await
                .map_err(RpcFailure::internal)?;
            let contacts: Vec<Vec<u8>> = users.iter().map(|user| types::contact(user.id)).collect();
            let user_bytes: Vec<Vec<u8>> = users.iter().map(other_user_bytes).collect();
            Ok(types::contacts_contacts(&contacts, &user_bytes))
        }
        ctor::CONTACTS_ADD_CONTACT => contacts_add_contact(ctx, &mut reader).await,
        ctor::CONTACTS_DELETE_CONTACTS => contacts_delete_contacts(ctx, &mut reader).await,
        ctor::CONTACTS_BLOCK => contacts_block(ctx, &mut reader, true).await,
        ctor::CONTACTS_UNBLOCK => contacts_block(ctx, &mut reader, false).await,
        ctor::CONTACTS_SEARCH => {
            let _flags = reader.u32()?;
            let query = reader.string()?;
            let limit = reader.i32()?;
            let Some(user_id) = ctx.user_id else {
                return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
            };
            let query = query.trim();
            if query.is_empty() {
                return Ok(types::contacts_found(&[], &[], &[], &[]));
            }
            let users = repo::search_users(ctx.db, query, limit, user_id)
                .await
                .map_err(RpcFailure::internal)?;
            let peers: Vec<Vec<u8>> = users.iter().map(|user| types::peer_user(user.id)).collect();
            let users_bytes: Vec<Vec<u8>> = users.iter().map(other_user_bytes).collect();
            Ok(types::contacts_found(&[], &peers, &[], &users_bytes))
        }
        ctor::MESSAGES_GET_DIALOGS => {
            let (dialogs, messages, chats, users) = load_dialogs(ctx).await?;
            Ok(types::messages_dialogs(&dialogs, &messages, &chats, &users))
        }
        ctor::MESSAGES_GET_PEER_DIALOGS => {
            let (dialogs, messages, chats, users) = load_dialogs(ctx).await?;
            let state = types::updates_state(user_pts(ctx).await?, 0, now() as i32, 0, 0);
            Ok(types::messages_peer_dialogs(
                &dialogs, &messages, &chats, &users, &state,
            ))
        }
        ctor::MESSAGES_GET_PINNED_DIALOGS => {
            let _folder_id = reader.i32()?;
            let (dialogs, messages, chats, users) = load_pinned_dialogs(ctx).await?;
            let state = types::updates_state(user_pts(ctx).await?, 0, now() as i32, 0, 0);
            Ok(types::messages_peer_dialogs(
                &dialogs, &messages, &chats, &users, &state,
            ))
        }
        ctor::MESSAGES_SAVE_DRAFT => messages_save_draft(ctx, &mut reader).await,
        ctor::MESSAGES_GET_ALL_DRAFTS => messages_get_all_drafts(ctx).await,
        ctor::MESSAGES_TOGGLE_DIALOG_PIN => messages_toggle_dialog_pin(ctx, &mut reader).await,
        ctor::MESSAGES_REORDER_PINNED_DIALOGS => {
            messages_reorder_pinned_dialogs(ctx, &mut reader).await
        }
        ctor::MESSAGES_UPDATE_DIALOG_FILTER => {
            messages_update_dialog_filter(ctx, &mut reader).await
        }
        ctor::MESSAGES_GET_HISTORY => messages_get_history(ctx, &mut reader).await,
        ctor::MESSAGES_SEND_MESSAGE => messages_send_message(ctx, &mut reader).await,
        ctor::MESSAGES_SEND_MEDIA => messages_send_media(ctx, &mut reader).await,
        ctor::MESSAGES_SEND_MULTI_MEDIA => messages_send_multi_media(ctx, &mut reader).await,
        ctor::MESSAGES_EDIT_MESSAGE => messages_edit_message(ctx, &mut reader).await,
        ctor::MESSAGES_DELETE_MESSAGES => messages_delete_messages(ctx, &mut reader).await,
        ctor::MESSAGES_FORWARD_MESSAGES => messages_forward_messages(ctx, &mut reader).await,
        ctor::MESSAGES_UPDATE_PINNED_MESSAGE => {
            messages_update_pinned_message(ctx, &mut reader).await
        }
        ctor::PHOTOS_UPLOAD_PROFILE_PHOTO => photos_upload_profile_photo(ctx, &mut reader).await,
        ctor::PHOTOS_UPDATE_PROFILE_PHOTO => photos_update_profile_photo(ctx, &mut reader).await,
        ctor::PHOTOS_GET_USER_PHOTOS => photos_get_user_photos(ctx, &mut reader).await,
        ctor::MESSAGES_GET_MESSAGES => messages_get_messages(ctx, &mut reader).await,
        ctor::MESSAGES_CREATE_CHAT => messages_create_chat(ctx, &mut reader).await,
        ctor::MESSAGES_GET_CHATS => messages_get_chats(ctx, &mut reader).await,
        ctor::MESSAGES_GET_FULL_CHAT => messages_get_full_chat(ctx, &mut reader).await,
        ctor::MESSAGES_ADD_CHAT_USER => messages_add_chat_user(ctx, &mut reader).await,
        ctor::MESSAGES_DELETE_CHAT_USER => messages_delete_chat_user(ctx, &mut reader).await,
        ctor::MESSAGES_EDIT_CHAT_TITLE => messages_edit_chat_title(ctx, &mut reader).await,
        ctor::MESSAGES_UNPIN_ALL_MESSAGES => messages_unpin_all_messages(ctx, &mut reader).await,
        ctor::MESSAGES_DELETE_HISTORY => messages_delete_history(ctx, &mut reader).await,
        ctor::MESSAGES_DELETE_CHAT => messages_delete_chat(ctx, &mut reader).await,
        ctor::MESSAGES_SEND_REACTION => messages_send_reaction(ctx, &mut reader).await,
        ctor::MESSAGES_SEND_VOTE => messages_send_vote(ctx, &mut reader).await,
        ctor::MESSAGES_GET_POLL_RESULTS => messages_get_poll_results(ctx, &mut reader).await,
        ctor::MESSAGES_EDIT_CHAT_PHOTO => messages_edit_chat_photo(ctx, &mut reader).await,
        ctor::CHANNELS_EDIT_PHOTO => channels_edit_photo(ctx, &mut reader).await,
        ctor::CHANNELS_DELETE_MESSAGES => channels_delete_messages(ctx, &mut reader).await,
        ctor::CHANNELS_GET_MESSAGES => channels_get_messages(ctx, &mut reader).await,
        ctor::MESSAGES_UPLOAD_MEDIA => messages_upload_media(ctx, &mut reader).await,
        ctor::MESSAGES_READ_HISTORY => messages_read_history(ctx, &mut reader).await,
        ctor::AUTH_BIND_TEMP_AUTH_KEY => auth_bind_temp_auth_key(ctx, &mut reader).await,
        ctor::UPLOAD_SAVE_FILE_PART => upload_save_file_part(ctx, &mut reader, false).await,
        ctor::UPLOAD_SAVE_BIG_FILE_PART => upload_save_file_part(ctx, &mut reader, true).await,
        ctor::UPLOAD_GET_FILE => upload_get_file(ctx, &mut reader).await,
        ctor::UPLOAD_GET_FILE_HASHES => upload_get_file_hashes(ctx, &mut reader).await,
        ctor::MESSAGES_GET_STICKERS => {
            let emoticon = reader.string()?;
            let hash = reader.i64()?;
            Ok(match stickers::pack() {
                Some(pack) => types::messages_stickers(
                    hash,
                    &stickers::documents_for_emoticon(pack, &emoticon),
                ),
                None => types::messages_stickers_empty(hash),
            })
        }
        ctor::MESSAGES_GET_STICKER_SET => messages_get_sticker_set(&mut reader),
        ctor::MESSAGES_GET_CUSTOM_EMOJI_DOCUMENTS => {
            let ids = reader.vector(|reader| reader.i64())?;
            Ok(match stickers::pack() {
                Some(pack) => types::document_vector(&stickers::documents_by_ids(pack, &ids)),
                None => types::document_vector(&[]),
            })
        }
        ctor::MESSAGES_GET_FEATURED_STICKERS | ctor::MESSAGES_GET_FEATURED_EMOJI_STICKERS => {
            Ok(types::messages_featured_stickers_not_modified(0))
        }
        ctor::MESSAGES_GET_PEER_SETTINGS => Ok(types::messages_peer_settings()),
        ctor::MESSAGES_GET_DIALOG_FILTERS => messages_get_dialog_filters(ctx).await,
        ctor::MESSAGES_GET_AVAILABLE_REACTIONS => {
            Ok(types::messages_available_reactions_not_modified())
        }
        ctor::MESSAGES_GET_ATTACH_MENU_BOTS => Ok(types::attach_menu_bots_not_modified()),
        ctor::MESSAGES_GET_EMOJI_GROUPS | ctor::MESSAGES_GET_EMOJI_STICKER_GROUPS => {
            Ok(types::messages_emoji_groups_not_modified())
        }
        ctor::MESSAGES_GET_QUICK_REPLIES => Ok(types::messages_quick_replies_not_modified()),
        ctor::MESSAGES_GET_RECENT_STICKERS => {
            let _flags = reader.u32()?;
            let _hash = reader.i64()?;
            Ok(types::bare(ctor::MESSAGES_RECENT_STICKERS_NOT_MODIFIED))
        }
        ctor::MESSAGES_GET_FAVED_STICKERS => {
            let _hash = reader.i64()?;
            Ok(types::bare(ctor::MESSAGES_FAVED_STICKERS_NOT_MODIFIED))
        }
        ctor::MESSAGES_GET_SAVED_GIFS => {
            let _hash = reader.i64()?;
            Ok(types::bare(ctor::MESSAGES_SAVED_GIFS_NOT_MODIFIED))
        }
        ctor::MESSAGES_GET_ALL_STICKERS => {
            let _hash = reader.i64()?;
            Ok(types::bare(ctor::MESSAGES_ALL_STICKERS_NOT_MODIFIED))
        }
        ctor::MESSAGES_GET_EMOJI_STICKERS => {
            let hash = reader.i64()?;
            Ok(match stickers::pack() {
                Some(pack) if pack.emojis => {
                    types::messages_all_stickers(hash, &[stickers::set_bytes(pack)])
                }
                _ => types::bare(ctor::MESSAGES_ALL_STICKERS_NOT_MODIFIED),
            })
        }
        ctor::MESSAGES_GET_RECENT_REACTIONS => {
            let _limit = reader.i32()?;
            let _hash = reader.i64()?;
            Ok(types::bare(ctor::MESSAGES_REACTIONS_NOT_MODIFIED))
        }
        ctor::MESSAGES_GET_DEFAULT_TAG_REACTIONS => {
            let _hash = reader.i64()?;
            Ok(types::bare(ctor::MESSAGES_REACTIONS_NOT_MODIFIED))
        }
        ctor::MESSAGES_GET_SAVED_REACTION_TAGS => {
            let flags = reader.u32()?;
            if flags & 1 != 0 {
                let _peer = read_input_peer(ctx, &mut reader)?;
            }
            let _hash = reader.i64()?;
            Ok(types::bare(ctor::MESSAGES_SAVED_REACTION_TAGS_NOT_MODIFIED))
        }
        ctor::MESSAGES_GET_DEFAULT_HISTORY_TTL => Ok(types::default_history_ttl(0)),
        ctor::MESSAGES_GET_EMOJI_KEYWORDS_LANGUAGES => {
            let lang_codes = reader.vector(|reader| reader.string())?;
            Ok(types::emoji_languages(&lang_codes))
        }
        ctor::MESSAGES_GET_EMOJI_KEYWORDS_DIFFERENCE => {
            let lang_code = reader.string()?;
            let from_version = reader.i32()?;
            Ok(types::emoji_keywords_difference(
                &lang_code,
                from_version,
                from_version,
            ))
        }
        ctor::MESSAGES_GET_EMOJI_KEYWORDS => {
            let lang_code = reader.string()?;
            Ok(types::emoji_keywords_difference(&lang_code, 0, 0))
        }
        ctor::MESSAGES_EXPORT_CHAT_INVITE => messages_export_chat_invite(ctx, &mut reader).await,
        ctor::MESSAGES_SET_TYPING => messages_set_typing(ctx, &mut reader).await,
        ctor::CHANNELS_READ_HISTORY => {
            let (channel_id, _access_hash) = read_input_channel(&mut reader)?;
            let max_id = reader.i32()?;
            if let Some(user_id) = ctx.user_id {
                if let Some(channel) = repo::find_channel(ctx.db, channel_id)
                    .await
                    .map_err(RpcFailure::internal)?
                {
                    repo::read_history(ctx.db, user_id, channel.id, i64::from(max_id))
                        .await
                        .map_err(RpcFailure::internal)?;
                    // `updateReadChannelOutbox` has no PTS; sync the reader's other
                    // sessions without touching the channel PTS stream.
                    let update = types::update_read_channel_outbox(channel.id, max_id);
                    let push = types::updates(&[update], &[], now() as i32, 0);
                    ctx.updates
                        .publish_excluding(user_id, Some(ctx.session_id), push);
                }
            }
            Ok(types::bool_true())
        }
        ctor::CHANNELS_CHECK_USERNAME => channels_check_username(ctx, &mut reader).await,
        ctor::CHANNELS_UPDATE_USERNAME => channels_update_username(ctx, &mut reader).await,
        ctor::CHANNELS_EDIT_ADMIN => channels_edit_admin(ctx, &mut reader).await,
        ctor::CHANNELS_EDIT_BANNED => channels_edit_banned(ctx, &mut reader).await,
        ctor::MESSAGES_CHECK_CHAT_INVITE => messages_check_chat_invite(ctx, &mut reader).await,
        ctor::MESSAGES_IMPORT_CHAT_INVITE => messages_import_chat_invite(ctx, &mut reader).await,
        ctor::ACCOUNT_CHECK_USERNAME => account_check_username(ctx, &mut reader).await,
        ctor::ACCOUNT_UPDATE_USERNAME => account_update_username(ctx, &mut reader).await,
        ctor::CONTACTS_RESOLVE_USERNAME => contacts_resolve_username(ctx, &mut reader).await,
        ctor::CHANNELS_GET_SEND_AS => {
            let _flags = reader.u32()?;
            let _peer = read_input_peer(ctx, &mut reader)?;
            Ok(types::channels_send_as_peers_empty())
        }
        ctor::MESSAGES_GET_MESSAGES_VIEWS => messages_get_message_views(ctx, &mut reader).await,
        ctor::MESSAGES_GET_SPONSORED_MESSAGES => {
            let flags = reader.u32()?;
            let _peer = read_input_peer(ctx, &mut reader)?;
            if flags & 1 != 0 {
                let _msg_id = reader.i32()?;
            }
            Ok(types::bare(ctor::MESSAGES_SPONSORED_MESSAGES_EMPTY))
        }
        ctor::PAYMENTS_GET_CURRENCY_RATES => Ok(types::payments_currency_rates_empty()),
        ctor::ACCOUNT_GET_PRIVACY => {
            let key = reader.constructor()?;
            let Some(user_id) = ctx.user_id else {
                return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
            };
            let rules = repo::privacy_rules(ctx.db, user_id, i64::from(key))
                .await
                .map_err(RpcFailure::internal)?;
            let rule_bytes = match rules {
                Some(rules) => privacy_rule_bytes(&rules),
                None => vec![types::privacy_value_allow_all()],
            };
            Ok(types::account_privacy_rules(&rule_bytes))
        }
        ctor::ACCOUNT_SET_PRIVACY => account_set_privacy(ctx, &mut reader).await,
        ctor::ACCOUNT_GET_WEB_AUTHORIZATIONS => Ok(types::account_web_authorizations_empty()),
        ctor::CONTACTS_GET_BLOCKED => {
            let _flags = reader.u32()?;
            let offset = reader.i32()?.max(0) as usize;
            let limit = reader.i32()?;
            let Some(user_id) = ctx.user_id else {
                return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
            };
            let records = repo::list_blocked(ctx.db, user_id)
                .await
                .map_err(RpcFailure::internal)?;
            let take = if limit <= 0 { 100 } else { limit as usize };
            let mut blocked = Vec::new();
            let mut users = Vec::new();
            for (user, blocked_at) in records.into_iter().skip(offset).take(take) {
                blocked.push(types::peer_blocked(
                    &types::peer_user(user.id),
                    blocked_at as i32,
                ));
                users.push(other_user_bytes(&user));
            }
            Ok(types::contacts_blocked(&blocked, &[], &users))
        }
        ctor::MESSAGES_GET_SHARE_THEME_BACKDROPS => {
            let _hash = reader.i32()?;
            Ok(types::bare(ctor::SHARE_THEME_BACKDROPS_NOT_MODIFIED))
        }
        ctor::STORIES_GET_ALBUMS => {
            let _peer = read_input_peer(ctx, &mut reader)?;
            let hash = reader.i64()?;
            Ok(types::stories_albums_empty(hash))
        }
        ctor::STORIES_GET_PINNED_STORIES => {
            let _peer = read_input_peer(ctx, &mut reader)?;
            let _offset_id = reader.i32()?;
            let _limit = reader.i32()?;
            Ok(types::stories_stories_empty())
        }
        ctor::PAYMENTS_GET_SAVED_STAR_GIFTS => {
            let flags = reader.u32()?;
            let _peer = read_input_peer(ctx, &mut reader)?;
            if flags & (1 << 6) != 0 {
                let _collection_id = reader.i32()?;
            }
            let _offset = reader.string()?;
            let _limit = reader.i32()?;
            Ok(types::payments_saved_star_gifts_empty())
        }
        ctor::MESSAGES_REPORT_READ_METRICS => Ok(types::bool_true()),
        ctor::ACCOUNT_GET_SAVED_RINGTONES => {
            let _hash = reader.i64()?;
            Ok(types::bare(ctor::ACCOUNT_SAVED_RINGTONES_NOT_MODIFIED))
        }
        ctor::ACCOUNT_GET_WALL_PAPERS => {
            let _hash = reader.i64()?;
            Ok(types::bare(ctor::ACCOUNT_WALL_PAPERS_NOT_MODIFIED))
        }
        ctor::HELP_GET_TIMEZONES_LIST => {
            let _hash = reader.i32()?;
            Ok(types::bare(ctor::HELP_TIMEZONES_LIST_NOT_MODIFIED))
        }
        ctor::MESSAGES_GET_SCHEDULED_HISTORY => {
            messages_get_scheduled_history(ctx, &mut reader).await
        }
        ctor::MESSAGES_SEND_SCHEDULED_MESSAGES => {
            messages_send_scheduled_messages(ctx, &mut reader).await
        }
        ctor::MESSAGES_DELETE_SCHEDULED_MESSAGES => {
            messages_delete_scheduled_messages(ctx, &mut reader).await
        }
        ctor::MESSAGES_SEARCH => messages_search(ctx, &mut reader).await,
        ctor::MESSAGES_SEARCH_GLOBAL => messages_search_global(ctx, &mut reader).await,
        ctor::ACCOUNT_GET_NOTIFY_SETTINGS => Ok(types::peer_notify_settings()),
        ctor::ACCOUNT_GET_REACTIONS_NOTIFY_SETTINGS => {
            let Some(user_id) = ctx.user_id else {
                return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
            };
            let settings = match repo::reaction_notify_settings(ctx.db, user_id)
                .await
                .map_err(RpcFailure::internal)?
            {
                Some(value) => reactions_notify_settings_from_json(&value),
                None => types::ReactionsNotifySettings::default(),
            };
            Ok(types::reactions_notify_settings(&settings))
        }
        ctor::ACCOUNT_SET_REACTIONS_NOTIFY_SETTINGS => {
            account_set_reactions_notify_settings(ctx, &mut reader).await
        }
        ctor::ACCOUNT_GET_DEFAULT_EMOJI_STATUSES | ctor::ACCOUNT_GET_RECENT_EMOJI_STATUSES => {
            let hash = reader.i64()?;
            Ok(match stickers::pack() {
                Some(pack) => {
                    types::account_emoji_statuses(hash, &stickers::default_statuses(pack, 6))
                }
                None => types::account_emoji_statuses_not_modified(),
            })
        }
        ctor::ACCOUNT_UPDATE_EMOJI_STATUS => account_update_emoji_status(ctx, &mut reader).await,
        ctor::ACCOUNT_GET_THEMES => Ok(types::account_themes_not_modified()),
        ctor::CONTACTS_GET_TOP_PEERS => Ok(types::contacts_top_peers_not_modified()),
        ctor::HELP_GET_PEER_COLORS | ctor::HELP_GET_PEER_PROFILE_COLORS => {
            Ok(types::help_peer_colors_not_modified())
        }
        ctor::HELP_GET_COUNTRIES_LIST => Ok(types::help_countries_list_not_modified()),
        ctor::HELP_GET_PROMO_DATA => Ok(types::help_promo_data_empty(0)),
        ctor::CHANNELS_CREATE_CHANNEL => channels_create_channel(ctx, &mut reader).await,
        ctor::CHANNELS_JOIN_CHANNEL => channels_join_channel(ctx, &mut reader).await,
        ctor::CHANNELS_LEAVE_CHANNEL => channels_leave_channel(ctx, &mut reader).await,
        ctor::CHANNELS_INVITE_TO_CHANNEL => channels_invite_to_channel(ctx, &mut reader).await,
        ctor::CHANNELS_GET_FULL_CHANNEL => channels_get_full_channel(ctx, &mut reader).await,
        ctor::CHANNELS_GET_PARTICIPANTS => channels_get_participants(ctx, &mut reader).await,
        ctor::STORIES_GET_ALL_STORIES => Ok(types::stories_all_stories_empty()),
        ctor::HELP_GET_PREMIUM_PROMO => Ok(types::help_premium_promo_empty()),
        ctor::UPDATES_GET_STATE => updates_get_state(ctx).await,
        ctor::UPDATES_GET_DIFFERENCE | ctor::UPDATES_GET_DIFFERENCE_LEGACY => {
            updates_get_difference(ctx, &mut reader).await
        }
        ctor::UPDATES_GET_CHANNEL_DIFFERENCE => {
            updates_get_channel_difference(ctx, &mut reader).await
        }
        ctor::ACCOUNT_GET_AUTHORIZATIONS => account_get_authorizations(ctx).await,
        ctor::ACCOUNT_RESET_AUTHORIZATION => account_reset_authorization(ctx, &mut reader).await,
        ctor::ACCOUNT_UPDATE_PROFILE => account_update_profile(ctx, &mut reader).await,
        ctor::ACCOUNT_UPDATE_BIRTHDAY => account_update_birthday(ctx, &mut reader).await,
        ctor::ACCOUNT_UPDATE_STATUS => {
            let offline = reader.bool()?;
            let Some(user_id) = ctx.user_id else {
                return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
            };
            let session = (ctx.auth_key_id, ctx.session_id);
            if offline {
                if presence::global().mark_offline(user_id, session) {
                    announce_presence(ctx.db, ctx.updates, user_id, false).await?;
                }
            } else if presence::global().mark_online(user_id, session) {
                announce_presence(ctx.db, ctx.updates, user_id, true).await?;
            }
            Ok(types::bool_true())
        }
        ctor::ACCOUNT_GET_PASSWORD => account_get_password(ctx).await,
        ctor::ACCOUNT_UPDATE_PASSWORD_SETTINGS => {
            account_update_password_settings(ctx, &mut reader).await
        }
        ctor::ACCOUNT_GET_PASSWORD_SETTINGS => {
            account_get_password_settings(ctx, &mut reader).await
        }
        ctor::ACCOUNT_GET_CONTACT_SIGN_UP_NOTIFICATION => Ok(types::bool_false()),
        ctor::ACCOUNT_GET_CONTENT_SETTINGS => Ok(types::account_content_settings(false, true)),
        ctor::ACCOUNT_GET_GLOBAL_PRIVACY_SETTINGS => Ok(types::global_privacy_settings_default()),
        ctor::ACCOUNT_GET_COLLECTIBLE_EMOJI_STATUSES => {
            let hash = reader.i64()?;
            Ok(types::account_emoji_statuses(hash, &[]))
        }
        ctor::MESSAGES_GET_WEB_PAGE => {
            let _url = reader.string()?;
            let _hash = reader.i32()?;
            Ok(types::messages_web_page_empty(0))
        }
        ctor::PAYMENTS_GET_STAR_GIFT_ACTIVE_AUCTIONS => {
            let _hash = reader.i64()?;
            Ok(types::payments_star_gift_active_auctions_empty())
        }
        ctor::STORIES_GET_STORIES_ARCHIVE => {
            let _peer = read_input_peer(ctx, &mut reader)?;
            let _offset_id = reader.i32()?;
            let _limit = reader.i32()?;
            Ok(types::stories_stories_empty())
        }
        ctor::AICOMPOSE_GET_TONES => {
            let hash = reader.i64()?;
            Ok(types::aicompose_tones(hash))
        }
        ctor::LANG_PACK_GET_LANG_PACK => {
            let _lang_pack = reader.string()?;
            let lang_code = reader.string().unwrap_or_else(|_| "en".to_owned());
            Ok(lang_pack_get_lang_pack(ctx, &lang_code))
        }
        ctor::LANG_PACK_GET_DIFFERENCE => {
            let _lang_pack = reader.string()?;
            let lang_code = reader.string().unwrap_or_else(|_| "en".to_owned());
            let from_version = reader.i32()?;
            Ok(lang_pack_get_difference(ctx, &lang_code, from_version))
        }
        ctor::LANG_PACK_GET_STRINGS => {
            let _lang_pack = reader.string()?;
            let lang_code = reader.string()?;
            let keys = reader.vector(|reader| reader.string())?;
            Ok(lang_pack_get_strings(ctx, &lang_code, &keys))
        }
        ctor::LANG_PACK_GET_LANGUAGE => {
            let _lang_pack = reader.string()?;
            let lang_code = reader.string()?;
            Ok(lang_pack_get_language(ctx, &lang_code)?)
        }
        ctor::LANG_PACK_GET_LANGUAGES | ctor::LANG_PACK_GET_LANGUAGES_ALT => {
            Ok(types::lang_pack_languages(&ctx.langpacks.languages()))
        }
        ctor::DESTROY_SESSION => {
            let session_id = reader.i64()?;
            Ok(types::destroy_session_none(session_id))
        }
        other => Err(RpcFailure::method_not_found(other)),
    }
}

fn read_init_connection(
    ctx: &mut RpcContext<'_>,
    reader: &mut Reader<'_>,
) -> Result<(), RpcFailure> {
    let flags = reader.u32()?;
    ctx.client.api_id = reader.i32()?;
    ctx.client.device_model = reader.string()?;
    ctx.client.system_version = reader.string()?;
    ctx.client.app_version = reader.string()?;
    let _system_lang_code = reader.string()?;
    let _lang_pack = reader.string()?;
    ctx.client.lang_code = reader.string()?;
    tracing::debug!(
        flags,
        api_id = ctx.client.api_id,
        device = %ctx.client.device_model,
        system = %ctx.client.system_version,
        app = %ctx.client.app_version,
        lang = %ctx.client.lang_code,
        remaining = reader.remaining(),
        "initConnection"
    );
    if flags & 1 != 0 {
        // InputClientProxy: constructor, address, port.
        let _ = reader.constructor()?;
        let _ = reader.string()?;
        let _ = reader.i32()?;
    }
    if flags & 2 != 0 {
        skip_json_value(reader)?;
    }
    Ok(())
}

fn skip_json_value(reader: &mut Reader<'_>) -> Result<(), RpcFailure> {
    match reader.constructor()? {
        0x3f6d7b68 => Ok(()), // jsonNull
        0xc7345e6a => {
            let _ = reader.bool()?;
            Ok(())
        }
        0x2be0dfa4 => {
            let _ = reader.f64()?;
            Ok(())
        }
        0xb71e767a => {
            let _ = reader.string()?;
            Ok(())
        }
        0xf7444763 => {
            reader.expect_constructor(ctor::VECTOR)?;
            let count = reader.i32()?;
            for _ in 0..count.max(0) {
                skip_json_value(reader)?;
            }
            Ok(())
        }
        0x99c1d49d => {
            reader.expect_constructor(ctor::VECTOR)?;
            let count = reader.i32()?;
            for _ in 0..count.max(0) {
                // jsonObjectValue#c0de1bd9 key:string value:JSONValue
                let _ = reader.constructor()?;
                let _ = reader.string()?;
                skip_json_value(reader)?;
            }
            Ok(())
        }
        other => Err(RpcFailure::new(
            400,
            format!("BAD_JSON_VALUE_0x{other:08X}"),
        )),
    }
}

async fn send_code(
    ctx: &mut RpcContext<'_>,
    reader: &mut Reader<'_>,
) -> Result<Vec<u8>, RpcFailure> {
    let raw_phone = reader.string()?;
    let _api_id = reader.i32()?;
    let _api_hash = reader.string()?;
    let Some(phone) = normalize_phone(&raw_phone) else {
        tracing::debug!(raw_phone = %raw_phone, "invalid phone number");
        return Err(RpcFailure::new(400, "PHONE_NUMBER_INVALID"));
    };
    tracing::debug!(raw_phone = %raw_phone, normalized = %phone, "auth.sendCode");
    let phone_code_hash = random_hex(16);
    let key = auth_code_key(&phone);
    let value = format!("{phone_code_hash}|{}", ctx.config.fixed_auth_code);
    ctx.cache
        .set_ex(&key, &value, 300)
        .await
        .map_err(RpcFailure::internal)?;
    tracing::info!(%phone, hash = %phone_code_hash, "auth code issued");
    Ok(types::auth_sent_code(&phone_code_hash, 5))
}

async fn account_get_authorizations(ctx: &mut RpcContext<'_>) -> Result<Vec<u8>, RpcFailure> {
    let Some(user_id) = ctx.user_id else {
        return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
    };
    let sessions = repo::list_user_sessions(ctx.db, user_id)
        .await
        .map_err(RpcFailure::internal)?;
    let authorizations: Vec<types::Authorization> = sessions
        .into_iter()
        .map(|session| types::Authorization {
            hash: session.auth_key_id,
            current: session.auth_key_id == ctx.auth_key_id,
            device_model: if session.device_model.is_empty() {
                "Unknown device".to_owned()
            } else {
                session.device_model
            },
            platform: session.platform,
            system_version: session.system_version,
            api_id: session.api_id,
            app_name: if session.app_name.is_empty() {
                "tsrv".to_owned()
            } else {
                session.app_name
            },
            app_version: session.app_version,
            date_created: session.created_at as i32,
            date_active: session.last_active_at as i32,
            ip: session.ip,
            country: String::new(),
            region: String::new(),
        })
        .collect();
    Ok(types::account_authorizations(&authorizations))
}

async fn account_reset_authorization(
    ctx: &mut RpcContext<'_>,
    reader: &mut Reader<'_>,
) -> Result<Vec<u8>, RpcFailure> {
    let hash = reader.i64()?;
    let Some(user_id) = ctx.user_id else {
        return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
    };
    let revoked = repo::delete_user_session(ctx.db, user_id, hash)
        .await
        .map_err(RpcFailure::internal)?;
    if !revoked {
        return Ok(types::bool_false());
    }
    if hash == ctx.auth_key_id {
        ctx.user_id = None;
    }
    Ok(types::bool_true())
}

async fn auth_reset_authorizations(ctx: &mut RpcContext<'_>) -> Result<Vec<u8>, RpcFailure> {
    let Some(user_id) = ctx.user_id else {
        return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
    };
    repo::delete_other_user_sessions(ctx.db, user_id, ctx.auth_key_id)
        .await
        .map_err(RpcFailure::internal)?;
    Ok(types::bool_true())
}

async fn export_login_token(
    ctx: &mut RpcContext<'_>,
    reader: &mut Reader<'_>,
) -> Result<Vec<u8>, RpcFailure> {
    let api_id = reader.i32()?;
    let _api_hash = reader.string()?;
    let _except_ids = reader.vector(|reader| reader.i64())?;
    let now_secs = now();

    // A previously displayed QR code may have been scanned meanwhile.
    if let Some(user_id) = repo::take_confirmed_login_token(ctx.db, ctx.auth_key_id, now_secs as i64)
        .await
        .map_err(RpcFailure::internal)?
    {
        let Some(user) = repo::find_user_by_id(ctx.db, user_id)
            .await
            .map_err(RpcFailure::internal)?
        else {
            return Err(RpcFailure::new(400, "LOGIN_TOKEN_INVALID"));
        };
        authorize(ctx, &user).await?;
        ensure_system_welcome(ctx, user.id).await;
        return Ok(types::auth_login_token_success(&types::auth_authorization(
            &user_bytes(user),
        )));
    }

    let token: [u8; 32] = rand::random();
    let expires_at = now_secs as i64 + 120;
    repo::create_login_token(
        ctx.db,
        &token,
        ctx.auth_key_id,
        api_id,
        now_secs as i64,
        expires_at,
    )
    .await
    .map_err(RpcFailure::internal)?;
    Ok(types::auth_login_token(expires_at as i32, &token))
}

async fn import_login_token(
    ctx: &mut RpcContext<'_>,
    reader: &mut Reader<'_>,
) -> Result<Vec<u8>, RpcFailure> {
    let token = reader.bytes()?;
    let Some(user_id) = ctx.user_id else {
        return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
    };
    let confirmed = repo::confirm_login_token(ctx.db, &token, user_id, now() as i64)
        .await
        .map_err(RpcFailure::internal)?;
    if !confirmed {
        return Err(RpcFailure::new(400, "LOGIN_TOKEN_INVALID"));
    }
    let Some(user) = repo::find_user_by_id(ctx.db, user_id)
        .await
        .map_err(RpcFailure::internal)?
    else {
        return Err(RpcFailure::new(400, "LOGIN_TOKEN_INVALID"));
    };
    Ok(types::auth_login_token_success(&types::auth_authorization(
        &user_bytes(user),
    )))
}

async fn messages_get_bot_callback_answer(
    ctx: &mut RpcContext<'_>,
    reader: &mut Reader<'_>,
) -> Result<Vec<u8>, RpcFailure> {
    let flags = reader.u32()?;
    let peer = read_input_peer(ctx, reader)?;
    let msg_id = reader.i32()?;
    let data = if flags & 1 != 0 {
        Some(reader.bytes()?)
    } else {
        None
    };
    if flags & 2 != 0 {
        return Err(RpcFailure::new(400, "CALLBACK_PASSWORD_UNSUPPORTED"));
    }
    let Some(user_id) = ctx.user_id else {
        return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
    };
    let PeerRef::User(bot_user_id) = peer else {
        return Err(RpcFailure::new(400, "BUTTON_NOT_FOUND"));
    };
    let Some(record) = repo::find_message(ctx.db, i64::from(msg_id))
        .await
        .map_err(RpcFailure::internal)?
    else {
        return Err(RpcFailure::new(400, "BUTTON_NOT_FOUND"));
    };
    let Some(chat) = repo::find_chat(ctx.db, record.chat_id)
        .await
        .map_err(RpcFailure::internal)?
    else {
        return Err(RpcFailure::new(400, "BUTTON_NOT_FOUND"));
    };
    let in_private_chat = chat.kind == "private"
        && ((chat.private_user_a == Some(user_id) && chat.private_user_b == Some(bot_user_id))
            || (chat.private_user_a == Some(bot_user_id)
                && chat.private_user_b == Some(user_id)));
    if !in_private_chat || record.sender_user_id != bot_user_id {
        return Err(RpcFailure::new(400, "BUTTON_NOT_FOUND"));
    }
    let Some(bot) = repo::find_user_by_id(ctx.db, bot_user_id)
        .await
        .map_err(RpcFailure::internal)?
    else {
        return Err(RpcFailure::new(400, "BUTTON_NOT_FOUND"));
    };
    if !bot.is_bot {
        return Err(RpcFailure::new(400, "BUTTON_NOT_FOUND"));
    }
    let data_text = data
        .as_ref()
        .map(|bytes| String::from_utf8_lossy(bytes).to_string());
    let Some(markup) = record.reply_markup.as_ref() else {
        return Err(RpcFailure::new(400, "BUTTON_NOT_FOUND"));
    };
    if !markup_has_callback(markup, data_text.as_deref()) {
        return Err(RpcFailure::new(400, "BUTTON_NOT_FOUND"));
    }
    let Some(clicker) = ctx_user(ctx).await? else {
        return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
    };
    let mut query_id = rand::random::<i64>();
    if query_id == 0 {
        query_id = 1;
    }
    let receiver = crate::bot_api::register_callback(query_id);
    crate::bot_api::enqueue_callback_query(
        ctx.db,
        &bot,
        &clicker,
        &record,
        data_text.as_deref(),
        query_id,
    )
    .await
    .map_err(RpcFailure::internal)?;
    let answer = match tokio::time::timeout(Duration::from_secs(15), receiver).await {
        Ok(Ok(answer)) => answer,
        _ => crate::bot_api::CallbackAnswer::default(),
    };
    Ok(types::bot_callback_answer(
        answer.show_alert,
        answer.text.as_deref(),
        answer.url.as_deref(),
        answer.cache_time,
    ))
}

fn markup_has_callback(markup: &serde_json::Value, data: Option<&str>) -> bool {
    let Some(data) = data else {
        return false;
    };
    let Some(rows) = markup
        .get("inline_keyboard")
        .and_then(|value| value.as_array())
    else {
        return false;
    };
    rows.iter()
        .filter_map(|row| row.as_array())
        .flatten()
        .any(|button| {
            button
                .get("callback_data")
                .and_then(|value| value.as_str())
                .is_some_and(|callback| callback == data)
        })
}

async fn import_bot_authorization(
    ctx: &mut RpcContext<'_>,
    reader: &mut Reader<'_>,
) -> Result<Vec<u8>, RpcFailure> {
    let _flags = reader.u32()?;
    let _api_id = reader.i32()?;
    let _api_hash = reader.string()?;
    let token = reader.string()?;
    let Some((user, _bot)) = repo::find_bot_by_token(ctx.db, &token)
        .await
        .map_err(RpcFailure::internal)?
    else {
        return Err(RpcFailure::new(400, "BOT_TOKEN_INVALID"));
    };
    authorize(ctx, &user).await?;
    let _ = repo::touch_bot_used(ctx.db, user.id).await;
    Ok(types::auth_authorization(&user_bytes(user)))
}

async fn sign_in(ctx: &mut RpcContext<'_>, reader: &mut Reader<'_>) -> Result<Vec<u8>, RpcFailure> {
    let flags = reader.u32()?;
    let raw_phone = reader.string()?;
    let Some(phone) = normalize_phone(&raw_phone) else {
        return Err(RpcFailure::new(400, "PHONE_NUMBER_INVALID"));
    };
    let phone_code_hash = reader.string()?;
    let code = if flags & 1 != 0 {
        reader.string()?
    } else {
        String::new()
    };
    verify_code(ctx, &phone, &phone_code_hash, Some(&code)).await?;
    let Some(user) = repo::find_user_by_phone(ctx.db, &phone)
        .await
        .map_err(RpcFailure::internal)?
    else {
        // Telegram Desktop expects auth.authorizationSignUpRequired (not an
        // error) so it can move on to the sign-up page.
        return Ok(types::auth_authorization_sign_up_required());
    };
    if repo::load_password(ctx.db, user.id)
        .await
        .map_err(RpcFailure::internal)?
        .is_some()
    {
        // 验证码正确但账号启用了两步验证：先挂起登录，等待 auth.checkPassword。
        srp::set_pending(ctx.auth_key_id, user.id);
        return Err(RpcFailure::new(401, "SESSION_PASSWORD_NEEDED"));
    }
    authorize(ctx, &user).await?;
    ensure_system_welcome(ctx, user.id).await;
    Ok(types::auth_authorization(&user_bytes(user)))
}

enum PasswordInput {
    Empty,
    Srp {
        srp_id: i64,
        a: Vec<u8>,
        m1: Vec<u8>,
    },
}

struct NewPasswordAlgo {
    salt1: Vec<u8>,
    salt2: Vec<u8>,
    g: i32,
    p: Vec<u8>,
}

struct NewPasswordSettings {
    algo: Option<NewPasswordAlgo>,
    password_hash: Vec<u8>,
    hint: String,
}

fn read_password_input(reader: &mut Reader<'_>) -> Result<PasswordInput, RpcFailure> {
    match reader.constructor()? {
        ctor::INPUT_CHECK_PASSWORD_EMPTY => Ok(PasswordInput::Empty),
        ctor::INPUT_CHECK_PASSWORD_SRP => {
            let srp_id = reader.i64()?;
            let a = reader.bytes()?;
            let m1 = reader.bytes()?;
            Ok(PasswordInput::Srp { srp_id, a, m1 })
        }
        _ => Err(RpcFailure::new(400, "PASSWORD_HASH_INVALID")),
    }
}

fn read_password_algo(reader: &mut Reader<'_>) -> Result<Option<NewPasswordAlgo>, RpcFailure> {
    match reader.constructor()? {
        ctor::PASSWORD_KDF_ALGO_SHA256_SHA256_PBKDF2_HMAC_SHA512_ITER_100000_SHA256_MOD_POW => {
            Ok(Some(NewPasswordAlgo {
                salt1: reader.bytes()?,
                salt2: reader.bytes()?,
                g: reader.i32()?,
                p: reader.bytes()?,
            }))
        }
        ctor::PASSWORD_KDF_ALGO_UNKNOWN => Ok(None),
        _ => Err(RpcFailure::new(400, "NEW_SETTINGS_INVALID")),
    }
}

fn read_password_input_settings(
    reader: &mut Reader<'_>,
) -> Result<NewPasswordSettings, RpcFailure> {
    let flags = reader.u32()?;
    let mut algo = None;
    let mut password_hash = Vec::new();
    let mut hint = String::new();
    if flags & 1 != 0 {
        algo = read_password_algo(reader)?;
        password_hash = reader.bytes()?;
        hint = reader.string()?;
    }
    if flags & 2 != 0 {
        // 恢复邮箱：本服务器不支持邮件，忽略但保持流同步。
        let _email = reader.string()?;
    }
    if flags & 4 != 0 {
        // SecureSecretSettings: secure_algo + secure_secret + secure_secret_id.
        let _ = reader.constructor()?;
        let _ = reader.bytes()?;
        let _ = reader.i64()?;
    }
    Ok(NewPasswordSettings {
        algo,
        password_hash,
        hint,
    })
}

fn password_failure(error: srp::CheckError) -> RpcFailure {
    match error {
        srp::CheckError::SrpIdInvalid => RpcFailure::new(400, "SRP_ID_INVALID"),
        srp::CheckError::PasswordInvalid => RpcFailure::new(400, "PASSWORD_HASH_INVALID"),
    }
}

fn verify_password(user_id: i64, input: &PasswordInput) -> Result<(), RpcFailure> {
    match input {
        PasswordInput::Empty => Err(RpcFailure::new(400, "PASSWORD_HASH_INVALID")),
        PasswordInput::Srp { srp_id, a, m1 } => {
            srp::check(*srp_id, user_id, a, m1).map_err(password_failure)
        }
    }
}

async fn account_get_password(ctx: &RpcContext<'_>) -> Result<Vec<u8>, RpcFailure> {
    let secure_random: [u8; 32] = rand::random();
    let new_algo = types::password_kdf_algo_sha256(
        srp::ALGO_SALT1,
        srp::ALGO_SALT2,
        3,
        &srp::prime_bytes(),
    );
    let new_secure_algo = types::secure_password_kdf_algo_pbkdf2(srp::SECURE_SALT);

    let target = ctx.user_id.or_else(|| srp::pending_user(ctx.auth_key_id));
    let Some(user_id) = target else {
        return Ok(types::account_password(
            None,
            &[],
            0,
            "",
            &new_algo,
            &new_secure_algo,
            &secure_random,
        ));
    };
    let Some(record) = repo::load_password(ctx.db, user_id)
        .await
        .map_err(RpcFailure::internal)?
    else {
        return Ok(types::account_password(
            None,
            &[],
            0,
            "",
            &new_algo,
            &new_secure_algo,
            &secure_random,
        ));
    };
    let (srp_id, srp_b) = srp::start(
        user_id,
        &record.salt1,
        &record.salt2,
        record.g,
        &record.verifier,
    );
    let current_algo =
        types::password_kdf_algo_sha256(&record.salt1, &record.salt2, record.g, &srp::prime_bytes());
    Ok(types::account_password(
        Some(&current_algo),
        &srp_b,
        srp_id,
        &record.hint,
        &new_algo,
        &new_secure_algo,
        &secure_random,
    ))
}

async fn account_update_password_settings(
    ctx: &mut RpcContext<'_>,
    reader: &mut Reader<'_>,
) -> Result<Vec<u8>, RpcFailure> {
    let Some(user_id) = ctx.user_id else {
        return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
    };
    let input = read_password_input(reader)?;
    let settings = read_password_input_settings(reader)?;
    let existing = repo::load_password(ctx.db, user_id)
        .await
        .map_err(RpcFailure::internal)?;
    match (&existing, &input) {
        (Some(_), PasswordInput::Empty) => {
            return Err(RpcFailure::new(400, "PASSWORD_HASH_INVALID"));
        }
        (Some(_), PasswordInput::Srp { .. }) => verify_password(user_id, &input)?,
        (None, PasswordInput::Srp { .. }) => {
            return Err(RpcFailure::new(400, "PASSWORD_HASH_INVALID"));
        }
        (None, PasswordInput::Empty) => {}
    }

    let clearing = settings.algo.is_none() || settings.password_hash.is_empty();
    if clearing {
        if existing.is_none() {
            return Err(RpcFailure::new(400, "NEW_SETTINGS_EMPTY"));
        }
        repo::clear_password(ctx.db, user_id)
            .await
            .map_err(RpcFailure::internal)?;
        srp::invalidate_user(user_id);
        return Ok(types::bool_true());
    }
    let Some(algo) = settings.algo else {
        return Err(RpcFailure::new(400, "NEW_SETTINGS_INVALID"));
    };
    if !srp::supported_algo(&algo.salt1, &algo.salt2, algo.g, &algo.p) {
        return Err(RpcFailure::new(400, "NEW_SALT_INVALID"));
    }
    if !srp::valid_verifier(&settings.password_hash) {
        return Err(RpcFailure::new(400, "PASSWORD_HASH_INVALID"));
    }
    let srp_id = srp::new_srp_id();
    repo::set_password(
        ctx.db,
        user_id,
        srp_id,
        &algo.salt1,
        &algo.salt2,
        &settings.password_hash,
        &settings.hint,
        algo.g,
    )
    .await
    .map_err(RpcFailure::internal)?;
    srp::invalidate_user(user_id);
    Ok(types::bool_true())
}

async fn account_get_password_settings(
    ctx: &mut RpcContext<'_>,
    reader: &mut Reader<'_>,
) -> Result<Vec<u8>, RpcFailure> {
    let Some(user_id) = ctx.user_id else {
        return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
    };
    let input = read_password_input(reader)?;
    if repo::load_password(ctx.db, user_id)
        .await
        .map_err(RpcFailure::internal)?
        .is_some()
    {
        verify_password(user_id, &input)?;
    }
    Ok(types::account_password_settings())
}

async fn auth_check_password(
    ctx: &mut RpcContext<'_>,
    reader: &mut Reader<'_>,
) -> Result<Vec<u8>, RpcFailure> {
    let input = read_password_input(reader)?;
    let Some(user_id) = srp::pending_user(ctx.auth_key_id) else {
        return Err(RpcFailure::new(401, "SESSION_PASSWORD_NEEDED"));
    };
    let PasswordInput::Srp { srp_id, a, m1 } = input else {
        return Err(RpcFailure::new(400, "PASSWORD_HASH_INVALID"));
    };
    srp::check(srp_id, user_id, &a, &m1).map_err(password_failure)?;
    srp::clear_pending(ctx.auth_key_id);
    let Some(user) = repo::find_user_by_id(ctx.db, user_id)
        .await
        .map_err(RpcFailure::internal)?
    else {
        return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
    };
    authorize(ctx, &user).await?;
    ensure_system_welcome(ctx, user.id).await;
    Ok(types::auth_authorization(&user_bytes(user)))
}

async fn sign_up(ctx: &mut RpcContext<'_>, reader: &mut Reader<'_>) -> Result<Vec<u8>, RpcFailure> {
    let _flags = reader.u32()?;
    let raw_phone = reader.string()?;
    let Some(phone) = normalize_phone(&raw_phone) else {
        return Err(RpcFailure::new(400, "PHONE_NUMBER_INVALID"));
    };
    let phone_code_hash = reader.string()?;
    let first_name = reader.string()?;
    let last_name = reader.string()?;
    verify_code(ctx, &phone, &phone_code_hash, None).await?;

    let user = match repo::find_user_by_phone(ctx.db, &phone)
        .await
        .map_err(RpcFailure::internal)?
    {
        Some(user) => user,
        None => repo::create_user(
            ctx.db,
            &phone,
            if first_name.is_empty() {
                "User"
            } else {
                &first_name
            },
            &last_name,
        )
        .await
        .map_err(RpcFailure::internal)?,
    };
    authorize(ctx, &user).await?;
    ensure_system_welcome(ctx, user.id).await;
    Ok(types::auth_authorization(&user_bytes(user)))
}

async fn verify_code(
    ctx: &RpcContext<'_>,
    phone: &str,
    phone_code_hash: &str,
    code: Option<&str>,
) -> Result<(), RpcFailure> {
    let Some(stored) = ctx
        .cache
        .get(&auth_code_key(phone))
        .await
        .map_err(RpcFailure::internal)?
    else {
        return Err(RpcFailure::new(401, "PHONE_CODE_EXPIRED"));
    };
    let (stored_hash, stored_code) = stored
        .split_once('|')
        .ok_or_else(|| RpcFailure::new(401, "PHONE_CODE_EXPIRED"))?;
    if stored_hash != phone_code_hash {
        return Err(RpcFailure::new(401, "PHONE_CODE_INVALID"));
    }
    // signUp verifies the hash only; signIn must also present the fixed code.
    if let Some(code) = code {
        if code.is_empty() || code != stored_code {
            return Err(RpcFailure::new(401, "PHONE_CODE_INVALID"));
        }
    }
    Ok(())
}

const SYSTEM_WELCOME_TEXT: &str = "欢迎使用自建 Telegram 服务器 👋\n\n我是系统助手，可以直接在这里测试收发消息、编辑、删除、转发和图片/视频。";

/// Sends a private message from the built-in system assistant, logging the
/// update and pushing it to the recipient's online sessions.
pub async fn send_system_message(
    db: &Db,
    updates: &UpdateHub,
    to_user_id: i64,
    text: &str,
) -> Result<bool, RpcFailure> {
    Ok(
        send_system_message_record(db, updates, to_user_id, text)
            .await?
            .is_some(),
    )
}

async fn send_system_message_record(
    db: &Db,
    updates: &UpdateHub,
    to_user_id: i64,
    text: &str,
) -> Result<Option<repo::MessageRecord>, RpcFailure> {
    let system = repo::ensure_system_user(db)
        .await
        .map_err(RpcFailure::internal)?;
    if to_user_id == system.id {
        return Ok(None);
    }
    let random_id = rand::random::<i64>();
    let extras = repo::MessageExtras::default();
    let (record, _sender_pts, recipient_pts) =
        repo::send_private_message(db, system.id, to_user_id, text, random_id, None, &extras)
            .await
            .map_err(RpcFailure::internal)?;
    let message = private_message_record(&record, false, system.id, None, 0, None);
    let update = types::update_new_message(&message, recipient_pts);
    repo::log_user_update(db, to_user_id, recipient_pts, &update)
        .await
        .map_err(RpcFailure::internal)?;
    if let Ok(Some(recipient)) = repo::find_user_by_id(db, to_user_id).await {
        if recipient.is_bot {
            if let Err(error) =
                crate::bot_api::enqueue_incoming_message(db, recipient.id, &record, &system).await
            {
                tracing::warn!(%error, "enqueue bot update failed");
            }
        }
    }
    // Keep the welcome message out of the unread badge so it does not distort
    // unread counters in tests and fresh sign-ins.
    let _ = repo::read_history(db, to_user_id, record.chat_id, record.id).await;
    let push = types::updates(
        &[update],
        &[other_user_bytes(&system)],
        record.sent_at as i32,
        0,
    );
    updates.publish(to_user_id, push);
    Ok(Some(record))
}

/// Sends a private message on behalf of a bot (HTTP Bot API `sendMessage`):
/// stores it, logs both PTS updates and pushes it to online sessions.
pub async fn bot_send_private_message(
    db: &Db,
    updates: &UpdateHub,
    sender: &UserRecord,
    recipient_id: i64,
    text: &str,
    extras: &repo::MessageExtras,
) -> Result<repo::MessageRecord, RpcFailure> {
    if recipient_id == sender.id {
        return Err(RpcFailure::new(400, "PEER_ID_INVALID"));
    }
    let Some(recipient) = repo::find_user_by_id(db, recipient_id)
        .await
        .map_err(RpcFailure::internal)?
    else {
        return Err(RpcFailure::new(400, "PEER_ID_INVALID"));
    };
    if repo::is_blocked_between(db, sender.id, recipient_id)
        .await
        .map_err(RpcFailure::internal)?
    {
        return Err(RpcFailure::new(403, "USER_IS_BLOCKED"));
    }
    let random_id = rand::random::<i64>();
    let (record, sender_pts, recipient_pts) = repo::send_private_message(
        db,
        sender.id,
        recipient_id,
        text,
        random_id,
        None,
        extras,
    )
    .await
    .map_err(RpcFailure::internal)?;
    let sent_at = record.sent_at as i32;
    let sender_message = private_message_record(&record, true, recipient_id, None, 0, None);
    let recipient_message = private_message_record(&record, false, sender.id, None, 0, None);
    repo::log_user_update(
        db,
        sender.id,
        sender_pts,
        &types::update_new_message(&sender_message, sender_pts),
    )
    .await
    .map_err(RpcFailure::internal)?;
    repo::log_user_update(
        db,
        recipient_id,
        recipient_pts,
        &types::update_new_message(&recipient_message, recipient_pts),
    )
    .await
    .map_err(RpcFailure::internal)?;
    let push = types::updates(
        &[types::update_new_message(&recipient_message, recipient_pts)],
        &[other_user_bytes(sender)],
        sent_at,
        0,
    );
    updates.publish(recipient_id, push);
    let self_push = types::updates(
        &[types::update_new_message(&sender_message, sender_pts)],
        &[other_user_bytes(&recipient)],
        sent_at,
        0,
    );
    updates.publish(sender.id, self_push);
    Ok(record)
}

fn admin_context<'a>(
    state: &'a crate::mtproto_listener::AppState,
    user_id: Option<i64>,
) -> RpcContext<'a> {
    RpcContext {
        db: &state.db,
        cache: &state.cache,
        config: &state.config,
        langpacks: &state.langpacks,
        updates: &state.updates,
        auth_key_id: 0,
        session_id: 0,
        user_id,
        layer: 232,
        peer: String::new(),
        client: ClientInfo::default(),
    }
}

/// Admin: sends a text message from the system assistant to a user's private
/// chat, returning `(chat_id, message_id)`.
pub async fn admin_send_message(
    state: &crate::mtproto_listener::AppState,
    to_user_id: i64,
    text: &str,
) -> Result<(i64, i64), RpcFailure> {
    let text = text.trim();
    if text.is_empty() {
        return Err(RpcFailure::new(400, "MESSAGE_EMPTY"));
    }
    if repo::find_user_by_id(&state.db, to_user_id)
        .await
        .map_err(RpcFailure::internal)?
        .is_none()
    {
        return Err(RpcFailure::new(404, "USER_NOT_FOUND"));
    }
    let Some(record) = send_system_message_record(&state.db, &state.updates, to_user_id, text)
        .await?
    else {
        return Err(RpcFailure::new(400, "USER_INVALID"));
    };
    Ok((record.chat_id, record.id))
}

/// Admin: sends the same text from the system assistant to a batch of users.
/// Per-recipient failures are collected instead of aborting the whole batch.
pub async fn admin_broadcast_message(
    state: &crate::mtproto_listener::AppState,
    user_ids: &[i64],
    text: &str,
) -> Result<serde_json::Value, RpcFailure> {
    let text = text.trim();
    if text.is_empty() {
        return Err(RpcFailure::new(400, "MESSAGE_EMPTY"));
    }
    if user_ids.is_empty() {
        return Err(RpcFailure::new(400, "MESSAGE_TARGETS_EMPTY"));
    }
    if user_ids.len() > 200 {
        return Err(RpcFailure::new(400, "MESSAGE_TARGETS_TOO_MANY"));
    }
    let mut sent = 0i64;
    let mut skipped = 0i64;
    let mut failed: Vec<serde_json::Value> = Vec::new();
    for user_id in user_ids {
        let exists = repo::find_user_by_id(&state.db, *user_id)
            .await
            .map_err(RpcFailure::internal)?
            .is_some();
        if !exists {
            skipped += 1;
            failed.push(serde_json::json!({ "user_id": *user_id, "error": "USER_INVALID" }));
            continue;
        }
        match send_system_message_record(&state.db, &state.updates, *user_id, text).await {
            Ok(Some(_)) => sent += 1,
            Ok(None) => {
                skipped += 1;
                failed.push(serde_json::json!({ "user_id": *user_id, "error": "USER_INVALID" }));
            }
            Err(error) => {
                failed.push(serde_json::json!({ "user_id": *user_id, "error": error.message }));
            }
        }
    }
    Ok(serde_json::json!({
        "total": user_ids.len(),
        "sent": sent,
        "skipped": skipped,
        "failed": failed,
    }))
}

/// Admin: deletes one message in any chat, keeping the same PTS/update_log
/// bookkeeping as a normal client deletion.
pub async fn admin_delete_message(
    state: &crate::mtproto_listener::AppState,
    chat_id: i64,
    message_id: i64,
) -> Result<i32, RpcFailure> {
    admin_delete_messages(state, chat_id, &[message_id]).await
}

/// Admin: deletes a batch of messages in one chat. Messages that no longer
/// exist are skipped; the number actually removed is returned.
pub async fn admin_delete_messages(
    state: &crate::mtproto_listener::AppState,
    chat_id: i64,
    message_ids: &[i64],
) -> Result<i32, RpcFailure> {
    if message_ids.is_empty() {
        return Err(RpcFailure::new(400, "MESSAGE_IDS_EMPTY"));
    }
    if message_ids.len() > 100 {
        return Err(RpcFailure::new(400, "MESSAGE_IDS_TOO_MANY"));
    }
    let ctx = admin_context(state, None);
    if repo::find_chat(&state.db, chat_id)
        .await
        .map_err(RpcFailure::internal)?
        .is_none()
    {
        return Err(RpcFailure::new(404, "CHAT_ID_INVALID"));
    }
    let (_, count) = delete_messages_in_chat(&ctx, &chat_id, message_ids).await?;
    if count == 0 {
        return Err(RpcFailure::new(404, "MESSAGE_NOT_FOUND"));
    }
    Ok(count)
}

/// Admin: removes a member from a basic group. The group owner is used as the
/// actor so the generated service message and participant update look normal.
pub async fn admin_kick_user(
    state: &crate::mtproto_listener::AppState,
    chat_id: i64,
    target_id: i64,
) -> Result<(), RpcFailure> {
    let Some(chat) = repo::find_channel(&state.db, chat_id)
        .await
        .map_err(RpcFailure::internal)?
    else {
        return Err(RpcFailure::new(404, "CHAT_ID_INVALID"));
    };
    if chat.kind != "basic_group" {
        return Err(RpcFailure::new(400, "CHAT_KIND_UNSUPPORTED"));
    }
    if target_id == chat.owner_user_id {
        return Err(RpcFailure::new(400, "CHAT_ADMIN_REQUIRED"));
    }
    if repo::find_user_by_id(&state.db, chat.owner_user_id)
        .await
        .map_err(RpcFailure::internal)?
        .is_none()
    {
        return Err(RpcFailure::new(400, "CHAT_OWNER_MISSING"));
    }
    if repo::channel_membership(&state.db, chat.id, target_id)
        .await
        .map_err(RpcFailure::internal)?
        .is_none()
    {
        return Err(RpcFailure::new(404, "USER_NOT_PARTICIPANT"));
    }
    let ctx = admin_context(state, Some(chat.owner_user_id));
    remove_basic_group_member(&ctx, chat.id, chat.owner_user_id, target_id).await?;
    Ok(())
}

/// Admin: updates a Telegram user's display name and/or username.
/// Passing an empty username clears it; `None` leaves the field unchanged.
pub async fn admin_update_user(
    state: &crate::mtproto_listener::AppState,
    user_id: i64,
    first_name: Option<&str>,
    last_name: Option<&str>,
    username: Option<&str>,
) -> Result<(), RpcFailure> {
    let Some(user) = repo::find_user_by_id(&state.db, user_id)
        .await
        .map_err(RpcFailure::internal)?
    else {
        return Err(RpcFailure::new(404, "USER_NOT_FOUND"));
    };
    if let Some(name) = first_name {
        if name.trim().is_empty() || name.chars().count() > 64 {
            return Err(RpcFailure::new(400, "FIRSTNAME_INVALID"));
        }
    }
    if let Some(name) = last_name {
        if name.chars().count() > 64 {
            return Err(RpcFailure::new(400, "LASTNAME_INVALID"));
        }
    }
    repo::update_user_profile(&state.db, user_id, first_name, last_name)
        .await
        .map_err(RpcFailure::internal)?;
    if let Some(raw) = username {
        let raw = raw.trim().trim_start_matches('@');
        if raw.is_empty() {
            repo::set_user_username(&state.db, user_id, "")
                .await
                .map_err(RpcFailure::internal)?;
        } else {
            let normalized = validate_username(raw)?;
            if normalized != user.username
                && repo::username_taken(&state.db, &normalized)
                    .await
                    .map_err(RpcFailure::internal)?
            {
                return Err(RpcFailure::new(400, "USERNAME_OCCUPIED"));
            }
            repo::set_user_username(&state.db, user_id, &normalized)
                .await
                .map_err(RpcFailure::internal)?;
        }
    }
    Ok(())
}

/// Admin: bans or unbans a user. Banning revokes every session so the account
/// is signed out immediately; sign-in stays blocked until the ban is lifted.
pub async fn admin_ban_user(
    state: &crate::mtproto_listener::AppState,
    user_id: i64,
    banned: bool,
) -> Result<(), RpcFailure> {
    let Some(user) = repo::find_user_by_id(&state.db, user_id)
        .await
        .map_err(RpcFailure::internal)?
    else {
        return Err(RpcFailure::new(404, "USER_NOT_FOUND"));
    };
    if user.phone == repo::SYSTEM_USER_PHONE {
        return Err(RpcFailure::new(400, "USER_NOT_MUTABLE"));
    }
    repo::set_user_banned(&state.db, user_id, banned)
        .await
        .map_err(RpcFailure::internal)?;
    if banned {
        repo::delete_other_user_sessions(&state.db, user_id, -1)
            .await
            .map_err(RpcFailure::internal)?;
    }
    Ok(())
}

/// Admin: revokes one device session. Returns `false` when the auth key did not
/// belong to the user.
pub async fn admin_kick_session(
    state: &crate::mtproto_listener::AppState,
    user_id: i64,
    auth_key_id: i64,
) -> Result<bool, RpcFailure> {
    repo::delete_user_session(&state.db, user_id, auth_key_id)
        .await
        .map_err(RpcFailure::internal)
}

/// Admin: revokes every device session of a user, returning the count.
pub async fn admin_kick_all_sessions(
    state: &crate::mtproto_listener::AppState,
    user_id: i64,
) -> Result<u64, RpcFailure> {
    repo::delete_other_user_sessions(&state.db, user_id, -1)
        .await
        .map_err(RpcFailure::internal)
}

/// Admin: adds a user to a basic group / supergroup / channel. The owner acts
/// as the actor so service messages, PTS and updates look like a normal invite.
pub async fn admin_add_member(
    state: &crate::mtproto_listener::AppState,
    chat_id: i64,
    target_id: i64,
) -> Result<(), RpcFailure> {
    let Some(chat) = repo::find_channel(&state.db, chat_id)
        .await
        .map_err(RpcFailure::internal)?
    else {
        return Err(RpcFailure::new(404, "CHAT_ID_INVALID"));
    };
    if repo::find_user_by_id(&state.db, target_id)
        .await
        .map_err(RpcFailure::internal)?
        .is_none()
    {
        return Err(RpcFailure::new(404, "USER_NOT_FOUND"));
    }
    if repo::channel_membership(&state.db, chat.id, target_id)
        .await
        .map_err(RpcFailure::internal)?
        .is_some()
    {
        return Err(RpcFailure::new(400, "USER_ALREADY_PARTICIPANT"));
    }
    let ctx = admin_context(state, Some(chat.owner_user_id));
    if chat.kind == "basic_group" {
        add_basic_group_member(&ctx, &chat, chat.owner_user_id, target_id).await?;
        return Ok(());
    }
    repo::add_channel_member(&state.db, chat.id, target_id)
        .await
        .map_err(RpcFailure::internal)?;
    repo::ensure_channel_dialog(&state.db, target_id, chat.id)
        .await
        .map_err(RpcFailure::internal)?;
    publish_channel_update(&ctx, &chat, chat.owner_user_id).await?;
    Ok(())
}

/// Admin: removes a user from a basic group / supergroup / channel.
pub async fn admin_remove_member(
    state: &crate::mtproto_listener::AppState,
    chat_id: i64,
    target_id: i64,
) -> Result<(), RpcFailure> {
    let Some(chat) = repo::find_channel(&state.db, chat_id)
        .await
        .map_err(RpcFailure::internal)?
    else {
        return Err(RpcFailure::new(404, "CHAT_ID_INVALID"));
    };
    if target_id == chat.owner_user_id {
        return Err(RpcFailure::new(400, "USER_NOT_MUTABLE"));
    }
    if repo::channel_membership(&state.db, chat.id, target_id)
        .await
        .map_err(RpcFailure::internal)?
        .is_none()
    {
        return Err(RpcFailure::new(404, "USER_NOT_PARTICIPANT"));
    }
    let ctx = admin_context(state, Some(chat.owner_user_id));
    if chat.kind == "basic_group" {
        remove_basic_group_member(&ctx, chat.id, chat.owner_user_id, target_id).await?;
        return Ok(());
    }
    repo::remove_channel_member(&state.db, chat.id, target_id)
        .await
        .map_err(RpcFailure::internal)?;
    publish_channel_update(&ctx, &chat, chat.owner_user_id).await?;
    Ok(())
}

/// Admin: promotes a supergroup/channel member (rights_flags > 0) or demotes
/// them back to a normal member (rights_flags == 0).
pub async fn admin_promote_member(
    state: &crate::mtproto_listener::AppState,
    chat_id: i64,
    target_id: i64,
    rights_flags: u32,
    rank: &str,
) -> Result<(), RpcFailure> {
    let Some(chat) = repo::find_channel(&state.db, chat_id)
        .await
        .map_err(RpcFailure::internal)?
    else {
        return Err(RpcFailure::new(404, "CHAT_ID_INVALID"));
    };
    if chat.kind == "basic_group" {
        return Err(RpcFailure::new(400, "CHAT_KIND_UNSUPPORTED"));
    }
    if target_id == chat.owner_user_id {
        return Err(RpcFailure::new(400, "USER_NOT_MUTABLE"));
    }
    if repo::channel_membership(&state.db, chat.id, target_id)
        .await
        .map_err(RpcFailure::internal)?
        .is_none()
    {
        return Err(RpcFailure::new(404, "USER_NOT_PARTICIPANT"));
    }
    let ctx = admin_context(state, Some(chat.owner_user_id));
    if rights_flags == 0 {
        repo::demote_chat_member(&state.db, chat.id, target_id)
            .await
            .map_err(RpcFailure::internal)?;
    } else {
        let rights = serde_json::json!({ "flags": rights_flags });
        let rank = rank.chars().take(16).collect::<String>();
        repo::set_chat_member_admin(
            &state.db,
            chat.id,
            target_id,
            &rights,
            &rank,
            chat.owner_user_id,
        )
        .await
        .map_err(RpcFailure::internal)?;
    }
    publish_channel_update(&ctx, &chat, chat.owner_user_id).await?;
    Ok(())
}

/// Admin: bans or unbans a user in a supergroup/channel. Banning uses the
/// `view messages` flag by default so the target also loses membership, mirroring
/// `channels.editBanned`; the channel owner is used as the acting user.
pub async fn admin_ban_chat_user(
    state: &crate::mtproto_listener::AppState,
    chat_id: i64,
    target_id: i64,
    banned: bool,
    rights_flags: u32,
    until_date: i64,
) -> Result<(), RpcFailure> {
    let Some(chat) = repo::find_channel(&state.db, chat_id)
        .await
        .map_err(RpcFailure::internal)?
    else {
        return Err(RpcFailure::new(404, "CHAT_ID_INVALID"));
    };
    if chat.kind == "basic_group" {
        return Err(RpcFailure::new(400, "CHAT_KIND_UNSUPPORTED"));
    }
    if target_id == chat.owner_user_id {
        return Err(RpcFailure::new(400, "USER_NOT_MUTABLE"));
    }
    if repo::find_user_by_id(&state.db, target_id)
        .await
        .map_err(RpcFailure::internal)?
        .is_none()
    {
        return Err(RpcFailure::new(404, "USER_NOT_FOUND"));
    }
    if banned
        && repo::channel_membership(&state.db, chat.id, target_id)
            .await
            .map_err(RpcFailure::internal)?
            .is_none()
    {
        return Err(RpcFailure::new(404, "USER_NOT_PARTICIPANT"));
    }
    let ctx = admin_context(state, Some(chat.owner_user_id));
    if banned {
        // A zero rights mask means "ban and remove" in the admin panel.
        let flags = if rights_flags == 0 { 1 } else { rights_flags };
        let rights = serde_json::json!({ "flags": flags });
        repo::set_chat_ban(
            &state.db,
            chat.id,
            target_id,
            &rights,
            until_date.max(0),
            chat.owner_user_id,
        )
        .await
        .map_err(RpcFailure::internal)?;
        if flags & 1 != 0 {
            repo::remove_channel_member(&state.db, chat.id, target_id)
                .await
                .map_err(RpcFailure::internal)?;
        }
    } else {
        repo::delete_chat_ban(&state.db, chat.id, target_id)
            .await
            .map_err(RpcFailure::internal)?;
    }
    publish_channel_update(&ctx, &chat, chat.owner_user_id).await?;
    Ok(())
}

/// Admin: creates an invite link for a supergroup/channel, returning
/// `(link, expires_at, usage_limit)`. `request_needed` links create pending
/// join requests that the admin panel can approve or reject.
pub async fn admin_create_invite(
    state: &crate::mtproto_listener::AppState,
    chat_id: i64,
    expires_at: i64,
    usage_limit: i32,
    request_needed: bool,
) -> Result<(String, i64, i32), RpcFailure> {
    let Some(chat) = repo::find_channel(&state.db, chat_id)
        .await
        .map_err(RpcFailure::internal)?
    else {
        return Err(RpcFailure::new(404, "CHAT_ID_INVALID"));
    };
    if chat.kind == "private" {
        return Err(RpcFailure::new(400, "CHAT_KIND_UNSUPPORTED"));
    }
    let token = random_hex(12);
    let link = format!("https://t.me/+{token}");
    let invite = repo::create_chat_invite(
        &state.db,
        &token,
        chat.id,
        chat.owner_user_id,
        &link,
        expires_at.max(0),
        usage_limit.max(0),
        request_needed,
    )
    .await
    .map_err(RpcFailure::internal)?;
    Ok((invite.link, invite.expires_at, invite.usage_limit))
}

/// Admin: revokes an invite link owned by the given chat.
pub async fn admin_revoke_invite(
    state: &crate::mtproto_listener::AppState,
    chat_id: i64,
    token: &str,
) -> Result<(), RpcFailure> {
    let Some(chat) = repo::find_channel(&state.db, chat_id)
        .await
        .map_err(RpcFailure::internal)?
    else {
        return Err(RpcFailure::new(404, "CHAT_ID_INVALID"));
    };
    if chat.kind == "private" {
        return Err(RpcFailure::new(400, "CHAT_KIND_UNSUPPORTED"));
    }
    let Some(invite) = repo::find_chat_invite(&state.db, token)
        .await
        .map_err(RpcFailure::internal)?
    else {
        return Err(RpcFailure::new(404, "INVITE_NOT_FOUND"));
    };
    if invite.chat_id != chat.id {
        return Err(RpcFailure::new(400, "INVITE_CHAT_MISMATCH"));
    }
    repo::revoke_chat_invite(&state.db, token)
        .await
        .map_err(RpcFailure::internal)?;
    Ok(())
}

/// Admin: updates a non-private chat's title and/or photo. Reuses the same
/// service-message / `updateChannel` flow as `messages.editChatTitle`,
/// `messages.editChatPhoto` and `channels.editPhoto`.
pub async fn admin_update_chat(
    state: &crate::mtproto_listener::AppState,
    chat_id: i64,
    title: Option<&str>,
    photo_media_id: Option<i64>,
) -> Result<(), RpcFailure> {
    let Some(chat) = repo::find_channel(&state.db, chat_id)
        .await
        .map_err(RpcFailure::internal)?
    else {
        return Err(RpcFailure::new(404, "CHAT_ID_INVALID"));
    };
    if chat.kind == "private" {
        return Err(RpcFailure::new(400, "CHAT_KIND_UNSUPPORTED"));
    }
    let ctx = admin_context(state, Some(chat.owner_user_id));
    if let Some(title) = title {
        let title = title.trim();
        if title.is_empty() || title.chars().count() > 255 {
            return Err(RpcFailure::new(400, "CHAT_TITLE_INVALID"));
        }
        repo::set_chat_title(&state.db, chat.id, title)
            .await
            .map_err(RpcFailure::internal)?;
        let Some(updated) = repo::find_channel(&state.db, chat.id)
            .await
            .map_err(RpcFailure::internal)?
        else {
            return Err(RpcFailure::new(404, "CHAT_ID_INVALID"));
        };
        if updated.kind == "basic_group" {
            let Some(sender) = ctx_user(&ctx).await? else {
                return Err(RpcFailure::new(400, "CHAT_OWNER_MISSING"));
            };
            let record = repo::send_service_message(
                &state.db,
                chat.id,
                chat.owner_user_id,
                "edit_title",
                0,
                title,
            )
            .await
            .map_err(RpcFailure::internal)?;
            deliver_basic_group_message(&ctx, &updated, &record, &sender, None, None).await?;
        } else {
            publish_channel_update(&ctx, &updated, chat.owner_user_id).await?;
        }
    }
    if let Some(media_id) = photo_media_id {
        let photo = if media_id <= 0 {
            InputChatPhotoRef::Empty
        } else {
            InputChatPhotoRef::Photo { id: media_id }
        };
        apply_chat_photo(&ctx, chat.id, photo).await?;
    }
    Ok(())
}

/// Admin: edits a text message in any chat. Reuses `messages.editMessage`
/// delivery so every member receives the same `updateEditMessage` push.
pub async fn admin_edit_message(
    state: &crate::mtproto_listener::AppState,
    chat_id: i64,
    message_id: i64,
    text: &str,
) -> Result<(), RpcFailure> {
    let text = text.trim();
    if text.is_empty() {
        return Err(RpcFailure::new(400, "MESSAGE_EMPTY"));
    }
    if text.chars().count() > 4096 {
        return Err(RpcFailure::new(400, "MESSAGE_TOO_LONG"));
    }
    let Some(record) = repo::find_message(&state.db, message_id)
        .await
        .map_err(RpcFailure::internal)?
    else {
        return Err(RpcFailure::new(404, "MESSAGE_ID_INVALID"));
    };
    if record.chat_id != chat_id {
        return Err(RpcFailure::new(400, "MESSAGE_ID_INVALID"));
    }
    if !record.action_kind.is_empty() {
        return Err(RpcFailure::new(400, "MESSAGE_ID_INVALID"));
    }
    let Some(chat) = repo::find_chat(&state.db, chat_id)
        .await
        .map_err(RpcFailure::internal)?
    else {
        return Err(RpcFailure::new(404, "CHAT_ID_INVALID"));
    };
    let actor = chat.owner_user_id.unwrap_or(record.sender_user_id);
    let ctx = admin_context(state, Some(actor));
    apply_message_edit(&ctx, actor, chat, record, text, None, None).await?;
    Ok(())
}

/// Admin: pins or unpins a message (`message_id = 0` unpins).
pub async fn admin_pin_message(
    state: &crate::mtproto_listener::AppState,
    chat_id: i64,
    message_id: i64,
) -> Result<(), RpcFailure> {
    let Some(chat) = repo::find_chat(&state.db, chat_id)
        .await
        .map_err(RpcFailure::internal)?
    else {
        return Err(RpcFailure::new(404, "CHAT_ID_INVALID"));
    };
    if message_id > 0 {
        let Some(record) = repo::find_message(&state.db, message_id)
            .await
            .map_err(RpcFailure::internal)?
        else {
            return Err(RpcFailure::new(404, "MESSAGE_ID_INVALID"));
        };
        if record.chat_id != chat_id {
            return Err(RpcFailure::new(400, "MESSAGE_ID_INVALID"));
        }
    }
    let actor = chat
        .owner_user_id
        .or(chat.private_user_a)
        .ok_or_else(|| RpcFailure::new(400, "CHAT_OWNER_MISSING"))?;
    let ctx = admin_context(state, Some(actor));
    let pin = if message_id > 0 {
        Some(message_id)
    } else {
        None
    };
    apply_pinned_message(&ctx, actor, chat, pin).await?;
    Ok(())
}

/// Admin: creates a basic group / supergroup / broadcast channel owned by
/// `owner_user_id`. Member ids are validated and de-duplicated.
pub async fn admin_create_chat(
    state: &crate::mtproto_listener::AppState,
    kind: &str,
    owner_user_id: i64,
    title: &str,
    about: &str,
    member_ids: &[i64],
) -> Result<i64, RpcFailure> {
    let title = title.trim();
    if title.is_empty() || title.chars().count() > 255 {
        return Err(RpcFailure::new(400, "NO_CHAT_TITLE"));
    }
    if about.chars().count() > 255 {
        return Err(RpcFailure::new(400, "CHAT_ABOUT_TOO_LONG"));
    }
    let Some(owner) = repo::find_user_by_id(&state.db, owner_user_id)
        .await
        .map_err(RpcFailure::internal)?
    else {
        return Err(RpcFailure::new(404, "USER_NOT_FOUND"));
    };
    let mut members = Vec::new();
    let mut seen = HashSet::new();
    for member_id in member_ids {
        if *member_id == owner_user_id || !seen.insert(*member_id) {
            continue;
        }
        if repo::find_user_by_id(&state.db, *member_id)
            .await
            .map_err(RpcFailure::internal)?
            .is_some()
        {
            members.push(*member_id);
        }
    }
    let ctx = admin_context(state, Some(owner.id));
    match kind {
        "basic_group" => {
            let chat = repo::create_basic_group(&state.db, owner.id, title, &members)
                .await
                .map_err(RpcFailure::internal)?;
            let record =
                repo::send_service_message(&state.db, chat.id, owner.id, "create", owner.id, title)
                    .await
                    .map_err(RpcFailure::internal)?;
            deliver_basic_group_message(&ctx, &chat, &record, &owner, None, None).await?;
            Ok(chat.id)
        }
        "group" | "channel" => {
            let channel = repo::create_channel(
                &state.db,
                owner.id,
                title,
                about,
                kind == "channel",
            )
            .await
            .map_err(RpcFailure::internal)?;
            repo::ensure_channel_dialog(&state.db, owner.id, channel.id)
                .await
                .map_err(RpcFailure::internal)?;
            for member_id in &members {
                repo::add_channel_member(&state.db, channel.id, *member_id)
                    .await
                    .map_err(RpcFailure::internal)?;
                repo::ensure_channel_dialog(&state.db, *member_id, channel.id)
                    .await
                    .map_err(RpcFailure::internal)?;
            }
            publish_channel_update(&ctx, &channel, owner.id).await?;
            Ok(channel.id)
        }
        _ => Err(RpcFailure::new(400, "CHAT_KIND_UNSUPPORTED")),
    }
}

/// Admin: hard-deletes a non-private chat after pushing message deletions to
/// the members. Returns the number of removed messages.
pub async fn admin_delete_chat(
    state: &crate::mtproto_listener::AppState,
    chat_id: i64,
) -> Result<i32, RpcFailure> {
    let Some(chat) = repo::find_channel(&state.db, chat_id)
        .await
        .map_err(RpcFailure::internal)?
    else {
        return Err(RpcFailure::new(404, "CHAT_ID_INVALID"));
    };
    if chat.kind == "private" {
        return Err(RpcFailure::new(400, "CHAT_KIND_UNSUPPORTED"));
    }
    let ids = repo::chat_message_ids(&state.db, chat_id)
        .await
        .map_err(RpcFailure::internal)?;
    let ctx = admin_context(state, Some(chat.owner_user_id));
    let mut deleted = 0i32;
    for chunk in ids.chunks(100) {
        let (_, count) = delete_messages_in_chat(&ctx, &chat_id, chunk).await?;
        deleted += count;
    }
    repo::delete_chat(&state.db, chat_id)
        .await
        .map_err(RpcFailure::internal)?;
    Ok(deleted)
}

#[derive(Debug, Clone)]
pub struct DeleteUserPlan {
    pub user_id: i64,
    pub owned_chats: Vec<i64>,
    pub private_chats: Vec<i64>,
    pub messages: i64,
    pub media: i64,
    pub executed: bool,
}

/// Admin: permanently deletes a Telegram account. Refuses while the user still
/// owns non-private chats (no cascade rule exists for `te_chats.owner_user_id`).
/// With `dry_run` the impact is only counted, never written.
pub async fn admin_delete_user(
    state: &crate::mtproto_listener::AppState,
    user_id: i64,
    dry_run: bool,
) -> Result<DeleteUserPlan, RpcFailure> {
    let Some(user) = repo::find_user_by_id(&state.db, user_id)
        .await
        .map_err(RpcFailure::internal)?
    else {
        return Err(RpcFailure::new(404, "USER_NOT_FOUND"));
    };
    if user.phone == repo::SYSTEM_USER_PHONE {
        return Err(RpcFailure::new(400, "SYSTEM_USER_PROTECTED"));
    }
    let owned = repo::user_owned_chat_ids(&state.db, user_id)
        .await
        .map_err(RpcFailure::internal)?;
    let private_chats = repo::user_private_chat_ids(&state.db, user_id)
        .await
        .map_err(RpcFailure::internal)?;
    let mut plan = DeleteUserPlan {
        user_id,
        owned_chats: owned.clone(),
        private_chats: private_chats.clone(),
        messages: repo::count_user_messages(&state.db, user_id)
            .await
            .map_err(RpcFailure::internal)?,
        media: repo::count_user_media(&state.db, user_id)
            .await
            .map_err(RpcFailure::internal)?,
        executed: false,
    };
    if dry_run {
        return Ok(plan);
    }
    if !owned.is_empty() {
        return Err(RpcFailure::new(400, "USER_OWNS_CHATS"));
    }

    let ctx = admin_context(state, Some(user_id));
    let mut deleted_messages = 0i32;
    for chat_id in &private_chats {
        let ids = repo::chat_message_ids(&state.db, *chat_id)
            .await
            .map_err(RpcFailure::internal)?;
        for chunk in ids.chunks(100) {
            let (_, count) = delete_messages_in_chat(&ctx, chat_id, chunk).await?;
            deleted_messages += count;
        }
        repo::delete_chat(&state.db, *chat_id)
            .await
            .map_err(RpcFailure::internal)?;
    }
    for (chat_id, ids) in repo::user_message_ids_by_chat(&state.db, user_id)
        .await
        .map_err(RpcFailure::internal)?
    {
        let Some(chat) = repo::find_chat(&state.db, chat_id)
            .await
            .map_err(RpcFailure::internal)?
        else {
            continue;
        };
        let chat_ctx = admin_context(state, chat.owner_user_id.or(Some(user_id)));
        for chunk in ids.chunks(100) {
            let (_, count) = delete_messages_in_chat(&chat_ctx, &chat_id, chunk).await?;
            deleted_messages += count;
        }
        if ids.contains(&chat.pinned_msg_id) {
            repo::set_pinned_message(&state.db, chat_id, 0)
                .await
                .map_err(RpcFailure::internal)?;
        }
    }
    let released = repo::release_user_media(&state.db, user_id)
        .await
        .map_err(RpcFailure::internal)?;
    repo::delete_user_record(&state.db, user_id)
        .await
        .map_err(RpcFailure::internal)?;
    plan.messages = i64::from(deleted_messages);
    plan.media = released as i64;
    plan.executed = true;
    Ok(plan)
}

/// Admin: approves or rejects a pending join request. Approval reuses the
/// normal member insert + channel update path.
pub async fn admin_review_join_request(
    state: &crate::mtproto_listener::AppState,
    chat_id: i64,
    user_id: i64,
    approve: bool,
    reviewer: &str,
) -> Result<(), RpcFailure> {
    let Some(chat) = repo::find_channel(&state.db, chat_id)
        .await
        .map_err(RpcFailure::internal)?
    else {
        return Err(RpcFailure::new(404, "CHAT_ID_INVALID"));
    };
    if chat.kind != "group" && chat.kind != "channel" {
        return Err(RpcFailure::new(400, "CHAT_KIND_UNSUPPORTED"));
    }
    let Some(status) = repo::find_join_request(&state.db, chat_id, user_id)
        .await
        .map_err(RpcFailure::internal)?
    else {
        return Err(RpcFailure::new(404, "JOIN_REQUEST_NOT_FOUND"));
    };
    if status != "pending" {
        return Err(RpcFailure::new(400, "JOIN_REQUEST_HANDLED"));
    }
    if approve {
        if repo::find_user_by_id(&state.db, user_id)
            .await
            .map_err(RpcFailure::internal)?
            .is_none()
        {
            return Err(RpcFailure::new(404, "USER_NOT_FOUND"));
        }
        if repo::channel_membership(&state.db, chat_id, user_id)
            .await
            .map_err(RpcFailure::internal)?
            .is_none()
        {
            repo::add_channel_member(&state.db, chat_id, user_id)
                .await
                .map_err(RpcFailure::internal)?;
            repo::ensure_channel_dialog(&state.db, user_id, chat_id)
                .await
                .map_err(RpcFailure::internal)?;
            let Some(updated) = repo::find_channel(&state.db, chat_id)
                .await
                .map_err(RpcFailure::internal)?
            else {
                return Err(RpcFailure::new(404, "CHAT_ID_INVALID"));
            };
            let ctx = admin_context(state, Some(updated.owner_user_id));
            publish_channel_update(&ctx, &updated, updated.owner_user_id).await?;
        }
    }
    let status = if approve { "approved" } else { "rejected" };
    repo::review_join_request(&state.db, chat_id, user_id, status, reviewer)
        .await
        .map_err(RpcFailure::internal)?;
    Ok(())
}

/// Makes sure every user has the system assistant in their chat list.
async fn ensure_system_welcome(ctx: &RpcContext<'_>, user_id: i64) {
    let Ok(system) = repo::ensure_system_user(ctx.db).await else {
        return;
    };
    if user_id == system.id {
        return;
    }
    let has_chat = repo::find_private_chat(ctx.db, system.id, user_id)
        .await
        .ok()
        .flatten()
        .is_some();
    if !has_chat {
        let _ = send_system_message(ctx.db, ctx.updates, user_id, SYSTEM_WELCOME_TEXT).await;
    }
}

async fn authorize(ctx: &mut RpcContext<'_>, user: &UserRecord) -> Result<(), RpcFailure> {
    if repo::user_banned(ctx.db, user.id)
        .await
        .map_err(RpcFailure::internal)?
        .unwrap_or(false)
    {
        return Err(RpcFailure::new(401, "USER_DEACTIVATED_BANNED"));
    }
    let device = repo::SessionDevice {
        device_model: &ctx.client.device_model,
        platform: "",
        system_version: &ctx.client.system_version,
        app_version: &ctx.client.app_version,
        api_id: ctx.client.api_id,
        app_name: "",
        lang_code: &ctx.client.lang_code,
    };
    repo::save_session(
        ctx.db,
        ctx.auth_key_id,
        user.id,
        ctx.layer,
        &ctx.peer,
        &device,
    )
    .await
    .map_err(RpcFailure::internal)?;
    for peer in repo::auth_key_binding_peers(ctx.db, ctx.auth_key_id)
        .await
        .map_err(RpcFailure::internal)?
    {
        repo::copy_session_to_auth_key(ctx.db, ctx.auth_key_id, peer)
            .await
            .map_err(RpcFailure::internal)?;
    }
    ctx.user_id = Some(user.id);
    Ok(())
}

async fn users_get_users(
    ctx: &mut RpcContext<'_>,
    reader: &mut Reader<'_>,
) -> Result<Vec<u8>, RpcFailure> {
    reader.expect_constructor(ctor::VECTOR)?;
    let count = reader.i32()?;
    let mut users = Vec::new();
    for _ in 0..count.max(0) {
        match read_input_user(reader)? {
            InputUser::SelfUser => {
                if let Some(user) = ctx_user(ctx).await? {
                    users.push(user_bytes(user));
                }
            }
            InputUser::Id(id) => {
                if let Some(user) = repo::find_user_by_id(ctx.db, id)
                    .await
                    .map_err(RpcFailure::internal)?
                {
                    users.push(other_user_bytes(&user));
                } else {
                    users.push(types::user_empty(id));
                }
            }
        }
    }
    let mut writer = Writer::new();
    writer.u32(ctor::VECTOR);
    writer.i32(users.len() as i32);
    for user in users {
        writer.raw(&user);
    }
    Ok(writer.into_bytes())
}

async fn users_get_full_user(
    ctx: &mut RpcContext<'_>,
    reader: &mut Reader<'_>,
) -> Result<Vec<u8>, RpcFailure> {
    let input = read_input_user(reader)?;
    let user = match input {
        InputUser::SelfUser => ctx_user(ctx).await?,
        InputUser::Id(id) => repo::find_user_by_id(ctx.db, id)
            .await
            .map_err(RpcFailure::internal)?,
    };
    let Some(user) = user else {
        return Err(RpcFailure::new(400, "USER_ID_INVALID"));
    };
    let (about, birthday) = repo::user_profile_extras(ctx.db, user.id)
        .await
        .map_err(RpcFailure::internal)?;
    Ok(types::users_user_full(&types::user_full(
        user.id, &about, birthday,
    )))
}

async fn account_update_profile(
    ctx: &mut RpcContext<'_>,
    reader: &mut Reader<'_>,
) -> Result<Vec<u8>, RpcFailure> {
    let flags = reader.u32()?;
    let first_name = if flags & 1 != 0 {
        Some(reader.string()?)
    } else {
        None
    };
    let last_name = if flags & 2 != 0 {
        Some(reader.string()?)
    } else {
        None
    };
    let about = if flags & 4 != 0 {
        Some(reader.string()?)
    } else {
        None
    };
    let Some(user) = ctx_user(ctx).await? else {
        return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
    };
    if let Some(about) = about {
        repo::set_user_bio(ctx.db, user.id, &about)
            .await
            .map_err(RpcFailure::internal)?;
    }
    let updated =
        repo::update_user_profile(ctx.db, user.id, first_name.as_deref(), last_name.as_deref())
            .await
            .map_err(RpcFailure::internal)?;
    Ok(user_bytes(updated))
}

async fn account_update_birthday(
    ctx: &mut RpcContext<'_>,
    reader: &mut Reader<'_>,
) -> Result<Vec<u8>, RpcFailure> {
    let flags = reader.u32()?;
    let Some(user) = ctx_user(ctx).await? else {
        return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
    };
    if flags & 1 == 0 {
        repo::set_user_birthday(ctx.db, user.id, 0, 0, 0)
            .await
            .map_err(RpcFailure::internal)?;
        return Ok(types::bool_true());
    }
    reader.expect_constructor(ctor::BIRTHDAY)?;
    let birthday_flags = reader.u32()?;
    let day = reader.i32()?;
    let month = reader.i32()?;
    let year = if birthday_flags & 1 != 0 {
        reader.i32()?
    } else {
        0
    };
    if !(1..=31).contains(&day) || !(1..=12).contains(&month) || year < 0 {
        return Err(RpcFailure::new(400, "BIRTHDAY_INVALID"));
    }
    repo::set_user_birthday(ctx.db, user.id, day, month, year)
        .await
        .map_err(RpcFailure::internal)?;
    Ok(types::bool_true())
}

async fn ctx_user(ctx: &RpcContext<'_>) -> Result<Option<UserRecord>, RpcFailure> {
    let Some(id) = ctx.user_id else {
        return Ok(None);
    };
    repo::find_user_by_id(ctx.db, id)
        .await
        .map_err(RpcFailure::internal)
}

/// Wire `UserStatus` for a user: online while at least one session is
/// connected, otherwise the persisted last-seen timestamp, falling back to
/// `userStatusRecently` when the account has never been seen offline.
fn user_status_bytes(user: &UserRecord) -> Vec<u8> {
    if presence::is_online(user.id) {
        types::user_status_online(now() as i32 + 120)
    } else if user.last_seen_at > 0 {
        types::user_status_offline(user.last_seen_at as i32)
    } else {
        types::user_status_recently()
    }
}

/// Broadcasts a presence change (`updateUserStatus`) to every user that shares
/// a private chat with `user_id`. A lost connection persists `last_seen_at`
/// before the offline update is sent.
pub async fn announce_presence(
    db: &Db,
    updates: &UpdateHub,
    user_id: i64,
    online: bool,
) -> Result<(), RpcFailure> {
    if !online {
        repo::touch_user_last_seen(db, user_id, now() as i64)
            .await
            .map_err(RpcFailure::internal)?;
    }
    let Some(user) = repo::find_user_by_id(db, user_id)
        .await
        .map_err(RpcFailure::internal)?
    else {
        return Ok(());
    };
    let peers = repo::presence_peers(db, user_id)
        .await
        .map_err(RpcFailure::internal)?;
    if peers.is_empty() {
        return Ok(());
    }
    let status = user_status_bytes(&user);
    let update = types::update_user_status(user_id, &status);
    let push = types::updates(&[update], &[other_user_bytes(&user)], now() as i32, 0);
    for peer_id in peers {
        updates.publish(peer_id, push.clone());
    }
    Ok(())
}

fn user_bytes(user: UserRecord) -> Vec<u8> {
    let status = user_status_bytes(&user);
    if user.is_bot {
        return types::user_bot_status(
            user.id,
            user.access_hash,
            &user.first_name,
            &user.last_name,
            &user.username,
            user.photo_media_id,
            user.bot_info_version.max(1),
            &status,
            true,
        );
    }
    types::user_with_photo_status(
        user.id,
        user.access_hash,
        &user.first_name,
        &user.last_name,
        &user.username,
        &user.phone,
        user.photo_media_id,
        user.emoji_status_document_id,
        &status,
    )
}

fn lang_pack_get_lang_pack(ctx: &RpcContext<'_>, lang_code: &str) -> Vec<u8> {
    match ctx.langpacks.find(lang_code) {
        Some(pack) => pack.difference(0),
        None => {
            tracing::debug!(%lang_code, "unknown language pack requested");
            types::lang_pack_difference(lang_code, 1)
        }
    }
}

fn lang_pack_get_difference(ctx: &RpcContext<'_>, lang_code: &str, from_version: i32) -> Vec<u8> {
    match ctx.langpacks.find(lang_code) {
        Some(pack) => pack.difference(from_version),
        None => types::lang_pack_difference(lang_code, 1),
    }
}

fn lang_pack_get_strings(ctx: &RpcContext<'_>, lang_code: &str, keys: &[String]) -> Vec<u8> {
    let strings = ctx
        .langpacks
        .find(lang_code)
        .map(|pack| pack.strings_for_keys(keys))
        .unwrap_or_default();
    types::lang_pack_strings(&strings)
}

fn lang_pack_get_language(ctx: &RpcContext<'_>, lang_code: &str) -> Result<Vec<u8>, RpcFailure> {
    match ctx.langpacks.find(lang_code) {
        Some(pack) => Ok(pack.language_entry().to_vec()),
        None => Err(RpcFailure::new(400, "LANG_CODE_NOT_SUPPORTED")),
    }
}

#[derive(Debug, Clone, Copy)]
enum InputUser {
    SelfUser,
    Id(i64),
}

fn read_input_user(reader: &mut Reader<'_>) -> Result<InputUser, RpcFailure> {
    match reader.constructor()? {
        ctor::INPUT_USER_SELF => Ok(InputUser::SelfUser),
        ctor::INPUT_USER => {
            let id = reader.i64()?;
            let _access_hash = reader.i64()?;
            Ok(InputUser::Id(id))
        }
        other => Err(RpcFailure::new(
            400,
            format!("UNSUPPORTED_INPUT_USER_0x{other:08X}"),
        )),
    }
}

fn read_input_user_ids(reader: &mut Reader<'_>, self_id: i64) -> Result<Vec<i64>, RpcFailure> {
    reader.expect_constructor(ctor::VECTOR)?;
    let count = reader.i32()?.max(0);
    let mut ids = Vec::with_capacity(count as usize);
    for _ in 0..count {
        match read_input_user(reader)? {
            InputUser::SelfUser => ids.push(self_id),
            InputUser::Id(id) => ids.push(id),
        }
    }
    Ok(ids)
}

async fn contacts_add_contact(
    ctx: &RpcContext<'_>,
    reader: &mut Reader<'_>,
) -> Result<Vec<u8>, RpcFailure> {
    let flags = reader.u32()?;
    let target = read_input_user(reader)?;
    let _first_name = reader.string()?;
    let _last_name = reader.string()?;
    let _phone = reader.string()?;
    if flags & 2 != 0 {
        // Note is an optional textWithEntities value.
        reader.expect_constructor(0x751f_3146)?;
        let note = reader.string()?;
        read_message_entities(reader, &note)?;
    }
    let Some(user_id) = ctx.user_id else {
        return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
    };
    let target_id = match target {
        InputUser::SelfUser => user_id,
        InputUser::Id(id) => id,
    };
    if target_id == user_id {
        return Err(RpcFailure::new(400, "PEER_ID_INVALID"));
    }
    let Some(user) = repo::find_user_by_id(ctx.db, target_id)
        .await
        .map_err(RpcFailure::internal)?
    else {
        return Err(RpcFailure::new(400, "PEER_ID_INVALID"));
    };
    repo::add_contact(ctx.db, user_id, target_id)
        .await
        .map_err(RpcFailure::internal)?;
    Ok(types::updates(&[], &[other_user_bytes(&user)], now() as i32, 0))
}

async fn contacts_delete_contacts(
    ctx: &RpcContext<'_>,
    reader: &mut Reader<'_>,
) -> Result<Vec<u8>, RpcFailure> {
    let Some(user_id) = ctx.user_id else {
        return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
    };
    let ids = read_input_user_ids(reader, user_id)?;
    repo::delete_contacts(ctx.db, user_id, &ids)
        .await
        .map_err(RpcFailure::internal)?;
    Ok(types::updates(&[], &[], now() as i32, 0))
}

async fn contacts_block(
    ctx: &RpcContext<'_>,
    reader: &mut Reader<'_>,
    block: bool,
) -> Result<Vec<u8>, RpcFailure> {
    let _flags = reader.u32()?;
    let peer = read_input_peer(ctx, reader)?;
    let Some(user_id) = ctx.user_id else {
        return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
    };
    let target_id = match peer {
        PeerRef::User(id) => id,
        _ => return Err(RpcFailure::new(400, "PEER_ID_INVALID")),
    };
    if target_id == user_id {
        return Err(RpcFailure::new(400, "PEER_ID_INVALID"));
    }
    if block {
        repo::block_user(ctx.db, user_id, target_id)
            .await
            .map_err(RpcFailure::internal)?;
    } else {
        repo::unblock_user(ctx.db, user_id, target_id)
            .await
            .map_err(RpcFailure::internal)?;
    }
    Ok(types::bool_true())
}

fn read_privacy_rules(
    reader: &mut Reader<'_>,
    self_id: i64,
) -> Result<Vec<serde_json::Value>, RpcFailure> {
    reader.expect_constructor(ctor::VECTOR)?;
    let count = reader.i32()?.max(0);
    let mut rules = Vec::with_capacity(count as usize);
    for _ in 0..count {
        let rule = match reader.constructor()? {
            0x0d09_e07b => serde_json::json!({ "type": "allow_contacts" }),
            0x184b_35ce => serde_json::json!({ "type": "allow_all" }),
            0x131c_c67f => {
                let ids = read_input_user_ids(reader, self_id)?;
                serde_json::json!({ "type": "allow_users", "user_ids": ids })
            }
            0x0ba5_2007 => serde_json::json!({ "type": "disallow_contacts" }),
            0xd66b_66c9 => serde_json::json!({ "type": "disallow_all" }),
            0x9011_0467 => {
                let ids = read_input_user_ids(reader, self_id)?;
                serde_json::json!({ "type": "disallow_users", "user_ids": ids })
            }
            other => {
                return Err(RpcFailure::new(
                    400,
                    format!("UNSUPPORTED_INPUT_PRIVACY_RULE_0x{other:08X}"),
                ))
            }
        };
        rules.push(rule);
    }
    Ok(rules)
}

fn privacy_rule_bytes(rules: &serde_json::Value) -> Vec<Vec<u8>> {
    let mut output = Vec::new();
    let Some(items) = rules.as_array() else {
        return output;
    };
    for item in items {
        let kind = item
            .get("type")
            .and_then(serde_json::Value::as_str)
            .unwrap_or("");
        let user_ids: Vec<i64> = item
            .get("user_ids")
            .and_then(serde_json::Value::as_array)
            .map(|ids| {
                ids.iter()
                    .filter_map(serde_json::Value::as_i64)
                    .collect::<Vec<_>>()
            })
            .unwrap_or_default();
        match kind {
            "allow_all" => output.push(types::privacy_value_allow_all()),
            "allow_contacts" => output.push(types::privacy_value_allow_contacts()),
            "disallow_all" => output.push(types::privacy_value_disallow_all()),
            "disallow_contacts" => output.push(types::privacy_value_disallow_contacts()),
            "allow_users" => output.push(types::privacy_value_allow_users(&user_ids)),
            "disallow_users" => output.push(types::privacy_value_disallow_users(&user_ids)),
            _ => {}
        }
    }
    output
}

async fn account_set_privacy(
    ctx: &RpcContext<'_>,
    reader: &mut Reader<'_>,
) -> Result<Vec<u8>, RpcFailure> {
    let key = reader.constructor()?;
    let Some(user_id) = ctx.user_id else {
        return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
    };
    let rules = read_privacy_rules(reader, user_id)?;
    let value = serde_json::Value::Array(rules);
    repo::save_privacy_rules(ctx.db, user_id, i64::from(key), &value)
        .await
        .map_err(RpcFailure::internal)?;
    Ok(types::account_privacy_rules(&privacy_rule_bytes(&value)))
}

fn read_notify_from(reader: &mut Reader<'_>) -> Result<types::NotifyFrom, RpcFailure> {
    match reader.constructor()? {
        ctor::REACTION_NOTIFICATIONS_FROM_CONTACTS => Ok(types::NotifyFrom::Contacts),
        ctor::REACTION_NOTIFICATIONS_FROM_ALL => Ok(types::NotifyFrom::All),
        other => Err(RpcFailure::new(
            400,
            format!("REACTION_NOTIFICATIONS_FROM_INVALID_0x{other:08X}"),
        )),
    }
}

fn read_reactions_notify_settings(
    reader: &mut Reader<'_>,
) -> Result<types::ReactionsNotifySettings, RpcFailure> {
    let flags = reader.u32()?;
    let messages_notify_from = if flags & (1 << 0) != 0 {
        Some(read_notify_from(reader)?)
    } else {
        None
    };
    let stories_notify_from = if flags & (1 << 1) != 0 {
        Some(read_notify_from(reader)?)
    } else {
        None
    };
    let poll_votes_notify_from = if flags & (1 << 2) != 0 {
        Some(read_notify_from(reader)?)
    } else {
        None
    };
    let sound = match reader.constructor()? {
        ctor::NOTIFICATION_SOUND_DEFAULT => types::NotificationSound::Default,
        ctor::NOTIFICATION_SOUND_NONE => types::NotificationSound::None,
        ctor::NOTIFICATION_SOUND_LOCAL => types::NotificationSound::Local {
            title: reader.string()?,
            data: reader.string()?,
        },
        ctor::NOTIFICATION_SOUND_RINGTONE => types::NotificationSound::Ringtone {
            id: reader.i64()?,
        },
        other => {
            return Err(RpcFailure::new(
                400,
                format!("NOTIFICATION_SOUND_INVALID_0x{other:08X}"),
            ))
        }
    };
    let show_previews = reader.bool()?;
    Ok(types::ReactionsNotifySettings {
        messages_notify_from,
        stories_notify_from,
        poll_votes_notify_from,
        sound,
        show_previews,
    })
}

fn notify_from_json(value: types::NotifyFrom) -> serde_json::Value {
    serde_json::Value::String(
        match value {
            types::NotifyFrom::Contacts => "contacts",
            types::NotifyFrom::All => "all",
        }
        .to_owned(),
    )
}

fn notify_from_from_json(value: &serde_json::Value) -> Option<types::NotifyFrom> {
    match value.as_str() {
        Some("contacts") => Some(types::NotifyFrom::Contacts),
        Some("all") => Some(types::NotifyFrom::All),
        _ => None,
    }
}

fn reactions_notify_settings_to_json(settings: &types::ReactionsNotifySettings) -> serde_json::Value {
    let mut object = serde_json::Map::new();
    if let Some(value) = settings.messages_notify_from {
        object.insert("messages_notify_from".to_owned(), notify_from_json(value));
    }
    if let Some(value) = settings.stories_notify_from {
        object.insert("stories_notify_from".to_owned(), notify_from_json(value));
    }
    if let Some(value) = settings.poll_votes_notify_from {
        object.insert("poll_votes_notify_from".to_owned(), notify_from_json(value));
    }
    match &settings.sound {
        types::NotificationSound::Default => {
            object.insert("sound".to_owned(), serde_json::Value::String("default".to_owned()));
        }
        types::NotificationSound::None => {
            object.insert("sound".to_owned(), serde_json::Value::String("none".to_owned()));
        }
        types::NotificationSound::Local { title, data } => {
            object.insert("sound".to_owned(), serde_json::Value::String("local".to_owned()));
            object.insert("sound_title".to_owned(), serde_json::Value::String(title.clone()));
            object.insert("sound_data".to_owned(), serde_json::Value::String(data.clone()));
        }
        types::NotificationSound::Ringtone { id } => {
            object.insert("sound".to_owned(), serde_json::Value::String("ringtone".to_owned()));
            object.insert("sound_id".to_owned(), serde_json::Value::from(*id));
        }
    }
    object.insert(
        "show_previews".to_owned(),
        serde_json::Value::Bool(settings.show_previews),
    );
    serde_json::Value::Object(object)
}

fn reactions_notify_settings_from_json(value: &serde_json::Value) -> types::ReactionsNotifySettings {
    let read = |key: &str| value.get(key).and_then(notify_from_from_json);
    let sound = match value.get("sound").and_then(|sound| sound.as_str()) {
        Some("none") => types::NotificationSound::None,
        Some("local") => types::NotificationSound::Local {
            title: value
                .get("sound_title")
                .and_then(|title| title.as_str())
                .unwrap_or_default()
                .to_owned(),
            data: value
                .get("sound_data")
                .and_then(|data| data.as_str())
                .unwrap_or_default()
                .to_owned(),
        },
        Some("ringtone") => types::NotificationSound::Ringtone {
            id: value
                .get("sound_id")
                .and_then(|id| id.as_i64())
                .unwrap_or_default(),
        },
        _ => types::NotificationSound::Default,
    };
    types::ReactionsNotifySettings {
        messages_notify_from: read("messages_notify_from"),
        stories_notify_from: read("stories_notify_from"),
        poll_votes_notify_from: read("poll_votes_notify_from"),
        sound,
        show_previews: value
            .get("show_previews")
            .and_then(|previews| previews.as_bool())
            .unwrap_or(true),
    }
}

async fn account_set_reactions_notify_settings(
    ctx: &RpcContext<'_>,
    reader: &mut Reader<'_>,
) -> Result<Vec<u8>, RpcFailure> {
    let Some(user_id) = ctx.user_id else {
        return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
    };
    let settings = read_reactions_notify_settings(reader)?;
    let value = reactions_notify_settings_to_json(&settings);
    repo::save_reaction_notify_settings(ctx.db, user_id, &value)
        .await
        .map_err(RpcFailure::internal)?;
    Ok(types::reactions_notify_settings(&settings))
}

async fn load_dialogs(
    ctx: &RpcContext<'_>,
) -> Result<(Vec<Vec<u8>>, Vec<Vec<u8>>, Vec<Vec<u8>>, Vec<Vec<u8>>), RpcFailure> {
    let Some(user_id) = ctx.user_id else {
        return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
    };
    let records = repo::list_dialogs(ctx.db, user_id)
        .await
        .map_err(RpcFailure::internal)?;
    build_dialogs(ctx, user_id, records).await
}

async fn load_pinned_dialogs(
    ctx: &RpcContext<'_>,
) -> Result<(Vec<Vec<u8>>, Vec<Vec<u8>>, Vec<Vec<u8>>, Vec<Vec<u8>>), RpcFailure> {
    let Some(user_id) = ctx.user_id else {
        return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
    };
    let records = repo::list_pinned_dialogs(ctx.db, user_id)
        .await
        .map_err(RpcFailure::internal)?;
    build_dialogs(ctx, user_id, records).await
}

async fn build_dialogs(
    ctx: &RpcContext<'_>,
    user_id: i64,
    records: Vec<repo::DialogRecord>,
) -> Result<(Vec<Vec<u8>>, Vec<Vec<u8>>, Vec<Vec<u8>>, Vec<Vec<u8>>), RpcFailure> {
    let mut dialogs = Vec::with_capacity(records.len());
    let mut messages = Vec::with_capacity(records.len());
    let mut chats = Vec::new();
    let mut users = Vec::new();
    let mut seen_users = HashSet::new();
    let mut seen_chats = HashSet::new();

    for record in records {
        if record.message_id == 0 {
            continue;
        }
        let media = load_media_bytes(ctx, record.media_id).await?;
        if record.kind == "private" {
            let Some(other) = repo::find_user_by_id(ctx.db, record.other_user_id)
                .await
                .map_err(RpcFailure::internal)?
            else {
                continue;
            };
            let peer = types::peer_user(record.other_user_id);
            dialogs.push(types::dialog_ext(
                &peer,
                record.message_id as i32,
                record.unread_count,
                record.pinned,
            ));
            messages.push(private_message(
                record.message_id as i32,
                record.sender_user_id == user_id,
                record.sender_user_id,
                record.other_user_id,
                record.sent_at as i32,
                &record.text,
                media.as_deref(),
            ));
            if seen_users.insert(other.id) {
                users.push(other_user_bytes(&other));
            }
        } else if record.kind == "basic_group" {
            let Some(chat) = repo::find_channel(ctx.db, record.chat_id)
                .await
                .map_err(RpcFailure::internal)?
            else {
                continue;
            };
            let peer = types::peer_chat(record.chat_id);
            dialogs.push(types::dialog_ext(
                &peer,
                record.message_id as i32,
                record.unread_count,
                record.pinned,
            ));
            messages.push(chat_message(
                record.message_id as i32,
                record.sender_user_id == user_id,
                record.sender_user_id,
                record.chat_id,
                record.sent_at as i32,
                &record.text,
                media.as_deref(),
            ));
            if seen_chats.insert(record.chat_id) {
                chats.push(chat_record_bytes(&chat, user_id));
            }
            if record.sender_user_id != user_id && seen_users.insert(record.sender_user_id) {
                if let Some(sender) = repo::find_user_by_id(ctx.db, record.sender_user_id)
                    .await
                    .map_err(RpcFailure::internal)?
                {
                    users.push(other_user_bytes(&sender));
                }
            }
        } else {
            let Some(channel) = repo::find_channel(ctx.db, record.chat_id)
                .await
                .map_err(RpcFailure::internal)?
            else {
                continue;
            };
            let peer = types::peer_channel(record.chat_id);
            dialogs.push(types::dialog_ext(
                &peer,
                record.message_id as i32,
                record.unread_count,
                record.pinned,
            ));
            messages.push(channel_message(
                record.message_id as i32,
                record.sender_user_id == user_id,
                record.sender_user_id,
                record.chat_id,
                record.sent_at as i32,
                &record.text,
                media.as_deref(),
            ));
            if seen_chats.insert(record.chat_id) {
                chats.push(channel_bytes(&channel, user_id));
            }
            if record.sender_user_id != user_id && seen_users.insert(record.sender_user_id) {
                if let Some(sender) = repo::find_user_by_id(ctx.db, record.sender_user_id)
                    .await
                    .map_err(RpcFailure::internal)?
                {
                    users.push(other_user_bytes(&sender));
                }
            }
        }
    }
    Ok((dialogs, messages, chats, users))
}

fn read_draft_reply_to(reader: &mut Reader<'_>) -> Result<i64, RpcFailure> {
    match reader.constructor()? {
        ctor::INPUT_REPLY_TO_MESSAGE => Ok(i64::from(reader.i32()?)),
        ctor::INPUT_REPLY_TO_STORY => {
            let _peer = reader.constructor()?;
            let _peer_id = reader.i64()?;
            let _story_id = reader.i32()?;
            Ok(0)
        }
        other => Err(RpcFailure::new(
            400,
            format!("UNSUPPORTED_INPUT_REPLY_TO_0x{other:08X}"),
        )),
    }
}

/// Reads `InputDialogPeer`, resolving it to the local chat id. Folder peers
/// resolve to `None` because this server keeps pinned dialogs in a single list.
async fn read_input_dialog_peer(
    ctx: &RpcContext<'_>,
    reader: &mut Reader<'_>,
    user_id: i64,
) -> Result<Option<i64>, RpcFailure> {
    match reader.constructor()? {
        ctor::INPUT_DIALOG_PEER => {
            let peer = read_input_peer(ctx, reader)?;
            let chat = resolve_peer_chat(ctx, peer, user_id, false).await?;
            Ok(Some(chat.id))
        }
        ctor::INPUT_DIALOG_PEER_FOLDER => {
            let _folder_id = reader.i32()?;
            Ok(None)
        }
        other => Err(RpcFailure::new(
            400,
            format!("UNSUPPORTED_INPUT_DIALOG_PEER_0x{other:08X}"),
        )),
    }
}

async fn messages_save_draft(
    ctx: &RpcContext<'_>,
    reader: &mut Reader<'_>,
) -> Result<Vec<u8>, RpcFailure> {
    let flags = reader.u32()?;
    let reply_to = if flags & (1 << 4) != 0 {
        read_draft_reply_to(reader)?
    } else {
        0
    };
    let peer = read_input_peer(ctx, reader)?;
    let message = reader.string()?;
    let Some(user_id) = ctx.user_id else {
        return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
    };
    let chat = resolve_peer_chat(ctx, peer, user_id, false).await?;
    repo::save_draft(ctx.db, user_id, chat.id, &message, reply_to)
        .await
        .map_err(RpcFailure::internal)?;
    Ok(types::bool_true())
}

async fn messages_get_all_drafts(ctx: &RpcContext<'_>) -> Result<Vec<u8>, RpcFailure> {
    let Some(user_id) = ctx.user_id else {
        return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
    };
    let drafts = repo::list_drafts(ctx.db, user_id)
        .await
        .map_err(RpcFailure::internal)?;
    let mut updates = Vec::with_capacity(drafts.len());
    let mut users = Vec::new();
    let mut chats = Vec::new();
    let mut seen_users = HashSet::new();
    let mut seen_chats = HashSet::new();
    for draft in drafts {
        let peer = match draft.kind.as_str() {
            "private" => {
                let Some(other) = repo::find_user_by_id(ctx.db, draft.other_user_id)
                    .await
                    .map_err(RpcFailure::internal)?
                else {
                    continue;
                };
                if seen_users.insert(other.id) {
                    users.push(other_user_bytes(&other));
                }
                types::peer_user(draft.other_user_id)
            }
            "basic_group" => {
                if let Some(chat) = repo::find_channel(ctx.db, draft.chat_id)
                    .await
                    .map_err(RpcFailure::internal)?
                {
                    if seen_chats.insert(chat.id) {
                        chats.push(chat_record_bytes(&chat, user_id));
                    }
                }
                types::peer_chat(draft.chat_id)
            }
            _ => {
                if let Some(channel) = repo::find_channel(ctx.db, draft.chat_id)
                    .await
                    .map_err(RpcFailure::internal)?
                {
                    if seen_chats.insert(channel.id) {
                        chats.push(channel_bytes(&channel, user_id));
                    }
                }
                types::peer_channel(draft.chat_id)
            }
        };
        updates.push(types::update_draft_message(
            &peer,
            &draft.text,
            draft.reply_to,
            draft.updated_at as i32,
        ));
    }
    Ok(types::updates_with_chats(
        &updates,
        &users,
        &chats,
        now() as i32,
        0,
    ))
}

async fn messages_toggle_dialog_pin(
    ctx: &RpcContext<'_>,
    reader: &mut Reader<'_>,
) -> Result<Vec<u8>, RpcFailure> {
    let flags = reader.u32()?;
    let pinned = flags & 1 != 0;
    let Some(user_id) = ctx.user_id else {
        return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
    };
    let chat_id = read_input_dialog_peer(ctx, reader, user_id)
        .await?
        .ok_or_else(|| RpcFailure::new(400, "FOLDER_ID_INVALID"))?;
    repo::set_dialog_pin(ctx.db, user_id, chat_id, pinned)
        .await
        .map_err(RpcFailure::internal)?;
    Ok(types::bool_true())
}

async fn messages_reorder_pinned_dialogs(
    ctx: &RpcContext<'_>,
    reader: &mut Reader<'_>,
) -> Result<Vec<u8>, RpcFailure> {
    let _flags = reader.u32()?;
    let _folder_id = reader.i32()?;
    reader.expect_constructor(ctor::VECTOR)?;
    let count = reader.i32()?;
    let Some(user_id) = ctx.user_id else {
        return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
    };
    let mut chat_ids = Vec::with_capacity(count.max(0) as usize);
    for _ in 0..count.max(0) {
        if let Some(chat_id) = read_input_dialog_peer(ctx, reader, user_id).await? {
            chat_ids.push(chat_id);
        }
    }
    repo::reorder_pinned_dialogs(ctx.db, user_id, &chat_ids, now() as i64)
        .await
        .map_err(RpcFailure::internal)?;
    Ok(types::bool_true())
}

async fn messages_update_dialog_filter(
    ctx: &RpcContext<'_>,
    reader: &mut Reader<'_>,
) -> Result<Vec<u8>, RpcFailure> {
    let flags = reader.u32()?;
    let filter_id = reader.i32()?;
    let Some(user_id) = ctx.user_id else {
        return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
    };
    if flags & 1 == 0 {
        repo::delete_dialog_filter(ctx.db, user_id, filter_id)
            .await
            .map_err(RpcFailure::internal)?;
        return Ok(types::bool_true());
    }
    let remaining = reader.remaining();
    let filter = reader.raw(remaining)?.to_vec();
    if filter.len() < 4 {
        return Err(RpcFailure::new(400, "FILTER_ID_INVALID"));
    }
    repo::save_dialog_filter(ctx.db, user_id, filter_id, &filter)
        .await
        .map_err(RpcFailure::internal)?;
    Ok(types::bool_true())
}

async fn messages_get_dialog_filters(ctx: &RpcContext<'_>) -> Result<Vec<u8>, RpcFailure> {
    let Some(user_id) = ctx.user_id else {
        return Ok(types::messages_dialog_filters());
    };
    let filters = repo::list_dialog_filters(ctx.db, user_id)
        .await
        .map_err(RpcFailure::internal)?;
    Ok(types::messages_dialog_filters_with(&filters))
}

fn channel_bytes(channel: &repo::ChannelRecord, viewer_user_id: i64) -> Vec<u8> {
    channel_bytes_with_rights(channel, viewer_user_id, None)
}

fn channel_bytes_with_rights(
    channel: &repo::ChannelRecord,
    viewer_user_id: i64,
    admin_rights: Option<&[u8]>,
) -> Vec<u8> {
    let is_owner = channel.owner_user_id == viewer_user_id;
    let rights = if is_owner {
        Some(types::chat_admin_rights_full())
    } else {
        admin_rights.map(<[u8]>::to_vec)
    };
    let photo = (channel.photo_media_id > 0).then(|| types::chat_photo(channel.photo_media_id, 2));
    types::channel(
        channel.id,
        channel.access_hash,
        &channel.title,
        &channel.username,
        channel.kind == "channel",
        channel.kind == "group",
        is_owner,
        rights.as_deref(),
        None,
        channel.participants_count as i32,
        now() as i32,
        photo.as_deref(),
    )
}

async fn messages_get_history(
    ctx: &RpcContext<'_>,
    reader: &mut Reader<'_>,
) -> Result<Vec<u8>, RpcFailure> {
    let peer = read_input_peer(ctx, reader)?;
    let _offset_id = reader.i32()?;
    let _offset_date = reader.i32()?;
    let _add_offset = reader.i32()?;
    let limit = reader.i32()?;
    let _max_id = reader.i32()?;
    let _min_id = reader.i32()?;
    let _hash = reader.i64()?;
    let Some(user_id) = ctx.user_id else {
        return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
    };

    match peer {
        PeerRef::User(peer_id) => {
            if peer_id == user_id {
                return Ok(types::messages_messages(&[], &[], &[]));
            }
            let Some(chat_id) = repo::find_private_chat(ctx.db, user_id, peer_id)
                .await
                .map_err(RpcFailure::internal)?
            else {
                return Ok(types::messages_messages(&[], &[], &[]));
            };
            let records = repo::history(ctx.db, chat_id, limit)
                .await
                .map_err(RpcFailure::internal)?;
            let pinned_id = repo::pinned_message_id(ctx.db, chat_id)
                .await
                .map_err(RpcFailure::internal)?;
            let mut messages = Vec::with_capacity(records.len());
            for record in &records {
                let media = load_media_bytes(ctx, record.media_id).await?;
                let reactions = message_reactions_bytes(ctx, record.id, user_id).await?;
                messages.push(private_message_record(
                    record,
                    record.sender_user_id == user_id,
                    peer_id,
                    media.as_deref(),
                    pinned_id,
                    reactions.as_deref(),
                ));
            }
            let users = repo::find_user_by_id(ctx.db, peer_id)
                .await
                .map_err(RpcFailure::internal)?
                .map(|user| vec![other_user_bytes(&user)])
                .unwrap_or_default();
            Ok(types::messages_messages(&messages, &[], &users))
        }
        PeerRef::Channel { id, .. } => {
            let Some(channel) = repo::find_channel(ctx.db, id)
                .await
                .map_err(RpcFailure::internal)?
            else {
                return Err(RpcFailure::new(400, "CHANNEL_INVALID"));
            };
            if repo::channel_membership(ctx.db, channel.id, user_id)
                .await
                .map_err(RpcFailure::internal)?
                .is_none()
            {
                return Err(RpcFailure::new(403, "CHANNEL_PRIVATE"));
            }
            let records = repo::history(ctx.db, channel.id, limit)
                .await
                .map_err(RpcFailure::internal)?;
            let pinned_id = repo::pinned_message_id(ctx.db, channel.id)
                .await
                .map_err(RpcFailure::internal)?;
            let mut messages = Vec::with_capacity(records.len());
            for record in &records {
                let media = load_media_bytes(ctx, record.media_id).await?;
                let reactions = message_reactions_bytes(ctx, record.id, user_id).await?;
                messages.push(channel_message_record(
                    record,
                    record.sender_user_id == user_id,
                    channel.id,
                    media.as_deref(),
                    pinned_id,
                    reactions.as_deref(),
                ));
            }
            let mut users = Vec::new();
            let mut seen = HashSet::new();
            for record in &records {
                if record.sender_user_id != user_id && seen.insert(record.sender_user_id) {
                    if let Some(sender) = repo::find_user_by_id(ctx.db, record.sender_user_id)
                        .await
                        .map_err(RpcFailure::internal)?
                    {
                        users.push(other_user_bytes(&sender));
                    }
                }
            }
            Ok(types::messages_messages(
                &messages,
                &[channel_bytes(&channel, user_id)],
                &users,
            ))
        }
        PeerRef::Chat(id) => {
            let Some(chat) = repo::find_channel(ctx.db, id)
                .await
                .map_err(RpcFailure::internal)?
            else {
                return Err(RpcFailure::new(400, "CHAT_ID_INVALID"));
            };
            if chat.kind != "basic_group" {
                return Err(RpcFailure::new(400, "CHAT_ID_INVALID"));
            }
            if repo::channel_membership(ctx.db, chat.id, user_id)
                .await
                .map_err(RpcFailure::internal)?
                .is_none()
            {
                return Err(RpcFailure::new(403, "CHAT_PRIVATE"));
            }
            let records = repo::history(ctx.db, chat.id, limit)
                .await
                .map_err(RpcFailure::internal)?;
            let pinned_id = repo::pinned_message_id(ctx.db, chat.id)
                .await
                .map_err(RpcFailure::internal)?;
            let mut messages = Vec::with_capacity(records.len());
            for record in &records {
                let media = load_media_bytes(ctx, record.media_id).await?;
                let reactions = message_reactions_bytes(ctx, record.id, user_id).await?;
                messages.push(chat_message_or_service(
                    record,
                    record.sender_user_id == user_id,
                    chat.id,
                    media.as_deref(),
                    pinned_id,
                    reactions.as_deref(),
                ));
            }
            let mut users = Vec::new();
            let mut seen = HashSet::new();
            for record in &records {
                if record.sender_user_id != user_id && seen.insert(record.sender_user_id) {
                    if let Some(sender) = repo::find_user_by_id(ctx.db, record.sender_user_id)
                        .await
                        .map_err(RpcFailure::internal)?
                    {
                        users.push(other_user_bytes(&sender));
                    }
                }
            }
            Ok(types::messages_messages(
                &messages,
                &[chat_record_bytes(&chat, user_id)],
                &users,
            ))
        }
    }
}

async fn messages_search(
    ctx: &RpcContext<'_>,
    reader: &mut Reader<'_>,
) -> Result<Vec<u8>, RpcFailure> {
    let flags = reader.u32()?;
    let peer = read_input_peer(ctx, reader)?;
    let query = reader.string()?;
    if flags & (1 << 0) != 0 {
        let _from = read_input_peer(ctx, reader)?;
    }
    if flags & (1 << 2) != 0 {
        let _saved_peer = read_input_peer(ctx, reader)?;
    }
    if flags & (1 << 3) != 0 {
        return Err(RpcFailure::new(400, "REACTION_SEARCH_UNSUPPORTED"));
    }
    if flags & (1 << 1) != 0 {
        let _top_msg_id = reader.i32()?;
    }
    let _filter = reader.constructor()?;
    let _min_date = reader.i32()?;
    let _max_date = reader.i32()?;
    let _offset_id = reader.i32()?;
    let _add_offset = reader.i32()?;
    let limit = reader.i32()?;
    let _max_id = reader.i32()?;
    let _min_id = reader.i32()?;
    let _hash = reader.i64()?;
    let Some(user_id) = ctx.user_id else {
        return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
    };
    if query.trim().is_empty() {
        return Ok(types::messages_messages(&[], &[], &[]));
    }

    match peer {
        PeerRef::User(peer_id) => {
            if peer_id == user_id {
                return Ok(types::messages_messages(&[], &[], &[]));
            }
            let Some(chat_id) = repo::find_private_chat(ctx.db, user_id, peer_id)
                .await
                .map_err(RpcFailure::internal)?
            else {
                return Ok(types::messages_messages(&[], &[], &[]));
            };
            let records = repo::search_messages(ctx.db, chat_id, &query, limit)
                .await
                .map_err(RpcFailure::internal)?;
            let pinned_id = repo::pinned_message_id(ctx.db, chat_id)
                .await
                .map_err(RpcFailure::internal)?;
            let mut messages = Vec::with_capacity(records.len());
            for record in &records {
                let media = load_media_bytes(ctx, record.media_id).await?;
                let reactions = message_reactions_bytes(ctx, record.id, user_id).await?;
                messages.push(private_message_record(
                    record,
                    record.sender_user_id == user_id,
                    peer_id,
                    media.as_deref(),
                    pinned_id,
                    reactions.as_deref(),
                ));
            }
            let users = repo::find_user_by_id(ctx.db, peer_id)
                .await
                .map_err(RpcFailure::internal)?
                .map(|user| vec![other_user_bytes(&user)])
                .unwrap_or_default();
            Ok(types::messages_messages(&messages, &[], &users))
        }
        PeerRef::Channel { id, .. } => {
            let Some(channel) = repo::find_channel(ctx.db, id)
                .await
                .map_err(RpcFailure::internal)?
            else {
                return Err(RpcFailure::new(400, "CHANNEL_INVALID"));
            };
            if repo::channel_membership(ctx.db, channel.id, user_id)
                .await
                .map_err(RpcFailure::internal)?
                .is_none()
            {
                return Err(RpcFailure::new(403, "CHANNEL_PRIVATE"));
            }
            let records = repo::search_messages(ctx.db, channel.id, &query, limit)
                .await
                .map_err(RpcFailure::internal)?;
            let pinned_id = repo::pinned_message_id(ctx.db, channel.id)
                .await
                .map_err(RpcFailure::internal)?;
            let mut messages = Vec::with_capacity(records.len());
            for record in &records {
                let media = load_media_bytes(ctx, record.media_id).await?;
                let reactions = message_reactions_bytes(ctx, record.id, user_id).await?;
                messages.push(channel_message_record(
                    record,
                    record.sender_user_id == user_id,
                    channel.id,
                    media.as_deref(),
                    pinned_id,
                    reactions.as_deref(),
                ));
            }
            let mut users = Vec::new();
            let mut seen = HashSet::new();
            for record in &records {
                if record.sender_user_id != user_id && seen.insert(record.sender_user_id) {
                    if let Some(sender) = repo::find_user_by_id(ctx.db, record.sender_user_id)
                        .await
                        .map_err(RpcFailure::internal)?
                    {
                        users.push(other_user_bytes(&sender));
                    }
                }
            }
            Ok(types::messages_messages(
                &messages,
                &[channel_bytes(&channel, user_id)],
                &users,
            ))
        }
        PeerRef::Chat(id) => {
            let Some(chat) = repo::find_channel(ctx.db, id)
                .await
                .map_err(RpcFailure::internal)?
            else {
                return Err(RpcFailure::new(400, "CHAT_ID_INVALID"));
            };
            if chat.kind != "basic_group" {
                return Err(RpcFailure::new(400, "CHAT_ID_INVALID"));
            }
            if repo::channel_membership(ctx.db, chat.id, user_id)
                .await
                .map_err(RpcFailure::internal)?
                .is_none()
            {
                return Err(RpcFailure::new(403, "CHAT_PRIVATE"));
            }
            let records = repo::search_messages(ctx.db, chat.id, &query, limit)
                .await
                .map_err(RpcFailure::internal)?;
            let pinned_id = repo::pinned_message_id(ctx.db, chat.id)
                .await
                .map_err(RpcFailure::internal)?;
            let mut messages = Vec::with_capacity(records.len());
            for record in &records {
                let media = load_media_bytes(ctx, record.media_id).await?;
                let reactions = message_reactions_bytes(ctx, record.id, user_id).await?;
                messages.push(chat_message_record(
                    record,
                    record.sender_user_id == user_id,
                    chat.id,
                    media.as_deref(),
                    pinned_id,
                    reactions.as_deref(),
                ));
            }
            let mut users = Vec::new();
            let mut seen = HashSet::new();
            for record in &records {
                if record.sender_user_id != user_id && seen.insert(record.sender_user_id) {
                    if let Some(sender) = repo::find_user_by_id(ctx.db, record.sender_user_id)
                        .await
                        .map_err(RpcFailure::internal)?
                    {
                        users.push(other_user_bytes(&sender));
                    }
                }
            }
            Ok(types::messages_messages(
                &messages,
                &[chat_record_bytes(&chat, user_id)],
                &users,
            ))
        }
    }
}

fn skip_optional_offset_peer(reader: &mut Reader<'_>) -> Result<(), RpcFailure> {
    match reader.constructor()? {
        0x7f3b_18ea => Ok(()), // inputPeerEmpty
        ctor::INPUT_PEER_SELF => Ok(()),
        ctor::INPUT_PEER_USER | ctor::INPUT_PEER_CHANNEL => {
            let _id = reader.i64()?;
            let _access_hash = reader.i64()?;
            Ok(())
        }
        ctor::INPUT_PEER_CHAT => {
            let _chat_id = reader.i64()?;
            Ok(())
        }
        other => Err(RpcFailure::new(
            400,
            format!("UNSUPPORTED_INPUT_PEER_0x{other:08X}"),
        )),
    }
}

async fn messages_search_global(
    ctx: &RpcContext<'_>,
    reader: &mut Reader<'_>,
) -> Result<Vec<u8>, RpcFailure> {
    let flags = reader.u32()?;
    if flags & (1 << 0) != 0 {
        let _folder_id = reader.i32()?;
    }
    if flags & (1 << 4) != 0 {
        let _community = read_input_channel(reader)?;
    }
    let query = reader.string()?;
    let _filter = reader.constructor()?;
    let _min_date = reader.i32()?;
    let _max_date = reader.i32()?;
    let _offset_rate = reader.i32()?;
    skip_optional_offset_peer(reader)?;
    let _offset_id = reader.i32()?;
    let limit = reader.i32()?;
    let Some(user_id) = ctx.user_id else {
        return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
    };
    let query = query.trim();
    if query.is_empty() {
        return Ok(types::messages_messages(&[], &[], &[]));
    }
    let records = repo::search_user_messages(ctx.db, user_id, query, limit)
        .await
        .map_err(RpcFailure::internal)?;
    let mut messages = Vec::with_capacity(records.len());
    let mut chats = Vec::new();
    let mut users = Vec::new();
    let mut seen_chats = HashSet::new();
    let mut seen_users = HashSet::new();
    for record in &records {
        let media = load_media_bytes(ctx, record.message.media_id).await?;
        if record.kind == "private" {
            if record.other_user_id == 0 {
                continue;
            }
            messages.push(private_message_record(
                &record.message,
                record.message.sender_user_id == user_id,
                record.other_user_id,
                media.as_deref(),
                0,
                None,
            ));
            if seen_users.insert(record.other_user_id) {
                if let Some(user) = repo::find_user_by_id(ctx.db, record.other_user_id)
                    .await
                    .map_err(RpcFailure::internal)?
                {
                    users.push(other_user_bytes(&user));
                }
            }
        } else if record.kind == "basic_group" {
            let Some(chat) = repo::find_channel(ctx.db, record.message.chat_id)
                .await
                .map_err(RpcFailure::internal)?
            else {
                continue;
            };
            messages.push(chat_message_record(
                &record.message,
                record.message.sender_user_id == user_id,
                chat.id,
                media.as_deref(),
                0,
                None,
            ));
            if seen_chats.insert(chat.id) {
                chats.push(chat_record_bytes(&chat, user_id));
            }
            if record.message.sender_user_id != user_id
                && seen_users.insert(record.message.sender_user_id)
            {
                if let Some(sender) = repo::find_user_by_id(ctx.db, record.message.sender_user_id)
                    .await
                    .map_err(RpcFailure::internal)?
                {
                    users.push(other_user_bytes(&sender));
                }
            }
        } else {
            let Some(channel) = repo::find_channel(ctx.db, record.message.chat_id)
                .await
                .map_err(RpcFailure::internal)?
            else {
                continue;
            };
            messages.push(channel_message_record(
                &record.message,
                record.message.sender_user_id == user_id,
                channel.id,
                media.as_deref(),
                0,
                None,
            ));
            if seen_chats.insert(channel.id) {
                chats.push(channel_bytes(&channel, user_id));
            }
            if record.message.sender_user_id != user_id
                && seen_users.insert(record.message.sender_user_id)
            {
                if let Some(sender) = repo::find_user_by_id(ctx.db, record.message.sender_user_id)
                    .await
                    .map_err(RpcFailure::internal)?
                {
                    users.push(other_user_bytes(&sender));
                }
            }
        }
    }
    Ok(types::messages_messages(&messages, &chats, &users))
}

async fn messages_send_message(
    ctx: &RpcContext<'_>,
    reader: &mut Reader<'_>,
) -> Result<Vec<u8>, RpcFailure> {
    let flags = reader.u32()?;
    let peer = read_input_peer(ctx, reader)?;
    let reply_to = if flags & 1 != 0 {
        read_input_reply_to(reader)?
    } else {
        None
    };
    let text = reader.string()?;
    let random_id = reader.i64()?;
    if text.is_empty() || text.chars().count() > 4096 {
        return Err(RpcFailure::new(400, "MESSAGE_EMPTY"));
    }
    let (entities, schedule_date, reply_markup) = parse_message_tail(reader, flags, &text)?;
    let extras = repo::MessageExtras {
        reply_to_msg_id: reply_to,
        entities,
        reply_markup,
        ..repo::MessageExtras::default()
    };
    if schedule_date > 0 {
        return schedule_message(ctx, peer, &text, random_id, None, &extras, schedule_date).await;
    }
    deliver_message(ctx, peer, &text, random_id, None, &extras).await
}

/// Reads `Vector<MessageEntity>` and keeps the raw TL bytes so the entity
/// survives storage and is echoed back unchanged.
fn read_message_entities(
    reader: &mut Reader<'_>,
    text: &str,
) -> Result<Vec<Vec<u8>>, RpcFailure> {
    reader.expect_constructor(ctor::VECTOR)?;
    let count = reader.i32()?;
    if !(0..=1000).contains(&count) {
        return Err(RpcFailure::new(400, "ENTITIES_TOO_LONG"));
    }
    let text_len = text.encode_utf16().count() as i32;
    let mut entities = Vec::new();
    for _ in 0..count {
        let start = reader.position();
        let constructor = reader.constructor()?;
        let (offset, length) = match constructor {
            0x7392_4be0 => {
                // messageEntityPre
                let offset = reader.i32()?;
                let length = reader.i32()?;
                let _language = reader.string()?;
                (offset, length)
            }
            0x76a6_d327 => {
                // messageEntityTextUrl
                let offset = reader.i32()?;
                let length = reader.i32()?;
                let _url = reader.string()?;
                (offset, length)
            }
            0xdc7b_1140 => {
                // messageEntityMentionName
                let offset = reader.i32()?;
                let length = reader.i32()?;
                let _user_id = reader.i64()?;
                (offset, length)
            }
            0xc8cf_05f8 => {
                // messageEntityCustomEmoji
                let offset = reader.i32()?;
                let length = reader.i32()?;
                let _document_id = reader.i64()?;
                (offset, length)
            }
            0xf1cc_aaac => {
                // messageEntityBlockquote
                let _flags = reader.u32()?;
                let offset = reader.i32()?;
                let length = reader.i32()?;
                (offset, length)
            }
            0x904a_c7c7 => {
                // messageEntityFormattedDate
                let _flags = reader.u32()?;
                let offset = reader.i32()?;
                let length = reader.i32()?;
                let _date = reader.i32()?;
                (offset, length)
            }
            0xc6c1_e5a7 => {
                // messageEntityDiffReplace
                let offset = reader.i32()?;
                let length = reader.i32()?;
                let _old_text = reader.string()?;
                (offset, length)
            }
            0x208e_68c9 => {
                // inputMessageEntityMentionName -> messageEntityMentionName
                let offset = reader.i32()?;
                let length = reader.i32()?;
                let user_id = match reader.constructor()? {
                    0xb988_86cf | ctor::INPUT_USER_SELF => None, // inputUserEmpty
                    ctor::INPUT_USER => {
                        let user_id = reader.i64()?;
                        let _access_hash = reader.i64()?;
                        Some(user_id)
                    }
                    other => {
                        return Err(RpcFailure::new(
                            400,
                            format!("UNSUPPORTED_INPUT_USER_0x{other:08X}"),
                        ));
                    }
                };
                if let Some(user_id) = user_id {
                    if offset >= 0
                        && length > 0
                        && offset.saturating_add(length) <= text_len
                    {
                        let mut writer = Writer::new();
                        writer.u32(0xdc7b_1140);
                        writer.i32(offset);
                        writer.i32(length);
                        writer.i64(user_id);
                        entities.push(writer.into_bytes());
                    }
                }
                continue;
            }
            _ => {
                let offset = reader.i32()?;
                let length = reader.i32()?;
                (offset, length)
            }
        };
        if offset >= 0 && length > 0 && offset.saturating_add(length) <= text_len {
            entities.push(reader.take_since(start)?.to_vec());
        }
    }
    Ok(entities)
}

/// Reads the optional `reply_markup` / `entities` / `schedule_date` tail shared
/// by `sendMessage` and `sendMedia`.
fn parse_message_tail(
    reader: &mut Reader<'_>,
    flags: u32,
    text: &str,
) -> Result<(Vec<Vec<u8>>, i32, Option<serde_json::Value>), RpcFailure> {
    let reply_markup = if flags & (1 << 2) != 0 {
        Some(read_reply_markup(reader)?)
    } else {
        None
    };
    let entities = if flags & (1 << 3) != 0 {
        read_message_entities(reader, text)?
    } else {
        Vec::new()
    };
    let schedule_date = if flags & (1 << 10) != 0 {
        reader.i32()?
    } else {
        0
    };
    Ok((entities, schedule_date, reply_markup))
}

/// Parses `ReplyMarkup` into Bot API JSON. Only inline keyboards are
/// supported; reply keyboards still return `REPLY_MARKUP_UNSUPPORTED`.
fn read_reply_markup(reader: &mut Reader<'_>) -> Result<serde_json::Value, RpcFailure> {
    let constructor = reader.constructor()?;
    if constructor != 0x48a3_0254 {
        return Err(RpcFailure::new(400, "REPLY_MARKUP_UNSUPPORTED"));
    }
    let row_count = reader.i32()?.max(0);
    let mut rows = Vec::with_capacity(row_count as usize);
    for _ in 0..row_count {
        if reader.constructor()? != 0x7760_8b83 {
            return Err(RpcFailure::new(400, "REPLY_MARKUP_UNSUPPORTED"));
        }
        let button_count = reader.i32()?.max(0);
        let mut buttons = Vec::with_capacity(button_count as usize);
        for _ in 0..button_count {
            buttons.push(read_keyboard_button(reader)?);
        }
        rows.push(serde_json::Value::Array(buttons));
    }
    Ok(serde_json::json!({ "inline_keyboard": rows }))
}

fn read_keyboard_button(reader: &mut Reader<'_>) -> Result<serde_json::Value, RpcFailure> {
    match reader.constructor()? {
        0xa2fa_4880 => {
            // keyboardButton#a2fa4880 text:string
            let text = reader.string()?;
            Ok(serde_json::json!({ "text": text }))
        }
        0x258a_ff05 => {
            // keyboardButtonUrl#258aff05 text:string url:string
            let text = reader.string()?;
            let url = reader.string()?;
            Ok(serde_json::json!({ "text": text, "url": url }))
        }
        0x35bb_db6b => {
            // keyboardButtonCallback#35bbdb6b flags:# text:string data:bytes
            let _flags = reader.u32()?;
            let text = reader.string()?;
            let data = reader.bytes()?;
            let data = String::from_utf8(data).unwrap_or_default();
            Ok(serde_json::json!({
                "text": text,
                "callback_data": data,
            }))
        }
        other => Err(RpcFailure::new(
            400,
            format!("REPLY_MARKUP_UNSUPPORTED_0x{other:08X}"),
        )),
    }
}

fn read_input_reply_to(reader: &mut Reader<'_>) -> Result<Option<i64>, RpcFailure> {
    match reader.constructor()? {
        0x75c1_ad70 => {
            // inputReplyToMessage#75c1ad70
            let flags = reader.u32()?;
            let reply_to_msg_id = i64::from(reader.i32()?);
            if flags != 0 {
                return Err(RpcFailure::new(400, "REPLY_OPTIONS_UNSUPPORTED"));
            }
            Ok(Some(reply_to_msg_id))
        }
        other => Err(RpcFailure::new(
            400,
            format!("UNSUPPORTED_REPLY_TO_0x{other:08X}"),
        )),
    }
}

async fn deliver_message(
    ctx: &RpcContext<'_>,
    peer: PeerRef,
    text: &str,
    random_id: i64,
    media_record: Option<&repo::MediaRecord>,
    extras: &repo::MessageExtras,
) -> Result<Vec<u8>, RpcFailure> {
    let Some(user_id) = ctx.user_id else {
        return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
    };
    let media = match media_record {
        Some(record) => Some(media_bytes(ctx, record, ctx.user_id).await?),
        None => None,
    };
    let media_id = media_record.map(|record| record.id);

    match peer {
        PeerRef::User(peer_id) => {
            if peer_id == user_id {
                return Err(RpcFailure::new(400, "PEER_ID_INVALID"));
            }
            let Some(recipient) = repo::find_user_by_id(ctx.db, peer_id)
                .await
                .map_err(RpcFailure::internal)?
            else {
                return Err(RpcFailure::new(400, "PEER_ID_INVALID"));
            };
            let Some(sender) = ctx_user(ctx).await? else {
                return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
            };
            if repo::is_blocked_between(ctx.db, user_id, peer_id)
                .await
                .map_err(RpcFailure::internal)?
            {
                return Err(RpcFailure::new(403, "USER_IS_BLOCKED"));
            }

            let (record, sender_pts, recipient_pts) = repo::send_private_message(
                ctx.db, user_id, peer_id, text, random_id, media_id, extras,
            )
            .await
            .map_err(RpcFailure::internal)?;
            let sent_at = record.sent_at as i32;

            let sender_message =
                private_message_record(&record, true, peer_id, media.as_deref(), 0, None);
            let response = types::updates(
                &[
                    types::update_message_id(record.id as i32, random_id),
                    types::update_new_message(&sender_message, sender_pts),
                ],
                &[other_user_bytes(&recipient)],
                sent_at,
                0,
            );

            let recipient_message =
                private_message_record(&record, false, user_id, media.as_deref(), 0, None);
            let recipient_update = types::update_new_message(&recipient_message, recipient_pts);
            repo::log_user_update(
                ctx.db,
                user_id,
                sender_pts,
                &types::update_new_message(&sender_message, sender_pts),
            )
            .await
            .map_err(RpcFailure::internal)?;
            repo::log_user_update(ctx.db, peer_id, recipient_pts, &recipient_update)
                .await
                .map_err(RpcFailure::internal)?;
            if recipient.is_bot {
                if let Err(error) =
                    crate::bot_api::enqueue_incoming_message(ctx.db, recipient.id, &record, &sender)
                        .await
                {
                    tracing::warn!(%error, "enqueue bot update failed");
                }
            }
            let push = types::updates(
                &[recipient_update],
                &[other_user_bytes(&sender)],
                sent_at,
                0,
            );
            ctx.updates.publish(peer_id, push);

            // Sync the outgoing message to the sender's other online sessions.
            let self_push = types::updates(
                &[types::update_new_message(&sender_message, sender_pts)],
                &[other_user_bytes(&recipient)],
                sent_at,
                0,
            );
            ctx.updates
                .publish_excluding(user_id, Some(ctx.session_id), self_push);

            Ok(response)
        }
        PeerRef::Channel { id, access_hash } => {
            let Some(channel) = repo::find_channel(ctx.db, id)
                .await
                .map_err(RpcFailure::internal)?
            else {
                return Err(RpcFailure::new(400, "CHANNEL_INVALID"));
            };
            if channel.access_hash != 0 && channel.access_hash != access_hash {
                return Err(RpcFailure::new(400, "CHANNEL_INVALID"));
            }
            if repo::channel_membership(ctx.db, channel.id, user_id)
                .await
                .map_err(RpcFailure::internal)?
                .is_none()
            {
                return Err(RpcFailure::new(403, "CHAT_WRITE_FORBIDDEN"));
            }
            ensure_not_banned(ctx, channel.id, user_id, true).await?;
            if channel.kind == "channel" && channel.owner_user_id != user_id {
                return Err(RpcFailure::new(403, "CHAT_WRITE_FORBIDDEN"));
            }
            let Some(sender) = ctx_user(ctx).await? else {
                return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
            };

            let (record, pts, members) = repo::send_channel_message(
                ctx.db, channel.id, user_id, text, random_id, media_id, extras,
            )
            .await
            .map_err(RpcFailure::internal)?;
            let sent_at = record.sent_at as i32;
            let sender_message =
                channel_message_record(&record, true, channel.id, media.as_deref(), 0, None);
            let member_message =
                channel_message_record(&record, false, channel.id, media.as_deref(), 0, None);
            let channel_update = types::update_new_channel_message(&member_message, pts);
            repo::log_channel_update(ctx.db, channel.id, pts, &channel_update)
                .await
                .map_err(RpcFailure::internal)?;
            let response = types::updates_with_chats(
                &[
                    types::update_message_id(record.id as i32, random_id),
                    types::update_new_channel_message(&sender_message, pts),
                ],
                &[],
                &[channel_bytes(&channel, user_id)],
                sent_at,
                0,
            );

            for member_id in members {
                if member_id == user_id {
                    continue;
                }
                let member_message =
                    channel_message_record(&record, false, channel.id, media.as_deref(), 0, None);
                let push = types::updates_with_chats(
                    &[types::update_new_channel_message(&member_message, pts)],
                    &[other_user_bytes(&sender)],
                    &[channel_bytes(&channel, member_id)],
                    sent_at,
                    0,
                );
                ctx.updates.publish(member_id, push);
            }
            // Sync the outgoing channel message to the sender's other sessions.
            let self_push = types::updates_with_chats(
                &[types::update_new_channel_message(&sender_message, pts)],
                &[other_user_bytes(&sender)],
                &[channel_bytes(&channel, user_id)],
                sent_at,
                0,
            );
            ctx.updates
                .publish_excluding(user_id, Some(ctx.session_id), self_push);
            Ok(response)
        }
        PeerRef::Chat(id) => {
            let Some(chat) = repo::find_channel(ctx.db, id)
                .await
                .map_err(RpcFailure::internal)?
            else {
                return Err(RpcFailure::new(400, "CHAT_ID_INVALID"));
            };
            if chat.kind != "basic_group" {
                return Err(RpcFailure::new(400, "CHAT_ID_INVALID"));
            }
            if repo::channel_membership(ctx.db, chat.id, user_id)
                .await
                .map_err(RpcFailure::internal)?
                .is_none()
            {
                return Err(RpcFailure::new(403, "CHAT_WRITE_FORBIDDEN"));
            }
            ensure_not_banned(ctx, chat.id, user_id, true).await?;
            let Some(sender) = ctx_user(ctx).await? else {
                return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
            };
            let (record, _ignored, _members) = repo::send_channel_message(
                ctx.db, chat.id, user_id, text, random_id, media_id, extras,
            )
            .await
            .map_err(RpcFailure::internal)?;
            deliver_basic_group_message(
                ctx,
                &chat,
                &record,
                &sender,
                media.as_deref(),
                Some(random_id),
            )
            .await
            .map(|(_, response, _)| response)
        }
    }
}

async fn deliver_basic_group_message(
    ctx: &RpcContext<'_>,
    chat: &repo::ChannelRecord,
    record: &repo::MessageRecord,
    sender: &repo::UserRecord,
    media: Option<&[u8]>,
    random_id: Option<i64>,
) -> Result<(Vec<u8>, Vec<u8>, i32), RpcFailure> {
    let Some(user_id) = ctx.user_id else {
        return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
    };
    let sent_at = record.sent_at as i32;
    let member_ids = repo::chat_member_ids(ctx.db, chat.id)
        .await
        .map_err(RpcFailure::internal)?;
    let mut sender_message = Vec::new();
    let mut sender_pts = 0;
    let mut users = Vec::new();
    for member_id in &member_ids {
        let pts = repo::bump_user_pts(ctx.db, *member_id)
            .await
            .map_err(RpcFailure::internal)?;
        let out = *member_id == user_id;
        let message = chat_message_or_service(record, out, chat.id, media, 0, None);
        let update = types::update_new_message(&message, pts);
        repo::log_user_update(ctx.db, *member_id, pts, &update)
            .await
            .map_err(RpcFailure::internal)?;
        if *member_id == user_id {
            sender_message = message;
            sender_pts = pts;
        } else {
            let push = types::updates_with_chats(
                &[update],
                &[user_bytes(sender.clone())],
                &[chat_record_bytes(chat, *member_id)],
                sent_at,
                0,
            );
            ctx.updates.publish(*member_id, push);
            if let Some(user) = repo::find_user_by_id(ctx.db, *member_id)
                .await
                .map_err(RpcFailure::internal)?
            {
                users.push(other_user_bytes(&user));
            }
        }
    }
    let self_push = types::updates_with_chats(
        &[types::update_new_message(&sender_message, sender_pts)],
        &[user_bytes(sender.clone())],
        &[chat_record_bytes(chat, user_id)],
        sent_at,
        0,
    );
    ctx.updates
        .publish_excluding(user_id, Some(ctx.session_id), self_push);
    let mut response_updates = Vec::new();
    if let Some(random_id) = random_id {
        response_updates.push(types::update_message_id(record.id as i32, random_id));
    }
    response_updates.push(types::update_new_message(&sender_message, sender_pts));
    let response = types::updates_with_chats(
        &response_updates,
        &users,
        &[chat_record_bytes(chat, user_id)],
        sent_at,
        0,
    );
    Ok((sender_message, response, sender_pts))
}

async fn schedule_message(
    ctx: &RpcContext<'_>,
    peer: PeerRef,
    text: &str,
    random_id: i64,
    media: Option<&repo::MediaRecord>,
    extras: &repo::MessageExtras,
    schedule_date: i32,
) -> Result<Vec<u8>, RpcFailure> {
    let Some(user_id) = ctx.user_id else {
        return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
    };
    let scheduled_at = i64::from(schedule_date);
    let now_ts = now() as i64;
    if scheduled_at <= now_ts {
        return Err(RpcFailure::new(400, "SCHEDULE_DATE_INVALID"));
    }
    if scheduled_at > now_ts + 366 * 86400 {
        return Err(RpcFailure::new(400, "SCHEDULE_DATE_TOO_LATE"));
    }
    let chat = match peer {
        PeerRef::User(peer_id) => {
            if peer_id == user_id
                || repo::find_user_by_id(ctx.db, peer_id)
                    .await
                    .map_err(RpcFailure::internal)?
                    .is_none()
            {
                return Err(RpcFailure::new(400, "PEER_ID_INVALID"));
            }
            if repo::is_blocked_between(ctx.db, user_id, peer_id)
                .await
                .map_err(RpcFailure::internal)?
            {
                return Err(RpcFailure::new(403, "USER_IS_BLOCKED"));
            }
            let chat_id = match repo::find_private_chat(ctx.db, user_id, peer_id)
                .await
                .map_err(RpcFailure::internal)?
            {
                Some(chat_id) => chat_id,
                None => repo::ensure_private_chat(ctx.db, user_id, peer_id)
                    .await
                    .map_err(RpcFailure::internal)?,
            };
            repo::find_chat(ctx.db, chat_id)
                .await
                .map_err(RpcFailure::internal)?
                .ok_or_else(|| RpcFailure::new(400, "PEER_ID_INVALID"))?
        }
        PeerRef::Channel { id, access_hash } => {
            let Some(channel) = repo::find_channel(ctx.db, id)
                .await
                .map_err(RpcFailure::internal)?
            else {
                return Err(RpcFailure::new(400, "CHANNEL_INVALID"));
            };
            if channel.access_hash != 0 && channel.access_hash != access_hash {
                return Err(RpcFailure::new(400, "CHANNEL_INVALID"));
            }
            if repo::channel_membership(ctx.db, id, user_id)
                .await
                .map_err(RpcFailure::internal)?
                .is_none()
            {
                return Err(RpcFailure::new(403, "CHANNEL_PRIVATE"));
            }
            ensure_not_banned(ctx, id, user_id, true).await?;
            repo::find_chat(ctx.db, id)
                .await
                .map_err(RpcFailure::internal)?
                .ok_or_else(|| RpcFailure::new(400, "CHANNEL_INVALID"))?
        }
        PeerRef::Chat(id) => {
            let Some(chat) = repo::find_channel(ctx.db, id)
                .await
                .map_err(RpcFailure::internal)?
            else {
                return Err(RpcFailure::new(400, "CHAT_ID_INVALID"));
            };
            if chat.kind != "basic_group"
                || repo::channel_membership(ctx.db, id, user_id)
                    .await
                    .map_err(RpcFailure::internal)?
                    .is_none()
            {
                return Err(RpcFailure::new(403, "CHAT_PRIVATE"));
            }
            ensure_not_banned(ctx, id, user_id, true).await?;
            repo::find_chat(ctx.db, id)
                .await
                .map_err(RpcFailure::internal)?
                .ok_or_else(|| RpcFailure::new(400, "CHAT_ID_INVALID"))?
        }
    };
    let media_id = media.map(|media| media.id);
    let record = repo::create_scheduled_message(
        ctx.db,
        chat.id,
        user_id,
        text,
        random_id,
        media_id,
        extras,
        i64::from(schedule_date),
    )
    .await
    .map_err(RpcFailure::internal)?;
    let media_bytes = match media {
        Some(record) => Some(media_bytes(ctx, record, Some(user_id)).await?),
        None => None,
    };
    let message = match chat.kind.as_str() {
        "private" => {
            let (a, b) = private_pair(&chat)?;
            let other_id = if user_id == a { b } else { a };
            private_message_record(&record, true, other_id, media_bytes.as_deref(), 0, None)
        }
        "basic_group" => {
            chat_message_or_service(&record, true, chat.id, media_bytes.as_deref(), 0, None)
        }
        _ => channel_message_record(&record, true, chat.id, media_bytes.as_deref(), 0, None),
    };
    let chats = if chat.kind == "private" {
        Vec::new()
    } else {
        let channel = repo::find_channel(ctx.db, chat.id)
            .await
            .map_err(RpcFailure::internal)?
            .ok_or_else(|| RpcFailure::new(400, "CHAT_ID_INVALID"))?;
        vec![if chat.kind == "basic_group" {
            chat_record_bytes(&channel, user_id)
        } else {
            channel_bytes(&channel, user_id)
        }]
    };
    let response = types::updates_with_chats(
        &[
            types::update_message_id(record.id as i32, random_id),
            types::update_new_scheduled_message(&message),
        ],
        &[],
        &chats,
        now() as i32,
        0,
    );
    ctx.updates
        .publish_excluding(user_id, Some(ctx.session_id), response.clone());
    Ok(response)
}

async fn deliver_existing_record(
    ctx: &RpcContext<'_>,
    record: &repo::MessageRecord,
) -> Result<(Vec<u8>, i32), RpcFailure> {
    let Some(chat) = repo::find_chat(ctx.db, record.chat_id)
        .await
        .map_err(RpcFailure::internal)?
    else {
        return Err(RpcFailure::new(400, "CHAT_ID_INVALID"));
    };
    let media = load_media_bytes(ctx, record.media_id).await?;
    let pinned_id = repo::pinned_message_id(ctx.db, chat.id)
        .await
        .map_err(RpcFailure::internal)?;
    let sender_id = record.sender_user_id;
    let Some(sender) = repo::find_user_by_id(ctx.db, sender_id)
        .await
        .map_err(RpcFailure::internal)?
    else {
        return Err(RpcFailure::new(400, "USER_ID_INVALID"));
    };
    let timestamp = record.sent_at as i32;
    if chat.kind == "private" {
        let (a, b) = private_pair(&chat)?;
        let a_pts = repo::bump_user_pts(ctx.db, a)
            .await
            .map_err(RpcFailure::internal)?;
        let b_pts = repo::bump_user_pts(ctx.db, b)
            .await
            .map_err(RpcFailure::internal)?;
        let a_out = sender_id == a;
        let a_reactions = message_reactions_bytes(ctx, record.id, a).await?;
        let b_reactions = message_reactions_bytes(ctx, record.id, b).await?;
        let a_message = private_message_record(
            record,
            a_out,
            b,
            media.as_deref(),
            pinned_id,
            a_reactions.as_deref(),
        );
        let b_message = private_message_record(
            record,
            !a_out,
            a,
            media.as_deref(),
            pinned_id,
            b_reactions.as_deref(),
        );
        let a_update = types::update_new_message(&a_message, a_pts);
        let b_update = types::update_new_message(&b_message, b_pts);
        repo::log_user_update(ctx.db, a, a_pts, &a_update)
            .await
            .map_err(RpcFailure::internal)?;
        repo::log_user_update(ctx.db, b, b_pts, &b_update)
            .await
            .map_err(RpcFailure::internal)?;
        let (sender_message, sender_pts) = if a_out {
            (a_message, a_pts)
        } else {
            (b_message, b_pts)
        };
        let a_push = types::updates(&[a_update], &[], timestamp, 0);
        let b_push = types::updates(&[b_update], &[], timestamp, 0);
        ctx.updates.publish_excluding(
            sender_id,
            Some(ctx.session_id),
            if a_out {
                a_push.clone()
            } else {
                b_push.clone()
            },
        );
        ctx.updates.publish(
            if a_out { b } else { a },
            if a_out { b_push } else { a_push },
        );
        return Ok((sender_message, sender_pts));
    }
    if chat.kind == "basic_group" {
        let Some(channel) = repo::find_channel(ctx.db, chat.id)
            .await
            .map_err(RpcFailure::internal)?
        else {
            return Err(RpcFailure::new(400, "CHAT_ID_INVALID"));
        };
        let (message, _response, pts) =
            deliver_basic_group_message(ctx, &channel, record, &sender, media.as_deref(), None)
                .await?;
        return Ok((message, pts));
    }
    let Some(channel) = repo::find_channel(ctx.db, chat.id)
        .await
        .map_err(RpcFailure::internal)?
    else {
        return Err(RpcFailure::new(400, "CHANNEL_INVALID"));
    };
    let pts = repo::bump_channel_pts(ctx.db, chat.id)
        .await
        .map_err(RpcFailure::internal)?;
    let sender_reactions = message_reactions_bytes(ctx, record.id, sender_id).await?;
    let sender_message = channel_message_record(
        record,
        true,
        chat.id,
        media.as_deref(),
        pinned_id,
        sender_reactions.as_deref(),
    );
    let member_message =
        channel_message_record(record, false, chat.id, media.as_deref(), pinned_id, None);
    let channel_update = types::update_new_channel_message(&member_message, pts);
    repo::log_channel_update(ctx.db, chat.id, pts, &channel_update)
        .await
        .map_err(RpcFailure::internal)?;
    for member_id in repo::chat_member_ids(ctx.db, chat.id)
        .await
        .map_err(RpcFailure::internal)?
    {
        if member_id == sender_id {
            let push = types::updates_with_chats(
                &[types::update_new_channel_message(&sender_message, pts)],
                &[user_bytes(sender.clone())],
                &[channel_bytes(&channel, member_id)],
                timestamp,
                0,
            );
            ctx.updates
                .publish_excluding(member_id, Some(ctx.session_id), push);
        } else {
            let reactions = message_reactions_bytes(ctx, record.id, member_id).await?;
            let member_view = channel_message_record(
                record,
                false,
                chat.id,
                media.as_deref(),
                pinned_id,
                reactions.as_deref(),
            );
            let push = types::updates_with_chats(
                &[types::update_new_channel_message(&member_view, pts)],
                &[other_user_bytes(&sender)],
                &[channel_bytes(&channel, member_id)],
                timestamp,
                0,
            );
            ctx.updates.publish(member_id, push);
        }
    }
    Ok((sender_message, pts))
}

async fn messages_get_scheduled_history(
    ctx: &RpcContext<'_>,
    reader: &mut Reader<'_>,
) -> Result<Vec<u8>, RpcFailure> {
    let peer = read_input_peer(ctx, reader)?;
    let _hash = reader.i64()?;
    let Some(user_id) = ctx.user_id else {
        return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
    };
    let chat = match peer {
        PeerRef::User(peer_id) => {
            let Some(chat_id) = repo::find_private_chat(ctx.db, user_id, peer_id)
                .await
                .map_err(RpcFailure::internal)?
            else {
                return Ok(types::messages_messages(&[], &[], &[]));
            };
            repo::find_chat(ctx.db, chat_id)
                .await
                .map_err(RpcFailure::internal)?
                .ok_or_else(|| RpcFailure::new(400, "PEER_ID_INVALID"))?
        }
        _ => resolve_peer_chat(ctx, peer, user_id, false).await?,
    };
    let records = repo::list_scheduled_messages(ctx.db, chat.id, user_id)
        .await
        .map_err(RpcFailure::internal)?;
    let mut messages = Vec::with_capacity(records.len());
    for record in &records {
        let media = load_media_bytes(ctx, record.media_id).await?;
        messages.push(match chat.kind.as_str() {
            "private" => {
                let (a, b) = private_pair(&chat)?;
                let other_id = if user_id == a { b } else { a };
                private_message_record(record, true, other_id, media.as_deref(), 0, None)
            }
            "basic_group" => {
                chat_message_or_service(record, true, chat.id, media.as_deref(), 0, None)
            }
            _ => channel_message_record(record, true, chat.id, media.as_deref(), 0, None),
        });
    }
    let (chats, users) = if chat.kind == "private" {
        let (_, b) = private_pair(&chat)?;
        let other_id = if user_id == chat.private_user_a.unwrap_or(user_id) {
            b
        } else {
            chat.private_user_a.unwrap_or(b)
        };
        let users = repo::find_user_by_id(ctx.db, other_id)
            .await
            .map_err(RpcFailure::internal)?
            .map(|user| vec![other_user_bytes(&user)])
            .unwrap_or_default();
        (Vec::new(), users)
    } else {
        let channel = repo::find_channel(ctx.db, chat.id)
            .await
            .map_err(RpcFailure::internal)?
            .ok_or_else(|| RpcFailure::new(400, "CHAT_ID_INVALID"))?;
        let chats = vec![if chat.kind == "basic_group" {
            chat_record_bytes(&channel, user_id)
        } else {
            channel_bytes(&channel, user_id)
        }];
        (chats, Vec::new())
    };
    Ok(types::messages_messages(&messages, &chats, &users))
}

async fn messages_send_scheduled_messages(
    ctx: &RpcContext<'_>,
    reader: &mut Reader<'_>,
) -> Result<Vec<u8>, RpcFailure> {
    let peer = read_input_peer(ctx, reader)?;
    let ids = reader.vector(|reader| reader.i32())?;
    let Some(user_id) = ctx.user_id else {
        return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
    };
    let chat = resolve_peer_chat(ctx, peer, user_id, true).await?;
    let mut response_updates = Vec::new();
    let mut sent = Vec::new();
    for id in ids {
        let message_id = i64::from(id);
        let Some(record) = repo::find_message(ctx.db, message_id)
            .await
            .map_err(RpcFailure::internal)?
        else {
            continue;
        };
        if record.chat_id != chat.id || record.scheduled_date <= 0 {
            continue;
        }
        if record.sender_user_id != user_id {
            continue;
        }
        let Some(record) = repo::activate_scheduled_message(ctx.db, message_id)
            .await
            .map_err(RpcFailure::internal)?
        else {
            continue;
        };
        let (message, pts) = deliver_existing_record(ctx, &record).await?;
        response_updates.push(types::update_new_message(&message, pts));
        sent.push(record.id as i32);
    }
    if sent.is_empty() {
        return Ok(types::updates(&[], &[], now() as i32, 0));
    }
    let (peer_bytes, chats) = scheduled_peer_bytes(ctx, &chat, user_id).await?;
    response_updates.push(types::update_delete_scheduled_messages(
        &peer_bytes,
        &sent,
        Some(&sent),
    ));
    let response = types::updates_with_chats(&response_updates, &[], &chats, now() as i32, 0);
    ctx.updates
        .publish_excluding(user_id, Some(ctx.session_id), response.clone());
    Ok(response)
}

async fn messages_delete_scheduled_messages(
    ctx: &RpcContext<'_>,
    reader: &mut Reader<'_>,
) -> Result<Vec<u8>, RpcFailure> {
    let peer = read_input_peer(ctx, reader)?;
    let ids = reader.vector(|reader| reader.i32())?;
    let Some(user_id) = ctx.user_id else {
        return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
    };
    let chat = resolve_peer_chat(ctx, peer, user_id, true).await?;
    let ids: Vec<i64> = ids.into_iter().map(i64::from).collect();
    let deleted = repo::delete_scheduled_messages(ctx.db, chat.id, user_id, &ids)
        .await
        .map_err(RpcFailure::internal)?;
    let deleted_ids: Vec<i32> = deleted.iter().map(|record| record.id as i32).collect();
    let (peer_bytes, chats) = scheduled_peer_bytes(ctx, &chat, user_id).await?;
    let update = types::update_delete_scheduled_messages(&peer_bytes, &deleted_ids, None);
    let response =
        types::updates_with_chats(std::slice::from_ref(&update), &[], &chats, now() as i32, 0);
    ctx.updates
        .publish_excluding(user_id, Some(ctx.session_id), response.clone());
    Ok(response)
}

async fn scheduled_peer_bytes(
    ctx: &RpcContext<'_>,
    chat: &repo::ChatInfo,
    user_id: i64,
) -> Result<(Vec<u8>, Vec<Vec<u8>>), RpcFailure> {
    if chat.kind == "private" {
        let (a, b) = private_pair(chat)?;
        let other_id = if user_id == a { b } else { a };
        return Ok((types::peer_user(other_id), Vec::new()));
    }
    let channel = repo::find_channel(ctx.db, chat.id)
        .await
        .map_err(RpcFailure::internal)?
        .ok_or_else(|| RpcFailure::new(400, "CHAT_ID_INVALID"))?;
    if chat.kind == "basic_group" {
        Ok((
            types::peer_chat(chat.id),
            vec![chat_record_bytes(&channel, user_id)],
        ))
    } else {
        Ok((
            types::peer_channel(chat.id),
            vec![channel_bytes(&channel, user_id)],
        ))
    }
}

pub async fn deliver_due_scheduled(
    state: &crate::mtproto_listener::AppState,
) -> Result<(), RpcFailure> {
    let ids = repo::due_scheduled_message_ids(&state.db, now() as i64)
        .await
        .map_err(RpcFailure::internal)?;
    for id in ids {
        let Some(record) = repo::activate_scheduled_message(&state.db, id)
            .await
            .map_err(RpcFailure::internal)?
        else {
            continue;
        };
        let ctx = RpcContext {
            db: &state.db,
            cache: &state.cache,
            config: &state.config,
            langpacks: &state.langpacks,
            updates: &state.updates,
            auth_key_id: 0,
            session_id: 0,
            user_id: Some(record.sender_user_id),
            layer: 232,
            peer: String::new(),
            client: ClientInfo {
                api_id: 0,
                device_model: String::new(),
                system_version: String::new(),
                app_version: String::new(),
                lang_code: String::new(),
            },
        };
        deliver_existing_record(&ctx, &record).await?;
        tracing::info!(message_id = record.id, "scheduled message sent");
    }
    Ok(())
}

async fn messages_set_typing(
    ctx: &RpcContext<'_>,
    reader: &mut Reader<'_>,
) -> Result<Vec<u8>, RpcFailure> {
    let flags = reader.u32()?;
    let peer = read_input_peer(ctx, reader)?;
    let top_msg_id = if flags & 1 != 0 {
        Some(reader.i32()?)
    } else {
        None
    };
    let action_ctor = reader.constructor()?;
    // Upload actions carry a progress value; the remaining typing actions are
    // either payload-free or carry data we do not forward. Unknown actions are
    // ignored so a newer client cannot break the RPC.
    let progress = match action_ctor {
        ctor::SEND_MESSAGE_UPLOAD_VIDEO_ACTION
        | ctor::SEND_MESSAGE_UPLOAD_AUDIO_ACTION
        | ctor::SEND_MESSAGE_UPLOAD_PHOTO_ACTION
        | ctor::SEND_MESSAGE_UPLOAD_DOCUMENT_ACTION
        | ctor::SEND_MESSAGE_UPLOAD_ROUND_ACTION => Some(reader.i32()?),
        ctor::SEND_MESSAGE_TYPING_ACTION
        | ctor::SEND_MESSAGE_CANCEL_ACTION
        | ctor::SEND_MESSAGE_RECORD_VIDEO_ACTION
        | ctor::SEND_MESSAGE_RECORD_AUDIO_ACTION
        | ctor::SEND_MESSAGE_RECORD_ROUND_ACTION
        | ctor::SEND_MESSAGE_GEO_LOCATION_ACTION
        | ctor::SEND_MESSAGE_CHOOSE_CONTACT_ACTION
        | ctor::SEND_MESSAGE_GAME_PLAY_ACTION
        | ctor::SEND_MESSAGE_CHOOSE_STICKER_ACTION
        | ctor::SPEAKING_IN_GROUP_CALL_ACTION => None,
        _ => return Ok(types::bool_true()),
    };
    let Some(user_id) = ctx.user_id else {
        return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
    };
    let Some(sender) = ctx_user(ctx).await? else {
        return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
    };
    let action = types::send_message_action(action_ctor, progress);
    let sender_bytes = other_user_bytes(&sender);
    match peer {
        PeerRef::User(peer_id) => {
            if peer_id == user_id {
                return Ok(types::bool_true());
            }
            let update = types::update_user_typing(user_id, top_msg_id, &action);
            let push = types::updates(&[update], &[sender_bytes], now() as i32, 0);
            ctx.updates.publish(peer_id, push.clone());
            ctx.updates
                .publish_excluding(user_id, Some(ctx.session_id), push);
        }
        PeerRef::Chat(chat_id) => {
            let members = repo::chat_member_ids(ctx.db, chat_id)
                .await
                .map_err(RpcFailure::internal)?;
            if !members.contains(&user_id) {
                return Ok(types::bool_true());
            }
            let update = types::update_chat_user_typing(
                chat_id,
                &types::peer_user(user_id),
                &action,
            );
            let push = types::updates(&[update], &[sender_bytes], now() as i32, 0);
            for member in members {
                if member != user_id {
                    ctx.updates.publish(member, push.clone());
                }
            }
        }
        PeerRef::Channel { id, .. } => {
            let Some(channel) = repo::find_channel(ctx.db, id)
                .await
                .map_err(RpcFailure::internal)?
            else {
                return Err(RpcFailure::new(400, "CHANNEL_INVALID"));
            };
            let members = repo::chat_member_ids(ctx.db, channel.id)
                .await
                .map_err(RpcFailure::internal)?;
            if !members.contains(&user_id) {
                return Ok(types::bool_true());
            }
            let update = types::update_channel_user_typing(
                channel.id,
                top_msg_id,
                &types::peer_user(user_id),
                &action,
            );
            let push = types::updates_with_chats(
                &[update],
                &[sender_bytes],
                &[chat_record_bytes(&channel, user_id)],
                now() as i32,
                0,
            );
            for member in members {
                if member != user_id {
                    ctx.updates.publish(member, push.clone());
                }
            }
        }
    }
    Ok(types::bool_true())
}

async fn messages_read_history(
    ctx: &RpcContext<'_>,
    reader: &mut Reader<'_>,
) -> Result<Vec<u8>, RpcFailure> {
    let peer = read_input_peer(ctx, reader)?;
    let max_id = reader.i32()?;
    let Some(user_id) = ctx.user_id else {
        return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
    };
    match peer {
        PeerRef::User(peer_id) => {
            let Some(chat_id) = repo::find_private_chat(ctx.db, user_id, peer_id)
                .await
                .map_err(RpcFailure::internal)?
            else {
                return Ok(types::messages_affected_messages(user_pts(ctx).await?, 0));
            };
            repo::read_history(ctx.db, user_id, chat_id, i64::from(max_id))
                .await
                .map_err(RpcFailure::internal)?;

            // Sync the reader's other devices and bump the reader's PTS.
            let my_pts = repo::bump_user_pts(ctx.db, user_id)
                .await
                .map_err(RpcFailure::internal)?;
            let outbox = types::update_read_history_outbox(
                &types::peer_user(peer_id),
                max_id,
                my_pts,
                1,
            );
            repo::log_user_update(ctx.db, user_id, my_pts, &outbox)
                .await
                .map_err(RpcFailure::internal)?;
            let outbox_push = types::updates(&[outbox], &[], now() as i32, 0);
            ctx.updates
                .publish_excluding(user_id, Some(ctx.session_id), outbox_push);

            // Tell the peer that their messages were read.
            if let Some(peer_user) = repo::find_user_by_id(ctx.db, peer_id)
                .await
                .map_err(RpcFailure::internal)?
            {
                let peer_pts = repo::bump_user_pts(ctx.db, peer_id)
                    .await
                    .map_err(RpcFailure::internal)?;
                let inbox = types::update_read_history_inbox(
                    &types::peer_user(user_id),
                    max_id,
                    0,
                    peer_pts,
                    1,
                );
                repo::log_user_update(ctx.db, peer_id, peer_pts, &inbox)
                    .await
                    .map_err(RpcFailure::internal)?;
                ctx.updates.publish(
                    peer_id,
                    types::updates(&[inbox], &[other_user_bytes(&peer_user)], now() as i32, 0),
                );
            }
            Ok(types::messages_affected_messages(my_pts, 1))
        }
        PeerRef::Channel { id, .. } => {
            let Some(channel) = repo::find_channel(ctx.db, id)
                .await
                .map_err(RpcFailure::internal)?
            else {
                return Err(RpcFailure::new(400, "CHANNEL_INVALID"));
            };
            repo::read_history(ctx.db, user_id, channel.id, i64::from(max_id))
                .await
                .map_err(RpcFailure::internal)?;
            let pts = repo::channel_pts(ctx.db, channel.id)
                .await
                .map_err(RpcFailure::internal)?;
            // Channel reads stay out of the channel PTS stream; only the reader's
            // other sessions need the outbox update.
            let outbox = types::update_read_channel_outbox(channel.id, max_id);
            let push = types::updates(&[outbox], &[], now() as i32, 0);
            ctx.updates
                .publish_excluding(user_id, Some(ctx.session_id), push);
            Ok(types::messages_affected_messages(pts, 0))
        }
        PeerRef::Chat(id) => {
            let Some(chat) = repo::find_channel(ctx.db, id)
                .await
                .map_err(RpcFailure::internal)?
            else {
                return Err(RpcFailure::new(400, "CHAT_ID_INVALID"));
            };
            if chat.kind != "basic_group" {
                return Err(RpcFailure::new(400, "CHAT_ID_INVALID"));
            }
            repo::read_history(ctx.db, user_id, chat.id, i64::from(max_id))
                .await
                .map_err(RpcFailure::internal)?;
            let my_pts = repo::bump_user_pts(ctx.db, user_id)
                .await
                .map_err(RpcFailure::internal)?;
            let peer_chat = types::peer_chat(chat.id);
            let outbox =
                types::update_read_history_outbox(&peer_chat, max_id, my_pts, 1);
            repo::log_user_update(ctx.db, user_id, my_pts, &outbox)
                .await
                .map_err(RpcFailure::internal)?;
            let outbox_push = types::updates_with_chats(
                &[outbox],
                &[],
                &[chat_record_bytes(&chat, user_id)],
                now() as i32,
                0,
            );
            ctx.updates
                .publish_excluding(user_id, Some(ctx.session_id), outbox_push);

            let members = repo::chat_member_ids(ctx.db, chat.id)
                .await
                .map_err(RpcFailure::internal)?;
            for member in members {
                if member == user_id {
                    continue;
                }
                let member_pts = repo::bump_user_pts(ctx.db, member)
                    .await
                    .map_err(RpcFailure::internal)?;
                let inbox = types::update_read_history_inbox(
                    &peer_chat,
                    max_id,
                    0,
                    member_pts,
                    1,
                );
                repo::log_user_update(ctx.db, member, member_pts, &inbox)
                    .await
                    .map_err(RpcFailure::internal)?;
                ctx.updates.publish(
                    member,
                    types::updates_with_chats(
                        &[inbox],
                        &[],
                        &[chat_record_bytes(&chat, member)],
                        now() as i32,
                        0,
                    ),
                );
            }
            Ok(types::messages_affected_messages(my_pts, 1))
        }
    }
}

async fn updates_get_state(ctx: &RpcContext<'_>) -> Result<Vec<u8>, RpcFailure> {
    let pts = user_pts(ctx).await?;
    let unread_count = match ctx.user_id {
        Some(user_id) => repo::total_unread(ctx.db, user_id)
            .await
            .map_err(RpcFailure::internal)?,
        None => 0,
    };
    // Push the current user object once per state request so clients refresh
    // cached flags (e.g. Premium) instead of keeping the values they stored at
    // the original login.
    if let Some(user) = ctx_user(ctx).await? {
        let push = types::updates(
            &[types::update_user(user.id)],
            &[user_bytes(user)],
            now() as i32,
            0,
        );
        ctx.updates.publish(ctx.user_id.unwrap_or(0), push);
    }
    Ok(types::updates_state(pts, 0, now() as i32, 0, unread_count))
}

async fn updates_get_difference(
    ctx: &RpcContext<'_>,
    reader: &mut Reader<'_>,
) -> Result<Vec<u8>, RpcFailure> {
    let flags = reader.u32()?;
    let pts = reader.i32()?;
    let pts_limit = if flags & (1 << 1) != 0 {
        Some(reader.i32()?)
    } else {
        None
    };
    if flags & (1 << 0) != 0 {
        let _pts_total_limit = reader.i32()?;
    }
    let _date = reader.i32()?;
    let _qts = reader.i32()?;
    if flags & (1 << 2) != 0 {
        let _qts_limit = reader.i32()?;
    }
    let Some(user_id) = ctx.user_id else {
        return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
    };
    let current_pts = repo::user_pts(ctx.db, user_id)
        .await
        .map_err(RpcFailure::internal)?;
    let unread_count = repo::total_unread(ctx.db, user_id)
        .await
        .map_err(RpcFailure::internal)?;
    if pts >= current_pts {
        return Ok(types::updates_difference_empty(now() as i32, 0));
    }
    if let Some(oldest) = repo::oldest_user_update_pts(ctx.db, user_id)
        .await
        .map_err(RpcFailure::internal)?
    {
        if oldest > i64::from(pts) + 1 {
            return Ok(types::updates_difference_too_long(current_pts));
        }
    }
    let limit = i64::from(pts_limit.unwrap_or(1000).clamp(1, 1000));
    let mut logged = repo::user_updates_after(ctx.db, user_id, i64::from(pts), limit + 1)
        .await
        .map_err(RpcFailure::internal)?;
    if logged.is_empty() {
        return Ok(types::updates_difference_too_long(current_pts));
    }
    let intermediate = logged.len() as i64 > limit;
    if intermediate {
        logged.truncate(limit as usize);
    }
    let other_updates: Vec<Vec<u8>> = logged.iter().map(|entry| entry.data.clone()).collect();
    let (new_messages, other_updates) = split_new_message_updates(&other_updates);
    let (_, _, chats, users) = load_dialogs(ctx).await?;
    if intermediate {
        let last_pts = logged
            .last()
            .map(|entry| entry.pts as i32)
            .unwrap_or(current_pts);
        let state = types::updates_state(last_pts, 0, now() as i32, 0, unread_count);
        Ok(types::updates_difference_slice(
            &new_messages,
            &other_updates,
            &chats,
            &users,
            &state,
        ))
    } else {
        let state = types::updates_state(current_pts, 0, now() as i32, 0, unread_count);
        Ok(types::updates_difference(
            &new_messages,
            &other_updates,
            &chats,
            &users,
            &state,
        ))
    }
}

/// Splits `updateNewMessage` / `updateNewChannelMessage` entries into the
/// `new_messages` vector expected by `updates.difference`.
fn split_new_message_updates(updates: &[Vec<u8>]) -> (Vec<Vec<u8>>, Vec<Vec<u8>>) {
    let mut new_messages = Vec::new();
    let mut other_updates = Vec::new();
    for update in updates {
        let constructor = update
            .get(..4)
            .and_then(|bytes| bytes.try_into().ok())
            .map(u32::from_le_bytes);
        let is_new_message = matches!(
            constructor,
            Some(ctor::UPDATE_NEW_MESSAGE) | Some(ctor::UPDATE_NEW_CHANNEL_MESSAGE)
        );
        if is_new_message && update.len() >= 12 {
            new_messages.push(update[4..update.len() - 8].to_vec());
        } else {
            other_updates.push(update.clone());
        }
    }
    (new_messages, other_updates)
}

async fn updates_get_channel_difference(
    ctx: &RpcContext<'_>,
    reader: &mut Reader<'_>,
) -> Result<Vec<u8>, RpcFailure> {
    let flags = reader.u32()?;
    let _force = flags & 1 != 0;
    let (channel_id, access_hash) = read_input_channel(reader)?;
    skip_channel_messages_filter(reader)?;
    let pts = reader.i32()?;
    let limit = reader.i32()?.clamp(1, 1000);
    let Some(user_id) = ctx.user_id else {
        return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
    };
    let Some(channel) = repo::find_channel(ctx.db, channel_id)
        .await
        .map_err(RpcFailure::internal)?
    else {
        return Err(RpcFailure::new(400, "CHANNEL_INVALID"));
    };
    if channel.access_hash != 0 && channel.access_hash != access_hash {
        return Err(RpcFailure::new(400, "CHANNEL_INVALID"));
    }
    if repo::channel_membership(ctx.db, channel.id, user_id)
        .await
        .map_err(RpcFailure::internal)?
        .is_none()
    {
        return Err(RpcFailure::new(403, "CHANNEL_PRIVATE"));
    }
    let current_pts = repo::channel_pts(ctx.db, channel.id)
        .await
        .map_err(RpcFailure::internal)?;
    if pts >= current_pts {
        return Ok(types::updates_channel_difference_empty(current_pts, 0));
    }
    // The client's pts is older than the retained log, so the missing updates
    // cannot be replayed: answer with a full dialog snapshot instead.
    if let Some(oldest) = repo::channel_oldest_update_pts(ctx.db, channel.id)
        .await
        .map_err(RpcFailure::internal)?
    {
        if i64::from(pts) + 1 < oldest {
            let mut records = repo::history(ctx.db, channel.id, limit)
                .await
                .map_err(RpcFailure::internal)?;
            records.reverse();
            let mut messages = Vec::with_capacity(records.len());
            for record in &records {
                let media = load_media_bytes(ctx, record.media_id).await?;
                let reactions = message_reactions_bytes(ctx, record.id, user_id).await?;
                messages.push(channel_message_record(
                    record,
                    record.sender_user_id == user_id,
                    channel.id,
                    media.as_deref(),
                    0,
                    reactions.as_deref(),
                ));
            }
            let peer = types::peer_channel(channel.id);
            let dialog = types::dialog_ext(&peer, current_pts, 0, false);
            let chats = vec![channel_bytes(&channel, user_id)];
            return Ok(types::updates_channel_difference_too_long(
                true, None, &dialog, &messages, &chats, &[],
            ));
        }
    }
    let mut logged =
        repo::channel_updates_after(ctx.db, channel.id, i64::from(pts), i64::from(limit) + 1)
            .await
            .map_err(RpcFailure::internal)?;
    if logged.is_empty() {
        return Ok(types::updates_channel_difference_empty(current_pts, 0));
    }
    let final_difference = logged.len() <= limit as usize;
    if !final_difference {
        logged.truncate(limit as usize);
    }
    let result_pts = if final_difference {
        current_pts
    } else {
        logged
            .last()
            .map(|entry| entry.pts as i32)
            .unwrap_or(current_pts)
    };
    let mut other_updates: Vec<Vec<u8>> = logged.iter().map(|entry| entry.data.clone()).collect();
    for update in &mut other_updates {
        patch_channel_message_out(update, user_id);
    }
    let (new_messages, other_updates) = split_new_message_updates(&other_updates);
    let chats = vec![channel_bytes(&channel, user_id)];
    Ok(types::updates_channel_difference(
        final_difference,
        result_pts,
        None,
        &new_messages,
        &other_updates,
        &chats,
        &[],
    ))
}

/// The channel update log stores one copy per channel, but the `out` flag of
/// the message is receiver-specific. When replaying a channel difference, mark
/// messages authored by the requesting user as outgoing again, otherwise the
/// user's own channel posts would jump to the incoming (left) side.
fn patch_channel_message_out(update: &mut [u8], viewer_user_id: i64) {
    if update.len() < 32 {
        return;
    }
    let constructor = u32::from_le_bytes(update[0..4].try_into().expect("four bytes"));
    if constructor != ctor::UPDATE_NEW_CHANNEL_MESSAGE
        && constructor != ctor::UPDATE_EDIT_CHANNEL_MESSAGE
    {
        return;
    }
    let message_constructor = u32::from_le_bytes(update[4..8].try_into().expect("four bytes"));
    if message_constructor != ctor::MESSAGE {
        return;
    }
    let flags = u32::from_le_bytes(update[8..12].try_into().expect("four bytes"));
    if flags & (1 << 8) == 0 {
        return;
    }
    let from_constructor = u32::from_le_bytes(update[20..24].try_into().expect("four bytes"));
    if from_constructor != ctor::PEER_USER {
        return;
    }
    let from_user_id = i64::from_le_bytes(update[24..32].try_into().expect("eight bytes"));
    if from_user_id != viewer_user_id {
        return;
    }
    let patched = flags | (1 << 1);
    update[8..12].copy_from_slice(&patched.to_le_bytes());
}

fn skip_channel_messages_filter(reader: &mut Reader<'_>) -> Result<(), RpcFailure> {
    match reader.constructor()? {
        0x94d4_2ee7 => Ok(()),
        0xcd77_d957 => {
            let _flags = reader.u32()?;
            reader.expect_constructor(ctor::VECTOR)?;
            let count = reader.i32()?.max(0) as usize;
            for _ in 0..count {
                if reader.constructor()? != 0x0ae3_0253 {
                    return Err(RpcFailure::new(400, "FILTER_INVALID"));
                }
                let _min_id = reader.i32()?;
                let _max_id = reader.i32()?;
            }
            Ok(())
        }
        other => Err(RpcFailure::new(
            400,
            format!("UNSUPPORTED_CHANNEL_FILTER_0x{other:08X}"),
        )),
    }
}

const FILE_DC_ID: i32 = 2;

fn private_pair(chat: &repo::ChatInfo) -> Result<(i64, i64), RpcFailure> {
    match (chat.private_user_a, chat.private_user_b) {
        (Some(a), Some(b)) => Ok((a, b)),
        _ => Err(RpcFailure::new(400, "PEER_ID_INVALID")),
    }
}

fn private_pair_contains(chat: &repo::ChatInfo, user_id: i64) -> bool {
    chat.private_user_a == Some(user_id) || chat.private_user_b == Some(user_id)
}

async fn resolve_peer_chat(
    ctx: &RpcContext<'_>,
    peer: PeerRef,
    user_id: i64,
    require_write: bool,
) -> Result<repo::ChatInfo, RpcFailure> {
    match peer {
        PeerRef::User(peer_id) => {
            if peer_id == user_id {
                return Err(RpcFailure::new(400, "PEER_ID_INVALID"));
            }
            let Some(chat_id) = repo::find_private_chat(ctx.db, user_id, peer_id)
                .await
                .map_err(RpcFailure::internal)?
            else {
                return Err(RpcFailure::new(400, "PEER_ID_INVALID"));
            };
            repo::find_chat(ctx.db, chat_id)
                .await
                .map_err(RpcFailure::internal)?
                .ok_or_else(|| RpcFailure::new(400, "PEER_ID_INVALID"))
        }
        PeerRef::Channel { id, access_hash } => {
            let Some(channel) = repo::find_channel(ctx.db, id)
                .await
                .map_err(RpcFailure::internal)?
            else {
                return Err(RpcFailure::new(400, "CHANNEL_INVALID"));
            };
            if channel.access_hash != 0 && channel.access_hash != access_hash {
                return Err(RpcFailure::new(400, "CHANNEL_INVALID"));
            }
            if repo::channel_membership(ctx.db, channel.id, user_id)
                .await
                .map_err(RpcFailure::internal)?
                .is_none()
            {
                return Err(RpcFailure::new(403, "CHANNEL_PRIVATE"));
            }
            if require_write && channel.kind == "channel" && channel.owner_user_id != user_id {
                return Err(RpcFailure::new(403, "CHAT_WRITE_FORBIDDEN"));
            }
            repo::find_chat(ctx.db, channel.id)
                .await
                .map_err(RpcFailure::internal)?
                .ok_or_else(|| RpcFailure::new(400, "CHANNEL_INVALID"))
        }
        PeerRef::Chat(id) => {
            let Some(chat) = repo::find_channel(ctx.db, id)
                .await
                .map_err(RpcFailure::internal)?
            else {
                return Err(RpcFailure::new(400, "CHAT_ID_INVALID"));
            };
            if chat.kind != "basic_group" {
                return Err(RpcFailure::new(400, "CHAT_ID_INVALID"));
            }
            if repo::channel_membership(ctx.db, chat.id, user_id)
                .await
                .map_err(RpcFailure::internal)?
                .is_none()
            {
                return Err(RpcFailure::new(403, "CHAT_PRIVATE"));
            }
            let _ = require_write;
            repo::find_chat(ctx.db, chat.id)
                .await
                .map_err(RpcFailure::internal)?
                .ok_or_else(|| RpcFailure::new(400, "CHAT_ID_INVALID"))
        }
    }
}

async fn messages_edit_message(
    ctx: &RpcContext<'_>,
    reader: &mut Reader<'_>,
) -> Result<Vec<u8>, RpcFailure> {
    let flags = reader.u32()?;
    let peer = read_input_peer(ctx, reader)?;
    let id = i64::from(reader.i32()?);
    if flags & (1 << 11) == 0 {
        return Err(RpcFailure::new(400, "MESSAGE_EMPTY"));
    }
    let text = reader.string()?;
    if text.chars().count() > 4096 {
        return Err(RpcFailure::new(400, "MESSAGE_TOO_LONG"));
    }
    let edit_media = if flags & (1 << 14) != 0 {
        Some(read_input_media(reader)?)
    } else {
        None
    };
    if flags & (1 << 2) != 0 {
        return Err(RpcFailure::new(400, "REPLY_MARKUP_UNSUPPORTED"));
    }
    let entities = if flags & (1 << 3) != 0 {
        read_message_entities(reader, &text)?
    } else {
        Vec::new()
    };
    let Some(user_id) = ctx.user_id else {
        return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
    };
    let Some(record) = repo::find_message(ctx.db, id)
        .await
        .map_err(RpcFailure::internal)?
    else {
        return Err(RpcFailure::new(400, "MESSAGE_ID_INVALID"));
    };
    if !record.action_kind.is_empty() {
        return Err(RpcFailure::new(400, "MESSAGE_ID_INVALID"));
    }
    let chat = resolve_peer_chat(ctx, peer, user_id, true).await?;
    if record.chat_id != chat.id {
        return Err(RpcFailure::new(400, "MESSAGE_ID_INVALID"));
    }
    let owner = chat.owner_user_id == Some(user_id);
    if record.sender_user_id != user_id && !owner {
        return Err(RpcFailure::new(403, "MESSAGE_AUTHOR_REQUIRED"));
    }
    apply_message_edit(ctx, user_id, chat, record, &text, edit_media, Some(&entities)).await
}

/// Shared edit implementation used by the client RPC above and the admin
/// panel, so PTS, update_log and online pushes stay identical.
async fn apply_message_edit(
    ctx: &RpcContext<'_>,
    user_id: i64,
    chat: repo::ChatInfo,
    record: repo::MessageRecord,
    text: &str,
    edit_media: Option<InputMediaRef>,
    edit_entities: Option<&[Vec<u8>]>,
) -> Result<Vec<u8>, RpcFailure> {
    let mut record = record;
    if let Some(input) = edit_media {
        let new_media_id = materialize_input_media(ctx, user_id, input)
            .await?
            .map(|media| media.id);
        record = repo::set_message_media(ctx.db, record.id, new_media_id, now() as i64)
            .await
            .map_err(RpcFailure::internal)?;
    }
    let pinned_id = repo::pinned_message_id(ctx.db, chat.id)
        .await
        .map_err(RpcFailure::internal)?;
    let updated = repo::update_message_text(ctx.db, record.id, text, edit_entities, now() as i64)
        .await
        .map_err(RpcFailure::internal)?;
    let media = load_media_bytes(ctx, updated.media_id).await?;
    let edited_at = now() as i32;

    if chat.kind == "private" {
        let (a, b) = private_pair(&chat)?;
        let a_pts = repo::bump_user_pts(ctx.db, a)
            .await
            .map_err(RpcFailure::internal)?;
        let b_pts = repo::bump_user_pts(ctx.db, b)
            .await
            .map_err(RpcFailure::internal)?;
        let (my_pts, other_id, other_pts) = if user_id == a {
            (a_pts, b, b_pts)
        } else {
            (b_pts, a, a_pts)
        };
        let my_reactions = message_reactions_bytes(ctx, updated.id, user_id).await?;
        let other_reactions = message_reactions_bytes(ctx, updated.id, other_id).await?;
        let my_message = private_message_record(
            &updated,
            true,
            other_id,
            media.as_deref(),
            pinned_id,
            my_reactions.as_deref(),
        );
        let other_message = private_message_record(
            &updated,
            false,
            user_id,
            media.as_deref(),
            pinned_id,
            other_reactions.as_deref(),
        );
        let my_update = types::update_edit_message(&my_message, my_pts, 1);
        let other_update = types::update_edit_message(&other_message, other_pts, 1);
        repo::log_user_update(ctx.db, user_id, my_pts, &my_update)
            .await
            .map_err(RpcFailure::internal)?;
        repo::log_user_update(ctx.db, other_id, other_pts, &other_update)
            .await
            .map_err(RpcFailure::internal)?;
        let response = types::updates(&[my_update], &[], edited_at, 0);
        let push_updates = vec![other_update];
        let mut users = Vec::new();
        if let Some(other) = repo::find_user_by_id(ctx.db, other_id)
            .await
            .map_err(RpcFailure::internal)?
        {
            users.push(other_user_bytes(&other));
        }
        let push = types::updates(&push_updates, &users, edited_at, 0);
        ctx.updates.publish(other_id, push);
        let self_push = types::updates(
            &[types::update_edit_message(&my_message, my_pts, 1)],
            &users,
            edited_at,
            0,
        );
        ctx.updates
            .publish_excluding(user_id, Some(ctx.session_id), self_push);
        return Ok(response);
    }

    if chat.kind == "basic_group" {
        let Some(basic_chat) = repo::find_channel(ctx.db, chat.id)
            .await
            .map_err(RpcFailure::internal)?
        else {
            return Err(RpcFailure::new(400, "CHAT_ID_INVALID"));
        };
        let member_ids = repo::chat_member_ids(ctx.db, chat.id)
            .await
            .map_err(RpcFailure::internal)?;
        let Some(sender) = ctx_user(ctx).await? else {
            return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
        };
        let mut my_message = Vec::new();
        let mut my_pts = 0;
        for member_id in &member_ids {
            let pts = repo::bump_user_pts(ctx.db, *member_id)
                .await
                .map_err(RpcFailure::internal)?;
            let out = *member_id == user_id;
            let reactions = message_reactions_bytes(ctx, updated.id, *member_id).await?;
            let message = chat_message_record(
                &updated,
                out,
                chat.id,
                media.as_deref(),
                pinned_id,
                reactions.as_deref(),
            );
            let update = types::update_edit_message(&message, pts, 1);
            repo::log_user_update(ctx.db, *member_id, pts, &update)
                .await
                .map_err(RpcFailure::internal)?;
            if *member_id == user_id {
                my_message = message;
                my_pts = pts;
            } else {
                let push = types::updates_with_chats(
                    &[update],
                    &[other_user_bytes(&sender)],
                    &[chat_record_bytes(&basic_chat, *member_id)],
                    edited_at,
                    0,
                );
                ctx.updates.publish(*member_id, push);
            }
        }
        let mut users = Vec::new();
        if updated.sender_user_id != user_id {
            if let Some(author) = repo::find_user_by_id(ctx.db, updated.sender_user_id)
                .await
                .map_err(RpcFailure::internal)?
            {
                users.push(other_user_bytes(&author));
            }
        }
        let response = types::updates_with_chats(
            &[types::update_edit_message(&my_message, my_pts, 1)],
            &users,
            &[chat_record_bytes(&basic_chat, user_id)],
            edited_at,
            0,
        );
        let self_push = types::updates_with_chats(
            &[types::update_edit_message(&my_message, my_pts, 1)],
            &users,
            &[chat_record_bytes(&basic_chat, user_id)],
            edited_at,
            0,
        );
        ctx.updates
            .publish_excluding(user_id, Some(ctx.session_id), self_push);
        return Ok(response);
    }

    let Some(channel) = repo::find_channel(ctx.db, chat.id)
        .await
        .map_err(RpcFailure::internal)?
    else {
        return Err(RpcFailure::new(400, "CHANNEL_INVALID"));
    };
    let pts = repo::bump_channel_pts(ctx.db, chat.id)
        .await
        .map_err(RpcFailure::internal)?;
    let sender_reactions = message_reactions_bytes(ctx, updated.id, user_id).await?;
    let sender_message = channel_message_record(
        &updated,
        true,
        chat.id,
        media.as_deref(),
        pinned_id,
        sender_reactions.as_deref(),
    );
    let member_message =
        channel_message_record(&updated, false, chat.id, media.as_deref(), pinned_id, None);
    let channel_update = types::update_edit_channel_message(&member_message, pts, 1);
    repo::log_channel_update(ctx.db, chat.id, pts, &channel_update)
        .await
        .map_err(RpcFailure::internal)?;
    let chat_bytes = channel_bytes(&channel, user_id);
    let response = types::updates_with_chats(
        &[types::update_edit_channel_message(&sender_message, pts, 1)],
        &[],
        std::slice::from_ref(&chat_bytes),
        edited_at,
        0,
    );
    let Some(sender) = ctx_user(ctx).await? else {
        return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
    };
    for member_id in repo::chat_member_ids(ctx.db, chat.id)
        .await
        .map_err(RpcFailure::internal)?
    {
        if member_id == user_id {
            continue;
        }
        let reactions = message_reactions_bytes(ctx, updated.id, member_id).await?;
        let member_view = channel_message_record(
            &updated,
            false,
            chat.id,
            media.as_deref(),
            pinned_id,
            reactions.as_deref(),
        );
        let push = types::updates_with_chats(
            &[types::update_edit_channel_message(&member_view, pts, 1)],
            &[other_user_bytes(&sender)],
            &[channel_bytes(&channel, member_id)],
            edited_at,
            0,
        );
        ctx.updates.publish(member_id, push);
    }
    let self_push = types::updates_with_chats(
        &[types::update_edit_channel_message(&sender_message, pts, 1)],
        &[other_user_bytes(&sender)],
        &[chat_bytes],
        edited_at,
        0,
    );
    ctx.updates
        .publish_excluding(user_id, Some(ctx.session_id), self_push);
    Ok(response)
}

async fn messages_delete_messages(
    ctx: &RpcContext<'_>,
    reader: &mut Reader<'_>,
) -> Result<Vec<u8>, RpcFailure> {
    let flags = reader.u32()?;
    let _revoke = flags & 1 != 0;
    let ids = reader.vector(|reader| reader.i32())?;
    let ids: Vec<i64> = ids.into_iter().map(i64::from).collect();
    let Some(user_id) = ctx.user_id else {
        return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
    };
    delete_messages_by_chat(ctx, user_id, &ids).await
}

async fn channels_delete_messages(
    ctx: &RpcContext<'_>,
    reader: &mut Reader<'_>,
) -> Result<Vec<u8>, RpcFailure> {
    let (channel_id, access_hash) = read_input_channel(reader)?;
    let ids = reader.vector(|reader| reader.i32())?;
    let ids: Vec<i64> = ids.into_iter().map(i64::from).collect();
    let Some(user_id) = ctx.user_id else {
        return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
    };
    let Some(channel) = repo::find_channel(ctx.db, channel_id)
        .await
        .map_err(RpcFailure::internal)?
    else {
        return Err(RpcFailure::new(400, "CHANNEL_INVALID"));
    };
    if channel.access_hash != 0 && channel.access_hash != access_hash {
        return Err(RpcFailure::new(400, "CHANNEL_INVALID"));
    }
    if repo::channel_membership(ctx.db, channel_id, user_id)
        .await
        .map_err(RpcFailure::internal)?
        .is_none()
    {
        return Err(RpcFailure::new(403, "CHANNEL_PRIVATE"));
    }
    let records = repo::find_messages(ctx.db, &ids)
        .await
        .map_err(RpcFailure::internal)?;
    let permitted: Vec<i64> = records
        .iter()
        .filter(|record| record.chat_id == channel_id)
        .filter(|record| channel.owner_user_id == user_id || record.sender_user_id == user_id)
        .map(|record| record.id)
        .collect();
    let (pts, count) = delete_messages_in_chat(ctx, &channel_id, &permitted).await?;
    Ok(types::messages_affected_messages(pts, count))
}

async fn delete_messages_by_chat(
    ctx: &RpcContext<'_>,
    user_id: i64,
    ids: &[i64],
) -> Result<Vec<u8>, RpcFailure> {
    let records = repo::find_messages(ctx.db, ids)
        .await
        .map_err(RpcFailure::internal)?;
    let mut groups: std::collections::HashMap<i64, Vec<i64>> = std::collections::HashMap::new();
    for record in &records {
        let Some(chat) = repo::find_chat(ctx.db, record.chat_id)
            .await
            .map_err(RpcFailure::internal)?
        else {
            continue;
        };
        let allowed = if chat.kind == "private" {
            private_pair_contains(&chat, user_id)
        } else {
            repo::channel_membership(ctx.db, chat.id, user_id)
                .await
                .map_err(RpcFailure::internal)?
                .is_some()
                && (chat.owner_user_id == Some(user_id) || record.sender_user_id == user_id)
        };
        if allowed {
            groups.entry(chat.id).or_default().push(record.id);
        }
    }
    let mut pts = user_pts(ctx).await?;
    let mut count = 0;
    for (chat_id, chat_ids) in groups {
        let (chat_pts, chat_count) = delete_messages_in_chat(ctx, &chat_id, &chat_ids).await?;
        pts = chat_pts;
        count += chat_count;
    }
    Ok(types::messages_affected_messages(pts, count))
}

async fn delete_messages_in_chat(
    ctx: &RpcContext<'_>,
    chat_id: &i64,
    ids: &[i64],
) -> Result<(i32, i32), RpcFailure> {
    let Some(chat) = repo::find_chat(ctx.db, *chat_id)
        .await
        .map_err(RpcFailure::internal)?
    else {
        return Ok((0, 0));
    };
    let deleted = repo::delete_messages(ctx.db, *chat_id, ids)
        .await
        .map_err(RpcFailure::internal)?;
    let deleted_ids: Vec<i32> = deleted.iter().map(|record| record.id as i32).collect();
    let count = deleted_ids.len() as i32;
    if count == 0 {
        return Ok((0, 0));
    }
    let user_id = ctx.user_id.unwrap_or(0);
    let timestamp = now() as i32;
    if chat.kind == "private" {
        let (a, b) = private_pair(&chat)?;
        let a_pts = repo::bump_user_pts(ctx.db, a)
            .await
            .map_err(RpcFailure::internal)?;
        let b_pts = repo::bump_user_pts(ctx.db, b)
            .await
            .map_err(RpcFailure::internal)?;
        let a_update = types::update_delete_messages(&deleted_ids, a_pts, count);
        let b_update = types::update_delete_messages(&deleted_ids, b_pts, count);
        repo::log_user_update(ctx.db, a, a_pts, &a_update)
            .await
            .map_err(RpcFailure::internal)?;
        repo::log_user_update(ctx.db, b, b_pts, &b_update)
            .await
            .map_err(RpcFailure::internal)?;
        let a_push = types::updates(&[a_update], &[], timestamp, 0);
        let b_push = types::updates(&[b_update], &[], timestamp, 0);
        if user_id == a {
            ctx.updates
                .publish_excluding(a, Some(ctx.session_id), a_push.clone());
            ctx.updates.publish(b, b_push);
            return Ok((a_pts, count));
        }
        ctx.updates.publish(a, a_push);
        ctx.updates
            .publish_excluding(b, Some(ctx.session_id), b_push);
        return Ok((b_pts, count));
    }

    if chat.kind == "basic_group" {
        let member_ids = repo::chat_member_ids(ctx.db, *chat_id)
            .await
            .map_err(RpcFailure::internal)?;
        let mut my_pts = 0;
        for member_id in &member_ids {
            let pts = repo::bump_user_pts(ctx.db, *member_id)
                .await
                .map_err(RpcFailure::internal)?;
            let update = types::update_delete_messages(&deleted_ids, pts, count);
            repo::log_user_update(ctx.db, *member_id, pts, &update)
                .await
                .map_err(RpcFailure::internal)?;
            if *member_id == user_id {
                my_pts = pts;
            } else {
                let push = types::updates(&[update], &[], timestamp, 0);
                ctx.updates.publish(*member_id, push);
            }
        }
        let self_push = types::updates(
            &[types::update_delete_messages(&deleted_ids, my_pts, count)],
            &[],
            timestamp,
            0,
        );
        ctx.updates
            .publish_excluding(user_id, Some(ctx.session_id), self_push);
        return Ok((my_pts, count));
    }

    let pts = repo::bump_channel_pts(ctx.db, *chat_id)
        .await
        .map_err(RpcFailure::internal)?;
    let channel_update = types::update_delete_channel_messages(*chat_id, &deleted_ids, pts, count);
    repo::log_channel_update(ctx.db, *chat_id, pts, &channel_update)
        .await
        .map_err(RpcFailure::internal)?;
    let push = types::updates(&[channel_update], &[], timestamp, 0);
    for member_id in repo::chat_member_ids(ctx.db, *chat_id)
        .await
        .map_err(RpcFailure::internal)?
    {
        if member_id == user_id {
            ctx.updates
                .publish_excluding(member_id, Some(ctx.session_id), push.clone());
        } else {
            ctx.updates.publish(member_id, push.clone());
        }
    }
    Ok((pts, count))
}

#[allow(clippy::too_many_arguments)]
async fn messages_forward_messages(
    ctx: &RpcContext<'_>,
    reader: &mut Reader<'_>,
) -> Result<Vec<u8>, RpcFailure> {
    let flags = reader.u32()?;
    if flags
        & (1 << 9 | 1 << 10 | 1 << 13 | 1 << 17 | 1 << 18 | 1 << 20 | 1 << 21 | 1 << 23 | 1 << 24)
        != 0
    {
        return Err(RpcFailure::new(400, "FORWARD_OPTIONS_UNSUPPORTED"));
    }
    let drop_author = flags & (1 << 11) != 0;
    let drop_media_captions = flags & (1 << 12) != 0;
    let from_peer = read_input_peer(ctx, reader)?;
    let source_ids = reader.vector(|reader| reader.i32())?;
    let random_ids = reader.vector(|reader| reader.i64())?;
    let to_peer = read_input_peer(ctx, reader)?;
    let reply_to = if flags & (1 << 22) != 0 {
        read_input_reply_to(reader)?
    } else {
        None
    };
    if source_ids.len() != random_ids.len() {
        return Err(RpcFailure::new(400, "RANDOM_ID_INVALID"));
    }
    let Some(user_id) = ctx.user_id else {
        return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
    };
    let source_chat_id = match from_peer {
        PeerRef::User(peer_id) => repo::find_private_chat(ctx.db, user_id, peer_id)
            .await
            .map_err(RpcFailure::internal)?
            .ok_or_else(|| RpcFailure::new(400, "PEER_ID_INVALID"))?,
        PeerRef::Channel { id, access_hash } => {
            let Some(channel) = repo::find_channel(ctx.db, id)
                .await
                .map_err(RpcFailure::internal)?
            else {
                return Err(RpcFailure::new(400, "CHANNEL_INVALID"));
            };
            if channel.access_hash != 0 && channel.access_hash != access_hash {
                return Err(RpcFailure::new(400, "CHANNEL_INVALID"));
            }
            if repo::channel_membership(ctx.db, id, user_id)
                .await
                .map_err(RpcFailure::internal)?
                .is_none()
            {
                return Err(RpcFailure::new(403, "CHANNEL_PRIVATE"));
            }
            id
        }
        PeerRef::Chat(id) => {
            let Some(chat) = repo::find_channel(ctx.db, id)
                .await
                .map_err(RpcFailure::internal)?
            else {
                return Err(RpcFailure::new(400, "CHAT_ID_INVALID"));
            };
            if chat.kind != "basic_group" {
                return Err(RpcFailure::new(400, "CHAT_ID_INVALID"));
            }
            if repo::channel_membership(ctx.db, chat.id, user_id)
                .await
                .map_err(RpcFailure::internal)?
                .is_none()
            {
                return Err(RpcFailure::new(403, "CHAT_PRIVATE"));
            }
            chat.id
        }
    };
    let source_chat = repo::find_chat(ctx.db, source_chat_id)
        .await
        .map_err(RpcFailure::internal)?
        .ok_or_else(|| RpcFailure::new(400, "PEER_ID_INVALID"))?;
    let source_records = repo::find_messages(
        ctx.db,
        &source_ids
            .iter()
            .map(|id| i64::from(*id))
            .collect::<Vec<_>>(),
    )
    .await
    .map_err(RpcFailure::internal)?;
    let mut by_id = std::collections::HashMap::new();
    for record in source_records {
        by_id.insert(record.id, record);
    }
    let mut last_response = types::updates(&[], &[], now() as i32, 0);
    let mut produced = 0usize;
    for (index, source_id) in source_ids.iter().enumerate() {
        let Some(record) = by_id.get(&i64::from(*source_id)) else {
            continue;
        };
        if record.chat_id != source_chat_id {
            continue;
        }
        if !record.action_kind.is_empty() {
            continue;
        }
        let media = repo::find_media(ctx.db, record.media_id.unwrap_or(-1))
            .await
            .map_err(RpcFailure::internal)?;
        let mut extras = if drop_author {
            repo::MessageExtras {
                reply_to_msg_id: reply_to,
                ..repo::MessageExtras::default()
            }
        } else if source_chat.kind == "private" {
            repo::MessageExtras {
                reply_to_msg_id: reply_to,
                fwd_from_user_id: Some(record.sender_user_id),
                fwd_date: record.sent_at,
                ..repo::MessageExtras::default()
            }
        } else {
            repo::MessageExtras {
                reply_to_msg_id: reply_to,
                fwd_from_chat_id: Some(source_chat.id),
                fwd_from_msg_id: Some(record.id),
                fwd_date: record.sent_at,
                ..repo::MessageExtras::default()
            }
        };
        if !drop_media_captions {
            extras.entities = record.entities.clone();
        }
        let forwarded_text = if drop_media_captions {
            ""
        } else {
            &record.text
        };
        let response = deliver_message(
            ctx,
            to_peer,
            forwarded_text,
            random_ids[index],
            media.as_ref(),
            &extras,
        )
        .await?;
        produced += 1;
        last_response = response.clone();
        if index + 1 < source_ids.len() {
            ctx.updates.publish(user_id, response);
        }
    }
    if produced == 0 {
        return Err(RpcFailure::new(400, "MESSAGE_ID_INVALID"));
    }
    Ok(last_response)
}

enum InputChatPhotoRef {
    Empty,
    Photo { id: i64 },
    Uploaded { file: InputFileRef },
}

fn read_input_chat_photo(reader: &mut Reader<'_>) -> Result<InputChatPhotoRef, RpcFailure> {
    match reader.constructor()? {
        ctor::INPUT_CHAT_PHOTO_EMPTY => Ok(InputChatPhotoRef::Empty),
        ctor::INPUT_CHAT_PHOTO => Ok(InputChatPhotoRef::Photo {
            id: read_input_photo_id(reader)?,
        }),
        ctor::INPUT_CHAT_UPLOADED_PHOTO => {
            let flags = reader.u32()?;
            if flags & 1 == 0 {
                return Err(RpcFailure::new(400, "PHOTO_REQUIRED"));
            }
            if flags & !1 != 0 {
                return Err(RpcFailure::new(400, "VIDEO_EMOJI_UNSUPPORTED"));
            }
            Ok(InputChatPhotoRef::Uploaded {
                file: read_input_file(reader)?,
            })
        }
        other => Err(RpcFailure::new(
            400,
            format!("UNSUPPORTED_INPUT_CHAT_PHOTO_0x{other:08X}"),
        )),
    }
}

async fn apply_chat_photo(
    ctx: &RpcContext<'_>,
    chat_id: i64,
    photo: InputChatPhotoRef,
) -> Result<Vec<u8>, RpcFailure> {
    let Some(user_id) = ctx.user_id else {
        return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
    };
    let media_id = match photo {
        InputChatPhotoRef::Empty => 0,
        InputChatPhotoRef::Photo { id } => {
            let record = repo::find_media(ctx.db, id)
                .await
                .map_err(RpcFailure::internal)?
                .ok_or_else(|| RpcFailure::new(400, "MEDIA_INVALID"))?;
            if record.kind != "photo" {
                return Err(RpcFailure::new(400, "MEDIA_INVALID"));
            }
            id
        }
        InputChatPhotoRef::Uploaded { file } => {
            let media =
                materialize_input_media(ctx, user_id, InputMediaRef::UploadedPhoto { file })
                    .await?
                    .ok_or_else(|| RpcFailure::new(400, "MEDIA_INVALID"))?;
            media.id
        }
    };
    repo::set_chat_photo(ctx.db, chat_id, media_id)
        .await
        .map_err(RpcFailure::internal)?;
    let Some(chat) = repo::find_channel(ctx.db, chat_id)
        .await
        .map_err(RpcFailure::internal)?
    else {
        return Err(RpcFailure::new(400, "CHAT_ID_INVALID"));
    };
    let timestamp = now() as i32;
    if chat.kind == "basic_group" {
        let response =
            types::updates_with_chats(&[], &[], &[chat_record_bytes(&chat, user_id)], timestamp, 0);
        for member_id in repo::chat_member_ids(ctx.db, chat.id)
            .await
            .map_err(RpcFailure::internal)?
        {
            let push = types::updates_with_chats(
                &[],
                &[],
                &[chat_record_bytes(&chat, member_id)],
                timestamp,
                0,
            );
            if member_id == user_id {
                ctx.updates
                    .publish_excluding(member_id, Some(ctx.session_id), push);
            } else {
                ctx.updates.publish(member_id, push);
            }
        }
        return Ok(response);
    }
    let update = types::update_channel(chat.id);
    let response = types::updates_with_chats(
        std::slice::from_ref(&update),
        &[],
        &[channel_bytes(&chat, user_id)],
        timestamp,
        0,
    );
    for member_id in repo::chat_member_ids(ctx.db, chat.id)
        .await
        .map_err(RpcFailure::internal)?
    {
        let push = types::updates_with_chats(
            std::slice::from_ref(&update),
            &[],
            &[channel_bytes(&chat, member_id)],
            timestamp,
            0,
        );
        if member_id == user_id {
            ctx.updates
                .publish_excluding(member_id, Some(ctx.session_id), push);
        } else {
            ctx.updates.publish(member_id, push);
        }
    }
    Ok(response)
}

async fn messages_edit_chat_photo(
    ctx: &RpcContext<'_>,
    reader: &mut Reader<'_>,
) -> Result<Vec<u8>, RpcFailure> {
    let chat_id = reader.i64()?;
    let photo = read_input_chat_photo(reader)?;
    let Some(user_id) = ctx.user_id else {
        return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
    };
    let Some(chat) = repo::find_channel(ctx.db, chat_id)
        .await
        .map_err(RpcFailure::internal)?
    else {
        return Err(RpcFailure::new(400, "CHAT_ID_INVALID"));
    };
    if chat.kind != "basic_group" {
        return Err(RpcFailure::new(400, "CHAT_ID_INVALID"));
    }
    if repo::channel_membership(ctx.db, chat.id, user_id)
        .await
        .map_err(RpcFailure::internal)?
        .is_none()
    {
        return Err(RpcFailure::new(403, "CHAT_WRITE_FORBIDDEN"));
    }
    if chat.owner_user_id != user_id {
        return Err(RpcFailure::new(403, "CHAT_ADMIN_REQUIRED"));
    }
    apply_chat_photo(ctx, chat.id, photo).await
}

async fn channels_edit_photo(
    ctx: &RpcContext<'_>,
    reader: &mut Reader<'_>,
) -> Result<Vec<u8>, RpcFailure> {
    let (channel_id, access_hash) = read_input_channel(reader)?;
    let photo = read_input_chat_photo(reader)?;
    let Some(user_id) = ctx.user_id else {
        return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
    };
    let Some(channel) = repo::find_channel(ctx.db, channel_id)
        .await
        .map_err(RpcFailure::internal)?
    else {
        return Err(RpcFailure::new(400, "CHANNEL_INVALID"));
    };
    if channel.access_hash != 0 && channel.access_hash != access_hash {
        return Err(RpcFailure::new(400, "CHANNEL_INVALID"));
    }
    if repo::channel_membership(ctx.db, channel_id, user_id)
        .await
        .map_err(RpcFailure::internal)?
        .is_none()
    {
        return Err(RpcFailure::new(403, "CHANNEL_PRIVATE"));
    }
    if channel.owner_user_id != user_id {
        return Err(RpcFailure::new(403, "CHAT_ADMIN_REQUIRED"));
    }
    apply_chat_photo(ctx, channel.id, photo).await
}

async fn messages_update_pinned_message(
    ctx: &RpcContext<'_>,
    reader: &mut Reader<'_>,
) -> Result<Vec<u8>, RpcFailure> {
    let flags = reader.u32()?;
    let peer = read_input_peer(ctx, reader)?;
    let id = i64::from(reader.i32()?);
    let unpin = flags & (1 << 1) != 0 || id == 0;
    let Some(user_id) = ctx.user_id else {
        return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
    };
    let chat = resolve_peer_chat(ctx, peer, user_id, true).await?;
    if chat.kind != "private" && chat.owner_user_id != Some(user_id) {
        return Err(RpcFailure::new(403, "CHAT_ADMIN_REQUIRED"));
    }
    if !unpin {
        let Some(record) = repo::find_message(ctx.db, id)
            .await
            .map_err(RpcFailure::internal)?
        else {
            return Err(RpcFailure::new(400, "MESSAGE_ID_INVALID"));
        };
        if record.chat_id != chat.id {
            return Err(RpcFailure::new(400, "MESSAGE_ID_INVALID"));
        }
    }
    apply_pinned_message(ctx, user_id, chat, if unpin { None } else { Some(id) }).await
}

/// Shared pin implementation for the client RPC and the admin panel.
async fn apply_pinned_message(
    ctx: &RpcContext<'_>,
    user_id: i64,
    chat: repo::ChatInfo,
    pin: Option<i64>,
) -> Result<Vec<u8>, RpcFailure> {
    let unpin = pin.is_none();
    match pin {
        Some(id) => repo::set_pinned_message(ctx.db, chat.id, id)
            .await
            .map_err(RpcFailure::internal)?,
        None => repo::set_pinned_message(ctx.db, chat.id, 0)
            .await
            .map_err(RpcFailure::internal)?,
    }
    let timestamp = now() as i32;
    let ids = match pin {
        Some(id) => vec![id as i32],
        None => Vec::new(),
    };
    if chat.kind == "private" {
        let (a, b) = private_pair(&chat)?;
        let a_pts = repo::bump_user_pts(ctx.db, a)
            .await
            .map_err(RpcFailure::internal)?;
        let b_pts = repo::bump_user_pts(ctx.db, b)
            .await
            .map_err(RpcFailure::internal)?;
        let (my_pts, other_id, other_pts, other_peer) = if user_id == a {
            (a_pts, b, b_pts, b)
        } else {
            (b_pts, a, a_pts, a)
        };
        let peer_bytes = types::peer_user(other_peer);
        let other_peer_bytes = types::peer_user(user_id);
        let my_update = types::update_pinned_messages(!unpin, &peer_bytes, &ids, my_pts, 1);
        let other_update =
            types::update_pinned_messages(!unpin, &other_peer_bytes, &ids, other_pts, 1);
        repo::log_user_update(ctx.db, user_id, my_pts, &my_update)
            .await
            .map_err(RpcFailure::internal)?;
        repo::log_user_update(ctx.db, other_id, other_pts, &other_update)
            .await
            .map_err(RpcFailure::internal)?;
        let response = types::updates(&[my_update], &[], timestamp, 0);
        let push = types::updates(&[other_update], &[], timestamp, 0);
        ctx.updates.publish(other_id, push);
        ctx.updates
            .publish_excluding(user_id, Some(ctx.session_id), response.clone());
        return Ok(response);
    }
    let Some(channel) = repo::find_channel(ctx.db, chat.id)
        .await
        .map_err(RpcFailure::internal)?
    else {
        return Err(RpcFailure::new(400, "CHANNEL_INVALID"));
    };
    if chat.kind == "basic_group" {
        let member_ids = repo::chat_member_ids(ctx.db, chat.id)
            .await
            .map_err(RpcFailure::internal)?;
        let peer_bytes = types::peer_chat(chat.id);
        let mut my_pts = 0;
        for member_id in &member_ids {
            let pts = repo::bump_user_pts(ctx.db, *member_id)
                .await
                .map_err(RpcFailure::internal)?;
            let update = types::update_pinned_messages(!unpin, &peer_bytes, &ids, pts, 1);
            repo::log_user_update(ctx.db, *member_id, pts, &update)
                .await
                .map_err(RpcFailure::internal)?;
            if *member_id == user_id {
                my_pts = pts;
            } else {
                let push = types::updates_with_chats(
                    &[update],
                    &[],
                    &[chat_record_bytes(&channel, *member_id)],
                    timestamp,
                    0,
                );
                ctx.updates.publish(*member_id, push);
            }
        }
        let response = types::updates_with_chats(
            &[types::update_pinned_messages(
                !unpin,
                &peer_bytes,
                &ids,
                my_pts,
                1,
            )],
            &[],
            &[chat_record_bytes(&channel, user_id)],
            timestamp,
            0,
        );
        ctx.updates
            .publish_excluding(user_id, Some(ctx.session_id), response.clone());
        return Ok(response);
    }
    let pts = repo::bump_channel_pts(ctx.db, chat.id)
        .await
        .map_err(RpcFailure::internal)?;
    let channel_update = types::update_pinned_channel_messages(!unpin, chat.id, &ids, pts, 1);
    repo::log_channel_update(ctx.db, chat.id, pts, &channel_update)
        .await
        .map_err(RpcFailure::internal)?;
    let chat_bytes = channel_bytes(&channel, user_id);
    let response = types::updates_with_chats(
        &[channel_update],
        &[],
        std::slice::from_ref(&chat_bytes),
        timestamp,
        0,
    );
    for member_id in repo::chat_member_ids(ctx.db, chat.id)
        .await
        .map_err(RpcFailure::internal)?
    {
        let push = types::updates_with_chats(
            &[types::update_pinned_channel_messages(
                !unpin, chat.id, &ids, pts, 1,
            )],
            &[],
            &[channel_bytes(&channel, member_id)],
            timestamp,
            0,
        );
        if member_id == user_id {
            ctx.updates
                .publish_excluding(member_id, Some(ctx.session_id), push);
        } else {
            ctx.updates.publish(member_id, push);
        }
    }
    Ok(response)
}

async fn apply_profile_photo(ctx: &RpcContext<'_>, media_id: i64) -> Result<Vec<u8>, RpcFailure> {
    let Some(user_id) = ctx.user_id else {
        return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
    };
    let Some(record) = repo::find_media(ctx.db, media_id)
        .await
        .map_err(RpcFailure::internal)?
    else {
        return Err(RpcFailure::new(400, "MEDIA_INVALID"));
    };
    if record.kind != "photo" {
        return Err(RpcFailure::new(400, "PHOTO_INVALID"));
    }
    repo::set_user_photo(ctx.db, user_id, record.id)
        .await
        .map_err(RpcFailure::internal)?;
    let Some(user) = repo::find_user_by_id(ctx.db, user_id)
        .await
        .map_err(RpcFailure::internal)?
    else {
        return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
    };
    let push = types::updates(
        &[types::update_user(user.id)],
        &[user_bytes(user.clone())],
        now() as i32,
        0,
    );
    ctx.updates
        .publish_excluding(user_id, Some(ctx.session_id), push);
    Ok(types::photos_photo(
        &photo_object(&record),
        &[user_bytes(user)],
    ))
}

async fn photos_upload_profile_photo(
    ctx: &RpcContext<'_>,
    reader: &mut Reader<'_>,
) -> Result<Vec<u8>, RpcFailure> {
    let flags = reader.u32()?;
    if flags & (1 << 5) != 0 {
        let _bot = read_input_user(reader)?;
    }
    let file = if flags & 1 != 0 {
        Some(read_input_file(reader)?)
    } else {
        None
    };
    if flags & (1 << 1) != 0 {
        let _video = read_input_file(reader)?;
    }
    if flags & (1 << 2) != 0 {
        let _video_start_ts = reader.f64()?;
    }
    if flags & (1 << 4) != 0 {
        return Err(RpcFailure::new(400, "VIDEO_EMOJI_UNSUPPORTED"));
    }
    let Some(file) = file else {
        return Err(RpcFailure::new(400, "PHOTO_REQUIRED"));
    };
    let Some(user_id) = ctx.user_id else {
        return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
    };
    let media =
        materialize_input_media(ctx, user_id, InputMediaRef::UploadedPhoto { file }).await?;
    let Some(media) = media else {
        return Err(RpcFailure::new(400, "MEDIA_INVALID"));
    };
    apply_profile_photo(ctx, media.id).await
}

async fn photos_update_profile_photo(
    ctx: &RpcContext<'_>,
    reader: &mut Reader<'_>,
) -> Result<Vec<u8>, RpcFailure> {
    let flags = reader.u32()?;
    if flags & (1 << 1) != 0 {
        let _bot = read_input_user(reader)?;
    }
    if reader.constructor()? != 0x3bb3_b94a {
        return Err(RpcFailure::new(400, "UNSUPPORTED_INPUT_PHOTO"));
    }
    let media_id = reader.i64()?;
    let _access_hash = reader.i64()?;
    let _file_reference = reader.bytes()?;
    apply_profile_photo(ctx, media_id).await
}

async fn photos_get_user_photos(
    ctx: &RpcContext<'_>,
    reader: &mut Reader<'_>,
) -> Result<Vec<u8>, RpcFailure> {
    let user = read_input_user(reader)?;
    let _offset = reader.i32()?;
    let _max_id = reader.i64()?;
    let _limit = reader.i32()?;
    let Some(actor_id) = ctx.user_id else {
        return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
    };
    let target_id = match user {
        InputUser::SelfUser => actor_id,
        InputUser::Id(id) => id,
    };
    let Some(target) = repo::find_user_by_id(ctx.db, target_id)
        .await
        .map_err(RpcFailure::internal)?
    else {
        return Err(RpcFailure::new(400, "USER_ID_INVALID"));
    };
    let mut photos = Vec::new();
    if target.photo_media_id > 0 {
        if let Some(record) = repo::find_media(ctx.db, target.photo_media_id)
            .await
            .map_err(RpcFailure::internal)?
        {
            photos.push(photo_object(&record));
        }
    }
    let users = vec![if target_id == actor_id {
        user_bytes(target)
    } else {
        other_user_bytes(&target)
    }];
    Ok(types::photos_photos(&photos, &users))
}

async fn messages_create_chat(
    ctx: &RpcContext<'_>,
    reader: &mut Reader<'_>,
) -> Result<Vec<u8>, RpcFailure> {
    let flags = reader.u32()?;
    if flags & 1 != 0 {
        let _ttl_period = reader.i32()?;
    }
    reader.expect_constructor(ctor::VECTOR)?;
    let count = reader.i32()?.max(0);
    let mut inputs = Vec::with_capacity(count as usize);
    for _ in 0..count {
        inputs.push(read_input_user(reader)?);
    }
    let title = reader.string()?;
    let title = title.trim();
    if title.is_empty() {
        return Err(RpcFailure::new(400, "NO_CHAT_TITLE"));
    }
    let Some(owner) = ctx_user(ctx).await? else {
        return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
    };
    let mut members = Vec::new();
    for input in inputs {
        match input {
            InputUser::SelfUser => {}
            InputUser::Id(id) => {
                if id != owner.id
                    && repo::find_user_by_id(ctx.db, id)
                        .await
                        .map_err(RpcFailure::internal)?
                        .is_some()
                {
                    members.push(id);
                }
            }
        }
    }
    if members.is_empty() {
        return Err(RpcFailure::new(400, "USERS_TOO_FEW"));
    }
    let chat = repo::create_basic_group(ctx.db, owner.id, title, &members)
        .await
        .map_err(RpcFailure::internal)?;
    let record = repo::send_service_message(ctx.db, chat.id, owner.id, "create", owner.id, title)
        .await
        .map_err(RpcFailure::internal)?;
    let (_, updates, _) =
        deliver_basic_group_message(ctx, &chat, &record, &owner, None, None).await?;
    Ok(types::messages_invited_users(&updates))
}

async fn messages_get_chats(
    ctx: &RpcContext<'_>,
    reader: &mut Reader<'_>,
) -> Result<Vec<u8>, RpcFailure> {
    let ids = reader.vector(|reader| reader.i64())?;
    let Some(user_id) = ctx.user_id else {
        return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
    };
    let mut chats = Vec::new();
    for id in ids {
        let Some(chat) = repo::find_channel(ctx.db, id)
            .await
            .map_err(RpcFailure::internal)?
        else {
            continue;
        };
        if chat.kind != "basic_group" {
            continue;
        }
        if repo::channel_membership(ctx.db, chat.id, user_id)
            .await
            .map_err(RpcFailure::internal)?
            .is_none()
        {
            continue;
        }
        chats.push(chat_record_bytes(&chat, user_id));
    }
    Ok(types::messages_chats(&chats))
}

async fn messages_get_full_chat(
    ctx: &RpcContext<'_>,
    reader: &mut Reader<'_>,
) -> Result<Vec<u8>, RpcFailure> {
    let chat_id = reader.i64()?;
    let Some(user_id) = ctx.user_id else {
        return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
    };
    let Some(chat) = repo::find_channel(ctx.db, chat_id)
        .await
        .map_err(RpcFailure::internal)?
    else {
        return Err(RpcFailure::new(400, "CHAT_ID_INVALID"));
    };
    if chat.kind != "basic_group" {
        return Err(RpcFailure::new(400, "CHAT_ID_INVALID"));
    }
    if repo::channel_membership(ctx.db, chat.id, user_id)
        .await
        .map_err(RpcFailure::internal)?
        .is_none()
    {
        return Err(RpcFailure::new(403, "CHAT_PRIVATE"));
    }
    let member_ids = repo::chat_member_ids(ctx.db, chat.id)
        .await
        .map_err(RpcFailure::internal)?;
    let mut participants = Vec::new();
    let mut users = Vec::new();
    for member_id in member_ids {
        if member_id == chat.owner_user_id {
            participants.push(types::chat_participant_creator(member_id));
        } else {
            participants.push(types::chat_participant(
                member_id,
                chat.owner_user_id,
                now() as i32,
            ));
        }
        if let Some(user) = repo::find_user_by_id(ctx.db, member_id)
            .await
            .map_err(RpcFailure::internal)?
        {
            if member_id == user_id {
                users.push(user_bytes(user));
            } else {
                users.push(other_user_bytes(&user));
            }
        }
    }
    let full = types::chat_full_minimal(
        chat.id,
        &chat.about,
        &participants,
        (chat.photo_media_id > 0)
            .then(|| types::chat_photo(chat.photo_media_id, 2))
            .as_deref(),
    );
    Ok(types::messages_chat_full(
        &full,
        &[chat_record_bytes(&chat, user_id)],
        &users,
    ))
}

async fn basic_group_participants(
    ctx: &RpcContext<'_>,
    chat_id: i64,
) -> Result<Vec<u8>, RpcFailure> {
    let Some(chat) = repo::find_channel(ctx.db, chat_id)
        .await
        .map_err(RpcFailure::internal)?
    else {
        return Err(RpcFailure::new(400, "CHAT_ID_INVALID"));
    };
    let member_ids = repo::chat_member_ids(ctx.db, chat.id)
        .await
        .map_err(RpcFailure::internal)?;
    let mut participants = Vec::with_capacity(member_ids.len());
    for member_id in member_ids {
        if member_id == chat.owner_user_id {
            participants.push(types::chat_participant_creator(member_id));
        } else {
            participants.push(types::chat_participant(
                member_id,
                chat.owner_user_id,
                now() as i32,
            ));
        }
    }
    Ok(types::chat_participants(chat.id, 1, &participants))
}

async fn basic_group_users_except(
    ctx: &RpcContext<'_>,
    chat_id: i64,
    viewer_user_id: i64,
) -> Result<Vec<Vec<u8>>, RpcFailure> {
    let members = repo::list_channel_members(ctx.db, chat_id)
        .await
        .map_err(RpcFailure::internal)?;
    Ok(members
        .iter()
        .filter(|(user, _, _, _, _)| user.id != viewer_user_id)
        .map(|(user, _, _, _, _)| other_user_bytes(user))
        .collect())
}

async fn messages_add_chat_user(
    ctx: &RpcContext<'_>,
    reader: &mut Reader<'_>,
) -> Result<Vec<u8>, RpcFailure> {
    let chat_id = reader.i64()?;
    let invitee = read_input_user(reader)?;
    let _fwd_limit = reader.i32()?;
    let Some(actor_id) = ctx.user_id else {
        return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
    };
    let Some(chat) = repo::find_channel(ctx.db, chat_id)
        .await
        .map_err(RpcFailure::internal)?
    else {
        return Err(RpcFailure::new(400, "CHAT_ID_INVALID"));
    };
    if chat.kind != "basic_group" {
        return Err(RpcFailure::new(400, "CHAT_ID_INVALID"));
    }
    if repo::channel_membership(ctx.db, chat.id, actor_id)
        .await
        .map_err(RpcFailure::internal)?
        .is_none()
    {
        return Err(RpcFailure::new(403, "CHAT_WRITE_FORBIDDEN"));
    }
    let target_id = match invitee {
        InputUser::SelfUser => actor_id,
        InputUser::Id(id) => id,
    };
    if target_id == actor_id
        || repo::channel_membership(ctx.db, chat.id, target_id)
            .await
            .map_err(RpcFailure::internal)?
            .is_some()
    {
        return Err(RpcFailure::new(400, "USER_ALREADY_PARTICIPANT"));
    }
    if repo::find_user_by_id(ctx.db, target_id)
        .await
        .map_err(RpcFailure::internal)?
        .is_none()
    {
        return Err(RpcFailure::new(400, "USER_ID_INVALID"));
    }
    add_basic_group_member(ctx, &chat, actor_id, target_id).await
}

/// Shared basic-group add path for `messages.addChatUser` and the admin API:
/// inserts the member, writes the "add_user" service message, pushes
/// participant updates and returns the actor's response payload.
async fn add_basic_group_member(
    ctx: &RpcContext<'_>,
    chat: &repo::ChannelRecord,
    actor_id: i64,
    target_id: i64,
) -> Result<Vec<u8>, RpcFailure> {
    repo::add_channel_member(ctx.db, chat.id, target_id)
        .await
        .map_err(RpcFailure::internal)?;
    let Some(chat) = repo::find_channel(ctx.db, chat.id)
        .await
        .map_err(RpcFailure::internal)?
    else {
        return Err(RpcFailure::new(400, "CHAT_ID_INVALID"));
    };
    let Some(sender) = ctx_user(ctx).await? else {
        return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
    };
    let record = repo::send_service_message(ctx.db, chat.id, actor_id, "add_user", target_id, "")
        .await
        .map_err(RpcFailure::internal)?;
    let (_, response, _) =
        deliver_basic_group_message(ctx, &chat, &record, &sender, None, None).await?;
    let participants = basic_group_participants(ctx, chat.id).await?;
    let update = types::update_chat_participants(&participants);
    let timestamp = now() as i32;
    for member_id in repo::chat_member_ids(ctx.db, chat.id)
        .await
        .map_err(RpcFailure::internal)?
    {
        let users = basic_group_users_except(ctx, chat.id, member_id).await?;
        let push = types::updates_with_chats(
            std::slice::from_ref(&update),
            &users,
            &[chat_record_bytes(&chat, member_id)],
            timestamp,
            0,
        );
        if member_id == actor_id {
            ctx.updates
                .publish_excluding(member_id, Some(ctx.session_id), push);
        } else {
            ctx.updates.publish(member_id, push);
        }
    }
    Ok(types::messages_invited_users(&response))
}

async fn messages_delete_chat_user(
    ctx: &RpcContext<'_>,
    reader: &mut Reader<'_>,
) -> Result<Vec<u8>, RpcFailure> {
    let _flags = reader.u32()?;
    let chat_id = reader.i64()?;
    let member = read_input_user(reader)?;
    let Some(actor_id) = ctx.user_id else {
        return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
    };
    let Some(chat) = repo::find_channel(ctx.db, chat_id)
        .await
        .map_err(RpcFailure::internal)?
    else {
        return Err(RpcFailure::new(400, "CHAT_ID_INVALID"));
    };
    if chat.kind != "basic_group" {
        return Err(RpcFailure::new(400, "CHAT_ID_INVALID"));
    }
    let target_id = match member {
        InputUser::SelfUser => actor_id,
        InputUser::Id(id) => id,
    };
    if repo::channel_membership(ctx.db, chat.id, actor_id)
        .await
        .map_err(RpcFailure::internal)?
        .is_none()
    {
        return Err(RpcFailure::new(403, "CHAT_WRITE_FORBIDDEN"));
    }
    if target_id != actor_id && chat.owner_user_id != actor_id {
        return Err(RpcFailure::new(403, "CHAT_ADMIN_REQUIRED"));
    }
    if target_id == chat.owner_user_id {
        return Err(RpcFailure::new(400, "CHAT_ADMIN_REQUIRED"));
    }
    if repo::channel_membership(ctx.db, chat.id, target_id)
        .await
        .map_err(RpcFailure::internal)?
        .is_none()
    {
        return Err(RpcFailure::new(400, "USER_NOT_PARTICIPANT"));
    }
    remove_basic_group_member(ctx, chat.id, actor_id, target_id).await
}

/// Shared removal path for `messages.deleteChatUser` and the admin API.
/// Publishes participant updates to remaining members and a removal update to
/// the kicked user, returning the actor's response payload.
async fn remove_basic_group_member(
    ctx: &RpcContext<'_>,
    chat_id: i64,
    actor_id: i64,
    target_id: i64,
) -> Result<Vec<u8>, RpcFailure> {
    let Some(chat) = repo::find_channel(ctx.db, chat_id)
        .await
        .map_err(RpcFailure::internal)?
    else {
        return Err(RpcFailure::new(400, "CHAT_ID_INVALID"));
    };
    repo::remove_channel_member(ctx.db, chat.id, target_id)
        .await
        .map_err(RpcFailure::internal)?;
    let Some(chat) = repo::find_channel(ctx.db, chat.id)
        .await
        .map_err(RpcFailure::internal)?
    else {
        return Err(RpcFailure::new(400, "CHAT_ID_INVALID"));
    };
    let participants = basic_group_participants(ctx, chat.id).await?;
    let update = types::update_chat_participants(&participants);
    let timestamp = now() as i32;
    let response = if target_id != actor_id {
        let Some(sender) = ctx_user(ctx).await? else {
            return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
        };
        let record =
            repo::send_service_message(ctx.db, chat.id, actor_id, "delete_user", target_id, "")
                .await
                .map_err(RpcFailure::internal)?;
        deliver_basic_group_message(ctx, &chat, &record, &sender, None, None)
            .await?
            .1
    } else {
        types::updates_with_chats(
            std::slice::from_ref(&update),
            &[],
            &[chat_record_bytes(&chat, target_id)],
            timestamp,
            0,
        )
    };
    for member_id in repo::chat_member_ids(ctx.db, chat.id)
        .await
        .map_err(RpcFailure::internal)?
    {
        let push = types::updates_with_chats(
            std::slice::from_ref(&update),
            &basic_group_users_except(ctx, chat.id, member_id).await?,
            &[chat_record_bytes(&chat, member_id)],
            timestamp,
            0,
        );
        if member_id == actor_id {
            ctx.updates
                .publish_excluding(member_id, Some(ctx.session_id), push);
        } else {
            ctx.updates.publish(member_id, push);
        }
    }
    let removed_push = types::updates_with_chats(
        std::slice::from_ref(&update),
        &[],
        &[chat_record_bytes(&chat, target_id)],
        timestamp,
        0,
    );
    if target_id == actor_id {
        ctx.updates
            .publish_excluding(target_id, Some(ctx.session_id), removed_push);
        ctx.updates
            .publish_excluding(actor_id, Some(ctx.session_id), response.clone());
    } else {
        ctx.updates.publish(target_id, removed_push);
    }
    Ok(response)
}

async fn messages_edit_chat_title(
    ctx: &RpcContext<'_>,
    reader: &mut Reader<'_>,
) -> Result<Vec<u8>, RpcFailure> {
    let chat_id = reader.i64()?;
    let title = reader.string()?;
    let title = title.trim();
    if title.is_empty() {
        return Err(RpcFailure::new(400, "NO_CHAT_TITLE"));
    }
    let Some(actor_id) = ctx.user_id else {
        return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
    };
    let Some(chat) = repo::find_channel(ctx.db, chat_id)
        .await
        .map_err(RpcFailure::internal)?
    else {
        return Err(RpcFailure::new(400, "CHAT_ID_INVALID"));
    };
    if chat.kind != "basic_group" {
        return Err(RpcFailure::new(400, "CHAT_ID_INVALID"));
    }
    if repo::channel_membership(ctx.db, chat.id, actor_id)
        .await
        .map_err(RpcFailure::internal)?
        .is_none()
    {
        return Err(RpcFailure::new(403, "CHAT_WRITE_FORBIDDEN"));
    }
    if chat.owner_user_id != actor_id {
        return Err(RpcFailure::new(403, "CHAT_ADMIN_REQUIRED"));
    }
    repo::set_chat_title(ctx.db, chat.id, title)
        .await
        .map_err(RpcFailure::internal)?;
    let Some(chat) = repo::find_channel(ctx.db, chat.id)
        .await
        .map_err(RpcFailure::internal)?
    else {
        return Err(RpcFailure::new(400, "CHAT_ID_INVALID"));
    };
    let Some(sender) = ctx_user(ctx).await? else {
        return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
    };
    let record = repo::send_service_message(ctx.db, chat.id, actor_id, "edit_title", 0, title)
        .await
        .map_err(RpcFailure::internal)?;
    deliver_basic_group_message(ctx, &chat, &record, &sender, None, None)
        .await
        .map(|(_, response, _)| response)
}

async fn messages_unpin_all_messages(
    ctx: &RpcContext<'_>,
    reader: &mut Reader<'_>,
) -> Result<Vec<u8>, RpcFailure> {
    let flags = reader.u32()?;
    let peer = read_input_peer(ctx, reader)?;
    if flags & (1 << 0) != 0 {
        let _top_msg_id = reader.i32()?;
    }
    if flags & (1 << 1) != 0 {
        let _saved_peer = read_input_peer(ctx, reader)?;
    }
    let Some(user_id) = ctx.user_id else {
        return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
    };
    let chat = resolve_peer_chat(ctx, peer, user_id, true).await?;
    if chat.kind != "private" && chat.owner_user_id != Some(user_id) {
        return Err(RpcFailure::new(403, "CHAT_ADMIN_REQUIRED"));
    }
    repo::set_pinned_message(ctx.db, chat.id, 0)
        .await
        .map_err(RpcFailure::internal)?;
    let timestamp = now() as i32;
    let ids: Vec<i32> = Vec::new();
    if chat.kind == "private" {
        let (a, b) = private_pair(&chat)?;
        let a_pts = repo::bump_user_pts(ctx.db, a)
            .await
            .map_err(RpcFailure::internal)?;
        let b_pts = repo::bump_user_pts(ctx.db, b)
            .await
            .map_err(RpcFailure::internal)?;
        let (my_pts, other_id, other_pts, other_peer) = if user_id == a {
            (a_pts, b, b_pts, b)
        } else {
            (b_pts, a, a_pts, a)
        };
        let my_update =
            types::update_pinned_messages(false, &types::peer_user(other_peer), &ids, my_pts, 1);
        let other_update =
            types::update_pinned_messages(false, &types::peer_user(user_id), &ids, other_pts, 1);
        repo::log_user_update(ctx.db, user_id, my_pts, &my_update)
            .await
            .map_err(RpcFailure::internal)?;
        repo::log_user_update(ctx.db, other_id, other_pts, &other_update)
            .await
            .map_err(RpcFailure::internal)?;
        let response = types::updates(&[my_update], &[], timestamp, 0);
        ctx.updates
            .publish(other_id, types::updates(&[other_update], &[], timestamp, 0));
        ctx.updates
            .publish_excluding(user_id, Some(ctx.session_id), response.clone());
        return Ok(types::messages_affected_history(my_pts, 1, 0));
    }
    if chat.kind == "basic_group" {
        let Some(basic_chat) = repo::find_channel(ctx.db, chat.id)
            .await
            .map_err(RpcFailure::internal)?
        else {
            return Err(RpcFailure::new(400, "CHAT_ID_INVALID"));
        };
        let peer_bytes = types::peer_chat(chat.id);
        let mut my_pts = 0;
        for member_id in repo::chat_member_ids(ctx.db, chat.id)
            .await
            .map_err(RpcFailure::internal)?
        {
            let pts = repo::bump_user_pts(ctx.db, member_id)
                .await
                .map_err(RpcFailure::internal)?;
            let update = types::update_pinned_messages(false, &peer_bytes, &ids, pts, 1);
            repo::log_user_update(ctx.db, member_id, pts, &update)
                .await
                .map_err(RpcFailure::internal)?;
            if member_id == user_id {
                my_pts = pts;
            } else {
                let push = types::updates_with_chats(
                    &[update],
                    &[],
                    &[chat_record_bytes(&basic_chat, member_id)],
                    timestamp,
                    0,
                );
                ctx.updates.publish(member_id, push);
            }
        }
        let self_push = types::updates_with_chats(
            &[types::update_pinned_messages(
                false,
                &peer_bytes,
                &ids,
                my_pts,
                1,
            )],
            &[],
            &[chat_record_bytes(&basic_chat, user_id)],
            timestamp,
            0,
        );
        ctx.updates
            .publish_excluding(user_id, Some(ctx.session_id), self_push);
        return Ok(types::messages_affected_history(my_pts, 1, 0));
    }
    let pts = repo::bump_channel_pts(ctx.db, chat.id)
        .await
        .map_err(RpcFailure::internal)?;
    let channel_update = types::update_pinned_channel_messages(false, chat.id, &ids, pts, 1);
    repo::log_channel_update(ctx.db, chat.id, pts, &channel_update)
        .await
        .map_err(RpcFailure::internal)?;
    for member_id in repo::chat_member_ids(ctx.db, chat.id)
        .await
        .map_err(RpcFailure::internal)?
    {
        let push = types::updates(std::slice::from_ref(&channel_update), &[], timestamp, 0);
        if member_id == user_id {
            ctx.updates
                .publish_excluding(member_id, Some(ctx.session_id), push);
        } else {
            ctx.updates.publish(member_id, push);
        }
    }
    Ok(types::messages_affected_history(pts, 1, 0))
}

async fn messages_delete_history(
    ctx: &RpcContext<'_>,
    reader: &mut Reader<'_>,
) -> Result<Vec<u8>, RpcFailure> {
    let flags = reader.u32()?;
    let peer = read_input_peer(ctx, reader)?;
    let max_id = i64::from(reader.i32()?);
    if flags & (1 << 2) != 0 {
        let _min_date = reader.i32()?;
    }
    if flags & (1 << 3) != 0 {
        let _max_date = reader.i32()?;
    }
    let Some(user_id) = ctx.user_id else {
        return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
    };
    let chat = match resolve_peer_chat(ctx, peer, user_id, true).await {
        Ok(chat) => chat,
        Err(_) if matches!(peer, PeerRef::User(_)) => {
            let pts = user_pts(ctx).await?;
            return Ok(types::messages_affected_history(pts, 0, 0));
        }
        Err(error) => return Err(error),
    };
    let ids = repo::history_message_ids(ctx.db, chat.id, max_id)
        .await
        .map_err(RpcFailure::internal)?;
    if ids.is_empty() {
        let pts = if chat.kind == "private" || chat.kind == "basic_group" {
            user_pts(ctx).await?
        } else {
            repo::channel_pts(ctx.db, chat.id)
                .await
                .map_err(RpcFailure::internal)?
        };
        return Ok(types::messages_affected_history(pts, 0, 0));
    }
    let (pts, count) = delete_messages_in_chat(ctx, &chat.id, &ids).await?;
    Ok(types::messages_affected_history(pts, count, 0))
}

async fn messages_delete_chat(
    ctx: &RpcContext<'_>,
    reader: &mut Reader<'_>,
) -> Result<Vec<u8>, RpcFailure> {
    let chat_id = reader.i64()?;
    let Some(user_id) = ctx.user_id else {
        return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
    };
    let Some(chat) = repo::find_channel(ctx.db, chat_id)
        .await
        .map_err(RpcFailure::internal)?
    else {
        return Ok(types::bool_true());
    };
    if chat.kind == "basic_group" && chat.owner_user_id != user_id {
        repo::remove_channel_member(ctx.db, chat.id, user_id)
            .await
            .map_err(RpcFailure::internal)?;
        return Ok(types::bool_true());
    }
    let ids = repo::history_message_ids(ctx.db, chat.id, 0)
        .await
        .map_err(RpcFailure::internal)?;
    if !ids.is_empty() {
        let _ = delete_messages_in_chat(ctx, &chat.id, &ids).await?;
    }
    repo::delete_dialog(ctx.db, user_id, chat.id)
        .await
        .map_err(RpcFailure::internal)?;
    Ok(types::bool_true())
}

async fn message_reactions_bytes(
    ctx: &RpcContext<'_>,
    message_id: i64,
    viewer_user_id: i64,
) -> Result<Option<Vec<u8>>, RpcFailure> {
    let rows = repo::list_message_reactions(ctx.db, message_id, viewer_user_id)
        .await
        .map_err(RpcFailure::internal)?;
    if rows.is_empty() {
        return Ok(None);
    }
    let results: Vec<Vec<u8>> = rows
        .iter()
        .map(|row| {
            types::reaction_count(&types::reaction_emoji(&row.emoticon), row.count, row.chosen)
        })
        .collect();
    Ok(Some(types::message_reactions(&results)))
}

async fn messages_send_reaction(
    ctx: &RpcContext<'_>,
    reader: &mut Reader<'_>,
) -> Result<Vec<u8>, RpcFailure> {
    let flags = reader.u32()?;
    let peer = read_input_peer(ctx, reader)?;
    let message_id = i64::from(reader.i32()?);
    let mut emoticon = None;
    if flags & 1 != 0 {
        reader.expect_constructor(ctor::VECTOR)?;
        let count = reader.i32()?;
        for _ in 0..count.max(0) {
            match reader.constructor()? {
                ctor::REACTION_EMOJI => emoticon = Some(reader.string()?),
                ctor::REACTION_CUSTOM_EMOJI => {
                    let _document_id = reader.i64()?;
                    return Err(RpcFailure::new(400, "REACTION_INVALID"));
                }
                other => {
                    return Err(RpcFailure::new(
                        400,
                        format!("UNSUPPORTED_REACTION_0x{other:08X}"),
                    ))
                }
            }
        }
        if count > 1 {
            return Err(RpcFailure::new(400, "REACTION_INVALID"));
        }
    }
    let Some(user_id) = ctx.user_id else {
        return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
    };
    let Some(record) = repo::find_message(ctx.db, message_id)
        .await
        .map_err(RpcFailure::internal)?
    else {
        return Err(RpcFailure::new(400, "MESSAGE_ID_INVALID"));
    };
    let chat = resolve_peer_chat(ctx, peer, user_id, false).await?;
    if record.chat_id != chat.id {
        return Err(RpcFailure::new(400, "MESSAGE_ID_INVALID"));
    }
    repo::set_message_reaction(ctx.db, message_id, user_id, emoticon.as_deref())
        .await
        .map_err(RpcFailure::internal)?;
    let timestamp = now() as i32;
    let mut response = types::updates(&[], &[], timestamp, 0);
    let viewers: Vec<(i64, Vec<u8>, Vec<u8>)> = if chat.kind == "private" {
        let (a, b) = private_pair(&chat)?;
        vec![
            (a, types::peer_user(b), Vec::new()),
            (b, types::peer_user(a), Vec::new()),
        ]
    } else {
        let Some(channel) = repo::find_channel(ctx.db, chat.id)
            .await
            .map_err(RpcFailure::internal)?
        else {
            return Err(RpcFailure::new(400, "CHAT_ID_INVALID"));
        };
        let peer_bytes = if chat.kind == "basic_group" {
            types::peer_chat(chat.id)
        } else {
            types::peer_channel(chat.id)
        };
        repo::chat_member_ids(ctx.db, chat.id)
            .await
            .map_err(RpcFailure::internal)?
            .into_iter()
            .map(|member_id| {
                (
                    member_id,
                    peer_bytes.clone(),
                    chat_record_bytes(&channel, member_id),
                )
            })
            .collect()
    };
    for (viewer_id, peer_bytes, chat_bytes) in viewers {
        let reactions = message_reactions_bytes(ctx, message_id, viewer_id)
            .await?
            .unwrap_or_else(|| types::message_reactions(&[]));
        let update = types::update_message_reactions(&peer_bytes, message_id as i32, &reactions);
        let chats: Vec<Vec<u8>> = if chat_bytes.is_empty() {
            Vec::new()
        } else {
            vec![chat_bytes]
        };
        let payload = types::updates_with_chats(&[update], &[], &chats, timestamp, 0);
        if viewer_id == user_id {
            response = payload.clone();
            ctx.updates
                .publish_excluding(viewer_id, Some(ctx.session_id), payload);
        } else {
            ctx.updates.publish(viewer_id, payload);
        }
    }
    Ok(response)
}

fn peer_bytes_for_chat(chat: &repo::ChatInfo, user_id: i64) -> Result<Vec<u8>, RpcFailure> {
    match chat.kind.as_str() {
        "private" => {
            let (a, b) = private_pair(chat)?;
            let other = if a == user_id { b } else { a };
            Ok(types::peer_user(other))
        }
        "basic_group" => Ok(types::peer_chat(chat.id)),
        _ => Ok(types::peer_channel(chat.id)),
    }
}

/// Loads a poll media record for `message_id` in a chat the caller can access.
async fn load_poll_media(
    ctx: &RpcContext<'_>,
    peer: PeerRef,
    message_id: i64,
    user_id: i64,
) -> Result<(repo::ChatInfo, repo::MediaRecord, i64), RpcFailure> {
    let Some(record) = repo::find_message(ctx.db, message_id)
        .await
        .map_err(RpcFailure::internal)?
    else {
        return Err(RpcFailure::new(400, "MESSAGE_ID_INVALID"));
    };
    let chat = resolve_peer_chat(ctx, peer, user_id, false).await?;
    if record.chat_id != chat.id {
        return Err(RpcFailure::new(400, "MESSAGE_ID_INVALID"));
    }
    let Some(media_id) = record.media_id else {
        return Err(RpcFailure::new(400, "MESSAGE_ID_INVALID"));
    };
    let media = repo::find_media(ctx.db, media_id)
        .await
        .map_err(RpcFailure::internal)?
        .ok_or_else(|| RpcFailure::new(400, "MESSAGE_ID_INVALID"))?;
    if media.kind != "poll" {
        return Err(RpcFailure::new(400, "MESSAGE_ID_INVALID"));
    }
    Ok((chat, media, record.id))
}

async fn messages_send_vote(
    ctx: &RpcContext<'_>,
    reader: &mut Reader<'_>,
) -> Result<Vec<u8>, RpcFailure> {
    let peer = read_input_peer(ctx, reader)?;
    let message_id = i64::from(reader.i32()?);
    let options = reader.vector(|reader| reader.bytes())?;
    let Some(user_id) = ctx.user_id else {
        return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
    };
    let (chat, media, message_id) = load_poll_media(ctx, peer, message_id, user_id).await?;
    if payload_bool(&media.payload, "closed") {
        return Err(RpcFailure::new(403, "POLL_CLOSED"));
    }
    let allowed: Vec<Vec<u8>> = media
        .payload
        .get("answers")
        .and_then(|value| value.as_array())
        .map(|answers| {
            answers
                .iter()
                .map(|answer| {
                    json_option_bytes(answer.get("option").unwrap_or(&serde_json::Value::Null))
                })
                .collect()
        })
        .unwrap_or_default();
    let mut chosen: Vec<Vec<u8>> = Vec::new();
    for option in &options {
        if !allowed.iter().any(|allowed| allowed == option) {
            return Err(RpcFailure::new(400, "OPTION_INVALID"));
        }
        if !chosen.iter().any(|chosen| chosen == option) {
            chosen.push(option.clone());
        }
    }
    if chosen.len() > 1 && !payload_bool(&media.payload, "multiple_choice") {
        return Err(RpcFailure::new(400, "OPTIONS_TOO_MUCH"));
    }
    repo::replace_poll_vote(ctx.db, media.id, user_id, &chosen)
        .await
        .map_err(RpcFailure::internal)?;

    let timestamp = now() as i32;
    let mut response = types::updates(&[], &[], timestamp, 0);
    let viewers: Vec<(i64, Vec<u8>, Vec<u8>)> = if chat.kind == "private" {
        let (a, b) = private_pair(&chat)?;
        vec![
            (a, types::peer_user(b), Vec::new()),
            (b, types::peer_user(a), Vec::new()),
        ]
    } else {
        let Some(channel) = repo::find_channel(ctx.db, chat.id)
            .await
            .map_err(RpcFailure::internal)?
        else {
            return Err(RpcFailure::new(400, "CHAT_ID_INVALID"));
        };
        let peer_bytes = peer_bytes_for_chat(&chat, user_id)?;
        repo::chat_member_ids(ctx.db, chat.id)
            .await
            .map_err(RpcFailure::internal)?
            .into_iter()
            .map(|member_id| {
                (
                    member_id,
                    peer_bytes.clone(),
                    chat_record_bytes(&channel, member_id),
                )
            })
            .collect()
    };
    for (viewer_id, peer_bytes, chat_bytes) in viewers {
        let (poll, results, poll_id) = poll_media_parts(ctx, &media, Some(viewer_id)).await?;
        let update =
            types::update_message_poll(&peer_bytes, message_id as i32, &poll, poll_id, &results);
        let chats: Vec<Vec<u8>> = if chat_bytes.is_empty() {
            Vec::new()
        } else {
            vec![chat_bytes]
        };
        let payload = types::updates_with_chats(&[update], &[], &chats, timestamp, 0);
        if viewer_id == user_id {
            response = payload.clone();
            ctx.updates
                .publish_excluding(viewer_id, Some(ctx.session_id), payload);
        } else {
            ctx.updates.publish(viewer_id, payload);
        }
    }
    Ok(response)
}

async fn messages_get_poll_results(
    ctx: &RpcContext<'_>,
    reader: &mut Reader<'_>,
) -> Result<Vec<u8>, RpcFailure> {
    let peer = read_input_peer(ctx, reader)?;
    let message_id = i64::from(reader.i32()?);
    let _poll_hash = reader.i64()?;
    let Some(user_id) = ctx.user_id else {
        return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
    };
    let (chat, media, message_id) = load_poll_media(ctx, peer, message_id, user_id).await?;
    let (poll, results, poll_id) = poll_media_parts(ctx, &media, Some(user_id)).await?;
    let peer_bytes = peer_bytes_for_chat(&chat, user_id)?;
    let update =
        types::update_message_poll(&peer_bytes, message_id as i32, &poll, poll_id, &results);
    let chats: Vec<Vec<u8>> = if chat.kind == "private" {
        Vec::new()
    } else {
        match repo::find_channel(ctx.db, chat.id)
            .await
            .map_err(RpcFailure::internal)?
        {
            Some(channel) => vec![chat_record_bytes(&channel, user_id)],
            None => Vec::new(),
        }
    };
    Ok(types::updates_with_chats(
        &[update],
        &[],
        &chats,
        now() as i32,
        0,
    ))
}

async fn messages_get_messages(
    ctx: &RpcContext<'_>,
    reader: &mut Reader<'_>,
) -> Result<Vec<u8>, RpcFailure> {
    let ids = read_input_message_ids(reader)?;
    get_messages_for_user(ctx, &ids, None).await
}

async fn channels_get_messages(
    ctx: &RpcContext<'_>,
    reader: &mut Reader<'_>,
) -> Result<Vec<u8>, RpcFailure> {
    let (channel_id, access_hash) = read_input_channel(reader)?;
    let ids = read_input_message_ids(reader)?;
    let Some(channel) = repo::find_channel(ctx.db, channel_id)
        .await
        .map_err(RpcFailure::internal)?
    else {
        return Err(RpcFailure::new(400, "CHANNEL_INVALID"));
    };
    if channel.access_hash != 0 && channel.access_hash != access_hash {
        return Err(RpcFailure::new(400, "CHANNEL_INVALID"));
    }
    let Some(user_id) = ctx.user_id else {
        return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
    };
    if repo::channel_membership(ctx.db, channel_id, user_id)
        .await
        .map_err(RpcFailure::internal)?
        .is_none()
    {
        return Err(RpcFailure::new(403, "CHANNEL_PRIVATE"));
    }
    get_messages_for_user(ctx, &ids, Some((channel, user_id))).await
}

fn read_input_message_ids(reader: &mut Reader<'_>) -> Result<Vec<i64>, RpcFailure> {
    reader.expect_constructor(ctor::VECTOR)?;
    let count = reader.i32()?.max(0) as usize;
    let mut ids = Vec::with_capacity(count);
    for _ in 0..count {
        match reader.constructor()? {
            ctor::INPUT_MESSAGE_ID => ids.push(i64::from(reader.i32()?)),
            0x8687_2538 => {} // inputMessagePinned
            other => {
                return Err(RpcFailure::new(
                    400,
                    format!("UNSUPPORTED_INPUT_MESSAGE_0x{other:08X}"),
                ))
            }
        }
    }
    Ok(ids)
}

async fn get_messages_for_user(
    ctx: &RpcContext<'_>,
    ids: &[i64],
    channel_filter: Option<(repo::ChannelRecord, i64)>,
) -> Result<Vec<u8>, RpcFailure> {
    let Some(user_id) = ctx.user_id else {
        return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
    };
    let records = repo::find_messages(ctx.db, ids)
        .await
        .map_err(RpcFailure::internal)?;
    let mut messages = Vec::new();
    let mut chats = Vec::new();
    let mut users = Vec::new();
    let mut seen_users = std::collections::HashSet::new();
    let mut seen_chats = std::collections::HashSet::new();
    for record in &records {
        let Some(chat) = repo::find_chat(ctx.db, record.chat_id)
            .await
            .map_err(RpcFailure::internal)?
        else {
            continue;
        };
        if let Some((channel, _)) = &channel_filter {
            if chat.id != channel.id {
                continue;
            }
        } else if chat.kind == "private" {
            if !private_pair_contains(&chat, user_id) {
                continue;
            }
        } else if repo::channel_membership(ctx.db, chat.id, user_id)
            .await
            .map_err(RpcFailure::internal)?
            .is_none()
        {
            continue;
        }
        let media = load_media_bytes(ctx, record.media_id).await?;
        let pinned_id = repo::pinned_message_id(ctx.db, chat.id)
            .await
            .map_err(RpcFailure::internal)?;
        let reactions = message_reactions_bytes(ctx, record.id, user_id).await?;
        if chat.kind == "private" {
            let peer_id = if let Some((channel, _)) = &channel_filter {
                let _ = channel;
                user_id
            } else if chat.private_user_a == Some(user_id) {
                chat.private_user_b.unwrap_or(user_id)
            } else {
                chat.private_user_a.unwrap_or(user_id)
            };
            messages.push(private_message_record(
                record,
                record.sender_user_id == user_id,
                peer_id,
                media.as_deref(),
                pinned_id,
                reactions.as_deref(),
            ));
        } else if chat.kind == "basic_group" {
            messages.push(chat_message_or_service(
                record,
                record.sender_user_id == user_id,
                chat.id,
                media.as_deref(),
                pinned_id,
                reactions.as_deref(),
            ));
            if channel_filter.is_none() && seen_chats.insert(chat.id) {
                if let Some(basic_chat) = repo::find_channel(ctx.db, chat.id)
                    .await
                    .map_err(RpcFailure::internal)?
                {
                    chats.push(chat_record_bytes(&basic_chat, user_id));
                }
            }
        } else {
            messages.push(channel_message_record(
                record,
                record.sender_user_id == user_id,
                chat.id,
                media.as_deref(),
                pinned_id,
                reactions.as_deref(),
            ));
            if channel_filter.is_none() && seen_chats.insert(chat.id) {
                if let Some(channel) = repo::find_channel(ctx.db, chat.id)
                    .await
                    .map_err(RpcFailure::internal)?
                {
                    chats.push(channel_bytes(&channel, user_id));
                }
            }
        }
        if seen_users.insert(record.sender_user_id) && record.sender_user_id != user_id {
            if let Some(sender) = repo::find_user_by_id(ctx.db, record.sender_user_id)
                .await
                .map_err(RpcFailure::internal)?
            {
                users.push(other_user_bytes(&sender));
            }
        }
    }
    if let Some((channel, _)) = channel_filter {
        chats.push(channel_bytes(&channel, user_id));
    }
    Ok(types::messages_messages(&messages, &chats, &users))
}

async fn messages_get_message_views(
    ctx: &RpcContext<'_>,
    reader: &mut Reader<'_>,
) -> Result<Vec<u8>, RpcFailure> {
    let peer = read_input_peer(ctx, reader)?;
    let ids: Vec<i64> = reader
        .vector(|reader| reader.i32())?
        .into_iter()
        .map(i64::from)
        .collect();
    let increment = reader.bool()?;
    let Some(user_id) = ctx.user_id else {
        return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
    };
    let chat = resolve_peer_chat(ctx, peer, user_id, false).await?;
    if increment && chat.kind != "private" {
        repo::increment_message_views(ctx.db, chat.id, &ids)
            .await
            .map_err(RpcFailure::internal)?;
    }
    let views = repo::message_views(ctx.db, chat.id, &ids)
        .await
        .map_err(RpcFailure::internal)?;
    let mut chats = Vec::new();
    let mut users = Vec::new();
    if chat.kind == "private" {
        let (a, b) = private_pair(&chat)?;
        let other = if a == user_id { b } else { a };
        if let Some(user) = repo::find_user_by_id(ctx.db, other)
            .await
            .map_err(RpcFailure::internal)?
        {
            users.push(other_user_bytes(&user));
        }
    } else if let Some(channel) = repo::find_channel(ctx.db, chat.id)
        .await
        .map_err(RpcFailure::internal)?
    {
        chats.push(channel_bytes(&channel, user_id));
    }
    let counts: Vec<i32> = views.iter().map(|(_, count)| *count as i32).collect();
    Ok(types::messages_message_views(&counts, &chats, &users))
}

fn message_extras_from_record(
    record: &repo::MessageRecord,
    pinned_id: i64,
    reactions: Option<&[u8]>,
) -> types::MessageExtras {
    types::MessageExtras {
        reply_to_msg_id: record.reply_to_msg_id.map(|id| id as i32),
        fwd_from_user_id: record.fwd_from_user_id,
        fwd_from_chat_id: record.fwd_from_chat_id,
        fwd_from_msg_id: record.fwd_from_msg_id.map(|id| id as i32),
        fwd_date: record.fwd_date as i32,
        edit_date: record.edit_date as i32,
        pinned: pinned_id == record.id,
        reactions: reactions.map(|bytes| bytes.to_vec()),
        grouped_id: record.grouped_id,
        views: record.views as i32,
        entities: record.entities.clone(),
        reply_markup: record
            .reply_markup
            .as_ref()
            .and_then(reply_markup_bytes),
    }
}

/// Converts a Bot API `ReplyMarkup` JSON object into the TL
/// `replyInlineMarkup` constructor tree.
fn reply_markup_bytes(value: &serde_json::Value) -> Option<Vec<u8>> {
    let rows = value.get("inline_keyboard")?.as_array()?;
    let mut writer = Writer::new();
    writer.u32(0x48a3_0254); // replyInlineMarkup
    writer.i32(rows.len() as i32);
    for row in rows {
        let buttons = row.as_array()?;
        writer.u32(0x7760_8b83); // keyboardButtonRow
        writer.i32(buttons.len() as i32);
        for button in buttons {
            let text = button.get("text").and_then(|value| value.as_str()).unwrap_or("");
            if let Some(url) = button.get("url").and_then(|value| value.as_str()) {
                writer.u32(0x258a_ff05); // keyboardButtonUrl
                writer.string(text);
                writer.string(url);
            } else if let Some(data) = button.get("callback_data").and_then(|value| value.as_str()) {
                writer.u32(0x35bb_db6b); // keyboardButtonCallback
                writer.u32(0);
                writer.string(text);
                writer.bytes(data.as_bytes());
            } else {
                writer.u32(0xa2fa_4880); // keyboardButton
                writer.string(text);
            }
        }
    }
    Some(writer.into_bytes())
}

#[allow(clippy::too_many_arguments)]
fn private_message_record(
    record: &repo::MessageRecord,
    out: bool,
    peer_user_id: i64,
    media: Option<&[u8]>,
    pinned_id: i64,
    reactions: Option<&[u8]>,
) -> Vec<u8> {
    types::message_ext(
        record.id as i32,
        out,
        record.sender_user_id,
        peer_user_id,
        record.sent_at as i32,
        &record.text,
        media,
        &message_extras_from_record(record, pinned_id, reactions),
    )
}

#[allow(clippy::too_many_arguments)]
fn channel_message_record(
    record: &repo::MessageRecord,
    out: bool,
    channel_id: i64,
    media: Option<&[u8]>,
    pinned_id: i64,
    reactions: Option<&[u8]>,
) -> Vec<u8> {
    types::message_channel_ext(
        record.id as i32,
        out,
        record.sender_user_id,
        channel_id,
        record.sent_at as i32,
        &record.text,
        media,
        &message_extras_from_record(record, pinned_id, reactions),
    )
}

fn private_message(
    id: i32,
    out: bool,
    sender_user_id: i64,
    peer_user_id: i64,
    date: i32,
    text: &str,
    media: Option<&[u8]>,
) -> Vec<u8> {
    match media {
        Some(media) => {
            types::message_media(id, out, sender_user_id, peer_user_id, date, text, media)
        }
        None => types::message(id, out, sender_user_id, peer_user_id, date, text),
    }
}

#[allow(clippy::too_many_arguments)]
fn channel_message(
    id: i32,
    out: bool,
    sender_user_id: i64,
    channel_id: i64,
    date: i32,
    text: &str,
    media: Option<&[u8]>,
) -> Vec<u8> {
    match media {
        Some(media) => {
            types::message_channel_media(id, out, sender_user_id, channel_id, date, text, media)
        }
        None => types::message_channel(id, out, sender_user_id, channel_id, date, text),
    }
}

fn chat_record_bytes(record: &repo::ChannelRecord, viewer_user_id: i64) -> Vec<u8> {
    let photo = (record.photo_media_id > 0).then(|| types::chat_photo(record.photo_media_id, 2));
    types::chat(
        record.id,
        &record.title,
        record.owner_user_id == viewer_user_id,
        record.participants_count as i32,
        now() as i32,
        photo.as_deref(),
    )
}

#[allow(clippy::too_many_arguments)]
fn chat_message_record(
    record: &repo::MessageRecord,
    out: bool,
    chat_id: i64,
    media: Option<&[u8]>,
    pinned_id: i64,
    reactions: Option<&[u8]>,
) -> Vec<u8> {
    types::message_chat_ext(
        record.id as i32,
        out,
        record.sender_user_id,
        chat_id,
        record.sent_at as i32,
        &record.text,
        media,
        &message_extras_from_record(record, pinned_id, reactions),
    )
}

#[allow(clippy::too_many_arguments)]
fn chat_message_or_service(
    record: &repo::MessageRecord,
    out: bool,
    chat_id: i64,
    media: Option<&[u8]>,
    pinned_id: i64,
    reactions: Option<&[u8]>,
) -> Vec<u8> {
    let action = match record.action_kind.as_str() {
        "create" => Some(types::message_action_chat_create(
            &record.action_title,
            &[record.sender_user_id],
        )),
        "edit_title" => Some(types::message_action_chat_edit_title(&record.action_title)),
        "add_user" => Some(types::message_action_chat_add_user(
            &[record.action_user_id],
        )),
        "delete_user" => Some(types::message_action_chat_delete_user(
            record.action_user_id,
        )),
        _ => None,
    };
    match action {
        Some(action) => types::message_service(
            record.id as i32,
            out,
            record.sender_user_id,
            chat_id,
            record.sent_at as i32,
            &action,
        ),
        None => chat_message_record(record, out, chat_id, media, pinned_id, reactions),
    }
}

fn chat_message(
    id: i32,
    out: bool,
    sender_user_id: i64,
    chat_id: i64,
    date: i32,
    text: &str,
    media: Option<&[u8]>,
) -> Vec<u8> {
    match media {
        Some(media) => {
            types::message_chat_media(id, out, sender_user_id, chat_id, date, text, media)
        }
        None => types::message_chat(id, out, sender_user_id, chat_id, date, text),
    }
}

fn thumbnail_values(assembled: &media::AssembledFile) -> (&str, i32, i32, i64) {
    let primary = assembled
        .thumbnails
        .iter()
        .find(|thumbnail| thumbnail.kind == "m")
        .or_else(|| assembled.thumbnails.first());
    match primary {
        Some(thumbnail) => (
            &thumbnail.storage_key,
            thumbnail.width,
            thumbnail.height,
            thumbnail.size,
        ),
        None => ("", 0, 0, 0),
    }
}

fn thumbnail_inputs(assembled: &media::AssembledFile) -> Vec<repo::MediaThumbInput> {
    assembled
        .thumbnails
        .iter()
        .map(|thumbnail| repo::MediaThumbInput {
            kind: thumbnail.kind.clone(),
            storage_key: thumbnail.storage_key.clone(),
            width: thumbnail.width,
            height: thumbnail.height,
            size: thumbnail.size,
        })
        .collect()
}

fn photo_sizes(record: &repo::MediaRecord) -> Vec<Vec<u8>> {
    let mut sizes = Vec::with_capacity(record.thumbs.len() + 2);
    for thumb in &record.thumbs {
        // "x" is the full-resolution entry for photos; the generated 640px
        // preview is only used for documents.
        if thumb.kind == "x" {
            continue;
        }
        sizes.push(types::photo_size(
            &thumb.kind,
            thumb.width,
            thumb.height,
            thumb.size,
        ));
    }
    if record.thumbs.is_empty() && record.thumb_width > 0 && record.thumb_height > 0 {
        sizes.push(types::photo_size(
            "m",
            record.thumb_width,
            record.thumb_height,
            record.thumb_size,
        ));
    }
    sizes.push(types::photo_size(
        "x",
        record.width,
        record.height,
        record.size,
    ));
    sizes
}

fn document_thumb_sizes(record: &repo::MediaRecord) -> Vec<Vec<u8>> {
    let mut thumbs = Vec::with_capacity(record.thumbs.len() + 1);
    for thumb in &record.thumbs {
        thumbs.push(types::photo_size(
            &thumb.kind,
            thumb.width,
            thumb.height,
            thumb.size,
        ));
    }
    if record.thumbs.is_empty() && record.thumb_width > 0 && record.thumb_height > 0 {
        thumbs.push(types::photo_size(
            "m",
            record.thumb_width,
            record.thumb_height,
            record.thumb_size,
        ));
    }
    thumbs
}

fn photo_object(record: &repo::MediaRecord) -> Vec<u8> {
    types::photo(
        record.id,
        record.access_hash,
        &record.file_reference,
        record.created_at as i32,
        &photo_sizes(record),
        FILE_DC_ID,
    )
}

fn payload_i64(payload: &serde_json::Value, key: &str) -> i64 {
    payload.get(key).and_then(|value| value.as_i64()).unwrap_or(0)
}

fn payload_i32(payload: &serde_json::Value, key: &str) -> i32 {
    payload
        .get(key)
        .and_then(|value| value.as_i64())
        .unwrap_or(0) as i32
}

fn payload_str(payload: &serde_json::Value, key: &str) -> String {
    payload
        .get(key)
        .and_then(|value| value.as_str())
        .unwrap_or("")
        .to_owned()
}

fn payload_f64(payload: &serde_json::Value, key: &str) -> f64 {
    payload
        .get(key)
        .and_then(|value| value.as_f64())
        .unwrap_or(0.0)
}

fn payload_bool(payload: &serde_json::Value, key: &str) -> bool {
    payload
        .get(key)
        .and_then(|value| value.as_bool())
        .unwrap_or(false)
}

fn json_option_bytes(value: &serde_json::Value) -> Vec<u8> {
    value
        .as_array()
        .map(|items| {
            items
                .iter()
                .filter_map(|item| item.as_u64().map(|byte| byte as u8))
                .collect()
        })
        .unwrap_or_default()
}

/// Builds the `poll` object and the viewer-specific `pollResults` for a stored
/// poll media record.
async fn poll_media_parts(
    ctx: &RpcContext<'_>,
    record: &repo::MediaRecord,
    viewer: Option<i64>,
) -> Result<(Vec<u8>, Vec<u8>, i64), RpcFailure> {
    let payload = &record.payload;
    let poll_id = payload_i64(payload, "id");
    let question = payload_str(payload, "question");
    let mut flags = 0u32;
    if payload_bool(payload, "closed") {
        flags |= 1 << 0;
    }
    if payload_bool(payload, "public_voters") {
        flags |= 1 << 1;
    }
    if payload_bool(payload, "multiple_choice") {
        flags |= 1 << 2;
    }
    if payload_bool(payload, "quiz") {
        flags |= 1 << 3;
    }
    let close_period = payload_i32(payload, "close_period");
    let close_date = payload_i32(payload, "close_date");
    if close_period > 0 {
        flags |= 1 << 4;
    }
    if close_date > 0 {
        flags |= 1 << 5;
    }
    let answers = payload
        .get("answers")
        .and_then(|value| value.as_array())
        .cloned()
        .unwrap_or_default();
    let mut answer_bytes = Vec::with_capacity(answers.len());
    let mut answer_options = Vec::with_capacity(answers.len());
    for answer in &answers {
        let option = json_option_bytes(answer.get("option").unwrap_or(&serde_json::Value::Null));
        answer_bytes.push(types::poll_answer(
            answer.get("text").and_then(|value| value.as_str()).unwrap_or(""),
            &option,
        ));
        answer_options.push(option);
    }
    let poll = types::poll(
        poll_id,
        flags,
        &question,
        &answer_bytes,
        close_period,
        close_date,
    );

    let counts = repo::poll_option_counts(ctx.db, record.id)
        .await
        .map_err(RpcFailure::internal)?;
    let total = repo::poll_voter_total(ctx.db, record.id)
        .await
        .map_err(RpcFailure::internal)?;
    let mine = match viewer {
        Some(user_id) => repo::poll_user_options(ctx.db, record.id, user_id)
            .await
            .map_err(RpcFailure::internal)?,
        None => Vec::new(),
    };
    let correct: HashSet<Vec<u8>> = payload
        .get("correct_options")
        .and_then(|value| value.as_array())
        .map(|items| items.iter().map(json_option_bytes).collect())
        .unwrap_or_default();
    let closed = flags & 1 != 0;
    let mut options = Vec::with_capacity(answer_options.len());
    for option in &answer_options {
        let voters = counts
            .iter()
            .find(|(stored, _)| stored == option)
            .map(|(_, count)| *count)
            .unwrap_or(0);
        let chosen = mine.iter().any(|mine| mine == option);
        options.push(types::poll_answer_voters(
            option,
            voters as i32,
            chosen,
            closed && correct.contains(option),
        ));
    }
    let results = types::poll_results(&options, total as i32);
    Ok((poll, results, poll_id))
}

async fn media_bytes(
    ctx: &RpcContext<'_>,
    record: &repo::MediaRecord,
    viewer: Option<i64>,
) -> Result<Vec<u8>, RpcFailure> {
    match record.kind.as_str() {
        "poll" => {
            let (poll, results, _) = poll_media_parts(ctx, record, viewer).await?;
            return Ok(types::message_media_poll(&poll, &results));
        }
        "geo" => {
            return Ok(types::message_media_geo(&types::geo_point(
                payload_f64(&record.payload, "lat"),
                payload_f64(&record.payload, "long"),
                payload_i64(&record.payload, "access_hash"),
                payload_i32(&record.payload, "accuracy_radius"),
            )));
        }
        "contact" => {
            return Ok(types::message_media_contact(
                &payload_str(&record.payload, "phone_number"),
                &payload_str(&record.payload, "first_name"),
                &payload_str(&record.payload, "last_name"),
                &payload_str(&record.payload, "vcard"),
                payload_i64(&record.payload, "user_id"),
            ));
        }
        "dice" => {
            return Ok(types::message_media_dice(
                payload_i32(&record.payload, "value"),
                &payload_str(&record.payload, "emoticon"),
            ));
        }
        _ => {}
    }
    if record.kind == "photo" {
        return Ok(types::message_media_photo(&photo_object(record)));
    }

    let is_video = record.kind == "video";
    let is_sticker = record.sticker || record.custom_emoji;
    let mut attributes = Vec::with_capacity(5);
    if !is_sticker {
        attributes.push(types::document_attribute_filename(
            if record.file_name.is_empty() {
                "file"
            } else {
                &record.file_name
            },
        ));
        if record.width > 0 && record.height > 0 {
            attributes.push(types::document_attribute_image_size(
                record.width,
                record.height,
            ));
        }
    }
    if is_video {
        attributes.push(types::document_attribute_video(
            record.duration as f64,
            record.width,
            record.height,
            true,
        ));
    }
    if record.audio_voice || !record.audio_title.is_empty() || !record.audio_performer.is_empty() {
        attributes.push(types::document_attribute_audio(
            record.audio_voice,
            record.duration,
            &record.audio_title,
            &record.audio_performer,
            &record.audio_waveform,
        ));
    }
    if record.mime_type == "image/gif" {
        attributes.push(types::document_attribute_animated());
    }
    if record.sticker {
        attributes.push(types::document_attribute_sticker(
            &record.sticker_alt,
            record.sticker_set_id,
            record.sticker_set_access_hash,
        ));
    } else if record.custom_emoji {
        attributes.push(types::document_attribute_custom_emoji(
            &record.custom_emoji_alt,
            record.sticker_set_id,
            record.sticker_set_access_hash,
            false,
        ));
    }
    let thumbs = document_thumb_sizes(record);
    let document = types::document(
        record.id,
        record.access_hash,
        &record.file_reference,
        record.created_at as i32,
        &record.mime_type,
        record.size,
        &thumbs,
        FILE_DC_ID,
        &attributes,
    );
    Ok(types::message_media_document(&document, is_video))
}

async fn load_media_bytes(
    ctx: &RpcContext<'_>,
    media_id: Option<i64>,
) -> Result<Option<Vec<u8>>, RpcFailure> {
    let Some(media_id) = media_id else {
        return Ok(None);
    };
    let Some(record) = repo::find_media(ctx.db, media_id)
        .await
        .map_err(RpcFailure::internal)?
    else {
        return Ok(None);
    };
    Ok(Some(media_bytes(ctx, &record, ctx.user_id).await?))
}

#[derive(Debug, Clone)]
struct InputFileRef {
    id: i64,
    parts: i32,
    name: String,
}

#[derive(Debug, Clone)]
enum ParsedAttribute {
    Filename(String),
    ImageSize {
        width: i32,
        height: i32,
    },
    Video {
        duration: f64,
        width: i32,
        height: i32,
    },
    Audio {
        voice: bool,
        duration: i32,
        title: String,
        performer: String,
        waveform: Vec<u8>,
    },
    Animated,
    Sticker {
        alt: String,
        set_id: i64,
        set_access_hash: i64,
    },
    CustomEmoji {
        alt: String,
        set_id: i64,
        set_access_hash: i64,
    },
}

#[derive(Debug, Clone)]
struct ParsedPoll {
    id: i64,
    /// Poll flags: closed(0) / public_voters(1) / multiple_choice(2) / quiz(3).
    flags: u32,
    question: String,
    answers: Vec<(String, Vec<u8>)>,
    close_period: i32,
    close_date: i32,
    correct_indexes: Vec<i32>,
}

enum InputMediaRef {
    UploadedPhoto {
        file: InputFileRef,
    },
    UploadedDocument {
        file: InputFileRef,
        mime_type: String,
        attributes: Vec<ParsedAttribute>,
    },
    ExistingPhoto {
        id: i64,
    },
    ExistingDocument {
        id: i64,
    },
    Poll {
        poll: ParsedPoll,
    },
    Geo {
        lat: f64,
        long: f64,
        accuracy_radius: i32,
    },
    Contact {
        phone_number: String,
        first_name: String,
        last_name: String,
        vcard: String,
    },
    Dice {
        emoticon: String,
    },
    Empty,
}

fn read_input_file(reader: &mut Reader<'_>) -> Result<InputFileRef, RpcFailure> {
    match reader.constructor()? {
        ctor::INPUT_FILE => {
            let id = reader.i64()?;
            let parts = reader.i32()?;
            let name = reader.string()?;
            let _md5_checksum = reader.string()?;
            Ok(InputFileRef { id, parts, name })
        }
        ctor::INPUT_FILE_BIG => {
            let id = reader.i64()?;
            let parts = reader.i32()?;
            let name = reader.string()?;
            Ok(InputFileRef { id, parts, name })
        }
        other => Err(RpcFailure::new(
            400,
            format!("UNSUPPORTED_INPUT_FILE_0x{other:08X}"),
        )),
    }
}

fn skip_input_document(reader: &mut Reader<'_>) -> Result<(), RpcFailure> {
    if reader.constructor()? != 0x1abf_b575 {
        return Err(RpcFailure::new(400, "UNSUPPORTED_INPUT_DOCUMENT"));
    }
    let _id = reader.i64()?;
    let _access_hash = reader.i64()?;
    let _file_reference = reader.bytes()?;
    Ok(())
}

fn skip_input_photo(reader: &mut Reader<'_>) -> Result<(), RpcFailure> {
    let _id = read_input_photo_id(reader)?;
    Ok(())
}

fn read_input_photo_id(reader: &mut Reader<'_>) -> Result<i64, RpcFailure> {
    if reader.constructor()? != 0x3bb3_b94a {
        return Err(RpcFailure::new(400, "UNSUPPORTED_INPUT_PHOTO"));
    }
    let id = reader.i64()?;
    let _access_hash = reader.i64()?;
    let _file_reference = reader.bytes()?;
    Ok(id)
}

fn read_input_document_id(reader: &mut Reader<'_>) -> Result<i64, RpcFailure> {
    if reader.constructor()? != 0x1abf_b575 {
        return Err(RpcFailure::new(400, "UNSUPPORTED_INPUT_DOCUMENT"));
    }
    let id = reader.i64()?;
    let _access_hash = reader.i64()?;
    let _file_reference = reader.bytes()?;
    Ok(id)
}

fn skip_input_documents(reader: &mut Reader<'_>, present: bool) -> Result<(), RpcFailure> {
    if !present {
        return Ok(());
    }
    reader.expect_constructor(ctor::VECTOR)?;
    let count = reader.i32()?.max(0);
    for _ in 0..count {
        skip_input_document(reader)?;
    }
    Ok(())
}

fn read_input_sticker_set_id(reader: &mut Reader<'_>) -> Result<(i64, i64), RpcFailure> {
    match reader.constructor()? {
        ctor::INPUT_STICKER_SET_ID => Ok((reader.i64()?, reader.i64()?)),
        ctor::INPUT_STICKER_SET_SHORT_NAME => {
            let _short_name = reader.string()?;
            Ok((0, 0))
        }
        ctor::INPUT_STICKER_SET_EMPTY => Ok((0, 0)),
        other => Err(RpcFailure::new(
            400,
            format!("UNSUPPORTED_INPUT_STICKER_SET_0x{other:08X}"),
        )),
    }
}

fn read_text_with_entities(reader: &mut Reader<'_>) -> Result<String, RpcFailure> {
    reader.expect_constructor(ctor::TEXT_WITH_ENTITIES)?;
    let text = reader.string()?;
    read_message_entities(reader, &text)?;
    Ok(text)
}

fn skip_peer(reader: &mut Reader<'_>) -> Result<(), RpcFailure> {
    match reader.constructor()? {
        ctor::PEER_USER | ctor::PEER_CHANNEL => {
            let _user_id = reader.i64()?;
            let _access_hash = reader.i64()?;
            Ok(())
        }
        ctor::PEER_CHAT => {
            let _chat_id = reader.i64()?;
            Ok(())
        }
        other => Err(RpcFailure::new(
            400,
            format!("UNSUPPORTED_PEER_0x{other:08X}"),
        )),
    }
}

fn read_poll(reader: &mut Reader<'_>) -> Result<ParsedPoll, RpcFailure> {
    reader.expect_constructor(ctor::POLL)?;
    let id = reader.i64()?;
    let flags = reader.u32()?;
    let question = read_text_with_entities(reader)?;
    reader.expect_constructor(ctor::VECTOR)?;
    let count = reader.i32()?.max(0);
    let mut answers = Vec::with_capacity(count as usize);
    for _ in 0..count {
        reader.expect_constructor(ctor::POLL_ANSWER)?;
        let answer_flags = reader.u32()?;
        let text = read_text_with_entities(reader)?;
        let option = reader.bytes()?;
        if answer_flags & (1 << 0) != 0 {
            return Err(RpcFailure::new(400, "POLL_ANSWER_MEDIA_UNSUPPORTED"));
        }
        if answer_flags & (1 << 1) != 0 {
            skip_peer(reader)?;
            let _date = reader.i32()?;
        }
        answers.push((text, option));
    }
    let close_period = if flags & (1 << 4) != 0 {
        reader.i32()?
    } else {
        0
    };
    let close_date = if flags & (1 << 5) != 0 {
        reader.i32()?
    } else {
        0
    };
    if flags & (1 << 12) != 0 {
        let _countries = reader.vector(|reader| reader.string())?;
    }
    let _hash = reader.i64()?;
    Ok(ParsedPoll {
        id,
        flags,
        question,
        answers,
        close_period,
        close_date,
        correct_indexes: Vec::new(),
    })
}

fn read_document_attribute(reader: &mut Reader<'_>) -> Result<ParsedAttribute, RpcFailure> {
    match reader.constructor()? {
        ctor::DOCUMENT_ATTRIBUTE_FILENAME => Ok(ParsedAttribute::Filename(reader.string()?)),
        ctor::DOCUMENT_ATTRIBUTE_IMAGE_SIZE => Ok(ParsedAttribute::ImageSize {
            width: reader.i32()?,
            height: reader.i32()?,
        }),
        ctor::DOCUMENT_ATTRIBUTE_VIDEO => {
            let flags = reader.u32()?;
            let duration = reader.f64()?;
            let width = reader.i32()?;
            let height = reader.i32()?;
            if flags & (1 << 2) != 0 {
                let _preload_prefix_size = reader.i32()?;
            }
            if flags & (1 << 4) != 0 {
                let _video_start_ts = reader.f64()?;
            }
            if flags & (1 << 5) != 0 {
                let _video_codec = reader.string()?;
            }
            Ok(ParsedAttribute::Video {
                duration,
                width,
                height,
            })
        }
        ctor::DOCUMENT_ATTRIBUTE_ANIMATED => Ok(ParsedAttribute::Animated),
        ctor::DOCUMENT_ATTRIBUTE_STICKER => {
            let flags = reader.u32()?;
            let alt = reader.string()?;
            let (set_id, set_access_hash) = read_input_sticker_set_id(reader)?;
            if flags & (1 << 0) != 0 {
                let _mask_n = reader.i32()?;
                let _mask_x = reader.f64()?;
                let _mask_y = reader.f64()?;
                let _mask_zoom = reader.f64()?;
            }
            Ok(ParsedAttribute::Sticker {
                alt,
                set_id,
                set_access_hash,
            })
        }
        ctor::DOCUMENT_ATTRIBUTE_CUSTOM_EMOJI => {
            let _flags = reader.u32()?;
            let alt = reader.string()?;
            let (set_id, set_access_hash) = read_input_sticker_set_id(reader)?;
            Ok(ParsedAttribute::CustomEmoji {
                alt,
                set_id,
                set_access_hash,
            })
        }
        0x9801_d2f7 => Ok(ParsedAttribute::Animated), // documentAttributeHasStickers
        0x9852_f9c6 => {
            // documentAttributeAudio
            let flags = reader.u32()?;
            let duration = reader.i32()?;
            let title = if flags & (1 << 0) != 0 {
                reader.string()?
            } else {
                String::new()
            };
            let performer = if flags & (1 << 1) != 0 {
                reader.string()?
            } else {
                String::new()
            };
            let waveform = if flags & (1 << 2) != 0 {
                reader.bytes()?
            } else {
                Vec::new()
            };
            Ok(ParsedAttribute::Audio {
                voice: flags & (1 << 10) != 0,
                duration,
                title,
                performer,
                waveform,
            })
        }
        other => Err(RpcFailure::new(
            400,
            format!("UNSUPPORTED_DOCUMENT_ATTRIBUTE_0x{other:08X}"),
        )),
    }
}

fn read_input_media(reader: &mut Reader<'_>) -> Result<InputMediaRef, RpcFailure> {
    match reader.constructor()? {
        ctor::INPUT_MEDIA_UPLOADED_PHOTO => {
            let flags = reader.u32()?;
            let file = read_input_file(reader)?;
            skip_input_documents(reader, flags & (1 << 0) != 0)?;
            if flags & (1 << 1) != 0 {
                let _ttl_seconds = reader.i32()?;
            }
            if flags & (1 << 3) != 0 {
                skip_input_document(reader)?;
            }
            Ok(InputMediaRef::UploadedPhoto { file })
        }
        ctor::INPUT_MEDIA_UPLOADED_DOCUMENT => {
            let flags = reader.u32()?;
            let file = read_input_file(reader)?;
            if flags & (1 << 2) != 0 {
                let _thumb = read_input_file(reader)?;
            }
            let mime_type = reader.string()?;
            reader.expect_constructor(ctor::VECTOR)?;
            let count = reader.i32()?.max(0) as usize;
            let mut attributes = Vec::with_capacity(count);
            for _ in 0..count {
                attributes.push(read_document_attribute(reader)?);
            }
            skip_input_documents(reader, flags & (1 << 0) != 0)?;
            if flags & (1 << 6) != 0 {
                skip_input_photo(reader)?;
            }
            if flags & (1 << 7) != 0 {
                let _video_timestamp = reader.i32()?;
            }
            if flags & (1 << 1) != 0 {
                let _ttl_seconds = reader.i32()?;
            }
            Ok(InputMediaRef::UploadedDocument {
                file,
                mime_type,
                attributes,
            })
        }
        ctor::INPUT_MEDIA_EMPTY => Ok(InputMediaRef::Empty),
        ctor::INPUT_MEDIA_PHOTO => {
            let flags = reader.u32()?;
            let id = read_input_photo_id(reader)?;
            if flags & (1 << 0) != 0 {
                let _ttl_seconds = reader.i32()?;
            }
            if flags & (1 << 2) != 0 {
                skip_input_document(reader)?;
            }
            Ok(InputMediaRef::ExistingPhoto { id })
        }
        ctor::INPUT_MEDIA_DOCUMENT => {
            let flags = reader.u32()?;
            let id = read_input_document_id(reader)?;
            if flags & (1 << 3) != 0 {
                skip_input_photo(reader)?;
            }
            if flags & (1 << 4) != 0 {
                let _video_timestamp = reader.i32()?;
            }
            if flags & (1 << 0) != 0 {
                let _ttl_seconds = reader.i32()?;
            }
            if flags & (1 << 1) != 0 {
                let _query = reader.string()?;
            }
            Ok(InputMediaRef::ExistingDocument { id })
        }
        ctor::INPUT_MEDIA_POLL => {
            let flags = reader.u32()?;
            let poll = read_poll(reader)?;
            let correct_indexes = if flags & (1 << 0) != 0 {
                reader.vector(|reader| reader.i32())?
            } else {
                Vec::new()
            };
            if flags & (1 << 3) != 0 {
                let _attached_media = read_input_media(reader)?;
            }
            if flags & (1 << 1) != 0 {
                let solution = reader.string()?;
                read_message_entities(reader, &solution)?;
            }
            if flags & (1 << 2) != 0 {
                let _solution_media = read_input_media(reader)?;
            }
            Ok(InputMediaRef::Poll {
                poll: ParsedPoll {
                    correct_indexes,
                    ..poll
                },
            })
        }
        ctor::INPUT_MEDIA_GEO_POINT => {
            reader.expect_constructor(ctor::INPUT_GEO_POINT)?;
            let geo_flags = reader.u32()?;
            let lat = reader.f64()?;
            let long = reader.f64()?;
            let accuracy_radius = if geo_flags & (1 << 0) != 0 {
                reader.i32()?
            } else {
                0
            };
            Ok(InputMediaRef::Geo {
                lat,
                long,
                accuracy_radius,
            })
        }
        ctor::INPUT_MEDIA_CONTACT => Ok(InputMediaRef::Contact {
            phone_number: reader.string()?,
            first_name: reader.string()?,
            last_name: reader.string()?,
            vcard: reader.string()?,
        }),
        ctor::INPUT_MEDIA_DICE => Ok(InputMediaRef::Dice {
            emoticon: reader.string()?,
        }),
        other => Err(RpcFailure::new(
            400,
            format!("UNSUPPORTED_INPUT_MEDIA_0x{other:08X}"),
        )),
    }
}

async fn assemble_upload(
    ctx: &RpcContext<'_>,
    owner_user_id: i64,
    file: &InputFileRef,
) -> Result<media::AssembledFile, RpcFailure> {
    let parts = repo::list_upload_parts(ctx.db, file.id, owner_user_id)
        .await
        .map_err(RpcFailure::internal)?;
    if parts.is_empty() {
        return Err(RpcFailure::new(400, "FILE_PART_MISSING"));
    }
    let assembled = media::assemble(
        &ctx.config.media_dir,
        file.id,
        &parts,
        file.parts,
        &file.name,
    )
    .await
    .map_err(RpcFailure::internal)?;
    repo::delete_upload_parts(ctx.db, file.id, owner_user_id)
        .await
        .map_err(RpcFailure::internal)?;
    Ok(assembled)
}

fn option_json(option: &[u8]) -> serde_json::Value {
    serde_json::Value::Array(
        option
            .iter()
            .map(|byte| serde_json::Value::from(*byte))
            .collect(),
    )
}

fn nonzero_i64() -> i64 {
    let mut value = rand::random::<i64>();
    if value == 0 {
        value = 1;
    }
    value
}

fn dice_value(emoticon: &str) -> Option<i32> {
    let max = match emoticon {
        "🎲" | "🎯" | "🎳" => 6,
        "🏀" | "⚽" | "🍒" | "🍌" | "🥁" | "💣" => 5,
        "🎰" => 64,
        _ => return None,
    };
    Some((rand::random::<u32>() % max as u32) as i32 + 1)
}

async fn materialize_input_media(
    ctx: &RpcContext<'_>,
    owner_user_id: i64,
    input: InputMediaRef,
) -> Result<Option<repo::MediaRecord>, RpcFailure> {
    match input {
        InputMediaRef::Empty => Ok(None),
        InputMediaRef::Poll { poll } => {
            if poll.question.trim().is_empty() {
                return Err(RpcFailure::new(400, "POLL_QUESTION_INVALID"));
            }
            if !(2..=10).contains(&poll.answers.len()) {
                return Err(RpcFailure::new(400, "POLL_ANSWERS_INVALID"));
            }
            let mut answers = Vec::with_capacity(poll.answers.len());
            for (text, option) in &poll.answers {
                if text.trim().is_empty() || option.is_empty() {
                    return Err(RpcFailure::new(400, "POLL_ANSWERS_INVALID"));
                }
                answers.push(serde_json::json!({
                    "text": text,
                    "option": option_json(option),
                }));
            }
            let correct_options: Vec<serde_json::Value> = poll
                .correct_indexes
                .iter()
                .filter_map(|index| {
                    poll.answers
                        .get(*index as usize)
                        .map(|(_, option)| option_json(option))
                })
                .collect();
            let poll_id = if poll.id != 0 { poll.id } else { nonzero_i64() };
            let payload = serde_json::json!({
                "id": poll_id,
                "question": poll.question,
                "answers": answers,
                "public_voters": poll.flags & (1 << 1) != 0,
                "multiple_choice": poll.flags & (1 << 2) != 0,
                "quiz": poll.flags & (1 << 3) != 0,
                "closed": poll.flags & (1 << 0) != 0,
                "close_period": poll.close_period,
                "close_date": poll.close_date,
                "correct_options": correct_options,
            });
            let record = repo::create_special_media(ctx.db, owner_user_id, "poll", &payload)
                .await
                .map_err(RpcFailure::internal)?;
            Ok(Some(record))
        }
        InputMediaRef::Geo {
            lat,
            long,
            accuracy_radius,
        } => {
            let payload = serde_json::json!({
                "lat": lat,
                "long": long,
                "accuracy_radius": accuracy_radius,
                "access_hash": nonzero_i64(),
            });
            let record = repo::create_special_media(ctx.db, owner_user_id, "geo", &payload)
                .await
                .map_err(RpcFailure::internal)?;
            Ok(Some(record))
        }
        InputMediaRef::Contact {
            phone_number,
            first_name,
            last_name,
            vcard,
        } => {
            if phone_number.trim().is_empty() {
                return Err(RpcFailure::new(400, "CONTACT_PHONE_INVALID"));
            }
            let user_id = match repo::find_user_by_phone(ctx.db, &phone_number)
                .await
                .map_err(RpcFailure::internal)?
            {
                Some(user) => user.id,
                None => {
                    let normalized = format!("+{}", phone_number.trim_start_matches('+'));
                    match repo::find_user_by_phone(ctx.db, &normalized)
                        .await
                        .map_err(RpcFailure::internal)?
                    {
                        Some(user) => user.id,
                        None => 0,
                    }
                }
            };
            let payload = serde_json::json!({
                "phone_number": phone_number,
                "first_name": first_name,
                "last_name": last_name,
                "vcard": vcard,
                "user_id": user_id,
            });
            let record = repo::create_special_media(ctx.db, owner_user_id, "contact", &payload)
                .await
                .map_err(RpcFailure::internal)?;
            Ok(Some(record))
        }
        InputMediaRef::Dice { emoticon } => {
            let value = dice_value(&emoticon)
                .ok_or_else(|| RpcFailure::new(400, "DICE_EMOJI_INVALID"))?;
            let payload = serde_json::json!({
                "value": value,
                "emoticon": emoticon,
            });
            let record = repo::create_special_media(ctx.db, owner_user_id, "dice", &payload)
                .await
                .map_err(RpcFailure::internal)?;
            Ok(Some(record))
        }
        InputMediaRef::ExistingPhoto { id } => {
            let record = repo::find_media(ctx.db, id)
                .await
                .map_err(RpcFailure::internal)?
                .ok_or_else(|| RpcFailure::new(400, "MEDIA_INVALID"))?;
            if record.kind != "photo" {
                return Err(RpcFailure::new(400, "MEDIA_INVALID"));
            }
            Ok(Some(record))
        }
        InputMediaRef::ExistingDocument { id } => {
            let record = repo::find_media(ctx.db, id)
                .await
                .map_err(RpcFailure::internal)?
                .ok_or_else(|| RpcFailure::new(400, "MEDIA_INVALID"))?;
            if record.kind == "photo" {
                return Err(RpcFailure::new(400, "MEDIA_INVALID"));
            }
            Ok(Some(record))
        }
        InputMediaRef::UploadedPhoto { file } => {
            let assembled = assemble_upload(ctx, owner_user_id, &file).await?;
            if !assembled.analysis.is_image
                || assembled.analysis.width <= 0
                || assembled.analysis.height <= 0
            {
                return Err(RpcFailure::new(400, "PHOTO_EXTENSION_INVALID"));
            }
            let (thumb_key, thumb_width, thumb_height, thumb_size) = thumbnail_values(&assembled);
            let record = repo::create_media(
                ctx.db,
                owner_user_id,
                "photo",
                &assembled.storage_key,
                thumb_key,
                &assembled.sha256,
                &assembled.analysis.mime_type,
                assembled.size,
                assembled.analysis.width,
                assembled.analysis.height,
                thumb_width,
                thumb_height,
                thumb_size,
                0,
                &file.name,
                &thumbnail_inputs(&assembled),
                &repo::MediaAudioInput::default(),
                &repo::MediaStickerInput::default(),
            )
            .await
            .map_err(RpcFailure::internal)?;
            Ok(Some(record))
        }
        InputMediaRef::UploadedDocument {
            file,
            mime_type,
            attributes,
        } => {
            let assembled = assemble_upload(ctx, owner_user_id, &file).await?;
            let mut width = assembled.analysis.width;
            let mut height = assembled.analysis.height;
            let mut duration = assembled.analysis.duration;
            let mut file_name = if file.name.is_empty() {
                "file".to_owned()
            } else {
                file.name.clone()
            };
            let mut is_video = assembled.analysis.is_video;
            let mut audio = repo::MediaAudioInput::default();
            let mut sticker = repo::MediaStickerInput::default();
            for attribute in &attributes {
                match attribute {
                    ParsedAttribute::Filename(name) => {
                        if !name.is_empty() {
                            file_name = name.clone();
                        }
                    }
                    ParsedAttribute::ImageSize {
                        width: attribute_width,
                        height: attribute_height,
                    } => {
                        if *attribute_width > 0 && *attribute_height > 0 {
                            width = *attribute_width;
                            height = *attribute_height;
                        }
                    }
                    ParsedAttribute::Video {
                        duration: attribute_duration,
                        width: attribute_width,
                        height: attribute_height,
                    } => {
                        if *attribute_width > 0 && *attribute_height > 0 {
                            width = *attribute_width;
                            height = *attribute_height;
                        }
                        duration = attribute_duration.round().max(0.0) as i32;
                        is_video = true;
                    }
                    ParsedAttribute::Audio {
                        voice,
                        duration: attribute_duration,
                        title,
                        performer,
                        waveform,
                    } => {
                        if *attribute_duration > 0 {
                            duration = *attribute_duration;
                        }
                        audio.voice = *voice;
                        audio.title = title.clone();
                        audio.performer = performer.clone();
                        audio.waveform = waveform.clone();
                    }
                    ParsedAttribute::Animated => {}
                    ParsedAttribute::Sticker {
                        alt,
                        set_id,
                        set_access_hash,
                    } => {
                        sticker.sticker = true;
                        sticker.alt = alt.clone();
                        sticker.set_id = *set_id;
                        sticker.set_access_hash = *set_access_hash;
                    }
                    ParsedAttribute::CustomEmoji {
                        alt,
                        set_id,
                        set_access_hash,
                    } => {
                        sticker.custom_emoji = true;
                        sticker.custom_emoji_alt = alt.clone();
                        sticker.set_id = *set_id;
                        sticker.set_access_hash = *set_access_hash;
                    }
                }
            }
            let resolved_mime = if mime_type.is_empty() {
                assembled.analysis.mime_type.clone()
            } else {
                mime_type
            };
            let kind = if is_video { "video" } else { "document" };
            let (thumb_key, thumb_width, thumb_height, thumb_size) = thumbnail_values(&assembled);
            let record = repo::create_media(
                ctx.db,
                owner_user_id,
                kind,
                &assembled.storage_key,
                thumb_key,
                &assembled.sha256,
                &resolved_mime,
                assembled.size,
                width,
                height,
                thumb_width,
                thumb_height,
                thumb_size,
                duration,
                &file_name,
                &thumbnail_inputs(&assembled),
                &audio,
                &sticker,
            )
            .await
            .map_err(RpcFailure::internal)?;
            Ok(Some(record))
        }
    }
}

async fn upload_save_file_part(
    ctx: &RpcContext<'_>,
    reader: &mut Reader<'_>,
    big: bool,
) -> Result<Vec<u8>, RpcFailure> {
    let file_id = reader.i64()?;
    let part = reader.i32()?;
    let total_parts = if big { reader.i32()? } else { 0 };
    let data = reader.bytes()?;
    let Some(user_id) = ctx.user_id else {
        return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
    };
    if !(0..=9999).contains(&part) {
        return Err(RpcFailure::new(400, "FILE_PART_INVALID"));
    }
    if !(0..=10_000).contains(&total_parts) {
        return Err(RpcFailure::new(400, "FILE_PART_INVALID"));
    }
    if data.is_empty() || data.len() > 1024 * 1024 {
        return Err(RpcFailure::new(400, "FILE_PART_TOO_BIG"));
    }
    let storage_key = media::write_part(&ctx.config.media_dir, file_id, part, &data)
        .await
        .map_err(RpcFailure::internal)?;
    repo::save_upload_part(
        ctx.db,
        file_id,
        user_id,
        part,
        total_parts,
        big,
        &storage_key,
        data.len() as i64,
    )
    .await
    .map_err(RpcFailure::internal)?;
    Ok(types::bool_true())
}

struct FileLocation {
    media_id: i64,
    access_hash: i64,
    thumb_size: String,
}

fn read_file_location(
    ctx: &RpcContext<'_>,
    reader: &mut Reader<'_>,
) -> Result<FileLocation, RpcFailure> {
    match reader.constructor()? {
        ctor::INPUT_DOCUMENT_FILE_LOCATION | ctor::INPUT_PHOTO_FILE_LOCATION => {
            let media_id = reader.i64()?;
            let access_hash = reader.i64()?;
            let _file_reference = reader.bytes()?;
            let thumb_size = reader.string()?;
            Ok(FileLocation {
                media_id,
                access_hash,
                thumb_size,
            })
        }
        ctor::INPUT_PEER_PHOTO_FILE_LOCATION => {
            let _flags = reader.u32()?;
            let _peer = read_input_peer(ctx, reader)?;
            let photo_id = reader.i64()?;
            Ok(FileLocation {
                media_id: photo_id,
                access_hash: 0,
                thumb_size: String::new(),
            })
        }
        ctor::INPUT_FILE_LOCATION => {
            let volume_id = reader.i64()?;
            let _local_id = reader.i32()?;
            let _secret = reader.i64()?;
            let _file_reference = reader.bytes()?;
            Ok(FileLocation {
                media_id: volume_id,
                access_hash: 0,
                thumb_size: String::new(),
            })
        }
        other => Err(RpcFailure::new(
            400,
            format!("UNSUPPORTED_FILE_LOCATION_0x{other:08X}"),
        )),
    }
}

fn file_storage_key<'a>(record: &'a repo::MediaRecord, location: &FileLocation) -> &'a str {
    if !location.thumb_size.is_empty() && location.thumb_size != "x" {
        if let Some(thumb) = record
            .thumbs
            .iter()
            .find(|thumb| thumb.kind == location.thumb_size)
        {
            return &thumb.storage_key;
        }
        if location.thumb_size == "m" && !record.thumb_storage_key.is_empty() {
            return &record.thumb_storage_key;
        }
    }
    if record.kind != "photo" && location.thumb_size == "x" {
        if let Some(thumb) = record.thumbs.iter().find(|thumb| thumb.kind == "x") {
            return &thumb.storage_key;
        }
    }
    &record.storage_key
}

async fn upload_get_file(
    ctx: &RpcContext<'_>,
    reader: &mut Reader<'_>,
) -> Result<Vec<u8>, RpcFailure> {
    let _flags = reader.u32()?;
    let location = read_file_location(ctx, reader)?;
    let offset = reader.i64()?;
    let limit = reader.i32()?;
    let Some(_user_id) = ctx.user_id else {
        return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
    };
    if offset < 0 {
        return Err(RpcFailure::new(400, "FILE_PART_INVALID"));
    }
    let Some(record) = repo::find_media(ctx.db, location.media_id)
        .await
        .map_err(RpcFailure::internal)?
    else {
        return Err(RpcFailure::new(400, "FILE_REFERENCE_EXPIRED"));
    };
    if location.access_hash != 0 && location.access_hash != record.access_hash {
        return Err(RpcFailure::new(400, "FILE_REFERENCE_INVALID"));
    }
    let limit = i64::from(limit.clamp(1, 1024 * 1024));
    let storage_key = file_storage_key(&record, &location);
    let bytes = media::read_range(&ctx.config.media_dir, storage_key, offset, limit)
        .await
        .map_err(RpcFailure::internal)?;
    let thumb = record
        .thumbs
        .iter()
        .any(|thumb| thumb.storage_key == storage_key)
        || (!record.thumb_storage_key.is_empty() && storage_key == record.thumb_storage_key);
    let (mime_type, extension) = if thumb {
        ("image/jpeg", "jpg")
    } else {
        (
            record.mime_type.as_str(),
            record
                .storage_key
                .rsplit_once('.')
                .map(|(_, extension)| extension)
                .unwrap_or(""),
        )
    };
    Ok(types::upload_file(
        media::storage_type(mime_type, extension),
        record.created_at as i32,
        &bytes,
    ))
}

async fn upload_get_file_hashes(
    ctx: &RpcContext<'_>,
    reader: &mut Reader<'_>,
) -> Result<Vec<u8>, RpcFailure> {
    let location = read_file_location(ctx, reader)?;
    let offset = reader.i64()?;
    let Some(_user_id) = ctx.user_id else {
        return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
    };
    if offset < 0 {
        return Err(RpcFailure::new(400, "FILE_PART_INVALID"));
    }
    let Some(record) = repo::find_media(ctx.db, location.media_id)
        .await
        .map_err(RpcFailure::internal)?
    else {
        return Err(RpcFailure::new(400, "FILE_REFERENCE_EXPIRED"));
    };
    if location.access_hash != 0 && location.access_hash != record.access_hash {
        return Err(RpcFailure::new(400, "FILE_REFERENCE_INVALID"));
    }
    let storage_key = file_storage_key(&record, &location);
    let (hash_offset, hash_limit, hash) =
        media::hash_range(&ctx.config.media_dir, storage_key, offset, 1024 * 1024)
            .await
            .map_err(RpcFailure::internal)?;
    let mut writer = Writer::new();
    writer.u32(ctor::VECTOR);
    if hash_limit > 0 {
        writer.i32(1);
        writer.u32(ctor::FILE_HASH);
        writer.i64(hash_offset);
        writer.i32(hash_limit);
        writer.bytes(&hash);
    } else {
        writer.i32(0);
    }
    Ok(writer.into_bytes())
}

async fn messages_send_media(
    ctx: &RpcContext<'_>,
    reader: &mut Reader<'_>,
) -> Result<Vec<u8>, RpcFailure> {
    let flags = reader.u32()?;
    let peer = read_input_peer(ctx, reader)?;
    let reply_to = if flags & (1 << 0) != 0 {
        read_input_reply_to(reader)?
    } else {
        None
    };
    let input = read_input_media(reader)?;
    let text = reader.string()?;
    let random_id = reader.i64()?;
    let Some(user_id) = ctx.user_id else {
        return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
    };
    if text.chars().count() > 1024 {
        return Err(RpcFailure::new(400, "MEDIA_CAPTION_TOO_LONG"));
    }
    let media = materialize_input_media(ctx, user_id, input).await?;
    let Some(media) = media else {
        return Err(RpcFailure::new(400, "MEDIA_EMPTY"));
    };
    let (entities, schedule_date, reply_markup) = parse_message_tail(reader, flags, &text)?;
    let extras = repo::MessageExtras {
        reply_to_msg_id: reply_to,
        entities,
        reply_markup,
        ..repo::MessageExtras::default()
    };
    if schedule_date > 0 {
        return schedule_message(
            ctx,
            peer,
            &text,
            random_id,
            Some(&media),
            &extras,
            schedule_date,
        )
        .await;
    }
    deliver_message(ctx, peer, &text, random_id, Some(&media), &extras).await
}

async fn messages_send_multi_media(
    ctx: &RpcContext<'_>,
    reader: &mut Reader<'_>,
) -> Result<Vec<u8>, RpcFailure> {
    // messages.sendMultiMedia#1bf89d74
    //   flags:# peer:InputPeer reply_to:flags.0?InputReplyTo
    //   multi_media:Vector<InputSingleMedia> schedule_date:flags.10?int ...
    let flags = reader.u32()?;
    let peer = read_input_peer(ctx, reader)?;
    let reply_to = if flags & (1 << 0) != 0 {
        read_input_reply_to(reader)?
    } else {
        None
    };
    reader.expect_constructor(ctor::VECTOR)?;
    let count = reader.i32()?;
    if !(1..=10).contains(&count) {
        return Err(RpcFailure::new(400, "MEDIA_GROUP_INVALID"));
    }
    let mut items = Vec::with_capacity(count as usize);
    for _ in 0..count {
        if reader.constructor()? != ctor::INPUT_SINGLE_MEDIA {
            return Err(RpcFailure::new(400, "MEDIA_GROUP_INVALID"));
        }
        let item_flags = reader.u32()?;
        let input = read_input_media(reader)?;
        let random_id = reader.i64()?;
        let text = reader.string()?;
        let entities = if item_flags & (1 << 0) != 0 {
            read_message_entities(reader, &text)?
        } else {
            Vec::new()
        };
        if text.chars().count() > 1024 {
            return Err(RpcFailure::new(400, "MEDIA_CAPTION_TOO_LONG"));
        }
        items.push((input, random_id, text, entities));
    }
    let schedule_date = if flags & (1 << 10) != 0 {
        reader.i32()?
    } else {
        0
    };
    if flags & (1 << 13) != 0 {
        let _send_as = read_input_peer(ctx, reader)?;
    }
    if flags & (1 << 17) != 0 {
        if reader.constructor()? != ctor::INPUT_QUICK_REPLY_SHORTCUT {
            return Err(RpcFailure::new(400, "QUICK_REPLY_INVALID"));
        }
        let _shortcut = reader.string()?;
    }
    if flags & (1 << 18) != 0 {
        let _effect = reader.i64()?;
    }
    if flags & (1 << 21) != 0 {
        let _allow_paid_stars = reader.i64()?;
    }
    let Some(user_id) = ctx.user_id else {
        return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
    };
    // The whole batch shares one album id so the client renders it as a gallery.
    let mut grouped_id = rand::random::<i64>();
    if grouped_id == 0 {
        grouped_id = 1;
    }
    let mut last_response: Option<Vec<u8>> = None;
    for (input, random_id, text, entities) in items {
        let extras = repo::MessageExtras {
            reply_to_msg_id: reply_to,
            grouped_id,
            entities,
            ..repo::MessageExtras::default()
        };
        let Some(media) = materialize_input_media(ctx, user_id, input).await? else {
            return Err(RpcFailure::new(400, "MEDIA_EMPTY"));
        };
        let response = if schedule_date > 0 {
            schedule_message(
                ctx,
                peer,
                &text,
                random_id,
                Some(&media),
                &extras,
                schedule_date,
            )
            .await?
        } else {
            deliver_message(ctx, peer, &text, random_id, Some(&media), &extras).await?
        };
        // Only the final response is returned to the caller; earlier members of
        // the album are pushed to the sender's own sessions so the client sees
        // every message of the group.
        if last_response.is_some() {
            ctx.updates.publish(user_id, response.clone());
        }
        last_response = Some(response);
    }
    last_response.ok_or_else(|| RpcFailure::new(400, "MEDIA_GROUP_INVALID"))
}

async fn messages_upload_media(
    ctx: &RpcContext<'_>,
    reader: &mut Reader<'_>,
) -> Result<Vec<u8>, RpcFailure> {
    let flags = reader.u32()?;
    if flags & (1 << 0) != 0 {
        let _business_connection_id = reader.string()?;
    }
    let _peer = read_input_peer(ctx, reader)?;
    let input = read_input_media(reader)?;
    let Some(user_id) = ctx.user_id else {
        return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
    };
    let media = materialize_input_media(ctx, user_id, input).await?;
    let Some(media) = media else {
        return Err(RpcFailure::new(400, "MEDIA_EMPTY"));
    };
    media_bytes(ctx, &media, Some(user_id)).await
}

async fn auth_bind_temp_auth_key(
    ctx: &mut RpcContext<'_>,
    reader: &mut Reader<'_>,
) -> Result<Vec<u8>, RpcFailure> {
    let perm_auth_key_id = reader.i64()?;
    let nonce = reader.i64()?;
    let client_expires_at = reader.i32()?;
    let encrypted_message = reader.bytes()?;
    let invalid = || RpcFailure::new(400, "ENCRYPTED_MESSAGE_INVALID");
    let now = now() as i64;

    if i64::from(client_expires_at) <= now {
        return Err(RpcFailure::new(400, "EXPIRES_AT_INVALID"));
    }

    let Some(temp_key) = repo::load_auth_key(ctx.db, ctx.auth_key_id)
        .await
        .map_err(RpcFailure::internal)?
    else {
        return Err(RpcFailure::new(400, "TEMP_AUTH_KEY_EMPTY"));
    };
    if temp_key.expires_at <= 0 || temp_key.expires_at <= now {
        return Err(RpcFailure::new(400, "TEMP_AUTH_KEY_EMPTY"));
    }
    let Some(perm_key) = repo::load_auth_key(ctx.db, perm_auth_key_id)
        .await
        .map_err(RpcFailure::internal)?
    else {
        return Err(invalid());
    };
    // The permanent side of a binding must never itself be a temporary key.
    if perm_key.expires_at != 0 {
        return Err(invalid());
    }

    let inner =
        tsrv_mtproto::crypto::decrypt_bind_auth_key_inner(&perm_key.value, &encrypted_message)
            .map_err(|error| {
                tracing::warn!(%error, "auth.bindTempAuthKey decryption failed");
                invalid()
            })?;
    if inner.nonce != nonce
        || inner.perm_auth_key_id != perm_auth_key_id
        || inner.temp_auth_key_id != ctx.auth_key_id
        || inner.temp_session_id != ctx.session_id
        || i64::from(inner.expires_at) != i64::from(client_expires_at)
    {
        return Err(invalid());
    }

    let temp_user = repo::session_user(ctx.db, ctx.auth_key_id)
        .await
        .map_err(RpcFailure::internal)?;
    let perm_user = repo::session_user(ctx.db, perm_auth_key_id)
        .await
        .map_err(RpcFailure::internal)?;
    if let (Some(temp), Some(perm)) = (temp_user, perm_user) {
        if temp != perm {
            return Err(invalid());
        }
    }

    // Store the handshake-authoritative temp lifetime rather than the client
    // assertion in the request. TDesktop intentionally adds a small grace
    // interval to the value it sends.
    let binding = repo::TempAuthKeyBinding {
        temp_auth_key_id: ctx.auth_key_id,
        perm_auth_key_id,
        nonce,
        temp_session_id: ctx.session_id,
        expires_at: temp_key.expires_at,
    };
    if !repo::save_temp_auth_key_binding(ctx.db, &binding)
        .await
        .map_err(RpcFailure::internal)?
    {
        return Err(RpcFailure::new(400, "TEMP_AUTH_KEY_ALREADY_BOUND"));
    }
    let resolved_user = repo::merge_session_for_auth_key(ctx.db, ctx.auth_key_id, perm_auth_key_id)
        .await
        .map_err(RpcFailure::internal)?;
    if let Some(user_id) = resolved_user {
        ctx.user_id = Some(user_id);
    }
    tracing::info!(
        temp_auth_key_id = ctx.auth_key_id,
        perm_auth_key_id,
        expires_at = temp_key.expires_at,
        ?resolved_user,
        "bound temporary auth key"
    );
    Ok(types::bool_true())
}

fn messages_get_sticker_set(reader: &mut Reader<'_>) -> Result<Vec<u8>, RpcFailure> {
    let requested = match reader.constructor()? {
        ctor::INPUT_STICKER_SET_ID => {
            let id = reader.i64()?;
            let access_hash = reader.i64()?;
            Some((id, access_hash, String::new()))
        }
        ctor::INPUT_STICKER_SET_SHORT_NAME => {
            let short_name = reader.string()?;
            Some((0, 0, short_name))
        }
        ctor::INPUT_STICKER_SET_EMPTY => None,
        // Default emoji status / topic icon packs.
        0x29d0_f5ee | 0x44c1_f8e9 | 0x4974_8553 | 0x04c4_d4ce => None,
        _ => None,
    };
    let Some(pack) = stickers::pack() else {
        let (id, access_hash, short_name) = requested.unwrap_or((0, 0, String::new()));
        return Ok(types::messages_sticker_set(
            &types::sticker_set(id, access_hash, "Stickers", &short_name, 0, 0, 0),
            &[],
            &[],
        ));
    };
    let matches = match &requested {
        None => true,
        Some((id, access_hash, short_name)) => {
            (*id == pack.id && *access_hash == pack.access_hash)
                || short_name.eq_ignore_ascii_case(&pack.short_name)
        }
    };
    if matches {
        return Ok(stickers::messages_sticker_set(pack));
    }
    let (id, access_hash, short_name) = requested.unwrap_or((0, 0, String::new()));
    Ok(types::messages_sticker_set(
        &types::sticker_set(id, access_hash, "Stickers", &short_name, 0, 0, 0),
        &[],
        &[],
    ))
}

async fn account_update_emoji_status(
    ctx: &RpcContext<'_>,
    reader: &mut Reader<'_>,
) -> Result<Vec<u8>, RpcFailure> {
    let Some(user_id) = ctx.user_id else {
        return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
    };
    let document_id = match reader.constructor()? {
        ctor::EMOJI_STATUS => {
            let flags = reader.u32()?;
            if flags & 1 != 0 {
                let _until = reader.i32()?;
            }
            reader.i64()?
        }
        other => {
            return Err(RpcFailure::new(
                400,
                format!("UNSUPPORTED_EMOJI_STATUS_0x{other:08X}"),
            ));
        }
    };
    if document_id != 0 {
        if let Some(pack) = stickers::pack() {
            if !stickers::contains_document(pack, document_id) {
                return Err(RpcFailure::new(400, "DOCUMENT_INVALID"));
            }
        }
    }
    repo::set_user_emoji_status(ctx.db, user_id, document_id)
        .await
        .map_err(RpcFailure::internal)?;
    let push = types::updates(
        &[types::update_user_emoji_status(user_id, document_id)],
        &[],
        now() as i32,
        0,
    );
    ctx.updates
        .publish_excluding(user_id, Some(ctx.session_id), push);
    Ok(types::bool_true())
}

async fn user_pts(ctx: &RpcContext<'_>) -> Result<i32, RpcFailure> {
    let Some(user_id) = ctx.user_id else {
        return Ok(0);
    };
    repo::user_pts(ctx.db, user_id)
        .await
        .map_err(RpcFailure::internal)
}

#[derive(Debug, Clone, Copy)]
enum PeerRef {
    User(i64),
    Chat(i64),
    Channel { id: i64, access_hash: i64 },
}

fn read_input_peer(ctx: &RpcContext<'_>, reader: &mut Reader<'_>) -> Result<PeerRef, RpcFailure> {
    match reader.constructor()? {
        ctor::INPUT_PEER_SELF => ctx
            .user_id
            .map(PeerRef::User)
            .ok_or_else(|| RpcFailure::new(401, "AUTH_KEY_UNREGISTERED")),
        ctor::INPUT_PEER_USER => {
            let user_id = reader.i64()?;
            let _access_hash = reader.i64()?;
            Ok(PeerRef::User(user_id))
        }
        ctor::INPUT_PEER_CHANNEL => {
            let id = reader.i64()?;
            let access_hash = reader.i64()?;
            Ok(PeerRef::Channel { id, access_hash })
        }
        ctor::INPUT_PEER_CHAT => {
            let chat_id = reader.i64()?;
            Ok(PeerRef::Chat(chat_id))
        }
        other => Err(RpcFailure::new(
            400,
            format!("UNSUPPORTED_INPUT_PEER_0x{other:08X}"),
        )),
    }
}

async fn channels_create_channel(
    ctx: &RpcContext<'_>,
    reader: &mut Reader<'_>,
) -> Result<Vec<u8>, RpcFailure> {
    let flags = reader.u32()?;
    let title = reader.string()?;
    let about = reader.string()?;
    if flags & (1 << 2) != 0 {
        return Err(RpcFailure::new(400, "GEO_POINT_NOT_SUPPORTED"));
    }
    if flags & (1 << 4) != 0 {
        let _ttl = reader.i32()?;
    }
    if title.trim().is_empty() {
        return Err(RpcFailure::new(400, "CHANNEL_TITLE_EMPTY"));
    }
    let Some(self_user) = ctx_user(ctx).await? else {
        return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
    };
    let is_broadcast = flags & 1 != 0;
    let channel = repo::create_channel(ctx.db, self_user.id, title.trim(), &about, is_broadcast)
        .await
        .map_err(RpcFailure::internal)?;
    let update = types::update_channel(channel.id);
    Ok(types::updates_with_chats(
        &[update],
        &[user_bytes(self_user)],
        &[channel_bytes(&channel, channel.owner_user_id)],
        now() as i32,
        0,
    ))
}

async fn channels_join_channel(
    ctx: &RpcContext<'_>,
    reader: &mut Reader<'_>,
) -> Result<Vec<u8>, RpcFailure> {
    let (channel_id, _access_hash) = read_input_channel(reader)?;
    let Some(user_id) = ctx.user_id else {
        return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
    };
    let Some(channel) = repo::find_channel(ctx.db, channel_id)
        .await
        .map_err(RpcFailure::internal)?
    else {
        return Err(RpcFailure::new(400, "CHANNEL_INVALID"));
    };
    ensure_not_banned(ctx, channel.id, user_id, false).await?;
    repo::add_channel_member(ctx.db, channel.id, user_id)
        .await
        .map_err(RpcFailure::internal)?;
    repo::ensure_channel_dialog(ctx.db, user_id, channel.id)
        .await
        .map_err(RpcFailure::internal)?;
    let Some(self_user) = ctx_user(ctx).await? else {
        return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
    };
    let updates = types::updates_with_chats(
        &[types::update_channel(channel.id)],
        &[user_bytes(self_user)],
        &[channel_bytes(&channel, user_id)],
        now() as i32,
        0,
    );
    Ok(types::chat_invite_join_result_ok(&updates))
}

async fn channels_leave_channel(
    ctx: &RpcContext<'_>,
    reader: &mut Reader<'_>,
) -> Result<Vec<u8>, RpcFailure> {
    let (channel_id, _access_hash) = read_input_channel(reader)?;
    let Some(user_id) = ctx.user_id else {
        return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
    };
    let Some(channel) = repo::find_channel(ctx.db, channel_id)
        .await
        .map_err(RpcFailure::internal)?
    else {
        return Err(RpcFailure::new(400, "CHANNEL_INVALID"));
    };
    repo::remove_channel_member(ctx.db, channel.id, user_id)
        .await
        .map_err(RpcFailure::internal)?;
    Ok(types::updates_with_chats(
        &[types::update_channel(channel.id)],
        &[],
        &[],
        now() as i32,
        0,
    ))
}

async fn channels_invite_to_channel(
    ctx: &RpcContext<'_>,
    reader: &mut Reader<'_>,
) -> Result<Vec<u8>, RpcFailure> {
    let (channel_id, _access_hash) = read_input_channel(reader)?;
    let invitees = read_input_users(ctx, reader)?;
    let Some(channel) = repo::find_channel(ctx.db, channel_id)
        .await
        .map_err(RpcFailure::internal)?
    else {
        return Err(RpcFailure::new(400, "CHANNEL_INVALID"));
    };
    if let Some(actor_id) = ctx.user_id {
        let Some((role, rights)) = repo::channel_member_rights(ctx.db, channel.id, actor_id)
            .await
            .map_err(RpcFailure::internal)?
        else {
            return Err(RpcFailure::new(403, "CHAT_ADMIN_REQUIRED"));
        };
        if role != "owner" && (role != "admin" || rights & (1 << 5) == 0) {
            return Err(RpcFailure::new(403, "CHAT_ADMIN_REQUIRED"));
        }
    }
    let mut invited = Vec::new();
    for user_id in invitees {
        if user_id == channel.owner_user_id || user_id == ctx.user_id.unwrap_or(0) {
            continue;
        }
        if ensure_not_banned(ctx, channel.id, user_id, false)
            .await
            .is_err()
        {
            continue;
        }
        repo::add_channel_member(ctx.db, channel.id, user_id)
            .await
            .map_err(RpcFailure::internal)?;
        if let Some(user) = repo::find_user_by_id(ctx.db, user_id)
            .await
            .map_err(RpcFailure::internal)?
        {
            invited.push(user);
            let push = types::updates_with_chats(
                &[types::update_channel(channel.id)],
                &[],
                &[channel_bytes(&channel, user_id)],
                now() as i32,
                0,
            );
            ctx.updates.publish(user_id, push);
        }
    }
    let users: Vec<Vec<u8>> = invited.iter().map(other_user_bytes).collect();
    let updates = types::updates_with_chats(
        &[types::update_channel(channel.id)],
        &users,
        &[channel_bytes(&channel, ctx.user_id.unwrap_or(0))],
        now() as i32,
        0,
    );
    Ok(types::messages_invited_users(&updates))
}

async fn channels_get_full_channel(
    ctx: &RpcContext<'_>,
    reader: &mut Reader<'_>,
) -> Result<Vec<u8>, RpcFailure> {
    let (channel_id, _access_hash) = read_input_channel(reader)?;
    let Some(user_id) = ctx.user_id else {
        return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
    };
    let Some(channel) = repo::find_channel(ctx.db, channel_id)
        .await
        .map_err(RpcFailure::internal)?
    else {
        return Err(RpcFailure::new(400, "CHANNEL_INVALID"));
    };
    let members = repo::list_channel_members(ctx.db, channel.id)
        .await
        .map_err(RpcFailure::internal)?;
    let pinned_msg_id = repo::pinned_message_id(ctx.db, channel.id)
        .await
        .map_err(RpcFailure::internal)?;
    let full = types::channel_full(
        channel.id,
        &channel.about,
        channel.participants_count as i32,
        0,
        0,
        0,
        pinned_msg_id,
        channel.pts as i32,
    );
    let users: Vec<Vec<u8>> = members
        .iter()
        .map(|(user, _, _, _, _)| other_user_bytes(user))
        .collect();
    Ok(types::messages_chat_full(
        &full,
        &[channel_bytes(&channel, user_id)],
        &users,
    ))
}

async fn channels_get_participants(
    ctx: &RpcContext<'_>,
    reader: &mut Reader<'_>,
) -> Result<Vec<u8>, RpcFailure> {
    let (channel_id, _access_hash) = read_input_channel(reader)?;
    let Some(user_id) = ctx.user_id else {
        return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
    };
    let Some(channel) = repo::find_channel(ctx.db, channel_id)
        .await
        .map_err(RpcFailure::internal)?
    else {
        return Err(RpcFailure::new(400, "CHANNEL_INVALID"));
    };
    let members = repo::list_channel_members(ctx.db, channel.id)
        .await
        .map_err(RpcFailure::internal)?;
    let participants: Vec<Vec<u8>> = members
        .iter()
        .map(|(member, role, joined_at, rights_flags, rank)| {
            if role == "owner" {
                types::channel_participant_creator(
                    member.id,
                    &types::chat_admin_rights_full(),
                    rank,
                )
            } else if role == "admin" {
                types::channel_participant_admin(
                    member.id,
                    channel.owner_user_id,
                    channel.owner_user_id,
                    *joined_at as i32,
                    &types::chat_admin_rights(*rights_flags),
                    rank,
                    member.id == user_id,
                )
            } else {
                types::channel_participant(member.id, *joined_at as i32)
            }
        })
        .collect();
    let users: Vec<Vec<u8>> = members
        .iter()
        .map(|(user, _, _, _, _)| other_user_bytes(user))
        .collect();
    let viewer_rights = members
        .iter()
        .find(|(member, _, _, _, _)| member.id == user_id)
        .filter(|(_, role, _, _, _)| role == "admin")
        .map(|(_, _, _, rights_flags, _)| types::chat_admin_rights(*rights_flags));
    Ok(types::channels_channel_participants(
        members.len() as i32,
        &participants,
        &[channel_bytes_with_rights(
            &channel,
            user_id,
            viewer_rights.as_deref(),
        )],
        &users,
    ))
}

async fn messages_export_chat_invite(
    ctx: &RpcContext<'_>,
    reader: &mut Reader<'_>,
) -> Result<Vec<u8>, RpcFailure> {
    let flags = reader.u32()?;
    let peer = read_input_peer(ctx, reader)?;
    let expire_date = if flags & (1 << 0) != 0 {
        reader.i32()?
    } else {
        0
    };
    let usage_limit = if flags & (1 << 1) != 0 {
        reader.i32()?
    } else {
        0
    };
    let _legacy = flags & (1 << 2) != 0;
    let request_needed = flags & (1 << 3) != 0;
    let title = if flags & (1 << 4) != 0 {
        reader.string()?
    } else {
        String::new()
    };
    if flags & (1 << 5) != 0 {
        return Err(RpcFailure::new(400, "STAR_SUBSCRIPTIONS_UNSUPPORTED"));
    }
    let Some(user_id) = ctx.user_id else {
        return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
    };
    let chat_id = match peer {
        PeerRef::Channel { id, .. } | PeerRef::Chat(id) => id,
        PeerRef::User(_) => return Err(RpcFailure::new(400, "PEER_ID_INVALID")),
    };
    let Some(chat) = repo::find_channel(ctx.db, chat_id)
        .await
        .map_err(RpcFailure::internal)?
    else {
        return Err(RpcFailure::new(400, "CHAT_ID_INVALID"));
    };
    let Some((role, rights)) = repo::channel_member_rights(ctx.db, chat.id, user_id)
        .await
        .map_err(RpcFailure::internal)?
    else {
        return Err(RpcFailure::new(403, "CHAT_ADMIN_REQUIRED"));
    };
    if role != "owner" && (role != "admin" || rights & (1 << 5) == 0) {
        return Err(RpcFailure::new(403, "CHAT_ADMIN_REQUIRED"));
    }
    // Request-needed links store a pending join request for approval; the
    // client can still create direct links by leaving the flag unset.
    let token = random_hex(12);
    let link = format!("https://t.me/+{token}");
    let invite = repo::create_chat_invite(
        ctx.db,
        &token,
        chat.id,
        user_id,
        &link,
        i64::from(expire_date),
        usage_limit,
        request_needed,
    )
    .await
    .map_err(RpcFailure::internal)?;
    Ok(types::chat_invite_exported(
        &invite.link,
        invite.creator_id,
        now() as i32,
        expire_date,
        usage_limit,
        0,
        false,
        &title,
    ))
}

async fn messages_check_chat_invite(
    ctx: &RpcContext<'_>,
    reader: &mut Reader<'_>,
) -> Result<Vec<u8>, RpcFailure> {
    let hash = reader.string()?;
    let Some(user_id) = ctx.user_id else {
        return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
    };
    let Some(invite) = repo::find_chat_invite(ctx.db, &hash)
        .await
        .map_err(RpcFailure::internal)?
    else {
        return Err(RpcFailure::new(400, "INVITE_HASH_INVALID"));
    };
    if invite.revoked {
        return Err(RpcFailure::new(400, "INVITE_HASH_EXPIRED"));
    }
    let expires_at = invite.expires_at;
    if expires_at > 0 && expires_at <= now() as i64 {
        return Err(RpcFailure::new(400, "INVITE_HASH_EXPIRED"));
    }
    if invite.usage_limit > 0 && invite.usage_count >= invite.usage_limit {
        return Err(RpcFailure::new(400, "INVITE_HASH_EXPIRED"));
    }
    let Some(chat) = repo::find_channel(ctx.db, invite.chat_id)
        .await
        .map_err(RpcFailure::internal)?
    else {
        return Err(RpcFailure::new(400, "INVITE_HASH_INVALID"));
    };
    if repo::channel_membership(ctx.db, chat.id, user_id)
        .await
        .map_err(RpcFailure::internal)?
        .is_some()
    {
        return Ok(types::chat_invite_already(&channel_bytes(&chat, user_id)));
    }
    Ok(types::chat_invite(
        chat.kind != "basic_group",
        chat.kind == "channel",
        chat.kind == "group",
        &chat.title,
        &chat.about,
        None,
        chat.participants_count as i32,
        Some(&[]),
        invite.request_needed,
    ))
}

async fn messages_import_chat_invite(
    ctx: &RpcContext<'_>,
    reader: &mut Reader<'_>,
) -> Result<Vec<u8>, RpcFailure> {
    let hash = reader.string()?;
    let Some(user_id) = ctx.user_id else {
        return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
    };
    let Some(invite) = repo::find_chat_invite(ctx.db, &hash)
        .await
        .map_err(RpcFailure::internal)?
    else {
        return Err(RpcFailure::new(400, "INVITE_HASH_INVALID"));
    };
    if invite.revoked {
        return Err(RpcFailure::new(400, "INVITE_HASH_EXPIRED"));
    }
    if invite.expires_at > 0 && invite.expires_at <= now() as i64 {
        return Err(RpcFailure::new(400, "INVITE_HASH_EXPIRED"));
    }
    let Some(chat) = repo::find_channel(ctx.db, invite.chat_id)
        .await
        .map_err(RpcFailure::internal)?
    else {
        return Err(RpcFailure::new(400, "INVITE_HASH_INVALID"));
    };
    if chat.kind == "basic_group" {
        return Err(RpcFailure::new(400, "INVITE_HASH_INVALID"));
    }
    ensure_not_banned(ctx, chat.id, user_id, false).await?;
    if repo::channel_membership(ctx.db, chat.id, user_id)
        .await
        .map_err(RpcFailure::internal)?
        .is_some()
    {
        return Ok(types::chat_invite_join_result_ok(&types::updates_with_chats(
            &[],
            &[],
            &[channel_bytes(&chat, user_id)],
            now() as i32,
            0,
        )));
    }
    if invite.request_needed {
        repo::upsert_join_request(ctx.db, chat.id, user_id, "")
            .await
            .map_err(RpcFailure::internal)?;
        // The requirement is pending; the requester is not a member yet, so
        // return an empty updates container instead of updateChannel.
        return Ok(types::chat_invite_join_result_ok(&types::updates(
            &[],
            &[],
            now() as i32,
            0,
        )));
    }
    if !repo::consume_chat_invite(ctx.db, &hash)
        .await
        .map_err(RpcFailure::internal)?
    {
        return Err(RpcFailure::new(400, "INVITE_HASH_EXPIRED"));
    }
    repo::add_channel_member(ctx.db, chat.id, user_id)
        .await
        .map_err(RpcFailure::internal)?;
    repo::ensure_channel_dialog(ctx.db, user_id, chat.id)
        .await
        .map_err(RpcFailure::internal)?;
    let pts = repo::bump_channel_pts(ctx.db, chat.id)
        .await
        .map_err(RpcFailure::internal)?;
    let update = types::update_channel(chat.id);
    repo::log_channel_update(ctx.db, chat.id, pts, &update)
        .await
        .map_err(RpcFailure::internal)?;
    let Some(user) = ctx_user(ctx).await? else {
        return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
    };
    let chat_updated = repo::find_channel(ctx.db, chat.id)
        .await
        .map_err(RpcFailure::internal)?
        .unwrap_or_else(|| chat.clone());
    let push = types::updates_with_chats(
        std::slice::from_ref(&update),
        &[],
        &[channel_bytes(&chat_updated, user_id)],
        now() as i32,
        0,
    );
    for member_id in repo::chat_member_ids(ctx.db, chat.id)
        .await
        .map_err(RpcFailure::internal)?
    {
        ctx.updates.publish(member_id, push.clone());
    }
    let response = types::updates_with_chats(
        &[update],
        &[other_user_bytes(&user)],
        &[channel_bytes(&chat_updated, user_id)],
        now() as i32,
        0,
    );
    Ok(types::chat_invite_join_result_ok(&response))
}

async fn channels_check_username(
    ctx: &RpcContext<'_>,
    reader: &mut Reader<'_>,
) -> Result<Vec<u8>, RpcFailure> {
    let (channel_id, access_hash) = read_input_channel(reader)?;
    let username = reader.string()?;
    let Some(_user_id) = ctx.user_id else {
        return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
    };
    let Some(channel) = repo::find_channel(ctx.db, channel_id)
        .await
        .map_err(RpcFailure::internal)?
    else {
        return Err(RpcFailure::new(400, "CHANNEL_INVALID"));
    };
    if channel.access_hash != 0 && channel.access_hash != access_hash {
        return Err(RpcFailure::new(400, "CHANNEL_INVALID"));
    };
    if username.is_empty() || validate_username(&username).is_err() {
        return Ok(types::bool_false());
    }
    let taken = repo::username_taken(ctx.db, &username)
        .await
        .map_err(RpcFailure::internal)?;
    Ok(if taken {
        types::bool_false()
    } else {
        types::bool_true()
    })
}

async fn channels_update_username(
    ctx: &RpcContext<'_>,
    reader: &mut Reader<'_>,
) -> Result<Vec<u8>, RpcFailure> {
    let (channel_id, access_hash) = read_input_channel(reader)?;
    let username = reader.string()?;
    let Some(user_id) = ctx.user_id else {
        return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
    };
    let Some(channel) = repo::find_channel(ctx.db, channel_id)
        .await
        .map_err(RpcFailure::internal)?
    else {
        return Err(RpcFailure::new(400, "CHANNEL_INVALID"));
    };
    if channel.access_hash != 0 && channel.access_hash != access_hash {
        return Err(RpcFailure::new(400, "CHANNEL_INVALID"));
    };
    let Some((role, rights)) = repo::channel_member_rights(ctx.db, channel.id, user_id)
        .await
        .map_err(RpcFailure::internal)?
    else {
        return Err(RpcFailure::new(403, "CHAT_ADMIN_REQUIRED"));
    };
    if role != "owner" && (role != "admin" || rights & (1 << 9) == 0) {
        return Err(RpcFailure::new(403, "CHAT_ADMIN_REQUIRED"));
    }
    let normalized = if username.is_empty() {
        String::new()
    } else {
        validate_username(&username)?
    };
    if !normalized.is_empty()
        && !normalized.eq_ignore_ascii_case(&channel.username)
        && repo::username_taken(ctx.db, &normalized)
            .await
            .map_err(RpcFailure::internal)?
    {
        return Err(RpcFailure::new(400, "USERNAME_OCCUPIED"));
    }
    repo::set_channel_username(ctx.db, channel.id, &normalized)
        .await
        .map_err(RpcFailure::internal)?;
    deref_update_channel(ctx, &channel, user_id).await
}

async fn account_check_username(
    ctx: &RpcContext<'_>,
    reader: &mut Reader<'_>,
) -> Result<Vec<u8>, RpcFailure> {
    let username = reader.string()?;
    if ctx.user_id.is_none() {
        return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
    }
    if username.is_empty() || validate_username(&username).is_err() {
        return Ok(types::bool_false());
    }
    let taken = repo::username_taken(ctx.db, &username)
        .await
        .map_err(RpcFailure::internal)?;
    Ok(if taken {
        types::bool_false()
    } else {
        types::bool_true()
    })
}

async fn account_update_username(
    ctx: &RpcContext<'_>,
    reader: &mut Reader<'_>,
) -> Result<Vec<u8>, RpcFailure> {
    let username = reader.string()?;
    let Some(user_id) = ctx.user_id else {
        return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
    };
    let normalized = if username.is_empty() {
        String::new()
    } else {
        validate_username(&username)?
    };
    let mut user = ctx_user(ctx)
        .await?
        .ok_or_else(|| RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"))?;
    if !normalized.is_empty()
        && !normalized.eq_ignore_ascii_case(&user.username)
        && repo::username_taken(ctx.db, &normalized)
            .await
            .map_err(RpcFailure::internal)?
    {
        return Err(RpcFailure::new(400, "USERNAME_OCCUPIED"));
    }
    if normalized != user.username {
        repo::set_user_username(ctx.db, user_id, &normalized)
            .await
            .map_err(RpcFailure::internal)?;
        user.username = normalized;
    }
    Ok(user_bytes(user))
}

async fn contacts_resolve_username(
    ctx: &RpcContext<'_>,
    reader: &mut Reader<'_>,
) -> Result<Vec<u8>, RpcFailure> {
    let flags = reader.u32()?;
    let username = reader.string()?;
    if flags & 1 != 0 {
        let _referer = reader.string()?;
    }
    if ctx.user_id.is_none() {
        return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
    }
    if username.is_empty() {
        return Err(RpcFailure::new(400, "USERNAME_INVALID"));
    }
    if let Some(user) = repo::find_user_by_username(ctx.db, &username)
        .await
        .map_err(RpcFailure::internal)?
    {
        let peer = types::peer_user(user.id);
        return Ok(types::contacts_resolved_peer(
            &peer,
            &[],
            &[other_user_bytes(&user)],
        ));
    }
    if let Some(channel) = repo::find_channel_by_username(ctx.db, &username)
        .await
        .map_err(RpcFailure::internal)?
    {
        let peer = types::peer_channel(channel.id);
        let viewer = ctx.user_id.unwrap_or(0);
        return Ok(types::contacts_resolved_peer(
            &peer,
            &[channel_bytes(&channel, viewer)],
            &[],
        ));
    }
    Err(RpcFailure::new(400, "USERNAME_NOT_OCCUPIED"))
}

async fn channels_edit_admin(
    ctx: &RpcContext<'_>,
    reader: &mut Reader<'_>,
) -> Result<Vec<u8>, RpcFailure> {
    let flags = reader.u32()?;
    let (channel_id, access_hash) = read_input_channel(reader)?;
    let target = read_input_user(reader)?;
    let rights_flags = read_admin_rights(reader)?;
    let rank = if flags & 1 != 0 {
        reader.string()?
    } else {
        String::new()
    };
    let Some(actor_id) = ctx.user_id else {
        return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
    };
    let Some(channel) = repo::find_channel(ctx.db, channel_id)
        .await
        .map_err(RpcFailure::internal)?
    else {
        return Err(RpcFailure::new(400, "CHANNEL_INVALID"));
    };
    if channel.access_hash != 0 && channel.access_hash != access_hash {
        return Err(RpcFailure::new(400, "CHANNEL_INVALID"));
    };
    if channel.kind == "basic_group" {
        return Err(RpcFailure::new(400, "CHAT_ADMIN_REQUIRED"));
    }
    let Some((actor_role, actor_rights)) = repo::channel_member_rights(ctx.db, channel.id, actor_id)
        .await
        .map_err(RpcFailure::internal)?
    else {
        return Err(RpcFailure::new(403, "CHAT_ADMIN_REQUIRED"));
    };
    if actor_role != "owner" && (actor_role != "admin" || actor_rights & (1 << 9) == 0) {
        return Err(RpcFailure::new(403, "CHAT_ADMIN_REQUIRED"));
    }
    let target_id = match target {
        InputUser::SelfUser => actor_id,
        InputUser::Id(id) => id,
    };
    if target_id == channel.owner_user_id {
        return Err(RpcFailure::new(400, "USER_NOT_MUTABLE"));
    }
    if repo::channel_membership(ctx.db, channel.id, target_id)
        .await
        .map_err(RpcFailure::internal)?
        .is_none()
    {
        return Err(RpcFailure::new(400, "USER_NOT_PARTICIPANT"));
    }
    let rights = serde_json::json!({"flags": rights_flags});
    if rights_flags == 0 {
        repo::demote_chat_member(ctx.db, channel.id, target_id)
            .await
            .map_err(RpcFailure::internal)?;
    } else {
        let rank = rank.chars().take(16).collect::<String>();
        repo::set_chat_member_admin(ctx.db, channel.id, target_id, &rights, &rank, actor_id)
            .await
            .map_err(RpcFailure::internal)?;
    }
    publish_channel_update(ctx, &channel, actor_id).await
}

async fn channels_edit_banned(
    ctx: &RpcContext<'_>,
    reader: &mut Reader<'_>,
) -> Result<Vec<u8>, RpcFailure> {
    let (channel_id, access_hash) = read_input_channel(reader)?;
    let participant = read_input_peer(ctx, reader)?;
    let (rights_flags, until_date) = read_banned_rights(reader)?;
    let Some(actor_id) = ctx.user_id else {
        return Err(RpcFailure::new(401, "AUTH_KEY_UNREGISTERED"));
    };
    let Some(channel) = repo::find_channel(ctx.db, channel_id)
        .await
        .map_err(RpcFailure::internal)?
    else {
        return Err(RpcFailure::new(400, "CHANNEL_INVALID"));
    };
    if channel.access_hash != 0 && channel.access_hash != access_hash {
        return Err(RpcFailure::new(400, "CHANNEL_INVALID"));
    };
    if channel.kind == "basic_group" {
        return Err(RpcFailure::new(400, "CHAT_ADMIN_REQUIRED"));
    }
    let Some((actor_role, actor_rights)) = repo::channel_member_rights(ctx.db, channel.id, actor_id)
        .await
        .map_err(RpcFailure::internal)?
    else {
        return Err(RpcFailure::new(403, "CHAT_ADMIN_REQUIRED"));
    };
    if actor_role != "owner" && (actor_role != "admin" || actor_rights & (1 << 4) == 0) {
        return Err(RpcFailure::new(403, "CHAT_ADMIN_REQUIRED"));
    }
    let target_id = match participant {
        PeerRef::User(id) => id,
        _ => return Err(RpcFailure::new(400, "PEER_ID_INVALID")),
    };
    if target_id == channel.owner_user_id {
        return Err(RpcFailure::new(400, "USER_NOT_MUTABLE"));
    }
    if rights_flags == 0 {
        repo::delete_chat_ban(ctx.db, channel.id, target_id)
            .await
            .map_err(RpcFailure::internal)?;
    } else {
        let rights = serde_json::json!({"flags": rights_flags});
        repo::set_chat_ban(
            ctx.db,
            channel.id,
            target_id,
            &rights,
            until_date,
            actor_id,
        )
        .await
        .map_err(RpcFailure::internal)?;
        if rights_flags & 1 != 0 {
            repo::remove_channel_member(ctx.db, channel.id, target_id)
                .await
                .map_err(RpcFailure::internal)?;
        }
    }
    publish_channel_update(ctx, &channel, actor_id).await
}

fn read_admin_rights(reader: &mut Reader<'_>) -> Result<u32, RpcFailure> {
    reader.expect_constructor(ctor::CHAT_ADMIN_RIGHTS)?;
    Ok(reader.u32()?)
}

fn read_banned_rights(reader: &mut Reader<'_>) -> Result<(u32, i64), RpcFailure> {
    reader.expect_constructor(ctor::CHAT_BANNED_RIGHTS)?;
    let flags = reader.u32()?;
    let until_date = reader.i32()?;
    Ok((flags, i64::from(until_date)))
}

async fn ensure_not_banned(
    ctx: &RpcContext<'_>,
    chat_id: i64,
    user_id: i64,
    writing: bool,
) -> Result<(), RpcFailure> {
    let Some(ban) = repo::get_chat_ban(ctx.db, chat_id, user_id)
        .await
        .map_err(RpcFailure::internal)?
    else {
        return Ok(());
    };
    if ban.until_date > 0 && ban.until_date <= now() as i64 {
        return Ok(());
    }
    if ban.rights_flags & 1 != 0 || (writing && ban.rights_flags & (1 << 1) != 0) {
        return Err(RpcFailure::new(403, "USER_BANNED_IN_CHANNEL"));
    }
    Ok(())
}

/// Logs an `updateChannel` into the channel PTS stream and pushes it to all
/// active members, returning the Updates payload for the acting user.
async fn publish_channel_update(
    ctx: &RpcContext<'_>,
    channel: &repo::ChannelRecord,
    actor_id: i64,
) -> Result<Vec<u8>, RpcFailure> {
    let pts = repo::bump_channel_pts(ctx.db, channel.id)
        .await
        .map_err(RpcFailure::internal)?;
    let update = types::update_channel(channel.id);
    repo::log_channel_update(ctx.db, channel.id, pts, &update)
        .await
        .map_err(RpcFailure::internal)?;
    let updated = repo::find_channel(ctx.db, channel.id)
        .await
        .map_err(RpcFailure::internal)?
        .unwrap_or_else(|| channel.clone());
    let push = types::updates_with_chats(
        std::slice::from_ref(&update),
        &[],
        &[channel_bytes(&updated, actor_id)],
        now() as i32,
        0,
    );
    for member_id in repo::chat_member_ids_all(ctx.db, channel.id)
        .await
        .map_err(RpcFailure::internal)?
    {
        ctx.updates.publish(member_id, push.clone());
    }
    let actor_rights = repo::channel_member_rights(ctx.db, channel.id, actor_id)
        .await
        .map_err(RpcFailure::internal)?;
    let viewer_rights = actor_rights
        .filter(|(role, _)| role == "admin")
        .map(|(_, flags)| types::chat_admin_rights(flags));
    Ok(types::updates_with_chats(
        &[update],
        &[],
        &[channel_bytes_with_rights(
            &updated,
            actor_id,
            viewer_rights.as_deref(),
        )],
        now() as i32,
        0,
    ))
}

/// Returns an `updateChannel` response without changing the channel itself.
async fn deref_update_channel(
    ctx: &RpcContext<'_>,
    channel: &repo::ChannelRecord,
    user_id: i64,
) -> Result<Vec<u8>, RpcFailure> {
    let updated = repo::find_channel(ctx.db, channel.id)
        .await
        .map_err(RpcFailure::internal)?
        .unwrap_or_else(|| channel.clone());
    Ok(types::updates_with_chats(
        &[],
        &[],
        &[channel_bytes(&updated, user_id)],
        now() as i32,
        0,
    ))
}

fn validate_username(raw: &str) -> Result<String, RpcFailure> {
    let username = raw.trim().trim_start_matches('@').to_ascii_lowercase();
    if !(5..=32).contains(&username.len()) {
        return Err(RpcFailure::new(400, "USERNAME_INVALID"));
    }
    if !username
        .chars()
        .all(|c| c.is_ascii_lowercase() || c.is_ascii_digit() || c == '_')
    {
        return Err(RpcFailure::new(400, "USERNAME_INVALID"));
    }
    if !username.chars().next().is_some_and(|c| c.is_ascii_alphabetic()) {
        return Err(RpcFailure::new(400, "USERNAME_INVALID"));
    }
    if username.chars().all(|c| c.is_ascii_digit()) {
        return Err(RpcFailure::new(400, "USERNAME_INVALID"));
    }
    const RESERVED: &[&str] = &[
        "telegram",
        "admin",
        "administrator",
        "support",
        "help",
        "settings",
        "service",
        "premium",
        "tsrv",
        "tsrv_system",
    ];
    if RESERVED.contains(&username.as_str()) {
        return Err(RpcFailure::new(400, "USERNAME_PURCHASE_AVAILABLE"));
    }
    Ok(username)
}

fn read_input_channel(reader: &mut Reader<'_>) -> Result<(i64, i64), RpcFailure> {
    reader.expect_constructor(ctor::INPUT_CHANNEL)?;
    let channel_id = reader.i64()?;
    let access_hash = reader.i64()?;
    Ok((channel_id, access_hash))
}

fn read_input_users(ctx: &RpcContext<'_>, reader: &mut Reader<'_>) -> Result<Vec<i64>, RpcFailure> {
    reader.expect_constructor(ctor::VECTOR)?;
    let count = reader.i32()?;
    let mut ids = Vec::with_capacity(count.max(0) as usize);
    for _ in 0..count.max(0) {
        match reader.constructor()? {
            ctor::INPUT_USER_SELF => {
                if let Some(user_id) = ctx.user_id {
                    ids.push(user_id);
                }
            }
            ctor::INPUT_USER => {
                let user_id = reader.i64()?;
                let _access_hash = reader.i64()?;
                ids.push(user_id);
            }
            other => {
                return Err(RpcFailure::new(
                    400,
                    format!("UNSUPPORTED_INPUT_USER_0x{other:08X}"),
                ));
            }
        }
    }
    Ok(ids)
}

fn other_user_bytes(user: &UserRecord) -> Vec<u8> {
    let status = user_status_bytes(user);
    if user.is_bot {
        return types::user_bot_status(
            user.id,
            user.access_hash,
            &user.first_name,
            &user.last_name,
            &user.username,
            user.photo_media_id,
            user.bot_info_version.max(1),
            &status,
            false,
        );
    }
    types::user_other_with_photo_status(
        user.id,
        user.access_hash,
        &user.first_name,
        &user.last_name,
        &user.username,
        &user.phone,
        user.photo_media_id,
        user.emoji_status_document_id,
        &status,
    )
}

fn normalize_phone(phone: &str) -> Option<String> {
    let mut digits = String::with_capacity(phone.len());
    for character in phone.chars() {
        if character.is_ascii_digit() {
            digits.push(character);
        } else if matches!(character, '+' | ' ' | '-' | '(' | ')') {
            continue;
        } else {
            return None;
        }
    }
    if !(5..=20).contains(&digits.len()) {
        return None;
    }
    Some(format!("+{digits}"))
}

fn auth_code_key(phone: &str) -> String {
    format!("{}:auth-code:{phone}", tsrv_store::REDIS_PREFIX)
}

fn random_hex(bytes: usize) -> String {
    let mut output = String::with_capacity(bytes * 2);
    for _ in 0..bytes {
        output.push_str(&format!("{:02x}", rand::random::<u8>()));
    }
    output
}

fn now() -> u64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap_or_default()
        .as_secs()
}

#[cfg(test)]
mod tests {
    use super::*;

    fn update_bytes(hex: &str) -> Vec<u8> {
        hex.as_bytes()
            .chunks(2)
            .map(|pair| {
                u8::from_str_radix(std::str::from_utf8(pair).expect("ascii"), 16).expect("hex")
            })
            .collect()
    }

    #[test]
    fn channel_difference_marks_own_posts_as_outgoing() {
        // updateNewChannelMessage(message from user 5) captured from update_log.
        let mut update = update_bytes(
            "d904ba62d3b900760001000000000000530000002217515905000000000000\
             001e37a5a20f00000000000000786ee96a04746573740000000100000001000000",
        );
        patch_channel_message_out(&mut update, 5);
        let flags = u32::from_le_bytes(update[8..12].try_into().expect("four bytes"));
        assert_eq!(flags, 0x102);
    }

    #[test]
    fn channel_difference_keeps_other_posts_incoming() {
        let mut update = update_bytes(
            "d904ba62d3b900760001000000000000530000002217515905000000000000\
             001e37a5a20f00000000000000786ee96a04746573740000000100000001000000",
        );
        patch_channel_message_out(&mut update, 7);
        let flags = u32::from_le_bytes(update[8..12].try_into().expect("four bytes"));
        assert_eq!(flags, 0x100);
    }
}
