//! Small PostgreSQL repository used by the MTProto login flow.

use anyhow::{bail, Context, Result};
use sha2::{Digest, Sha256};
use sqlx::Row;

use tsrv_store::Db;

#[derive(Debug, Clone)]
pub struct UserRecord {
    pub id: i64,
    pub access_hash: i64,
    pub phone: String,
    pub first_name: String,
    pub last_name: String,
    /// Public username without the leading `@`, empty when unset.
    pub username: String,
    /// `media_files.id` of the profile photo, `0` when there is no avatar.
    pub photo_media_id: i64,
    /// Selected premium emoji status document, `0` when unset.
    pub emoji_status_document_id: i64,
    /// Unix timestamp of the last disconnect, `0` when never seen offline.
    pub last_seen_at: i64,
    /// `true` for bot accounts created from the admin portal.
    pub is_bot: bool,
    /// Telegram `bot_info_version`, `0` for regular users.
    pub bot_info_version: i32,
}

/// Admin-created bot metadata stored in `te_bots`.
#[allow(dead_code)]
#[derive(Debug, Clone)]
pub struct BotRecord {
    pub user_id: i64,
    /// First characters of the token, shown in the admin portal.
    pub token_prefix: String,
    pub disabled: bool,
    pub owner_user_id: Option<i64>,
    pub created_by: String,
}

#[derive(Debug, Clone)]
pub struct AuthKeyRecord {
    pub value: [u8; 256],
    pub salt: i64,
    /// `0` for a permanent key, otherwise the absolute unix expiry of a
    /// temporary key created from `p_q_inner_data_temp`.
    pub expires_at: i64,
}

pub async fn save_auth_key(
    db: &Db,
    auth_key_id: i64,
    value: &[u8],
    salt: i64,
    expires_at: i64,
) -> Result<()> {
    if value.len() != 256 {
        bail!("auth key must contain 256 bytes");
    }
    if expires_at < 0 {
        bail!("auth key expiry must not be negative");
    }
    sqlx::query(
        "INSERT INTO te_auth_keys (auth_key_id, body, server_salt, expires_at)
         VALUES ($1, $2, $3, $4)
         ON CONFLICT (auth_key_id)
         DO UPDATE SET body = EXCLUDED.body,
                       server_salt = EXCLUDED.server_salt,
                       expires_at = EXCLUDED.expires_at",
    )
    .bind(auth_key_id)
    .bind(value)
    .bind(salt)
    .bind(expires_at)
    .execute(db.pool())
    .await
    .context("store auth key")?;
    Ok(())
}

pub async fn load_auth_key(db: &Db, auth_key_id: i64) -> Result<Option<AuthKeyRecord>> {
    let row = sqlx::query(
        "SELECT body, server_salt, expires_at FROM te_auth_keys WHERE auth_key_id = $1",
    )
    .bind(auth_key_id)
    .fetch_optional(db.pool())
    .await
    .context("load auth key")?;
    let Some(row) = row else {
        return Ok(None);
    };
    let body: Vec<u8> = row.try_get("body").context("read auth key body")?;
    if body.len() != 256 {
        bail!("stored auth key has invalid length {}", body.len());
    }
    let mut value = [0u8; 256];
    value.copy_from_slice(&body);
    let salt: i64 = row.try_get("server_salt").context("read server salt")?;
    let expires_at: i64 = row.try_get("expires_at").context("read auth key expiry")?;
    Ok(Some(AuthKeyRecord {
        value,
        salt,
        expires_at,
    }))
}

pub async fn find_user_by_phone(db: &Db, phone: &str) -> Result<Option<UserRecord>> {
    let row = sqlx::query(
        "SELECT id, access_hash, phone, first_name, last_name, username, photo_media_id, emoji_status_document_id, last_seen_at, is_bot, bot_info_version
         FROM te_users WHERE phone = $1",
    )
    .bind(phone)
    .fetch_optional(db.pool())
    .await
    .context("find user by phone")?;
    row.map(user_from_row).transpose()
}

/// Phone of the built-in system assistant that is pre-added for every user.
pub const SYSTEM_USER_PHONE: &str = "+10000000000";

pub async fn ensure_system_user(db: &Db) -> Result<UserRecord> {
    if let Some(user) = find_user_by_phone(db, SYSTEM_USER_PHONE).await? {
        return Ok(user);
    }
    let row = sqlx::query(
        "INSERT INTO te_users (access_hash, phone, first_name, last_name, username)
         VALUES ($1, $2, $3, $4, $5)
         ON CONFLICT (phone) DO NOTHING
         RETURNING id, access_hash, phone, first_name, last_name, username, photo_media_id, emoji_status_document_id, last_seen_at, is_bot, bot_info_version",
    )
    .bind(0x1122_3344_5566_7788_i64)
    .bind(SYSTEM_USER_PHONE)
    .bind("绯荤粺鍔╂墜")
    .bind("")
    .bind("tsrv_system")
    .fetch_optional(db.pool())
    .await
    .context("create system user")?;
    if let Some(row) = row {
        return user_from_row(row);
    }
    find_user_by_phone(db, SYSTEM_USER_PHONE)
        .await
        .context("load system user")?
        .context("system user is missing")
}

pub async fn search_users(
    db: &Db,
    query: &str,
    limit: i32,
    exclude_user_id: i64,
) -> Result<Vec<UserRecord>> {
    let rows = sqlx::query(
        "SELECT id, access_hash, phone, first_name, last_name, username, photo_media_id, emoji_status_document_id, last_seen_at, is_bot, bot_info_version
         FROM te_users
         WHERE id <> $1
           AND NOT EXISTS (
               SELECT 1 FROM te_blocked_users b
               WHERE (b.owner_user_id = $1 AND b.blocked_user_id = te_users.id)
                  OR (b.owner_user_id = te_users.id AND b.blocked_user_id = $1)
           )
           AND (first_name ILIKE '%' || $2 || '%'
                OR last_name ILIKE '%' || $2 || '%'
                OR phone LIKE '%' || $2 || '%'
                OR username ILIKE '%' || $2 || '%')
         ORDER BY id
         LIMIT $3",
    )
    .bind(exclude_user_id)
    .bind(query)
    .bind(i64::from(limit.clamp(1, 50)))
    .fetch_all(db.pool())
    .await
    .context("search users")?;
    rows.into_iter().map(user_from_row).collect()
}

pub async fn find_user_by_id(db: &Db, id: i64) -> Result<Option<UserRecord>> {
    let row = sqlx::query(
        "SELECT id, access_hash, phone, first_name, last_name, username, photo_media_id, emoji_status_document_id, last_seen_at, is_bot, bot_info_version
         FROM te_users WHERE id = $1",
    )
    .bind(id)
    .fetch_optional(db.pool())
    .await
    .context("find user by id")?;
    row.map(user_from_row).transpose()
}

pub async fn create_user(
    db: &Db,
    phone: &str,
    first_name: &str,
    last_name: &str,
) -> Result<UserRecord> {
    let mut access_hash = rand::random::<i64>();
    if access_hash == 0 {
        access_hash = 1;
    }
    let row = sqlx::query(
        "INSERT INTO te_users (access_hash, phone, first_name, last_name)
         VALUES ($1, $2, $3, $4)
         RETURNING id, access_hash, phone, first_name, last_name, username, photo_media_id, emoji_status_document_id, last_seen_at, is_bot, bot_info_version",
    )
    .bind(access_hash)
    .bind(phone)
    .bind(first_name)
    .bind(last_name)
    .fetch_one(db.pool())
    .await
    .context("create user")?;
    user_from_row(row)
}

fn user_from_row(row: sqlx::postgres::PgRow) -> Result<UserRecord> {
    Ok(UserRecord {
        id: row.try_get("id").context("read user id")?,
        access_hash: row.try_get("access_hash").context("read access hash")?,
        phone: row.try_get("phone").context("read phone")?,
        first_name: row.try_get("first_name").context("read first name")?,
        last_name: row.try_get("last_name").context("read last name")?,
        username: row
            .try_get::<Option<String>, _>("username")
            .context("read username")?
            .unwrap_or_default(),
        photo_media_id: row
            .try_get::<Option<i64>, _>("photo_media_id")
            .context("read user photo")?
            .unwrap_or(0),
        emoji_status_document_id: row
            .try_get::<Option<i64>, _>("emoji_status_document_id")
            .context("read user emoji status")?
            .unwrap_or(0),
        last_seen_at: row
            .try_get::<Option<i64>, _>("last_seen_at")
            .context("read user last seen")?
            .unwrap_or(0),
        is_bot: row
            .try_get::<Option<bool>, _>("is_bot")
            .context("read user bot flag")?
            .unwrap_or(false),
        bot_info_version: row
            .try_get::<Option<i32>, _>("bot_info_version")
            .context("read user bot info version")?
            .unwrap_or(0),
    })
}

pub async fn set_user_emoji_status(db: &Db, user_id: i64, document_id: i64) -> Result<()> {
    sqlx::query("UPDATE te_users SET emoji_status_document_id = $2 WHERE id = $1")
        .bind(user_id)
        .bind(document_id)
        .execute(db.pool())
        .await
        .context("set user emoji status")?;
    Ok(())
}

pub async fn set_user_photo(db: &Db, user_id: i64, media_id: i64) -> Result<()> {
    sqlx::query("UPDATE te_users SET photo_media_id = $2 WHERE id = $1")
        .bind(user_id)
        .bind(media_id)
        .execute(db.pool())
        .await
        .context("set user photo")?;
    Ok(())
}

const BOT_TOKEN_ALPHABET: &[u8] =
    b"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_-";

/// SHA-256 hex digest of the full bot token (`<user_id>:<secret>`).
pub fn bot_token_hash(token: &str) -> String {
    let digest = Sha256::digest(token.as_bytes());
    let mut out = String::with_capacity(64);
    for byte in digest {
        out.push_str(&format!("{byte:02x}"));
    }
    out
}

fn bot_token_secret() -> String {
    let mut out = String::with_capacity(35);
    for _ in 0..35 {
        let index = (rand::random::<u32>() as usize) % BOT_TOKEN_ALPHABET.len();
        out.push(BOT_TOKEN_ALPHABET[index] as char);
    }
    out
}

/// Creates a bot account and its token. The plaintext token is returned only
/// once; only the SHA-256 digest is stored.
pub async fn create_bot(
    db: &Db,
    username: &str,
    first_name: &str,
    last_name: &str,
    owner_user_id: Option<i64>,
    created_by: &str,
) -> Result<(UserRecord, String)> {
    let mut access_hash = rand::random::<i64>();
    if access_hash == 0 {
        access_hash = 1;
    }
    let phone = format!("bot:{}", username.to_ascii_lowercase());
    let mut transaction = db.pool().begin().await.context("begin bot tx")?;
    let row = sqlx::query(
        "INSERT INTO te_users
             (access_hash, phone, first_name, last_name, username, is_bot, bot_info_version)
         VALUES ($1, $2, $3, $4, $5, true, 1)
         RETURNING id, access_hash, phone, first_name, last_name, username,
                   photo_media_id, emoji_status_document_id, last_seen_at, is_bot, bot_info_version",
    )
    .bind(access_hash)
    .bind(&phone)
    .bind(first_name)
    .bind(last_name)
    .bind(username)
    .fetch_one(&mut *transaction)
    .await
    .context("create bot user")?;
    let user = user_from_row(row)?;
    let token = format!("{}:{}", user.id, bot_token_secret());
    let prefix: String = token.chars().take(16).collect();
    sqlx::query(
        "INSERT INTO te_bots (user_id, token_prefix, token_hash, owner_user_id, created_by)
         VALUES ($1, $2, $3, $4, $5)",
    )
    .bind(user.id)
    .bind(&prefix)
    .bind(bot_token_hash(&token))
    .bind(owner_user_id)
    .bind(created_by)
    .execute(&mut *transaction)
    .await
    .context("store bot token")?;
    transaction.commit().await.context("commit bot tx")?;
    Ok((user, token))
}

/// Resolves an enabled bot by its plaintext token.
pub async fn find_bot_by_token(db: &Db, token: &str) -> Result<Option<(UserRecord, BotRecord)>> {
    let row = sqlx::query(
        "SELECT u.id, u.access_hash, u.phone, u.first_name, u.last_name, u.username,
                u.photo_media_id, u.emoji_status_document_id, u.last_seen_at,
                u.is_bot, u.bot_info_version,
                b.token_prefix, b.disabled, b.owner_user_id, b.created_by
         FROM te_bots b
         JOIN te_users u ON u.id = b.user_id
         WHERE b.token_hash = $1 AND NOT b.disabled",
    )
    .bind(bot_token_hash(token))
    .fetch_optional(db.pool())
    .await
    .context("find bot by token")?;
    row.map(|row| {
        let bot = BotRecord {
            user_id: row.try_get("id").context("read bot id")?,
            token_prefix: row.try_get("token_prefix").context("read bot prefix")?,
            disabled: row.try_get("disabled").context("read bot disabled")?,
            owner_user_id: row.try_get("owner_user_id").context("read bot owner")?,
            created_by: row.try_get("created_by").context("read bot creator")?,
        };
        Ok((user_from_row(row)?, bot))
    })
    .transpose()
}

/// Issues a fresh token for an existing bot, invalidating the previous one.
pub async fn reset_bot_token(db: &Db, user_id: i64) -> Result<Option<String>> {
    let exists: Option<i64> = sqlx::query_scalar("SELECT user_id FROM te_bots WHERE user_id = $1")
        .bind(user_id)
        .fetch_optional(db.pool())
        .await
        .context("find bot for token reset")?;
    let Some(_) = exists else {
        return Ok(None);
    };
    let token = format!("{user_id}:{}", bot_token_secret());
    let prefix: String = token.chars().take(16).collect();
    sqlx::query("UPDATE te_bots SET token_prefix = $2, token_hash = $3 WHERE user_id = $1")
        .bind(user_id)
        .bind(&prefix)
        .bind(bot_token_hash(&token))
        .execute(db.pool())
        .await
        .context("reset bot token")?;
    Ok(Some(token))
}

pub async fn set_bot_disabled(db: &Db, user_id: i64, disabled: bool) -> Result<bool> {
    let updated = sqlx::query("UPDATE te_bots SET disabled = $2 WHERE user_id = $1")
        .bind(user_id)
        .bind(disabled)
        .execute(db.pool())
        .await
        .context("set bot disabled")?
        .rows_affected();
    Ok(updated > 0)
}

pub async fn touch_bot_used(db: &Db, user_id: i64) -> Result<()> {
    sqlx::query("UPDATE te_bots SET last_used_at = now() WHERE user_id = $1")
        .bind(user_id)
        .execute(db.pool())
        .await
        .context("touch bot used")?;
    Ok(())
}

pub async fn enqueue_bot_update(
    db: &Db,
    bot_user_id: i64,
    payload: &serde_json::Value,
) -> Result<i64> {
    sqlx::query_scalar::<_, i64>(
        "INSERT INTO te_bot_updates (bot_user_id, payload) VALUES ($1, $2) RETURNING update_id",
    )
    .bind(bot_user_id)
    .bind(payload)
    .fetch_one(db.pool())
    .await
    .context("enqueue bot update")
}

pub async fn list_bot_updates(
    db: &Db,
    bot_user_id: i64,
    offset: i64,
    limit: i32,
) -> Result<Vec<(i64, serde_json::Value)>> {
    let rows = sqlx::query(
        "SELECT update_id, payload FROM te_bot_updates
         WHERE bot_user_id = $1 AND update_id >= $2
         ORDER BY update_id
         LIMIT $3",
    )
    .bind(bot_user_id)
    .bind(offset)
    .bind(i64::from(limit.clamp(1, 100)))
    .fetch_all(db.pool())
    .await
    .context("list bot updates")?;
    rows.into_iter()
        .map(|row| {
            Ok((
                row.try_get::<i64, _>("update_id")
                    .context("read bot update id")?,
                row.try_get::<serde_json::Value, _>("payload")
                    .context("read bot update payload")?,
            ))
        })
        .collect()
}

pub async fn user_profile_extras(
    db: &Db,
    user_id: i64,
) -> Result<(String, Option<(i32, i32, i32)>)> {
    let row = sqlx::query(
        "SELECT bio, birthday_day, birthday_month, birthday_year
         FROM te_users WHERE id = $1",
    )
    .bind(user_id)
    .fetch_one(db.pool())
    .await
    .context("load user profile extras")?;
    let bio: String = row.try_get("bio").context("read user bio")?;
    let day: i32 = row.try_get("birthday_day").context("read birthday day")?;
    let month: i32 = row
        .try_get("birthday_month")
        .context("read birthday month")?;
    let year: i32 = row
        .try_get("birthday_year")
        .context("read birthday year")?;
    let birthday = if day > 0 && month > 0 {
        Some((day, month, year))
    } else {
        None
    };
    Ok((bio, birthday))
}

pub async fn set_user_bio(db: &Db, user_id: i64, bio: &str) -> Result<()> {
    sqlx::query("UPDATE te_users SET bio = $2, updated_at = now() WHERE id = $1")
        .bind(user_id)
        .bind(bio)
        .execute(db.pool())
        .await
        .context("set user bio")?;
    Ok(())
}

pub async fn set_user_birthday(
    db: &Db,
    user_id: i64,
    day: i32,
    month: i32,
    year: i32,
) -> Result<()> {
    sqlx::query(
        "UPDATE te_users
         SET birthday_day = $2, birthday_month = $3, birthday_year = $4, updated_at = now()
         WHERE id = $1",
    )
    .bind(user_id)
    .bind(day)
    .bind(month)
    .bind(year)
    .execute(db.pool())
    .await
    .context("set user birthday")?;
    Ok(())
}

pub struct SessionDevice<'a> {
    pub device_model: &'a str,
    pub platform: &'a str,
    pub system_version: &'a str,
    pub app_version: &'a str,
    pub api_id: i32,
    pub app_name: &'a str,
    pub lang_code: &'a str,
}

pub async fn save_session(
    db: &Db,
    auth_key_id: i64,
    user_id: i64,
    layer: i32,
    ip: &str,
    device: &SessionDevice<'_>,
) -> Result<()> {
    sqlx::query(
        "INSERT INTO te_sessions
             (auth_key_id, user_id, layer, ip, device_model, platform, system_version,
              app_version, api_id, app_name, lang_code)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
         ON CONFLICT (auth_key_id)
         DO UPDATE SET user_id = EXCLUDED.user_id,
                       layer = EXCLUDED.layer,
                       ip = EXCLUDED.ip,
                       device_model = EXCLUDED.device_model,
                       platform = EXCLUDED.platform,
                       system_version = EXCLUDED.system_version,
                       app_version = EXCLUDED.app_version,
                       api_id = EXCLUDED.api_id,
                       app_name = EXCLUDED.app_name,
                       lang_code = EXCLUDED.lang_code,
                       last_active_at = now()",
    )
    .bind(auth_key_id)
    .bind(user_id)
    .bind(layer)
    .bind(ip)
    .bind(device.device_model)
    .bind(device.platform)
    .bind(device.system_version)
    .bind(device.app_version)
    .bind(device.api_id)
    .bind(device.app_name)
    .bind(device.lang_code)
    .execute(db.pool())
    .await
    .context("store session")?;
    Ok(())
}

#[derive(Debug, Clone)]
pub struct SessionRecord {
    pub auth_key_id: i64,
    pub device_model: String,
    pub platform: String,
    pub system_version: String,
    pub app_version: String,
    pub api_id: i32,
    pub app_name: String,
    pub ip: String,
    pub created_at: i64,
    pub last_active_at: i64,
}

pub async fn list_user_sessions(db: &Db, user_id: i64) -> Result<Vec<SessionRecord>> {
    let rows = sqlx::query(
        "SELECT auth_key_id, device_model, platform, system_version, app_version, api_id,
                app_name, ip,
                EXTRACT(EPOCH FROM created_at)::bigint AS created_at,
                EXTRACT(EPOCH FROM last_active_at)::bigint AS last_active_at
           FROM te_sessions
          WHERE user_id = $1
          ORDER BY last_active_at DESC",
    )
    .bind(user_id)
    .fetch_all(db.pool())
    .await
    .context("list sessions")?;
    rows.into_iter()
        .map(|row| {
            Ok(SessionRecord {
                auth_key_id: row.try_get("auth_key_id")?,
                device_model: row.try_get("device_model")?,
                platform: row.try_get("platform")?,
                system_version: row.try_get("system_version")?,
                app_version: row.try_get("app_version")?,
                api_id: row.try_get("api_id")?,
                app_name: row.try_get("app_name")?,
                ip: row.try_get("ip")?,
                created_at: row.try_get("created_at")?,
                last_active_at: row.try_get("last_active_at")?,
            })
        })
        .collect::<Result<Vec<_>>>()
        .context("decode sessions")
}

/// Revokes one of the user's sessions by removing its auth key.
pub async fn delete_user_session(db: &Db, user_id: i64, auth_key_id: i64) -> Result<bool> {
    let result = sqlx::query(
        "DELETE FROM te_auth_keys
          WHERE auth_key_id = $1
            AND EXISTS (
                SELECT 1 FROM te_sessions
                 WHERE auth_key_id = $1 AND user_id = $2
            )",
    )
    .bind(auth_key_id)
    .bind(user_id)
    .execute(db.pool())
    .await
    .context("delete session")?;
    Ok(result.rows_affected() > 0)
}

pub async fn delete_other_user_sessions(
    db: &Db,
    user_id: i64,
    keep_auth_key_id: i64,
) -> Result<u64> {
    let result = sqlx::query(
        "DELETE FROM te_auth_keys
          WHERE auth_key_id <> $2
            AND EXISTS (
                SELECT 1 FROM te_sessions
                 WHERE te_sessions.auth_key_id = te_auth_keys.auth_key_id
                   AND te_sessions.user_id = $1
            )",
    )
    .bind(user_id)
    .bind(keep_auth_key_id)
    .execute(db.pool())
    .await
    .context("delete other sessions")?;
    Ok(result.rows_affected())
}

pub async fn session_user(db: &Db, auth_key_id: i64) -> Result<Option<i64>> {
    let row = sqlx::query("SELECT user_id FROM te_sessions WHERE auth_key_id = $1")
        .bind(auth_key_id)
        .fetch_optional(db.pool())
        .await
        .context("load session user")?;
    row.map(|row| {
        row.try_get::<i64, _>("user_id")
            .context("read session user")
    })
    .transpose()
}

/// Creates a fresh QR login token for `auth_key_id`, dropping expired rows of
/// the same exporter first so the table stays small.
pub async fn create_login_token(
    db: &Db,
    token: &[u8],
    exporter_auth_key_id: i64,
    api_id: i32,
    created_at: i64,
    expires_at: i64,
) -> Result<()> {
    sqlx::query("DELETE FROM te_login_tokens WHERE expires_at < $1")
        .bind(created_at)
        .execute(db.pool())
        .await
        .context("purge login tokens")?;
    sqlx::query(
        "INSERT INTO te_login_tokens
             (token, exporter_auth_key_id, api_id, created_at, expires_at)
         VALUES ($1, $2, $3, $4, $5)",
    )
    .bind(token)
    .bind(exporter_auth_key_id)
    .bind(api_id)
    .bind(created_at)
    .bind(expires_at)
    .execute(db.pool())
    .await
    .context("store login token")?;
    Ok(())
}

/// Marks a QR token as approved by an already authorized user.
pub async fn confirm_login_token(
    db: &Db,
    token: &[u8],
    user_id: i64,
    confirmed_at: i64,
) -> Result<bool> {
    let result = sqlx::query(
        "UPDATE te_login_tokens
            SET confirmed_user_id = $2, confirmed_at = $3
          WHERE token = $1
            AND used = false
            AND expires_at > $4",
    )
    .bind(token)
    .bind(user_id)
    .bind(confirmed_at)
    .bind(confirmed_at)
    .execute(db.pool())
    .await
    .context("confirm login token")?;
    Ok(result.rows_affected() > 0)
}

/// Atomically consumes the newest approved token for `auth_key_id` and returns
/// the user that approved it.
pub async fn take_confirmed_login_token(
    db: &Db,
    exporter_auth_key_id: i64,
    now: i64,
) -> Result<Option<i64>> {
    let row = sqlx::query(
        "UPDATE te_login_tokens
            SET used = true
          WHERE token = (
              SELECT token FROM te_login_tokens
               WHERE exporter_auth_key_id = $1
                 AND confirmed_user_id IS NOT NULL
                 AND used = false
                 AND expires_at > $2
               ORDER BY created_at DESC
               LIMIT 1
          )
          RETURNING confirmed_user_id",
    )
    .bind(exporter_auth_key_id)
    .bind(now)
    .fetch_optional(db.pool())
    .await
    .context("consume login token")?;
    row.map(|row| {
        row.try_get::<i64, _>("confirmed_user_id")
            .context("read login token user")
    })
    .transpose()
}

/// `None` when the user does not exist, otherwise whether the account is
/// currently banned by the admin panel.
pub async fn user_banned(db: &Db, user_id: i64) -> Result<Option<bool>> {
    sqlx::query_scalar::<_, bool>(
        "SELECT banned_at IS NOT NULL FROM te_users WHERE id = $1",
    )
    .bind(user_id)
    .fetch_optional(db.pool())
    .await
    .context("load user ban state")
}

pub async fn set_user_banned(db: &Db, user_id: i64, banned: bool) -> Result<()> {
    sqlx::query(
        "UPDATE te_users
            SET banned_at = CASE WHEN $2 THEN now() ELSE NULL END,
                updated_at = now()
          WHERE id = $1",
    )
    .bind(user_id)
    .bind(banned)
    .execute(db.pool())
    .await
    .context("update user ban state")?;
    Ok(())
}

/// 两步验证（SRP）参数。`password_verifier` 为 NULL 时表示未启用。
#[derive(Debug, Clone)]
pub struct PasswordRecord {
    pub salt1: Vec<u8>,
    pub salt2: Vec<u8>,
    pub verifier: Vec<u8>,
    pub hint: String,
    pub g: i32,
}

pub async fn load_password(db: &Db, user_id: i64) -> Result<Option<PasswordRecord>> {
    let row = sqlx::query(
        "SELECT password_salt1, password_salt2, password_verifier,
                password_hint, password_g
           FROM te_users WHERE id = $1",
    )
    .bind(user_id)
    .fetch_optional(db.pool())
    .await
    .context("load user password")?;
    let Some(row) = row else {
        return Ok(None);
    };
    let verifier: Option<Vec<u8>> = row
        .try_get("password_verifier")
        .context("read password verifier")?;
    let Some(verifier) = verifier else {
        return Ok(None);
    };
    let salt1: Option<Vec<u8>> = row.try_get("password_salt1").context("read salt1")?;
    let salt2: Option<Vec<u8>> = row.try_get("password_salt2").context("read salt2")?;
    let (Some(salt1), Some(salt2)) = (salt1, salt2) else {
        return Ok(None);
    };
    Ok(Some(PasswordRecord {
        salt1,
        salt2,
        verifier,
        hint: row
            .try_get::<String, _>("password_hint")
            .context("read password hint")?,
        g: row
            .try_get::<i32, _>("password_g")
            .context("read password g")?,
    }))
}

#[allow(clippy::too_many_arguments)]
pub async fn set_password(
    db: &Db,
    user_id: i64,
    srp_id: i64,
    salt1: &[u8],
    salt2: &[u8],
    verifier: &[u8],
    hint: &str,
    g: i32,
) -> Result<()> {
    sqlx::query(
        "UPDATE te_users
            SET password_srp_id = $2,
                password_salt1 = $3,
                password_salt2 = $4,
                password_verifier = $5,
                password_hint = $6,
                password_g = $7,
                password_updated_at = $8,
                updated_at = now()
          WHERE id = $1",
    )
    .bind(user_id)
    .bind(srp_id)
    .bind(salt1)
    .bind(salt2)
    .bind(verifier)
    .bind(hint)
    .bind(g)
    .bind(unix_time())
    .execute(db.pool())
    .await
    .context("store user password")?;
    Ok(())
}

pub async fn clear_password(db: &Db, user_id: i64) -> Result<()> {
    sqlx::query(
        "UPDATE te_users
            SET password_srp_id = 0,
                password_salt1 = NULL,
                password_salt2 = NULL,
                password_verifier = NULL,
                password_hint = '',
                password_updated_at = $2,
                updated_at = now()
          WHERE id = $1",
    )
    .bind(user_id)
    .bind(unix_time())
    .execute(db.pool())
    .await
    .context("clear user password")?;
    Ok(())
}

/// 记录一条管理员操作审计。调用方应忽略审计失败，避免影响主操作。
#[allow(clippy::too_many_arguments)]
pub async fn insert_admin_audit(
    db: &Db,
    actor: &str,
    action: &str,
    target_user_id: Option<i64>,
    target_chat_id: Option<i64>,
    target_message_id: Option<i64>,
    params: &serde_json::Value,
    success: bool,
    error: Option<&str>,
) -> Result<()> {
    sqlx::query(
        "INSERT INTO te_admin_audit
             (actor, action, target_user_id, target_chat_id, target_message_id,
              params, success, error)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8)",
    )
    .bind(actor)
    .bind(action)
    .bind(target_user_id)
    .bind(target_chat_id)
    .bind(target_message_id)
    .bind(params)
    .bind(success)
    .bind(error)
    .execute(db.pool())
    .await
    .context("insert admin audit")?;
    Ok(())
}

pub async fn update_user_profile(
    db: &Db,
    id: i64,
    first_name: Option<&str>,
    last_name: Option<&str>,
) -> Result<UserRecord> {
    let row = sqlx::query(
        "UPDATE te_users
         SET first_name = COALESCE($2, first_name),
             last_name = COALESCE($3, last_name),
             updated_at = now()
         WHERE id = $1
         RETURNING id, access_hash, phone, first_name, last_name, username, photo_media_id, emoji_status_document_id, last_seen_at, is_bot, bot_info_version",
    )
    .bind(id)
    .bind(first_name)
    .bind(last_name)
    .fetch_one(db.pool())
    .await
    .context("update user profile")?;
    user_from_row(row)
}

pub async fn delete_session(db: &Db, auth_key_id: i64) -> Result<()> {
    sqlx::query("DELETE FROM te_sessions WHERE auth_key_id = $1")
        .bind(auth_key_id)
        .execute(db.pool())
        .await
        .context("delete session")?;
    Ok(())
}

pub async fn touch_session(db: &Db, auth_key_id: i64) -> Result<Option<i64>> {
    let row = sqlx::query(
        "UPDATE te_sessions SET last_active_at = now()
          WHERE auth_key_id = $1
          RETURNING user_id",
    )
    .bind(auth_key_id)
    .fetch_optional(db.pool())
    .await
    .context("touch session")?;
    row.map(|row| row.try_get::<i64, _>("user_id").context("read session user"))
        .transpose()
}

#[allow(dead_code)]
#[derive(Debug, Clone)]
pub struct MessageRecord {
    pub id: i64,
    pub chat_id: i64,
    pub seq: i64,
    pub sender_user_id: i64,
    pub text: String,
    pub sent_at: i64,
    pub media_id: Option<i64>,
    pub reply_to_msg_id: Option<i64>,
    /// Non-zero when the message belongs to an album.
    pub grouped_id: i64,
    pub edit_date: i64,
    pub fwd_from_user_id: Option<i64>,
    pub fwd_from_chat_id: Option<i64>,
    pub fwd_from_msg_id: Option<i64>,
    pub fwd_date: i64,
    pub action_kind: String,
    pub action_user_id: i64,
    pub action_title: String,
    pub scheduled_date: i64,
    /// View counter for channel / megagroup posts.
    pub views: i64,
    /// Raw `MessageEntity` constructors stored as hex strings in `entities`.
    pub entities: Vec<Vec<u8>>,
    /// Bot API `ReplyMarkup` JSON (inline keyboard), `None` for plain messages.
    pub reply_markup: Option<serde_json::Value>,
}

fn hex_encode(bytes: &[u8]) -> String {
    let mut out = String::with_capacity(bytes.len() * 2);
    for byte in bytes {
        out.push_str(&format!("{byte:02x}"));
    }
    out
}

fn hex_decode(hex: &str) -> Option<Vec<u8>> {
    if !hex.len().is_multiple_of(2) {
        return None;
    }
    let mut out = Vec::with_capacity(hex.len() / 2);
    for chunk in hex.as_bytes().chunks(2) {
        out.push(u8::from_str_radix(std::str::from_utf8(chunk).ok()?, 16).ok()?);
    }
    Some(out)
}

fn encode_entities(entities: &[Vec<u8>]) -> serde_json::Value {
    serde_json::Value::Array(
        entities
            .iter()
            .map(|bytes| serde_json::Value::String(hex_encode(bytes)))
            .collect(),
    )
}

fn entities_from_json(value: serde_json::Value) -> Vec<Vec<u8>> {
    let serde_json::Value::Array(items) = value else {
        return Vec::new();
    };
    items
        .into_iter()
        .filter_map(|item| {
            let serde_json::Value::String(hex) = item else {
                return None;
            };
            hex_decode(&hex)
        })
        .collect()
}

#[derive(Debug, Clone, Default)]
pub struct MessageExtras {
    pub reply_to_msg_id: Option<i64>,
    pub fwd_from_user_id: Option<i64>,
    pub fwd_from_chat_id: Option<i64>,
    pub fwd_from_msg_id: Option<i64>,
    pub fwd_date: i64,
    /// Shared album id for `messages.sendMultiMedia`, `0` for standalone media.
    pub grouped_id: i64,
    /// Raw `MessageEntity` constructors copied into `te_messages.entities`.
    pub entities: Vec<Vec<u8>>,
    /// Bot API `ReplyMarkup` JSON stored in `te_messages.reply_markup`.
    pub reply_markup: Option<serde_json::Value>,
}

#[allow(dead_code)]
#[derive(Debug, Clone)]
pub struct DialogRecord {
    pub chat_id: i64,
    pub kind: String,
    pub title: String,
    pub access_hash: i64,
    pub owner_user_id: i64,
    pub other_user_id: i64,
    pub message_id: i64,
    pub sender_user_id: i64,
    pub text: String,
    pub sent_at: i64,
    pub unread_count: i32,
    pub read_max_seq: i64,
    pub media_id: Option<i64>,
    pub pinned: bool,
}

#[allow(dead_code)]
#[derive(Debug, Clone)]
pub struct ChatInfo {
    pub id: i64,
    pub kind: String,
    pub title: String,
    pub access_hash: i64,
    pub owner_user_id: Option<i64>,
    pub private_user_a: Option<i64>,
    pub private_user_b: Option<i64>,
    pub pinned_msg_id: i64,
}

pub async fn find_chat(db: &Db, chat_id: i64) -> Result<Option<ChatInfo>> {
    let row = sqlx::query(
        "SELECT id, kind, title, access_hash, owner_user_id,
                private_user_a, private_user_b, pinned_msg_id
         FROM te_chats WHERE id = $1",
    )
    .bind(chat_id)
    .fetch_optional(db.pool())
    .await
    .context("find chat")?;
    row.map(|row| {
        Ok(ChatInfo {
            id: row.try_get("id").context("read chat id")?,
            kind: row.try_get("kind").context("read chat kind")?,
            title: row.try_get("title").context("read chat title")?,
            access_hash: row.try_get("access_hash").context("read chat access")?,
            owner_user_id: row.try_get("owner_user_id").context("read chat owner")?,
            private_user_a: row.try_get("private_user_a").context("read chat user a")?,
            private_user_b: row.try_get("private_user_b").context("read chat user b")?,
            pinned_msg_id: row.try_get("pinned_msg_id").context("read chat pin")?,
        })
    })
    .transpose()
}

pub async fn find_message(db: &Db, message_id: i64) -> Result<Option<MessageRecord>> {
    let row = sqlx::query(
        "SELECT id, chat_id, seq, sender_user_id, text, sent_at, media_id, grouped_id,
                reply_to_msg_id, edit_date, fwd_from_user_id, fwd_from_chat_id,
                fwd_from_msg_id, fwd_date, action_kind, action_user_id, action_title, scheduled_date,
                views, entities, reply_markup
         FROM te_messages WHERE id = $1",
    )
    .bind(message_id)
    .fetch_optional(db.pool())
    .await
    .context("find message")?;
    row.map(message_from_row).transpose()
}

pub async fn find_messages(db: &Db, ids: &[i64]) -> Result<Vec<MessageRecord>> {
    if ids.is_empty() {
        return Ok(Vec::new());
    }
    let rows = sqlx::query(
        "SELECT id, chat_id, seq, sender_user_id, text, sent_at, media_id, grouped_id,
                reply_to_msg_id, edit_date, fwd_from_user_id, fwd_from_chat_id,
                fwd_from_msg_id, fwd_date, action_kind, action_user_id, action_title, scheduled_date,
                views, entities, reply_markup
         FROM te_messages
         WHERE id = ANY($1)
         ORDER BY id DESC",
    )
    .bind(ids)
    .fetch_all(db.pool())
    .await
    .context("find messages")?;
    rows.into_iter().map(message_from_row).collect()
}

pub async fn update_message_text(
    db: &Db,
    message_id: i64,
    text: &str,
    entities: Option<&[Vec<u8>]>,
    edit_date: i64,
) -> Result<MessageRecord> {
    let entities = entities.map(encode_entities);
    let row = sqlx::query(
        "UPDATE te_messages
         SET text = $2, entities = COALESCE($3, entities), edit_date = $4
         WHERE id = $1
         RETURNING id, chat_id, seq, sender_user_id, text, sent_at, media_id, grouped_id,
                   reply_to_msg_id, edit_date, fwd_from_user_id, fwd_from_chat_id,
                   fwd_from_msg_id, fwd_date, action_kind, action_user_id, action_title, scheduled_date,
                views, entities, reply_markup",
    )
    .bind(message_id)
    .bind(text)
    .bind(entities)
    .bind(edit_date)
    .fetch_one(db.pool())
    .await
    .context("edit message")?;
    message_from_row(row)
}

pub async fn set_message_media(
    db: &Db,
    message_id: i64,
    media_id: Option<i64>,
    edit_date: i64,
) -> Result<MessageRecord> {
    let row = sqlx::query(
        "UPDATE te_messages SET media_id = $2, edit_date = $3
         WHERE id = $1
         RETURNING id, chat_id, seq, sender_user_id, text, sent_at, media_id, grouped_id,
                   reply_to_msg_id, edit_date, fwd_from_user_id, fwd_from_chat_id,
                   fwd_from_msg_id, fwd_date, action_kind, action_user_id, action_title, scheduled_date,
                views, entities, reply_markup",
    )
    .bind(message_id)
    .bind(media_id)
    .bind(edit_date)
    .fetch_one(db.pool())
    .await
    .context("edit message media")?;
    message_from_row(row)
}

pub async fn delete_messages(db: &Db, chat_id: i64, ids: &[i64]) -> Result<Vec<MessageRecord>> {
    if ids.is_empty() {
        return Ok(Vec::new());
    }
    let mut transaction = db.pool().begin().await.context("begin delete tx")?;
    sqlx::query("SELECT id FROM te_chats WHERE id = $1 FOR UPDATE")
        .bind(chat_id)
        .execute(&mut *transaction)
        .await
        .context("lock chat for delete")?;
    let rows = sqlx::query(
        "DELETE FROM te_messages
         WHERE chat_id = $1 AND id = ANY($2)
         RETURNING id, chat_id, seq, sender_user_id, text, sent_at, media_id, grouped_id,
                   reply_to_msg_id, edit_date, fwd_from_user_id, fwd_from_chat_id,
                   fwd_from_msg_id, fwd_date, action_kind, action_user_id, action_title, scheduled_date,
                views, entities, reply_markup",
    )
    .bind(chat_id)
    .bind(ids)
    .fetch_all(&mut *transaction)
    .await
    .context("delete messages")?;
    let records = rows
        .into_iter()
        .map(message_from_row)
        .collect::<Result<Vec<_>>>()?;
    sqlx::query(
        "UPDATE te_user_dialogs d
         SET top_message_seq = COALESCE(
                 (SELECT MAX(m.seq) FROM te_messages m WHERE m.chat_id = d.chat_id), 0),
             top_message_date = COALESCE(
                 (SELECT m.sent_at FROM te_messages m
                  WHERE m.chat_id = d.chat_id ORDER BY m.seq DESC LIMIT 1), 0),
             unread_count = LEAST(
                 d.unread_count,
                 GREATEST(
                     (SELECT COUNT(*) FROM te_messages m
                      WHERE m.chat_id = d.chat_id AND m.seq > d.read_max_seq), 0
                 )::int),
             updated_at = now()
         WHERE d.chat_id = $1",
    )
    .bind(chat_id)
    .execute(&mut *transaction)
    .await
    .context("refresh dialogs after delete")?;
    transaction.commit().await.context("commit delete tx")?;
    Ok(records)
}

#[derive(Debug, Clone)]
pub struct LoggedUpdate {
    pub pts: i64,
    pub data: Vec<u8>,
}

pub async fn log_user_update(db: &Db, user_id: i64, pts: i32, update: &[u8]) -> Result<()> {
    sqlx::query(
        "INSERT INTO te_update_log (user_id, pts, update_data)
         VALUES ($1, $2, $3)",
    )
    .bind(user_id)
    .bind(i64::from(pts))
    .bind(update)
    .execute(db.pool())
    .await
    .context("log user update")?;
    Ok(())
}

pub async fn log_channel_update(db: &Db, channel_id: i64, pts: i32, update: &[u8]) -> Result<()> {
    sqlx::query(
        "INSERT INTO te_update_log (channel_id, pts, update_data)
         VALUES ($1, $2, $3)",
    )
    .bind(channel_id)
    .bind(i64::from(pts))
    .bind(update)
    .execute(db.pool())
    .await
    .context("log channel update")?;
    Ok(())
}

pub async fn user_updates_after(
    db: &Db,
    user_id: i64,
    pts: i64,
    limit: i64,
) -> Result<Vec<LoggedUpdate>> {
    let rows = sqlx::query(
        "SELECT pts, update_data FROM te_update_log
         WHERE user_id = $1 AND pts > $2
         ORDER BY pts, id
         LIMIT $3",
    )
    .bind(user_id)
    .bind(pts)
    .bind(limit)
    .fetch_all(db.pool())
    .await
    .context("load user update log")?;
    rows.into_iter()
        .map(|row| {
            Ok(LoggedUpdate {
                pts: row.try_get("pts").context("read update pts")?,
                data: row.try_get("update_data").context("read update data")?,
            })
        })
        .collect()
}

/// Oldest channel update still available for replay; `None` when the log is
/// empty. A client whose `pts` is older than this needs a full snapshot.
pub async fn channel_oldest_update_pts(db: &Db, channel_id: i64) -> Result<Option<i64>> {
    let row = sqlx::query("SELECT min(pts) AS oldest FROM te_update_log WHERE channel_id = $1")
        .bind(channel_id)
        .fetch_one(db.pool())
        .await
        .context("load oldest channel pts")?;
    let oldest: Option<i64> = row.try_get("oldest").context("read oldest pts")?;
    Ok(oldest)
}

pub async fn channel_updates_after(
    db: &Db,
    channel_id: i64,
    pts: i64,
    limit: i64,
) -> Result<Vec<LoggedUpdate>> {
    let rows = sqlx::query(
        "SELECT pts, update_data FROM te_update_log
         WHERE channel_id = $1 AND pts > $2
         ORDER BY pts, id
         LIMIT $3",
    )
    .bind(channel_id)
    .bind(pts)
    .bind(limit)
    .fetch_all(db.pool())
    .await
    .context("load channel update log")?;
    rows.into_iter()
        .map(|row| {
            Ok(LoggedUpdate {
                pts: row.try_get("pts").context("read update pts")?,
                data: row.try_get("update_data").context("read update data")?,
            })
        })
        .collect()
}

pub async fn oldest_user_update_pts(db: &Db, user_id: i64) -> Result<Option<i64>> {
    let pts = sqlx::query_scalar::<_, Option<i64>>(
        "SELECT MIN(pts)::bigint FROM te_update_log WHERE user_id = $1",
    )
    .bind(user_id)
    .fetch_one(db.pool())
    .await
    .context("load oldest user update pts")?;
    Ok(pts)
}

pub async fn total_unread(db: &Db, user_id: i64) -> Result<i32> {
    let unread = sqlx::query_scalar::<_, i64>(
        "SELECT COALESCE(SUM(unread_count), 0)::bigint
         FROM te_user_dialogs WHERE user_id = $1",
    )
    .bind(user_id)
    .fetch_one(db.pool())
    .await
    .context("load total unread")?;
    Ok(unread as i32)
}

#[derive(Debug, Clone, Default)]
pub struct OpsStats {
    pub users: i64,
    pub chats: i64,
    pub messages: i64,
    pub media: i64,
    pub pending_scheduled: i64,
    pub update_log: i64,
    pub auth_keys: i64,
    pub temp_bindings: i64,
    pub reactions: i64,
}

pub async fn ops_stats(db: &Db) -> Result<OpsStats> {
    let row = sqlx::query(
        "SELECT
             (SELECT COUNT(*) FROM te_users)::bigint AS users,
             (SELECT COUNT(*) FROM te_chats)::bigint AS chats,
             (SELECT COUNT(*) FROM te_messages)::bigint AS messages,
             (SELECT COUNT(*) FROM te_media_files)::bigint AS media,
             (SELECT COUNT(*) FROM te_messages WHERE scheduled_date > 0)::bigint AS pending_scheduled,
             (SELECT COUNT(*) FROM te_update_log)::bigint AS update_log,
             (SELECT COUNT(*) FROM te_auth_keys)::bigint AS auth_keys,
             (SELECT COUNT(*) FROM te_temp_auth_key_bindings)::bigint AS temp_bindings,
             (SELECT COUNT(*) FROM te_message_reactions)::bigint AS reactions",
    )
    .fetch_one(db.pool())
    .await
    .context("load ops stats")?;
    Ok(OpsStats {
        users: row.try_get("users").context("read users count")?,
        chats: row.try_get("chats").context("read chats count")?,
        messages: row.try_get("messages").context("read messages count")?,
        media: row.try_get("media").context("read media count")?,
        pending_scheduled: row
            .try_get("pending_scheduled")
            .context("read scheduled count")?,
        update_log: row.try_get("update_log").context("read update log count")?,
        auth_keys: row.try_get("auth_keys").context("read auth keys count")?,
        temp_bindings: row
            .try_get("temp_bindings")
            .context("read temp bindings count")?,
        reactions: row.try_get("reactions").context("read reactions count")?,
    })
}

pub async fn prune_update_log(db: &Db, retention_seconds: i64) -> Result<u64> {
    let result = sqlx::query(
        "DELETE FROM te_update_log
         WHERE created_at < now() - make_interval(secs => $1)",
    )
    .bind(retention_seconds as f64)
    .execute(db.pool())
    .await
    .context("prune update log")?;
    Ok(result.rows_affected())
}

pub async fn delete_expired_auth_keys(db: &Db, timestamp: i64) -> Result<u64> {
    let result = sqlx::query("DELETE FROM te_auth_keys WHERE expires_at > 0 AND expires_at <= $1")
        .bind(timestamp)
        .execute(db.pool())
        .await
        .context("delete expired auth keys")?;
    Ok(result.rows_affected())
}

pub async fn delete_stale_upload_parts(db: &Db, ttl_seconds: i64) -> Result<Vec<i64>> {
    let rows = sqlx::query_scalar::<_, i64>(
        "DELETE FROM te_upload_parts
         WHERE upload_id IN (
             SELECT upload_id FROM te_upload_parts
             GROUP BY upload_id
             HAVING MAX(created_at) < now() - make_interval(secs => $1)
         )
         RETURNING upload_id",
    )
    .bind(ttl_seconds as f64)
    .fetch_all(db.pool())
    .await
    .context("delete stale upload parts")?;
    Ok(rows)
}

pub async fn bump_user_pts(db: &Db, user_id: i64) -> Result<i32> {
    let pts = sqlx::query_scalar::<_, i64>(
        "UPDATE te_users SET pts = pts + 1 WHERE id = $1 RETURNING pts",
    )
    .bind(user_id)
    .fetch_one(db.pool())
    .await
    .context("bump user pts")?;
    Ok(pts as i32)
}

pub async fn bump_channel_pts(db: &Db, chat_id: i64) -> Result<i32> {
    let pts = sqlx::query_scalar::<_, i64>(
        "UPDATE te_chats SET pts = pts + 1, updated_at = now()
         WHERE id = $1 RETURNING pts",
    )
    .bind(chat_id)
    .fetch_one(db.pool())
    .await
    .context("bump channel pts")?;
    Ok(pts as i32)
}

pub async fn chat_member_ids(db: &Db, chat_id: i64) -> Result<Vec<i64>> {
    sqlx::query_scalar::<_, i64>(
        "SELECT user_id FROM te_chat_members WHERE chat_id = $1 AND left_at = 0",
    )
    .bind(chat_id)
    .fetch_all(db.pool())
    .await
    .context("load chat members")
}

pub async fn set_pinned_message(db: &Db, chat_id: i64, message_id: i64) -> Result<()> {
    sqlx::query("UPDATE te_chats SET pinned_msg_id = $2, updated_at = now() WHERE id = $1")
        .bind(chat_id)
        .bind(message_id)
        .execute(db.pool())
        .await
        .context("set pinned message")?;
    Ok(())
}

pub async fn pinned_message_id(db: &Db, chat_id: i64) -> Result<i64> {
    sqlx::query_scalar::<_, i64>("SELECT pinned_msg_id FROM te_chats WHERE id = $1")
        .bind(chat_id)
        .fetch_one(db.pool())
        .await
        .context("load pinned message")
}

pub async fn list_contacts(db: &Db, owner_user_id: i64) -> Result<Vec<UserRecord>> {
    let rows = sqlx::query(
        "SELECT u.id, u.access_hash, u.phone, u.first_name, u.last_name, u.username,
                u.photo_media_id, u.emoji_status_document_id, u.last_seen_at
         FROM te_contacts c
         JOIN te_users u ON u.id = c.contact_user_id
         WHERE c.owner_user_id = $1
           AND NOT EXISTS (
               SELECT 1 FROM te_blocked_users b
               WHERE (b.owner_user_id = $1 AND b.blocked_user_id = u.id)
                  OR (b.owner_user_id = u.id AND b.blocked_user_id = $1)
           )
         ORDER BY u.id",
    )
    .bind(owner_user_id)
    .fetch_all(db.pool())
    .await
    .context("list contacts")?;
    rows.into_iter().map(user_from_row).collect()
}

pub async fn add_contact(db: &Db, owner_user_id: i64, contact_user_id: i64) -> Result<()> {
    sqlx::query(
        "INSERT INTO te_contacts (owner_user_id, contact_user_id)
         VALUES ($1, $2)
         ON CONFLICT DO NOTHING",
    )
    .bind(owner_user_id)
    .bind(contact_user_id)
    .execute(db.pool())
    .await
    .context("add contact")?;
    Ok(())
}

pub async fn delete_contacts(db: &Db, owner_user_id: i64, contact_ids: &[i64]) -> Result<()> {
    sqlx::query(
        "DELETE FROM te_contacts
         WHERE owner_user_id = $1 AND contact_user_id = ANY($2)",
    )
    .bind(owner_user_id)
    .bind(contact_ids)
    .execute(db.pool())
    .await
    .context("delete contacts")?;
    Ok(())
}

pub async fn block_user(db: &Db, owner_user_id: i64, blocked_user_id: i64) -> Result<()> {
    sqlx::query(
        "INSERT INTO te_blocked_users (owner_user_id, blocked_user_id)
         VALUES ($1, $2)
         ON CONFLICT DO NOTHING",
    )
    .bind(owner_user_id)
    .bind(blocked_user_id)
    .execute(db.pool())
    .await
    .context("block user")?;
    Ok(())
}

pub async fn unblock_user(db: &Db, owner_user_id: i64, blocked_user_id: i64) -> Result<()> {
    sqlx::query(
        "DELETE FROM te_blocked_users
         WHERE owner_user_id = $1 AND blocked_user_id = $2",
    )
    .bind(owner_user_id)
    .bind(blocked_user_id)
    .execute(db.pool())
    .await
    .context("unblock user")?;
    Ok(())
}

pub async fn list_blocked(db: &Db, owner_user_id: i64) -> Result<Vec<(UserRecord, i64)>> {
    let rows = sqlx::query(
        "SELECT u.id, u.access_hash, u.phone, u.first_name, u.last_name, u.username,
                u.photo_media_id, u.emoji_status_document_id, u.last_seen_at,
                EXTRACT(EPOCH FROM b.created_at)::bigint AS blocked_at
         FROM te_blocked_users b
         JOIN te_users u ON u.id = b.blocked_user_id
         WHERE b.owner_user_id = $1
         ORDER BY b.created_at DESC",
    )
    .bind(owner_user_id)
    .fetch_all(db.pool())
    .await
    .context("list blocked users")?;
    rows.into_iter()
        .map(|row| {
            let blocked_at: i64 = row.try_get("blocked_at").context("read blocked date")?;
            Ok((user_from_row(row)?, blocked_at))
        })
        .collect()
}

/// Returns true when either user has blocked the other.
pub async fn is_blocked_between(db: &Db, user_a: i64, user_b: i64) -> Result<bool> {
    let blocked: i64 = sqlx::query_scalar(
        "SELECT count(*) FROM te_blocked_users
         WHERE (owner_user_id = $1 AND blocked_user_id = $2)
            OR (owner_user_id = $2 AND blocked_user_id = $1)",
    )
    .bind(user_a)
    .bind(user_b)
    .fetch_one(db.pool())
    .await
    .context("check blocked users")?;
    Ok(blocked > 0)
}

pub async fn privacy_rules(
    db: &Db,
    user_id: i64,
    key: i64,
) -> Result<Option<serde_json::Value>> {
    let rules: Option<serde_json::Value> = sqlx::query_scalar(
        "SELECT rules FROM te_privacy_settings WHERE user_id = $1 AND key = $2",
    )
    .bind(user_id)
    .bind(key)
    .fetch_optional(db.pool())
    .await
    .context("load privacy settings")?;
    Ok(rules)
}

pub async fn save_privacy_rules(
    db: &Db,
    user_id: i64,
    key: i64,
    rules: &serde_json::Value,
) -> Result<()> {
    sqlx::query(
        "INSERT INTO te_privacy_settings (user_id, key, rules, updated_at)
         VALUES ($1, $2, $3, now())
         ON CONFLICT (user_id, key)
         DO UPDATE SET rules = EXCLUDED.rules, updated_at = now()",
    )
    .bind(user_id)
    .bind(key)
    .bind(rules)
    .execute(db.pool())
    .await
    .context("save privacy settings")?;
    Ok(())
}

pub async fn reaction_notify_settings(
    db: &Db,
    user_id: i64,
) -> Result<Option<serde_json::Value>> {
    let settings: Option<serde_json::Value> = sqlx::query_scalar(
        "SELECT settings FROM te_reaction_notify_settings WHERE user_id = $1",
    )
    .bind(user_id)
    .fetch_optional(db.pool())
    .await
    .context("load reaction notify settings")?;
    Ok(settings)
}

pub async fn save_reaction_notify_settings(
    db: &Db,
    user_id: i64,
    settings: &serde_json::Value,
) -> Result<()> {
    sqlx::query(
        "INSERT INTO te_reaction_notify_settings (user_id, settings, updated_at)
         VALUES ($1, $2, now())
         ON CONFLICT (user_id)
         DO UPDATE SET settings = EXCLUDED.settings, updated_at = now()",
    )
    .bind(user_id)
    .bind(settings)
    .execute(db.pool())
    .await
    .context("save reaction notify settings")?;
    Ok(())
}

pub async fn find_private_chat(db: &Db, user_a: i64, user_b: i64) -> Result<Option<i64>> {
    let (first, second) = ordered_pair(user_a, user_b);
    let row = sqlx::query_scalar::<_, i64>(
        "SELECT id FROM te_chats
         WHERE kind = 'private' AND private_user_a = $1 AND private_user_b = $2",
    )
    .bind(first)
    .bind(second)
    .fetch_optional(db.pool())
    .await
    .context("find private chat")?;
    Ok(row)
}

pub async fn list_dialogs(db: &Db, user_id: i64) -> Result<Vec<DialogRecord>> {
    let rows = sqlx::query(
        "SELECT c.id AS chat_id,
                c.kind,
                c.title,
                c.access_hash,
                COALESCE(c.owner_user_id, 0) AS owner_user_id,
                COALESCE(CASE WHEN c.private_user_a = $1 THEN c.private_user_b
                         ELSE c.private_user_a END, 0) AS other_user_id,
                COALESCE(m.id, 0) AS message_id,
                COALESCE(m.sender_user_id, 0) AS sender_user_id,
                COALESCE(m.text, '') AS text,
                COALESCE(m.sent_at, 0) AS sent_at,
                m.media_id,
                d.unread_count,
                d.read_max_seq,
                (p.chat_id IS NOT NULL) AS pinned
         FROM te_user_dialogs d
         JOIN te_chats c ON c.id = d.chat_id
         LEFT JOIN te_messages m ON m.chat_id = c.id AND m.seq = d.top_message_seq
         LEFT JOIN te_pinned_dialogs p ON p.user_id = d.user_id AND p.chat_id = d.chat_id
         WHERE d.user_id = $1
         ORDER BY (p.chat_id IS NOT NULL) DESC, p.sort_order ASC,
                  d.top_message_date DESC, m.id DESC",
    )
    .bind(user_id)
    .fetch_all(db.pool())
    .await
    .context("list dialogs")?;
    rows.into_iter()
        .map(|row| {
            Ok(DialogRecord {
                chat_id: row.try_get("chat_id").context("read dialog chat")?,
                kind: row.try_get("kind").context("read dialog kind")?,
                title: row.try_get("title").context("read dialog title")?,
                access_hash: row.try_get("access_hash").context("read dialog access")?,
                owner_user_id: row.try_get("owner_user_id").context("read dialog owner")?,
                other_user_id: row.try_get("other_user_id").context("read dialog peer")?,
                message_id: row.try_get("message_id").context("read dialog message")?,
                sender_user_id: row
                    .try_get("sender_user_id")
                    .context("read dialog sender")?,
                text: row.try_get("text").context("read dialog text")?,
                sent_at: row.try_get("sent_at").context("read dialog date")?,
                unread_count: row.try_get("unread_count").context("read unread count")?,
                read_max_seq: row.try_get("read_max_seq").context("read read seq")?,
                media_id: row.try_get("media_id").context("read dialog media")?,
                pinned: row.try_get("pinned").context("read dialog pinned")?,
            })
        })
        .collect()
}

pub async fn list_pinned_dialogs(db: &Db, user_id: i64) -> Result<Vec<DialogRecord>> {
    let rows = sqlx::query(
        "SELECT c.id AS chat_id,
                c.kind,
                c.title,
                c.access_hash,
                COALESCE(c.owner_user_id, 0) AS owner_user_id,
                COALESCE(CASE WHEN c.private_user_a = $1 THEN c.private_user_b
                         ELSE c.private_user_a END, 0) AS other_user_id,
                COALESCE(m.id, 0) AS message_id,
                COALESCE(m.sender_user_id, 0) AS sender_user_id,
                COALESCE(m.text, '') AS text,
                COALESCE(m.sent_at, 0) AS sent_at,
                m.media_id,
                d.unread_count,
                d.read_max_seq,
                true AS pinned
         FROM te_pinned_dialogs p
         JOIN te_user_dialogs d ON d.user_id = p.user_id AND d.chat_id = p.chat_id
         JOIN te_chats c ON c.id = p.chat_id
         LEFT JOIN te_messages m ON m.chat_id = c.id AND m.seq = d.top_message_seq
         WHERE p.user_id = $1
         ORDER BY p.sort_order ASC, p.pinned_at DESC",
    )
    .bind(user_id)
    .fetch_all(db.pool())
    .await
    .context("list pinned dialogs")?;
    rows.into_iter()
        .map(|row| {
            Ok(DialogRecord {
                chat_id: row.try_get("chat_id").context("read pinned chat")?,
                kind: row.try_get("kind").context("read pinned kind")?,
                title: row.try_get("title").context("read pinned title")?,
                access_hash: row.try_get("access_hash").context("read pinned access")?,
                owner_user_id: row.try_get("owner_user_id").context("read pinned owner")?,
                other_user_id: row.try_get("other_user_id").context("read pinned peer")?,
                message_id: row.try_get("message_id").context("read pinned message")?,
                sender_user_id: row
                    .try_get("sender_user_id")
                    .context("read pinned sender")?,
                text: row.try_get("text").context("read pinned text")?,
                sent_at: row.try_get("sent_at").context("read pinned date")?,
                unread_count: row.try_get("unread_count").context("read pinned unread")?,
                read_max_seq: row.try_get("read_max_seq").context("read pinned read seq")?,
                media_id: row.try_get("media_id").context("read pinned media")?,
                pinned: true,
            })
        })
        .collect()
}

#[derive(Debug, Clone)]
pub struct DraftRecord {
    pub chat_id: i64,
    pub kind: String,
    pub other_user_id: i64,
    pub text: String,
    pub reply_to: i64,
    pub updated_at: i64,
}

pub async fn save_draft(
    db: &Db,
    user_id: i64,
    chat_id: i64,
    text: &str,
    reply_to: i64,
) -> Result<()> {
    if text.trim().is_empty() {
        return clear_draft(db, user_id, chat_id).await;
    }
    sqlx::query(
        "INSERT INTO te_drafts (user_id, chat_id, text, reply_to, updated_at)
         VALUES ($1, $2, $3, $4, $5)
         ON CONFLICT (user_id, chat_id)
         DO UPDATE SET text = EXCLUDED.text,
                       reply_to = EXCLUDED.reply_to,
                       updated_at = EXCLUDED.updated_at",
    )
    .bind(user_id)
    .bind(chat_id)
    .bind(text)
    .bind(reply_to)
    .bind(unix_time())
    .execute(db.pool())
    .await
    .context("save draft")?;
    Ok(())
}

pub async fn clear_draft(db: &Db, user_id: i64, chat_id: i64) -> Result<()> {
    sqlx::query("DELETE FROM te_drafts WHERE user_id = $1 AND chat_id = $2")
        .bind(user_id)
        .bind(chat_id)
        .execute(db.pool())
        .await
        .context("clear draft")?;
    Ok(())
}

pub async fn list_drafts(db: &Db, user_id: i64) -> Result<Vec<DraftRecord>> {
    let rows = sqlx::query(
        "SELECT dr.chat_id,
                c.kind,
                COALESCE(CASE WHEN c.private_user_a = $1 THEN c.private_user_b
                         ELSE c.private_user_a END, 0) AS other_user_id,
                dr.text,
                dr.reply_to,
                dr.updated_at
         FROM te_drafts dr
         JOIN te_chats c ON c.id = dr.chat_id
         WHERE dr.user_id = $1
         ORDER BY dr.updated_at DESC",
    )
    .bind(user_id)
    .fetch_all(db.pool())
    .await
    .context("list drafts")?;
    rows.into_iter()
        .map(|row| {
            Ok(DraftRecord {
                chat_id: row.try_get("chat_id").context("read draft chat")?,
                kind: row.try_get("kind").context("read draft kind")?,
                other_user_id: row.try_get("other_user_id").context("read draft peer")?,
                text: row.try_get("text").context("read draft text")?,
                reply_to: row.try_get("reply_to").context("read draft reply")?,
                updated_at: row.try_get("updated_at").context("read draft date")?,
            })
        })
        .collect()
}

pub async fn set_dialog_pin(db: &Db, user_id: i64, chat_id: i64, pinned: bool) -> Result<()> {
    if pinned {
        let next: i32 = sqlx::query_scalar(
            "SELECT COALESCE(MAX(sort_order), -1) + 1 FROM te_pinned_dialogs WHERE user_id = $1",
        )
        .bind(user_id)
        .fetch_one(db.pool())
        .await
        .context("next pinned order")?;
        sqlx::query(
            "INSERT INTO te_pinned_dialogs (user_id, chat_id, sort_order, pinned_at)
             VALUES ($1, $2, $3, $4)
             ON CONFLICT (user_id, chat_id) DO NOTHING",
        )
        .bind(user_id)
        .bind(chat_id)
        .bind(next)
        .bind(unix_time())
        .execute(db.pool())
        .await
        .context("pin dialog")?;
    } else {
        sqlx::query("DELETE FROM te_pinned_dialogs WHERE user_id = $1 AND chat_id = $2")
            .bind(user_id)
            .bind(chat_id)
            .execute(db.pool())
            .await
            .context("unpin dialog")?;
    }
    Ok(())
}

pub async fn reorder_pinned_dialogs(
    db: &Db,
    user_id: i64,
    chat_ids: &[i64],
    pinned_now: i64,
) -> Result<()> {
    for (order, chat_id) in chat_ids.iter().enumerate() {
        sqlx::query(
            "INSERT INTO te_pinned_dialogs (user_id, chat_id, sort_order, pinned_at)
             VALUES ($1, $2, $3, $4)
             ON CONFLICT (user_id, chat_id)
             DO UPDATE SET sort_order = EXCLUDED.sort_order",
        )
        .bind(user_id)
        .bind(chat_id)
        .bind(order as i32)
        .bind(pinned_now)
        .execute(db.pool())
        .await
        .context("reorder pinned dialog")?;
    }
    Ok(())
}

pub async fn save_dialog_filter(
    db: &Db,
    user_id: i64,
    filter_id: i32,
    filter: &[u8],
) -> Result<()> {
    sqlx::query(
        "INSERT INTO te_dialog_filters (user_id, filter_id, filter, updated_at)
         VALUES ($1, $2, $3, $4)
         ON CONFLICT (user_id, filter_id)
         DO UPDATE SET filter = EXCLUDED.filter, updated_at = EXCLUDED.updated_at",
    )
    .bind(user_id)
    .bind(filter_id)
    .bind(filter)
    .bind(unix_time())
    .execute(db.pool())
    .await
    .context("save dialog filter")?;
    Ok(())
}

pub async fn delete_dialog_filter(db: &Db, user_id: i64, filter_id: i32) -> Result<()> {
    sqlx::query("DELETE FROM te_dialog_filters WHERE user_id = $1 AND filter_id = $2")
        .bind(user_id)
        .bind(filter_id)
        .execute(db.pool())
        .await
        .context("delete dialog filter")?;
    Ok(())
}

pub async fn list_dialog_filters(db: &Db, user_id: i64) -> Result<Vec<Vec<u8>>> {
    sqlx::query_scalar::<_, Vec<u8>>(
        "SELECT filter FROM te_dialog_filters WHERE user_id = $1 ORDER BY filter_id",
    )
    .bind(user_id)
    .fetch_all(db.pool())
    .await
    .context("list dialog filters")
}

#[derive(Debug, Clone)]
pub struct GlobalMessageRecord {
    pub message: MessageRecord,
    pub kind: String,
    pub other_user_id: i64,
}

pub async fn search_user_messages(
    db: &Db,
    user_id: i64,
    query: &str,
    limit: i32,
) -> Result<Vec<GlobalMessageRecord>> {
    let rows = sqlx::query(
        "SELECT m.id, m.chat_id, m.seq, m.sender_user_id, m.text, m.sent_at, m.media_id, m.grouped_id,
                m.reply_to_msg_id, m.edit_date, m.fwd_from_user_id, m.fwd_from_chat_id,
                m.fwd_from_msg_id, m.fwd_date, m.action_kind, m.action_user_id,
                m.action_title, m.scheduled_date, m.views, m.entities, m.reply_markup,
                c.kind,
                COALESCE(CASE WHEN c.private_user_a = $1 THEN c.private_user_b
                         ELSE c.private_user_a END, 0) AS other_user_id
         FROM te_messages m
         JOIN te_chats c ON c.id = m.chat_id
         WHERE (
             (c.kind = 'private' AND (c.private_user_a = $1 OR c.private_user_b = $1))
             OR (c.kind IN ('group', 'channel', 'basic_group') AND EXISTS (
                 SELECT 1 FROM te_chat_members cm
                 WHERE cm.chat_id = c.id AND cm.user_id = $1 AND cm.left_at = 0))
         )
         AND m.text ILIKE '%' || $2 || '%'
         AND m.scheduled_date = 0
         ORDER BY m.sent_at DESC
         LIMIT $3",
    )
    .bind(user_id)
    .bind(query)
    .bind(i64::from(limit.clamp(1, 100)))
    .fetch_all(db.pool())
    .await
    .context("search user messages")?;
    rows.into_iter()
        .map(|row| {
            let kind = row.try_get("kind").context("read chat kind")?;
            let other_user_id = row.try_get("other_user_id").context("read peer")?;
            Ok(GlobalMessageRecord {
                message: message_from_row(row)?,
                kind,
                other_user_id,
            })
        })
        .collect()
}

pub async fn search_messages(
    db: &Db,
    chat_id: i64,
    query: &str,
    limit: i32,
) -> Result<Vec<MessageRecord>> {
    let rows = sqlx::query(
        "SELECT id, chat_id, seq, sender_user_id, text, sent_at, media_id, grouped_id,
                reply_to_msg_id, edit_date, fwd_from_user_id, fwd_from_chat_id,
                fwd_from_msg_id, fwd_date, action_kind, action_user_id, action_title, scheduled_date,
                views, entities, reply_markup
         FROM te_messages
         WHERE chat_id = $1 AND text ILIKE '%' || $2 || '%' AND scheduled_date = 0
         ORDER BY seq DESC
         LIMIT $3",
    )
    .bind(chat_id)
    .bind(query)
    .bind(i64::from(limit.clamp(1, 100)))
    .fetch_all(db.pool())
    .await
    .context("search messages")?;
    rows.into_iter().map(message_from_row).collect()
}

pub async fn history(db: &Db, chat_id: i64, limit: i32) -> Result<Vec<MessageRecord>> {
    let rows = sqlx::query(
        "SELECT id, chat_id, seq, sender_user_id, text, sent_at, media_id, grouped_id,
                reply_to_msg_id, edit_date, fwd_from_user_id, fwd_from_chat_id,
                fwd_from_msg_id, fwd_date, action_kind, action_user_id, action_title, scheduled_date,
                views, entities, reply_markup
         FROM te_messages
         WHERE chat_id = $1 AND scheduled_date = 0
         ORDER BY seq DESC
         LIMIT $2",
    )
    .bind(chat_id)
    .bind(i64::from(limit.clamp(1, 1000)))
    .fetch_all(db.pool())
    .await
    .context("load history")?;
    rows.into_iter().map(message_from_row).collect()
}

#[allow(clippy::too_many_arguments)]
pub async fn send_private_message(
    db: &Db,
    sender_user_id: i64,
    recipient_user_id: i64,
    text: &str,
    random_id: i64,
    media_id: Option<i64>,
    extras: &MessageExtras,
) -> Result<(MessageRecord, i32, i32)> {
    let (first, second) = ordered_pair(sender_user_id, recipient_user_id);
    let mut transaction = db.pool().begin().await.context("begin message tx")?;

    let chat_id = match sqlx::query_scalar::<_, i64>(
        "SELECT id FROM te_chats
         WHERE kind = 'private' AND private_user_a = $1 AND private_user_b = $2",
    )
    .bind(first)
    .bind(second)
    .fetch_optional(&mut *transaction)
    .await
    .context("find chat in transaction")?
    {
        Some(id) => id,
        None => {
            let inserted = sqlx::query_scalar::<_, i64>(
                "INSERT INTO te_chats (kind, private_user_a, private_user_b)
                 VALUES ('private', $1, $2)
                 ON CONFLICT DO NOTHING
                 RETURNING id",
            )
            .bind(first)
            .bind(second)
            .fetch_optional(&mut *transaction)
            .await
            .context("create private chat")?;
            match inserted {
                Some(id) => id,
                None => sqlx::query_scalar::<_, i64>(
                    "SELECT id FROM te_chats
                     WHERE kind = 'private' AND private_user_a = $1 AND private_user_b = $2",
                )
                .bind(first)
                .bind(second)
                .fetch_one(&mut *transaction)
                .await
                .context("resolve created chat")?,
            }
        }
    };

    // Serialize seq generation for this chat.
    sqlx::query("SELECT id FROM te_chats WHERE id = $1 FOR UPDATE")
        .bind(chat_id)
        .execute(&mut *transaction)
        .await
        .context("lock chat")?;

    let seq = sqlx::query_scalar::<_, i64>(
        "SELECT COALESCE(MAX(seq), 0) + 1 FROM te_messages WHERE chat_id = $1",
    )
    .bind(chat_id)
    .fetch_one(&mut *transaction)
    .await
    .context("next message seq")?;

    let sent_at = unix_time();
    let message_id = sqlx::query_scalar::<_, i64>(
        "INSERT INTO te_messages
             (chat_id, seq, sender_user_id, random_id, sent_at, text, media_id, grouped_id,
              reply_to_msg_id, fwd_from_user_id, fwd_from_chat_id, fwd_from_msg_id, fwd_date,
              entities, reply_markup)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15)
         RETURNING id",
    )
    .bind(chat_id)
    .bind(seq)
    .bind(sender_user_id)
    .bind(random_id)
    .bind(sent_at)
    .bind(text)
    .bind(media_id)
    .bind(extras.grouped_id)
    .bind(extras.reply_to_msg_id)
    .bind(extras.fwd_from_user_id)
    .bind(extras.fwd_from_chat_id)
    .bind(extras.fwd_from_msg_id)
    .bind(extras.fwd_date)
    .bind(encode_entities(&extras.entities))
    .bind(extras.reply_markup.clone())
    .fetch_one(&mut *transaction)
    .await
    .context("insert message")?;

    let sender_pts = sqlx::query_scalar::<_, i64>(
        "UPDATE te_users SET pts = pts + 1, last_seen_at = $2 WHERE id = $1 RETURNING pts",
    )
    .bind(sender_user_id)
    .bind(sent_at)
    .fetch_one(&mut *transaction)
    .await
    .context("bump sender pts")?;
    let recipient_pts = sqlx::query_scalar::<_, i64>(
        "UPDATE te_users SET pts = pts + 1 WHERE id = $1 RETURNING pts",
    )
    .bind(recipient_user_id)
    .fetch_one(&mut *transaction)
    .await
    .context("bump recipient pts")?;

    upsert_dialog(
        &mut transaction,
        sender_user_id,
        chat_id,
        seq,
        sent_at,
        false,
    )
    .await?;
    upsert_dialog(
        &mut transaction,
        recipient_user_id,
        chat_id,
        seq,
        sent_at,
        true,
    )
    .await?;

    transaction.commit().await.context("commit message tx")?;

    Ok((
        MessageRecord {
            id: message_id,
            chat_id,
            seq,
            sender_user_id,
            text: text.to_owned(),
            sent_at,
            media_id,
            reply_to_msg_id: extras.reply_to_msg_id,
            grouped_id: extras.grouped_id,
            edit_date: 0,
            views: 0,
            entities: extras.entities.clone(),
            reply_markup: extras.reply_markup.clone(),
            fwd_from_user_id: extras.fwd_from_user_id,
            fwd_from_chat_id: extras.fwd_from_chat_id,
            fwd_from_msg_id: extras.fwd_from_msg_id,
            fwd_date: extras.fwd_date,
            action_kind: String::new(),
            action_user_id: 0,
            action_title: String::new(),
            scheduled_date: 0,
        },
        sender_pts as i32,
        recipient_pts as i32,
    ))
}

async fn upsert_dialog(
    transaction: &mut sqlx::Transaction<'_, sqlx::Postgres>,
    user_id: i64,
    chat_id: i64,
    seq: i64,
    date: i64,
    unread: bool,
) -> Result<()> {
    if unread {
        sqlx::query(
            "INSERT INTO te_user_dialogs
                 (user_id, chat_id, top_message_seq, top_message_date, read_max_seq, unread_count)
             VALUES ($1, $2, $3, $4, 0, 1)
             ON CONFLICT (user_id, chat_id) DO UPDATE SET
                 top_message_seq = EXCLUDED.top_message_seq,
                 top_message_date = EXCLUDED.top_message_date,
                 unread_count = te_user_dialogs.unread_count + 1,
                 updated_at = now()",
        )
        .bind(user_id)
        .bind(chat_id)
        .bind(seq)
        .bind(date)
        .execute(&mut **transaction)
        .await
        .context("upsert recipient dialog")?;
    } else {
        sqlx::query(
            "INSERT INTO te_user_dialogs
                 (user_id, chat_id, top_message_seq, top_message_date, read_max_seq, unread_count)
             VALUES ($1, $2, $3, $4, $3, 0)
             ON CONFLICT (user_id, chat_id) DO UPDATE SET
                 top_message_seq = EXCLUDED.top_message_seq,
                 top_message_date = EXCLUDED.top_message_date,
                 read_max_seq = GREATEST(te_user_dialogs.read_max_seq, EXCLUDED.read_max_seq),
                 unread_count = 0,
                 updated_at = now()",
        )
        .bind(user_id)
        .bind(chat_id)
        .bind(seq)
        .bind(date)
        .execute(&mut **transaction)
        .await
        .context("upsert sender dialog")?;
    }
    Ok(())
}

#[derive(Debug, Clone)]
pub struct ChannelRecord {
    pub id: i64,
    pub access_hash: i64,
    pub kind: String,
    pub title: String,
    /// Public username without `@`, empty when unset.
    pub username: String,
    pub about: String,
    pub owner_user_id: i64,
    pub pts: i64,
    pub participants_count: i64,
    pub photo_media_id: i64,
}

pub async fn create_channel(
    db: &Db,
    owner_user_id: i64,
    title: &str,
    about: &str,
    is_broadcast: bool,
) -> Result<ChannelRecord> {
    let mut transaction = db.pool().begin().await.context("begin channel tx")?;
    let kind = if is_broadcast { "channel" } else { "group" };
    let mut access_hash = rand::random::<i64>();
    if access_hash == 0 {
        access_hash = 1;
    }
    let row = sqlx::query(
        "INSERT INTO te_chats
             (kind, owner_user_id, title, about, access_hash)
         VALUES ($1, $2, $3, $4, $5)
         RETURNING id, access_hash, kind, title, username, about, owner_user_id, pts, photo_media_id",
    )
    .bind(kind)
    .bind(owner_user_id)
    .bind(title)
    .bind(about)
    .bind(access_hash)
    .fetch_one(&mut *transaction)
    .await
    .context("create channel")?;
    let now = unix_time();
    sqlx::query(
        "INSERT INTO te_chat_members (chat_id, user_id, role, joined_at)
         VALUES ($1, $2, 'owner', $3)",
    )
    .bind(row.try_get::<i64, _>("id").context("read channel id")?)
    .bind(owner_user_id)
    .bind(now)
    .execute(&mut *transaction)
    .await
    .context("add channel owner")?;

    let record = ChannelRecord {
        id: row.try_get("id").context("read channel id")?,
        access_hash: row.try_get("access_hash").context("read channel access")?,
        kind: row.try_get("kind").context("read channel kind")?,
        title: row.try_get("title").context("read channel title")?,
        username: row
            .try_get::<Option<String>, _>("username")
            .context("read channel username")?
            .unwrap_or_default(),
        about: row.try_get("about").context("read channel about")?,
        owner_user_id: row.try_get("owner_user_id").context("read channel owner")?,
        pts: row.try_get("pts").context("read channel pts")?,
        participants_count: 1,
        photo_media_id: row
            .try_get("photo_media_id")
            .context("read channel photo")?,
    };
    transaction.commit().await.context("commit channel tx")?;
    Ok(record)
}

pub async fn create_basic_group(
    db: &Db,
    owner_user_id: i64,
    title: &str,
    members: &[i64],
) -> Result<ChannelRecord> {
    let mut transaction = db.pool().begin().await.context("begin group tx")?;
    let mut access_hash = rand::random::<i64>();
    if access_hash == 0 {
        access_hash = 1;
    }
    let row = sqlx::query(
        "INSERT INTO te_chats
             (kind, owner_user_id, title, about, access_hash)
         VALUES ('basic_group', $1, $2, '', $3)
         RETURNING id, access_hash, kind, title, username, about, owner_user_id, pts, photo_media_id",
    )
    .bind(owner_user_id)
    .bind(title)
    .bind(access_hash)
    .fetch_one(&mut *transaction)
    .await
    .context("create basic group")?;
    let chat_id: i64 = row.try_get("id").context("read group id")?;
    let now = unix_time();
    sqlx::query(
        "INSERT INTO te_chat_members (chat_id, user_id, role, joined_at)
         VALUES ($1, $2, 'owner', $3)
         ON CONFLICT DO NOTHING",
    )
    .bind(chat_id)
    .bind(owner_user_id)
    .bind(now)
    .execute(&mut *transaction)
    .await
    .context("add group owner")?;
    let mut participants = 1;
    for member_id in members {
        if *member_id == owner_user_id {
            continue;
        }
        sqlx::query(
            "INSERT INTO te_chat_members (chat_id, user_id, role, joined_at)
             VALUES ($1, $2, 'member', $3)
             ON CONFLICT DO NOTHING",
        )
        .bind(chat_id)
        .bind(member_id)
        .bind(now)
        .execute(&mut *transaction)
        .await
        .context("add group member")?;
        participants += 1;
    }
    let record = ChannelRecord {
        id: chat_id,
        access_hash: row.try_get("access_hash").context("read group access")?,
        kind: row.try_get("kind").context("read group kind")?,
        title: row.try_get("title").context("read group title")?,
        username: row
            .try_get::<Option<String>, _>("username")
            .context("read group username")?
            .unwrap_or_default(),
        about: row.try_get("about").context("read group about")?,
        owner_user_id: row.try_get("owner_user_id").context("read group owner")?,
        pts: row.try_get("pts").context("read group pts")?,
        participants_count: participants,
        photo_media_id: row.try_get("photo_media_id").context("read group photo")?,
    };
    transaction.commit().await.context("commit group tx")?;
    Ok(record)
}

pub async fn history_message_ids(db: &Db, chat_id: i64, max_id: i64) -> Result<Vec<i64>> {
    sqlx::query_scalar::<_, i64>(
        "SELECT id FROM te_messages
         WHERE chat_id = $1 AND ($2 = 0 OR id <= $2)
         ORDER BY id ASC",
    )
    .bind(chat_id)
    .bind(max_id)
    .fetch_all(db.pool())
    .await
    .context("load history message ids")
}

pub async fn delete_dialog(db: &Db, user_id: i64, chat_id: i64) -> Result<()> {
    sqlx::query("DELETE FROM te_user_dialogs WHERE user_id = $1 AND chat_id = $2")
        .bind(user_id)
        .bind(chat_id)
        .execute(db.pool())
        .await
        .context("delete dialog")?;
    Ok(())
}

#[derive(Debug, Clone)]
pub struct ReactionRecord {
    pub emoticon: String,
    pub count: i32,
    pub chosen: bool,
}

pub async fn set_message_reaction(
    db: &Db,
    message_id: i64,
    user_id: i64,
    emoticon: Option<&str>,
) -> Result<()> {
    match emoticon {
        Some(emoticon) => {
            sqlx::query(
                "INSERT INTO te_message_reactions (message_id, user_id, emoticon)
                 VALUES ($1, $2, $3)
                 ON CONFLICT (message_id, user_id)
                 DO UPDATE SET emoticon = EXCLUDED.emoticon, created_at = now()",
            )
            .bind(message_id)
            .bind(user_id)
            .bind(emoticon)
            .execute(db.pool())
            .await
            .context("set message reaction")?;
        }
        None => {
            sqlx::query("DELETE FROM te_message_reactions WHERE message_id = $1 AND user_id = $2")
                .bind(message_id)
                .bind(user_id)
                .execute(db.pool())
                .await
                .context("remove message reaction")?;
        }
    }
    Ok(())
}

pub async fn list_message_reactions(
    db: &Db,
    message_id: i64,
    viewer_user_id: i64,
) -> Result<Vec<ReactionRecord>> {
    let rows = sqlx::query(
        "SELECT emoticon,
                COUNT(*)::int AS count,
                BOOL_OR(user_id = $2) AS chosen
         FROM te_message_reactions
         WHERE message_id = $1
         GROUP BY emoticon
         ORDER BY count DESC, emoticon ASC",
    )
    .bind(message_id)
    .bind(viewer_user_id)
    .fetch_all(db.pool())
    .await
    .context("list message reactions")?;
    rows.into_iter()
        .map(|row| {
            Ok(ReactionRecord {
                emoticon: row.try_get("emoticon").context("read reaction emoji")?,
                count: row.try_get("count").context("read reaction count")?,
                chosen: row.try_get("chosen").context("read reaction chosen")?,
            })
        })
        .collect()
}

pub async fn set_chat_title(db: &Db, chat_id: i64, title: &str) -> Result<()> {
    sqlx::query("UPDATE te_chats SET title = $2 WHERE id = $1")
        .bind(chat_id)
        .bind(title)
        .execute(db.pool())
        .await
        .context("set chat title")?;
    Ok(())
}

pub async fn set_chat_photo(db: &Db, chat_id: i64, media_id: i64) -> Result<()> {
    sqlx::query("UPDATE te_chats SET photo_media_id = $2, updated_at = now() WHERE id = $1")
        .bind(chat_id)
        .bind(media_id)
        .execute(db.pool())
        .await
        .context("set chat photo")?;
    Ok(())
}

pub async fn find_channel(db: &Db, channel_id: i64) -> Result<Option<ChannelRecord>> {
    let row = sqlx::query(
        "SELECT c.id, c.access_hash, c.kind, c.title, c.username, c.about, c.owner_user_id, c.pts,
                c.photo_media_id,
                (SELECT COUNT(*) FROM te_chat_members m
                 WHERE m.chat_id = c.id AND m.left_at = 0) AS participants_count
         FROM te_chats c
         WHERE c.id = $1 AND c.kind IN ('group', 'channel', 'basic_group')",
    )
    .bind(channel_id)
    .fetch_optional(db.pool())
    .await
    .context("find channel")?;
    row.map(|row| {
        Ok(ChannelRecord {
            id: row.try_get("id").context("read channel id")?,
            access_hash: row.try_get("access_hash").context("read channel access")?,
            kind: row.try_get("kind").context("read channel kind")?,
            title: row.try_get("title").context("read channel title")?,
            username: row
                .try_get::<Option<String>, _>("username")
                .context("read channel username")?
                .unwrap_or_default(),
            about: row.try_get("about").context("read channel about")?,
            owner_user_id: row.try_get("owner_user_id").context("read channel owner")?,
            pts: row.try_get("pts").context("read channel pts")?,
            participants_count: row
                .try_get("participants_count")
                .context("read channel participants")?,
            photo_media_id: row
                .try_get("photo_media_id")
                .context("read channel photo")?,
        })
    })
    .transpose()
}

pub async fn channel_membership(db: &Db, channel_id: i64, user_id: i64) -> Result<Option<String>> {
    sqlx::query_scalar::<_, String>(
        "SELECT role FROM te_chat_members
         WHERE chat_id = $1 AND user_id = $2 AND left_at = 0",
    )
    .bind(channel_id)
    .bind(user_id)
    .fetch_optional(db.pool())
    .await
    .context("load channel membership")
}

/// Role and stored administrator rights for an active member.
pub async fn channel_member_rights(
    db: &Db,
    channel_id: i64,
    user_id: i64,
) -> Result<Option<(String, u32)>> {
    let row = sqlx::query(
        "SELECT role, admin_rights FROM te_chat_members
         WHERE chat_id = $1 AND user_id = $2 AND left_at = 0",
    )
    .bind(channel_id)
    .bind(user_id)
    .fetch_optional(db.pool())
    .await
    .context("load channel member rights")?;
    row.map(|row| {
        let role: String = row.try_get("role").context("read member role")?;
        let rights: serde_json::Value = row
            .try_get("admin_rights")
            .context("read member admin rights")?;
        Ok((role, rights_flags(&rights)))
    })
    .transpose()
}

pub async fn add_channel_member(db: &Db, channel_id: i64, user_id: i64) -> Result<()> {
    sqlx::query(
        "INSERT INTO te_chat_members (chat_id, user_id, role, joined_at)
         VALUES ($1, $2, 'member', $3)
         ON CONFLICT (chat_id, user_id)
         DO UPDATE SET left_at = 0,
                       joined_at = EXCLUDED.joined_at,
                       role = CASE WHEN te_chat_members.role = 'owner' THEN 'owner' ELSE 'member' END,
                       admin_rights = CASE WHEN te_chat_members.role = 'owner'
                                           THEN te_chat_members.admin_rights
                                           ELSE '{}'::jsonb END,
                       rank = CASE WHEN te_chat_members.role = 'owner'
                                   THEN te_chat_members.rank
                                   ELSE '' END",
    )
    .bind(channel_id)
    .bind(user_id)
    .bind(unix_time())
    .execute(db.pool())
    .await
    .context("add channel member")?;
    Ok(())
}

pub async fn remove_channel_member(db: &Db, channel_id: i64, user_id: i64) -> Result<()> {
    sqlx::query(
        "UPDATE te_chat_members SET left_at = $3
         WHERE chat_id = $1 AND user_id = $2 AND left_at = 0",
    )
    .bind(channel_id)
    .bind(user_id)
    .bind(unix_time())
    .execute(db.pool())
    .await
    .context("remove channel member")?;
    sqlx::query("DELETE FROM te_user_dialogs WHERE user_id = $1 AND chat_id = $2")
        .bind(user_id)
        .bind(channel_id)
        .execute(db.pool())
        .await
        .context("delete channel dialog")?;
    Ok(())
}

pub async fn list_channel_members(
    db: &Db,
    channel_id: i64,
) -> Result<Vec<(UserRecord, String, i64, u32, String)>> {
    let rows = sqlx::query(
        "SELECT u.id, u.access_hash, u.phone, u.first_name, u.last_name, u.username,
                u.photo_media_id, u.emoji_status_document_id, u.last_seen_at,
                m.role, m.joined_at, m.admin_rights, m.rank
         FROM te_chat_members m
         JOIN te_users u ON u.id = m.user_id
         WHERE m.chat_id = $1 AND m.left_at = 0
         ORDER BY m.role DESC, u.id",
    )
    .bind(channel_id)
    .fetch_all(db.pool())
    .await
    .context("list channel members")?;
    rows.into_iter()
        .map(|row| {
            let role = row.try_get("role").context("read member role")?;
            let joined_at = row.try_get("joined_at").context("read member date")?;
            let rights: serde_json::Value = row
                .try_get("admin_rights")
                .context("read member admin rights")?;
            let rank: String = row.try_get("rank").context("read member rank")?;
            Ok((
                user_from_row(row)?,
                role,
                joined_at,
                rights_flags(&rights),
                rank,
            ))
        })
        .collect()
}

fn rights_flags(value: &serde_json::Value) -> u32 {
    value
        .get("flags")
        .and_then(serde_json::Value::as_u64)
        .unwrap_or(0) as u32
}

#[derive(Debug, Clone)]
pub struct ChatBanRecord {
    pub rights_flags: u32,
    pub until_date: i64,
}

pub async fn get_chat_ban(db: &Db, chat_id: i64, user_id: i64) -> Result<Option<ChatBanRecord>> {
    let row = sqlx::query(
        "SELECT banned_rights, until_date FROM te_chat_bans
         WHERE chat_id = $1 AND user_id = $2",
    )
    .bind(chat_id)
    .bind(user_id)
    .fetch_optional(db.pool())
    .await
    .context("load chat ban")?;
    row.map(|row| {
        let rights: serde_json::Value = row
            .try_get("banned_rights")
            .context("read banned rights")?;
        Ok(ChatBanRecord {
            rights_flags: rights_flags(&rights),
            until_date: row.try_get("until_date").context("read ban expiry")?,
        })
    })
    .transpose()
}

#[allow(clippy::too_many_arguments)]
pub async fn set_chat_ban(
    db: &Db,
    chat_id: i64,
    user_id: i64,
    rights: &serde_json::Value,
    until_date: i64,
    kicked_by: i64,
) -> Result<()> {
    sqlx::query(
        "INSERT INTO te_chat_bans (chat_id, user_id, banned_rights, until_date, kicked_by, created_at)
         VALUES ($1, $2, $3, $4, $5, $6)
         ON CONFLICT (chat_id, user_id)
         DO UPDATE SET banned_rights = EXCLUDED.banned_rights,
                       until_date = EXCLUDED.until_date,
                       kicked_by = EXCLUDED.kicked_by,
                       created_at = EXCLUDED.created_at",
    )
    .bind(chat_id)
    .bind(user_id)
    .bind(rights)
    .bind(until_date)
    .bind(kicked_by)
    .bind(unix_time())
    .execute(db.pool())
    .await
    .context("save chat ban")?;
    Ok(())
}

pub async fn delete_chat_ban(db: &Db, chat_id: i64, user_id: i64) -> Result<()> {
    sqlx::query("DELETE FROM te_chat_bans WHERE chat_id = $1 AND user_id = $2")
        .bind(chat_id)
        .bind(user_id)
        .execute(db.pool())
        .await
        .context("delete chat ban")?;
    Ok(())
}

/// All message ids of one chat, oldest first. Used by the admin before a
/// destructive chat removal so clients can receive delete updates.
pub async fn chat_message_ids(db: &Db, chat_id: i64) -> Result<Vec<i64>> {
    let rows = sqlx::query("SELECT id FROM te_messages WHERE chat_id = $1 ORDER BY id")
        .bind(chat_id)
        .fetch_all(db.pool())
        .await
        .context("list chat message ids")?;
    Ok(rows
        .into_iter()
        .filter_map(|row| row.try_get::<i64, _>("id").ok())
        .collect())
}

/// Hard-deletes a non-private chat. Dependent rows (messages, members,
/// dialogs, invites, bans, channel updates) are removed by ON DELETE CASCADE.
pub async fn delete_chat(db: &Db, chat_id: i64) -> Result<bool> {
    let result = sqlx::query("DELETE FROM te_chats WHERE id = $1")
        .bind(chat_id)
        .execute(db.pool())
        .await
        .context("delete chat")?;
    Ok(result.rows_affected() > 0)
}

/// Non-private chats owned by a user. Account deletion is refused while any
/// exist because `te_chats.owner_user_id` has no cascade rule.
pub async fn user_owned_chat_ids(db: &Db, user_id: i64) -> Result<Vec<i64>> {
    let rows = sqlx::query(
        "SELECT id FROM te_chats WHERE owner_user_id = $1 AND kind <> 'private' ORDER BY id",
    )
    .bind(user_id)
    .fetch_all(db.pool())
    .await
    .context("list owned chats")?;
    Ok(rows
        .into_iter()
        .filter_map(|row| row.try_get::<i64, _>("id").ok())
        .collect())
}

pub async fn user_private_chat_ids(db: &Db, user_id: i64) -> Result<Vec<i64>> {
    let rows = sqlx::query(
        "SELECT id FROM te_chats
         WHERE kind = 'private' AND (private_user_a = $1 OR private_user_b = $1)
         ORDER BY id",
    )
    .bind(user_id)
    .fetch_all(db.pool())
    .await
    .context("list private chats")?;
    Ok(rows
        .into_iter()
        .filter_map(|row| row.try_get::<i64, _>("id").ok())
        .collect())
}

pub async fn count_user_messages(db: &Db, user_id: i64) -> Result<i64> {
    let row = sqlx::query("SELECT COUNT(*) AS total FROM te_messages WHERE sender_user_id = $1")
        .bind(user_id)
        .fetch_one(db.pool())
        .await
        .context("count user messages")?;
    row.try_get("total").context("read user message count")
}

pub async fn count_user_media(db: &Db, user_id: i64) -> Result<i64> {
    let row = sqlx::query("SELECT COUNT(*) AS total FROM te_media_files WHERE owner_user_id = $1")
        .bind(user_id)
        .fetch_one(db.pool())
        .await
        .context("count user media")?;
    row.try_get("total").context("read user media count")
}

/// Detaches uploaded media from a user so the account row can be deleted.
pub async fn release_user_media(db: &Db, user_id: i64) -> Result<u64> {
    let result = sqlx::query("UPDATE te_media_files SET owner_user_id = NULL WHERE owner_user_id = $1")
        .bind(user_id)
        .execute(db.pool())
        .await
        .context("release user media")?;
    Ok(result.rows_affected())
}

/// Remaining messages sent by a user in non-private chats, grouped by chat.
pub async fn user_message_ids_by_chat(
    db: &Db,
    user_id: i64,
) -> Result<Vec<(i64, Vec<i64>)>> {
    let rows = sqlx::query(
        "SELECT m.chat_id, m.id
         FROM te_messages m
         JOIN te_chats c ON c.id = m.chat_id
         WHERE m.sender_user_id = $1 AND c.kind <> 'private'
         ORDER BY m.chat_id, m.id",
    )
    .bind(user_id)
    .fetch_all(db.pool())
    .await
    .context("list user messages by chat")?;
    let mut grouped: Vec<(i64, Vec<i64>)> = Vec::new();
    for row in rows {
        let chat_id: i64 = row.try_get("chat_id").context("read message chat")?;
        let message_id: i64 = row.try_get("id").context("read message id")?;
        match grouped.last_mut() {
            Some((last_chat, ids)) if *last_chat == chat_id => ids.push(message_id),
            _ => grouped.push((chat_id, vec![message_id])),
        }
    }
    Ok(grouped)
}

pub async fn delete_user_record(db: &Db, user_id: i64) -> Result<bool> {
    let result = sqlx::query("DELETE FROM te_users WHERE id = $1")
        .bind(user_id)
        .execute(db.pool())
        .await
        .context("delete user record")?;
    Ok(result.rows_affected() > 0)
}

pub async fn set_chat_member_admin(
    db: &Db,
    chat_id: i64,
    user_id: i64,
    rights: &serde_json::Value,
    rank: &str,
    promoted_by: i64,
) -> Result<()> {
    sqlx::query(
        "UPDATE te_chat_members
         SET role = 'admin', admin_rights = $3, rank = $4, promoted_by = $5
         WHERE chat_id = $1 AND user_id = $2 AND left_at = 0 AND role <> 'owner'",
    )
    .bind(chat_id)
    .bind(user_id)
    .bind(rights)
    .bind(rank)
    .bind(promoted_by)
    .execute(db.pool())
    .await
    .context("promote chat member")?;
    Ok(())
}

pub async fn demote_chat_member(db: &Db, chat_id: i64, user_id: i64) -> Result<()> {
    sqlx::query(
        "UPDATE te_chat_members
         SET role = 'member', admin_rights = '{}'::jsonb, rank = '', promoted_by = 0
         WHERE chat_id = $1 AND user_id = $2 AND role = 'admin'",
    )
    .bind(chat_id)
    .bind(user_id)
    .execute(db.pool())
    .await
    .context("demote chat member")?;
    Ok(())
}

#[derive(Debug, Clone)]
pub struct ChatInviteRecord {
    pub chat_id: i64,
    pub creator_id: i64,
    pub link: String,
    pub expires_at: i64,
    pub usage_limit: i32,
    pub usage_count: i32,
    pub revoked: bool,
    pub request_needed: bool,
}

#[allow(clippy::too_many_arguments)]
pub async fn create_chat_invite(
    db: &Db,
    token: &str,
    chat_id: i64,
    creator_id: i64,
    link: &str,
    expires_at: i64,
    usage_limit: i32,
    request_needed: bool,
) -> Result<ChatInviteRecord> {
    let row = sqlx::query(
        "INSERT INTO te_chat_invites
             (token, chat_id, creator_id, link, expires_at, usage_limit, request_needed, created_at)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
         RETURNING chat_id, creator_id, link, expires_at, usage_limit, usage_count, revoked, request_needed",
    )
    .bind(token)
    .bind(chat_id)
    .bind(creator_id)
    .bind(link)
    .bind(expires_at)
    .bind(usage_limit)
    .bind(request_needed)
    .bind(unix_time())
    .fetch_one(db.pool())
    .await
    .context("create chat invite")?;
    invite_from_row(row)
}

fn invite_from_row(row: sqlx::postgres::PgRow) -> Result<ChatInviteRecord> {
    Ok(ChatInviteRecord {
        chat_id: row.try_get("chat_id").context("read invite chat")?,
        creator_id: row.try_get("creator_id").context("read invite creator")?,
        link: row.try_get("link").context("read invite link")?,
        expires_at: row.try_get("expires_at").context("read invite expiry")?,
        usage_limit: row.try_get("usage_limit").context("read invite limit")?,
        usage_count: row.try_get("usage_count").context("read invite usage")?,
        revoked: row.try_get("revoked").context("read invite revoked flag")?,
        request_needed: row
            .try_get("request_needed")
            .context("read invite request flag")?,
    })
}

pub async fn find_chat_invite(db: &Db, token: &str) -> Result<Option<ChatInviteRecord>> {
    let row = sqlx::query(
        "SELECT chat_id, creator_id, link, expires_at, usage_limit, usage_count, revoked, request_needed
         FROM te_chat_invites WHERE token = $1",
    )
    .bind(token)
    .fetch_optional(db.pool())
    .await
    .context("find chat invite")?;
    row.map(invite_from_row).transpose()
}

/// Increments the invite usage count when the link still has capacity.
pub async fn consume_chat_invite(db: &Db, token: &str) -> Result<bool> {
    let updated = sqlx::query(
        "UPDATE te_chat_invites
         SET usage_count = usage_count + 1
         WHERE token = $1 AND revoked = false
           AND (usage_limit = 0 OR usage_count < usage_limit)",
    )
    .bind(token)
    .execute(db.pool())
    .await
    .context("consume chat invite")?
    .rows_affected();
    Ok(updated > 0)
}

pub async fn revoke_chat_invite(db: &Db, token: &str) -> Result<()> {
    sqlx::query("UPDATE te_chat_invites SET revoked = true WHERE token = $1")
        .bind(token)
        .execute(db.pool())
        .await
        .context("revoke chat invite")?;
    Ok(())
}

/// Creates a pending join request, or resets a previously rejected one.
pub async fn upsert_join_request(db: &Db, chat_id: i64, user_id: i64, about: &str) -> Result<()> {
    sqlx::query(
        "INSERT INTO te_join_requests (chat_id, user_id, about, status, requested_at)
         VALUES ($1, $2, $3, 'pending', $4)
         ON CONFLICT (chat_id, user_id) DO UPDATE
         SET about = EXCLUDED.about,
             status = 'pending',
             requested_at = EXCLUDED.requested_at,
             reviewed_at = 0,
             reviewer = ''",
    )
    .bind(chat_id)
    .bind(user_id)
    .bind(about)
    .bind(unix_time())
    .execute(db.pool())
    .await
    .context("upsert join request")?;
    Ok(())
}

/// Returns the stored status (`pending`/`approved`/`rejected`) if any.
pub async fn find_join_request(db: &Db, chat_id: i64, user_id: i64) -> Result<Option<String>> {
    let row = sqlx::query(
        "SELECT status FROM te_join_requests WHERE chat_id = $1 AND user_id = $2",
    )
    .bind(chat_id)
    .bind(user_id)
    .fetch_optional(db.pool())
    .await
    .context("find join request")?;
    match row {
        Some(row) => Ok(Some(
            row.try_get("status").context("read join request status")?,
        )),
        None => Ok(None),
    }
}

pub async fn review_join_request(
    db: &Db,
    chat_id: i64,
    user_id: i64,
    status: &str,
    reviewer: &str,
) -> Result<bool> {
    let updated = sqlx::query(
        "UPDATE te_join_requests
         SET status = $3, reviewed_at = $4, reviewer = $5
         WHERE chat_id = $1 AND user_id = $2 AND status = 'pending'",
    )
    .bind(chat_id)
    .bind(user_id)
    .bind(status)
    .bind(unix_time())
    .bind(reviewer)
    .execute(db.pool())
    .await
    .context("review join request")?
    .rows_affected();
    Ok(updated > 0)
}

pub async fn find_user_by_username(db: &Db, username: &str) -> Result<Option<UserRecord>> {
    let row = sqlx::query(
        "SELECT id, access_hash, phone, first_name, last_name, username,
                photo_media_id, emoji_status_document_id, last_seen_at, is_bot, bot_info_version
         FROM te_users WHERE lower(username) = lower($1) AND username <> ''",
    )
    .bind(username)
    .fetch_optional(db.pool())
    .await
    .context("find user by username")?;
    row.map(user_from_row).transpose()
}

pub async fn find_channel_by_username(db: &Db, username: &str) -> Result<Option<ChannelRecord>> {
    let row = sqlx::query(
        "SELECT c.id, c.access_hash, c.kind, c.title, c.username, c.about, c.owner_user_id,
                c.pts, c.photo_media_id,
                (SELECT COUNT(*) FROM te_chat_members m
                 WHERE m.chat_id = c.id AND m.left_at = 0) AS participants_count
         FROM te_chats c
         WHERE lower(c.username) = lower($1)
           AND c.kind IN ('group', 'channel', 'basic_group')",
    )
    .bind(username)
    .fetch_optional(db.pool())
    .await
    .context("find channel by username")?;
    row.map(|row| {
        Ok(ChannelRecord {
            id: row.try_get("id").context("read channel id")?,
            access_hash: row.try_get("access_hash").context("read channel access")?,
            kind: row.try_get("kind").context("read channel kind")?,
            title: row.try_get("title").context("read channel title")?,
            username: row
                .try_get::<Option<String>, _>("username")
                .context("read channel username")?
                .unwrap_or_default(),
            about: row.try_get("about").context("read channel about")?,
            owner_user_id: row.try_get("owner_user_id").context("read channel owner")?,
            pts: row.try_get("pts").context("read channel pts")?,
            participants_count: row
                .try_get("participants_count")
                .context("read channel participants")?,
            photo_media_id: row
                .try_get("photo_media_id")
                .context("read channel photo")?,
        })
    })
    .transpose()
}

pub async fn username_taken(db: &Db, username: &str) -> Result<bool> {
    let found: Option<i64> = sqlx::query_scalar(
        "SELECT 1 FROM te_users WHERE lower(username) = lower($1) AND username <> ''
         UNION ALL
         SELECT 1 FROM te_chats WHERE lower(username) = lower($1) AND username <> ''
         LIMIT 1",
    )
    .bind(username)
    .fetch_optional(db.pool())
    .await
    .context("check username availability")?;
    Ok(found.is_some())
}

pub async fn set_user_username(db: &Db, user_id: i64, username: &str) -> Result<()> {
    sqlx::query("UPDATE te_users SET username = $2, updated_at = now() WHERE id = $1")
        .bind(user_id)
        .bind(username)
        .execute(db.pool())
        .await
        .context("update user username")?;
    Ok(())
}

pub async fn set_channel_username(db: &Db, chat_id: i64, username: &str) -> Result<()> {
    sqlx::query("UPDATE te_chats SET username = $2, updated_at = now() WHERE id = $1")
        .bind(chat_id)
        .bind(username)
        .execute(db.pool())
        .await
        .context("update channel username")?;
    Ok(())
}

/// Member ids eligible to receive channel updates (owner, admins and members).
pub async fn chat_member_ids_all(db: &Db, chat_id: i64) -> Result<Vec<i64>> {
    sqlx::query_scalar(
        "SELECT user_id FROM te_chat_members WHERE chat_id = $1 AND left_at = 0 ORDER BY user_id",
    )
    .bind(chat_id)
    .fetch_all(db.pool())
    .await
    .context("list chat member ids")
}

/// Makes sure a joined channel appears in the user's dialog list.
pub async fn ensure_channel_dialog(db: &Db, user_id: i64, chat_id: i64) -> Result<()> {
    sqlx::query(
        "INSERT INTO te_user_dialogs
             (user_id, chat_id, top_message_seq, top_message_date, read_max_seq, unread_count)
         VALUES ($1, $2, 0, $3, 0, 0)
         ON CONFLICT (user_id, chat_id) DO NOTHING",
    )
    .bind(user_id)
    .bind(chat_id)
    .bind(unix_time())
    .execute(db.pool())
    .await
    .context("ensure channel dialog")?;
    Ok(())
}

#[allow(clippy::too_many_arguments)]
pub async fn send_channel_message(
    db: &Db,
    channel_id: i64,
    sender_user_id: i64,
    text: &str,
    random_id: i64,
    media_id: Option<i64>,
    extras: &MessageExtras,
) -> Result<(MessageRecord, i32, Vec<i64>)> {
    let mut transaction = db.pool().begin().await.context("begin channel msg tx")?;
    sqlx::query("SELECT id FROM te_chats WHERE id = $1 FOR UPDATE")
        .bind(channel_id)
        .execute(&mut *transaction)
        .await
        .context("lock channel")?;
    let seq = sqlx::query_scalar::<_, i64>(
        "SELECT COALESCE(MAX(seq), 0) + 1 FROM te_messages WHERE chat_id = $1",
    )
    .bind(channel_id)
    .fetch_one(&mut *transaction)
    .await
    .context("next channel seq")?;
    let sent_at = unix_time();
    let message_id = sqlx::query_scalar::<_, i64>(
        "INSERT INTO te_messages
             (chat_id, seq, sender_user_id, random_id, sent_at, text, media_id, grouped_id,
              reply_to_msg_id, fwd_from_user_id, fwd_from_chat_id, fwd_from_msg_id, fwd_date,
              entities, reply_markup)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15)
         RETURNING id",
    )
    .bind(channel_id)
    .bind(seq)
    .bind(sender_user_id)
    .bind(random_id)
    .bind(sent_at)
    .bind(text)
    .bind(media_id)
    .bind(extras.grouped_id)
    .bind(extras.reply_to_msg_id)
    .bind(extras.fwd_from_user_id)
    .bind(extras.fwd_from_chat_id)
    .bind(extras.fwd_from_msg_id)
    .bind(extras.fwd_date)
    .bind(encode_entities(&extras.entities))
    .bind(extras.reply_markup.clone())
    .fetch_one(&mut *transaction)
    .await
    .context("insert channel message")?;
    let pts = sqlx::query_scalar::<_, i64>(
        "UPDATE te_chats SET pts = pts + 1, updated_at = now()
         WHERE id = $1 RETURNING pts",
    )
    .bind(channel_id)
    .fetch_one(&mut *transaction)
    .await
    .context("bump channel pts")?;

    let members = sqlx::query_scalar::<_, i64>(
        "SELECT user_id FROM te_chat_members WHERE chat_id = $1 AND left_at = 0",
    )
    .bind(channel_id)
    .fetch_all(&mut *transaction)
    .await
    .context("load channel members")?;
    for member_id in &members {
        upsert_dialog(
            &mut transaction,
            *member_id,
            channel_id,
            seq,
            sent_at,
            *member_id != sender_user_id,
        )
        .await?;
    }
    transaction
        .commit()
        .await
        .context("commit channel msg tx")?;

    Ok((
        MessageRecord {
            id: message_id,
            chat_id: channel_id,
            seq,
            sender_user_id,
            text: text.to_owned(),
            sent_at,
            media_id,
            reply_to_msg_id: extras.reply_to_msg_id,
            grouped_id: extras.grouped_id,
            edit_date: 0,
            views: 0,
            entities: extras.entities.clone(),
            reply_markup: extras.reply_markup.clone(),
            fwd_from_user_id: extras.fwd_from_user_id,
            fwd_from_chat_id: extras.fwd_from_chat_id,
            fwd_from_msg_id: extras.fwd_from_msg_id,
            fwd_date: extras.fwd_date,
            action_kind: String::new(),
            action_user_id: 0,
            action_title: String::new(),
            scheduled_date: 0,
        },
        pts as i32,
        members,
    ))
}

pub async fn send_service_message(
    db: &Db,
    chat_id: i64,
    sender_user_id: i64,
    action_kind: &str,
    action_user_id: i64,
    action_title: &str,
) -> Result<MessageRecord> {
    let mut transaction = db
        .pool()
        .begin()
        .await
        .context("begin service message tx")?;
    sqlx::query("SELECT id FROM te_chats WHERE id = $1 FOR UPDATE")
        .bind(chat_id)
        .execute(&mut *transaction)
        .await
        .context("lock chat for service message")?;
    let seq = sqlx::query_scalar::<_, i64>(
        "SELECT COALESCE(MAX(seq), 0) + 1 FROM te_messages WHERE chat_id = $1",
    )
    .bind(chat_id)
    .fetch_one(&mut *transaction)
    .await
    .context("next service message seq")?;
    let sent_at = unix_time();
    let message_id = sqlx::query_scalar::<_, i64>(
        "INSERT INTO te_messages
             (chat_id, seq, sender_user_id, random_id, sent_at, text,
              action_kind, action_user_id, action_title)
         VALUES ($1, $2, $3, 0, $4, '', $5, $6, $7)
         RETURNING id",
    )
    .bind(chat_id)
    .bind(seq)
    .bind(sender_user_id)
    .bind(sent_at)
    .bind(action_kind)
    .bind(action_user_id)
    .bind(action_title)
    .fetch_one(&mut *transaction)
    .await
    .context("insert service message")?;
    let members = sqlx::query_scalar::<_, i64>(
        "SELECT user_id FROM te_chat_members WHERE chat_id = $1 AND left_at = 0",
    )
    .bind(chat_id)
    .fetch_all(&mut *transaction)
    .await
    .context("load service message members")?;
    for member_id in &members {
        upsert_dialog(&mut transaction, *member_id, chat_id, seq, sent_at, false).await?;
    }
    transaction
        .commit()
        .await
        .context("commit service message tx")?;
    Ok(MessageRecord {
        id: message_id,
        chat_id,
        seq,
        sender_user_id,
        text: String::new(),
        sent_at,
        media_id: None,
        reply_to_msg_id: None,
        grouped_id: 0,
        edit_date: 0,
        views: 0,
        entities: Vec::new(),
        reply_markup: None,
        fwd_from_user_id: None,
        fwd_from_chat_id: None,
        fwd_from_msg_id: None,
        fwd_date: 0,
        action_kind: action_kind.to_owned(),
        action_user_id,
        action_title: action_title.to_owned(),
        scheduled_date: 0,
    })
}

pub async fn ensure_private_chat(db: &Db, a: i64, b: i64) -> Result<i64> {
    let (first, second) = ordered_pair(a, b);
    if let Some(chat_id) = sqlx::query_scalar::<_, i64>(
        "SELECT id FROM te_chats
         WHERE kind = 'private' AND private_user_a = $1 AND private_user_b = $2",
    )
    .bind(first)
    .bind(second)
    .fetch_optional(db.pool())
    .await
    .context("find private chat")?
    {
        return Ok(chat_id);
    }
    let inserted = sqlx::query_scalar::<_, i64>(
        "INSERT INTO te_chats (kind, private_user_a, private_user_b)
         VALUES ('private', $1, $2)
         ON CONFLICT DO NOTHING
         RETURNING id",
    )
    .bind(first)
    .bind(second)
    .fetch_optional(db.pool())
    .await
    .context("create private chat")?;
    match inserted {
        Some(id) => Ok(id),
        None => sqlx::query_scalar::<_, i64>(
            "SELECT id FROM te_chats
             WHERE kind = 'private' AND private_user_a = $1 AND private_user_b = $2",
        )
        .bind(first)
        .bind(second)
        .fetch_one(db.pool())
        .await
        .context("resolve created private chat"),
    }
}

#[allow(clippy::too_many_arguments)]
pub async fn create_scheduled_message(
    db: &Db,
    chat_id: i64,
    sender_user_id: i64,
    text: &str,
    random_id: i64,
    media_id: Option<i64>,
    extras: &MessageExtras,
    scheduled_date: i64,
) -> Result<MessageRecord> {
    let mut transaction = db
        .pool()
        .begin()
        .await
        .context("begin scheduled message tx")?;
    sqlx::query("SELECT id FROM te_chats WHERE id = $1 FOR UPDATE")
        .bind(chat_id)
        .execute(&mut *transaction)
        .await
        .context("lock chat for scheduled message")?;
    let seq = sqlx::query_scalar::<_, i64>(
        "SELECT COALESCE(MAX(seq), 0) + 1 FROM te_messages WHERE chat_id = $1",
    )
    .bind(chat_id)
    .fetch_one(&mut *transaction)
    .await
    .context("next scheduled seq")?;
    let sent_at = unix_time();
    let row = sqlx::query(
        "INSERT INTO te_messages
             (chat_id, seq, sender_user_id, random_id, sent_at, text, media_id, grouped_id,
              reply_to_msg_id, fwd_from_user_id, fwd_from_chat_id, fwd_from_msg_id, fwd_date,
              scheduled_date, entities, reply_markup)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16)
         RETURNING id, chat_id, seq, sender_user_id, text, sent_at, media_id, grouped_id,
                   reply_to_msg_id, edit_date, fwd_from_user_id, fwd_from_chat_id,
                   fwd_from_msg_id, fwd_date, action_kind, action_user_id, action_title,
                   scheduled_date, entities, reply_markup",
    )
    .bind(chat_id)
    .bind(seq)
    .bind(sender_user_id)
    .bind(random_id)
    .bind(sent_at)
    .bind(text)
    .bind(media_id)
    .bind(extras.grouped_id)
    .bind(extras.reply_to_msg_id)
    .bind(extras.fwd_from_user_id)
    .bind(extras.fwd_from_chat_id)
    .bind(extras.fwd_from_msg_id)
    .bind(extras.fwd_date)
    .bind(scheduled_date)
    .bind(encode_entities(&extras.entities))
    .bind(extras.reply_markup.clone())
    .fetch_one(&mut *transaction)
    .await
    .context("insert scheduled message")?;
    transaction
        .commit()
        .await
        .context("commit scheduled message tx")?;
    message_from_row(row)
}

pub async fn list_scheduled_messages(
    db: &Db,
    chat_id: i64,
    sender_user_id: i64,
) -> Result<Vec<MessageRecord>> {
    let rows = sqlx::query(
        "SELECT id, chat_id, seq, sender_user_id, text, sent_at, media_id, grouped_id,
                reply_to_msg_id, edit_date, fwd_from_user_id, fwd_from_chat_id,
                fwd_from_msg_id, fwd_date, action_kind, action_user_id, action_title,
                scheduled_date, entities, reply_markup
         FROM te_messages
         WHERE chat_id = $1 AND sender_user_id = $2 AND scheduled_date > 0
         ORDER BY scheduled_date ASC, seq ASC",
    )
    .bind(chat_id)
    .bind(sender_user_id)
    .fetch_all(db.pool())
    .await
    .context("list scheduled messages")?;
    rows.into_iter().map(message_from_row).collect()
}

pub async fn delete_scheduled_messages(
    db: &Db,
    chat_id: i64,
    sender_user_id: i64,
    ids: &[i64],
) -> Result<Vec<MessageRecord>> {
    if ids.is_empty() {
        return Ok(Vec::new());
    }
    let rows = sqlx::query(
        "DELETE FROM te_messages
         WHERE chat_id = $1 AND sender_user_id = $2 AND id = ANY($3) AND scheduled_date > 0
         RETURNING id, chat_id, seq, sender_user_id, text, sent_at, media_id, grouped_id,
                   reply_to_msg_id, edit_date, fwd_from_user_id, fwd_from_chat_id,
                   fwd_from_msg_id, fwd_date, action_kind, action_user_id, action_title,
                   scheduled_date, entities, reply_markup",
    )
    .bind(chat_id)
    .bind(sender_user_id)
    .bind(ids)
    .fetch_all(db.pool())
    .await
    .context("delete scheduled messages")?;
    rows.into_iter().map(message_from_row).collect()
}

pub async fn activate_scheduled_message(db: &Db, message_id: i64) -> Result<Option<MessageRecord>> {
    let mut transaction = db
        .pool()
        .begin()
        .await
        .context("begin activate scheduled tx")?;
    let row = sqlx::query(
        "UPDATE te_messages SET scheduled_date = 0, sent_at = $2
         WHERE id = $1 AND scheduled_date > 0
         RETURNING id, chat_id, seq, sender_user_id, text, sent_at, media_id, grouped_id,
                   reply_to_msg_id, edit_date, fwd_from_user_id, fwd_from_chat_id,
                   fwd_from_msg_id, fwd_date, action_kind, action_user_id, action_title,
                   scheduled_date, entities, reply_markup",
    )
    .bind(message_id)
    .bind(unix_time())
    .fetch_optional(&mut *transaction)
    .await
    .context("activate scheduled message")?;
    let Some(row) = row else {
        transaction
            .commit()
            .await
            .context("commit empty activate tx")?;
        return Ok(None);
    };
    let record = message_from_row(row)?;
    let members = sqlx::query_scalar::<_, i64>(
        "SELECT user_id FROM te_chat_members WHERE chat_id = $1 AND left_at = 0",
    )
    .bind(record.chat_id)
    .fetch_all(&mut *transaction)
    .await
    .context("load activated members")?;
    for member_id in members {
        upsert_dialog(
            &mut transaction,
            member_id,
            record.chat_id,
            record.seq,
            record.sent_at,
            member_id != record.sender_user_id,
        )
        .await?;
    }
    transaction
        .commit()
        .await
        .context("commit activate scheduled tx")?;
    Ok(Some(record))
}

pub async fn due_scheduled_message_ids(db: &Db, timestamp: i64) -> Result<Vec<i64>> {
    sqlx::query_scalar::<_, i64>(
        "SELECT id FROM te_messages
         WHERE scheduled_date > 0 AND scheduled_date <= $1
         ORDER BY scheduled_date ASC
         LIMIT 100",
    )
    .bind(timestamp)
    .fetch_all(db.pool())
    .await
    .context("load due scheduled messages")
}

pub async fn channel_pts(db: &Db, channel_id: i64) -> Result<i32> {
    let pts = sqlx::query_scalar::<_, i64>("SELECT pts FROM te_chats WHERE id = $1")
        .bind(channel_id)
        .fetch_one(db.pool())
        .await
        .context("load channel pts")?;
    Ok(pts as i32)
}

pub async fn read_history(db: &Db, user_id: i64, chat_id: i64, max_message_id: i64) -> Result<i32> {
    sqlx::query(
        "UPDATE te_user_dialogs d
         SET read_max_seq = GREATEST(
                 d.read_max_seq,
                 COALESCE((SELECT MAX(m.seq) FROM te_messages m
                           WHERE m.chat_id = d.chat_id AND m.id <= $3), 0)),
             unread_count = 0,
             updated_at = now()
         WHERE d.user_id = $1 AND d.chat_id = $2",
    )
    .bind(user_id)
    .bind(chat_id)
    .bind(max_message_id)
    .execute(db.pool())
    .await
    .context("read history")?;
    user_pts(db, user_id).await
}

/// Persists the last time a user was seen online (unix seconds). The value
/// only moves forward so a late disconnect from an older client cannot
/// overwrite a newer timestamp.
pub async fn touch_user_last_seen(db: &Db, user_id: i64, timestamp: i64) -> Result<()> {
    sqlx::query("UPDATE te_users SET last_seen_at = GREATEST(last_seen_at, $2) WHERE id = $1")
        .bind(user_id)
        .bind(timestamp)
        .execute(db.pool())
        .await
        .context("touch user last seen")?;
    Ok(())
}

/// Users that share a private chat with `user_id`; they are the audience for
/// `updateUserStatus` presence changes.
pub async fn presence_peers(db: &Db, user_id: i64) -> Result<Vec<i64>> {
    sqlx::query_scalar::<_, i64>(
        "SELECT CASE WHEN private_user_a = $1 THEN private_user_b ELSE private_user_a END
         FROM te_chats
         WHERE kind = 'private' AND (private_user_a = $1 OR private_user_b = $1)",
    )
    .bind(user_id)
    .fetch_all(db.pool())
    .await
    .context("load presence peers")
}

pub async fn user_pts(db: &Db, user_id: i64) -> Result<i32> {
    let pts = sqlx::query_scalar::<_, i64>("SELECT pts FROM te_users WHERE id = $1")
        .bind(user_id)
        .fetch_one(db.pool())
        .await
        .context("load user pts")?;
    Ok(pts as i32)
}

fn ordered_pair(a: i64, b: i64) -> (i64, i64) {
    if a < b {
        (a, b)
    } else {
        (b, a)
    }
}

fn message_from_row(row: sqlx::postgres::PgRow) -> Result<MessageRecord> {
    Ok(MessageRecord {
        id: row.try_get("id").context("read message id")?,
        chat_id: row.try_get("chat_id").context("read message chat")?,
        seq: row.try_get("seq").context("read message seq")?,
        sender_user_id: row
            .try_get("sender_user_id")
            .context("read message sender")?,
        text: row.try_get("text").context("read message text")?,
        sent_at: row.try_get("sent_at").context("read message date")?,
        media_id: row.try_get("media_id").context("read message media")?,
        reply_to_msg_id: row
            .try_get("reply_to_msg_id")
            .context("read message reply")?,
        grouped_id: row
            .try_get("grouped_id")
            .context("read message grouped id")?,
        edit_date: row.try_get("edit_date").context("read message edit date")?,
        fwd_from_user_id: row
            .try_get("fwd_from_user_id")
            .context("read message fwd user")?,
        fwd_from_chat_id: row
            .try_get("fwd_from_chat_id")
            .context("read message fwd chat")?,
        fwd_from_msg_id: row
            .try_get("fwd_from_msg_id")
            .context("read message fwd id")?,
        fwd_date: row.try_get("fwd_date").context("read message fwd date")?,
        action_kind: row.try_get("action_kind").context("read message action")?,
        action_user_id: row
            .try_get("action_user_id")
            .context("read message action user")?,
        action_title: row
            .try_get("action_title")
            .context("read message action title")?,
        scheduled_date: row
            .try_get("scheduled_date")
            .context("read message scheduled date")?,
        views: row.try_get("views").unwrap_or(0),
        entities: row
            .try_get::<serde_json::Value, _>("entities")
            .map(entities_from_json)
            .unwrap_or_default(),
        reply_markup: row.try_get::<Option<serde_json::Value>, _>("reply_markup")?,
    })
}

fn unix_time() -> i64 {
    std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .unwrap_or_default()
        .as_secs() as i64
}

#[derive(Debug, Clone)]
pub struct UploadPartRecord {
    pub part: i32,
    pub storage_key: String,
    pub size: i64,
    pub total_parts: i32,
}

#[allow(clippy::too_many_arguments)]
pub async fn save_upload_part(
    db: &Db,
    upload_id: i64,
    owner_user_id: i64,
    part: i32,
    total_parts: i32,
    is_big: bool,
    storage_key: &str,
    size: i64,
) -> Result<()> {
    sqlx::query(
        "INSERT INTO te_upload_parts
             (upload_id, owner_user_id, part, total_parts, is_big, storage_key, size)
         VALUES ($1, $2, $3, $4, $5, $6, $7)
         ON CONFLICT (upload_id, part) DO UPDATE SET
             owner_user_id = EXCLUDED.owner_user_id,
             total_parts = EXCLUDED.total_parts,
             is_big = EXCLUDED.is_big,
             storage_key = EXCLUDED.storage_key,
             size = EXCLUDED.size",
    )
    .bind(upload_id)
    .bind(owner_user_id)
    .bind(part)
    .bind(total_parts)
    .bind(is_big)
    .bind(storage_key)
    .bind(size)
    .execute(db.pool())
    .await
    .context("save upload part")?;
    Ok(())
}

pub async fn list_upload_parts(
    db: &Db,
    upload_id: i64,
    owner_user_id: i64,
) -> Result<Vec<UploadPartRecord>> {
    let rows = sqlx::query(
        "SELECT part, storage_key, size, total_parts
         FROM te_upload_parts
         WHERE upload_id = $1 AND owner_user_id = $2
         ORDER BY part",
    )
    .bind(upload_id)
    .bind(owner_user_id)
    .fetch_all(db.pool())
    .await
    .context("list upload parts")?;
    rows.into_iter()
        .map(|row| {
            Ok(UploadPartRecord {
                part: row.try_get("part").context("read upload part")?,
                storage_key: row.try_get("storage_key").context("read upload key")?,
                size: row.try_get("size").context("read upload size")?,
                total_parts: row.try_get("total_parts").context("read upload total")?,
            })
        })
        .collect()
}

pub async fn delete_upload_parts(db: &Db, upload_id: i64, owner_user_id: i64) -> Result<()> {
    sqlx::query("DELETE FROM te_upload_parts WHERE upload_id = $1 AND owner_user_id = $2")
        .bind(upload_id)
        .bind(owner_user_id)
        .execute(db.pool())
        .await
        .context("delete upload parts")?;
    Ok(())
}

#[derive(Debug, Clone)]
pub struct TempAuthKeyBinding {
    pub temp_auth_key_id: i64,
    pub perm_auth_key_id: i64,
    pub nonce: i64,
    pub temp_session_id: i64,
    pub expires_at: i64,
}

pub async fn save_temp_auth_key_binding(db: &Db, binding: &TempAuthKeyBinding) -> Result<bool> {
    let result = sqlx::query(
        "INSERT INTO te_temp_auth_key_bindings
             (temp_auth_key_id, perm_auth_key_id, nonce, temp_session_id, expires_at)
         VALUES ($1, $2, $3, $4, $5)
         ON CONFLICT (temp_auth_key_id) DO UPDATE SET
             nonce = EXCLUDED.nonce,
             temp_session_id = EXCLUDED.temp_session_id,
             expires_at = EXCLUDED.expires_at,
             created_at = now()
         WHERE te_temp_auth_key_bindings.perm_auth_key_id = EXCLUDED.perm_auth_key_id",
    )
    .bind(binding.temp_auth_key_id)
    .bind(binding.perm_auth_key_id)
    .bind(binding.nonce)
    .bind(binding.temp_session_id)
    .bind(binding.expires_at)
    .execute(db.pool())
    .await
    .context("save temp auth key binding")?;
    Ok(result.rows_affected() == 1)
}

pub async fn find_temp_auth_key_binding(
    db: &Db,
    temp_auth_key_id: i64,
) -> Result<Option<TempAuthKeyBinding>> {
    let row = sqlx::query(
        "SELECT temp_auth_key_id, perm_auth_key_id, nonce, temp_session_id, expires_at
         FROM te_temp_auth_key_bindings
         WHERE temp_auth_key_id = $1",
    )
    .bind(temp_auth_key_id)
    .fetch_optional(db.pool())
    .await
    .context("find temp auth key binding")?;
    row.map(|row| {
        Ok(TempAuthKeyBinding {
            temp_auth_key_id: row
                .try_get("temp_auth_key_id")
                .context("read temp key id")?,
            perm_auth_key_id: row
                .try_get("perm_auth_key_id")
                .context("read perm key id")?,
            nonce: row.try_get("nonce").context("read temp key nonce")?,
            temp_session_id: row
                .try_get("temp_session_id")
                .context("read temp session")?,
            expires_at: row.try_get("expires_at").context("read temp expiry")?,
        })
    })
    .transpose()
}

pub async fn merge_session_for_auth_key(
    db: &Db,
    temp_auth_key_id: i64,
    perm_auth_key_id: i64,
) -> Result<Option<i64>> {
    let mut transaction = db
        .pool()
        .begin()
        .await
        .context("begin temp auth key session merge")?;

    // Sign-in usually happens on the temporary key, while the freshly
    // generated permanent key has no session yet. Copy in both directions so
    // the bound pair shares one authorization regardless of which key the
    // client used first.
    sqlx::query(
        "INSERT INTO te_sessions (auth_key_id, user_id, layer, ip)
         SELECT $1, user_id, layer, ip FROM te_sessions WHERE auth_key_id = $2
         ON CONFLICT (auth_key_id) DO NOTHING",
    )
    .bind(perm_auth_key_id)
    .bind(temp_auth_key_id)
    .execute(&mut *transaction)
    .await
    .context("copy temporary session to permanent key")?;
    sqlx::query(
        "INSERT INTO te_sessions (auth_key_id, user_id, layer, ip)
         SELECT $1, user_id, layer, ip FROM te_sessions WHERE auth_key_id = $2
         ON CONFLICT (auth_key_id) DO NOTHING",
    )
    .bind(temp_auth_key_id)
    .bind(perm_auth_key_id)
    .execute(&mut *transaction)
    .await
    .context("copy permanent session to temporary key")?;

    sqlx::query(
        "INSERT INTO te_update_states (auth_key_id, user_id, pts, qts, seq, date)
         SELECT $1, user_id, pts, qts, seq, date FROM te_update_states WHERE auth_key_id = $2
         ON CONFLICT (auth_key_id) DO NOTHING",
    )
    .bind(perm_auth_key_id)
    .bind(temp_auth_key_id)
    .execute(&mut *transaction)
    .await
    .context("copy temporary update state to permanent key")?;
    sqlx::query(
        "INSERT INTO te_update_states (auth_key_id, user_id, pts, qts, seq, date)
         SELECT $1, user_id, pts, qts, seq, date FROM te_update_states WHERE auth_key_id = $2
         ON CONFLICT (auth_key_id) DO NOTHING",
    )
    .bind(temp_auth_key_id)
    .bind(perm_auth_key_id)
    .execute(&mut *transaction)
    .await
    .context("copy permanent update state to temporary key")?;

    let temp_user: Option<i64> =
        sqlx::query_scalar("SELECT user_id FROM te_sessions WHERE auth_key_id = $1")
            .bind(temp_auth_key_id)
            .fetch_optional(&mut *transaction)
            .await
            .context("read temporary session user")?;
    let perm_user: Option<i64> =
        sqlx::query_scalar("SELECT user_id FROM te_sessions WHERE auth_key_id = $1")
            .bind(perm_auth_key_id)
            .fetch_optional(&mut *transaction)
            .await
            .context("read permanent session user")?;

    let resolved = match (temp_user, perm_user) {
        (Some(temp), Some(perm)) if temp != perm => {
            bail!("temporary and permanent auth keys belong to different users")
        }
        (Some(user), _) | (_, Some(user)) => Some(user),
        (None, None) => None,
    };
    transaction
        .commit()
        .await
        .context("commit temp auth key session merge")?;
    Ok(resolved)
}

pub async fn auth_key_binding_peers(db: &Db, auth_key_id: i64) -> Result<Vec<i64>> {
    let rows = sqlx::query(
        "SELECT perm_auth_key_id AS peer
         FROM te_temp_auth_key_bindings WHERE temp_auth_key_id = $1
         UNION
         SELECT temp_auth_key_id AS peer
         FROM te_temp_auth_key_bindings WHERE perm_auth_key_id = $1",
    )
    .bind(auth_key_id)
    .fetch_all(db.pool())
    .await
    .context("list bound auth key peers")?;
    rows.into_iter()
        .map(|row| row.try_get("peer").context("read bound auth key peer"))
        .collect()
}

/// Propagates a freshly authorized session to the other side of a
/// temp鈫抪ermanent binding. Sign-in commonly happens after the bind request, so
/// the copy must also run on `auth.signIn`, not only inside the bind handler.
pub async fn copy_session_to_auth_key(db: &Db, source: i64, destination: i64) -> Result<()> {
    let mut transaction = db.pool().begin().await.context("begin session copy")?;
    sqlx::query(
        "INSERT INTO te_sessions (auth_key_id, user_id, layer, ip)
         SELECT $1, user_id, layer, ip FROM te_sessions WHERE auth_key_id = $2
         ON CONFLICT (auth_key_id) DO NOTHING",
    )
    .bind(destination)
    .bind(source)
    .execute(&mut *transaction)
    .await
    .context("copy session to bound auth key")?;
    sqlx::query(
        "INSERT INTO te_update_states (auth_key_id, user_id, pts, qts, seq, date)
         SELECT $1, user_id, pts, qts, seq, date FROM te_update_states WHERE auth_key_id = $2
         ON CONFLICT (auth_key_id) DO NOTHING",
    )
    .bind(destination)
    .bind(source)
    .execute(&mut *transaction)
    .await
    .context("copy update state to bound auth key")?;
    transaction.commit().await.context("commit session copy")?;
    Ok(())
}

#[derive(Debug, Clone)]
pub struct MediaThumbRecord {
    pub kind: String,
    pub storage_key: String,
    pub width: i32,
    pub height: i32,
    pub size: i64,
}

#[derive(Debug, Clone)]
pub struct MediaThumbInput {
    pub kind: String,
    pub storage_key: String,
    pub width: i32,
    pub height: i32,
    pub size: i64,
}

#[derive(Debug, Clone, Default)]
pub struct MediaAudioInput {
    pub voice: bool,
    pub title: String,
    pub performer: String,
    pub waveform: Vec<u8>,
}

#[derive(Debug, Clone, Default)]
pub struct MediaStickerInput {
    pub sticker: bool,
    pub alt: String,
    pub set_id: i64,
    pub set_access_hash: i64,
    pub custom_emoji: bool,
    pub custom_emoji_alt: String,
}

#[derive(Debug, Clone)]
pub struct MediaRecord {
    pub id: i64,
    pub kind: String,
    pub storage_key: String,
    pub thumb_storage_key: String,
    #[allow(dead_code)]
    pub sha256: Vec<u8>,
    pub mime_type: String,
    pub size: i64,
    pub width: i32,
    pub height: i32,
    pub thumb_width: i32,
    pub thumb_height: i32,
    pub thumb_size: i64,
    pub duration: i32,
    pub audio_voice: bool,
    pub audio_title: String,
    pub audio_performer: String,
    pub audio_waveform: Vec<u8>,
    pub sticker: bool,
    pub sticker_alt: String,
    pub sticker_set_id: i64,
    pub sticker_set_access_hash: i64,
    pub custom_emoji: bool,
    pub custom_emoji_alt: String,
    pub access_hash: i64,
    pub file_reference: Vec<u8>,
    pub file_name: String,
    pub created_at: i64,
    /// Inline metadata for file-less media (`poll`, `geo`, `contact`, `dice`).
    pub payload: serde_json::Value,
    pub thumbs: Vec<MediaThumbRecord>,
}

#[allow(clippy::too_many_arguments)]
pub async fn create_media(
    db: &Db,
    owner_user_id: i64,
    kind: &str,
    storage_key: &str,
    thumb_storage_key: &str,
    sha256: &[u8],
    mime_type: &str,
    size: i64,
    width: i32,
    height: i32,
    thumb_width: i32,
    thumb_height: i32,
    thumb_size: i64,
    duration: i32,
    file_name: &str,
    thumbs: &[MediaThumbInput],
    audio: &MediaAudioInput,
    sticker: &MediaStickerInput,
) -> Result<MediaRecord> {
    let access_hash = nonzero_random();
    let mut file_reference = Vec::with_capacity(16);
    for _ in 0..16 {
        file_reference.push(rand::random::<u8>());
    }
    let mut transaction = db.pool().begin().await.context("begin media tx")?;
    let row = sqlx::query(
        "INSERT INTO te_media_files
             (kind, storage_key, thumb_storage_key, sha256, mime_type, size,
              width, height, thumb_width, thumb_height, thumb_size, duration,
              access_hash, file_reference, owner_user_id, file_name,
              audio_voice, audio_title, audio_performer, audio_waveform,
              sticker, sticker_alt, sticker_set_id, sticker_set_access_hash,
              custom_emoji, custom_emoji_alt)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16,
                 $17, $18, $19, $20, $21, $22, $23, $24, $25, $26)
         RETURNING id",
    )
    .bind(kind)
    .bind(storage_key)
    .bind(thumb_storage_key)
    .bind(sha256)
    .bind(mime_type)
    .bind(size)
    .bind(width)
    .bind(height)
    .bind(thumb_width)
    .bind(thumb_height)
    .bind(thumb_size)
    .bind(duration)
    .bind(access_hash)
    .bind(&file_reference)
    .bind(owner_user_id)
    .bind(file_name)
    .bind(audio.voice)
    .bind(&audio.title)
    .bind(&audio.performer)
    .bind(&audio.waveform)
    .bind(sticker.sticker)
    .bind(&sticker.alt)
    .bind(sticker.set_id)
    .bind(sticker.set_access_hash)
    .bind(sticker.custom_emoji)
    .bind(&sticker.custom_emoji_alt)
    .fetch_one(&mut *transaction)
    .await
    .context("create media")?;
    let media_id = row.try_get("id").context("read media id")?;
    for thumb in thumbs {
        sqlx::query(
            "INSERT INTO te_media_thumbs (media_id, kind, storage_key, width, height, size)
             VALUES ($1, $2, $3, $4, $5, $6)
             ON CONFLICT (media_id, kind) DO UPDATE
             SET storage_key = EXCLUDED.storage_key,
                 width = EXCLUDED.width,
                 height = EXCLUDED.height,
                 size = EXCLUDED.size",
        )
        .bind(media_id)
        .bind(&thumb.kind)
        .bind(&thumb.storage_key)
        .bind(thumb.width)
        .bind(thumb.height)
        .bind(thumb.size)
        .execute(&mut *transaction)
        .await
        .context("insert media thumbnail")?;
    }
    transaction.commit().await.context("commit media tx")?;
    Ok(MediaRecord {
        id: media_id,
        kind: kind.to_owned(),
        storage_key: storage_key.to_owned(),
        thumb_storage_key: thumb_storage_key.to_owned(),
        sha256: sha256.to_vec(),
        mime_type: mime_type.to_owned(),
        size,
        width,
        height,
        thumb_width,
        thumb_height,
        thumb_size,
        duration,
        audio_voice: audio.voice,
        audio_title: audio.title.clone(),
        audio_performer: audio.performer.clone(),
        audio_waveform: audio.waveform.clone(),
        sticker: sticker.sticker,
        sticker_alt: sticker.alt.clone(),
        sticker_set_id: sticker.set_id,
        sticker_set_access_hash: sticker.set_access_hash,
        custom_emoji: sticker.custom_emoji,
        custom_emoji_alt: sticker.custom_emoji_alt.clone(),
        access_hash,
        file_reference,
        file_name: file_name.to_owned(),
        created_at: unix_time(),
        payload: serde_json::Value::Object(serde_json::Map::new()),
        thumbs: thumbs
            .iter()
            .map(|thumb| MediaThumbRecord {
                kind: thumb.kind.clone(),
                storage_key: thumb.storage_key.clone(),
                width: thumb.width,
                height: thumb.height,
                size: thumb.size,
            })
            .collect(),
    })
}

pub async fn find_media(db: &Db, id: i64) -> Result<Option<MediaRecord>> {
    let row = sqlx::query(
        "SELECT id, kind, storage_key, thumb_storage_key, sha256, mime_type, size,
                width, height, thumb_width, thumb_height, thumb_size, duration,
                access_hash, file_reference, file_name,
                audio_voice, audio_title, audio_performer, audio_waveform,
                sticker, sticker_alt, sticker_set_id, sticker_set_access_hash,
                custom_emoji, custom_emoji_alt, media_payload,
                EXTRACT(EPOCH FROM created_at)::bigint AS created_at
         FROM te_media_files
         WHERE id = $1",
    )
    .bind(id)
    .fetch_optional(db.pool())
    .await
    .context("find media")?;
    let Some(row) = row else {
        return Ok(None);
    };
    let thumbs = sqlx::query(
        "SELECT kind, storage_key, width, height, size
         FROM te_media_thumbs
         WHERE media_id = $1
         ORDER BY size ASC",
    )
    .bind(id)
    .fetch_all(db.pool())
    .await
    .context("list media thumbnails")?;
    let thumbs = thumbs
        .into_iter()
        .map(|row| {
            Ok(MediaThumbRecord {
                kind: row.try_get("kind").context("read thumb kind")?,
                storage_key: row.try_get("storage_key").context("read thumb key")?,
                width: row.try_get("width").context("read thumb width")?,
                height: row.try_get("height").context("read thumb height")?,
                size: row.try_get("size").context("read thumb size")?,
            })
        })
        .collect::<Result<Vec<_>>>()?;
    Ok(Some(MediaRecord {
        id: row.try_get("id").context("read media id")?,
        kind: row.try_get("kind").context("read media kind")?,
        storage_key: row.try_get("storage_key").context("read media key")?,
        thumb_storage_key: row
            .try_get("thumb_storage_key")
            .context("read media thumb key")?,
        sha256: row.try_get("sha256").context("read media sha")?,
        mime_type: row.try_get("mime_type").context("read media mime")?,
        size: row.try_get("size").context("read media size")?,
        width: row.try_get("width").context("read media width")?,
        height: row.try_get("height").context("read media height")?,
        thumb_width: row
            .try_get("thumb_width")
            .context("read media thumb width")?,
        thumb_height: row
            .try_get("thumb_height")
            .context("read media thumb height")?,
        thumb_size: row.try_get("thumb_size").context("read media thumb size")?,
        duration: row.try_get("duration").context("read media duration")?,
        audio_voice: row.try_get("audio_voice").context("read media voice")?,
        audio_title: row.try_get("audio_title").context("read media title")?,
        audio_performer: row
            .try_get("audio_performer")
            .context("read media performer")?,
        audio_waveform: row
            .try_get::<Option<Vec<u8>>, _>("audio_waveform")
            .context("read media waveform")?
            .unwrap_or_default(),
        sticker: row.try_get("sticker").context("read media sticker")?,
        sticker_alt: row
            .try_get("sticker_alt")
            .context("read media sticker alt")?,
        sticker_set_id: row
            .try_get("sticker_set_id")
            .context("read media sticker set")?,
        sticker_set_access_hash: row
            .try_get("sticker_set_access_hash")
            .context("read media sticker set access")?,
        custom_emoji: row
            .try_get("custom_emoji")
            .context("read media custom emoji")?,
        custom_emoji_alt: row
            .try_get("custom_emoji_alt")
            .context("read media custom emoji alt")?,
        access_hash: row.try_get("access_hash").context("read media access")?,
        file_reference: row
            .try_get("file_reference")
            .context("read media reference")?,
        file_name: row.try_get("file_name").context("read media name")?,
        created_at: row.try_get("created_at").context("read media date")?,
        payload: row.try_get("media_payload").context("read media payload")?,
        thumbs,
    }))
}

/// Bumps the view counter for messages that belong to `chat_id`.
pub async fn increment_message_views(db: &Db, chat_id: i64, ids: &[i64]) -> Result<()> {
    if ids.is_empty() {
        return Ok(());
    }
    sqlx::query(
        "UPDATE te_messages SET views = views + 1 WHERE chat_id = $1 AND id = ANY($2)",
    )
    .bind(chat_id)
    .bind(ids)
    .execute(db.pool())
    .await
    .context("increment message views")?;
    Ok(())
}

/// View counters for the requested messages, ordered by the given id list.
pub async fn message_views(db: &Db, chat_id: i64, ids: &[i64]) -> Result<Vec<(i64, i64)>> {
    if ids.is_empty() {
        return Ok(Vec::new());
    }
    let rows = sqlx::query(
        "SELECT id, views FROM te_messages WHERE chat_id = $1 AND id = ANY($2)",
    )
    .bind(chat_id)
    .bind(ids)
    .fetch_all(db.pool())
    .await
    .context("load message views")?;
    let mut found = std::collections::HashMap::new();
    for row in rows {
        let id: i64 = row.try_get("id").context("read view message id")?;
        let views: i64 = row.try_get("views").context("read views")?;
        found.insert(id, views);
    }
    Ok(ids
        .iter()
        .map(|id| (*id, found.get(id).copied().unwrap_or(0)))
        .collect())
}

/// Stores a file-less media payload (`poll`, `geo`, `contact`, `dice`).
pub async fn create_special_media(
    db: &Db,
    owner_user_id: i64,
    kind: &str,
    payload: &serde_json::Value,
) -> Result<MediaRecord> {
    let access_hash = nonzero_random();
    let mut file_reference = Vec::with_capacity(16);
    for _ in 0..16 {
        file_reference.push(rand::random::<u8>());
    }
    let storage_key = format!("special/{kind}/{access_hash}");
    let row = sqlx::query(
        "INSERT INTO te_media_files
             (kind, storage_key, thumb_storage_key, sha256, mime_type, size,
              width, height, duration, access_hash, file_reference, owner_user_id,
              file_name, media_payload)
         VALUES ($1, $2, '', $3, '', 0, 0, 0, 0, $4, $5, $6, '', $7)
         RETURNING id, EXTRACT(EPOCH FROM created_at)::bigint AS created_at",
    )
    .bind(kind)
    .bind(&storage_key)
    .bind(Vec::<u8>::new())
    .bind(access_hash)
    .bind(&file_reference)
    .bind(owner_user_id)
    .bind(payload)
    .fetch_one(db.pool())
    .await
    .context("create special media")?;
    Ok(MediaRecord {
        id: row.try_get("id").context("read special media id")?,
        kind: kind.to_owned(),
        storage_key,
        thumb_storage_key: String::new(),
        sha256: Vec::new(),
        mime_type: String::new(),
        size: 0,
        width: 0,
        height: 0,
        thumb_width: 0,
        thumb_height: 0,
        thumb_size: 0,
        duration: 0,
        audio_voice: false,
        audio_title: String::new(),
        audio_performer: String::new(),
        audio_waveform: Vec::new(),
        sticker: false,
        sticker_alt: String::new(),
        sticker_set_id: 0,
        sticker_set_access_hash: 0,
        custom_emoji: false,
        custom_emoji_alt: String::new(),
        access_hash,
        file_reference,
        file_name: String::new(),
        created_at: row.try_get("created_at").context("read special media date")?,
        payload: payload.clone(),
        thumbs: Vec::new(),
    })
}

/// Replaces the user's whole selection for a poll. An empty `options` slice
/// retracts the vote.
pub async fn replace_poll_vote(
    db: &Db,
    media_id: i64,
    user_id: i64,
    options: &[Vec<u8>],
) -> Result<()> {
    let mut transaction = db.pool().begin().await.context("begin poll vote tx")?;
    sqlx::query("DELETE FROM te_poll_votes WHERE media_id = $1 AND user_id = $2")
        .bind(media_id)
        .bind(user_id)
        .execute(&mut *transaction)
        .await
        .context("clear poll vote")?;
    for option in options {
        sqlx::query(
            "INSERT INTO te_poll_votes (media_id, user_id, option, voted_at)
             VALUES ($1, $2, $3, $4)
             ON CONFLICT (media_id, user_id, option) DO NOTHING",
        )
        .bind(media_id)
        .bind(user_id)
        .bind(option)
        .bind(unix_time())
        .execute(&mut *transaction)
        .await
        .context("insert poll vote")?;
    }
    transaction.commit().await.context("commit poll vote tx")?;
    Ok(())
}

/// Per-option voter counts for a poll.
pub async fn poll_option_counts(db: &Db, media_id: i64) -> Result<Vec<(Vec<u8>, i64)>> {
    let rows = sqlx::query(
        "SELECT option, COUNT(*)::bigint AS voters
         FROM te_poll_votes
         WHERE media_id = $1
         GROUP BY option",
    )
    .bind(media_id)
    .fetch_all(db.pool())
    .await
    .context("poll option counts")?;
    rows.into_iter()
        .map(|row| {
            Ok((
                row.try_get("option").context("read poll option")?,
                row.try_get("voters").context("read poll voters")?,
            ))
        })
        .collect()
}

pub async fn poll_voter_total(db: &Db, media_id: i64) -> Result<i64> {
    let total: i64 = sqlx::query_scalar(
        "SELECT COUNT(DISTINCT user_id)::bigint FROM te_poll_votes WHERE media_id = $1",
    )
    .bind(media_id)
    .fetch_one(db.pool())
    .await
    .context("poll voter total")?;
    Ok(total)
}

pub async fn poll_user_options(db: &Db, media_id: i64, user_id: i64) -> Result<Vec<Vec<u8>>> {
    let rows = sqlx::query(
        "SELECT option FROM te_poll_votes WHERE media_id = $1 AND user_id = $2",
    )
    .bind(media_id)
    .bind(user_id)
    .fetch_all(db.pool())
    .await
    .context("poll user options")?;
    rows.into_iter()
        .map(|row| row.try_get("option").context("read poll user option"))
        .collect()
}

fn nonzero_random() -> i64 {
    let mut value = rand::random::<i64>();
    if value == 0 {
        value = 1;
    }
    value
}

