//! Upload part storage, media assembly and lightweight file inspection.

use std::io::SeekFrom;
use std::path::{Path, PathBuf};

use anyhow::{bail, Context, Result};
use sha2::{Digest, Sha256};
use tokio::io::{AsyncReadExt, AsyncSeekExt, AsyncWriteExt};

use crate::repo::UploadPartRecord;

#[derive(Debug, Clone)]
pub struct FileAnalysis {
    pub width: i32,
    pub height: i32,
    pub duration: i32,
    pub mime_type: String,
    pub extension: String,
    pub is_image: bool,
    pub is_video: bool,
}

#[derive(Debug, Clone)]
pub struct Thumbnail {
    pub kind: String,
    pub storage_key: String,
    pub width: i32,
    pub height: i32,
    pub size: i64,
}

#[derive(Debug, Clone)]
pub struct AssembledFile {
    pub storage_key: String,
    pub size: i64,
    pub sha256: Vec<u8>,
    pub analysis: FileAnalysis,
    pub thumbnails: Vec<Thumbnail>,
}
/// Persist one `upload.saveFilePart` chunk and return its storage key.
pub async fn write_part(
    media_dir: &Path,
    upload_id: i64,
    part: i32,
    data: &[u8],
) -> Result<String> {
    let directory = media_dir.join("uploads").join(upload_id.to_string());
    tokio::fs::create_dir_all(&directory)
        .await
        .context("create upload directory")?;
    let path = directory.join(part.to_string());
    tokio::fs::write(&path, data)
        .await
        .with_context(|| format!("write upload part {}", path.display()))?;
    Ok(format!("uploads/{upload_id}/{part}"))
}

/// Concatenate all uploaded parts into a single file under `media_dir/files`.
pub async fn assemble(
    media_dir: &Path,
    upload_id: i64,
    parts: &[UploadPartRecord],
    expected_parts: i32,
    file_name: &str,
) -> Result<AssembledFile> {
    if parts.is_empty() {
        bail!("upload {upload_id} has no parts");
    }
    let expected = if expected_parts > 0 {
        expected_parts
    } else {
        parts.len() as i32
    };
    if parts.len() != expected as usize {
        bail!(
            "upload {upload_id} has {} of {} parts",
            parts.len(),
            expected
        );
    }
    for (index, part) in parts.iter().enumerate() {
        if part.part != index as i32 {
            bail!("upload {upload_id} is missing part {index}");
        }
    }
    if let Some(total) = parts.iter().map(|part| part.total_parts).max() {
        if total > 0 && total != expected {
            bail!("upload {upload_id} declares {total} total parts, got {expected}");
        }
    }

    let files_dir = media_dir.join("files");
    tokio::fs::create_dir_all(&files_dir)
        .await
        .context("create media directory")?;
    let temporary = files_dir.join(format!("upload-{upload_id}-{}.tmp", rand::random::<u32>()));
    let mut output = tokio::fs::File::create(&temporary)
        .await
        .with_context(|| format!("create {}", temporary.display()))?;
    let mut hasher = Sha256::new();
    let mut head: Vec<u8> = Vec::new();
    let mut total_size: i64 = 0;

    for part in parts {
        let path = resolve(media_dir, &part.storage_key)?;
        let data = tokio::fs::read(&path)
            .await
            .with_context(|| format!("read upload part {}", path.display()))?;
        if part.size > 0 && data.len() as i64 != part.size {
            bail!(
                "upload part {} changed size: {} != {}",
                part.part,
                data.len(),
                part.size
            );
        }
        hasher.update(&data);
        output
            .write_all(&data)
            .await
            .context("write assembled media")?;
        total_size += data.len() as i64;
        if head.len() < 64 * 1024 {
            let remaining = 64 * 1024 - head.len();
            head.extend_from_slice(&data[..data.len().min(remaining)]);
        }
    }
    output.flush().await.context("flush assembled media")?;
    drop(output);

    let analysis = analyze(&head, file_name);
    let extension = if analysis.extension.is_empty() {
        "bin".to_owned()
    } else {
        analysis.extension.clone()
    };
    let mut name = rand::random::<i64>().to_string();
    if name.starts_with('-') {
        name.remove(0);
    }
    let storage_key = format!("files/{name}.{extension}");
    let final_path = media_dir.join(&storage_key);
    tokio::fs::rename(&temporary, &final_path)
        .await
        .with_context(|| format!("move media to {}", final_path.display()))?;

    let thumbnails = if analysis.is_image {
        match generate_thumbnails(media_dir, &final_path) {
            Ok(thumbnails) => thumbnails,
            Err(error) => {
                tracing::warn!(%error, path = %final_path.display(), "thumbnail generation failed");
                Vec::new()
            }
        }
    } else if analysis.is_video {
        match generate_video_thumbnails(media_dir, &final_path, analysis.duration) {
            Ok(thumbnails) => thumbnails,
            Err(error) => {
                tracing::warn!(%error, path = %final_path.display(), "video thumbnail generation failed");
                Vec::new()
            }
        }
    } else {
        Vec::new()
    };

    let upload_directory = media_dir.join("uploads").join(upload_id.to_string());
    let _ = tokio::fs::remove_dir_all(&upload_directory).await;

    Ok(AssembledFile {
        storage_key,
        size: total_size,
        sha256: hasher.finalize().to_vec(),
        analysis,
        thumbnails,
    })
}

/// Thumbnail tiers: (kind, max edge). Telegram Desktop uses s/m/x for
/// small, medium and large previews.
const THUMB_TIERS: [(&str, u32); 3] = [("s", 160), ("m", 320), ("x", 640)];

/// Generates all configured JPEG thumbnail tiers for an image file.
fn generate_thumbnails(media_dir: &Path, source: &Path) -> Result<Vec<Thumbnail>> {
    let image =
        image::open(source).with_context(|| format!("decode image {}", source.display()))?;
    let (source_width, source_height) = (image.width(), image.height());
    if source_width == 0 || source_height == 0 {
        bail!("image dimensions are zero");
    }
    let max_edge = source_width.max(source_height);
    let thumbs_dir = media_dir.join("thumbs");
    std::fs::create_dir_all(&thumbs_dir).context("create thumbnail directory")?;
    let mut thumbnails = Vec::with_capacity(THUMB_TIERS.len());
    for (kind, box_edge) in THUMB_TIERS {
        if box_edge > max_edge {
            continue;
        }
        let scaled = if max_edge > box_edge {
            image.resize(box_edge, box_edge, image::imageops::FilterType::Lanczos3)
        } else {
            image.clone()
        };
        thumbnails.push(write_thumbnail(media_dir, &scaled, kind)?);
    }
    if thumbnails.is_empty() {
        // Source is smaller than every tier; keep one preview at its own size.
        thumbnails.push(write_thumbnail(media_dir, &image, "s")?);
    }
    Ok(thumbnails)
}

/// Extracts a video frame with ffmpeg and generates thumbnail tiers from it.
/// ffmpeg comes from `TSRV_FFMPEG` or `PATH`; a missing binary is non-fatal.
fn generate_video_thumbnails(
    media_dir: &Path,
    source: &Path,
    duration: i32,
) -> Result<Vec<Thumbnail>> {
    let ffmpeg = std::env::var("TSRV_FFMPEG").unwrap_or_else(|_| "ffmpeg".to_owned());
    let thumbs_dir = media_dir.join("thumbs");
    std::fs::create_dir_all(&thumbs_dir).context("create thumbnail directory")?;
    let frame_path = thumbs_dir.join(format!("frame-{}.jpg", rand::random::<u64>()));
    let seek = if duration > 2 { "1" } else { "0" };
    let status = std::process::Command::new(&ffmpeg)
        .args(["-y", "-loglevel", "error", "-ss", seek, "-i"])
        .arg(source)
        .args(["-frames:v", "1", "-q:v", "2"])
        .arg(&frame_path)
        .status()
        .with_context(|| format!("run {ffmpeg} for {}", source.display()))?;
    let result = if status.success() {
        generate_thumbnails(media_dir, &frame_path)
    } else {
        bail!("ffmpeg exited with {status}");
    };
    let _ = std::fs::remove_file(&frame_path);
    result
}

/// Generates one JPEG preview for `upload.getFile` thumbnails.
fn write_thumbnail(media_dir: &Path, image: &image::DynamicImage, kind: &str) -> Result<Thumbnail> {
    let (width, height) = (image.width() as i32, image.height() as i32);
    if width == 0 || height == 0 {
        bail!("thumbnail dimensions are zero");
    }
    let mut name = rand::random::<i64>().to_string();
    if name.starts_with('-') {
        name.remove(0);
    }
    let storage_key = format!("thumbs/{name}-{kind}.jpg");
    let path = media_dir.join(&storage_key);
    let file = std::fs::File::create(&path)
        .with_context(|| format!("create thumbnail {}", path.display()))?;
    let mut encoder = image::codecs::jpeg::JpegEncoder::new_with_quality(file, 80);
    encoder
        .encode_image(image)
        .with_context(|| format!("encode thumbnail {}", path.display()))?;
    let size = std::fs::metadata(&path)
        .with_context(|| format!("stat thumbnail {}", path.display()))?
        .len() as i64;
    Ok(Thumbnail {
        kind: kind.to_owned(),
        storage_key,
        width,
        height,
        size,
    })
}

/// Hashes one byte range for `upload.getFileHashes`.
pub async fn hash_range(
    media_dir: &Path,
    storage_key: &str,
    offset: i64,
    limit: i64,
) -> Result<(i64, i32, Vec<u8>)> {
    let data = read_range(media_dir, storage_key, offset, limit).await?;
    let size = data.len() as i32;
    let hash = Sha256::digest(&data).to_vec();
    Ok((offset, size, hash))
}

/// Read a byte range from a stored media file for `upload.getFile`.
pub async fn read_range(
    media_dir: &Path,
    storage_key: &str,
    offset: i64,
    limit: i64,
) -> Result<Vec<u8>> {
    let path = resolve(media_dir, storage_key)?;
    let mut file = tokio::fs::File::open(&path)
        .await
        .with_context(|| format!("open media {}", path.display()))?;
    let length = file.metadata().await.context("stat media")?.len();
    if offset < 0 || offset as u64 >= length || limit <= 0 {
        return Ok(Vec::new());
    }
    file.seek(SeekFrom::Start(offset as u64))
        .await
        .context("seek media")?;
    let count = (length - offset as u64).min(limit as u64) as usize;
    let mut buffer = vec![0u8; count];
    file.read_exact(&mut buffer)
        .await
        .context("read media range")?;
    Ok(buffer)
}

pub fn storage_type(mime_type: &str, extension: &str) -> u32 {
    let mime = mime_type.to_ascii_lowercase();
    let extension = extension.to_ascii_lowercase();
    if mime == "image/jpeg" || matches!(extension.as_str(), "jpg" | "jpeg") {
        tsrv_tl::ctor::STORAGE_FILE_JPEG
    } else if mime == "image/png" || extension == "png" {
        tsrv_tl::ctor::STORAGE_FILE_PNG
    } else if mime == "video/mp4" || matches!(extension.as_str(), "mp4" | "m4v") {
        tsrv_tl::ctor::STORAGE_FILE_MP4
    } else {
        tsrv_tl::ctor::STORAGE_FILE_UNKNOWN
    }
}

pub fn analyze(head: &[u8], file_name: &str) -> FileAnalysis {
    if let Some((width, height)) = png_size(head) {
        return FileAnalysis {
            width,
            height,
            duration: 0,
            mime_type: "image/png".to_owned(),
            extension: "png".to_owned(),
            is_image: true,
            is_video: false,
        };
    }
    if let Some((width, height)) = jpeg_size(head) {
        return FileAnalysis {
            width,
            height,
            duration: 0,
            mime_type: "image/jpeg".to_owned(),
            extension: "jpg".to_owned(),
            is_image: true,
            is_video: false,
        };
    }
    if let Some((width, height, duration)) = mp4_info(head) {
        return FileAnalysis {
            width,
            height,
            duration,
            mime_type: "video/mp4".to_owned(),
            extension: "mp4".to_owned(),
            is_image: false,
            is_video: true,
        };
    }
    let extension = file_name
        .rsplit_once('.')
        .map(|(_, extension)| extension.to_ascii_lowercase())
        .filter(|extension| {
            !extension.is_empty()
                && extension.len() <= 5
                && extension
                    .chars()
                    .all(|character| character.is_ascii_alphanumeric())
        })
        .unwrap_or_default();
    FileAnalysis {
        width: 0,
        height: 0,
        duration: 0,
        mime_type: mime_from_extension(&extension).to_owned(),
        extension,
        is_image: false,
        is_video: false,
    }
}

/// Removes staged upload parts for an abandoned upload id.
pub async fn remove_upload_directory(media_dir: &Path, upload_id: i64) {
    let directory = media_dir.join("uploads").join(upload_id.to_string());
    match tokio::fs::remove_dir_all(&directory).await {
        Ok(()) => {}
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => {}
        Err(error) => {
            tracing::warn!(%error, path = %directory.display(), "remove upload directory failed");
        }
    }
}

fn resolve(media_dir: &Path, storage_key: &str) -> Result<PathBuf> {
    if storage_key.is_empty()
        || storage_key.starts_with('/')
        || storage_key.contains("..")
        || storage_key.contains(':')
        || storage_key.contains('\\')
    {
        bail!("invalid storage key {storage_key:?}");
    }
    Ok(media_dir.join(storage_key))
}

fn png_size(data: &[u8]) -> Option<(i32, i32)> {
    if data.len() < 24 || data[..8] != [0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a] {
        return None;
    }
    let width = u32::from_be_bytes(data[16..20].try_into().ok()?) as i32;
    let height = u32::from_be_bytes(data[20..24].try_into().ok()?) as i32;
    Some((width, height))
}

fn jpeg_size(data: &[u8]) -> Option<(i32, i32)> {
    if data.len() < 4 || data[0] != 0xff || data[1] != 0xd8 {
        return None;
    }
    let mut index = 2usize;
    while index + 9 < data.len() {
        if data[index] != 0xff {
            index += 1;
            continue;
        }
        let marker = data[index + 1];
        if marker == 0xd8 || marker == 0xd9 {
            index += 2;
            continue;
        }
        if marker == 0xda {
            return None;
        }
        let length = u16::from_be_bytes([data[index + 2], data[index + 3]]) as usize;
        let is_sof = matches!(
            marker,
            0xc0..=0xc3 | 0xc5..=0xc7 | 0xc9..=0xcb | 0xcd..=0xcf
        );
        if is_sof && index + 9 <= data.len() {
            let height = u16::from_be_bytes([data[index + 5], data[index + 6]]) as i32;
            let width = u16::from_be_bytes([data[index + 7], data[index + 8]]) as i32;
            if width > 0 && height > 0 {
                return Some((width, height));
            }
        }
        if length < 2 {
            return None;
        }
        index += 2 + length;
    }
    None
}

fn mp4_info(data: &[u8]) -> Option<(i32, i32, i32)> {
    if !data.starts_with(b"\x00\x00\x00") || data.len() < 12 {
        return None;
    }
    let has_ftyp = find_box(data, b"ftyp").is_some();
    let tkhd = find_box(data, b"tkhd")?;
    let (width, height) = {
        if tkhd.len() < 8 {
            return None;
        }
        let raw_width = u32::from_be_bytes(tkhd[tkhd.len() - 8..tkhd.len() - 4].try_into().ok()?);
        let raw_height = u32::from_be_bytes(tkhd[tkhd.len() - 4..].try_into().ok()?);
        ((raw_width >> 16) as i32, (raw_height >> 16) as i32)
    };
    let duration = find_box(data, b"mvhd")
        .and_then(|mvhd| {
            if mvhd.len() < 20 {
                return None;
            }
            let version = mvhd[0];
            if version == 1 {
                if mvhd.len() < 32 {
                    return None;
                }
                let timescale = u32::from_be_bytes(mvhd[20..24].try_into().ok()?);
                let duration = u64::from_be_bytes(mvhd[24..32].try_into().ok()?);
                (timescale > 0).then(|| (duration / u64::from(timescale)) as i32)
            } else {
                let timescale = u32::from_be_bytes(mvhd[12..16].try_into().ok()?);
                let duration = u32::from_be_bytes(mvhd[16..20].try_into().ok()?);
                (timescale > 0).then(|| (duration / timescale) as i32)
            }
        })
        .unwrap_or(0);
    if !has_ftyp && width == 0 && height == 0 {
        return None;
    }
    Some((width, height, duration))
}

fn find_box<'a>(data: &'a [u8], name: &[u8; 4]) -> Option<&'a [u8]> {
    let mut index = 0usize;
    while index + 8 <= data.len() {
        let size32 = u32::from_be_bytes(data[index..index + 4].try_into().ok()?) as usize;
        let kind = &data[index + 4..index + 8];
        let size = if size32 == 1 {
            if index + 16 > data.len() {
                return None;
            }
            u64::from_be_bytes(data[index + 8..index + 16].try_into().ok()?) as usize
        } else if size32 == 0 {
            data.len() - index
        } else {
            size32
        };
        if size < 8 || index + size > data.len() {
            return None;
        }
        if kind == name {
            return Some(&data[index + 8..index + size]);
        }
        if matches!(
            kind,
            b"moov" | b"trak" | b"mdia" | b"minf" | b"stbl" | b"edts" | b"udta"
        ) {
            if let Some(found) = find_box(&data[index + 8..index + size], name) {
                return Some(found);
            }
        }
        index += size;
    }
    None
}

fn mime_from_extension(extension: &str) -> &'static str {
    match extension {
        "jpg" | "jpeg" => "image/jpeg",
        "png" => "image/png",
        "gif" => "image/gif",
        "webp" => "image/webp",
        "mp4" | "m4v" => "video/mp4",
        "mov" => "video/quicktime",
        "mp3" => "audio/mpeg",
        "pdf" => "application/pdf",
        "txt" => "text/plain",
        "zip" => "application/zip",
        _ => "application/octet-stream",
    }
}

#[cfg(test)]
mod tests {
    use super::{analyze, generate_thumbnails, jpeg_size, mp4_info, png_size, storage_type};

    const PNG_1X1: &[u8] = &[
        0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x00, 0x00, 0x00, 0x0d, 0x49, 0x48, 0x44,
        0x52, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x01, 0x08, 0x06, 0x00, 0x00, 0x00, 0x1f,
        0x15, 0xc4, 0x89, 0x00, 0x00, 0x00, 0x0a, 0x49, 0x44, 0x41, 0x54, 0x78, 0x9c, 0x63, 0x00,
        0x01, 0x00, 0x00, 0x05, 0x00, 0x01, 0x0d, 0x0a, 0x2d, 0xb4, 0x00, 0x00, 0x00, 0x00, 0x49,
        0x45, 0x4e, 0x44, 0xae, 0x42, 0x60, 0x82,
    ];

    #[test]
    fn png_dimensions_are_detected() {
        assert_eq!(png_size(PNG_1X1), Some((1, 1)));
        let analysis = analyze(PNG_1X1, "pixel.png");
        assert_eq!(analysis.width, 1);
        assert_eq!(analysis.mime_type, "image/png");
        assert!(analysis.is_image);
    }

    #[test]
    fn thumbnail_generation_produces_jpeg() {
        let directory = std::env::temp_dir().join(format!("tsrv-thumb-{}", rand::random::<u64>()));
        std::fs::create_dir_all(&directory).unwrap();
        let source = directory.join("source.png");
        let image = image::RgbImage::from_fn(64, 32, |x, y| {
            image::Rgb([(x * 4) as u8, (y * 8) as u8, 0x80])
        });
        image.save(&source).unwrap();
        let thumbnails = generate_thumbnails(&directory, &source).unwrap();
        assert_eq!(thumbnails.len(), 1);
        let thumbnail = &thumbnails[0];
        assert_eq!(thumbnail.kind, "s");
        assert_eq!(thumbnail.width, 64);
        assert_eq!(thumbnail.height, 32);
        assert!(thumbnail.size > 0);
        let bytes = std::fs::read(directory.join(&thumbnail.storage_key)).unwrap();
        assert!(bytes.starts_with(&[0xff, 0xd8]));
        std::fs::remove_dir_all(directory).ok();
    }

    #[test]
    fn thumbnail_generation_builds_all_tiers() {
        let directory = std::env::temp_dir().join(format!("tsrv-tiers-{}", rand::random::<u64>()));
        std::fs::create_dir_all(&directory).unwrap();
        let source = directory.join("source.png");
        let image = image::RgbImage::from_fn(800, 600, |x, y| {
            image::Rgb([(x % 255) as u8, (y % 255) as u8, 0x40])
        });
        image.save(&source).unwrap();
        let thumbnails = generate_thumbnails(&directory, &source).unwrap();
        let kinds: Vec<&str> = thumbnails
            .iter()
            .map(|thumbnail| thumbnail.kind.as_str())
            .collect();
        assert_eq!(kinds, ["s", "m", "x"]);
        assert!(thumbnails[0].width <= 160);
        assert!(thumbnails[1].width <= 320);
        assert!(thumbnails[2].width <= 640);
        std::fs::remove_dir_all(directory).ok();
    }

    #[test]
    fn jpeg_dimensions_are_detected() {
        // SOI + APP0 + SOF0 with 2x3 in a 400 byte dummy payload.
        let mut data = vec![0xff, 0xd8, 0xff, 0xe0, 0x00, 0x10];
        data.extend_from_slice(&[0u8; 14]);
        data.extend_from_slice(&[0xff, 0xe0, 0x00, 0x10]);
        data.extend_from_slice(&[0u8; 14]);
        data.extend_from_slice(&[0xff, 0xe0, 0x00, 0x10]);
        data.extend_from_slice(&[0u8; 14]);
        data.extend_from_slice(&[0xff, 0xe0, 0x00, 0x10]);
        data.extend_from_slice(&[0u8; 14]);
        data.extend_from_slice(&[0xff, 0xc0, 0x00, 0x11, 0x08, 0x00, 0x03, 0x00, 0x02]);
        data.extend_from_slice(&[0u8; 64]);
        assert_eq!(jpeg_size(&data), Some((2, 3)));
    }

    #[test]
    fn mp4_dimensions_are_detected() {
        let mut data = Vec::new();
        data.extend_from_slice(&[0x00, 0x00, 0x00, 0x18]);
        data.extend_from_slice(b"ftyp");
        data.extend_from_slice(b"isom\x00\x00\x02\x00isomiso2");
        data.extend_from_slice(&[0x00, 0x00, 0x00, 0x20]);
        data.extend_from_slice(b"tkhd");
        data.extend_from_slice(&[0u8; 16]);
        data.extend_from_slice(&[0x02, 0x80, 0x00, 0x00, 0x01, 0xe0, 0x00, 0x00]);
        // mvhd (version 0): flags, create, modified, timescale, duration.
        data.extend_from_slice(&[0x00, 0x00, 0x00, 0x2c]);
        data.extend_from_slice(b"mvhd");
        data.extend_from_slice(&[0u8; 12]);
        data.extend_from_slice(&[0x00, 0x00, 0x03, 0xe8]); // timescale 1000
        data.extend_from_slice(&[0x00, 0x00, 0x03, 0xe8]); // duration 1000
        data.extend_from_slice(&[0u8; 16]);
        assert_eq!(mp4_info(&data), Some((640, 480, 1)));
    }

    #[test]
    fn storage_types_map_to_tl_constructors() {
        assert_eq!(
            storage_type("image/png", "png"),
            tsrv_tl::ctor::STORAGE_FILE_PNG
        );
        assert_eq!(
            storage_type("video/mp4", "mp4"),
            tsrv_tl::ctor::STORAGE_FILE_MP4
        );
        assert_eq!(
            storage_type("application/octet-stream", "bin"),
            tsrv_tl::ctor::STORAGE_FILE_UNKNOWN
        );
    }
}
