//! Encrypted MTProto message envelope.

use anyhow::{bail, Context, Result};
use rand::RngCore;

use crate::crypto::{auth_key_id, derive_keys, ige_decrypt, ige_encrypt, message_key, Side};
use tsrv_tl::{read_i64_le, Writer};

const HEADER_LENGTH: usize = 40;
const MAX_PADDING: usize = 1024;

#[derive(Debug, Clone)]
pub struct EncryptedMessage {
    pub salt: i64,
    pub session_id: i64,
    pub message_id: i64,
    pub seq_no: i32,
    pub body: Vec<u8>,
}

/// Reads the auth_key_id prefix without decrypting the packet.
pub fn peek_auth_key_id(packet: &[u8]) -> Option<i64> {
    if packet.len() < 8 {
        return None;
    }
    Some(read_i64_le(&packet[..8]))
}

#[allow(clippy::too_many_arguments)]
pub fn encrypt_packet(
    auth_key: &[u8],
    salt: i64,
    session_id: i64,
    message_id: i64,
    seq_no: i32,
    body: &[u8],
    sender: Side,
    random: &mut impl RngCore,
) -> Result<Vec<u8>> {
    if auth_key.len() != 256 {
        bail!("auth key must contain 256 bytes");
    }
    if !body.len().is_multiple_of(4) {
        bail!("message body is not 4-byte aligned");
    }

    let mut plaintext = Vec::with_capacity(HEADER_LENGTH + body.len() + 32);
    let mut header = Writer::new();
    header.i64(salt);
    header.i64(session_id);
    header.i64(message_id);
    header.i32(seq_no);
    header.i32(body.len() as i32);
    plaintext.extend_from_slice(header.as_bytes());
    plaintext.extend_from_slice(body);

    let mut padding = (16 - (plaintext.len() % 16)) % 16;
    if padding < 12 {
        padding += 16;
    }
    let padding_start = plaintext.len();
    plaintext.resize(padding_start + padding, 0);
    random.fill_bytes(&mut plaintext[padding_start..]);

    let msg_key = message_key(auth_key, &plaintext, sender);
    let (key, iv) = derive_keys(auth_key, &msg_key, sender);
    let encrypted = ige_encrypt(&key, &iv, &plaintext)?;

    let mut packet = Vec::with_capacity(8 + 16 + encrypted.len());
    packet.extend_from_slice(&auth_key_id(auth_key));
    packet.extend_from_slice(&msg_key);
    packet.extend_from_slice(&encrypted);
    Ok(packet)
}

pub fn decrypt_packet(auth_key: &[u8], packet: &[u8], sender: Side) -> Result<EncryptedMessage> {
    if auth_key.len() != 256 {
        bail!("auth key must contain 256 bytes");
    }
    if packet.len() < 8 + 16 + 16 {
        bail!("encrypted packet is too short");
    }
    let expected_id = auth_key_id(auth_key);
    if packet[..8] != expected_id {
        bail!("unknown auth_key_id in encrypted packet");
    }
    let mut msg_key = [0u8; 16];
    msg_key.copy_from_slice(&packet[8..24]);
    let encrypted = &packet[24..];
    if !encrypted.len().is_multiple_of(16) {
        bail!("encrypted payload is not 16-byte aligned");
    }
    let (key, iv) = derive_keys(auth_key, &msg_key, sender);
    let plaintext = ige_decrypt(&key, &iv, encrypted)?;
    let computed = message_key(auth_key, &plaintext, sender);
    if computed != msg_key {
        bail!("msg_key mismatch");
    }
    if plaintext.len() < HEADER_LENGTH {
        bail!("decrypted message is shorter than its header");
    }

    let mut reader = tsrv_tl::Reader::new(&plaintext);
    let salt = reader.i64()?;
    let session_id = reader.i64()?;
    let message_id = reader.i64()?;
    let seq_no = reader.i32()?;
    let body_length = reader.i32()?;
    if body_length < 0 {
        bail!("negative message length {body_length}");
    }
    let body_length = body_length as usize;
    if !body_length.is_multiple_of(4) {
        bail!("message length {body_length} is not divisible by 4");
    }
    let body = reader
        .raw(body_length)
        .context("message body exceeds decrypted payload")?
        .to_vec();
    let padding_length = plaintext.len() - HEADER_LENGTH - body_length;
    if padding_length > MAX_PADDING {
        bail!("message padding is too large: {padding_length}");
    }

    Ok(EncryptedMessage {
        salt,
        session_id,
        message_id,
        seq_no,
        body,
    })
}

#[cfg(test)]
mod tests {
    use super::{decrypt_packet, encrypt_packet};
    use crate::crypto::Side;
    use rand::rngs::OsRng;

    #[test]
    fn envelope_round_trip_for_both_sides() {
        let key = [42u8; 256];
        for sender in [Side::Client, Side::Server] {
            let body = vec![0u8; 16];
            let packet = encrypt_packet(&key, 123, 456, 789, 1, &body, sender, &mut OsRng).unwrap();
            let message = decrypt_packet(&key, &packet, sender).unwrap();
            assert_eq!(message.salt, 123);
            assert_eq!(message.session_id, 456);
            assert_eq!(message.message_id, 789);
            assert_eq!(message.seq_no, 1);
            assert_eq!(message.body, body);
        }
    }

    #[test]
    fn rejects_wrong_auth_key() {
        let key = [1u8; 256];
        let packet = encrypt_packet(&key, 0, 0, 0, 0, &[0u8; 8], Side::Server, &mut OsRng).unwrap();
        assert!(decrypt_packet(&[2u8; 256], &packet, Side::Server).is_err());
    }
}
