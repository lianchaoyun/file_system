//! MTProto 2.0 cryptography.
//!
//! The implementation follows the public MTProto specification and the
//! reference behavior used by gotd. Only the algorithms needed by the
//! experimental server and its smoke-test client live here.

use aes::cipher::generic_array::GenericArray;
use aes::cipher::{BlockDecrypt, BlockEncrypt, KeyInit};
use aes::{Aes256, Block};
use anyhow::{bail, Context, Result};
use rand::RngCore;
use rsa::traits::{PrivateKeyParts, PublicKeyParts};
use rsa::{BigUint, RsaPrivateKey};
use sha1::{Digest, Sha1};
use sha2::Sha256;

use tsrv_tl::{Int128, Int256};

pub const AUTH_KEY_SIZE: usize = 256;

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Side {
    Client,
    Server,
}

impl Side {
    fn offset(self) -> usize {
        match self {
            Self::Client => 0,
            Self::Server => 8,
        }
    }

    pub fn opposite(self) -> Self {
        match self {
            Self::Client => Self::Server,
            Self::Server => Self::Client,
        }
    }
}

fn sha1(data: &[u8]) -> [u8; 20] {
    let mut hasher = Sha1::new();
    hasher.update(data);
    let digest = hasher.finalize();
    let mut out = [0u8; 20];
    out.copy_from_slice(&digest);
    out
}

fn sha256(data: &[u8]) -> [u8; 32] {
    let mut hasher = Sha256::new();
    hasher.update(data);
    let digest = hasher.finalize();
    let mut out = [0u8; 32];
    out.copy_from_slice(&digest);
    out
}

/// Encrypts a block-aligned input with AES-256-IGE.
pub fn ige_encrypt(key: &[u8; 32], iv: &[u8; 32], source: &[u8]) -> Result<Vec<u8>> {
    if !source.len().is_multiple_of(16) {
        bail!("AES-IGE input length {} is not block aligned", source.len());
    }
    let cipher = Aes256::new(GenericArray::from_slice(key));
    let mut previous_cipher = [0u8; 16];
    let mut previous_plain = [0u8; 16];
    previous_cipher.copy_from_slice(&iv[..16]);
    previous_plain.copy_from_slice(&iv[16..]);
    let mut output = Vec::with_capacity(source.len());

    for chunk in source.chunks_exact(16) {
        let mut block = Block::clone_from_slice(chunk);
        for index in 0..16 {
            block[index] ^= previous_cipher[index];
        }
        cipher.encrypt_block(&mut block);
        for index in 0..16 {
            block[index] ^= previous_plain[index];
        }
        output.extend_from_slice(&block);
        previous_cipher.copy_from_slice(&block);
        previous_plain.copy_from_slice(chunk);
    }
    Ok(output)
}

/// Decrypts a block-aligned input with AES-256-IGE.
pub fn ige_decrypt(key: &[u8; 32], iv: &[u8; 32], source: &[u8]) -> Result<Vec<u8>> {
    if !source.len().is_multiple_of(16) {
        bail!("AES-IGE input length {} is not block aligned", source.len());
    }
    let cipher = Aes256::new(GenericArray::from_slice(key));
    let mut previous_cipher = [0u8; 16];
    let mut previous_plain = [0u8; 16];
    previous_cipher.copy_from_slice(&iv[..16]);
    previous_plain.copy_from_slice(&iv[16..]);
    let mut output = Vec::with_capacity(source.len());

    for chunk in source.chunks_exact(16) {
        let source_block = Block::clone_from_slice(chunk);
        let mut block = source_block;
        for index in 0..16 {
            block[index] ^= previous_plain[index];
        }
        cipher.decrypt_block(&mut block);
        for index in 0..16 {
            block[index] ^= previous_cipher[index];
        }
        output.extend_from_slice(&block);
        previous_cipher.copy_from_slice(&source_block);
        previous_plain.copy_from_slice(&block);
    }
    Ok(output)
}

/// Server RSA key, loaded from the existing telesrv private key.
#[derive(Clone)]
pub struct RsaKey {
    private: RsaPrivateKey,
    modulus: BigUint,
    exponent: BigUint,
    fingerprint: i64,
}

impl RsaKey {
    pub fn from_pkcs1_pem_file(path: &std::path::Path) -> Result<Self> {
        use rsa::pkcs1::DecodeRsaPrivateKey;
        let pem = std::fs::read_to_string(path)
            .with_context(|| format!("read RSA key {}", path.display()))?;
        let private = RsaPrivateKey::from_pkcs1_pem(&pem)
            .with_context(|| format!("parse PKCS#1 RSA key {}", path.display()))?;
        let modulus = private.n().clone();
        let exponent = private.e().clone();
        let fingerprint = rsa_fingerprint(&modulus, &exponent);
        Ok(Self {
            private,
            modulus,
            exponent,
            fingerprint,
        })
    }

    pub fn fingerprint(&self) -> i64 {
        self.fingerprint
    }

    /// Raw RSA private-key operation used by `req_DH_params`.
    pub fn decrypt(&self, encrypted: &[u8]) -> Result<Vec<u8>> {
        let value = BigUint::from_bytes_be(encrypted);
        if value >= self.modulus {
            bail!("encrypted RSA payload is larger than the modulus");
        }
        let plain = value.modpow(self.private.d(), &self.modulus);
        let mut bytes = plain.to_bytes_be();
        if bytes.len() > AUTH_KEY_SIZE {
            bail!("RSA plaintext does not fit into 256 bytes");
        }
        let mut result = vec![0u8; AUTH_KEY_SIZE];
        let offset = AUTH_KEY_SIZE - bytes.len();
        result[offset..].copy_from_slice(&bytes);
        bytes.clear();
        Ok(result)
    }

    /// Public-key operation used by the smoke-test client.
    pub fn encrypt_for_test(&self, value: &[u8]) -> Vec<u8> {
        let value = BigUint::from_bytes_be(value);
        let encrypted = value.modpow(&self.exponent, &self.modulus);
        let bytes = encrypted.to_bytes_be();
        let mut result = vec![0u8; AUTH_KEY_SIZE];
        let offset = AUTH_KEY_SIZE.saturating_sub(bytes.len());
        result[offset..].copy_from_slice(&bytes);
        result
    }

    pub fn public_modulus(&self) -> &BigUint {
        &self.modulus
    }

    pub fn public_exponent(&self) -> &BigUint {
        &self.exponent
    }
}

fn rsa_fingerprint(modulus: &BigUint, exponent: &BigUint) -> i64 {
    let mut writer = tsrv_tl::Writer::new();
    writer.bytes(&modulus.to_bytes_be());
    writer.bytes(&exponent.to_bytes_be());
    let hash = sha1(writer.as_bytes());
    i64::from_le_bytes(hash[12..20].try_into().expect("eight bytes"))
}

/// tmp_aes_key / tmp_aes_iv derived from `new_nonce` and `server_nonce`.
pub fn temp_aes_keys(new_nonce: &Int256, server_nonce: &Int128) -> ([u8; 32], [u8; 32]) {
    let mut new_server = Vec::with_capacity(48);
    new_server.extend_from_slice(new_nonce);
    new_server.extend_from_slice(server_nonce);
    let mut server_new = Vec::with_capacity(48);
    server_new.extend_from_slice(server_nonce);
    server_new.extend_from_slice(new_nonce);
    let hash_new_server = sha1(&new_server);
    let hash_server_new = sha1(&server_new);
    let mut new_new = Vec::with_capacity(64);
    new_new.extend_from_slice(new_nonce);
    new_new.extend_from_slice(new_nonce);
    let hash_new_new = sha1(&new_new);

    let mut key = [0u8; 32];
    key[..20].copy_from_slice(&hash_new_server);
    key[20..].copy_from_slice(&hash_server_new[..12]);

    let mut iv = [0u8; 32];
    iv[..8].copy_from_slice(&hash_server_new[12..20]);
    iv[8..28].copy_from_slice(&hash_new_new);
    iv[28..].copy_from_slice(&new_nonce[..4]);
    (key, iv)
}

/// Encrypts an exchange answer using SHA1(data) + data + random padding.
pub fn encrypt_exchange_answer(
    data: &[u8],
    new_nonce: &Int256,
    server_nonce: &Int128,
    random: &mut impl RngCore,
) -> Result<Vec<u8>> {
    let hash = sha1(data);
    let unpadded = 20 + data.len();
    let padding = (16 - (unpadded % 16)) % 16;
    let mut payload = Vec::with_capacity(unpadded + padding);
    payload.extend_from_slice(&hash);
    payload.extend_from_slice(data);
    payload.resize(unpadded + padding, 0);
    random.fill_bytes(&mut payload[unpadded..]);
    let (key, iv) = temp_aes_keys(new_nonce, server_nonce);
    ige_encrypt(&key, &iv, &payload)
}

/// Decrypts an exchange answer and validates the embedded SHA1 hash.
pub fn decrypt_exchange_answer(
    data: &[u8],
    new_nonce: &Int256,
    server_nonce: &Int128,
) -> Result<Vec<u8>> {
    let (key, iv) = temp_aes_keys(new_nonce, server_nonce);
    let decrypted = ige_decrypt(&key, &iv, data)?;
    if decrypted.len() < 20 {
        bail!("exchange answer is shorter than its hash");
    }
    let expected = &decrypted[..20];
    for padding in 0..16 {
        if decrypted.len() < 20 + padding {
            break;
        }
        let body = &decrypted[20..decrypted.len() - padding];
        if sha1(body).as_slice() == expected {
            return Ok(body.to_vec());
        }
    }
    bail!("exchange answer hash mismatch")
}

pub fn nonce_hash1(new_nonce: &Int256, auth_key: &[u8]) -> Int128 {
    let key_hash = sha1(auth_key);
    let mut payload = Vec::with_capacity(32 + 1 + 8);
    payload.extend_from_slice(new_nonce);
    payload.push(1);
    payload.extend_from_slice(&key_hash[..8]);
    let hash = sha1(&payload);
    let mut result = [0u8; 16];
    result.copy_from_slice(&hash[4..20]);
    result
}

pub fn server_salt(new_nonce: &Int256, server_nonce: &Int128) -> i64 {
    let mut salt = [0u8; 8];
    for index in 0..8 {
        salt[index] = new_nonce[index] ^ server_nonce[index];
    }
    i64::from_le_bytes(salt)
}

/// Decodes the RSA payload produced by `req_DH_params`.
///
/// Telegram does not use PKCS#1 v1.5 padding here. The RSA operation yields
/// `temp_key_xor(32) || aes_encrypted(224)`, which is decrypted with AES-IGE
/// and verified against `SHA256(temp_key || data_with_padding)`.
pub fn decode_rsa_pad(rsa: &RsaKey, encrypted: &[u8]) -> Result<Vec<u8>> {
    let mut decrypted = rsa.decrypt(encrypted)?;
    if decrypted.len() != AUTH_KEY_SIZE {
        bail!("unexpected RSA payload length");
    }
    let temp_key_xor = decrypted[..32].to_vec();
    let aes_encrypted = decrypted[32..].to_vec();

    let mut temp_key = [0u8; 32];
    let hash = sha256(&aes_encrypted);
    for index in 0..32 {
        temp_key[index] = temp_key_xor[index] ^ hash[index];
    }
    let zero_iv = [0u8; 32];
    let data_with_hash = ige_decrypt(&temp_key, &zero_iv, &aes_encrypted)?;

    let mut data_with_padding = data_with_hash[..192].to_vec();
    data_with_padding.reverse();
    let expected_hash = &data_with_hash[192..224];

    let mut hash_input = Vec::with_capacity(32 + data_with_padding.len());
    hash_input.extend_from_slice(&temp_key);
    hash_input.extend_from_slice(&data_with_padding);
    if sha256(&hash_input).as_slice() != expected_hash {
        bail!("RSA payload hash mismatch");
    }
    // The remaining bytes after the 144-byte data limit are random padding.
    if data_with_padding.len() < 144 {
        bail!("RSA payload is too short");
    }
    decrypted.clear();
    Ok(data_with_padding)
}

/// Encodes the matching `req_DH_params` RSA payload for the smoke-test client.
pub fn encode_rsa_pad(rsa: &RsaKey, data: &[u8], random: &mut impl RngCore) -> Result<Vec<u8>> {
    if data.len() > 144 {
        bail!("RSA data is longer than 144 bytes");
    }
    let mut data_with_padding = vec![0u8; 192];
    data_with_padding[..data.len()].copy_from_slice(data);
    random.fill_bytes(&mut data_with_padding[data.len()..]);
    let mut reversed = data_with_padding.clone();
    reversed.reverse();

    loop {
        let mut temp_key = [0u8; 32];
        random.fill_bytes(&mut temp_key);
        let mut hash_input = Vec::with_capacity(32 + data_with_padding.len());
        hash_input.extend_from_slice(&temp_key);
        hash_input.extend_from_slice(&data_with_padding);
        let hash = sha256(&hash_input);

        let mut data_with_hash = Vec::with_capacity(224);
        data_with_hash.extend_from_slice(&reversed);
        data_with_hash.extend_from_slice(&hash);
        debug_assert_eq!(data_with_hash.len(), 224);

        let zero_iv = [0u8; 32];
        let aes_encrypted = ige_encrypt(&temp_key, &zero_iv, &data_with_hash)?;
        let encrypted_hash = sha256(&aes_encrypted);
        let mut key_xor = [0u8; 32];
        for index in 0..32 {
            key_xor[index] = temp_key[index] ^ encrypted_hash[index];
        }
        let mut value = Vec::with_capacity(256);
        value.extend_from_slice(&key_xor);
        value.extend_from_slice(&aes_encrypted);
        let integer = BigUint::from_bytes_be(&value);
        if integer >= *rsa.public_modulus() {
            continue;
        }
        return Ok(rsa.encrypt_for_test(&value));
    }
}

pub fn auth_key_id(auth_key: &[u8]) -> [u8; 8] {
    let hash = sha1(auth_key);
    hash[12..20].try_into().expect("eight bytes")
}

pub fn auth_key_id_i64(auth_key: &[u8]) -> i64 {
    i64::from_le_bytes(auth_key_id(auth_key))
}

/// Computes `msg_key = substr(SHA256(auth_key[88+x..120+x] || data), 8, 16)`.
pub fn message_key(auth_key: &[u8], plaintext: &[u8], side: Side) -> Int128 {
    let offset = 88 + side.offset();
    let mut input = Vec::with_capacity(32 + plaintext.len());
    input.extend_from_slice(&auth_key[offset..offset + 32]);
    input.extend_from_slice(plaintext);
    let hash = sha256(&input);
    let mut key = [0u8; 16];
    key.copy_from_slice(&hash[8..24]);
    key
}

/// Derives the AES key and IV from `auth_key`, `msg_key` and side.
pub fn derive_keys(auth_key: &[u8], msg_key: &Int128, side: Side) -> ([u8; 32], [u8; 32]) {
    let x = side.offset();
    let mut a_input = Vec::with_capacity(52);
    a_input.extend_from_slice(msg_key);
    a_input.extend_from_slice(&auth_key[x..x + 36]);
    let sha_a = sha256(&a_input);

    let mut b_input = Vec::with_capacity(52);
    b_input.extend_from_slice(&auth_key[40 + x..76 + x]);
    b_input.extend_from_slice(msg_key);
    let sha_b = sha256(&b_input);

    let mut key = [0u8; 32];
    key[..8].copy_from_slice(&sha_a[..8]);
    key[8..24].copy_from_slice(&sha_b[8..24]);
    key[24..].copy_from_slice(&sha_a[24..32]);

    let mut iv = [0u8; 32];
    iv[..8].copy_from_slice(&sha_b[..8]);
    iv[8..24].copy_from_slice(&sha_a[8..24]);
    iv[24..].copy_from_slice(&sha_b[24..32]);
    (key, iv)
}

/// Old MTProto 1.0 key derivation, still used for `bind_auth_key_inner`.
pub fn derive_keys_oldmtp(auth_key: &[u8], msg_key: &Int128, side: Side) -> ([u8; 32], [u8; 32]) {
    let x = side.offset();
    let mut a_input = Vec::with_capacity(48);
    a_input.extend_from_slice(msg_key);
    a_input.extend_from_slice(&auth_key[x..x + 32]);
    let sha_a = sha1(&a_input);

    let mut b_input = Vec::with_capacity(48);
    b_input.extend_from_slice(&auth_key[32 + x..48 + x]);
    b_input.extend_from_slice(msg_key);
    b_input.extend_from_slice(&auth_key[48 + x..64 + x]);
    let sha_b = sha1(&b_input);

    let mut c_input = Vec::with_capacity(48);
    c_input.extend_from_slice(&auth_key[64 + x..96 + x]);
    c_input.extend_from_slice(msg_key);
    let sha_c = sha1(&c_input);

    let mut d_input = Vec::with_capacity(48);
    d_input.extend_from_slice(msg_key);
    d_input.extend_from_slice(&auth_key[96 + x..128 + x]);
    let sha_d = sha1(&d_input);

    let mut key = [0u8; 32];
    key[..8].copy_from_slice(&sha_a[..8]);
    key[8..20].copy_from_slice(&sha_b[8..20]);
    key[20..].copy_from_slice(&sha_c[4..16]);

    let mut iv = [0u8; 32];
    iv[..12].copy_from_slice(&sha_a[8..20]);
    iv[12..20].copy_from_slice(&sha_b[..8]);
    iv[20..24].copy_from_slice(&sha_c[16..20]);
    iv[24..].copy_from_slice(&sha_d[..8]);
    (key, iv)
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct BindAuthKeyInner {
    pub nonce: i64,
    pub temp_auth_key_id: i64,
    pub perm_auth_key_id: i64,
    pub temp_session_id: i64,
    pub expires_at: i32,
}

/// Decrypts the `auth.bindTempAuthKey.encrypted_message` payload.
///
/// The payload is an old-style MTProto message encrypted with the permanent
/// auth key: `auth_key_id(8) || msg_key(16) || AES-IGE(plaintext)`.
pub fn decrypt_bind_auth_key_inner(auth_key: &[u8], encrypted: &[u8]) -> Result<BindAuthKeyInner> {
    if auth_key.len() != AUTH_KEY_SIZE {
        bail!("auth key must contain {AUTH_KEY_SIZE} bytes");
    }
    if encrypted.len() < 24 + 16 || !(encrypted.len() - 24).is_multiple_of(16) {
        bail!("encrypted bind payload has an invalid length");
    }
    let header_id = i64::from_le_bytes(encrypted[..8].try_into().expect("eight bytes"));
    if header_id != auth_key_id_i64(auth_key) {
        bail!("encrypted bind payload names a different auth key");
    }
    let msg_key: Int128 = encrypted[8..24].try_into().expect("sixteen bytes");
    // Telegram uses the old-MTPS x=0 (client) key schedule for the bind
    // payload on both sides, unlike regular MTProto 1.0 messages.
    let (key, iv) = derive_keys_oldmtp(auth_key, &msg_key, Side::Client);
    let plaintext = ige_decrypt(&key, &iv, &encrypted[24..])?;
    if plaintext.len() < 32 {
        bail!("decrypted bind payload is too short");
    }
    let body_len = i32::from_le_bytes(plaintext[28..32].try_into().expect("four bytes"));
    if body_len < 40 || body_len % 4 != 0 {
        bail!("invalid bind payload body length {body_len}");
    }
    let unpadded = 32usize + body_len as usize;
    if unpadded > plaintext.len() {
        bail!("bind payload body exceeds the decrypted buffer");
    }
    if sha1(&plaintext[..unpadded])[4..20] != msg_key {
        bail!("bind payload msg_key mismatch");
    }

    let mut reader = tsrv_tl::Reader::new(&plaintext[32..unpadded]);
    if reader.constructor()? != tsrv_tl::ctor::BIND_AUTH_KEY_INNER {
        bail!("unexpected bind_auth_key_inner constructor");
    }
    Ok(BindAuthKeyInner {
        nonce: reader.i64()?,
        temp_auth_key_id: reader.i64()?,
        perm_auth_key_id: reader.i64()?,
        temp_session_id: reader.i64()?,
        expires_at: reader.i32()?,
    })
}

/// Encodes the matching `encrypted_message` for tests and the smoke client.
#[allow(clippy::too_many_arguments)]
pub fn encrypt_bind_auth_key_inner(
    auth_key: &[u8],
    inner: &BindAuthKeyInner,
    message_id: i64,
    random: &mut impl RngCore,
) -> Result<Vec<u8>> {
    if auth_key.len() != AUTH_KEY_SIZE {
        bail!("auth key must contain {AUTH_KEY_SIZE} bytes");
    }
    let mut writer = tsrv_tl::Writer::new();
    writer.u32(tsrv_tl::ctor::BIND_AUTH_KEY_INNER);
    writer.i64(inner.nonce);
    writer.i64(inner.temp_auth_key_id);
    writer.i64(inner.perm_auth_key_id);
    writer.i64(inner.temp_session_id);
    writer.i32(inner.expires_at);
    let body = writer.into_bytes();

    let mut plaintext = Vec::with_capacity(32 + body.len() + 16);
    let mut session_and_salt = [0u8; 16];
    random.fill_bytes(&mut session_and_salt);
    plaintext.extend_from_slice(&session_and_salt);
    plaintext.extend_from_slice(&message_id.to_le_bytes());
    plaintext.extend_from_slice(&0i32.to_le_bytes()); // seq_no
    plaintext.extend_from_slice(&(body.len() as i32).to_le_bytes());
    plaintext.extend_from_slice(&body);

    let unpadded = plaintext.len();
    let padding = (16 - (unpadded % 16)) % 16;
    plaintext.resize(unpadded + padding, 0);
    if padding > 0 {
        random.fill_bytes(&mut plaintext[unpadded..]);
    }

    let msg_key: Int128 = sha1(&plaintext[..unpadded])[4..20]
        .try_into()
        .expect("sixteen bytes");
    let (key, iv) = derive_keys_oldmtp(auth_key, &msg_key, Side::Client);
    let ciphertext = ige_encrypt(&key, &iv, &plaintext)?;
    let mut encrypted = Vec::with_capacity(24 + ciphertext.len());
    encrypted.extend_from_slice(&auth_key_id(auth_key));
    encrypted.extend_from_slice(&msg_key);
    encrypted.extend_from_slice(&ciphertext);
    Ok(encrypted)
}

pub fn random_int128(random: &mut impl RngCore) -> Int128 {
    let mut value = [0u8; 16];
    random.fill_bytes(&mut value);
    value
}

pub fn random_int256(random: &mut impl RngCore) -> Int256 {
    let mut value = [0u8; 32];
    random.fill_bytes(&mut value);
    value
}

#[cfg(test)]
mod tests {
    use super::{
        decrypt_bind_auth_key_inner, decrypt_exchange_answer, encrypt_bind_auth_key_inner,
        encrypt_exchange_answer, ige_decrypt, ige_encrypt, BindAuthKeyInner,
    };
    use rand::rngs::OsRng;

    /// A constant key would hide x=0/x=8 key-schedule mistakes because both
    /// slices of the auth key are identical. Use a non-uniform key instead.
    fn non_uniform_auth_key() -> [u8; 256] {
        let mut key = [0u8; 256];
        for (index, byte) in key.iter_mut().enumerate() {
            *byte = (index as u8).wrapping_mul(37).wrapping_add(11);
        }
        key
    }

    #[test]
    fn ige_round_trip() {
        let key = [7u8; 32];
        let iv = [9u8; 32];
        let plaintext: Vec<u8> = (0..64).collect();
        let encrypted = ige_encrypt(&key, &iv, &plaintext).unwrap();
        assert_eq!(ige_decrypt(&key, &iv, &encrypted).unwrap(), plaintext);
    }

    #[test]
    fn bind_auth_key_inner_round_trip() {
        let auth_key = non_uniform_auth_key();
        let inner = BindAuthKeyInner {
            nonce: 41,
            temp_auth_key_id: 42,
            perm_auth_key_id: 43,
            temp_session_id: 44,
            expires_at: 1_700_000_000,
        };
        let encrypted = encrypt_bind_auth_key_inner(&auth_key, &inner, 45, &mut OsRng).unwrap();
        assert_eq!(
            decrypt_bind_auth_key_inner(&auth_key, &encrypted).unwrap(),
            inner
        );
    }

    #[test]
    fn bind_auth_key_inner_rejects_tampering() {
        let auth_key = non_uniform_auth_key();
        let inner = BindAuthKeyInner {
            nonce: 1,
            temp_auth_key_id: 2,
            perm_auth_key_id: 3,
            temp_session_id: 4,
            expires_at: 5,
        };
        let mut encrypted = encrypt_bind_auth_key_inner(&auth_key, &inner, 6, &mut OsRng).unwrap();
        let last = encrypted.len() - 1;
        encrypted[last] ^= 0x80;
        assert!(decrypt_bind_auth_key_inner(&auth_key, &encrypted).is_err());
    }

    #[test]
    fn exchange_answer_round_trip() {
        let new_nonce = [3u8; 32];
        let server_nonce = [5u8; 16];
        let payload = vec![11u8; 137];
        let encrypted =
            encrypt_exchange_answer(&payload, &new_nonce, &server_nonce, &mut OsRng).unwrap();
        let decrypted = decrypt_exchange_answer(&encrypted, &new_nonce, &server_nonce).unwrap();
        assert_eq!(decrypted, payload);
    }
}
