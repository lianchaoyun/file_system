//! MTProto TCP transports.
//!
//! Clients may use a plain transport tag (abridged, intermediate or padded
//! intermediate) or the obfuscated transport used by Telegram Desktop. In the
//! obfuscated variant the first 56 bytes of the 64-byte header are plaintext
//! random bytes, while the last 8 bytes are AES-CTR encrypted and contain the
//! inner transport tag and DC id. All following frames are encrypted as well.

use aes::cipher::generic_array::GenericArray;
use aes::cipher::{BlockEncrypt, KeyInit};
use aes::{Aes256, Block};
use anyhow::{bail, Context, Result};
use rand::RngCore;
use tokio::io::{AsyncReadExt, AsyncWriteExt};
use tokio::net::TcpStream;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum TransportKind {
    Abridged,
    Intermediate,
    PaddedIntermediate,
}

impl TransportKind {
    pub fn as_str(self) -> &'static str {
        match self {
            Self::Abridged => "abridged",
            Self::Intermediate => "intermediate",
            Self::PaddedIntermediate => "padded-intermediate",
        }
    }

    fn from_tag(tag: &[u8]) -> Option<Self> {
        match tag {
            [0xef, 0xef, 0xef, 0xef] => Some(Self::Abridged),
            [0xee, 0xee, 0xee, 0xee] => Some(Self::Intermediate),
            [0xdd, 0xdd, 0xdd, 0xdd] => Some(Self::PaddedIntermediate),
            _ => None,
        }
    }
}

struct CtrStream {
    cipher: Aes256,
    counter: [u8; 16],
    keystream: [u8; 16],
    position: usize,
}

impl CtrStream {
    fn new(key: &[u8], iv: &[u8]) -> Result<Self> {
        if key.len() != 32 || iv.len() != 16 {
            bail!("obfuscated transport requires a 32-byte key and 16-byte IV");
        }
        let cipher = Aes256::new(GenericArray::from_slice(key));
        let mut counter = [0u8; 16];
        counter.copy_from_slice(iv);
        Ok(Self {
            cipher,
            counter,
            keystream: [0u8; 16],
            position: 16,
        })
    }

    fn apply(&mut self, data: &mut [u8]) {
        for byte in data.iter_mut() {
            if self.position == 16 {
                let mut block = Block::clone_from_slice(&self.counter);
                self.cipher.encrypt_block(&mut block);
                self.keystream.copy_from_slice(&block);
                for index in (0..16).rev() {
                    self.counter[index] = self.counter[index].wrapping_add(1);
                    if self.counter[index] != 0 {
                        break;
                    }
                }
                self.position = 0;
            }
            *byte ^= self.keystream[self.position];
            self.position += 1;
        }
    }
}

struct Obfuscation {
    read: CtrStream,
    write: CtrStream,
}

pub struct Transport {
    stream: TcpStream,
    kind: TransportKind,
    obfuscation: Option<Obfuscation>,
}

impl Transport {
    /// Creates the client side of a plain transport and writes its header.
    pub async fn connect(mut stream: TcpStream, kind: TransportKind) -> Result<Self> {
        let header = match kind {
            TransportKind::Abridged => [0xef, 0xef, 0xef, 0xef],
            TransportKind::Intermediate => [0xee, 0xee, 0xee, 0xee],
            TransportKind::PaddedIntermediate => [0xdd, 0xdd, 0xdd, 0xdd],
        };
        stream
            .write_all(&header)
            .await
            .context("write transport header")?;
        stream.flush().await.context("flush transport header")?;
        Ok(Self {
            stream,
            kind,
            obfuscation: None,
        })
    }

    pub async fn accept(mut stream: TcpStream) -> Result<Self> {
        let mut header = [0u8; 4];
        stream
            .read_exact(&mut header)
            .await
            .context("read transport header")?;
        if let Some(kind) = TransportKind::from_tag(&header) {
            return Ok(Self {
                stream,
                kind,
                obfuscation: None,
            });
        }
        Self::accept_obfuscated(stream, header).await
    }

    async fn accept_obfuscated(mut stream: TcpStream, header: [u8; 4]) -> Result<Self> {
        let mut full = [0u8; 64];
        full[..4].copy_from_slice(&header);
        stream
            .read_exact(&mut full[4..])
            .await
            .context("read obfuscated transport header")?;

        // Client -> server stream: key = header[8..40], IV = header[40..56].
        let mut read = CtrStream::new(&full[8..40], &full[40..56])?;
        let mut decoded = full;
        // The first 56 bytes stay plaintext; XOR over the full header advances
        // the stream to the position used by the encrypted protocol tag.
        read.apply(&mut decoded);
        let protocol = &decoded[56..60];
        let Some(kind) = TransportKind::from_tag(protocol) else {
            bail!("unsupported obfuscated transport tag {protocol:02x?}");
        };
        let dc_id = u16::from_le_bytes([decoded[60], decoded[61]]);

        // Server -> client stream: reverse of header[8..56].
        let mut reversed = full[8..56].to_vec();
        reversed.reverse();
        let write = CtrStream::new(&reversed[..32], &reversed[32..48])?;
        tracing::debug!(
            protocol = kind.as_str(),
            dc_id,
            "accepted obfuscated MTProto transport"
        );
        Ok(Self {
            stream,
            kind,
            obfuscation: Some(Obfuscation { read, write }),
        })
    }

    pub fn kind(&self) -> TransportKind {
        self.kind
    }

    pub fn is_obfuscated(&self) -> bool {
        self.obfuscation.is_some()
    }

    pub fn peer_addr(&self) -> std::io::Result<std::net::SocketAddr> {
        self.stream.peer_addr()
    }

    async fn read_decrypted(&mut self, count: usize) -> Result<Vec<u8>> {
        let mut buffer = vec![0u8; count];
        self.stream
            .read_exact(&mut buffer)
            .await
            .context("read transport bytes")?;
        if let Some(obfuscation) = &mut self.obfuscation {
            obfuscation.read.apply(&mut buffer);
        }
        Ok(buffer)
    }

    pub async fn read_packet(&mut self) -> Result<Vec<u8>> {
        let length = match self.kind {
            TransportKind::Abridged => self.read_abridged_length().await?,
            TransportKind::Intermediate | TransportKind::PaddedIntermediate => {
                let raw = self.read_decrypted(4).await?;
                let length = i32::from_le_bytes(raw.try_into().expect("four bytes"));
                if length < 0 {
                    bail!("negative packet length {length}");
                }
                length as usize
            }
        };
        tracing::trace!(
            kind = self.kind.as_str(),
            obfuscated = self.is_obfuscated(),
            length,
            "transport packet length"
        );
        if length == 0 {
            bail!("empty transport packet");
        }
        if length > 4 * 1024 * 1024 {
            bail!("transport packet is too large: {length}");
        }
        let mut payload = self.read_decrypted(length).await?;
        if self.kind == TransportKind::PaddedIntermediate {
            let padding = length % 4;
            payload.truncate(length - padding);
        }
        Ok(payload)
    }

    async fn read_abridged_length(&mut self) -> Result<usize> {
        let first = self.read_decrypted(1).await?[0];
        let quick_ack = first & 0x80 != 0;
        let mut words = u32::from(first & 0x7f);
        if words < 0x7f {
            if words == 0 {
                bail!("zero abridged packet length");
            }
        } else {
            let extended = self.read_decrypted(3).await?;
            words = u32::from_le_bytes([extended[0], extended[1], extended[2], 0]);
            if words < 0x7f {
                bail!("invalid abridged extended length {words}");
            }
        }
        if quick_ack {
            // The high bit asks for a quick acknowledgement. RPC replies are
            // written immediately, so no extra bookkeeping is needed.
            tracing::trace!("client requested quick ack");
        }
        Ok((words as usize) * 4)
    }

    pub async fn write_packet(&mut self, payload: &[u8]) -> Result<()> {
        if !payload.len().is_multiple_of(4) {
            bail!("outgoing payload is not 4-byte aligned");
        }
        let mut frame = Vec::with_capacity(payload.len() + 8);
        match self.kind {
            TransportKind::Abridged => {
                let words = (payload.len() / 4) as u32;
                if words < 0x7f {
                    frame.push(words as u8);
                } else {
                    let mut header = [0x7f, 0, 0, 0];
                    header[1..].copy_from_slice(&words.to_le_bytes()[..3]);
                    frame.extend_from_slice(&header);
                }
                frame.extend_from_slice(payload);
            }
            TransportKind::Intermediate => {
                frame.extend_from_slice(&(payload.len() as i32).to_le_bytes());
                frame.extend_from_slice(payload);
            }
            TransportKind::PaddedIntermediate => {
                let padding = (rand::thread_rng().next_u32() as usize) % 4;
                let total = payload.len() + padding;
                frame.extend_from_slice(&(total as i32).to_le_bytes());
                frame.extend_from_slice(payload);
                if padding > 0 {
                    let mut random = vec![0u8; padding];
                    rand::thread_rng().fill_bytes(&mut random);
                    frame.extend_from_slice(&random);
                }
            }
        }
        if let Some(obfuscation) = &mut self.obfuscation {
            obfuscation.write.apply(&mut frame);
        }
        self.stream
            .write_all(&frame)
            .await
            .context("write transport packet")?;
        self.stream
            .flush()
            .await
            .context("flush transport packet")?;
        Ok(())
    }

    pub async fn shutdown(&mut self) {
        let _ = self.stream.shutdown().await;
    }
}

#[cfg(test)]
mod tests {
    use super::{CtrStream, TransportKind};

    #[test]
    fn transport_names_are_stable() {
        assert_eq!(TransportKind::Abridged.as_str(), "abridged");
        assert_eq!(TransportKind::Intermediate.as_str(), "intermediate");
        assert_eq!(
            TransportKind::PaddedIntermediate.as_str(),
            "padded-intermediate"
        );
    }

    #[test]
    fn ctr_stream_round_trips() {
        let key = [3u8; 32];
        let iv = [7u8; 16];
        let plaintext: Vec<u8> = (0..97).collect();
        let mut first = CtrStream::new(&key, &iv).unwrap();
        let mut second = CtrStream::new(&key, &iv).unwrap();
        let mut encrypted = plaintext.clone();
        first.apply(&mut encrypted);
        assert_ne!(encrypted, plaintext);
        second.apply(&mut encrypted);
        assert_eq!(encrypted, plaintext);
    }
}
