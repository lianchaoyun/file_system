//! Server-side MTProto authorization-key exchange (`req_pq` -> `dh_gen_ok`).

use std::time::{SystemTime, UNIX_EPOCH};

use anyhow::{bail, Context, Result};
use rand::rngs::OsRng;
use rsa::BigUint;
use tsrv_tl::{exchange, types, Int128, Int256, Reader, UnencryptedMessage};

use crate::crypto::{
    auth_key_id_i64, decode_rsa_pad, decrypt_exchange_answer, encrypt_exchange_answer, nonce_hash1,
    random_int128, random_int256, server_salt, RsaKey, AUTH_KEY_SIZE,
};

const PQ: u64 = 0x17ED_4894_1A08_F981;
const G: i32 = 3;

const DH_PRIME_HEX: &str = concat!(
    "C71CAEB9C6B1C9048E6C522F70F13F73980D40238E3E21C14934D037563D930F",
    "48198A0AA7C14058229493D22530F4DBFA336F6E0AC925139543AED44CCE7C37",
    "20FD51F69458705AC68CD4FE6B6B13ABDC9746512969328454F18FAF8C595F64",
    "2477FE96BB2A941D5BCD1D4AC8CC49880708FA9B378E3C4F3A9060BEE67CF9A4",
    "A4A695811051907E162753B56B0F6B410DBA74D8A84B2A14B3144E0EF1284754",
    "FD17ED950D5965B4B9DD46582DB1178D169C6BC465B0D6FF9CA3928FEF5B9AE4",
    "E418FC15E83EBEA0F87FA9FF5EED70050DED2849F47BF959D956850CE929851F",
    "0D8115F635B105EE2E4E15D04B2454BF6F4FADF034B10403119CD8E3B92FCC5B"
);

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum MessageIdKind {
    Client,
    ServerResponse,
    Server,
}

impl MessageIdKind {
    fn yield_bits(self) -> i64 {
        match self {
            Self::Client => 0,
            Self::ServerResponse => 1,
            Self::Server => 3,
        }
    }
}

/// Generates monotonically increasing MTProto message ids.
#[derive(Debug, Default)]
pub struct MessageIdGen {
    last: i64,
}

impl MessageIdGen {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn next(&mut self, kind: MessageIdKind) -> i64 {
        let now = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap_or_default();
        let seconds = now.as_secs() as i64;
        let fraction = (now.subsec_nanos() as i64) & !3;
        let mut id = (seconds << 32) | (fraction | kind.yield_bits());
        if kind == MessageIdKind::Client && (id as u32) == 0 {
            id += 4;
        }
        if id <= self.last {
            id = self.last.saturating_add(4);
        }
        self.last = id;
        id
    }
}

#[derive(Debug, Clone)]
pub struct HandshakeAuthKey {
    pub value: [u8; AUTH_KEY_SIZE],
    pub id: i64,
    pub salt: i64,
    /// `0` for a permanent key, otherwise the absolute unix expiry derived
    /// from `p_q_inner_data_temp.expires_in`.
    pub expires_at: i64,
}

pub struct HandshakeResponse {
    pub reply: Vec<u8>,
    pub auth_key: Option<HandshakeAuthKey>,
    pub server_salt: i64,
}

pub struct ServerHandshake {
    rsa: RsaKey,
    message_ids: MessageIdGen,
    nonce: Option<Int128>,
    server_nonce: Option<Int128>,
    new_nonce: Option<Int256>,
    dh_a: Option<BigUint>,
    auth_key_expires_at: Option<i64>,
    dh_prime: BigUint,
}

impl ServerHandshake {
    pub fn new(rsa: RsaKey) -> Self {
        Self {
            rsa,
            message_ids: MessageIdGen::new(),
            nonce: None,
            server_nonce: None,
            new_nonce: None,
            dh_a: None,
            auth_key_expires_at: None,
            dh_prime: dh_prime(),
        }
    }

    pub fn handle(&mut self, packet: &[u8]) -> Result<HandshakeResponse> {
        let message = UnencryptedMessage::decode(packet).context("decode unencrypted message")?;
        if message.data.len() < 4 {
            bail!("unencrypted message is too short");
        }
        let mut reader = Reader::new(&message.data);
        let constructor = reader.constructor()?;
        tracing::debug!(
            constructor = format_args!("0x{constructor:08x}"),
            message_id = message.message_id,
            "unencrypted handshake message"
        );
        let body = match constructor {
            tsrv_tl::ctor::REQ_PQ | tsrv_tl::ctor::REQ_PQ_MULTI => {
                let nonce = reader.int128()?;
                self.begin(nonce)?
            }
            tsrv_tl::ctor::REQ_DH_PARAMS => {
                let nonce = reader.int128()?;
                let server_nonce = reader.int128()?;
                let p = reader.bytes()?;
                let q = reader.bytes()?;
                let fingerprint = reader.i64()?;
                let encrypted = reader.bytes()?;
                self.dh_params(nonce, server_nonce, &p, &q, fingerprint, &encrypted)?
            }
            tsrv_tl::ctor::SET_CLIENT_DH_PARAMS => {
                let nonce = reader.int128()?;
                let server_nonce = reader.int128()?;
                let encrypted = reader.bytes()?;
                return self.client_dh_params(nonce, server_nonce, &encrypted);
            }
            tsrv_tl::ctor::MSGS_ACK => {
                // Some clients flush queued acknowledgements before sending
                // req_pq on a fresh connection. They need no reply and must
                // not tear down the connection.
                tracing::debug!("ignoring unencrypted msgs_ack before handshake");
                return Ok(HandshakeResponse {
                    reply: Vec::new(),
                    auth_key: None,
                    server_salt: 0,
                });
            }
            other => bail!("unexpected unencrypted constructor 0x{other:08x}"),
        };
        Ok(HandshakeResponse {
            reply: self.reply(&body),
            auth_key: None,
            server_salt: 0,
        })
    }

    fn reply(&mut self, body: &[u8]) -> Vec<u8> {
        UnencryptedMessage {
            message_id: self.message_ids.next(MessageIdKind::ServerResponse),
            data: body.to_vec(),
        }
        .encode()
    }

    fn begin(&mut self, nonce: Int128) -> Result<Vec<u8>> {
        let server_nonce = random_int128(&mut OsRng);
        self.nonce = Some(nonce);
        self.server_nonce = Some(server_nonce);
        self.new_nonce = None;
        self.dh_a = None;
        self.auth_key_expires_at = None;
        let pq = PQ.to_be_bytes();
        Ok(types::res_pq(
            &nonce,
            &server_nonce,
            &pq,
            &[self.rsa.fingerprint()],
        ))
    }

    fn dh_params(
        &mut self,
        nonce: Int128,
        server_nonce: Int128,
        p: &[u8],
        q: &[u8],
        fingerprint: i64,
        encrypted: &[u8],
    ) -> Result<Vec<u8>> {
        if self.nonce != Some(nonce) || self.server_nonce != Some(server_nonce) {
            bail!("req_DH_params nonce does not match resPQ");
        }
        if fingerprint != self.rsa.fingerprint() {
            bail!("client used an unknown RSA key fingerprint");
        }

        let decrypted = decode_rsa_pad(&self.rsa, encrypted)?;
        let mut reader = Reader::new(&decrypted);
        let constructor = reader.constructor()?;
        let pq = reader.bytes()?;
        let inner_p = reader.bytes()?;
        let inner_q = reader.bytes()?;
        let inner_nonce = reader.int128()?;
        let inner_server_nonce = reader.int128()?;
        let new_nonce = reader.int256()?;
        // `p_q_inner_data_dc` and the temp variants append a dc id and/or
        // expires_in after new_nonce.
        let expires_at = match constructor {
            0x83c95aec => 0,
            0xa9f55f95 => {
                let _dc = reader.i32()?;
                0
            }
            0x3c6a84d4 => temporary_key_expiry(reader.i32()?)?,
            0x56fddf88 => {
                let _dc = reader.i32()?;
                temporary_key_expiry(reader.i32()?)?
            }
            other => bail!("unexpected p_q_inner_data constructor 0x{other:08x}"),
        };

        if inner_nonce != nonce || inner_server_nonce != server_nonce {
            bail!("p_q_inner_data nonce mismatch");
        }
        if inner_p != p || inner_q != q {
            bail!("req_DH_params p/q does not match the RSA payload");
        }
        let expected_pq = BigUint::from_bytes_be(&pq);
        let actual_pq = BigUint::from_bytes_be(&inner_p) * BigUint::from_bytes_be(&inner_q);
        if expected_pq != actual_pq {
            bail!("p*q does not equal pq");
        }

        self.new_nonce = Some(new_nonce);
        self.auth_key_expires_at = Some(expires_at);
        let a = random_scalar(&self.dh_prime);
        let g_a = BigUint::from(G as u32).modpow(&a, &self.dh_prime);
        self.dh_a = Some(a);
        let server_time = unix_time() as i32;
        let inner = exchange::server_dh_inner_data(
            &nonce,
            &server_nonce,
            G,
            &self.dh_prime.to_bytes_be(),
            &g_a.to_bytes_be(),
            server_time,
        );
        let encrypted_answer =
            encrypt_exchange_answer(&inner, &new_nonce, &server_nonce, &mut OsRng)?;
        Ok(types::server_dh_params_ok(
            &nonce,
            &server_nonce,
            &encrypted_answer,
        ))
    }

    fn client_dh_params(
        &mut self,
        nonce: Int128,
        server_nonce: Int128,
        encrypted: &[u8],
    ) -> Result<HandshakeResponse> {
        if self.nonce != Some(nonce) || self.server_nonce != Some(server_nonce) {
            bail!("set_client_DH_params nonce mismatch");
        }
        let new_nonce = self
            .new_nonce
            .context("set_client_DH_params before req_DH_params")?;
        let a = self
            .dh_a
            .take()
            .context("set_client_DH_params without a server DH secret")?;

        let decrypted = decrypt_exchange_answer(encrypted, &new_nonce, &server_nonce)?;
        let mut reader = Reader::new(&decrypted);
        reader.expect_constructor(0x6643b654)?;
        let inner_nonce = reader.int128()?;
        let inner_server_nonce = reader.int128()?;
        let _retry_id = reader.i64()?;
        let g_b = reader.bytes()?;
        if inner_nonce != nonce || inner_server_nonce != server_nonce {
            bail!("client_DH_inner_data nonce mismatch");
        }

        let g_b = BigUint::from_bytes_be(&g_b);
        let shared = g_b.modpow(&a, &self.dh_prime);
        let mut auth_key = [0u8; AUTH_KEY_SIZE];
        let shared_bytes = shared.to_bytes_be();
        if shared_bytes.len() > AUTH_KEY_SIZE {
            bail!("DH shared secret does not fit into 256 bytes");
        }
        auth_key[AUTH_KEY_SIZE - shared_bytes.len()..].copy_from_slice(&shared_bytes);

        let hash1 = nonce_hash1(&new_nonce, &auth_key);
        let salt = server_salt(&new_nonce, &server_nonce);
        let expires_at = self
            .auth_key_expires_at
            .take()
            .context("set_client_DH_params without a key expiry")?;
        let reply = self.reply(&types::dh_gen_ok(&nonce, &server_nonce, &hash1));
        Ok(HandshakeResponse {
            reply,
            auth_key: Some(HandshakeAuthKey {
                value: auth_key,
                id: auth_key_id_i64(&auth_key),
                salt,
                expires_at,
            }),
            server_salt: salt,
        })
    }
}

/// Validates the client-requested lifetime of a temporary auth key and turns
/// it into an absolute unix timestamp.
fn temporary_key_expiry(expires_in: i32) -> Result<i64> {
    const MAX_TEMP_KEY_LIFETIME: i32 = 7 * 86_400;
    if !(1..=MAX_TEMP_KEY_LIFETIME).contains(&expires_in) {
        bail!("temporary auth key lifetime {expires_in} is out of range");
    }
    Ok(unix_time() as i64 + i64::from(expires_in))
}

fn random_scalar(prime: &BigUint) -> BigUint {
    // A 256-bit random exponent is well inside the safe range required by
    // MTProto and avoids modulo bias in the outer range.
    loop {
        let value = BigUint::from_bytes_be(&random_int256(&mut OsRng));
        if value > BigUint::from(1u32) && value < *prime {
            return value;
        }
    }
}

fn unix_time() -> u64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap_or_default()
        .as_secs()
}

fn dh_prime() -> BigUint {
    let mut bytes = Vec::with_capacity(DH_PRIME_HEX.len() / 2);
    let chars: Vec<char> = DH_PRIME_HEX.chars().collect();
    for pair in chars.chunks(2) {
        let high = pair[0].to_digit(16).expect("valid DH prime hex") as u8;
        let low = pair[1].to_digit(16).expect("valid DH prime hex") as u8;
        bytes.push((high << 4) | low);
    }
    BigUint::from_bytes_be(&bytes)
}

#[cfg(test)]
mod tests {
    use super::{dh_prime, DH_PRIME_HEX};

    #[test]
    fn dh_prime_is_2048_bits() {
        let prime = dh_prime();
        assert_eq!(prime.bits(), 2048);
        assert_eq!(DH_PRIME_HEX.len(), 512);
    }
}
