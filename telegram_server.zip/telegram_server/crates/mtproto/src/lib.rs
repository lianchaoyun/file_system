//! MTProto transport, auth-key exchange and encrypted envelopes.

pub mod crypto;
pub mod envelope;
pub mod handshake;
pub mod transport;

pub const TRANSPORT_ABRIDGED: &str = "abridged";
pub const TRANSPORT_INTERMEDIATE: &str = "intermediate";
pub const TRANSPORT_PADDED_INTERMEDIATE: &str = "padded-intermediate";
