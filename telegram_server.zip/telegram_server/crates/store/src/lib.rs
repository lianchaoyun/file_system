//! PostgreSQL and Redis access for the experimental server.
//!
//! PostgreSQL is the durable source of truth. Redis only stores expiring
//! auth codes, rate-limit counters and rebuildable session caches.

use anyhow::{bail, Context, Result};
use redis::aio::ConnectionManager;
use sqlx::postgres::PgPoolOptions;
use sqlx::{Executor, PgPool};

pub const REDIS_PREFIX: &str = "tsrv";

#[derive(Clone)]
pub struct Db {
    pool: PgPool,
}

impl Db {
    pub async fn connect(dsn: &str, schema: &str) -> Result<Self> {
        validate_schema(schema)?;
        let schema = schema.to_owned();
        let pool = PgPoolOptions::new()
            .max_connections(8)
            .after_connect(move |connection, _| {
                let schema = schema.clone();
                Box::pin(async move {
                    // The schema name is validated before interpolation. It
                    // cannot be bound as a normal SQL parameter.
                    let statement = format!("SET search_path TO \"{schema}\", public");
                    connection.execute(statement.as_str()).await?;
                    Ok(())
                })
            })
            .connect(dsn)
            .await
            .context("connect PostgreSQL")?;
        Ok(Self { pool })
    }

    pub async fn ping(&self) -> Result<()> {
        sqlx::query("SELECT 1")
            .execute(&self.pool)
            .await
            .context("PostgreSQL ping")?;
        Ok(())
    }

    pub fn pool(&self) -> &PgPool {
        &self.pool
    }
}

#[derive(Clone)]
pub struct Cache {
    manager: ConnectionManager,
}

impl Cache {
    pub async fn connect(url: &str) -> Result<Self> {
        let client = redis::Client::open(url).context("open Redis URL")?;
        let manager = ConnectionManager::new(client)
            .await
            .context("connect Redis")?;
        Ok(Self { manager })
    }

    pub async fn ping(&self) -> Result<()> {
        let mut connection = self.manager.clone();
        let pong: String = redis::cmd("PING")
            .query_async(&mut connection)
            .await
            .context("Redis ping")?;
        if pong != "PONG" {
            bail!("unexpected Redis PING reply: {pong}");
        }
        Ok(())
    }

    pub async fn set_ex(&self, key: &str, value: &str, seconds: u64) -> Result<()> {
        let mut connection = self.manager.clone();
        redis::cmd("SETEX")
            .arg(key)
            .arg(seconds)
            .arg(value)
            .query_async::<()>(&mut connection)
            .await
            .with_context(|| format!("set Redis key {key}"))?;
        Ok(())
    }

    pub async fn get(&self, key: &str) -> Result<Option<String>> {
        let mut connection = self.manager.clone();
        redis::cmd("GET")
            .arg(key)
            .query_async(&mut connection)
            .await
            .with_context(|| format!("get Redis key {key}"))
    }

    pub async fn del(&self, key: &str) -> Result<()> {
        let mut connection = self.manager.clone();
        redis::cmd("DEL")
            .arg(key)
            .query_async::<()>(&mut connection)
            .await
            .with_context(|| format!("delete Redis key {key}"))?;
        Ok(())
    }
}

/// PostgreSQL identifiers used as schema names are restricted to a safe
/// subset before being interpolated into `SET search_path`.
pub fn validate_schema(schema: &str) -> Result<()> {
    if schema.is_empty() || schema.len() > 63 {
        bail!("database schema must be 1..=63 characters");
    }
    let mut characters = schema.chars();
    let first = characters.next().expect("non-empty schema");
    if !(first.is_ascii_alphabetic() || first == '_') {
        bail!("database schema must start with a letter or underscore");
    }
    if !characters.all(|character| character.is_ascii_alphanumeric() || character == '_') {
        bail!("database schema contains invalid characters");
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::validate_schema;

    #[test]
    fn accepts_dev_and_test_schemas() {
        assert!(validate_schema("dev").is_ok());
        assert!(validate_schema("test").is_ok());
        assert!(validate_schema("game_chat_2").is_ok());
        assert!(validate_schema("public").is_ok());
    }

    #[test]
    fn rejects_unsafe_schema_names() {
        assert!(validate_schema("").is_err());
        assert!(validate_schema("dev;drop schema public").is_err());
        assert!(validate_schema("dev-test").is_err());
        assert!(validate_schema("1dev").is_err());
    }
}
