//! Telegram TL types for the subset of Layer 232 implemented by this server.
//!
//! The crate intentionally contains no networking or storage dependencies. It
//! owns the binary primitives, constructor ids and the unencrypted / container
//! envelopes that are shared by the server and the smoke-test client.

use std::fmt;

pub const TL_LAYER: i32 = 232;

pub type Int128 = [u8; 16];
pub type Int256 = [u8; 32];

/// TL constructor ids used by the implemented subset.
pub mod ctor {
    pub const VECTOR: u32 = 0x1cb5c415;
    pub const BOOL_FALSE: u32 = 0xbc799737;
    pub const BOOL_TRUE: u32 = 0x997275b5;

    pub const REQ_PQ: u32 = 0x60469778;
    pub const REQ_PQ_MULTI: u32 = 0xbe7e8ef1;
    pub const RES_PQ: u32 = 0x05162463;
    pub const REQ_DH_PARAMS: u32 = 0xd712e4be;
    pub const SERVER_DH_PARAMS_OK: u32 = 0xd0e8075c;
    pub const SERVER_DH_PARAMS_FAIL: u32 = 0x79cb045d;
    pub const SET_CLIENT_DH_PARAMS: u32 = 0xf5045f1f;
    pub const DH_GEN_OK: u32 = 0x3bcbf734;
    pub const DH_GEN_RETRY: u32 = 0x46dc1fb9;
    pub const DH_GEN_FAIL: u32 = 0xa69dae02;

    pub const MSG_CONTAINER: u32 = 0x73f1f8dc;
    pub const MSGS_ACK: u32 = 0x62d6b459;
    pub const MSGS_STATE_REQ: u32 = 0xda69fb52;
    pub const GZIP_PACKED: u32 = 0x3072cfa1;
    pub const RPC_RESULT: u32 = 0xf35c6d01;
    pub const RPC_ERROR: u32 = 0x2144ca19;
    pub const NEW_SESSION_CREATED: u32 = 0x9ec20908;
    pub const PONG: u32 = 0x347773c5;
    pub const PING: u32 = 0x7abe77ec;
    pub const PING_DELAY_DISCONNECT: u32 = 0xf3427b8c;
    pub const DESTROY_SESSION: u32 = 0xe7512126;
    pub const DESTROY_SESSION_NONE: u32 = 0x62d350c9;
    pub const BIND_AUTH_KEY_INNER: u32 = 0x75a3f765;

    pub const INVOKE_WITH_LAYER: u32 = 0xda9b0d0d;
    pub const INVOKE_WITHOUT_UPDATES: u32 = 0xbf9459b7;
    pub const INVOKE_WITH_MESSAGES_RANGE: u32 = 0x365275f2;
    pub const INVOKE_WITH_TAKEOUT: u32 = 0xaca9fd2e;
    pub const INIT_CONNECTION: u32 = 0xc1cd5ea9;

    pub const AUTH_SEND_CODE: u32 = 0xa677244f;
    pub const AUTH_SIGN_IN: u32 = 0x8d52a951;
    pub const AUTH_SIGN_UP: u32 = 0xaac7b717;
    pub const AUTH_BIND_TEMP_AUTH_KEY: u32 = 0xcdd42a05;
    pub const AUTH_LOG_OUT: u32 = 0x3e72ba19;
    pub const AUTH_RESET_AUTHORIZATIONS: u32 = 0x9fab0d1a;
    pub const AUTH_EXPORT_AUTHORIZATION: u32 = 0xe5bfffcd;
    pub const AUTH_IMPORT_AUTHORIZATION: u32 = 0xa57a7dad;
    pub const AUTH_EXPORT_LOGIN_TOKEN: u32 = 0xb7e085fe;
    pub const AUTH_IMPORT_LOGIN_TOKEN: u32 = 0x95ac5ce4;
    pub const AUTH_LOGIN_TOKEN: u32 = 0x629f1980;
    pub const AUTH_LOGIN_TOKEN_SUCCESS: u32 = 0x390d5c5e;
    pub const AUTH_CHECK_PASSWORD: u32 = 0xd18b4d16;
    pub const AUTH_IMPORT_BOT_AUTHORIZATION: u32 = 0x67a3d90d;

    pub const MESSAGES_GET_BOT_CALLBACK_ANSWER: u32 = 0x9342ca07;

    pub const INPUT_CHECK_PASSWORD_EMPTY: u32 = 0x9880f658;
    pub const INPUT_CHECK_PASSWORD_SRP: u32 = 0xd27ff082;

    pub const AUTH_SENT_CODE: u32 = 0x5e002502;
    pub const AUTH_SENT_CODE_TYPE_APP: u32 = 0x3dbb5986;
    pub const AUTH_AUTHORIZATION: u32 = 0x2ea2c0d4;
    pub const AUTH_AUTHORIZATION_SIGN_UP_REQUIRED: u32 = 0x44747e9a;

    pub const USER_EMPTY: u32 = 0xd3bc4b7a;
    pub const USER: u32 = 0xb1b8cc83;
    pub const USER_STATUS_RECENTLY: u32 = 0x7b197dc8;
    pub const USER_STATUS_ONLINE: u32 = 0xedb93949;
    pub const USER_STATUS_OFFLINE: u32 = 0x008c703f;
    pub const UPDATE_USER_STATUS: u32 = 0xe5bdf8de;
    pub const UPDATE_USER_TYPING: u32 = 0x2a17bf5c;
    pub const UPDATE_CHAT_USER_TYPING: u32 = 0x83487af0;
    pub const UPDATE_CHANNEL_USER_TYPING: u32 = 0x8c88c923;
    pub const UPDATE_READ_HISTORY_INBOX: u32 = 0x9e84bc99;
    pub const UPDATE_READ_HISTORY_OUTBOX: u32 = 0x2f2f21bf;
    pub const UPDATE_READ_CHANNEL_INBOX: u32 = 0x922e6e10;
    pub const UPDATE_READ_CHANNEL_OUTBOX: u32 = 0xb75f99a9;

    pub const SEND_MESSAGE_TYPING_ACTION: u32 = 0x16bf744e;
    pub const SEND_MESSAGE_CANCEL_ACTION: u32 = 0xfd5ec8f5;
    pub const SEND_MESSAGE_RECORD_VIDEO_ACTION: u32 = 0xa187d66f;
    pub const SEND_MESSAGE_UPLOAD_VIDEO_ACTION: u32 = 0xe9763aec;
    pub const SEND_MESSAGE_RECORD_AUDIO_ACTION: u32 = 0xd52f73f7;
    pub const SEND_MESSAGE_UPLOAD_AUDIO_ACTION: u32 = 0xf351d7ab;
    pub const SEND_MESSAGE_UPLOAD_PHOTO_ACTION: u32 = 0xd1d34a26;
    pub const SEND_MESSAGE_UPLOAD_DOCUMENT_ACTION: u32 = 0xaa0cd9e4;
    pub const SEND_MESSAGE_GEO_LOCATION_ACTION: u32 = 0x176f8ba1;
    pub const SEND_MESSAGE_CHOOSE_CONTACT_ACTION: u32 = 0x628cbc6f;
    pub const SEND_MESSAGE_GAME_PLAY_ACTION: u32 = 0xdd6a8f48;
    pub const SEND_MESSAGE_RECORD_ROUND_ACTION: u32 = 0x88f27fbc;
    pub const SEND_MESSAGE_UPLOAD_ROUND_ACTION: u32 = 0x243e1c66;
    pub const SPEAKING_IN_GROUP_CALL_ACTION: u32 = 0xd92c2285;
    pub const SEND_MESSAGE_CHOOSE_STICKER_ACTION: u32 = 0xb05ac6b1;

    pub const INPUT_USER_SELF: u32 = 0xf7c1b13f;
    pub const INPUT_USER: u32 = 0xf21158c6;
    pub const USERS_GET_USERS: u32 = 0x0d91a548;
    pub const USERS_GET_FULL_USER: u32 = 0xb60f5918;
    pub const CONTACTS_GET_CONTACTS: u32 = 0x5dd69e12;
    pub const CONTACTS_SEARCH: u32 = 0x05f58d0f;
    pub const CONTACTS_FOUND: u32 = 0xb3134d9d;
    pub const CONTACTS_RESOLVE_USERNAME: u32 = 0x725afbbc;
    pub const CONTACTS_CONTACT: u32 = 0x145ade0b;
    pub const CONTACTS_RESOLVED_PEER: u32 = 0x7f077ad9;
    pub const CONTACTS_ADD_CONTACT: u32 = 0xd9ba2e54;
    pub const CONTACTS_DELETE_CONTACTS: u32 = 0x096a0e00;
    pub const CONTACTS_BLOCK: u32 = 0x2e2e8734;
    pub const CONTACTS_UNBLOCK: u32 = 0xb550d328;
    pub const PEER_BLOCKED: u32 = 0xe8fd8014;

    pub const INPUT_PEER_SELF: u32 = 0x7da07ec9;
    pub const INPUT_PEER_USER: u32 = 0xdde8a54c;
    pub const INPUT_PEER_CHAT: u32 = 0x35a95cb9;
    pub const INPUT_PEER_CHANNEL: u32 = 0x27bcbbfc;
    pub const INPUT_CHANNEL: u32 = 0xf35aec28;
    pub const INPUT_FILE: u32 = 0xf52ff27f;
    pub const INPUT_FILE_BIG: u32 = 0xfa4f0bb5;
    pub const INPUT_FILE_LOCATION: u32 = 0xdfdaabe1;
    pub const INPUT_DOCUMENT_FILE_LOCATION: u32 = 0xbad07584;
    pub const INPUT_PHOTO_FILE_LOCATION: u32 = 0x40181ffe;
    pub const INPUT_PEER_PHOTO_FILE_LOCATION: u32 = 0x37257e99;
    pub const INPUT_MEDIA_UPLOADED_PHOTO: u32 = 0x7d8375da;
    pub const INPUT_MEDIA_UPLOADED_DOCUMENT: u32 = 0x37c9330;
    pub const INPUT_MEDIA_PHOTO: u32 = 0xe3af4434;
    pub const INPUT_MEDIA_DOCUMENT: u32 = 0xa8763ab5;
    pub const INPUT_MEDIA_EMPTY: u32 = 0x9664f57f;
    pub const INPUT_MEDIA_POLL: u32 = 0x883a4108;
    pub const INPUT_MEDIA_GEO_POINT: u32 = 0xf9c44144;
    pub const INPUT_MEDIA_CONTACT: u32 = 0xf8ab7dfb;
    pub const INPUT_MEDIA_DICE: u32 = 0xe66fbf7b;
    pub const INPUT_GEO_POINT: u32 = 0x48222faf;
    pub const PEER_USER: u32 = 0x59511722;
    pub const PEER_CHAT: u32 = 0x36c6019a;
    pub const PEER_CHANNEL: u32 = 0xa2a5371e;
    pub const CHAT_FULL: u32 = 0x2633421b;
    pub const CHAT_PARTICIPANTS: u32 = 0x3cbc93f8;
    pub const CHAT_PARTICIPANT: u32 = 0x38e79fde;
    pub const CHAT_PARTICIPANT_CREATOR: u32 = 0xe1f867b8;
    pub const INPUT_PEER_EMPTY: u32 = 0x7f3b18ea;
    pub const MESSAGES_CREATE_CHAT: u32 = 0x92ceddd4;
    pub const MESSAGES_CHATS: u32 = 0x64ff9fd5;
    pub const MESSAGES_GET_CHATS: u32 = 0x49e9528f;
    pub const MESSAGES_GET_FULL_CHAT: u32 = 0xaeb00b34;
    pub const MESSAGES_ADD_CHAT_USER: u32 = 0xcbc6d107;
    pub const MESSAGES_DELETE_CHAT_USER: u32 = 0xa2185cab;
    pub const MESSAGES_EDIT_CHAT_TITLE: u32 = 0x73783ffd;
    pub const MESSAGES_UNPIN_ALL_MESSAGES: u32 = 0x062dd747;
    pub const MESSAGES_DELETE_HISTORY: u32 = 0xb08f922a;
    pub const MESSAGES_DELETE_CHAT: u32 = 0x5bd0ee50;
    pub const MESSAGES_AFFECTED_HISTORY: u32 = 0xb45c69d1;
    pub const UPDATE_CHAT_PARTICIPANTS: u32 = 0x07761198;
    pub const UPDATE_MESSAGE_REACTIONS: u32 = 0x1e297bfa;
    pub const MESSAGES_SEND_REACTION: u32 = 0xd30d78d4;
    pub const MESSAGES_SEND_SCHEDULED_MESSAGES: u32 = 0xbd38850a;
    pub const MESSAGES_DELETE_SCHEDULED_MESSAGES: u32 = 0x59ae2b16;
    pub const UPDATE_NEW_SCHEDULED_MESSAGE: u32 = 0x39a51dfb;
    pub const UPDATE_DELETE_SCHEDULED_MESSAGES: u32 = 0xf2a71983;
    pub const MESSAGES_EDIT_CHAT_PHOTO: u32 = 0x35ddd674;
    pub const CHANNELS_EDIT_PHOTO: u32 = 0xf12e57c9;
    pub const INPUT_CHAT_UPLOADED_PHOTO: u32 = 0xbdcdaec0;
    pub const INPUT_CHAT_PHOTO: u32 = 0x8953ad37;
    pub const INPUT_CHAT_PHOTO_EMPTY: u32 = 0x1ca48f57;
    pub const MESSAGE_REACTIONS: u32 = 0x0a339f0b;
    pub const REACTION_COUNT: u32 = 0xa3d1cb80;
    pub const REACTION_EMOJI: u32 = 0x1b2286b8;
    pub const REACTION_CUSTOM_EMOJI: u32 = 0x8935fc73;

    pub const MESSAGE: u32 = 0x7600b9d3;
    pub const DIALOG: u32 = 0xfc89f7f3;
    pub const MESSAGE_MEDIA_PHOTO: u32 = 0xe216eb63;
    pub const MESSAGE_MEDIA_DOCUMENT: u32 = 0x52d8ccd9;
    pub const MESSAGE_MEDIA_POLL: u32 = 0x773f4e66;
    pub const MESSAGE_MEDIA_GEO: u32 = 0x56e0d474;
    pub const MESSAGE_MEDIA_CONTACT: u32 = 0x70322949;
    pub const MESSAGE_MEDIA_DICE: u32 = 0x08cbec07;
    pub const POLL: u32 = 0x966e2dbf;
    pub const POLL_ANSWER: u32 = 0x4b7d786a;
    pub const POLL_RESULTS: u32 = 0xba7bb15e;
    pub const POLL_ANSWER_VOTERS: u32 = 0x3645230a;
    pub const GEO_POINT: u32 = 0xb2a2f663;
    pub const UPDATE_MESSAGE_POLL: u32 = 0xd64c522b;
    pub const MESSAGES_SEND_VOTE: u32 = 0x10ea6184;
    pub const MESSAGES_GET_POLL_RESULTS: u32 = 0xeda3e33b;
    pub const MESSAGE_REPLY_HEADER: u32 = 0xddb5ab75;
    pub const MESSAGE_FWD_HEADER: u32 = 0x4e4df4bb;
    pub const MESSAGE_SERVICE: u32 = 0x7a800e0a;
    pub const MESSAGE_ACTION_PIN_MESSAGE: u32 = 0x94bd38ed;
    pub const MESSAGE_ACTION_CHAT_CREATE: u32 = 0xbd47cbad;
    pub const MESSAGE_ACTION_CHAT_EDIT_TITLE: u32 = 0xb5a1ce5a;
    pub const MESSAGE_ACTION_CHAT_ADD_USER: u32 = 0x15cefd00;
    pub const MESSAGE_ACTION_CHAT_DELETE_USER: u32 = 0xa43f30cc;
    pub const PHOTO: u32 = 0xfb197a65;
    pub const PHOTO_SIZE: u32 = 0x75c78e60;
    pub const DOCUMENT: u32 = 0x8fd4c4d8;
    pub const DOCUMENT_ATTRIBUTE_FILENAME: u32 = 0x15590068;
    pub const DOCUMENT_ATTRIBUTE_VIDEO: u32 = 0x43c57c48;
    pub const DOCUMENT_ATTRIBUTE_IMAGE_SIZE: u32 = 0x6c37c15c;
    pub const DOCUMENT_ATTRIBUTE_ANIMATED: u32 = 0x11b58939;
    pub const DOCUMENT_ATTRIBUTE_AUDIO: u32 = 0x9852f9c6;
    pub const CHAT: u32 = 0x41cbf256;
    pub const CHANNEL: u32 = 0x7ad15240;
    pub const CHAT_PHOTO_EMPTY: u32 = 0x37c1011c;
    pub const CHAT_PHOTO: u32 = 0x1c6e1c11;
    pub const PHOTO_EMPTY: u32 = 0x2331b22d;
    pub const CHANNEL_FULL: u32 = 0xc4c4dd40;
    pub const MESSAGES_CHAT_FULL: u32 = 0xe5d7d19c;

    pub const PEER_SETTINGS: u32 = 0xf47741f7;
    pub const PEER_NOTIFY_SETTINGS: u32 = 0x99622c0c;
    pub const USER_PROFILE_PHOTO: u32 = 0x82d1f706;
    pub const PHOTOS_UPLOAD_PROFILE_PHOTO: u32 = 0x0388a3b5;
    pub const PHOTOS_UPDATE_PROFILE_PHOTO: u32 = 0x09e82039;
    pub const PHOTOS_PHOTO: u32 = 0x20212ca8;
    pub const PHOTOS_PHOTOS: u32 = 0x8dca6aa5;
    pub const PHOTOS_GET_USER_PHOTOS: u32 = 0x91cd32a8;
    pub const USER_FULL: u32 = 0xb90c2afd;
    pub const USERS_USER_FULL: u32 = 0x3b6d152e;

    pub const CONTACTS_CONTACTS: u32 = 0xeae87e42;
    pub const MESSAGES_GET_DIALOGS: u32 = 0xa0f4cb4f;
    pub const MESSAGES_GET_PEER_DIALOGS: u32 = 0xe470bcfd;
    pub const MESSAGES_GET_PINNED_DIALOGS: u32 = 0xd6b94df2;
    pub const MESSAGES_SAVE_DRAFT: u32 = 0xad0fa15c;
    pub const MESSAGES_GET_ALL_DRAFTS: u32 = 0x6a3f8d65;
    pub const MESSAGES_TOGGLE_DIALOG_PIN: u32 = 0xa731e257;
    pub const MESSAGES_REORDER_PINNED_DIALOGS: u32 = 0x3b1adf37;
    pub const MESSAGES_UPDATE_DIALOG_FILTER: u32 = 0x1ad4a04a;
    pub const DRAFT_MESSAGE: u32 = 0x60fe3294;
    pub const UPDATE_DRAFT_MESSAGE: u32 = 0xedfc111e;
    pub const DRAFT_MESSAGE_EMPTY: u32 = 0x1b0c841a;
    pub const INPUT_DIALOG_PEER: u32 = 0xfcaafeb7;
    pub const INPUT_DIALOG_PEER_FOLDER: u32 = 0x64600527;
    pub const TEXT_WITH_ENTITIES: u32 = 0x751f3146;
    pub const INPUT_REPLY_TO_MESSAGE: u32 = 0x75c1ad70;
    pub const INPUT_REPLY_TO_STORY: u32 = 0x5881323a;
    pub const DIALOG_FILTER: u32 = 0xaa472651;
    pub const MESSAGES_PEER_DIALOGS: u32 = 0x3371c354;
    pub const MESSAGES_DIALOGS: u32 = 0x15ba6c40;
    pub const MESSAGES_DIALOGS_NOT_MODIFIED: u32 = 0xf0e3e596;
    pub const MESSAGES_DIALOGS_SLICE: u32 = 0x71e094f3;
    pub const MESSAGES_MESSAGES: u32 = 0x1d73e7ea;
    pub const MESSAGES_GET_HISTORY: u32 = 0x4423e6c5;
    pub const MESSAGES_SEND_MESSAGE: u32 = 0xfef48f62;
    pub const MESSAGES_SEND_MEDIA: u32 = 0x0330e77f;
    pub const MESSAGES_SEND_MULTI_MEDIA: u32 = 0x1bf89d74;
    pub const INPUT_SINGLE_MEDIA: u32 = 0x1cc6e91f;
    pub const INPUT_QUICK_REPLY_SHORTCUT: u32 = 0x24596d41;
    pub const MESSAGES_EDIT_MESSAGE: u32 = 0xb106e66c;
    pub const MESSAGES_DELETE_MESSAGES: u32 = 0xe58e95d2;
    pub const MESSAGES_FORWARD_MESSAGES: u32 = 0x13704a7c;
    pub const MESSAGES_UPDATE_PINNED_MESSAGE: u32 = 0xd2aaf7ec;
    pub const MESSAGES_GET_MESSAGES: u32 = 0x63c66506;
    pub const CHANNELS_DELETE_MESSAGES: u32 = 0x84c1fd4e;
    pub const CHANNELS_GET_MESSAGES: u32 = 0xad8c9a23;
    pub const FILE_HASH: u32 = 0xf39b035c;
    pub const MESSAGES_UPLOAD_MEDIA: u32 = 0x14967978;
    pub const MESSAGES_READ_HISTORY: u32 = 0xe306d3a;
    pub const MESSAGES_AFFECTED_MESSAGES: u32 = 0x84d19185;
    pub const INPUT_MESSAGE_ID: u32 = 0xa676a322;
    pub const MESSAGES_GET_STICKERS: u32 = 0xd5a5d3a1;
    pub const MESSAGES_STICKERS: u32 = 0x30a6ec7e;
    pub const MESSAGES_GET_STICKER_SET: u32 = 0xc8a0ec74;
    pub const MESSAGES_STICKER_SET: u32 = 0x6e153f16;
    pub const STICKER_SET: u32 = 0x2dd14edc;
    pub const STICKER_PACK: u32 = 0x12b299d4;
    pub const INPUT_STICKER_SET_EMPTY: u32 = 0xffb62b95;
    pub const INPUT_STICKER_SET_ID: u32 = 0x9de7a269;
    pub const INPUT_STICKER_SET_SHORT_NAME: u32 = 0x861cc8a0;
    pub const DOCUMENT_ATTRIBUTE_STICKER: u32 = 0x6319d612;
    pub const DOCUMENT_ATTRIBUTE_CUSTOM_EMOJI: u32 = 0xfd149899;
    pub const MESSAGES_GET_CUSTOM_EMOJI_DOCUMENTS: u32 = 0xd9ab0f54;
    pub const ACCOUNT_UPDATE_EMOJI_STATUS: u32 = 0xfbd3de6b;
    pub const ACCOUNT_GET_RECENT_EMOJI_STATUSES: u32 = 0x0f578105;
    pub const EMOJI_STATUS: u32 = 0xe7ff068a;
    pub const UPDATE_USER_EMOJI_STATUS: u32 = 0x28373599;
    pub const MESSAGES_GET_FEATURED_STICKERS: u32 = 0x64780b14;
    pub const MESSAGES_FEATURED_STICKERS_NOT_MODIFIED: u32 = 0xc6dc0c66;
    pub const MESSAGES_GET_PEER_SETTINGS: u32 = 0xefd9a6a2;
    pub const MESSAGES_PEER_SETTINGS: u32 = 0x6880b94d;
    pub const MESSAGES_GET_DIALOG_FILTERS: u32 = 0xefd48c89;
    pub const MESSAGES_DIALOG_FILTERS: u32 = 0x2ad93719;
    pub const MESSAGES_GET_AVAILABLE_REACTIONS: u32 = 0x18dea0ac;
    pub const MESSAGES_AVAILABLE_REACTIONS_NOT_MODIFIED: u32 = 0x9f071957;
    pub const MESSAGES_GET_ATTACH_MENU_BOTS: u32 = 0x16fcc2cb;
    pub const ATTACH_MENU_BOTS_NOT_MODIFIED: u32 = 0xf1d88a5c;
    pub const MESSAGES_GET_EMOJI_GROUPS: u32 = 0x7488ce5b;
    pub const MESSAGES_GET_EMOJI_STICKER_GROUPS: u32 = 0x1dd840f5;
    pub const MESSAGES_EMOJI_GROUPS_NOT_MODIFIED: u32 = 0x6fb4ad87;
    pub const MESSAGES_GET_QUICK_REPLIES: u32 = 0xd483f2a8;
    pub const MESSAGES_QUICK_REPLIES_NOT_MODIFIED: u32 = 0x5f91eb5b;
    pub const MESSAGES_GET_SCHEDULED_HISTORY: u32 = 0xf516760b;
    pub const MESSAGES_SEARCH: u32 = 0x29ee847a;
    pub const MESSAGES_SEARCH_GLOBAL: u32 = 0x6126a43c;
    pub const ACCOUNT_GET_NOTIFY_SETTINGS: u32 = 0x12b3ad31;
    pub const ACCOUNT_GET_REACTIONS_NOTIFY_SETTINGS: u32 = 0x06dd654c;
    pub const ACCOUNT_SET_REACTIONS_NOTIFY_SETTINGS: u32 = 0x316ce548;
    pub const REACTIONS_NOTIFY_SETTINGS: u32 = 0x71e4ea58;
    pub const REACTION_NOTIFICATIONS_FROM_ALL: u32 = 0x4b9e22a0;
    pub const REACTION_NOTIFICATIONS_FROM_CONTACTS: u32 = 0xbac3a61a;
    pub const NOTIFICATION_SOUND_DEFAULT: u32 = 0x97e8bebe;
    pub const NOTIFICATION_SOUND_NONE: u32 = 0x6f0c34df;
    pub const NOTIFICATION_SOUND_LOCAL: u32 = 0x830b9ae4;
    pub const NOTIFICATION_SOUND_RINGTONE: u32 = 0xff6c8049;
    pub const ACCOUNT_GET_DEFAULT_EMOJI_STATUSES: u32 = 0xd6753386;
    pub const ACCOUNT_EMOJI_STATUSES_NOT_MODIFIED: u32 = 0xd08ce645;
    pub const ACCOUNT_GET_THEMES: u32 = 0x7206e458;
    pub const ACCOUNT_THEMES_NOT_MODIFIED: u32 = 0xf41eb622;
    pub const MESSAGES_GET_FEATURED_EMOJI_STICKERS: u32 = 0x0ecf6736;
    pub const CONTACTS_GET_TOP_PEERS: u32 = 0x973478b6;
    pub const CONTACTS_TOP_PEERS_NOT_MODIFIED: u32 = 0xde266ef5;
    pub const HELP_GET_PEER_COLORS: u32 = 0xda80f42f;
    pub const HELP_GET_PEER_PROFILE_COLORS: u32 = 0xabcfa9fd;
    pub const HELP_PEER_COLORS_NOT_MODIFIED: u32 = 0x2ba1f5ce;
    pub const HELP_GET_COUNTRIES_LIST: u32 = 0x735787a8;
    pub const HELP_COUNTRIES_LIST_NOT_MODIFIED: u32 = 0x93cc1f32;
    pub const HELP_GET_PROMO_DATA: u32 = 0xc0977421;
    pub const HELP_PROMO_DATA_EMPTY: u32 = 0x98f6ac75;
    pub const MESSAGES_CHAT_INVITE_JOIN_RESULT_OK: u32 = 0x445663a7;
    pub const MESSAGES_INVITED_USERS: u32 = 0x7f5defa6;
    pub const CHANNELS_CREATE_CHANNEL: u32 = 0x91006707;
    pub const CHANNELS_JOIN_CHANNEL: u32 = 0x7f6a1e22;
    pub const CHANNELS_LEAVE_CHANNEL: u32 = 0xf836aa95;
    pub const CHANNELS_INVITE_TO_CHANNEL: u32 = 0xc9e33d54;
    pub const CHANNELS_GET_FULL_CHANNEL: u32 = 0x08736a09;
    pub const CHANNELS_GET_PARTICIPANTS: u32 = 0x77ced9d0;
    pub const CHANNELS_CHANNEL_PARTICIPANTS: u32 = 0x9ab0feaf;
    pub const CHANNELS_EDIT_ADMIN: u32 = 0x9a98ad68;
    pub const CHANNELS_EDIT_BANNED: u32 = 0x96e6cd81;
    pub const CHANNELS_UPDATE_USERNAME: u32 = 0x3514b3de;
    pub const CHANNEL_PARTICIPANT: u32 = 0x1bd54456;
    pub const CHANNEL_PARTICIPANT_ADMIN: u32 = 0x34c3bb53;
    pub const CHANNEL_PARTICIPANT_CREATOR: u32 = 0x2fe601d3;
    pub const CHANNEL_PARTICIPANT_BANNED: u32 = 0xd5f0ad91;
    pub const CHANNEL_PARTICIPANTS_RECENT: u32 = 0xde3f3c79;
    pub const CHANNEL_PARTICIPANTS_ADMINS: u32 = 0xb4608969;
    pub const CHAT_ADMIN_RIGHTS: u32 = 0x5fb224d5;
    pub const CHAT_BANNED_RIGHTS: u32 = 0x9f120418;
    pub const CHAT_INVITE: u32 = 0x5c9d3702;
    pub const CHAT_INVITE_ALREADY: u32 = 0x5a686d7c;
    pub const MESSAGES_CHECK_CHAT_INVITE: u32 = 0x3eadb1bb;
    pub const MESSAGES_IMPORT_CHAT_INVITE: u32 = 0xde91436e;
    pub const ACCOUNT_CHECK_USERNAME: u32 = 0x2714d86c;
    pub const ACCOUNT_UPDATE_USERNAME: u32 = 0x3e0bdd7c;
    pub const ACCOUNT_UPDATE_BIRTHDAY: u32 = 0xcc6e0c11;
    pub const BIRTHDAY: u32 = 0x6c8e1e06;
    pub const UPLOAD_SAVE_FILE_PART: u32 = 0xb304a621;
    pub const UPLOAD_SAVE_BIG_FILE_PART: u32 = 0xde7b673d;
    pub const UPLOAD_GET_FILE: u32 = 0xbe5335be;
    pub const UPLOAD_GET_FILE_HASHES: u32 = 0x9156982a;
    pub const UPLOAD_FILE: u32 = 0x096a18d5;
    pub const STORAGE_FILE_UNKNOWN: u32 = 0xaa963b05;
    pub const STORAGE_FILE_JPEG: u32 = 0x007efe0e;
    pub const STORAGE_FILE_PNG: u32 = 0x00a4f63c;
    pub const STORAGE_FILE_MP4: u32 = 0xb3cea0e4;
    pub const STORIES_GET_ALL_STORIES: u32 = 0xeeb0d625;
    pub const STORIES_ALL_STORIES: u32 = 0x6efc5e81;
    pub const STORIES_STEALTH_MODE: u32 = 0x712e27fd;
    pub const HELP_GET_PREMIUM_PROMO: u32 = 0xb81b93d4;
    pub const HELP_PREMIUM_PROMO: u32 = 0x5334759c;

    pub const UPDATES_STATE: u32 = 0xa56c2a3e;
    pub const UPDATES_DIFFERENCE_EMPTY: u32 = 0x5d75a138;
    pub const UPDATES_DIFFERENCE: u32 = 0xf49ca0;
    pub const UPDATES_DIFFERENCE_SLICE: u32 = 0xa8fb1981;
    pub const UPDATES_DIFFERENCE_TOO_LONG: u32 = 0x4afe8f6d;
    pub const UPDATES_CHANNEL_DIFFERENCE: u32 = 0x2064674e;
    pub const UPDATES_CHANNEL_DIFFERENCE_EMPTY: u32 = 0x3e11affb;
    pub const UPDATES_CHANNEL_DIFFERENCE_TOO_LONG: u32 = 0xa4bcc6fe;
    pub const UPDATES_GET_STATE: u32 = 0xedd4882a;
    pub const UPDATES_GET_DIFFERENCE: u32 = 0x19c2f763;
    pub const UPDATES_GET_DIFFERENCE_LEGACY: u32 = 0x2593962d;
    pub const UPDATES_GET_CHANNEL_DIFFERENCE: u32 = 0x03173d78;
    pub const UPDATES: u32 = 0x74ae4240;
    pub const UPDATE_NEW_MESSAGE: u32 = 0x1f2b0afd;
    pub const UPDATE_USER: u32 = 0x20529438;
    pub const UPDATE_NEW_CHANNEL_MESSAGE: u32 = 0x62ba04d9;
    pub const UPDATE_CHANNEL: u32 = 0x635b4c09;
    pub const UPDATE_MESSAGE_ID: u32 = 0x4e90bfd6;
    pub const UPDATE_EDIT_MESSAGE: u32 = 0xe40370a3;
    pub const UPDATE_EDIT_CHANNEL_MESSAGE: u32 = 0x1b3f4df7;
    pub const UPDATE_DELETE_MESSAGES: u32 = 0xa20db0e5;
    pub const UPDATE_DELETE_CHANNEL_MESSAGES: u32 = 0xc32d5b12;
    pub const UPDATE_PINNED_MESSAGES: u32 = 0xed85eab5;
    pub const UPDATE_PINNED_CHANNEL_MESSAGES: u32 = 0x5bb98608;

    pub const HELP_GET_CONFIG: u32 = 0xc4f9186b;
    pub const HELP_GET_NEAREST_DC: u32 = 0x1fb33026;
    pub const HELP_GET_APP_CONFIG: u32 = 0x61e3f854;
    pub const HELP_GET_INVITE_TEXT: u32 = 0x4d392343;
    pub const HELP_GET_SUPPORT: u32 = 0x9cdf08cd;
    pub const HELP_GET_TERMS_OF_SERVICE_UPDATE: u32 = 0x2ca51fd1;
    pub const HELP_CONFIG: u32 = 0xcc1a241e;
    pub const HELP_NEAREST_DC: u32 = 0x8e1a1775;
    pub const HELP_APP_CONFIG_NOT_MODIFIED: u32 = 0x7cde641d;
    pub const HELP_INVITE_TEXT: u32 = 0x18cb9f78;
    pub const HELP_SUPPORT: u32 = 0x17c6b5f6;
    pub const HELP_TERMS_OF_SERVICE_UPDATE_EMPTY: u32 = 0xe3309f7f;
    pub const DC_OPTION: u32 = 0x18b7a10d;

    pub const ACCOUNT_AUTHORIZATIONS: u32 = 0x4bff8ea0;
    pub const AUTHORIZATION: u32 = 0xad01d61d;
    pub const ACCOUNT_RESET_AUTHORIZATION: u32 = 0xdf77f3bc;

    pub const LANG_PACK_GET_LANG_PACK: u32 = 0xf2f2330a;
    pub const LANG_PACK_GET_STRINGS: u32 = 0xefea3803;
    pub const LANG_PACK_GET_LANGUAGES: u32 = 0x42c6978f;
    pub const LANG_PACK_GET_LANGUAGES_ALT: u32 = 0x800fd57d;
    pub const LANG_PACK_GET_LANGUAGE: u32 = 0x6a596502;
    pub const LANG_PACK_GET_DIFFERENCE: u32 = 0xcd984aa5;
    pub const LANG_PACK_DIFFERENCE: u32 = 0xf385c1f6;
    pub const LANG_PACK_LANGUAGE: u32 = 0xeeca5ce3;
    pub const LANG_PACK_STRING: u32 = 0xcad181f6;
    pub const LANG_PACK_STRING_PLURALIZED: u32 = 0x6c47ac9f;

    pub const ACCOUNT_GET_AUTHORIZATIONS: u32 = 0xe320c158;
    pub const ACCOUNT_UPDATE_PROFILE: u32 = 0x78515775;
    pub const ACCOUNT_UPDATE_STATUS: u32 = 0x6628562c;

    pub const ACCOUNT_GET_PASSWORD: u32 = 0x548a30f5;
    pub const ACCOUNT_GET_CONTACT_SIGN_UP_NOTIFICATION: u32 = 0x9f07c728;
    pub const ACCOUNT_GET_CONTENT_SETTINGS: u32 = 0x8b9b4dae;
    pub const ACCOUNT_GET_GLOBAL_PRIVACY_SETTINGS: u32 = 0xeb2b4cf6;
    pub const ACCOUNT_GET_COLLECTIBLE_EMOJI_STATUSES: u32 = 0x2e7b4543;
    pub const MESSAGES_GET_WEB_PAGE: u32 = 0x8d9692a3;
    pub const PAYMENTS_GET_STAR_GIFT_ACTIVE_AUCTIONS: u32 = 0xa5d0514d;
    pub const STORIES_GET_STORIES_ARCHIVE: u32 = 0xb4352016;
    pub const AICOMPOSE_GET_TONES: u32 = 0xabd59201;

    pub const MESSAGES_GET_DEFAULT_HISTORY_TTL: u32 = 0x658b7188;
    pub const MESSAGES_GET_EMOJI_KEYWORDS_LANGUAGES: u32 = 0x4e9963b2;
    pub const MESSAGES_GET_EMOJI_KEYWORDS_DIFFERENCE: u32 = 0x1508b6af;
    pub const MESSAGES_GET_EMOJI_KEYWORDS: u32 = 0x35a0e062;
    pub const ACCOUNT_GET_PRIVACY: u32 = 0xdadbc950;
    pub const ACCOUNT_SET_PRIVACY: u32 = 0xc9f81ce8;
    pub const ACCOUNT_PRIVACY_RULES: u32 = 0x50a04e45;
    pub const PRIVACY_VALUE_ALLOW_CONTACTS: u32 = 0xfffe1bac;
    pub const PRIVACY_VALUE_ALLOW_ALL: u32 = 0x65427b82;
    pub const PRIVACY_VALUE_ALLOW_USERS: u32 = 0xb8905fb2;
    pub const PRIVACY_VALUE_DISALLOW_CONTACTS: u32 = 0xf888fa1a;
    pub const PRIVACY_VALUE_DISALLOW_ALL: u32 = 0x8b73e763;
    pub const PRIVACY_VALUE_DISALLOW_USERS: u32 = 0xe4621141;
    pub const ACCOUNT_GET_WEB_AUTHORIZATIONS: u32 = 0x182e6d6f;
    pub const ACCOUNT_WEB_AUTHORIZATIONS: u32 = 0xed56c9fc;
    pub const CONTACTS_GET_BLOCKED: u32 = 0x9a868f80;
    pub const CONTACTS_BLOCKED: u32 = 0x0ade1591;
    pub const MESSAGES_GET_SHARE_THEME_BACKDROPS: u32 = 0xf4599ef2;
    pub const SHARE_THEME_BACKDROPS_NOT_MODIFIED: u32 = 0x7a3f6dff;
    pub const STORIES_GET_ALBUMS: u32 = 0x25b3eac7;
    pub const STORIES_ALBUMS: u32 = 0xc3987a3a;
    pub const STORIES_GET_PINNED_STORIES: u32 = 0x5821a5dc;
    pub const PAYMENTS_GET_SAVED_STAR_GIFTS: u32 = 0xa319e569;
    pub const PAYMENTS_SAVED_STAR_GIFTS: u32 = 0x95f389b1;
    pub const MESSAGES_REPORT_READ_METRICS: u32 = 0x4067c5e6;
    pub const MESSAGES_SET_TYPING: u32 = 0x58943ee2;
    pub const CHANNELS_READ_HISTORY: u32 = 0xcc104937;
    pub const CHANNELS_CHECK_USERNAME: u32 = 0x10e6bd2c;
    pub const CHANNELS_GET_SEND_AS: u32 = 0xe785a43f;
    pub const MESSAGES_GET_MESSAGES_VIEWS: u32 = 0x5784d3e1;
    pub const MESSAGES_GET_SPONSORED_MESSAGES: u32 = 0x3d6ce850;
    pub const PAYMENTS_GET_CURRENCY_RATES: u32 = 0xd35983e8;

    pub const MESSAGES_MESSAGE_VIEWS: u32 = 0xb6c4f543;
    pub const MESSAGE_VIEWS: u32 = 0x455b853d;
    pub const MESSAGES_SPONSORED_MESSAGES_EMPTY: u32 = 0x1839490f;
    pub const CHANNELS_SEND_AS_PEERS: u32 = 0xf496b0c6;
    pub const PAYMENTS_CURRENCY_RATES: u32 = 0xbbcce4c2;
    pub const MESSAGES_EXPORT_CHAT_INVITE: u32 = 0xa455de90;
    pub const CHAT_INVITE_EXPORTED: u32 = 0xa22cbd96;

    pub const DEFAULT_HISTORY_TTL: u32 = 0x43b46b20;
    pub const EMOJI_LANGUAGE: u32 = 0xb3fb5361;
    pub const EMOJI_KEYWORDS_DIFFERENCE: u32 = 0x5cc761bd;

    pub const MESSAGES_GET_RECENT_STICKERS: u32 = 0x9da9403b;
    pub const MESSAGES_GET_FAVED_STICKERS: u32 = 0x04f1aaa9;
    pub const MESSAGES_GET_SAVED_GIFS: u32 = 0x5cf09635;
    pub const MESSAGES_GET_ALL_STICKERS: u32 = 0xb8a0a1a8;
    pub const MESSAGES_GET_EMOJI_STICKERS: u32 = 0xfbfca18f;
    pub const MESSAGES_GET_RECENT_REACTIONS: u32 = 0x39461db2;
    pub const MESSAGES_GET_DEFAULT_TAG_REACTIONS: u32 = 0xbdf93428;
    pub const MESSAGES_GET_SAVED_REACTION_TAGS: u32 = 0x3637e05b;
    pub const ACCOUNT_GET_SAVED_RINGTONES: u32 = 0xe1902288;
    pub const ACCOUNT_GET_WALL_PAPERS: u32 = 0x07967d36;
    pub const HELP_GET_TIMEZONES_LIST: u32 = 0x49b30240;

    pub const MESSAGES_RECENT_STICKERS_NOT_MODIFIED: u32 = 0x0b17f890;
    pub const MESSAGES_FAVED_STICKERS_NOT_MODIFIED: u32 = 0x9e8fa6d3;
    pub const MESSAGES_SAVED_GIFS_NOT_MODIFIED: u32 = 0xe8025ca2;
    pub const MESSAGES_ALL_STICKERS_NOT_MODIFIED: u32 = 0xe86602c3;
    pub const MESSAGES_REACTIONS_NOT_MODIFIED: u32 = 0xb06fdbdf;
    pub const MESSAGES_SAVED_REACTION_TAGS_NOT_MODIFIED: u32 = 0x889b59ef;
    pub const ACCOUNT_SAVED_RINGTONES_NOT_MODIFIED: u32 = 0xfbf6e8b1;
    pub const ACCOUNT_WALL_PAPERS_NOT_MODIFIED: u32 = 0x1c199183;
    pub const HELP_TIMEZONES_LIST_NOT_MODIFIED: u32 = 0x970708cc;

    pub const INPUT_CLIENT_PROXY: u32 = 0x75588b3f;
    pub const JSON_NULL: u32 = 0x3f6d7b68;
    pub const JSON_BOOL: u32 = 0xc7345e6a;
    pub const JSON_NUMBER: u32 = 0x2be0dfa4;
    pub const JSON_STRING: u32 = 0xb71e767a;
    pub const JSON_ARRAY: u32 = 0xf7444763;
    pub const JSON_OBJECT: u32 = 0x99c1d49d;
    pub const JSON_OBJECT_VALUE: u32 = 0xc0de1bd9;

    pub const ACCOUNT_PASSWORD: u32 = 0x957b50fb;
    pub const PASSWORD_KDF_ALGO_UNKNOWN: u32 = 0xd45ab096;
    pub const PASSWORD_KDF_ALGO_SHA256_SHA256_PBKDF2_HMAC_SHA512_ITER_100000_SHA256_MOD_POW: u32 =
        0x3a912d4a;
    pub const ACCOUNT_PASSWORD_INPUT_SETTINGS: u32 = 0xc23727c9;
    pub const ACCOUNT_UPDATE_PASSWORD_SETTINGS: u32 = 0xa59b102f;
    pub const ACCOUNT_GET_PASSWORD_SETTINGS: u32 = 0x9cd4eaf9;
    pub const ACCOUNT_PASSWORD_SETTINGS: u32 = 0x9a5c33e5;
    pub const SECURE_PASSWORD_KDF_ALGO_UNKNOWN: u32 = 0x4a8537;
    pub const SECURE_PASSWORD_KDF_ALGO_PBKDF2_HMAC_SHA512_ITER_100000: u32 = 0xbbf2dda0;
    pub const ACCOUNT_CONTENT_SETTINGS: u32 = 0x57e28221;
    pub const GLOBAL_PRIVACY_SETTINGS: u32 = 0xfe41b34f;
    pub const WEB_PAGE_EMPTY: u32 = 0x211a1788;
    pub const ACCOUNT_EMOJI_STATUSES: u32 = 0x90c467d1;
    pub const PAYMENTS_STAR_GIFT_ACTIVE_AUCTIONS: u32 = 0xaef6abbc;
    pub const STORIES_STORIES: u32 = 0x63c3dd0a;
    pub const AICOMPOSE_TONES: u32 = 0x6c9d0efe;

    pub const TRUE: u32 = 0x3fedd339;
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum Error {
    UnexpectedEof,
    InvalidLength(i32),
    UnexpectedConstructor { expected: u32, actual: u32 },
    InvalidString,
    InvalidBool(u32),
    MessageTooLarge(usize),
}

impl fmt::Display for Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::UnexpectedEof => f.write_str("unexpected end of TL input"),
            Self::InvalidLength(length) => write!(f, "invalid TL length {length}"),
            Self::UnexpectedConstructor { expected, actual } => write!(
                f,
                "unexpected TL constructor 0x{actual:08x}, expected 0x{expected:08x}"
            ),
            Self::InvalidString => f.write_str("invalid UTF-8 in TL string"),
            Self::InvalidBool(value) => write!(f, "invalid TL bool constructor 0x{value:08x}"),
            Self::MessageTooLarge(length) => write!(f, "TL message is too large: {length} bytes"),
        }
    }
}

impl std::error::Error for Error {}

pub type Result<T> = std::result::Result<T, Error>;

/// Little-endian helpers for the fixed protocol fields that Telegram defines as
/// raw 64-bit values.
pub fn write_i64_le(buffer: &mut Vec<u8>, value: i64) {
    buffer.extend_from_slice(&value.to_le_bytes());
}

pub fn read_i64_le(bytes: &[u8]) -> i64 {
    let mut raw = [0u8; 8];
    raw.copy_from_slice(&bytes[..8]);
    i64::from_le_bytes(raw)
}

#[derive(Default, Debug, Clone)]
pub struct Writer {
    buffer: Vec<u8>,
}

impl Writer {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn with_capacity(capacity: usize) -> Self {
        Self {
            buffer: Vec::with_capacity(capacity),
        }
    }

    pub fn len(&self) -> usize {
        self.buffer.len()
    }

    pub fn is_empty(&self) -> bool {
        self.buffer.is_empty()
    }

    pub fn into_bytes(self) -> Vec<u8> {
        self.buffer
    }

    pub fn as_bytes(&self) -> &[u8] {
        &self.buffer
    }

    pub fn raw(&mut self, bytes: &[u8]) -> &mut Self {
        self.buffer.extend_from_slice(bytes);
        self
    }

    pub fn i32(&mut self, value: i32) -> &mut Self {
        self.buffer.extend_from_slice(&value.to_le_bytes());
        self
    }

    pub fn u32(&mut self, value: u32) -> &mut Self {
        self.buffer.extend_from_slice(&value.to_le_bytes());
        self
    }

    pub fn i64(&mut self, value: i64) -> &mut Self {
        self.buffer.extend_from_slice(&value.to_le_bytes());
        self
    }

    pub fn f64(&mut self, value: f64) -> &mut Self {
        self.buffer.extend_from_slice(&value.to_le_bytes());
        self
    }

    pub fn bool(&mut self, value: bool) -> &mut Self {
        self.u32(if value {
            ctor::BOOL_TRUE
        } else {
            ctor::BOOL_FALSE
        })
    }

    /// Raw `int128` value (16 bytes, big-endian numeric representation).
    pub fn int128(&mut self, value: &Int128) -> &mut Self {
        self.raw(value)
    }

    /// Raw `int256` value (32 bytes, big-endian numeric representation).
    pub fn int256(&mut self, value: &Int256) -> &mut Self {
        self.raw(value)
    }

    /// TL `string` / `bytes`.
    ///
    /// Lengths up to 253 are encoded in a single byte. Longer values use the
    /// `0xFE` marker followed by a 24-bit little-endian length. The length
    /// header and payload together are padded to a 4-byte boundary.
    pub fn bytes(&mut self, value: &[u8]) -> &mut Self {
        let length = value.len();
        let header_length = if length <= 253 {
            self.buffer.push(length as u8);
            1
        } else {
            self.buffer.push(0xFE);
            self.buffer.push((length & 0xFF) as u8);
            self.buffer.push(((length >> 8) & 0xFF) as u8);
            self.buffer.push(((length >> 16) & 0xFF) as u8);
            4
        };
        self.raw(value);
        let total = header_length + length;
        let padding = (4 - total % 4) % 4;
        self.buffer.resize(self.buffer.len() + padding, 0);
        self
    }

    pub fn string(&mut self, value: &str) -> &mut Self {
        self.bytes(value.as_bytes())
    }

    pub fn vector<T>(&mut self, values: &[T], mut write: impl FnMut(&mut Self, &T)) -> &mut Self {
        self.u32(ctor::VECTOR);
        self.i32(values.len() as i32);
        for value in values {
            write(self, value);
        }
        self
    }
}

#[derive(Debug, Clone, Copy)]
pub struct Reader<'a> {
    buffer: &'a [u8],
    position: usize,
}

impl<'a> Reader<'a> {
    pub fn new(buffer: &'a [u8]) -> Self {
        Self {
            buffer,
            position: 0,
        }
    }

    pub fn position(&self) -> usize {
        self.position
    }

    pub fn remaining(&self) -> usize {
        self.buffer.len().saturating_sub(self.position)
    }

    pub fn is_empty(&self) -> bool {
        self.remaining() == 0
    }

    /// Bytes consumed since `start`; used to keep raw TL constructors intact.
    pub fn take_since(&self, start: usize) -> Result<&'a [u8]> {
        if start > self.position {
            return Err(Error::UnexpectedEof);
        }
        Ok(&self.buffer[start..self.position])
    }

    pub fn raw(&mut self, count: usize) -> Result<&'a [u8]> {
        let end = self
            .position
            .checked_add(count)
            .ok_or(Error::UnexpectedEof)?;
        if end > self.buffer.len() {
            return Err(Error::UnexpectedEof);
        }
        let value = &self.buffer[self.position..end];
        self.position = end;
        Ok(value)
    }

    pub fn peek_raw(&self, count: usize) -> Result<&'a [u8]> {
        let end = self
            .position
            .checked_add(count)
            .ok_or(Error::UnexpectedEof)?;
        if end > self.buffer.len() {
            return Err(Error::UnexpectedEof);
        }
        Ok(&self.buffer[self.position..end])
    }

    pub fn i32(&mut self) -> Result<i32> {
        let bytes = self.raw(4)?;
        Ok(i32::from_le_bytes(
            bytes.try_into().expect("four bytes checked"),
        ))
    }

    pub fn u32(&mut self) -> Result<u32> {
        let bytes = self.raw(4)?;
        Ok(u32::from_le_bytes(
            bytes.try_into().expect("four bytes checked"),
        ))
    }

    pub fn i64(&mut self) -> Result<i64> {
        let bytes = self.raw(8)?;
        Ok(i64::from_le_bytes(
            bytes.try_into().expect("eight bytes checked"),
        ))
    }

    pub fn f64(&mut self) -> Result<f64> {
        let bytes = self.raw(8)?;
        Ok(f64::from_le_bytes(
            bytes.try_into().expect("eight bytes checked"),
        ))
    }

    pub fn bool(&mut self) -> Result<bool> {
        match self.u32()? {
            ctor::BOOL_TRUE => Ok(true),
            ctor::BOOL_FALSE => Ok(false),
            value => Err(Error::InvalidBool(value)),
        }
    }

    pub fn int128(&mut self) -> Result<Int128> {
        let bytes = self.raw(16)?;
        Ok(bytes.try_into().expect("sixteen bytes checked"))
    }

    pub fn int256(&mut self) -> Result<Int256> {
        let bytes = self.raw(32)?;
        Ok(bytes.try_into().expect("thirty-two bytes checked"))
    }

    pub fn bytes(&mut self) -> Result<Vec<u8>> {
        let first = self.raw(1)?[0];
        let (length, header_length) = if first == 0xFE {
            let raw = self.raw(3)?;
            (
                usize::from(raw[0]) | (usize::from(raw[1]) << 8) | (usize::from(raw[2]) << 16),
                4usize,
            )
        } else {
            (usize::from(first), 1usize)
        };
        if length > 16 * 1024 * 1024 {
            return Err(Error::MessageTooLarge(length));
        }
        let value = self.raw(length)?.to_vec();
        let total = header_length + length;
        let padding = (4 - total % 4) % 4;
        if padding > 0 {
            let _ = self.raw(padding)?;
        }
        Ok(value)
    }

    pub fn string(&mut self) -> Result<String> {
        let bytes = self.bytes()?;
        String::from_utf8(bytes).map_err(|_| Error::InvalidString)
    }

    pub fn vector<T>(&mut self, mut read: impl FnMut(&mut Self) -> Result<T>) -> Result<Vec<T>> {
        self.expect_constructor(ctor::VECTOR)?;
        let count = self.i32()?;
        if count < 0 {
            return Err(Error::InvalidLength(count));
        }
        // Guards against absurd allocations from malformed input.
        if count as usize > self.remaining() {
            return Err(Error::InvalidLength(count));
        }
        let mut values = Vec::with_capacity(count as usize);
        for _ in 0..count {
            values.push(read(self)?);
        }
        Ok(values)
    }

    pub fn expect_constructor(&mut self, expected: u32) -> Result<()> {
        let actual = self.u32()?;
        if actual != expected {
            return Err(Error::UnexpectedConstructor { expected, actual });
        }
        Ok(())
    }

    pub fn constructor(&mut self) -> Result<u32> {
        self.u32()
    }
}

/// Unencrypted MTProto envelope used during the auth-key exchange.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct UnencryptedMessage {
    pub message_id: i64,
    pub data: Vec<u8>,
}

impl UnencryptedMessage {
    pub fn encode(&self) -> Vec<u8> {
        let mut writer = Writer::with_capacity(24 + self.data.len());
        writer.i64(0);
        writer.i64(self.message_id);
        writer.i32(self.data.len() as i32);
        writer.raw(&self.data);
        writer.into_bytes()
    }

    pub fn decode(bytes: &[u8]) -> Result<Self> {
        let mut reader = Reader::new(bytes);
        let auth_key_id = reader.i64()?;
        if auth_key_id != 0 {
            return Err(Error::UnexpectedConstructor {
                expected: 0,
                actual: auth_key_id as u32,
            });
        }
        let message_id = reader.i64()?;
        let length = reader.i32()?;
        if length < 0 {
            return Err(Error::InvalidLength(length));
        }
        let data = reader.raw(length as usize)?.to_vec();
        Ok(Self { message_id, data })
    }
}

/// A message inside an MTProto `msg_container`.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ContainerMessage {
    pub message_id: i64,
    pub seq_no: i32,
    pub body: Vec<u8>,
}

impl ContainerMessage {
    pub fn encode(&self) -> Vec<u8> {
        let mut writer = Writer::with_capacity(16 + self.body.len());
        writer.i64(self.message_id);
        writer.i32(self.seq_no);
        writer.i32(self.body.len() as i32);
        writer.raw(&self.body);
        writer.into_bytes()
    }

    pub fn decode(bytes: &[u8]) -> Result<Self> {
        let mut reader = Reader::new(bytes);
        let message_id = reader.i64()?;
        let seq_no = reader.i32()?;
        let length = reader.i32()?;
        if length < 0 {
            return Err(Error::InvalidLength(length));
        }
        let body = reader.raw(length as usize)?.to_vec();
        Ok(Self {
            message_id,
            seq_no,
            body,
        })
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct MessageContainer {
    pub messages: Vec<ContainerMessage>,
}

impl MessageContainer {
    pub fn encode(&self) -> Vec<u8> {
        let mut writer = Writer::with_capacity(8 + self.messages.len() * 8);
        writer.u32(ctor::MSG_CONTAINER);
        writer.i32(self.messages.len() as i32);
        for message in &self.messages {
            writer.raw(&message.encode());
        }
        writer.into_bytes()
    }

    pub fn decode(bytes: &[u8]) -> Result<Self> {
        let mut reader = Reader::new(bytes);
        reader.expect_constructor(ctor::MSG_CONTAINER)?;
        let count = reader.i32()?;
        if count < 0 {
            return Err(Error::InvalidLength(count));
        }
        let mut messages = Vec::with_capacity(count as usize);
        for _ in 0..count {
            let message_id = reader.i64()?;
            let seq_no = reader.i32()?;
            let length = reader.i32()?;
            if length < 0 {
                return Err(Error::InvalidLength(length));
            }
            let body = reader.raw(length as usize)?.to_vec();
            messages.push(ContainerMessage {
                message_id,
                seq_no,
                body,
            });
        }
        Ok(Self { messages })
    }
}

/// `rpc_result#f35c6d01 req_msg_id:long result:Object`.
pub fn rpc_result(request_message_id: i64, result: &[u8]) -> Vec<u8> {
    let mut writer = Writer::with_capacity(12 + result.len());
    writer.u32(ctor::RPC_RESULT);
    writer.i64(request_message_id);
    writer.raw(result);
    writer.into_bytes()
}

pub fn rpc_error(error_code: i32, message: &str) -> Vec<u8> {
    let mut writer = Writer::with_capacity(16 + message.len());
    writer.u32(ctor::RPC_ERROR);
    writer.i32(error_code);
    writer.string(message);
    writer.into_bytes()
}

pub fn pong(message_id: i64, ping_id: i64) -> Vec<u8> {
    let mut writer = Writer::new();
    writer.u32(ctor::PONG);
    writer.i64(message_id);
    writer.i64(ping_id);
    writer.into_bytes()
}

pub fn msgs_ack(message_ids: &[i64]) -> Vec<u8> {
    let mut writer = Writer::with_capacity(8 + message_ids.len() * 8);
    writer.u32(ctor::MSGS_ACK);
    writer.vector(message_ids, |writer, value| {
        writer.i64(*value);
    });
    writer.into_bytes()
}

pub fn new_session_created(first_message_id: i64, unique_id: i64, server_salt: i64) -> Vec<u8> {
    let mut writer = Writer::with_capacity(28);
    writer.u32(ctor::NEW_SESSION_CREATED);
    writer.i64(first_message_id);
    writer.i64(unique_id);
    writer.i64(server_salt);
    writer.into_bytes()
}

/// TL value constructors used by the login smoke test.
pub mod types {
    use super::{ctor, Int128, Writer};

    pub fn res_pq(
        nonce: &Int128,
        server_nonce: &Int128,
        pq: &[u8],
        fingerprints: &[i64],
    ) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::RES_PQ);
        writer.int128(nonce);
        writer.int128(server_nonce);
        writer.bytes(pq);
        writer.vector(fingerprints, |writer, value| {
            writer.i64(*value);
        });
        writer.into_bytes()
    }

    pub fn server_dh_params_ok(
        nonce: &Int128,
        server_nonce: &Int128,
        encrypted_answer: &[u8],
    ) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::SERVER_DH_PARAMS_OK);
        writer.int128(nonce);
        writer.int128(server_nonce);
        writer.bytes(encrypted_answer);
        writer.into_bytes()
    }

    pub fn dh_gen_ok(nonce: &Int128, server_nonce: &Int128, new_nonce_hash1: &Int128) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::DH_GEN_OK);
        writer.int128(nonce);
        writer.int128(server_nonce);
        writer.int128(new_nonce_hash1);
        writer.into_bytes()
    }

    pub fn update_user(user_id: i64) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::UPDATE_USER);
        writer.i64(user_id);
        writer.into_bytes()
    }

    pub fn bool_true() -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::BOOL_TRUE);
        writer.into_bytes()
    }

    pub fn auth_login_token(expires: i32, token: &[u8]) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::AUTH_LOGIN_TOKEN);
        writer.i32(expires);
        writer.bytes(token);
        writer.into_bytes()
    }

    /// `auth.loginTokenSuccess#390d5c5e authorization:auth.Authorization`
    pub fn auth_login_token_success(authorization: &[u8]) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::AUTH_LOGIN_TOKEN_SUCCESS);
        writer.raw(authorization);
        writer.into_bytes()
    }

    pub fn auth_sent_code(phone_code_hash: &str, code_length: i32) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::AUTH_SENT_CODE);
        writer.u32(0); // flags
        writer.u32(ctor::AUTH_SENT_CODE_TYPE_APP);
        writer.i32(code_length);
        writer.string(phone_code_hash);
        writer.into_bytes()
    }

    pub fn auth_authorization(user: &[u8]) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::AUTH_AUTHORIZATION);
        writer.u32(0); // flags
        writer.raw(user);
        writer.into_bytes()
    }

    pub fn auth_authorization_sign_up_required() -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::AUTH_AUTHORIZATION_SIGN_UP_REQUIRED);
        writer.u32(0); // flags
        writer.into_bytes()
    }

    pub fn user(
        id: i64,
        access_hash: i64,
        first_name: &str,
        last_name: &str,
        phone: &str,
    ) -> Vec<u8> {
        user_impl(
            id,
            access_hash,
            first_name,
            last_name,
            "",
            phone,
            0,
            0,
            0,
            true,
            None,
        )
    }

    #[allow(clippy::too_many_arguments)]
    pub fn user_with_photo(
        id: i64,
        access_hash: i64,
        first_name: &str,
        last_name: &str,
        phone: &str,
        photo_id: i64,
        emoji_status_id: i64,
    ) -> Vec<u8> {
        user_impl(
            id,
            access_hash,
            first_name,
            last_name,
            "",
            phone,
            photo_id,
            emoji_status_id,
            0,
            true,
            None,
        )
    }

    /// User object for the current account with a caller-supplied presence
    /// status (`userStatusOnline` / `userStatusOffline` / `userStatusRecently`).
    #[allow(clippy::too_many_arguments)]
    pub fn user_with_photo_status(
        id: i64,
        access_hash: i64,
        first_name: &str,
        last_name: &str,
        username: &str,
        phone: &str,
        photo_id: i64,
        emoji_status_id: i64,
        status: &[u8],
    ) -> Vec<u8> {
        user_impl(
            id,
            access_hash,
            first_name,
            last_name,
            username,
            phone,
            photo_id,
            emoji_status_id,
            0,
            true,
            Some(status),
        )
    }

    pub fn user_other(
        id: i64,
        access_hash: i64,
        first_name: &str,
        last_name: &str,
        phone: &str,
    ) -> Vec<u8> {
        user_impl(
            id,
            access_hash,
            first_name,
            last_name,
            "",
            phone,
            0,
            0,
            0,
            false,
            None,
        )
    }

    #[allow(clippy::too_many_arguments)]
    pub fn user_other_with_photo(
        id: i64,
        access_hash: i64,
        first_name: &str,
        last_name: &str,
        phone: &str,
        photo_id: i64,
        emoji_status_id: i64,
    ) -> Vec<u8> {
        user_impl(
            id,
            access_hash,
            first_name,
            last_name,
            "",
            phone,
            photo_id,
            emoji_status_id,
            0,
            false,
            None,
        )
    }

    /// User object for another account with a caller-supplied presence status.
    #[allow(clippy::too_many_arguments)]
    pub fn user_other_with_photo_status(
        id: i64,
        access_hash: i64,
        first_name: &str,
        last_name: &str,
        username: &str,
        phone: &str,
        photo_id: i64,
        emoji_status_id: i64,
        status: &[u8],
    ) -> Vec<u8> {
        user_impl(
            id,
            access_hash,
            first_name,
            last_name,
            username,
            phone,
            photo_id,
            emoji_status_id,
            0,
            false,
            Some(status),
        )
    }

    #[allow(clippy::too_many_arguments)]
    pub fn user_bot_status(
        id: i64,
        access_hash: i64,
        first_name: &str,
        last_name: &str,
        username: &str,
        photo_id: i64,
        bot_info_version: i32,
        status: &[u8],
        is_self: bool,
    ) -> Vec<u8> {
        user_impl(
            id,
            access_hash,
            first_name,
            last_name,
            username,
            "",
            photo_id,
            0,
            bot_info_version,
            is_self,
            Some(status),
        )
    }

    #[allow(clippy::too_many_arguments)]
    fn user_impl(
        id: i64,
        access_hash: i64,
        first_name: &str,
        last_name: &str,
        username: &str,
        phone: &str,
        photo_id: i64,
        emoji_status_id: i64,
        bot_info_version: i32,
        is_self: bool,
        status: Option<&[u8]>,
    ) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::USER);
        // access_hash, first_name, last_name, username, phone, status.
        // Bit 10 (self) must only be set for the current account; Android
        // renders other users carrying this flag as Saved Messages.
        // Bit 28 marks the account as Telegram Premium: the client shows the
        // badge and allows one extra account slot while it is logged in.
        let mut flags = 0x0000_005f | (1 << 28);
        if is_self {
            flags |= 1 << 10;
        }
        if photo_id != 0 {
            flags |= 1 << 5;
        }
        if emoji_status_id != 0 {
            flags |= 1 << 30;
        }
        if bot_info_version != 0 {
            // Bots never expose a phone number.
            flags |= 1 << 14;
            flags &= !(1 << 4);
        }
        writer.u32(flags);
        writer.u32(0); // flags2
        writer.i64(id);
        writer.i64(access_hash);
        writer.string(first_name);
        writer.string(last_name);
        writer.string(username);
        if flags & (1 << 4) != 0 {
            writer.string(phone);
        }
        if photo_id != 0 {
            writer.raw(&user_profile_photo(photo_id));
        }
        // status (flag 6)
        match status {
            Some(status) => {
                writer.raw(status);
            }
            None => {
                writer.raw(&user_status_recently());
            }
        }
        if bot_info_version != 0 {
            writer.i32(bot_info_version);
        }
        if emoji_status_id != 0 {
            writer.raw(&emoji_status(emoji_status_id));
        }
        writer.into_bytes()
    }

    pub fn user_profile_photo(photo_id: i64) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::USER_PROFILE_PHOTO);
        writer.u32(0); // flags
        writer.i64(photo_id);
        writer.i32(2); // dc_id
        writer.into_bytes()
    }

    pub fn photos_photo(photo: &[u8], users: &[Vec<u8>]) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::PHOTOS_PHOTO);
        writer.raw(photo);
        writer.u32(ctor::VECTOR);
        writer.i32(users.len() as i32);
        for user in users {
            writer.raw(user);
        }
        writer.into_bytes()
    }

    pub fn photos_photos(photos: &[Vec<u8>], users: &[Vec<u8>]) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::PHOTOS_PHOTOS);
        writer.u32(ctor::VECTOR);
        writer.i32(photos.len() as i32);
        for photo in photos {
            writer.raw(photo);
        }
        writer.u32(ctor::VECTOR);
        writer.i32(users.len() as i32);
        for user in users {
            writer.raw(user);
        }
        writer.into_bytes()
    }

    pub fn contacts_found(
        my_results: &[Vec<u8>],
        results: &[Vec<u8>],
        chats: &[Vec<u8>],
        users: &[Vec<u8>],
    ) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::CONTACTS_FOUND);
        for items in [my_results, results] {
            writer.u32(ctor::VECTOR);
            writer.i32(items.len() as i32);
            for item in items {
                writer.raw(item);
            }
        }
        writer.u32(ctor::VECTOR);
        writer.i32(chats.len() as i32);
        for chat in chats {
            writer.raw(chat);
        }
        writer.u32(ctor::VECTOR);
        writer.i32(users.len() as i32);
        for user in users {
            writer.raw(user);
        }
        writer.into_bytes()
    }

    pub fn peer_user(user_id: i64) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::PEER_USER);
        writer.i64(user_id);
        writer.into_bytes()
    }

    pub fn contact(user_id: i64) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::CONTACTS_CONTACT);
        writer.i64(user_id);
        writer.bool(false); // mutual
        writer.into_bytes()
    }

    pub fn bot_callback_answer(
        alert: bool,
        message: Option<&str>,
        url: Option<&str>,
        cache_time: i32,
    ) -> Vec<u8> {
        // messages.botCallbackAnswer#36585ea4 flags:# alert:flags.0?true
        // message:flags.1?string url:flags.2?string cache_time:flags.4?int
        let mut flags = 0;
        if alert {
            flags |= 1;
        }
        if message.is_some() {
            flags |= 1 << 1;
        }
        if url.is_some() {
            flags |= 1 << 2;
        }
        if cache_time > 0 {
            flags |= 1 << 4;
        }
        let mut writer = Writer::new();
        writer.u32(0x3658_5ea4);
        writer.u32(flags);
        if let Some(message) = message {
            writer.string(message);
        }
        if let Some(url) = url {
            writer.string(url);
        }
        if cache_time > 0 {
            writer.i32(cache_time);
        }
        writer.into_bytes()
    }

    #[derive(Debug, Clone, Default)]
    pub struct MessageExtras {
        pub reply_to_msg_id: Option<i32>,
        pub fwd_from_user_id: Option<i64>,
        pub fwd_from_chat_id: Option<i64>,
        pub fwd_from_msg_id: Option<i32>,
        pub fwd_date: i32,
        pub edit_date: i32,
        pub pinned: bool,
        pub reactions: Option<Vec<u8>>,
        /// Non-zero when the message belongs to an album (`message#flags.17`).
        pub grouped_id: i64,
        /// View counter written as `views:flags.10`, `0` hides the field.
        pub views: i32,
        /// Raw `MessageEntity` constructors written as `entities:flags.7`.
        pub entities: Vec<Vec<u8>>,
        /// Serialized `ReplyMarkup` written as `reply_markup:flags.6`.
        pub reply_markup: Option<Vec<u8>>,
    }

    pub fn message(
        id: i32,
        out: bool,
        from_user_id: i64,
        peer_user_id: i64,
        date: i32,
        text: &str,
    ) -> Vec<u8> {
        message_ext(
            id,
            out,
            from_user_id,
            peer_user_id,
            date,
            text,
            None,
            &MessageExtras::default(),
        )
    }

    #[allow(clippy::too_many_arguments)]
    pub fn message_media(
        id: i32,
        out: bool,
        from_user_id: i64,
        peer_user_id: i64,
        date: i32,
        text: &str,
        media: &[u8],
    ) -> Vec<u8> {
        message_ext(
            id,
            out,
            from_user_id,
            peer_user_id,
            date,
            text,
            Some(media),
            &MessageExtras::default(),
        )
    }

    #[allow(clippy::too_many_arguments)]
    pub fn message_ext(
        id: i32,
        out: bool,
        from_user_id: i64,
        peer_user_id: i64,
        date: i32,
        text: &str,
        media: Option<&[u8]>,
        extras: &MessageExtras,
    ) -> Vec<u8> {
        message_with_peer_media(
            id,
            out,
            from_user_id,
            &peer_user(peer_user_id),
            date,
            text,
            media,
            extras,
        )
    }

    pub fn message_channel(
        id: i32,
        out: bool,
        from_user_id: i64,
        channel_id: i64,
        date: i32,
        text: &str,
    ) -> Vec<u8> {
        message_channel_ext(
            id,
            out,
            from_user_id,
            channel_id,
            date,
            text,
            None,
            &MessageExtras::default(),
        )
    }

    #[allow(clippy::too_many_arguments)]
    pub fn message_channel_media(
        id: i32,
        out: bool,
        from_user_id: i64,
        channel_id: i64,
        date: i32,
        text: &str,
        media: &[u8],
    ) -> Vec<u8> {
        message_channel_ext(
            id,
            out,
            from_user_id,
            channel_id,
            date,
            text,
            Some(media),
            &MessageExtras::default(),
        )
    }

    #[allow(clippy::too_many_arguments)]
    pub fn message_channel_ext(
        id: i32,
        out: bool,
        from_user_id: i64,
        channel_id: i64,
        date: i32,
        text: &str,
        media: Option<&[u8]>,
        extras: &MessageExtras,
    ) -> Vec<u8> {
        message_with_peer_media(
            id,
            out,
            from_user_id,
            &peer_channel(channel_id),
            date,
            text,
            media,
            extras,
        )
    }

    #[allow(clippy::too_many_arguments)]
    fn message_with_peer_media(
        id: i32,
        out: bool,
        from_user_id: i64,
        peer: &[u8],
        date: i32,
        text: &str,
        media: Option<&[u8]>,
        extras: &MessageExtras,
    ) -> Vec<u8> {
        let has_fwd = extras.fwd_from_user_id.is_some() || extras.fwd_from_chat_id.is_some();
        let mut writer = Writer::new();
        writer.u32(ctor::MESSAGE);
        let mut flags = 1 << 8; // from_id
        if out {
            flags |= 1 << 1;
        }
        if has_fwd {
            flags |= 1 << 2;
        }
        if extras.reply_to_msg_id.is_some() {
            flags |= 1 << 3;
        }
        if media.is_some() {
            flags |= 1 << 9;
        }
        if extras.edit_date > 0 {
            flags |= 1 << 15;
        }
        if extras.pinned {
            flags |= 1 << 24;
        }
        if extras.reactions.is_some() {
            flags |= 1 << 20;
        }
        if extras.grouped_id != 0 {
            flags |= 1 << 17;
        }
        if extras.views > 0 {
            flags |= 1 << 10;
        }
        if !extras.entities.is_empty() {
            flags |= 1 << 7;
        }
        if extras.reply_markup.is_some() {
            flags |= 1 << 6;
        }
        writer.u32(flags);
        writer.u32(0); // flags2
        writer.i32(id);
        writer.raw(&peer_user(from_user_id));
        writer.raw(peer);
        if has_fwd {
            message_fwd_header(&mut writer, extras);
        }
        if let Some(reply_to_msg_id) = extras.reply_to_msg_id {
            // messageReplyHeader#ddb5ab75 with reply_to_msg_id (flags.4).
            writer.u32(ctor::MESSAGE_REPLY_HEADER);
            writer.u32(1 << 4);
            writer.i32(reply_to_msg_id);
        }
        writer.i32(date);
        writer.string(text);
        if let Some(media) = media {
            writer.raw(media);
        }
        if let Some(reply_markup) = &extras.reply_markup {
            writer.raw(reply_markup);
        }
        if !extras.entities.is_empty() {
            writer.u32(ctor::VECTOR);
            writer.i32(extras.entities.len() as i32);
            for entity in &extras.entities {
                writer.raw(entity);
            }
        }
        if extras.views > 0 {
            writer.i32(extras.views);
            writer.i32(0); // forwards
        }
        if extras.edit_date > 0 {
            writer.i32(extras.edit_date);
        }
        if extras.grouped_id != 0 {
            writer.i64(extras.grouped_id);
        }
        if let Some(reactions) = &extras.reactions {
            writer.raw(reactions);
        }
        writer.into_bytes()
    }

    fn message_fwd_header(writer: &mut Writer, extras: &MessageExtras) {
        let mut flags = 0;
        if extras.fwd_from_user_id.is_some() || extras.fwd_from_chat_id.is_some() {
            flags |= 1 << 0;
        }
        if extras.fwd_from_chat_id.is_some() && extras.fwd_from_msg_id.is_some() {
            flags |= 1 << 2;
        }
        writer.u32(ctor::MESSAGE_FWD_HEADER);
        writer.u32(flags);
        if let Some(user_id) = extras.fwd_from_user_id {
            writer.raw(&peer_user(user_id));
        } else if let Some(chat_id) = extras.fwd_from_chat_id {
            writer.raw(&peer_channel(chat_id));
        }
        writer.i32(extras.fwd_date);
        if flags & (1 << 2) != 0 {
            writer.i32(extras.fwd_from_msg_id.unwrap_or(0));
        }
    }

    /// `messageMediaPhoto#e216eb63` with the `photo` flag set.
    pub fn message_media_photo(photo: &[u8]) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::MESSAGE_MEDIA_PHOTO);
        writer.u32(1 << 0);
        writer.raw(photo);
        writer.into_bytes()
    }

    /// `messageMediaDocument#52d8ccd9` with the `document` flag set.
    pub fn message_media_document(document: &[u8], is_video: bool) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::MESSAGE_MEDIA_DOCUMENT);
        let mut flags = 1 << 0;
        if is_video {
            flags |= 1 << 6;
        }
        writer.u32(flags);
        writer.raw(document);
        writer.into_bytes()
    }

    /// `textWithEntities#751f3146` without formatting entities.
    pub fn text_with_entities(text: &str) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::TEXT_WITH_ENTITIES);
        writer.string(text);
        writer.u32(ctor::VECTOR);
        writer.i32(0);
        writer.into_bytes()
    }

    /// `pollAnswer#4b7d786a` without attached media.
    pub fn poll_answer(text: &str, option: &[u8]) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::POLL_ANSWER);
        writer.u32(0); // flags
        writer.raw(&text_with_entities(text));
        writer.bytes(option);
        writer.into_bytes()
    }

    /// `poll#966e2dbf` with `hash = 0`.
    pub fn poll(
        id: i64,
        flags: u32,
        question: &str,
        answers: &[Vec<u8>],
        close_period: i32,
        close_date: i32,
    ) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::POLL);
        writer.i64(id);
        writer.u32(flags);
        writer.raw(&text_with_entities(question));
        writer.u32(ctor::VECTOR);
        writer.i32(answers.len() as i32);
        for answer in answers {
            writer.raw(answer);
        }
        if flags & (1 << 4) != 0 {
            writer.i32(close_period);
        }
        if flags & (1 << 5) != 0 {
            writer.i32(close_date);
        }
        if flags & (1 << 12) != 0 {
            writer.u32(ctor::VECTOR);
            writer.i32(0);
        }
        writer.i64(0); // hash
        writer.into_bytes()
    }

    /// `pollAnswerVoters#3645230a`.
    pub fn poll_answer_voters(option: &[u8], voters: i32, chosen: bool, correct: bool) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::POLL_ANSWER_VOTERS);
        let mut flags = 0;
        if chosen {
            flags |= 1 << 0;
        }
        if correct {
            flags |= 1 << 1;
        }
        if voters >= 0 {
            flags |= 1 << 2;
        }
        writer.u32(flags);
        writer.bytes(option);
        if voters >= 0 {
            writer.i32(voters);
        }
        writer.into_bytes()
    }

    /// `pollResults#ba7bb15e` with per-option counts and total voters.
    pub fn poll_results(options: &[Vec<u8>], total_voters: i32) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::POLL_RESULTS);
        let mut flags = 1 << 1;
        if total_voters >= 0 {
            flags |= 1 << 2;
        }
        writer.u32(flags);
        writer.u32(ctor::VECTOR);
        writer.i32(options.len() as i32);
        for option in options {
            writer.raw(option);
        }
        if total_voters >= 0 {
            writer.i32(total_voters);
        }
        writer.into_bytes()
    }

    /// `messageMediaPoll#773f4e66` without attached media.
    pub fn message_media_poll(poll: &[u8], results: &[u8]) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::MESSAGE_MEDIA_POLL);
        writer.u32(0); // flags
        writer.raw(poll);
        writer.raw(results);
        writer.into_bytes()
    }

    /// `geoPoint#b2a2f663`.
    pub fn geo_point(lat: f64, long: f64, access_hash: i64, accuracy_radius: i32) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::GEO_POINT);
        let flags = if accuracy_radius > 0 { 1 << 0 } else { 0 };
        writer.u32(flags);
        writer.f64(long);
        writer.f64(lat);
        writer.i64(access_hash);
        if accuracy_radius > 0 {
            writer.i32(accuracy_radius);
        }
        writer.into_bytes()
    }

    /// `messageMediaGeo#56e0d474`.
    pub fn message_media_geo(geo: &[u8]) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::MESSAGE_MEDIA_GEO);
        writer.raw(geo);
        writer.into_bytes()
    }

    /// `messageMediaContact#70322949`.
    pub fn message_media_contact(
        phone_number: &str,
        first_name: &str,
        last_name: &str,
        vcard: &str,
        user_id: i64,
    ) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::MESSAGE_MEDIA_CONTACT);
        writer.string(phone_number);
        writer.string(first_name);
        writer.string(last_name);
        writer.string(vcard);
        writer.i64(user_id);
        writer.into_bytes()
    }

    /// `messageMediaDice#08cbec07`.
    pub fn message_media_dice(value: i32, emoticon: &str) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::MESSAGE_MEDIA_DICE);
        writer.u32(0); // flags
        writer.i32(value);
        writer.string(emoticon);
        writer.into_bytes()
    }

    /// `updateMessagePoll#d64c522b` carrying the peer and message id.
    pub fn update_message_poll(
        peer: &[u8],
        msg_id: i32,
        poll: &[u8],
        poll_id: i64,
        results: &[u8],
    ) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::UPDATE_MESSAGE_POLL);
        writer.u32((1 << 0) | (1 << 1));
        writer.raw(peer);
        writer.i32(msg_id);
        writer.i64(poll_id);
        writer.raw(poll);
        writer.raw(results);
        writer.into_bytes()
    }

    /// `photo#fb197a65`.
    pub fn photo(
        id: i64,
        access_hash: i64,
        file_reference: &[u8],
        date: i32,
        sizes: &[Vec<u8>],
        dc_id: i32,
    ) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::PHOTO);
        writer.u32(0); // flags
        writer.i64(id);
        writer.i64(access_hash);
        writer.bytes(file_reference);
        writer.i32(date);
        writer.u32(ctor::VECTOR);
        writer.i32(sizes.len() as i32);
        for size in sizes {
            writer.raw(size);
        }
        writer.i32(dc_id);
        writer.into_bytes()
    }

    /// `photoSize#75c78e60`.
    pub fn photo_size(kind: &str, width: i32, height: i32, size: i64) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::PHOTO_SIZE);
        writer.string(kind);
        writer.i32(width);
        writer.i32(height);
        writer.i32(size.min(i64::from(i32::MAX)) as i32);
        writer.into_bytes()
    }

    /// `document#8fd4c4d8`.
    #[allow(clippy::too_many_arguments)]
    pub fn document(
        id: i64,
        access_hash: i64,
        file_reference: &[u8],
        date: i32,
        mime_type: &str,
        size: i64,
        thumbs: &[Vec<u8>],
        dc_id: i32,
        attributes: &[Vec<u8>],
    ) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::DOCUMENT);
        let flags = if thumbs.is_empty() { 0 } else { 1 << 0 };
        writer.u32(flags);
        writer.i64(id);
        writer.i64(access_hash);
        writer.bytes(file_reference);
        writer.i32(date);
        writer.string(mime_type);
        writer.i64(size);
        if flags & (1 << 0) != 0 {
            writer.u32(ctor::VECTOR);
            writer.i32(thumbs.len() as i32);
            for thumb in thumbs {
                writer.raw(thumb);
            }
        }
        writer.i32(dc_id);
        writer.u32(ctor::VECTOR);
        writer.i32(attributes.len() as i32);
        for attribute in attributes {
            writer.raw(attribute);
        }
        writer.into_bytes()
    }

    pub fn document_attribute_filename(file_name: &str) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::DOCUMENT_ATTRIBUTE_FILENAME);
        writer.string(file_name);
        writer.into_bytes()
    }

    pub fn document_attribute_image_size(width: i32, height: i32) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::DOCUMENT_ATTRIBUTE_IMAGE_SIZE);
        writer.i32(width);
        writer.i32(height);
        writer.into_bytes()
    }

    pub fn document_attribute_video(
        duration: f64,
        width: i32,
        height: i32,
        supports_streaming: bool,
    ) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::DOCUMENT_ATTRIBUTE_VIDEO);
        let mut flags = 0;
        if supports_streaming {
            flags |= 1 << 1;
        }
        writer.u32(flags);
        writer.f64(duration);
        writer.i32(width);
        writer.i32(height);
        writer.into_bytes()
    }

    pub fn document_attribute_animated() -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::DOCUMENT_ATTRIBUTE_ANIMATED);
        writer.into_bytes()
    }

    pub fn document_attribute_audio(
        voice: bool,
        duration: i32,
        title: &str,
        performer: &str,
        waveform: &[u8],
    ) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::DOCUMENT_ATTRIBUTE_AUDIO);
        let mut flags = 0u32;
        if voice {
            flags |= 1 << 10;
        }
        if !title.is_empty() {
            flags |= 1 << 0;
        }
        if !performer.is_empty() {
            flags |= 1 << 1;
        }
        if !waveform.is_empty() {
            flags |= 1 << 2;
        }
        writer.u32(flags);
        writer.i32(duration);
        if !title.is_empty() {
            writer.string(title);
        }
        if !performer.is_empty() {
            writer.string(performer);
        }
        if !waveform.is_empty() {
            writer.bytes(waveform);
        }
        writer.into_bytes()
    }

    /// `upload.file#96a18d5`.
    pub fn upload_file(storage_type: u32, mtime: i32, bytes: &[u8]) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::UPLOAD_FILE);
        writer.u32(storage_type);
        writer.i32(mtime);
        writer.bytes(bytes);
        writer.into_bytes()
    }

    pub fn peer_channel(channel_id: i64) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::PEER_CHANNEL);
        writer.i64(channel_id);
        writer.into_bytes()
    }

    pub fn peer_chat(chat_id: i64) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::PEER_CHAT);
        writer.i64(chat_id);
        writer.into_bytes()
    }

    /// `chatPhoto#1c6e1c11`.
    pub fn chat_photo(photo_id: i64, dc_id: i32) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::CHAT_PHOTO);
        writer.u32(0); // flags
        writer.i64(photo_id);
        writer.i32(dc_id);
        writer.into_bytes()
    }

    pub fn chat(
        chat_id: i64,
        title: &str,
        creator: bool,
        participants_count: i32,
        date: i32,
        photo: Option<&[u8]>,
    ) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::CHAT);
        let mut flags = 0u32;
        if creator {
            flags |= 1 << 0;
        }
        writer.u32(flags);
        writer.i64(chat_id);
        writer.string(title);
        match photo {
            Some(photo) => {
                writer.raw(photo);
            }
            None => {
                writer.u32(ctor::CHAT_PHOTO_EMPTY);
            }
        }
        writer.i32(participants_count);
        writer.i32(date);
        writer.i32(1); // version
        writer.into_bytes()
    }

    pub fn chat_participant_creator(user_id: i64) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::CHAT_PARTICIPANT_CREATOR);
        writer.u32(0); // flags
        writer.i64(user_id);
        writer.into_bytes()
    }

    pub fn chat_participant(user_id: i64, inviter_id: i64, date: i32) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::CHAT_PARTICIPANT);
        writer.u32(0); // flags
        writer.i64(user_id);
        writer.i64(inviter_id);
        writer.i32(date);
        writer.into_bytes()
    }

    pub fn chat_participants(chat_id: i64, version: i32, participants: &[Vec<u8>]) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::CHAT_PARTICIPANTS);
        writer.i64(chat_id);
        writer.u32(ctor::VECTOR);
        writer.i32(participants.len() as i32);
        for participant in participants {
            writer.raw(participant);
        }
        writer.i32(version);
        writer.into_bytes()
    }

    pub fn chat_full_minimal(
        chat_id: i64,
        about: &str,
        participants: &[Vec<u8>],
        photo: Option<&[u8]>,
    ) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::CHAT_FULL);
        writer.u32(if photo.is_some() { 1 << 4 } else { 0 });
        writer.i64(chat_id);
        writer.string(about);
        writer.raw(&chat_participants(chat_id, 1, participants));
        if let Some(photo) = photo {
            writer.raw(photo);
        }
        writer.raw(&peer_notify_settings());
        writer.into_bytes()
    }

    pub fn messages_chats(chats: &[Vec<u8>]) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::MESSAGES_CHATS);
        writer.u32(ctor::VECTOR);
        writer.i32(chats.len() as i32);
        for chat in chats {
            writer.raw(chat);
        }
        writer.into_bytes()
    }

    #[allow(clippy::too_many_arguments)]
    pub fn message_chat_ext(
        id: i32,
        out: bool,
        from_user_id: i64,
        chat_id: i64,
        date: i32,
        text: &str,
        media: Option<&[u8]>,
        extras: &MessageExtras,
    ) -> Vec<u8> {
        message_with_peer_media(
            id,
            out,
            from_user_id,
            &peer_chat(chat_id),
            date,
            text,
            media,
            extras,
        )
    }

    #[allow(clippy::too_many_arguments)]
    pub fn message_service(
        id: i32,
        out: bool,
        from_user_id: i64,
        chat_id: i64,
        date: i32,
        action: &[u8],
    ) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::MESSAGE_SERVICE);
        writer.u32((1 << 8) | if out { 1 << 1 } else { 0 });
        writer.i32(id);
        writer.raw(&peer_user(from_user_id));
        writer.raw(&peer_chat(chat_id));
        writer.i32(date);
        writer.raw(action);
        writer.into_bytes()
    }

    pub fn message_action_chat_create(title: &str, users: &[i64]) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::MESSAGE_ACTION_CHAT_CREATE);
        writer.string(title);
        writer.u32(ctor::VECTOR);
        writer.i32(users.len() as i32);
        for user_id in users {
            writer.i64(*user_id);
        }
        writer.into_bytes()
    }

    pub fn message_action_chat_edit_title(title: &str) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::MESSAGE_ACTION_CHAT_EDIT_TITLE);
        writer.string(title);
        writer.into_bytes()
    }

    pub fn message_action_chat_add_user(users: &[i64]) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::MESSAGE_ACTION_CHAT_ADD_USER);
        writer.u32(ctor::VECTOR);
        writer.i32(users.len() as i32);
        for user_id in users {
            writer.i64(*user_id);
        }
        writer.into_bytes()
    }

    pub fn message_action_chat_delete_user(user_id: i64) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::MESSAGE_ACTION_CHAT_DELETE_USER);
        writer.i64(user_id);
        writer.into_bytes()
    }

    pub fn message_chat(
        id: i32,
        out: bool,
        from_user_id: i64,
        chat_id: i64,
        date: i32,
        text: &str,
    ) -> Vec<u8> {
        message_chat_ext(
            id,
            out,
            from_user_id,
            chat_id,
            date,
            text,
            None,
            &MessageExtras::default(),
        )
    }

    #[allow(clippy::too_many_arguments)]
    pub fn message_chat_media(
        id: i32,
        out: bool,
        from_user_id: i64,
        chat_id: i64,
        date: i32,
        text: &str,
        media: &[u8],
    ) -> Vec<u8> {
        message_chat_ext(
            id,
            out,
            from_user_id,
            chat_id,
            date,
            text,
            Some(media),
            &MessageExtras::default(),
        )
    }

    pub fn input_channel(channel_id: i64, access_hash: i64) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::INPUT_CHANNEL);
        writer.i64(channel_id);
        writer.i64(access_hash);
        writer.into_bytes()
    }

    #[allow(clippy::too_many_arguments)]
    pub fn channel(
        id: i64,
        access_hash: i64,
        title: &str,
        username: &str,
        is_broadcast: bool,
        is_megagroup: bool,
        creator: bool,
        admin_rights: Option<&[u8]>,
        banned_rights: Option<&[u8]>,
        participants_count: i32,
        date: i32,
        photo: Option<&[u8]>,
    ) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::CHANNEL);
        let mut flags = (1u32 << 13) | (1u32 << 17);
        if creator {
            flags |= 1 << 0;
        }
        if is_broadcast {
            flags |= 1 << 5;
        }
        if is_megagroup {
            flags |= 1 << 8;
        }
        if !username.is_empty() {
            flags |= 1 << 6;
        }
        if admin_rights.is_some() {
            flags |= 1 << 14;
        }
        if banned_rights.is_some() {
            flags |= 1 << 15;
        }
        writer.u32(flags);
        writer.u32(0); // flags2
        writer.i64(id);
        writer.i64(access_hash);
        writer.string(title);
        if !username.is_empty() {
            writer.string(username);
        }
        match photo {
            Some(photo) => {
                writer.raw(photo);
            }
            None => {
                writer.u32(ctor::CHAT_PHOTO_EMPTY);
            }
        }
        writer.i32(date);
        if let Some(rights) = admin_rights {
            writer.raw(rights);
        }
        if let Some(rights) = banned_rights {
            writer.raw(rights);
        }
        writer.i32(participants_count);
        writer.into_bytes()
    }

    #[allow(clippy::too_many_arguments)]
    pub fn channel_full(
        id: i64,
        about: &str,
        participants_count: i32,
        read_inbox_max_id: i32,
        read_outbox_max_id: i32,
        unread_count: i32,
        pinned_msg_id: i64,
        pts: i32,
    ) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::CHANNEL_FULL);
        let mut flags = 1 << 0; // participants_count
        if pinned_msg_id > 0 {
            flags |= 1 << 5;
        }
        writer.u32(flags);
        writer.u32(0); // flags2
        writer.i64(id);
        writer.string(about);
        writer.i32(participants_count);
        writer.i32(read_inbox_max_id);
        writer.i32(read_outbox_max_id);
        writer.i32(unread_count);
        // photoEmpty
        writer.u32(ctor::PHOTO_EMPTY);
        writer.i64(0);
        writer.raw(&peer_notify_settings());
        // bot_info vector
        writer.u32(ctor::VECTOR);
        writer.i32(0);
        if flags & (1 << 5) != 0 {
            writer.i32(pinned_msg_id as i32);
        }
        writer.i32(pts);
        writer.into_bytes()
    }

    pub fn messages_chat_full(full_chat: &[u8], chats: &[Vec<u8>], users: &[Vec<u8>]) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::MESSAGES_CHAT_FULL);
        writer.raw(full_chat);
        writer.u32(ctor::VECTOR);
        writer.i32(chats.len() as i32);
        for chat in chats {
            writer.raw(chat);
        }
        writer.u32(ctor::VECTOR);
        writer.i32(users.len() as i32);
        for user in users {
            writer.raw(user);
        }
        writer.into_bytes()
    }

    pub fn channel_participant(user_id: i64, date: i32) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::CHANNEL_PARTICIPANT);
        writer.u32(0); // flags
        writer.i64(user_id);
        writer.i32(date);
        writer.into_bytes()
    }

    pub fn chat_admin_rights(flags: u32) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::CHAT_ADMIN_RIGHTS);
        writer.u32(flags);
        writer.into_bytes()
    }

    /// All standard administrator rights, used for owners and full admins.
    pub fn chat_admin_rights_full() -> Vec<u8> {
        // change_info, post/edit/delete messages, ban, invite, pin, add
        // admins, anonymous, manage calls and "other".
        let flags = (1 << 0)
            | (1 << 1)
            | (1 << 2)
            | (1 << 3)
            | (1 << 4)
            | (1 << 5)
            | (1 << 7)
            | (1 << 9)
            | (1 << 10)
            | (1 << 11)
            | (1 << 12);
        chat_admin_rights(flags)
    }

    pub fn chat_banned_rights(flags: u32, until_date: i32) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::CHAT_BANNED_RIGHTS);
        writer.u32(flags);
        writer.i32(until_date);
        writer.into_bytes()
    }

    pub fn channel_participant_creator(user_id: i64, rights: &[u8], rank: &str) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::CHANNEL_PARTICIPANT_CREATOR);
        let mut flags = 0u32;
        if !rank.is_empty() {
            flags |= 1 << 0;
        }
        writer.u32(flags);
        writer.i64(user_id);
        writer.raw(rights);
        if !rank.is_empty() {
            writer.string(rank);
        }
        writer.into_bytes()
    }

    #[allow(clippy::too_many_arguments)]
    pub fn channel_participant_admin(
        user_id: i64,
        inviter_id: i64,
        promoted_by: i64,
        date: i32,
        rights: &[u8],
        rank: &str,
        is_self: bool,
    ) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::CHANNEL_PARTICIPANT_ADMIN);
        let mut flags = 1 << 0; // can_edit
        if is_self {
            // `self` and the optional `inviter_id` share bit 1.
            flags |= 1 << 1;
        }
        if !rank.is_empty() {
            flags |= 1 << 2;
        }
        writer.u32(flags);
        writer.i64(user_id);
        if is_self {
            writer.i64(inviter_id);
        }
        writer.i64(promoted_by);
        writer.i32(date);
        writer.raw(rights);
        if !rank.is_empty() {
            writer.string(rank);
        }
        writer.into_bytes()
    }

    pub fn channel_participant_banned(
        user_id: i64,
        kicked_by: i64,
        date: i32,
        rights: &[u8],
        rank: &str,
        left: bool,
    ) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::CHANNEL_PARTICIPANT_BANNED);
        let mut flags = 0u32;
        if left {
            flags |= 1 << 0;
        }
        if !rank.is_empty() {
            flags |= 1 << 2;
        }
        writer.u32(flags);
        writer.raw(&peer_user(user_id));
        writer.i64(kicked_by);
        writer.i32(date);
        writer.raw(rights);
        if !rank.is_empty() {
            writer.string(rank);
        }
        writer.into_bytes()
    }

    pub fn channels_channel_participants(
        count: i32,
        participants: &[Vec<u8>],
        chats: &[Vec<u8>],
        users: &[Vec<u8>],
    ) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::CHANNELS_CHANNEL_PARTICIPANTS);
        writer.i32(count);
        writer.u32(ctor::VECTOR);
        writer.i32(participants.len() as i32);
        for participant in participants {
            writer.raw(participant);
        }
        writer.u32(ctor::VECTOR);
        writer.i32(chats.len() as i32);
        for chat in chats {
            writer.raw(chat);
        }
        writer.u32(ctor::VECTOR);
        writer.i32(users.len() as i32);
        for user in users {
            writer.raw(user);
        }
        writer.into_bytes()
    }

    pub fn update_channel(channel_id: i64) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::UPDATE_CHANNEL);
        writer.i64(channel_id);
        writer.into_bytes()
    }

    pub fn update_chat_participants(participants: &[u8]) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::UPDATE_CHAT_PARTICIPANTS);
        writer.raw(participants);
        writer.into_bytes()
    }

    pub fn reaction_emoji(emoticon: &str) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::REACTION_EMOJI);
        writer.string(emoticon);
        writer.into_bytes()
    }

    pub fn reaction_count(reaction: &[u8], count: i32, chosen: bool) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::REACTION_COUNT);
        writer.u32(if chosen { 1 } else { 0 });
        if chosen {
            writer.i32(0); // chosen_order
        }
        writer.raw(reaction);
        writer.i32(count);
        writer.into_bytes()
    }

    pub fn message_reactions(results: &[Vec<u8>]) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::MESSAGE_REACTIONS);
        writer.u32(0); // flags
        writer.u32(ctor::VECTOR);
        writer.i32(results.len() as i32);
        for result in results {
            writer.raw(result);
        }
        writer.into_bytes()
    }

    pub fn update_message_reactions(peer: &[u8], msg_id: i32, reactions: &[u8]) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::UPDATE_MESSAGE_REACTIONS);
        writer.u32(0); // flags
        writer.raw(peer);
        writer.i32(msg_id);
        writer.raw(reactions);
        writer.into_bytes()
    }

    pub fn update_new_scheduled_message(message: &[u8]) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::UPDATE_NEW_SCHEDULED_MESSAGE);
        writer.raw(message);
        writer.into_bytes()
    }

    pub fn update_delete_scheduled_messages(
        peer: &[u8],
        ids: &[i32],
        sent: Option<&[i32]>,
    ) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::UPDATE_DELETE_SCHEDULED_MESSAGES);
        writer.u32(if sent.is_some() { 1 } else { 0 });
        writer.raw(peer);
        writer.u32(ctor::VECTOR);
        writer.i32(ids.len() as i32);
        for id in ids {
            writer.i32(*id);
        }
        if let Some(sent) = sent {
            writer.u32(ctor::VECTOR);
            writer.i32(sent.len() as i32);
            for id in sent {
                writer.i32(*id);
            }
        }
        writer.into_bytes()
    }

    pub fn update_new_channel_message(message: &[u8], pts: i32) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::UPDATE_NEW_CHANNEL_MESSAGE);
        writer.raw(message);
        writer.i32(pts);
        writer.i32(1);
        writer.into_bytes()
    }

    pub fn chat_invite_join_result_ok(updates: &[u8]) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::MESSAGES_CHAT_INVITE_JOIN_RESULT_OK);
        writer.raw(updates);
        writer.into_bytes()
    }

    pub fn messages_invited_users(updates: &[u8]) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::MESSAGES_INVITED_USERS);
        writer.raw(updates);
        writer.u32(ctor::VECTOR);
        writer.i32(0);
        writer.into_bytes()
    }

    pub fn dialog(peer: &[u8], top_message: i32, unread_count: i32) -> Vec<u8> {
        dialog_ext(peer, top_message, unread_count, false)
    }

    pub fn dialog_ext(
        peer: &[u8],
        top_message: i32,
        unread_count: i32,
        pinned: bool,
    ) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::DIALOG);
        writer.u32(if pinned { 1 << 2 } else { 0 });
        writer.raw(peer);
        writer.i32(top_message);
        writer.i32(top_message); // read_inbox_max_id
        writer.i32(top_message); // read_outbox_max_id
        writer.i32(unread_count);
        writer.i32(0); // unread_mentions_count
        writer.i32(0); // unread_reactions_count
        writer.i32(0); // unread_poll_votes_count
        writer.raw(&peer_notify_settings());
        writer.into_bytes()
    }

    pub fn draft_message(text: &str, reply_to: i64, date: i32) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::DRAFT_MESSAGE);
        writer.u32(if reply_to > 0 { 1 << 4 } else { 0 });
        if reply_to > 0 {
            writer.u32(ctor::INPUT_REPLY_TO_MESSAGE);
            writer.u32(0); // flags
            writer.i32(reply_to as i32);
        }
        writer.string(text);
        writer.i32(date);
        writer.into_bytes()
    }

    pub fn update_draft_message(peer: &[u8], text: &str, reply_to: i64, date: i32) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::UPDATE_DRAFT_MESSAGE);
        writer.u32(0); // flags
        writer.raw(peer);
        writer.raw(&draft_message(text, reply_to, date));
        writer.into_bytes()
    }

    pub fn update_new_message(message: &[u8], pts: i32) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::UPDATE_NEW_MESSAGE);
        writer.raw(message);
        writer.i32(pts);
        writer.i32(1);
        writer.into_bytes()
    }

    pub fn update_message_id(id: i32, random_id: i64) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::UPDATE_MESSAGE_ID);
        writer.i32(id);
        writer.i64(random_id);
        writer.into_bytes()
    }

    pub fn update_edit_message(message: &[u8], pts: i32, pts_count: i32) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::UPDATE_EDIT_MESSAGE);
        writer.raw(message);
        writer.i32(pts);
        writer.i32(pts_count);
        writer.into_bytes()
    }

    pub fn update_edit_channel_message(message: &[u8], pts: i32, pts_count: i32) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::UPDATE_EDIT_CHANNEL_MESSAGE);
        writer.raw(message);
        writer.i32(pts);
        writer.i32(pts_count);
        writer.into_bytes()
    }

    pub fn update_delete_messages(ids: &[i32], pts: i32, pts_count: i32) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::UPDATE_DELETE_MESSAGES);
        writer.u32(ctor::VECTOR);
        writer.i32(ids.len() as i32);
        for id in ids {
            writer.i32(*id);
        }
        writer.i32(pts);
        writer.i32(pts_count);
        writer.into_bytes()
    }

    pub fn update_delete_channel_messages(
        channel_id: i64,
        ids: &[i32],
        pts: i32,
        pts_count: i32,
    ) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::UPDATE_DELETE_CHANNEL_MESSAGES);
        writer.i64(channel_id);
        writer.u32(ctor::VECTOR);
        writer.i32(ids.len() as i32);
        for id in ids {
            writer.i32(*id);
        }
        writer.i32(pts);
        writer.i32(pts_count);
        writer.into_bytes()
    }

    pub fn update_pinned_messages(
        pinned: bool,
        peer: &[u8],
        ids: &[i32],
        pts: i32,
        pts_count: i32,
    ) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::UPDATE_PINNED_MESSAGES);
        writer.u32(if pinned { 1 << 0 } else { 0 });
        writer.raw(peer);
        writer.u32(ctor::VECTOR);
        writer.i32(ids.len() as i32);
        for id in ids {
            writer.i32(*id);
        }
        writer.i32(pts);
        writer.i32(pts_count);
        writer.into_bytes()
    }

    pub fn update_pinned_channel_messages(
        pinned: bool,
        channel_id: i64,
        ids: &[i32],
        pts: i32,
        pts_count: i32,
    ) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::UPDATE_PINNED_CHANNEL_MESSAGES);
        writer.u32(if pinned { 1 << 0 } else { 0 });
        writer.i64(channel_id);
        writer.u32(ctor::VECTOR);
        writer.i32(ids.len() as i32);
        for id in ids {
            writer.i32(*id);
        }
        writer.i32(pts);
        writer.i32(pts_count);
        writer.into_bytes()
    }

    pub fn updates(updates: &[Vec<u8>], users: &[Vec<u8>], date: i32, seq: i32) -> Vec<u8> {
        updates_with_chats(updates, users, &[], date, seq)
    }

    pub fn updates_with_chats(
        updates: &[Vec<u8>],
        users: &[Vec<u8>],
        chats: &[Vec<u8>],
        date: i32,
        seq: i32,
    ) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::UPDATES);
        writer.u32(ctor::VECTOR);
        writer.i32(updates.len() as i32);
        for update in updates {
            writer.raw(update);
        }
        writer.u32(ctor::VECTOR);
        writer.i32(users.len() as i32);
        for user in users {
            writer.raw(user);
        }
        writer.u32(ctor::VECTOR);
        writer.i32(chats.len() as i32);
        for chat in chats {
            writer.raw(chat);
        }
        writer.i32(date);
        writer.i32(seq);
        writer.into_bytes()
    }

    pub fn messages_messages(
        messages: &[Vec<u8>],
        chats: &[Vec<u8>],
        users: &[Vec<u8>],
    ) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::MESSAGES_MESSAGES);
        writer.u32(ctor::VECTOR);
        writer.i32(messages.len() as i32);
        for message in messages {
            writer.raw(message);
        }
        // topics
        writer.u32(ctor::VECTOR);
        writer.i32(0);
        // chats
        writer.u32(ctor::VECTOR);
        writer.i32(chats.len() as i32);
        for chat in chats {
            writer.raw(chat);
        }
        // users
        writer.u32(ctor::VECTOR);
        writer.i32(users.len() as i32);
        for user in users {
            writer.raw(user);
        }
        writer.into_bytes()
    }

    pub fn messages_dialogs(
        dialogs: &[Vec<u8>],
        messages: &[Vec<u8>],
        chats: &[Vec<u8>],
        users: &[Vec<u8>],
    ) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::MESSAGES_DIALOGS);
        writer.u32(ctor::VECTOR);
        writer.i32(dialogs.len() as i32);
        for dialog in dialogs {
            writer.raw(dialog);
        }
        writer.u32(ctor::VECTOR);
        writer.i32(messages.len() as i32);
        for message in messages {
            writer.raw(message);
        }
        writer.u32(ctor::VECTOR);
        writer.i32(chats.len() as i32);
        for chat in chats {
            writer.raw(chat);
        }
        writer.u32(ctor::VECTOR);
        writer.i32(users.len() as i32);
        for user in users {
            writer.raw(user);
        }
        writer.into_bytes()
    }

    pub fn messages_peer_dialogs(
        dialogs: &[Vec<u8>],
        messages: &[Vec<u8>],
        chats: &[Vec<u8>],
        users: &[Vec<u8>],
        state: &[u8],
    ) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::MESSAGES_PEER_DIALOGS);
        writer.u32(ctor::VECTOR);
        writer.i32(dialogs.len() as i32);
        for dialog in dialogs {
            writer.raw(dialog);
        }
        writer.u32(ctor::VECTOR);
        writer.i32(messages.len() as i32);
        for message in messages {
            writer.raw(message);
        }
        writer.u32(ctor::VECTOR);
        writer.i32(chats.len() as i32);
        for chat in chats {
            writer.raw(chat);
        }
        writer.u32(ctor::VECTOR);
        writer.i32(users.len() as i32);
        for user in users {
            writer.raw(user);
        }
        writer.raw(state);
        writer.into_bytes()
    }

    pub fn messages_affected_messages(pts: i32, pts_count: i32) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::MESSAGES_AFFECTED_MESSAGES);
        writer.i32(pts);
        writer.i32(pts_count);
        writer.into_bytes()
    }

    pub fn messages_affected_history(pts: i32, pts_count: i32, offset: i32) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::MESSAGES_AFFECTED_HISTORY);
        writer.i32(pts);
        writer.i32(pts_count);
        writer.i32(offset);
        writer.into_bytes()
    }

    pub fn user_empty(id: i64) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::USER_EMPTY);
        writer.i64(id);
        writer.into_bytes()
    }

    pub fn peer_settings() -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::PEER_SETTINGS);
        writer.u32(0);
        writer.into_bytes()
    }

    pub fn peer_notify_settings() -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::PEER_NOTIFY_SETTINGS);
        writer.u32(0);
        writer.into_bytes()
    }

    /// Minimal `messages.peerSettings#6880b94d`.
    pub fn messages_peer_settings() -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::MESSAGES_PEER_SETTINGS);
        writer.raw(&peer_settings());
        writer.u32(ctor::VECTOR);
        writer.i32(0);
        writer.u32(ctor::VECTOR);
        writer.i32(0);
        writer.into_bytes()
    }

    pub fn messages_featured_stickers_not_modified(count: i32) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::MESSAGES_FEATURED_STICKERS_NOT_MODIFIED);
        writer.i32(count);
        writer.into_bytes()
    }

    /// `inputStickerSetID#9de7a269`.
    pub fn input_sticker_set_id(id: i64, access_hash: i64) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::INPUT_STICKER_SET_ID);
        writer.i64(id);
        writer.i64(access_hash);
        writer.into_bytes()
    }

    /// `documentAttributeSticker#6319d612` without mask coordinates.
    pub fn document_attribute_sticker(alt: &str, set_id: i64, set_access_hash: i64) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::DOCUMENT_ATTRIBUTE_STICKER);
        writer.u32(0); // flags
        writer.string(alt);
        writer.raw(&input_sticker_set_id(set_id, set_access_hash));
        writer.into_bytes()
    }

    /// `documentAttributeCustomEmoji#fd149899`.
    pub fn document_attribute_custom_emoji(
        alt: &str,
        set_id: i64,
        set_access_hash: i64,
        text_color: bool,
    ) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::DOCUMENT_ATTRIBUTE_CUSTOM_EMOJI);
        writer.u32(u32::from(text_color) << 1);
        writer.string(alt);
        writer.raw(&input_sticker_set_id(set_id, set_access_hash));
        writer.into_bytes()
    }

    /// `stickerset#2dd14edc` with explicit flags / count / hash.
    pub fn sticker_set(
        id: i64,
        access_hash: i64,
        title: &str,
        short_name: &str,
        flags: u32,
        count: i32,
        hash: i32,
    ) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::STICKER_SET);
        writer.u32(flags);
        writer.i64(id);
        writer.i64(access_hash);
        writer.string(title);
        writer.string(short_name);
        writer.i32(count);
        writer.i32(hash);
        writer.into_bytes()
    }

    /// `stickerPack#12b299d4`.
    pub fn sticker_pack(emoticon: &str, document_ids: &[i64]) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::STICKER_PACK);
        writer.string(emoticon);
        writer.u32(ctor::VECTOR);
        writer.i32(document_ids.len() as i32);
        for id in document_ids {
            writer.i64(*id);
        }
        writer.into_bytes()
    }

    pub fn messages_sticker_set(set: &[u8], packs: &[Vec<u8>], documents: &[Vec<u8>]) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::MESSAGES_STICKER_SET);
        writer.raw(set);
        writer.u32(ctor::VECTOR);
        writer.i32(packs.len() as i32);
        for pack in packs {
            writer.raw(pack);
        }
        writer.u32(ctor::VECTOR);
        writer.i32(0); // keywords
        writer.u32(ctor::VECTOR);
        writer.i32(documents.len() as i32);
        for document in documents {
            writer.raw(document);
        }
        writer.into_bytes()
    }

    /// `messages.stickers#30a6ec7e`.
    pub fn messages_stickers(hash: i64, documents: &[Vec<u8>]) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::MESSAGES_STICKERS);
        writer.i64(hash);
        writer.u32(ctor::VECTOR);
        writer.i32(documents.len() as i32);
        for document in documents {
            writer.raw(document);
        }
        writer.into_bytes()
    }

    /// `messages.allStickers#cdbbcebb`.
    pub fn messages_all_stickers(hash: i64, sets: &[Vec<u8>]) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(0xcdbb_cebb);
        writer.i64(hash);
        writer.u32(ctor::VECTOR);
        writer.i32(sets.len() as i32);
        for set in sets {
            writer.raw(set);
        }
        writer.into_bytes()
    }

    /// `vector<Document>` for `messages.getCustomEmojiDocuments`.
    pub fn document_vector(documents: &[Vec<u8>]) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::VECTOR);
        writer.i32(documents.len() as i32);
        for document in documents {
            writer.raw(document);
        }
        writer.into_bytes()
    }

    /// `emojiStatus#e7ff068a`.
    pub fn emoji_status(document_id: i64) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::EMOJI_STATUS);
        writer.u32(0);
        writer.i64(document_id);
        writer.into_bytes()
    }

    pub fn user_status_online(expires: i32) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::USER_STATUS_ONLINE);
        writer.i32(expires);
        writer.into_bytes()
    }

    pub fn user_status_offline(was_online: i32) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::USER_STATUS_OFFLINE);
        writer.i32(was_online);
        writer.into_bytes()
    }

    pub fn user_status_recently() -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::USER_STATUS_RECENTLY);
        writer.u32(0); // flags: by_me not set
        writer.into_bytes()
    }

    pub fn update_user_status(user_id: i64, status: &[u8]) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::UPDATE_USER_STATUS);
        writer.i64(user_id);
        writer.raw(status);
        writer.into_bytes()
    }

    pub fn update_user_typing(user_id: i64, top_msg_id: Option<i32>, action: &[u8]) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::UPDATE_USER_TYPING);
        let mut flags = 0u32;
        if top_msg_id.is_some() {
            flags |= 1;
        }
        writer.u32(flags);
        writer.i64(user_id);
        if let Some(top_msg_id) = top_msg_id {
            writer.i32(top_msg_id);
        }
        writer.raw(action);
        writer.into_bytes()
    }

    /// Serialises a `SendMessageAction` from the constructor and optional
    /// progress value received in `messages.setTyping`.
    pub fn send_message_action(con: u32, progress: Option<i32>) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(con);
        if let Some(progress) = progress {
            writer.i32(progress);
        }
        writer.into_bytes()
    }

    pub fn update_chat_user_typing(chat_id: i64, from_id: &[u8], action: &[u8]) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::UPDATE_CHAT_USER_TYPING);
        writer.i64(chat_id);
        writer.raw(from_id);
        writer.raw(action);
        writer.into_bytes()
    }

    pub fn update_channel_user_typing(
        channel_id: i64,
        top_msg_id: Option<i32>,
        from_id: &[u8],
        action: &[u8],
    ) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::UPDATE_CHANNEL_USER_TYPING);
        let mut flags = 0u32;
        if top_msg_id.is_some() {
            flags |= 1;
        }
        writer.u32(flags);
        writer.i64(channel_id);
        if let Some(top_msg_id) = top_msg_id {
            writer.i32(top_msg_id);
        }
        writer.raw(from_id);
        writer.raw(action);
        writer.into_bytes()
    }

    pub fn update_read_history_inbox(
        peer: &[u8],
        max_id: i32,
        still_unread_count: i32,
        pts: i32,
        pts_count: i32,
    ) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::UPDATE_READ_HISTORY_INBOX);
        writer.u32(0); // flags: no folder / top_msg_id
        writer.raw(peer);
        writer.i32(max_id);
        writer.i32(still_unread_count);
        writer.i32(pts);
        writer.i32(pts_count);
        writer.into_bytes()
    }

    pub fn update_read_history_outbox(peer: &[u8], max_id: i32, pts: i32, pts_count: i32) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::UPDATE_READ_HISTORY_OUTBOX);
        writer.raw(peer);
        writer.i32(max_id);
        writer.i32(pts);
        writer.i32(pts_count);
        writer.into_bytes()
    }

    pub fn update_read_channel_inbox(
        channel_id: i64,
        max_id: i32,
        still_unread_count: i32,
        pts: i32,
    ) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::UPDATE_READ_CHANNEL_INBOX);
        writer.u32(0); // flags: no folder
        writer.i64(channel_id);
        writer.i32(max_id);
        writer.i32(still_unread_count);
        writer.i32(pts);
        writer.into_bytes()
    }

    pub fn update_read_channel_outbox(channel_id: i64, max_id: i32) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::UPDATE_READ_CHANNEL_OUTBOX);
        writer.i64(channel_id);
        writer.i32(max_id);
        writer.into_bytes()
    }

    /// `updateUserEmojiStatus#28373599`.
    pub fn update_user_emoji_status(user_id: i64, document_id: i64) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::UPDATE_USER_EMOJI_STATUS);
        writer.i64(user_id);
        writer.raw(&emoji_status(document_id));
        writer.into_bytes()
    }

    pub fn help_peer_colors_not_modified() -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::HELP_PEER_COLORS_NOT_MODIFIED);
        writer.into_bytes()
    }

    pub fn help_countries_list_not_modified() -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::HELP_COUNTRIES_LIST_NOT_MODIFIED);
        writer.into_bytes()
    }

    pub fn messages_dialog_filters() -> Vec<u8> {
        messages_dialog_filters_with(&[])
    }

    pub fn messages_dialog_filters_with(filters: &[Vec<u8>]) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::MESSAGES_DIALOG_FILTERS);
        writer.u32(0); // flags
        writer.u32(ctor::VECTOR);
        writer.i32(filters.len() as i32);
        for filter in filters {
            writer.raw(filter);
        }
        writer.into_bytes()
    }

    pub fn contacts_top_peers_not_modified() -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::CONTACTS_TOP_PEERS_NOT_MODIFIED);
        writer.into_bytes()
    }

    pub fn messages_available_reactions_not_modified() -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::MESSAGES_AVAILABLE_REACTIONS_NOT_MODIFIED);
        writer.into_bytes()
    }

    pub fn attach_menu_bots_not_modified() -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::ATTACH_MENU_BOTS_NOT_MODIFIED);
        writer.into_bytes()
    }

    pub fn messages_emoji_groups_not_modified() -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::MESSAGES_EMOJI_GROUPS_NOT_MODIFIED);
        writer.into_bytes()
    }

    pub fn messages_quick_replies_not_modified() -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::MESSAGES_QUICK_REPLIES_NOT_MODIFIED);
        writer.into_bytes()
    }

    pub fn account_emoji_statuses_not_modified() -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::ACCOUNT_EMOJI_STATUSES_NOT_MODIFIED);
        writer.into_bytes()
    }

    pub fn account_themes_not_modified() -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::ACCOUNT_THEMES_NOT_MODIFIED);
        writer.into_bytes()
    }

    pub fn help_promo_data_empty(expires: i32) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::HELP_PROMO_DATA_EMPTY);
        writer.i32(expires);
        writer.into_bytes()
    }

    pub fn user_full(id: i64, about: &str, birthday: Option<(i32, i32, i32)>) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::USER_FULL);
        let mut flags = 0u32;
        if !about.is_empty() {
            flags |= 1 << 1;
        }
        let mut flags2 = 0u32;
        if birthday.is_some() {
            flags2 |= 1 << 5;
        }
        writer.u32(flags);
        writer.u32(flags2);
        writer.i64(id);
        if !about.is_empty() {
            writer.string(about);
        }
        writer.raw(&peer_settings());
        writer.raw(&peer_notify_settings());
        writer.i32(0); // common_chats_count
        if let Some((day, month, year)) = birthday {
            writer.u32(ctor::BIRTHDAY);
            writer.u32(if year > 0 { 1 } else { 0 });
            writer.i32(day);
            writer.i32(month);
            if year > 0 {
                writer.i32(year);
            }
        }
        writer.into_bytes()
    }

    pub fn users_user_full(full_user: &[u8]) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::USERS_USER_FULL);
        writer.raw(full_user);
        writer.u32(ctor::VECTOR);
        writer.i32(0); // chats
        writer.u32(ctor::VECTOR);
        writer.i32(0); // users
        writer.into_bytes()
    }

    pub fn contacts_blocked(
        blocked: &[Vec<u8>],
        chats: &[Vec<u8>],
        users: &[Vec<u8>],
    ) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::CONTACTS_BLOCKED);
        for list in [blocked, chats, users] {
            writer.u32(ctor::VECTOR);
            writer.i32(list.len() as i32);
            for item in list {
                writer.raw(item);
            }
        }
        writer.into_bytes()
    }

    pub fn peer_blocked(peer: &[u8], date: i32) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::PEER_BLOCKED);
        writer.raw(peer);
        writer.i32(date);
        writer.into_bytes()
    }

    pub fn contacts_contacts(contacts: &[Vec<u8>], users: &[Vec<u8>]) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::CONTACTS_CONTACTS);
        writer.u32(ctor::VECTOR);
        writer.i32(contacts.len() as i32);
        for contact in contacts {
            writer.raw(contact);
        }
        writer.i32(contacts.len() as i32); // saved_count
        writer.u32(ctor::VECTOR);
        writer.i32(users.len() as i32);
        for user in users {
            writer.raw(user);
        }
        writer.into_bytes()
    }

    pub fn contacts_resolved_peer(peer: &[u8], chats: &[Vec<u8>], users: &[Vec<u8>]) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::CONTACTS_RESOLVED_PEER);
        writer.raw(peer);
        writer.u32(ctor::VECTOR);
        writer.i32(chats.len() as i32);
        for chat in chats {
            writer.raw(chat);
        }
        writer.u32(ctor::VECTOR);
        writer.i32(users.len() as i32);
        for user in users {
            writer.raw(user);
        }
        writer.into_bytes()
    }

    pub fn messages_dialogs_empty() -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::MESSAGES_DIALOGS);
        for _ in 0..4 {
            writer.u32(ctor::VECTOR);
            writer.i32(0);
        }
        writer.into_bytes()
    }

    pub fn messages_peer_dialogs_empty() -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::MESSAGES_PEER_DIALOGS);
        for _ in 0..4 {
            writer.u32(ctor::VECTOR);
            writer.i32(0);
        }
        writer.raw(&updates_state(0, 0, 0, 0, 0));
        writer.into_bytes()
    }

    pub fn messages_stickers_empty(hash: i64) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::MESSAGES_STICKERS);
        writer.i64(hash);
        writer.u32(ctor::VECTOR);
        writer.i32(0);
        writer.into_bytes()
    }

    pub fn stories_all_stories_empty() -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::STORIES_ALL_STORIES);
        writer.u32(0); // flags
        writer.i32(0); // count
        writer.string(""); // state
        for _ in 0..3 {
            writer.u32(ctor::VECTOR);
            writer.i32(0);
        }
        // stealth_mode
        writer.u32(ctor::STORIES_STEALTH_MODE);
        writer.u32(0);
        writer.into_bytes()
    }

    pub fn help_premium_promo_empty() -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::HELP_PREMIUM_PROMO);
        writer.string("");
        for _ in 0..5 {
            writer.u32(ctor::VECTOR);
            writer.i32(0);
        }
        writer.into_bytes()
    }

    pub fn updates_state(pts: i32, qts: i32, date: i32, seq: i32, unread_count: i32) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::UPDATES_STATE);
        writer.i32(pts);
        writer.i32(qts);
        writer.i32(date);
        writer.i32(seq);
        writer.i32(unread_count);
        writer.into_bytes()
    }

    pub fn updates_difference_empty(date: i32, seq: i32) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::UPDATES_DIFFERENCE_EMPTY);
        writer.i32(date);
        writer.i32(seq);
        writer.into_bytes()
    }

    #[allow(clippy::too_many_arguments)]
    pub fn updates_difference(
        new_messages: &[Vec<u8>],
        other_updates: &[Vec<u8>],
        chats: &[Vec<u8>],
        users: &[Vec<u8>],
        state: &[u8],
    ) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::UPDATES_DIFFERENCE);
        write_vectors(&mut writer, new_messages, other_updates, chats, users);
        writer.raw(state);
        writer.into_bytes()
    }

    #[allow(clippy::too_many_arguments)]
    pub fn updates_difference_slice(
        new_messages: &[Vec<u8>],
        other_updates: &[Vec<u8>],
        chats: &[Vec<u8>],
        users: &[Vec<u8>],
        intermediate_state: &[u8],
    ) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::UPDATES_DIFFERENCE_SLICE);
        write_vectors(&mut writer, new_messages, other_updates, chats, users);
        writer.raw(intermediate_state);
        writer.into_bytes()
    }

    pub fn updates_difference_too_long(pts: i32) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::UPDATES_DIFFERENCE_TOO_LONG);
        writer.i32(pts);
        writer.into_bytes()
    }

    pub fn updates_channel_difference_empty(pts: i32, timeout: i32) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::UPDATES_CHANNEL_DIFFERENCE_EMPTY);
        writer.u32(0); // flags: no final, no timeout
        writer.i32(pts);
        let _ = timeout;
        writer.into_bytes()
    }

    pub fn updates_channel_difference_too_long(
        final_difference: bool,
        timeout: Option<i32>,
        dialog: &[u8],
        messages: &[Vec<u8>],
        chats: &[Vec<u8>],
        users: &[Vec<u8>],
    ) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::UPDATES_CHANNEL_DIFFERENCE_TOO_LONG);
        let mut flags = 0;
        if final_difference {
            flags |= 1 << 0;
        }
        if timeout.is_some() {
            flags |= 1 << 1;
        }
        writer.u32(flags);
        if let Some(timeout) = timeout {
            writer.i32(timeout);
        }
        writer.raw(dialog);
        writer.u32(ctor::VECTOR);
        writer.i32(messages.len() as i32);
        for message in messages {
            writer.raw(message);
        }
        writer.u32(ctor::VECTOR);
        writer.i32(chats.len() as i32);
        for chat in chats {
            writer.raw(chat);
        }
        writer.u32(ctor::VECTOR);
        writer.i32(users.len() as i32);
        for user in users {
            writer.raw(user);
        }
        writer.into_bytes()
    }

    pub fn updates_channel_difference(
        final_difference: bool,
        pts: i32,
        timeout: Option<i32>,
        new_messages: &[Vec<u8>],
        other_updates: &[Vec<u8>],
        chats: &[Vec<u8>],
        users: &[Vec<u8>],
    ) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::UPDATES_CHANNEL_DIFFERENCE);
        let mut flags = 0;
        if final_difference {
            flags |= 1 << 0;
        }
        if timeout.is_some() {
            flags |= 1 << 1;
        }
        writer.u32(flags);
        writer.i32(pts);
        if let Some(timeout) = timeout {
            writer.i32(timeout);
        }
        // new_messages is the only encrypted vector here.
        writer.u32(ctor::VECTOR);
        writer.i32(new_messages.len() as i32);
        for message in new_messages {
            writer.raw(message);
        }
        write_update_vectors(&mut writer, other_updates, chats, users);
        writer.into_bytes()
    }

    fn write_vectors(
        writer: &mut Writer,
        new_messages: &[Vec<u8>],
        other_updates: &[Vec<u8>],
        chats: &[Vec<u8>],
        users: &[Vec<u8>],
    ) {
        writer.u32(ctor::VECTOR);
        writer.i32(new_messages.len() as i32);
        for message in new_messages {
            writer.raw(message);
        }
        // new_encrypted_messages
        writer.u32(ctor::VECTOR);
        writer.i32(0);
        write_update_vectors(writer, other_updates, chats, users);
    }

    fn write_update_vectors(
        writer: &mut Writer,
        other_updates: &[Vec<u8>],
        chats: &[Vec<u8>],
        users: &[Vec<u8>],
    ) {
        writer.u32(ctor::VECTOR);
        writer.i32(other_updates.len() as i32);
        for update in other_updates {
            writer.raw(update);
        }
        writer.u32(ctor::VECTOR);
        writer.i32(chats.len() as i32);
        for chat in chats {
            writer.raw(chat);
        }
        writer.u32(ctor::VECTOR);
        writer.i32(users.len() as i32);
        for user in users {
            writer.raw(user);
        }
    }

    pub fn nearest_dc(country: &str, this_dc: i32, nearest_dc: i32) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::HELP_NEAREST_DC);
        writer.string(country);
        writer.i32(this_dc);
        writer.i32(nearest_dc);
        writer.into_bytes()
    }

    pub fn help_invite_text(message: &str) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::HELP_INVITE_TEXT);
        writer.string(message);
        writer.into_bytes()
    }

    pub fn app_config_not_modified() -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::HELP_APP_CONFIG_NOT_MODIFIED);
        writer.into_bytes()
    }

    pub fn terms_of_service_update_empty(expires: i32) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::HELP_TERMS_OF_SERVICE_UPDATE_EMPTY);
        writer.i32(expires);
        writer.into_bytes()
    }

    pub fn help_support(user: &[u8]) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::HELP_SUPPORT);
        writer.string("");
        writer.raw(user);
        writer.into_bytes()
    }

    /// One entry of `account.authorizations`.
    pub struct Authorization {
        pub hash: i64,
        pub current: bool,
        pub device_model: String,
        pub platform: String,
        pub system_version: String,
        pub api_id: i32,
        pub app_name: String,
        pub app_version: String,
        pub date_created: i32,
        pub date_active: i32,
        pub ip: String,
        pub country: String,
        pub region: String,
    }

    pub fn account_authorizations(authorizations: &[Authorization]) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::ACCOUNT_AUTHORIZATIONS);
        writer.i32(0); // authorization_ttl_days
        writer.u32(ctor::VECTOR);
        writer.i32(authorizations.len() as i32);
        for authorization in authorizations {
            writer.u32(ctor::AUTHORIZATION);
            writer.u32(if authorization.current { 1 } else { 0 });
            writer.i64(authorization.hash);
            writer.string(&authorization.device_model);
            writer.string(&authorization.platform);
            writer.string(&authorization.system_version);
            writer.i32(authorization.api_id);
            writer.string(&authorization.app_name);
            writer.string(&authorization.app_version);
            writer.i32(authorization.date_created);
            writer.i32(authorization.date_active);
            writer.string(&authorization.ip);
            writer.string(&authorization.country);
            writer.string(&authorization.region);
        }
        writer.into_bytes()
    }

    /// Source of reaction notifications (`ReactionNotificationsFrom`).
    #[derive(Debug, Clone, Copy, PartialEq, Eq)]
    pub enum NotifyFrom {
        Contacts,
        All,
    }

    /// `NotificationSound`.
    #[derive(Debug, Clone, PartialEq, Eq)]
    pub enum NotificationSound {
        Default,
        None,
        Local { title: String, data: String },
        Ringtone { id: i64 },
    }

    /// `reactionsNotifySettings#71e4ea58`.
    #[derive(Debug, Clone, PartialEq, Eq)]
    pub struct ReactionsNotifySettings {
        pub messages_notify_from: Option<NotifyFrom>,
        pub stories_notify_from: Option<NotifyFrom>,
        pub poll_votes_notify_from: Option<NotifyFrom>,
        pub sound: NotificationSound,
        pub show_previews: bool,
    }

    impl Default for ReactionsNotifySettings {
        fn default() -> Self {
            Self {
                messages_notify_from: None,
                stories_notify_from: None,
                poll_votes_notify_from: None,
                sound: NotificationSound::Default,
                show_previews: true,
            }
        }
    }

    pub fn reactions_notify_settings(settings: &ReactionsNotifySettings) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::REACTIONS_NOTIFY_SETTINGS);
        let mut flags = 0u32;
        if settings.messages_notify_from.is_some() {
            flags |= 1 << 0;
        }
        if settings.stories_notify_from.is_some() {
            flags |= 1 << 1;
        }
        if settings.poll_votes_notify_from.is_some() {
            flags |= 1 << 2;
        }
        writer.u32(flags);
        let notify_from_ctor = |value: NotifyFrom| match value {
            NotifyFrom::Contacts => ctor::REACTION_NOTIFICATIONS_FROM_CONTACTS,
            NotifyFrom::All => ctor::REACTION_NOTIFICATIONS_FROM_ALL,
        };
        if let Some(value) = settings.messages_notify_from {
            writer.u32(notify_from_ctor(value));
        }
        if let Some(value) = settings.stories_notify_from {
            writer.u32(notify_from_ctor(value));
        }
        if let Some(value) = settings.poll_votes_notify_from {
            writer.u32(notify_from_ctor(value));
        }
        match &settings.sound {
            NotificationSound::Default => {
                writer.u32(ctor::NOTIFICATION_SOUND_DEFAULT);
            }
            NotificationSound::None => {
                writer.u32(ctor::NOTIFICATION_SOUND_NONE);
            }
            NotificationSound::Local { title, data } => {
                writer.u32(ctor::NOTIFICATION_SOUND_LOCAL);
                writer.string(title);
                writer.string(data);
            }
            NotificationSound::Ringtone { id } => {
                writer.u32(ctor::NOTIFICATION_SOUND_RINGTONE);
                writer.i64(*id);
            }
        }
        writer.u32(if settings.show_previews {
            ctor::BOOL_TRUE
        } else {
            ctor::BOOL_FALSE
        });
        writer.into_bytes()
    }

    pub fn bool_false() -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::BOOL_FALSE);
        writer.into_bytes()
    }

    pub fn messages_message_views_empty() -> Vec<u8> {
        messages_message_views(&[], &[], &[])
    }

    /// `messages.messageViews#b6c4f543` with per-message view counters.
    pub fn messages_message_views(
        views: &[i32],
        chats: &[Vec<u8>],
        users: &[Vec<u8>],
    ) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::MESSAGES_MESSAGE_VIEWS);
        writer.u32(ctor::VECTOR);
        writer.i32(views.len() as i32);
        for count in views {
            writer.u32(ctor::MESSAGE_VIEWS);
            writer.u32(1 << 0);
            writer.i32(*count);
        }
        for list in [chats, users] {
            writer.u32(ctor::VECTOR);
            writer.i32(list.len() as i32);
            for item in list {
                writer.raw(item);
            }
        }
        writer.into_bytes()
    }

    pub fn channels_send_as_peers_empty() -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::CHANNELS_SEND_AS_PEERS);
        for _ in 0..3 {
            writer.u32(ctor::VECTOR);
            writer.i32(0);
        }
        writer.into_bytes()
    }

    pub fn payments_currency_rates_empty() -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::PAYMENTS_CURRENCY_RATES);
        writer.u32(ctor::VECTOR);
        writer.i32(0);
        writer.into_bytes()
    }

    pub fn account_privacy_rules_empty() -> Vec<u8> {
        account_privacy_rules(&[])
    }

    pub fn account_privacy_rules(rules: &[Vec<u8>]) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::ACCOUNT_PRIVACY_RULES);
        writer.u32(ctor::VECTOR);
        writer.i32(rules.len() as i32);
        for rule in rules {
            writer.raw(rule);
        }
        for _ in 0..2 {
            writer.u32(ctor::VECTOR);
            writer.i32(0);
        }
        writer.into_bytes()
    }

    pub fn privacy_value_allow_all() -> Vec<u8> {
        bare(ctor::PRIVACY_VALUE_ALLOW_ALL)
    }

    pub fn privacy_value_allow_contacts() -> Vec<u8> {
        bare(ctor::PRIVACY_VALUE_ALLOW_CONTACTS)
    }

    pub fn privacy_value_disallow_all() -> Vec<u8> {
        bare(ctor::PRIVACY_VALUE_DISALLOW_ALL)
    }

    pub fn privacy_value_disallow_contacts() -> Vec<u8> {
        bare(ctor::PRIVACY_VALUE_DISALLOW_CONTACTS)
    }

    pub fn privacy_value_allow_users(user_ids: &[i64]) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::PRIVACY_VALUE_ALLOW_USERS);
        writer.vector(user_ids, |writer, id| {
            writer.i64(*id);
        });
        writer.into_bytes()
    }

    pub fn privacy_value_disallow_users(user_ids: &[i64]) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::PRIVACY_VALUE_DISALLOW_USERS);
        writer.vector(user_ids, |writer, id| {
            writer.i64(*id);
        });
        writer.into_bytes()
    }

    pub fn account_web_authorizations_empty() -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::ACCOUNT_WEB_AUTHORIZATIONS);
        for _ in 0..2 {
            writer.u32(ctor::VECTOR);
            writer.i32(0);
        }
        writer.into_bytes()
    }

    pub fn contacts_blocked_empty() -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::CONTACTS_BLOCKED);
        for _ in 0..3 {
            writer.u32(ctor::VECTOR);
            writer.i32(0);
        }
        writer.into_bytes()
    }

    pub fn stories_albums_empty(hash: i64) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::STORIES_ALBUMS);
        writer.i64(hash);
        writer.u32(ctor::VECTOR);
        writer.i32(0);
        writer.into_bytes()
    }

    pub fn payments_saved_star_gifts_empty() -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::PAYMENTS_SAVED_STAR_GIFTS);
        writer.u32(0); // flags
        writer.i32(0); // count
        writer.u32(ctor::VECTOR);
        writer.i32(0);
        for _ in 0..2 {
            writer.u32(ctor::VECTOR);
            writer.i32(0);
        }
        writer.into_bytes()
    }

    /// Constructor-only response (not-modified and empty result types).
    pub fn bare(constructor: u32) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(constructor);
        writer.into_bytes()
    }

    /// `passwordKdfAlgoSHA256SHA256PBKDF2HMACSHA512iter100000SHA256ModPow#3a912d4a`
    pub fn password_kdf_algo_sha256(salt1: &[u8], salt2: &[u8], g: i32, p: &[u8]) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::PASSWORD_KDF_ALGO_SHA256_SHA256_PBKDF2_HMAC_SHA512_ITER_100000_SHA256_MOD_POW);
        writer.bytes(salt1);
        writer.bytes(salt2);
        writer.i32(g);
        writer.bytes(p);
        writer.into_bytes()
    }

    /// `securePasswordKdfAlgoPBKDF2HMACSHA512iter100000#bbf2dda0`
    pub fn secure_password_kdf_algo_pbkdf2(salt: &[u8]) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::SECURE_PASSWORD_KDF_ALGO_PBKDF2_HMAC_SHA512_ITER_100000);
        writer.bytes(salt);
        writer.into_bytes()
    }

    /// `account.password#957b50fb`
    ///
    /// `current_algo` 为 `None` 表示未启用两步验证；`new_algo` 始终由服务器
    /// 提供新的盐，供客户端创建新密码时使用。
    pub fn account_password(
        current_algo: Option<&[u8]>,
        srp_b: &[u8],
        srp_id: i64,
        hint: &str,
        new_algo: &[u8],
        new_secure_algo: &[u8],
        secure_random: &[u8],
    ) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::ACCOUNT_PASSWORD);
        let mut flags = 0u32;
        if current_algo.is_some() {
            flags |= 1 << 2; // has_password
        }
        if !hint.is_empty() {
            flags |= 1 << 3;
        }
        writer.u32(flags);
        if let Some(algo) = current_algo {
            writer.raw(algo);
            writer.bytes(srp_b);
            writer.i64(srp_id);
        }
        if !hint.is_empty() {
            writer.string(hint);
        }
        writer.raw(new_algo);
        writer.raw(new_secure_algo);
        writer.bytes(secure_random);
        writer.into_bytes()
    }

    /// `account.passwordSettings#9a5c33e5`，未配置恢复邮箱与 Passport。
    pub fn account_password_settings() -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::ACCOUNT_PASSWORD_SETTINGS);
        writer.u32(0);
        writer.into_bytes()
    }

    pub fn account_content_settings(
        sensitive_enabled: bool,
        sensitive_can_change: bool,
    ) -> Vec<u8> {
        let mut flags = 0u32;
        if sensitive_enabled {
            flags |= 1 << 0;
        }
        if sensitive_can_change {
            flags |= 1 << 1;
        }
        let mut writer = Writer::new();
        writer.u32(ctor::ACCOUNT_CONTENT_SETTINGS);
        writer.u32(flags);
        writer.into_bytes()
    }

    pub fn global_privacy_settings_default() -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::GLOBAL_PRIVACY_SETTINGS);
        writer.u32(0);
        writer.into_bytes()
    }

    pub fn messages_web_page_empty(id: i64) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::WEB_PAGE_EMPTY);
        writer.u32(0);
        writer.i64(id);
        writer.into_bytes()
    }

    pub fn account_emoji_statuses(hash: i64, statuses: &[Vec<u8>]) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::ACCOUNT_EMOJI_STATUSES);
        writer.i64(hash);
        writer.u32(ctor::VECTOR);
        writer.i32(statuses.len() as i32);
        for status in statuses {
            writer.raw(status);
        }
        writer.into_bytes()
    }

    pub fn payments_star_gift_active_auctions_empty() -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::PAYMENTS_STAR_GIFT_ACTIVE_AUCTIONS);
        for _ in 0..3 {
            writer.u32(ctor::VECTOR);
            writer.i32(0);
        }
        writer.into_bytes()
    }

    pub fn stories_stories_empty() -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::STORIES_STORIES);
        writer.u32(0); // flags
        writer.i32(0); // count
        for _ in 0..3 {
            writer.u32(ctor::VECTOR);
            writer.i32(0);
        }
        writer.into_bytes()
    }

    pub fn aicompose_tones(hash: i64) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::AICOMPOSE_TONES);
        writer.i64(hash);
        for _ in 0..2 {
            writer.u32(ctor::VECTOR);
            writer.i32(0);
        }
        writer.into_bytes()
    }

    pub fn default_history_ttl(period: i32) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::DEFAULT_HISTORY_TTL);
        writer.i32(period);
        writer.into_bytes()
    }

    pub fn emoji_languages(lang_codes: &[String]) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::VECTOR);
        writer.i32(lang_codes.len() as i32);
        for code in lang_codes {
            writer.u32(ctor::EMOJI_LANGUAGE);
            writer.string(code);
        }
        writer.into_bytes()
    }

    #[allow(clippy::too_many_arguments)]
    pub fn chat_invite_exported(
        link: &str,
        admin_id: i64,
        date: i32,
        expire_date: i32,
        usage_limit: i32,
        usage: i32,
        request_needed: bool,
        title: &str,
    ) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::CHAT_INVITE_EXPORTED);
        let mut flags = 0u32;
        if expire_date > 0 {
            flags |= 1 << 1;
        }
        if usage_limit > 0 {
            flags |= 1 << 2;
        }
        if usage > 0 {
            flags |= 1 << 3;
        }
        if request_needed {
            flags |= 1 << 6;
        }
        if !title.is_empty() {
            flags |= 1 << 8;
        }
        writer.u32(flags);
        writer.string(link);
        writer.i64(admin_id);
        writer.i32(date);
        if expire_date > 0 {
            writer.i32(expire_date);
        }
        if usage_limit > 0 {
            writer.i32(usage_limit);
        }
        if usage > 0 {
            writer.i32(usage);
        }
        if !title.is_empty() {
            writer.string(title);
        }
        writer.into_bytes()
    }

    #[allow(clippy::too_many_arguments)]
    pub fn chat_invite(
        channel: bool,
        broadcast: bool,
        megagroup: bool,
        title: &str,
        about: &str,
        photo: Option<&[u8]>,
        participants_count: i32,
        participants: Option<&[Vec<u8>]>,
        request_needed: bool,
    ) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::CHAT_INVITE);
        let mut flags = 0u32;
        if channel {
            flags |= 1 << 0;
        }
        if broadcast {
            flags |= 1 << 1;
        }
        if megagroup {
            flags |= 1 << 3;
        }
        if request_needed {
            flags |= 1 << 6;
        }
        if !about.is_empty() {
            flags |= 1 << 5;
        }
        if participants.is_some() {
            flags |= 1 << 4;
        }
        writer.u32(flags);
        writer.string(title);
        if !about.is_empty() {
            writer.string(about);
        }
        match photo {
            Some(photo) => {
                writer.raw(photo);
            }
            None => {
                writer.u32(ctor::PHOTO_EMPTY);
            }
        }
        writer.i32(participants_count);
        if let Some(participants) = participants {
            writer.u32(ctor::VECTOR);
            writer.i32(participants.len() as i32);
            for user in participants {
                writer.raw(user);
            }
        }
        writer.i32(0); // color
        writer.into_bytes()
    }

    pub fn chat_invite_already(chat: &[u8]) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::CHAT_INVITE_ALREADY);
        writer.raw(chat);
        writer.into_bytes()
    }

    pub fn emoji_keywords_difference(lang_code: &str, from_version: i32, version: i32) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::EMOJI_KEYWORDS_DIFFERENCE);
        writer.string(lang_code);
        writer.i32(from_version);
        writer.i32(version);
        writer.u32(ctor::VECTOR);
        writer.i32(0);
        writer.into_bytes()
    }

    pub fn lang_pack_difference(lang_code: &str, version: i32) -> Vec<u8> {
        lang_pack_difference_strings(lang_code, 0, version, &[])
    }

    pub fn lang_pack_difference_strings(
        lang_code: &str,
        from_version: i32,
        version: i32,
        strings: &[Vec<u8>],
    ) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::LANG_PACK_DIFFERENCE);
        writer.string(lang_code);
        writer.i32(from_version);
        writer.i32(version);
        writer.u32(ctor::VECTOR);
        writer.i32(strings.len() as i32);
        for string in strings {
            writer.raw(string);
        }
        writer.into_bytes()
    }

    pub fn lang_pack_string(key: &str, value: &str) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::LANG_PACK_STRING);
        writer.string(key);
        writer.string(value);
        writer.into_bytes()
    }

    pub fn lang_pack_string_pluralized(key: &str, one: Option<&str>, other: &str) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::LANG_PACK_STRING_PLURALIZED);
        let mut flags = 0u32;
        if one.is_some() {
            flags |= 1 << 1;
        }
        writer.u32(flags);
        writer.string(key);
        if let Some(one) = one {
            writer.string(one);
        }
        writer.string(other);
        writer.into_bytes()
    }

    /// `langPackLanguage` with the `official` flag set.
    #[allow(clippy::too_many_arguments)]
    pub fn lang_pack_language(
        name: &str,
        native_name: &str,
        lang_code: &str,
        plural_code: &str,
        strings_count: i32,
        translated_count: i32,
        translations_url: &str,
    ) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::LANG_PACK_LANGUAGE);
        writer.u32(1); // official
        writer.string(name);
        writer.string(native_name);
        writer.string(lang_code);
        writer.string(plural_code);
        writer.i32(strings_count);
        writer.i32(translated_count);
        writer.string(translations_url);
        writer.into_bytes()
    }

    pub fn lang_pack_languages_empty() -> Vec<u8> {
        lang_pack_vector(&[])
    }

    pub fn lang_pack_languages(languages: &[Vec<u8>]) -> Vec<u8> {
        lang_pack_vector(languages)
    }

    pub fn lang_pack_strings(strings: &[Vec<u8>]) -> Vec<u8> {
        lang_pack_vector(strings)
    }

    fn lang_pack_vector(items: &[Vec<u8>]) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::VECTOR);
        writer.i32(items.len() as i32);
        for item in items {
            writer.raw(item);
        }
        writer.into_bytes()
    }

    pub fn destroy_session_none(session_id: i64) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::DESTROY_SESSION_NONE);
        writer.i64(session_id);
        writer.into_bytes()
    }

    pub fn lang_pack_strings_empty() -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::VECTOR);
        writer.i32(0);
        writer.into_bytes()
    }

    pub fn dc_option(id: i32, ip: &str, port: i32) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::DC_OPTION);
        writer.u32(0); // flags
        writer.i32(id);
        writer.string(ip);
        writer.i32(port);
        writer.into_bytes()
    }

    /// Minimal `config#cc1a241e` that lets clients discover this server.
    pub fn config(this_dc: i32, ip: &str, port: i32, date: i32) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::HELP_CONFIG);
        writer.u32(0); // flags
        writer.i32(date);
        writer.i32(date.saturating_add(86_400));
        writer.bool(false); // test_mode
        writer.i32(this_dc);
        writer.u32(ctor::VECTOR);
        writer.i32(1);
        writer.raw(&dc_option(this_dc, ip, port));
        writer.string(""); // dc_txt_domain_name
        writer.i32(2000); // chat_size_max
        writer.i32(2000); // megagroup_size_max
        writer.i32(100); // forwarded_count_max
        writer.i32(3000); // online_update_period_ms
        writer.i32(30000); // offline_blur_timeout_ms
        writer.i32(30000); // offline_idle_timeout_ms
        writer.i32(30000); // online_cloud_timeout_ms
        writer.i32(5000); // notify_cloud_delay_ms
        writer.i32(30000); // notify_default_delay_ms
        writer.i32(5000); // push_chat_period_ms
        writer.i32(2); // push_chat_limit
        writer.i32(172800); // edit_time_limit
        writer.i32(172800); // revoke_time_limit
        writer.i32(172800); // revoke_pm_time_limit
        writer.i32(100); // rating_e_decay
        writer.i32(200); // stickers_recent_limit
        writer.i32(30); // channels_read_media_period
        writer.i32(30000); // call_receive_timeout_ms
        writer.i32(30000); // call_ring_timeout_ms
        writer.i32(30000); // call_connect_timeout_ms
        writer.i32(2000); // call_packet_timeout_ms
        writer.string("https://t.me/"); // me_url_prefix
        writer.i32(1024); // caption_length_max
        writer.i32(4096); // message_length_max
        writer.i32(this_dc); // webfile_dc_id
        writer.into_bytes()
    }
}

/// Client-side exchange payloads.
pub mod exchange {
    use super::{ctor, Int128, Int256, Writer};

    pub fn p_q_inner_data(
        pq: &[u8],
        p: &[u8],
        q: &[u8],
        nonce: &Int128,
        server_nonce: &Int128,
        new_nonce: &Int256,
    ) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(0x83c95aec);
        writer.bytes(pq);
        writer.bytes(p);
        writer.bytes(q);
        writer.int128(nonce);
        writer.int128(server_nonce);
        writer.int256(new_nonce);
        writer.into_bytes()
    }

    pub fn p_q_inner_data_temp(
        pq: &[u8],
        p: &[u8],
        q: &[u8],
        nonce: &Int128,
        server_nonce: &Int128,
        new_nonce: &Int256,
        expires_in: i32,
    ) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(0x3c6a84d4);
        writer.bytes(pq);
        writer.bytes(p);
        writer.bytes(q);
        writer.int128(nonce);
        writer.int128(server_nonce);
        writer.int256(new_nonce);
        writer.i32(expires_in);
        writer.into_bytes()
    }

    pub fn server_dh_inner_data(
        nonce: &Int128,
        server_nonce: &Int128,
        g: i32,
        dh_prime: &[u8],
        g_a: &[u8],
        server_time: i32,
    ) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(0xb5890dba);
        writer.int128(nonce);
        writer.int128(server_nonce);
        writer.i32(g);
        writer.bytes(dh_prime);
        writer.bytes(g_a);
        writer.i32(server_time);
        writer.into_bytes()
    }

    pub fn client_dh_inner_data(
        nonce: &Int128,
        server_nonce: &Int128,
        retry_id: i64,
        g_b: &[u8],
    ) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(0x6643b654);
        writer.int128(nonce);
        writer.int128(server_nonce);
        writer.i64(retry_id);
        writer.bytes(g_b);
        writer.into_bytes()
    }

    pub fn req_dh_params(
        nonce: &Int128,
        server_nonce: &Int128,
        p: &[u8],
        q: &[u8],
        fingerprint: i64,
        encrypted_data: &[u8],
    ) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::REQ_DH_PARAMS);
        writer.int128(nonce);
        writer.int128(server_nonce);
        writer.bytes(p);
        writer.bytes(q);
        writer.i64(fingerprint);
        writer.bytes(encrypted_data);
        writer.into_bytes()
    }

    pub fn set_client_dh_params(
        nonce: &Int128,
        server_nonce: &Int128,
        encrypted_data: &[u8],
    ) -> Vec<u8> {
        let mut writer = Writer::new();
        writer.u32(ctor::SET_CLIENT_DH_PARAMS);
        writer.int128(nonce);
        writer.int128(server_nonce);
        writer.bytes(encrypted_data);
        writer.into_bytes()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::types::{message, message_ext, MessageExtras};

    #[test]
    fn unencrypted_message_round_trip() {
        let message = UnencryptedMessage {
            message_id: 0x0102_0304_0506_0708,
            data: vec![1, 2, 3, 4],
        };
        let encoded = message.encode();
        assert_eq!(UnencryptedMessage::decode(&encoded).unwrap(), message);
    }

    #[test]
    fn container_round_trip() {
        let container = MessageContainer {
            messages: vec![ContainerMessage {
                message_id: 7,
                seq_no: 1,
                body: vec![9, 9, 9, 9],
            }],
        };
        let encoded = container.encode();
        assert_eq!(MessageContainer::decode(&encoded).unwrap(), container);
    }

    #[test]
    fn message_extras_set_expected_flags() {
        let extras = MessageExtras {
            reply_to_msg_id: Some(7),
            fwd_from_user_id: Some(8),
            fwd_from_chat_id: None,
            fwd_from_msg_id: None,
            fwd_date: 100,
            edit_date: 200,
            pinned: true,
            reactions: None,
            grouped_id: 12345,
            views: 42,
            entities: Vec::new(),
        };
        let bytes = message_ext(1, true, 8, 9, 100, "text", None, &extras);
        let mut reader = Reader::new(&bytes);
        assert_eq!(reader.constructor().unwrap(), ctor::MESSAGE);
        let flags = reader.u32().unwrap();
        assert_ne!(flags & (1 << 2), 0, "fwd_from flag");
        assert_ne!(flags & (1 << 3), 0, "reply flag");
        assert_ne!(flags & (1 << 15), 0, "edit_date flag");
        assert_ne!(flags & (1 << 24), 0, "pinned flag");
        assert_ne!(flags & (1 << 17), 0, "grouped_id flag");
        assert_ne!(flags & (1 << 10), 0, "views flag");
        assert_eq!(reader.u32().unwrap(), 0, "flags2");
    }

    #[test]
    fn message_extras_are_absent_by_default() {
        let bytes = message(1, false, 8, 9, 100, "text");
        let mut reader = Reader::new(&bytes);
        assert_eq!(reader.constructor().unwrap(), ctor::MESSAGE);
        let flags = reader.u32().unwrap();
        assert_eq!(flags & (1 << 2), 0, "fwd_from flag");
        assert_eq!(flags & (1 << 3), 0, "reply flag");
        assert_eq!(flags & (1 << 15), 0, "edit_date flag");
    }

    #[test]
    fn message_entities_are_serialized_after_text() {
        let mut entity = Writer::new();
        entity.u32(0xbd61_0bc9); // messageEntityBold
        entity.i32(0);
        entity.i32(4);
        let entity = entity.into_bytes();
        let extras = MessageExtras {
            entities: vec![entity.clone()],
            ..MessageExtras::default()
        };
        let bytes = message_ext(1, false, 8, 9, 100, "bold", None, &extras);
        let mut reader = Reader::new(&bytes);
        assert_eq!(reader.constructor().unwrap(), ctor::MESSAGE);
        let flags = reader.u32().unwrap();
        assert_ne!(flags & (1 << 7), 0, "entities flag");
        let _flags2 = reader.u32().unwrap();
        let _id = reader.i32().unwrap();
        let _from = reader.constructor().unwrap();
        let _from_id = reader.i64().unwrap();
        let _peer = reader.constructor().unwrap();
        let _peer_id = reader.i64().unwrap();
        let _date = reader.i32().unwrap();
        let _text = reader.string().unwrap();
        assert_eq!(reader.constructor().unwrap(), ctor::VECTOR);
        assert_eq!(reader.i32().unwrap(), 1);
        assert_eq!(reader.u32().unwrap(), 0xbd61_0bc9);
        assert_eq!(reader.i32().unwrap(), 0);
        assert_eq!(reader.i32().unwrap(), 4);
        assert_eq!(entity.len(), 12);
    }

    #[test]
    fn only_self_user_carries_the_self_flag() {
        let self_user = types::user(1, 2, "Smoke", "User", "+14155550100");
        let other_user = types::user_other(2, 3, "Smoke", "Two", "+14155550101");
        let mut self_reader = Reader::new(&self_user);
        self_reader.expect_constructor(ctor::USER).unwrap();
        let self_flags = self_reader.u32().unwrap();
        let mut other_reader = Reader::new(&other_user);
        other_reader.expect_constructor(ctor::USER).unwrap();
        let other_flags = other_reader.u32().unwrap();
        assert_ne!(self_flags & (1 << 10), 0);
        assert_eq!(other_flags & (1 << 10), 0);
        assert_ne!(other_flags & (1 << 6), 0);
    }

    #[test]
    fn tl_bytes_use_compact_lengths_and_padding() {
        let mut writer = Writer::new();
        writer.bytes(&[1, 2, 3, 4]);
        assert_eq!(writer.into_bytes(), vec![4, 1, 2, 3, 4, 0, 0, 0]);

        let mut writer = Writer::new();
        writer.bytes(&[1, 2, 3]);
        let bytes = writer.into_bytes();
        assert_eq!(bytes, vec![3, 1, 2, 3]);
        let mut reader = Reader::new(&bytes);
        assert_eq!(reader.bytes().unwrap(), vec![1, 2, 3]);
        assert!(reader.is_empty());

        let long = vec![7u8; 254];
        let mut writer = Writer::new();
        writer.bytes(&long);
        let bytes = writer.into_bytes();
        assert_eq!(&bytes[..4], &[0xFE, 0xFE, 0, 0]);
        assert_eq!(bytes.len(), 260);
        let mut reader = Reader::new(&bytes);
        assert_eq!(reader.bytes().unwrap(), long);
    }

    #[test]
    fn vector_has_constructor_and_count() {
        let mut writer = Writer::new();
        writer.vector(&[1i64, 2], |writer, value| {
            writer.i64(*value);
        });
        let bytes = writer.into_bytes();
        assert_eq!(&bytes[..4], &ctor::VECTOR.to_le_bytes());
        assert_eq!(&bytes[4..8], &2i32.to_le_bytes());
        assert_eq!(bytes.len(), 24);
    }

    #[test]
    fn reader_rejects_truncated_long_strings() {
        let bytes = [0xFE, 1, 0, 0];
        let mut reader = Reader::new(&bytes);
        assert_eq!(reader.bytes().unwrap_err(), Error::UnexpectedEof);
    }
}
