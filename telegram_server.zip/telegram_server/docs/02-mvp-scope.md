# 第一版范围与 RPC 清单

## 1. 用户流程

### 1.1 登录

```text
客户端连接 127.0.0.1:3801
-> req_pq_multi
<- resPQ
-> req_DH_params
<- server_DH_params_ok
-> set_client_DH_params
<- dh_gen_ok
-> auth.sendCode
<- auth.sentCode
-> auth.signIn
<- auth.authorization
```

固定验证码：

```text
12345
```

### 1.2 注册

未注册手机号走：

```text
auth.signUp
```

第一版只要求填写名字和姓氏，不接短信。

### 1.3 私聊

- A 登录
- B 登录
- A 向 B 发文本
- B 收到 update
- A/B 的会话列表显示最后一条消息

### 1.4 群组

- 创建超级群
- 创建者自动成为成员
- 邀请另一个用户
- 两个用户都能看到历史和发文本

### 1.5 频道

- 创建广播频道
- 创建者发消息
- 普通用户订阅后能看到历史
- 普通用户不能发消息

### 1.6 图片 / 视频

- 上传 JPEG/PNG 图片
- 发送图片消息
- 对端下载并校验 sha256
- 视频按 MP4 文件上传/下载，不做在线播放

## 2. 第一版 RPC

以下是需要实现的最小集合。实际以客户端日志为准逐步补。

### 2.1 基础 / 配置

```text
help.getConfig
help.getNearestDc
help.getAppConfig
help.getInviteText
ping
```

### 2.2 登录 / 账号

```text
auth.sendCode
auth.signIn
auth.signUp
auth.logOut
account.getAuthorizations
account.getPassword
users.getUsers
users.getFullUser
```

### 2.3 会话 / 消息

```text
messages.getDialogs
messages.getPeerDialogs
messages.getHistory
messages.getMessages
messages.sendMessage
messages.readHistory
updates.getState
updates.getDifference
```

### 2.4 群组 / 频道

```text
channels.createChannel
channels.getFullChannel
channels.getParticipants
channels.inviteToChannel
channels.joinChannel
channels.leaveChannel
messages.sendMessage
messages.getHistory
```

### 2.5 媒体

```text
upload.saveFilePart
upload.saveBigFilePart
upload.getFile
messages.sendMedia
messages.uploadMedia
```

### 2.6 联系人

```text
contacts.resolveUsername
contacts.getContacts
```

### 2.7 语言包

```text
langpack.getLangPack
langpack.getLanguages
langpack.getStrings
```

第一版可以返回最小语言包或空结果，避免客户端因缺少语言包卡住。

## 3. 第一版不做

- 编辑 / 删除 / 转发消息
- 回复、引用、话题
- 表情回应、投票
- 管理员权限编辑
- 邀请链接
- 频道评论
- 置顶
- Bot
- 通知推送
- 多设备同步冲突处理
- 媒体缩略图以外的图片处理
- 视频转码和流式播放

## 4. 验收标准

### 4.1 协议

- 客户端完成 auth key 握手
- 客户端能登录
- 客户端主界面不白屏

### 4.2 私聊

- 两个账号能互相发送文本
- 双方断线重连后能看到历史
- 会话列表顺序正确

### 4.3 群组 / 频道

- 创建群组后能看到成员
- 创建频道后能发消息
- 非成员不能读取频道历史
- 普通成员不能在频道发消息

### 4.4 媒体

- 上传 1 张图片并发送
- 对端下载后 sha256 一致
- 上传 1 个 MP4 并发送
- 对端下载后 sha256 一致

### 4.5 稳定性

- 连续 30 分钟不崩溃
- 断线重连后不丢消息
- 同一账号第二个会话登录不破坏第一个会话

## 5. 客户端测试顺序

1. Rust 测试客户端
2. Telegram Desktop
3. Android
4. 桌面端 + Android 同时在线

## 6. 测试数据

```text
手机号 A：+1 415 555 0100
手机号 B：+1 415 555 0101
验证码：12345
```

测试账号只允许在 `telegram_server` 的 `test` schema 中创建。
