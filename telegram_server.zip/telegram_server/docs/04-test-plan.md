# 测试与冒烟方案

## 1. 测试分层

### 1.1 单元测试

- TL 类型序列化/反序列化
- RSA / AES-IGE / SHA / HMAC
- message id / seq / salt
- PTS 计算
- 媒体分片合并
- 错误码映射

### 1.2 仓储测试

使用独立测试 schema：

```text
telegram_server.test
```

覆盖：

- 用户创建/查询
- auth key 保存
- 会话列表
- 消息插入与历史查询
- 群组/频道成员
- update_events

### 1.3 协议集成测试

Rust 测试客户端直接连 `127.0.0.1:3801`：

```text
握手
登录
获取会话列表
发送私聊文本
获取历史
创建群组
邀请成员
创建频道
发频道消息
上传图片
下载图片
上传视频
下载视频
断线重连
```

### 1.4 客户端真机测试

AI 冒烟通过后：

1. Telegram Desktop 连接 `3801`
2. Android 连接 `3801`
3. 同时在线测试
4. 手工检查 UI 是否正常

## 2. AI 自动冒烟

### 2.1 隔离环境

- 端口：`3801`
- 数据库：`telegram_server` 的 `test` schema
- Redis：`DB 2`
- 媒体目录：`data/test-media`
- 不碰生产 `2398`、`telesrv_main`、`users/desktop-main`

### 2.2 脚本

第一次实现阶段加入：

```text
scripts/dev.ps1       启动本地 Rust 服务
scripts/test.ps1      创建/清空 test schema，跑 cargo test
scripts/smoke.ps1     启动服务 + 协议冒烟 + 关闭
```

`smoke.ps1` 返回非 0 表示失败。

### 2.3 冒烟用例

必须全部通过：

1. 服务启动，3801 可连接
2. `req_pq_multi` 有响应
3. auth key 握手成功
4. `auth.sendCode` 返回验证码
5. `auth.signIn` 成功
6. 登录后 `users.getUsers` 返回自己
7. A 给 B 发文本
8. B 的 `messages.getDialogs` 能看到会话
9. B 的 `messages.getHistory` 能看到消息
10. 创建群组成功
11. 邀请 B 成功
12. B 能看到群历史
13. 创建频道成功
14. 频道发消息成功
15. 普通成员不能发频道消息
16. 上传 1KB PNG 成功
17. 下载图片 sha256 一致
18. 上传 1KB 假 MP4 成功
19. 下载视频文件 sha256 一致
20. 断开重连后历史仍在
21. 第二个会话登录同一账号成功
22. 连续运行 30 分钟无崩溃

### 2.4 日志断言

- 无 panic
- 无未处理 RPC 错误洪泛
- 无数据库连接泄漏
- 无上传临时文件残留

## 3. 每阶段验收

| 阶段 | 自动化验收 |
|---|---|
| P0 骨架 | `cargo check` / `cargo test` 通过 |
| P1 握手登录 | 冒烟 1-6 |
| P2 私聊 | 冒烟 7-9、20-22 |
| P3 群组频道 | 冒烟 10-15 |
| P4 媒体 | 冒烟 16-19 |
| P5 客户端 | 桌面端 + Android 手工验收 |

## 4. 手工测试步骤

### 4.1 桌面端

1. 复制一份 endpoints：

```text
2 127.0.0.1 3801
```

2. 在桌面端登录页点击“服务器”
3. 地址填 `127.0.0.1`，端口填 `3801`
4. 保存并重启客户端
5. 用 `+1 415 555 0100` / `12345` 登录
6. 检查登录、会话、文本、图片、视频

### 4.2 Android

1. 打开 APK
2. 登录页点击“服务器”
3. 地址 `127.0.0.1` 或 `192.168.8.101`
4. 端口 `3801`
5. 使用同一测试账号登录
6. 与桌面端互发消息

### 4.3 双端同时在线

- 桌面端和 Android 同时登录同一账号
- 发送消息后另一端收到 update
- 断线重连后不丢历史

## 5. P1 验证记录（2026-11-03）

已通过：

- `cargo test --workspace`：16 个测试全部通过
- `cargo clippy --workspace --all-targets`：无错误、无警告
- `scripts/smoke.ps1`：健康检查、DB/Redis、3801、完整握手、`help.getConfig`、`auth.sendCode`、`auth.signIn` / `signUp`、`users.getUsers`、`messages.getDialogs`
- 真实 Telegram Desktop（独立 `tdata`，`2 127.0.0.1 3801`）：
  - 混淆传输握手成功
  - persistent + temporary auth key 建立成功
  - `auth.bindTempAuthKey` 成功
  - `help.getConfig`、`langpack.getLanguages`、`auth.sendCode`、`auth.signIn` 成功
  - 进入主界面（搜索框、主菜单、会话列表）

已知但属于后续阶段：

- 部分新版本 RPC（如 `stories.getAllStories`、`help.getPremiumPromo` 等）已返回空结果，其他未知 RPC 返回 `METHOD_NOT_FOUND`
- temporary auth key 绑定关系目前只返回 `boolTrue`，尚未持久化；P4 媒体阶段需要补绑定表

## 6. P2 验证记录（2026-11-03）

已通过：

- `cargo test --workspace`：16 个测试全部通过
- `cargo clippy --workspace --all-targets`：无错误、无警告
- `scripts/smoke.ps1`：
  - A/B 两个账号同时登录
  - A 发送 `hello from A to B`
  - B 实时收到 `updateNewMessage`
  - B `messages.getDialogs` 返回会话且未读数为 1
  - B `messages.getHistory` 返回消息
  - B `messages.readHistory` 后未读数变为 0
  - B 回复 `hello from B to A`
  - A 实时收到推送、历史正确
  - 双方会话列表最后一条消息正确
- 真实 Telegram Desktop：
  - 会话列表显示 `Smoke Two / hello from B to A / 1 new message`
  - 打开会话后显示双向消息、`Sent` / `Received` / `Seen` 状态
  - 历史消息与未读数正确

已知但属于后续阶段：

- `updates.getDifference` 目前返回空差量；断线后的完整增量同步由 `getDialogs` / `getHistory` 兜底
- 媒体仍是 P4

## 7. P3 验证记录（2026-11-03）

已通过：

- `cargo test --workspace`：16 个测试全部通过
- `cargo clippy --workspace --all-targets`：无错误、无警告
- `scripts/smoke.ps1`：
  - A 创建超级群，邀请 B
  - A 发群消息，B 实时收到推送
  - B 群会话列表、历史正确
  - B 回复群消息，A 实时收到推送、历史正确
  - A 创建广播频道，B `joinChannel`
  - `getParticipants` 返回 2 人
  - A 广播，B 实时收到并读取历史
  - B 向频道发送返回 `403 CHAT_WRITE_FORBIDDEN`
  - `getFullChannel` 返回成功
  - B 退出频道后读取历史返回 `403 CHANNEL_PRIVATE`
- 真实 Telegram Desktop：
  - 会话列表显示 `Group / P3 Group` 和 `Channel / P3 Channel`
  - 打开群显示双方消息和 `Seen`
  - 打开频道显示广播消息，所有者看到 `Broadcast a message...` 输入框

已知但属于后续阶段：

- 频道公开用户名、邀请链接、管理员权限编辑尚未实现
- 频道 `getFullChannel` 返回最小可用结构
- 媒体仍是 P4

## 8. P4 验证记录（2026-11-03）

已通过：

- `cargo test --workspace`：21 个测试全部通过（新增 PNG/JPEG/MP4 尺寸检测、storage.FileType 映射、user self flag）
- `cargo clippy --workspace --all-targets`：无错误、无警告
- `scripts/smoke.ps1`：
  - A 将 1×1 PNG 拆成 2 个分片上传（`upload.saveFilePart`）
  - A 调用 `messages.sendMedia` 发送照片，B 实时收到 `messageMediaPhoto`
  - B 用 `upload.getFile` + `inputPhotoFileLocation` 下载，字节与 sha256 一致
  - B 的历史消息同样携带照片媒体
  - A 用 `upload.saveBigFilePart` 分 4 片上传 MP4
  - A 发送 `inputMediaUploadedDocument`，B 收到 `messageMediaDocument` + `documentAttributeVideo`
  - B 下载 MP4，字节与 sha256 一致
  - A 向超级群发送照片，B 收到频道媒体推送并成功下载
- 真实 Telegram Desktop：
  - 会话列表预览显示 `Photo / group photo`、`Video / video caption`
  - 打开与 Smoke Two 的聊天显示 `Photo, 1×1`（含 caption）和 `Video, sample.mp4, 00:01, 640×480, 100 B`（含 caption）

已知但属于后续阶段：

- 未生成缩略图，照片仅返回单档 `photoSize("m")`（P8 已修复）
- 未下载的照片在桌面端显示下载箭头；`upload.getFileHashes` 返回空列表（P8 已修复）
- 视频编码本身未做校验，宽高/时长来自 MP4 `tkhd` / `mvhd`

## 9. P5 验证记录（2026-11-03）

已通过：

- `cargo test --workspace`：21 个测试全部通过
- `cargo clippy --workspace --all-targets`：无错误、无警告
- `scripts/smoke.ps1`：P2/P3/P4 全量用例通过
- 对运行中的服务直接执行 `tsrv-smoke-client.exe`：P2/P3/P4 全量用例再次通过
- Telegram Desktop：
  - 重新登录 `+14155550100`，会话列表、私聊、群组、频道正常
  - B 发送 `hello from B to A` 后桌面端实时收到
  - 图片/视频消息仍正常显示
- Android（LDPlayer14，Android 14，x86_64）：
  - 安装 `telegram-afat-debug-selfhost.apk`
  - 自定义服务器 `127.0.0.1:3801`（`adb reverse tcp:3801 tcp:3801`）
  - 使用 `+14155550100` 和固定验证码 `12345` 登录成功
  - 会话列表显示 `P3 Group`、`P3 Channel`、`Saved Messages` 和图片/视频预览
  - B 发送消息后 Android 收到未读角标和新消息
  - 桌面端与 Android 同时在线
- 兼容性修复：
  - `msgs_ack` 不再被服务端再次确认，避免 ack 回环和 binder 压力
  - 只有当前账号设置 `user.self`，其他用户不再被 Android 渲染成“收藏夹”
  - `account.getThemes`、`messages.getFeaturedStickers`、`help.getPeerColors`、`messages.getStickerSet` 等可选请求返回兼容空结果
- 稳定性：
  - `data/p5-stability.log` 每 30 秒记录健康状态、Android PID、桌面端进程数

已知问题：

- LDPlayer14 Android 14 镜像频繁 UI 操作后会报 `Too many Binders sent to SYSTEM` 并杀死 Telegram 进程
- `pm clear` 后 tgnet 偶尔复用旧 auth key，出现 `unknown auth_key_id` 重连循环，需要重新登录或重启模拟器
- `auth.bindTempAuthKey` 未持久化临时 key 绑定（P7 已修复）
- Android 私聊标题在旧缓存下可能仍显示“Saved Messages”；服务端已修复 `user.self` 位，本轮受模拟器 binder 限制未完成清理缓存后的复验

说明：同一账号多设备同步已在 P6 实现并验证；`auth.bindTempAuthKey` 持久化已在 P7 实现并验证。

## 10. P6 验证记录（2026-11-03）

已通过：

- `cargo test --workspace`：21 个测试全部通过
- `cargo clippy --workspace --all-targets`：无错误、无警告
- `scripts/smoke.ps1`：P2 / P3 / P4 / P6 全量通过
- 冒烟新增 A2（同账号第二个 session）：
  - B 的私聊消息同时到达 A1 和 A2
  - A2 发出的消息同步到 A1
  - A1 发出的消息同步到 A2
  - A1 发送连接不会收到自己的同步推送（`exclude_session_id` 生效）
  - A1 的群组消息同步到 A2
- 真实 Telegram Desktop（作为 A 的第三个 session）：
  - 实时显示 `multi-device from B`（接收）
  - 实时显示 `multi-device from A2`（其他设备发出，本机同步显示为 Me）
  - 实时显示 `multi-device from A1`（其他设备发出，本机同步显示为 Me）
  - 群组 `multi-device group` 同步到桌面端

## 11. P7 验证记录（2026-11-03）

已通过：

- `cargo test --workspace`：23 个测试全部通过（新增 `bind_auth_key_inner_round_trip`、`bind_auth_key_inner_rejects_tampering`）
- `cargo clippy --workspace --all-targets -- -D warnings`：无错误、无警告
- `scripts/smoke.ps1`：P2 / P3 / P4 / P6 / P7 全量通过
- P7 冒烟用例：
  - 新建临时 auth key（`p_q_inner_data_temp`，`expires_in=86400`）
  - 用永久 key 加密 `bind_auth_key_inner`，在临时 key 连接调用 `auth.bindTempAuthKey` 返回 `boolTrue`
  - 绑定记录写入 `temp_auth_key_bindings`，临时 session 与永久 key 共享用户
  - 非法 `encrypted_message` 返回 `400 ENCRYPTED_MESSAGE_INVALID`
  - 同一临时 key 绑定到另一把永久 key 返回 `400 TEMP_AUTH_KEY_ALREADY_BOUND`
  - 新建 TCP 连接仅使用持久化的临时 key，`users.getUsers` 解析到绑定用户
  - 过期 `expires_at` 断言返回 `400 EXPIRES_AT_INVALID`
  - 超过握手生命周期的临时 key 收到 transport `-404`
- 真实 Telegram Desktop（Layer 232，独立 `tdata`）：
  - 服务端把桌面已有临时 key `-7629698907985658899` 标记为过期
  - 桌面收到 transport `-404` 后销毁旧临时 key，重新握手创建 `7610275285726817234`
  - 桌面发送 `auth.bindTempAuthKey`，永久侧为 `-6470930820424172120`，服务端日志出现 `bound temporary auth key`
  - 该旧永久 key 因 P7 前的 dummy bind 没有 session，首次验证出现 `401 AUTH_KEY_UNREGISTERED`
  - 修复历史 session 后再次让临时 key 过期，桌面重新创建 `4319798713659361873` 并绑定到同一永久 key
  - 第二次绑定 `resolved_user=Some(1)`，`temp_auth_key_bindings` 落库，桌面在线且不再出现 `401`
  - 服务端验证日志保存在 `data/p7-desktop-server.log`
- 已知限制：
  - P7 之前只返回 `boolTrue` 的历史绑定不会自动回溯修复；旧 `tdata` 需要补 session 或重新登录
  - 临时 key 过期后服务端返回 transport `-404` 并关闭连接，客户端按协议重新握手（符合预期）

## 12. P8 验证记录（2026-11-03）

已通过：

- `cargo test --workspace`：26 个测试全部通过（新增 `thumbnail_generation_produces_jpeg`、`message_extras_set_expected_flags`、`message_extras_are_absent_by_default`）
- `cargo clippy --workspace --all-targets -- -D warnings`：无错误、无警告
- 图片上传后生成 320px 内 JPEG 缩略图，写回 `media_files.thumb_storage_key` / `thumb_width` / `thumb_height` / `thumb_size`
- `messageMediaPhoto` 返回 `photoSize("m")` 缩略图 + `photoSize("x")` 原图
- 文档缩略图通过 `document.thumbs` 返回
- `inputPhotoFileLocation` / `inputDocumentFileLocation` 的 `thumb_size="m"` 下载缩略图；空 `thumb_size` 下载原图
- `upload.getFileHashes` 返回请求偏移处 1MB 范围的 SHA-256（32 字节）
- 真实 Telegram Desktop mtp 日志解析到 `photoSize type:"m"` 与 `type:"x"`，说明官方客户端兼容；缩略图上限 320px，小图不放大

冒烟输出节选：

```text
P8 photo thumbnail: downloaded 629 bytes JPEG OK
P8: upload.getFileHashes returned one 32-byte hash
```

已知限制：

- 视频缩略图尚未生成，视频仍以普通文件返回
- 缩略图只生成一档 `m`，未实现 `s` / `a` / `b` 多档

## 13. P9 验证记录（2026-11-03）

已通过：

- 冒烟覆盖：
  - 回复：`messages.sendMessage` + `inputReplyToMessage`，接收端解析到 `messageReplyHeader` 和正确 `reply_to_msg_id`
  - 编辑：`messages.editMessage` 更新文本与 `edit_date`，双方收到 `updateEditMessage`
  - 删除：`messages.deleteMessages` 返回 `affectedMessages`，对端收到 `updateDeleteMessages`，`messages.getMessages` 不再返回该消息
  - 转发：私聊来源转发生成 `messageFwdHeader.from_id=peerUser`；频道来源转发生成 `peerChannel` + `channel_post`
  - 置顶：`messages.updatePinnedMessage` 返回 `updatePinnedChannelMessages`，群成员收到同一更新
- 真实 Telegram Desktop（Layer 232，同一账号第三 session）mtp 日志确认收到：
  - `updateEditMessage`
  - `updateDeleteMessages`（消息 id 247）
  - `messageFwdHeader`（`from_id: peerUser user_id:2`）
  - `updatePinnedChannelMessages`（`channel_id:48`）
  - `messageFwdHeader`（`from_id: peerChannel channel_id:48`）
- 桌面端在 P9 同步期间持续在线，无 `401` / auth key 错误
- 验证日志：`data/p8-p9-desktop-server.log`

已知限制：

- 编辑最初仅支持文本；媒体 caption 编辑已在 P11 支持，替换 media 仍未实现
- 回复暂不支持 quote / story / monoforum 等 `inputReplyTo*` 变体
- 转发 `reply_to` / `drop_media_captions` 已在 P11 支持；schedule / send_as 等仍返回 `FORWARD_OPTIONS_UNSUPPORTED`
- 删除为硬删除；P10 已补齐 `updates.getDifference` / `getChannelDifference`

## 14. P10 验证记录（2026-11-03）

已通过：

- 迁移 `0008_p10_update_log.sql`：`update_log` 按 user / channel 持久化每个 PTS 的完整 Update
- `updates.getState` 返回当前 PTS 与总未读数
- `updates.getDifference`：
  - 无缺口返回 `updates.difference`（含 `updates.state`）
  - 超过 1000 条返回 `differenceSlice` + `intermediate_state`
  - 历史缺口过大返回 `differenceTooLong`
- `updates.getChannelDifference`：`channelDifference` / `channelDifferenceEmpty`
- 新消息、编辑、删除、置顶均写入 `update_log`
- 真实 Telegram Desktop 在线收到 P10 消息更新（`message: "P10 difference message"`、`pts: 241`）；difference 协议由冒烟客户端验证

冒烟输出节选：

```text
P10: updates.getDifference returned the missing message (pts 224 -> 225)
P10: updates.getChannelDifference returned channel updates (pts 6)
```

已知限制：

- `update_log` 从 P10 开始写入；更早的 PTS 缺口用户 difference 返回 `differenceTooLong`，频道 difference 可能返回空差异
- `new_messages` 固定为空，消息通过 `other_updates` 下发
- 尚未实现 `updates.channelDifferenceTooLong` 的 dialog/messages 快照

## 15. P11 验证记录（2026-11-03）

已通过：

- `messages.editMessage` 支持 `media` 参数（`inputMediaPhoto`），编辑保留原 photo，只更新 caption 与 `edit_date`
- `messages.forwardMessages` 支持 `reply_to`（`inputReplyToMessage`），转发消息同时带 `fwd_from` 与 `reply_to` 头
- `messages.forwardMessages` 支持 `drop_media_captions`（空 caption 转发）
- 冒烟覆盖媒体 caption 编辑、带 reply_to 的转发
- 真实 Telegram Desktop mtp 日志确认：
  - `message: "photo caption edited"` + `messageMediaPhoto`（P11 caption 编辑）
  - 转发消息带 `messageReplyHeader reply_to_msg_id: 352` 与 `fwd_from`（P11 转发 reply_to）

冒烟输出节选：

```text
P11: media caption edit delivered with edit_date
P11: forward with reply_to delivered
```

已知限制：

- 编辑 media 仅支持 `inputMediaPhoto`（原 photo 引用）；视频 / 文档替换媒体暂未实现
- 转发可选参数中 `silent` / `background` / `with_my_score` / `noforwards` 等已读取但不改变行为

## 16. 登录流程验证记录（2026-11-03）

已通过：

- `auth.signIn` 对未注册号码不再返回 `401 PHONE_NUMBER_UNOCCUPIED`，改为返回 `auth.authorizationSignUpRequired`（`0x44747e9a`）
- Telegram Desktop 的 `intro_step.cpp` 在收到该构造后 `goReplace<SignupWidget>`，随后调用 `auth.signUp` 完成注册
- 登录顺序固定为：先校验 `phone_code_hash` + 固定码 `12345`，再判断用户是否已注册
- dev schema 种子测试用户：`+14155550100`（Alice）、`+14155550101`（Bob），可直接用 `12345` 登录
- 冒烟用全新号码验证注册路径：

```text
auth.signIn: +14155550123 unoccupied, registering
login A: user_id=3 phone=+14155550123
auth.signIn: +14155550124 unoccupied, registering
login B: user_id=4 phone=+14155550124
PASS: P6/P7/P8/P9/P10/P11 milestones completed
```

- dev schema 全量冒烟（P2/P3/P4/P6/P7/P8/P9/P10/P11）通过
- `cargo clippy --workspace --all-targets -- -D warnings` 通过
- `cargo test --workspace --all-targets`：26 个测试通过

已知限制：

- `auth.exportLoginToken` 只回传随机 token，`auth.importLoginToken` 仍返回 `LOGIN_TOKEN_INVALID`，QR 扫码登录未实现
- 验证码有效期 5 分钟（Redis TTL 300s），过期后桌面端回到手机号页面重新发码

## 17. P12 语言包验证记录（2026-11-03）

已通过：

- `langpack.getLanguages` 返回 `[en, zh-hans]`，桌面端语言列表不再为空
- `langpack.getLanguage` 返回 `langPackLanguage`（此前缺失，导致选中语言后无任何反应）
- `langpack.getLangPack` 返回 8858 条 `langPackString`，桌面端切到简体中文后立即写入本地缓存并重启生效
- `langpack.getStrings` 按 key 返回（`lng_languages`、`lng_settings_language`）
- `langpack.getDifference` 对已缓存版本返回空差异（`from_version >= 1`）
- 语言包来源：`https://translations.telegram.org/zh-hans/tdesktop/export`，保存为 `data/langpacks/zh-hans.strings`
- 启动日志会输出 `loaded language pack lang=zh-hans`；目录缺失时只警告并仅提供 `en`

冒烟输出节选：

```text
langpack.getLanguages: 2 language(s) OK
langpack.getLanguage: zh-hans OK
langpack.getLangPack: 8858 strings OK
langpack.getStrings: 2 strings OK
```

- `cargo clippy --workspace --all-targets -- -D warnings` 通过
- `cargo test --workspace --all-targets`：28 个测试通过（新增 2 个 langpack 解析测试）

已知限制：

- 语言包在服务启动时一次性加载；新增语言需重启服务
- 设置页附属 RPC（`account.getPassword` 等）当时缺失，已在第 18 节补齐

## 18. 设置页与搜索 RPC 补齐（2026-11-03）

真实客户端点开「设置」后，服务端日志持续报 `METHOD_NOT_FOUND`，逐条补齐：

- `account.getPassword` → 无两步验证的 `account.password`（`passwordKdfAlgoUnknown` / `securePasswordKdfAlgoUnknown`）
- `account.getContactSignUpNotification` → `boolFalse`
- `account.getContentSettings` → `sensitive_can_change = true`
- `account.getGlobalPrivacySettings` → 全默认 `globalPrivacySettings`
- `account.getCollectibleEmojiStatuses` → `account.emojiStatuses`（空列表）
- `messages.getWebPage` → `webPageEmpty`
- `payments.getStarGiftActiveAuctions` → 空 `payments.starGiftActiveAuctions`
- `stories.getStoriesArchive` → 空 `stories.stories`
- `aicompose.getTones` → 空 `aicompose.tones`
- `messages.getDefaultHistoryTTL`、`messages.getEmojiKeywordsLanguages`、`messages.getEmojiKeywordsDifference`
- 贴纸/表情/GIF/铃声/壁纸/时区等只读方法统一返回对应的 `NotModified`
- `messages.search` 改为真实文本检索（`ILIKE` + 每个会话内倒序）

冒烟输出节选：

```text
messages.search: 3 message(s) OK
PASS: P2 private chat, dialog list and history completed
```

- `cargo clippy --workspace --all-targets -- -D warnings` 通过
- `cargo test --workspace --all-targets`：28 个测试通过

已知限制：

- `messages.createChat`（新建普通群）未实现：当前数据模型只有 `group`/`channel`（`channel#` + `peerChannel`），
  Telegram Desktop 的建群回调要求 `chat#` + `peerChat`，需要单独实现基础群模型
- `messages.searchGlobal` 仍返回空结果
- 头像上传（`photos.uploadProfilePhoto`）未实现

## 19. 系统助手 / 默认好友 / 模拟消息（2026-11-03）

已通过：

- 服务启动时自动创建系统账号：`+10000000000`（`系统助手`，id = 6），并写入 `users`
- 新用户注册（`auth.signUp`）或已有用户登录（`auth.signIn`）时，若还没有与系统账号的私聊，会自动建立会话并发送欢迎消息
- 欢迎消息写入 `messages` / `user_dialogs`，同步写 `update_log` 并推送 `updateNewMessage`
- 欢迎消息发送后立刻标记已读（`read_max_seq` / `unread_count = 0`），避免影响未读断言
- 新增开发用 HTTP 接口（仅监听本机健康端口）：

```text
POST http://127.0.0.1:3802/admin/system-message
Authorization: Bearer <TSRV_ADMIN_TOKEN>
{ "phone": "+8615818852038", "text": "你好，我是系统助手" }
→ {"sent":true,"user_id":5,"phone":"+8615818852038"}
```

> 设置 `TSRV_ADMIN_TOKEN` 后，所有 `/admin/*` 都要带该请求头；未设置时保持旧的开放行为。

- `contacts.search` 已实现：按名字 / 手机号 / 用户名模糊搜索用户，返回 `contacts.found`，桌面端“新建聊天”搜索可用
- `messages.getEmojiKeywords`、`messages.exportChatInvite` 补齐（邀请链接返回 `https://t.me/+<随机>`）

冒烟输出节选：

```text
contacts.search: 2 result(s) OK
messages.search: 5 message(s) OK
PASS: P2 private chat, dialog list and history completed
```

数据库核对：

```text
dev.users:  5 = +8615818852038 (xiao), 6 = +10000000000 (系统助手)
dev.chats: 10 = private(5, 6)
dev.user_dialogs: user 5 / chat 10 unread_count = 0
```

已知限制：

- `messages.createChat`（新建普通群）仍未实现：桌面端要求 `chat#` + `peerChat`，
  当前只有超级群模型（`channel#` + `peerChannel`），下一阶段补基础群
- 系统助手目前只能由服务端主动发消息，客户端回复走普通私聊通道（已支持）

## 20. 频道/群消息左右侧修复（2026-11-03）

现象：真实客户端在自己创建的频道里发消息，历史里显示在**左侧**（对方侧）。

原因：

- `update_log` 是**频道级**共享表，写日志时用 `member_message`（`out=false`）
- 客户端打开频道时调用 `updates.getChannelDifference`，重放日志把该消息的 `out` 标记改回 false
- 发消息时的 response/push 虽然是 `out=true`，但随后被差量覆盖

修复：

- 新增 `patch_channel_message_out`：重放 `updateNewChannelMessage` / `updateEditChannelMessage` 时，
  解析 message 的 `flags`、`from_id`（`PeerUser`），当 `from_id == 当前用户` 时把 `out` 位设为 1
- 只影响返回给请求者的差量，频道日志本身保持中性

验证：

- 单元测试使用真实 `update_log` 十六进制样本（message from user 5）：
  - 用户 5 请求 → flags `0x100` → `0x102`（out=true）
  - 用户 7 请求 → 保持 `0x100`（out=false）
- 顺带补齐该轮客户端实际打到但缺失的方法：
  `messages.setTyping`、`channels.readHistory`、`channels.checkUsername`、`channels.getSendAs`、
  `messages.getMessagesViews`、`messages.getSponsoredMessages`、`payments.getCurrencyRates`
- `cargo test --workspace --all-targets`：30 个测试通过

## 21. Premium 标记与设置页附属 RPC（2026-11-03）

- 所有自建用户统一标记为 Telegram Premium（`user#` flags bit28），客户端会显示会员徽章；
  会员在线时账号上限从 3 提升到 4（`Main::Domain::maxAccounts = min(3 + premium 数, 6)`）
- 冒烟新增断言：`users.getUsers: self user premium OK`
- 补齐设置/隐私/故事相关空结果：
  `account.getPrivacy`、`account.getWebAuthorizations`、`contacts.getBlocked`、
  `messages.getShareThemeBackdrops`、`stories.getAlbums`、`stories.getPinnedStories`、
  `payments.getSavedStarGifts`、`messages.reportReadMetrics`

注意：

- 账号上限由客户端本地按“在线 premium 账号数”计算，服务端无法绕过“从 3 个加到第 4 个”这一刻
- Premium 里的贴纸包、emoji 状态、Stories、礼物、语音转写等仍需要真实数据/RPC，目前只是空结果

## 22. 基础群 / 全局搜索 / 头像（2026-11-03）

- **基础群**：新增 `basic_group` 类型（migration `0009`），实现
  `messages.createChat`、`messages.getChats`、`messages.getFullChat`、
  `chat#` / `peerChat` 消息与会话列表、发消息/历史/已读、全局搜索命中
- **全局搜索**：`messages.searchGlobal` 跨私聊/群/频道按文本检索
- **头像上传**：新增 `users.photo_media_id`（migration `0010`），实现
  `photos.uploadProfilePhoto` / `photos.updateProfilePhoto`，
  `user#` 带 `photo:flags.5`，客户端可通过 `upload.getFile` 拉取头像
- 冒烟新增断言：`messages.createChat`、`basic group: A/B history`、
  `basic group: edit`、`basic group: pin`、`basic group: getMessages returns chat#`、
  `basic group: delete`、`photos.uploadProfilePhoto`、
  `avatar: self user carries profile photo`、`messages.searchGlobal`

冒烟输出节选：

```text
messages.searchGlobal: 20 message(s) OK
messages.createChat: chat_id=65
basic group: A/B history OK
basic group: edit OK
basic group: pin OK
basic group: getMessages returns chat#
basic group: delete OK
photos.uploadProfilePhoto: OK
avatar: self user carries profile photo
PASS: P2 private chat, dialog list and history completed
PASS: P6/P7/P8/P9/P10/P11 milestones completed
```

已知限制：

- 基础群暂不支持邀请链接（Telegram 基础群本身没有邀请链接）
- 头像只支持静态图片（video avatar 返回 `VIDEO_EMOJI_UNSUPPORTED`）
- 全局搜索忽略 `folder_id` / 过滤类型 / 日期范围

## 23. 基础群成员管理与服务消息（2026-11-03）

- migration `0011` 新增 `messages.action_kind / action_user_id / action_title`，
  用于保存并重建 `messageService#`：
  `messageActionChatCreate` / `ChatAddUser` / `ChatDeleteUser` / `ChatEditTitle`
- 新增 RPC：`messages.addChatUser`、`messages.deleteChatUser`、
  `messages.editChatTitle`、`messages.unpinAllMessages`
  - 成员变化逐成员推送 `updateChatParticipants` + `chat#`
  - 增删成员/改名会写入一条服务消息，并通过 `updateNewMessage` 分发，
    新成员因此能立刻在会话列表看到群
- `messages.getHistory` / `messages.getMessages` 对基础群的中的服务消息返回
  `messageService#`，不再返回带空文本的普通气泡
- 冒烟新增断言：`basic group: add user OK (3 participants)`、
  `basic group: edit title OK`、`basic group: remove user OK`
- 另：`photos.getUserPhotos` 返回当前头像，冒烟断言
  `photos.getUserPhotos: profile photo listed`
- 客户端定制构建：`out\Release\Telegram.exe`（262 MB，2026-11-03），
  已用 `-workdir out\Release` 启动验证进程可正常运行；
  账号上限与 Premium 逻辑需在 UI 中人工确认

## 24. 编辑替换媒体（2026-11-03）

- `messages.editMessage` 现在会解析 `media:flags.14`，支持替换为：
  - 新上传的 `inputMediaUploadedPhoto` / `inputMediaUploadedDocument`
  - 已存在的 `inputMediaPhoto` / `inputMediaDocument`
  - `inputMediaEmpty`（移除媒体）
- 新增 `repo::set_message_media`，替换后仍走原来的 edit 更新分发
- 冒烟新增断言：`P11: media replacement OK (media id ...)`，
  并下载替换后的图片字节进行比对

## 25. 清空历史与会话删除（2026-11-03）

- `messages.deleteHistory`：私聊 / 基础群 / 超级群按 `max_id` 清空历史，
  逐成员推送 `updateDeleteMessages` / `updateDeleteChannelMessages`，
  返回 `messages.affectedHistory`
- `messages.deleteChat`：删除当前用户的会话（基础群非群主同时退出群）
- 冒烟新增断言：`P12: deleteHistory cleared the private chat`

## 26. 消息反应（2026-11-03）

- migration `0012` 新增 `message_reactions`（每用户每条消息一个 emoji 反应）
- 新增 `messages.sendReaction#d30d78d4`：
  - `reaction` 为空时移除自己的反应
  - 其余值必须是 `reactionEmoji`（自定义 emoji 返回 `REACTION_INVALID`）
  - 返回并推送 `updateMessageReactions#1e297bfa`，按查看者计算 `chosen_order`
- `messageReactions#a339f0b` / `reactionCount#a3d1cb80` / `reactionEmoji#1b2286b8`
  与客户端的 Layer 232 schema 对齐
- `message#` flags bit20 的 `reactions` 已接入：私聊、基础群、频道历史、
  `messages.getMessages`、编辑消息更新都会带上反应
- 冒烟新增断言：`messages.sendReaction: reaction delivered to both peers`、
  `messages.sendReaction: reaction removal delivered`

## 27. 群/频道头像（2026-11-03）

- migration `0013` 新增 `chats.photo_media_id`
- 新增 `messages.editChatPhoto#35ddd674` / `channels.editPhoto#f12e57c9`
  - 支持 `inputChatUploadedPhoto`（上传新图）、`inputChatPhoto`（已有照片）、
    `inputChatPhotoEmpty`（移除）
  - 视频头像返回 `VIDEO_EMOJI_UNSUPPORTED`
- `chat#` / `channel#` / `chatFull` 的 `photo` 字段改为真实 `chatPhoto#1c6e1c11`
- `upload.getFile` 支持 `inputPeerPhotoFileLocation`，客户端可下载群/频道头像
- 冒烟新增断言：`basic group: chat photo uploaded and downloaded OK`

## 28. 计划消息（2026-11-03）

- migration `0014` 新增 `messages.scheduled_date`（`> 0` 表示待发送）与部分索引
- 新增 `messages.getScheduledHistory#f516760b` / `messages.sendScheduledMessages#bd38850a`
  / `messages.deleteScheduledMessages#59ae2b16`
- `messages.sendMessage` / `messages.sendMedia` 解析 flags bit10 `schedule_date`：
  - 过去时间返回 `SCHEDULE_DATE_INVALID`，超过一年返回 `SCHEDULE_DATE_TOO_LATE`
  - 待发送消息只对作者可见，且不出现在普通历史 / 搜索 / 会话摘要中
- 待发送消息存库并通过 `updateNewScheduledMessage#39a51dfb` / `updateDeleteScheduledMessages#f2a71983`
  同步到同账号其他会话
- `messages.sendScheduledMessages` 立即投递：激活记录（`scheduled_date=0`、`sent_at=now`）、
  更新成员会话、按原有消息路径推送，并移除计划条目
- 新增后台 worker（每 5 秒）扫描到期计划消息并自动投递
- 冒烟新增断言：
  - `P13: scheduled message stored, hidden and past dates rejected`
  - `P13: deleteScheduledMessages removed the pending message`
  - `P13: sendScheduledMessages delivered immediately`
  - `P13: due scheduled message delivered by the server worker`

## 29. 多档媒体缩略图（2026-11-03）

- migration `0015` 新增 `media_thumbs`（`media_id + kind`，`s` / `m` / `x`）
- 图片上传按 160 / 320 / 640 生成多档 JPEG 缩略图，不放大源图
- 视频上传通过 `ffmpeg` 抽帧（`TSRV_FFMPEG` 或 PATH），再生成多档缩略图；
  ffmpeg 不可用时只记录警告，不影响上传
- `photo#` / `document#` 的 `photoSize` 向量返回多档缩略图：
  - 照片用 `s` / `m` 预览，`x` 仍指向原图（下载原图不受影响）
  - 视频文档使用 `s` / `m` / `x` 预览
- `upload.getFile` 与 `upload.getFileHashes` 支持按 `thumb_size` 解析到对应分档
- 冒烟新增断言：
  - `P19: photo thumbnail tiers s/m and original download OK`
  - `P19: video thumbnail tiers ["s", "m"] generated with ffmpeg`
- 单元测试新增 `thumbnail_generation_builds_all_tiers`（s/m/x 三档尺寸）

## 30. 更多语言包（2026-11-03）

- 复制官方 tdesktop 语言包到 `data/langpacks`：
  - `ru.strings`（8107 条）
  - `zh-hant.strings`（8105 条）
- `langpack.getLanguages` 现在返回 4 种语言（en / zh-hans / zh-hant / ru）
- 冒烟新增断言：`langpack.getLangPack: zh-hant 8105 strings OK`、
  `langpack.getLangPack: ru 8107 strings OK`

## 31. 运维清理与管理接口（2026-11-03）

- 新增后台 maintenance worker（默认每小时，`TSRV_MAINTENANCE_INTERVAL_SECS`）：
  - 清理超过保留期的 `update_log`（默认 168 小时）
  - 删除已过期的临时 auth key（级联删除绑定）
  - 删除超过 TTL 的残留上传分片，并清理对应 `uploads/<id>` 目录
- 新增只读接口 `GET /admin/stats`：用户 / 会话 / 消息 / 媒体 / 待发送计划消息 /
  update_log / auth key / 临时绑定 / 反应数量
- 新增手动触发接口 `POST /admin/maintenance`，返回本轮清理结果
- 保留期与上传 TTL 可通过 `TSRV_UPDATE_LOG_RETENTION_HOURS` /
  `TSRV_UPLOAD_PART_TTL_HOURS` 调整
- 冒烟脚本验证：`admin stats: ...` 与 `admin maintenance: pruned=... keys=... uploads=...`

## 32. Premium 贴纸与 emoji 状态（2026-11-03）

- migration `0016` 新增 `users.emoji_status_document_id`
- 启动时从 `data/sticker-seed/status-pack` 播种官方 StatusPack：
  - 11 个真实 `.tgs` 自定义 emoji 文档写入 `media_files`
  - `messages.getStickerSet` 返回带有 `packs` / `documents` 的真实贴纸集
  - `messages.getStickers` / `messages.getEmojiStickers` /
    `messages.getCustomEmojiDocuments` 返回对应文档
- 新增 `account.getDefaultEmojiStatuses` / `account.getRecentEmojiStatuses`
  返回 6 个可选 emoji 状态
- 新增 `account.updateEmojiStatus`：持久化到用户记录，并向同账号其他会话推送
  `updateUserEmojiStatus`；`user#` 的 `emoji_status:flags.30` 已接入
- 冒烟新增断言：
  - `P20: premium sticker set docs=11 statuses=6 and sticker download OK`
- 说明：Stories / 礼物 / 语音转写仍为后续阶段

## 33. PTS 增量快照（2026-11-03）

- `updates.getDifference` 现在把 `updateNewMessage` / `updateNewChannelMessage`
  从 updates 中拆出，放入 `new_messages` 向量，其余更新保留在 `other_updates`
- `updates.getChannelDifference` 同样返回 `new_messages`，并保留
  `patch_channel_message_out` 的按查看者 `out` 修正
- 冒烟断言 `P10: updates.getDifference returned the missing message` 与
  `P10: updates.getChannelDifference returned channel updates` 继续通过
- 仍保留：日志缺失时返回 `*DifferenceTooLong` / 空差分的降级路径

## 34. 数据库迁移到 yun.public.te_（2026-11-03）

- 使用 `pg_dump` 导出 `telegram_server.dev`，转换为 `yun.public` 下的
  `te_` 前缀表和索引/约束名
- 迁移前后逐表行数一致：
  - users 7、chats 38、messages 221、auth_keys 78、sessions 60、
    user_dialogs 58、update_log 466、media_files 49、schema_migrations 17
- 服务端切换到 `yun` + `public`，`/healthz` 返回 `schema=public`
- 冒烟测试仍使用 `telegram_server.test`，全部通过
- 回滚备份：`data/migration/telegram_dev.sql`、`telegram_server.dev` schema

## 35. Rust admin API 与 yun 后台代理（2026-11-04）

- 新增 `TSRV_ADMIN_TOKEN`：设置后所有 `/admin/*` 需要
  `Authorization: Bearer <token>` 或 `X-Admin-Token: <token>`；未设置时保留本地开放行为
- 新增写操作（复用正常 RPC 的 PTS / `te_update_log` / 在线推送，不直接改表）：
  - `POST /admin/telegram/send-message`：`{user_id,text}`，系统助手发私聊
  - `POST /admin/telegram/delete-message`：`{chat_id,message_id}`，私聊/基础群/频道通用
  - `POST /admin/telegram/kick-user`：`{chat_id,user_id}`，基础群踢人
- yun.ai 新增 `[telegram] base_url/token` 配置，并提供代理接口：
  - `POST /api/admin/telegram_send_message`
  - `POST /api/admin/telegram_delete_message`
  - `POST /api/admin/telegram_kick_user`
- 管理后台「聊天 → Telegram 账号 / 会话 / 消息」增加「发消息 / 踢人 / 删除」按钮
- 已验证：
  - 无 token 访问 `/admin/stats` 返回 401
  - 发消息返回 `message_id`，`te_messages` 文本 UTF-8 正常
  - 删消息后记录消失，双方 `te_users.pts` +1，`te_update_log` 成对写入
  - 踢人后 `left_at` 非 0，写入 `delete_user` 服务消息（sender=群主，action_user=被踢者），
    剩余成员 PTS +1
  - 错误路径：空消息 400、不存在用户 `USER_NOT_FOUND`、不存在消息
    `MESSAGE_NOT_FOUND`、踢群主 `CHAT_ADMIN_REQUIRED`

## 36. 失败处理

AI 冒烟失败时：

1. 保留服务端日志
2. 保留测试客户端请求/响应
3. 记录失败 RPC 方法
4. 不自动修改生产数据
5. 修复后重新跑完整冒烟，不能只跑失败用例

## 37. 在线状态 / 正在输入 / 已读回执（2026-11-04）

- 在线状态：
  - 新增 `crates/server/src/presence.rs`，按 `(auth_key_id, session_id)` 记录会话，
    用户 `te_users.last_seen_at` 由 Rust 侧写入（`repo::touch_user_last_seen`）
  - `user#` 的 status 不再固定 `userStatusRecently`：在线返回 `userStatusOnline`，
    离线且有记录返回 `userStatusOffline(was_online)`，从未上线过才返回 Recently
  - 连接建立/断开（含错误退出、登出）通过 `PresenceGuard` 自动登记/注销，
    首个会话上线、最后一个会话离线时向私聊对端推送 `updateUserStatus`
  - `account.updateStatus(offline=true/false)` 支持手动上线/离线
- 正在输入：
  - `messages.setTyping` 解析 `sendMessageTypingAction`、`cancel`、录音/录像/上传等 action，
    私聊推 `updateUserTyping`，基础群推 `updateChatUserTyping`，
    频道/超级群推 `updateChannelUserTyping`（含 `top_msg_id`）
  - 推送给除发送者外的成员；未知 action 直接忽略而不报错
- 已读回执：
  - 私聊：`messages.readHistory` 给自己其它会话推 `updateReadHistoryOutbox`，
    给对方推 `updateReadHistoryInbox`；两者都写 `te_update_log` 并各自 +1 PTS
  - 基础群：给自己推 outbox，给其他成员逐个推 inbox，均写日志并各自 +1 PTS
  - 频道：`channels.readHistory` / `messages.readHistory` 只给自己其它会话推
    `updateReadChannelOutbox`，不进入频道 PTS 流（与官方 `channels.readHistory` 语义一致）
- 冒烟新增（`crates/server/src/bin/smoke_client.rs`）：
  - `P0-1 presence: B online while connected OK`
  - `P0-1 typing: B received updateUserTyping OK`
  - `P0-1 read receipt: A received updateReadHistoryInbox OK`
  - `P0-1 presence: B offline with last-seen after disconnect OK`
- 本地验证命令：
  - `cargo check --workspace --all-targets`
  - `cargo clippy --workspace --all-targets -- -D warnings`
  - `cargo test --workspace`（31 个通过）
  - `powershell -File scripts\smoke.ps1`（test schema，完整 P2-P19 + P0-1 通过）

## 38. 联系人 / 拉黑 / 隐私（2026-11-04）

- 迁移 `0017_p0_2_contacts.sql` 新增：
  - `te_contacts(owner_user_id, contact_user_id, created_at)`，主键 `(owner, contact)`
  - `te_blocked_users(owner_user_id, blocked_user_id, created_at)`，主键 `(owner, blocked)`
  - `te_privacy_settings(user_id, key bigint, rules jsonb, updated_at)`，主键 `(user, key)`
  - 首次迁移在用户数 ≤ 500 时把现有用户互相播种为联系人（避免桌面端联系人页为空）
- RPC：
  - `contacts.getContacts` 只返回 `te_contacts` 中的真实联系人（排除双向拉黑）
  - `contacts.addContact` / `contacts.deleteContacts` 立即写入/删除
  - `contacts.block` / `contacts.unblock` 写 `te_blocked_users`
  - `contacts.getBlocked` 返回 `PeerBlocked` + 用户，支持 offset/limit
  - `account.setPrivacy` / `account.getPrivacy` 读写 `te_privacy_settings`，
    支持 allow/disallow × all/contacts/users 六种规则
  - 被任一方向拉黑时：`messages.sendMessage` / `settings.sendMedia` / 定时消息
    返回 `403 USER_IS_BLOCKED`；`contacts.search` 与联系人列表均不返回拉黑对象
- 冒烟新增断言（`crates/server/src/bin/smoke_client.rs`）：
  - `P0-2 contacts: add/delete reflected in contacts.getContacts OK`
  - `P0-2 block: private send rejected, blocked peer hidden from contacts/search OK`
  - `P0-2 block: getBlocked/unblock work and delivery is restored OK`
  - `P0-2 privacy: setPrivacy/getPrivacy persisted OK`
  - 冒烟开头会清掉上次中断遗留的双向拉黑，保证可重复运行
- 已知限制：
  - 隐私规则目前只做持久化与返回，尚未按规则隐藏 last seen / 头像 / 手机号
  - 未知的 `InputPrivacyRule`（如 close friends / premium / bots）返回 400，未做静默忽略
  - 拉黑只拦截私聊与搜索；群/频道内仍可见（按交接文档留待产品决定）
- 本地验证命令：
  - `cargo check -p tsrv-server --bins`
  - `cargo clippy --workspace --all-targets -- -D warnings`
  - `cargo test --workspace`（31 个通过）
  - `powershell -File scripts\smoke.ps1`（test schema，完整 P2-P19 + P0-1 + P0-2 通过）

## 39. 群/频道管理员、封禁、邀请链接、用户名（2026-11-04）

- 迁移 `0018_p0_4_admins_invites_usernames.sql`：
  - `te_chat_members` 角色约束增加 `admin`，新增 `admin_rights jsonb`、`rank`、`promoted_by`
  - 新表 `te_chat_bans(chat_id, user_id, banned_rights jsonb, until_date, kicked_by, created_at)`，主键 `(chat_id, user_id)`
  - 新表 `te_chat_invites(token, chat_id, creator_id, link, expires_at, usage_limit, usage_count, request_needed, revoked, created_at)`
  - `te_users` / `te_chats` 增加大小写不敏感的唯一用户名索引（`lower(username)`，空串除外）
- RPC：
  - `account.checkUsername` / `account.updateUsername`（5–32 位、字母开头、仅 a-z 0-9 `_`、保留字拒绝）
  - `contacts.resolveUsername` 返回 `contacts.resolvedPeer`（用户或频道）
  - `channels.checkUsername` / `channels.updateUsername`（管理员需 `change_info` 权限）
  - `channels.editAdmin`（群主或具备 `add_admins` 的管理员；rights=0 表示降级）
  - `channels.editBanned`（群主或具备 `ban_users` 的管理员；`view_messages` 置位时同时踢出）
  - `messages.exportChatInvite` / `checkChatInvite` / `importChatInvite` 使用真实邀请链接表
  - 发送/定时消息、`channels.joinChannel`、`importChatInvite`、`inviteToChannel` 均检查封禁；
    发送被封禁返回 `403 USER_BANNED_IN_CHANNEL`
  - `channel#` 返回真实 `username`、`admin_rights`（群主/管理员）与真实参与者数
  - `channels.getParticipants` 按角色返回 `channelParticipantCreator` / `channelParticipantAdmin` / `channelParticipant`
  - 管理员/封禁变化写 `te_update_log` 并递增频道 PTS，推送 `updateChannel` 给所有在线成员
- 冒烟新增断言：
  - `P0-4 username: check/update/resolve for a user OK`
  - `P0-4 username: check/update for a channel OK`
  - `P0-4 invite: export/check/import/join for a channel OK`
  - `P0-4 admin: promote, ban, banned write rejected and unban OK`
- 已知限制：
  - 加入请求（`request_needed`）未实现审批页，导出时忽略该标记，链接直接加入
  - `channel#admin_rights` 只在创建者与 `getParticipants`/`editAdmin` 响应中携带；
    重新登录后的普通对话列表暂不按查看者回填管理员权限（后续可在 `messages.getDialogs` 补）
  - 用户名修改未推送 `updateUserName`，需重新拉取用户信息
  - 基础群仍未支持管理员与封禁（仅超级群/频道），与当前客户端行为一致
  - `messages.exportChatInvite` 的 `legacy` / 标题已存储，未实现 `editExportedChatInvite`
- 本地验证命令：
  - `cargo check --workspace --all-targets`
  - `cargo clippy --workspace --all-targets -- -D warnings`
  - `cargo test --workspace`（31 个通过）
  - `powershell -File scripts\smoke.ps1`（test schema，完整 P2-P19 + P0-1/P0-2/P0-4 通过）

## 40. 草稿、会话置顶、文件夹（2026-11-04）

状态：**已完成**（文件夹仅保存用户自定义过滤器原始数据）。

- 迁移 `0019_p0_3_drafts_pins_folders.sql`：
  - 新表 `te_drafts(user_id, chat_id, text, reply_to, updated_at)`，主键 `(user_id, chat_id)`
  - 新表 `te_pinned_dialogs(user_id, chat_id, sort_order, pinned_at)`，主键 `(user_id, chat_id)`
  - 新表 `te_dialog_filters(user_id, filter_id, filter, updated_at)`，`filter` 为原始 TL `DialogFilter` 字节
- RPC：
  - `messages.saveDraft`（`ad0fa15c`，解析 `reply_to`(flags.4) → `peer` → `message`；空文本等价清除草稿）
  - `messages.getAllDrafts`（`6a3f8d65`）返回 `updates#74ae4240`，每条草稿一个 `updateDraftMessage`
  - `messages.toggleDialogPin`（`a731e257`，`InputDialogPeer`），`messages.reorderPinnedDialogs`（`3b1adf37`）
  - `messages.getPinnedDialogs`（`d6b94df2`）改为只返回置顶会话（`te_pinned_dialogs` 排序）
  - `messages.getDialogs` 的 `dialog#` 带 `pinned:flags.2`，置顶会话排在最前
  - `messages.updateDialogFilter`（`1ad4a04a`，原样保存 `DialogFilter` 字节；`filter` 缺省即删除）
  - `messages.getDialogFilters`（`efd48c89`）返回 `messages.dialogFilters#2ad93719`
- 冒烟新增断言：
  - `P0-3 drafts: save/read/clear OK`
  - `P0-3 pins: toggleDialogPin/getPinnedDialogs OK`
  - `P0-3 folders: updateDialogFilter/getDialogFilters OK`
- 验证：`cargo check` / `cargo clippy --workspace --all-targets -- -D warnings` / `cargo test --workspace`
  全部通过；测试库执行迁移 `0019` 后完整冒烟通过；生产库已执行迁移，Rust 生产服务重启后
  `/healthz` 返回 `{"db":true,"redis":true,"schema":"public","status":"ok"}`。
- 已知限制：
  - 草稿只保存纯文本与 `reply_to`，`entities`/`media`/`no_webpage`/`effect` 被忽略
  - 草稿只能保存到已存在的会话（无消息的新私聊会返回 `PEER_ID_INVALID`）
  - 文件夹只做原样存储与读取，不参与会话过滤；“全部/未读/归档”内置过滤器未实现
  - 草稿/置顶/过滤器改动是本账号状态，不写 `te_update_log`、不影响 PTS，也不推送到同账号其他设备
- 本地验证命令：
  - `cargo check --workspace --all-targets`
  - `cargo clippy --workspace --all-targets -- -D warnings`
  - `cargo test --workspace`（31 个通过）
  - `powershell -File scripts\smoke.ps1`（test schema，完整 P2-P19 + P0-1/P0-2/P0-3/P0-4 通过）

## 41. 个人简介与生日（2026-11-04）

状态：**已完成**。

- 迁移 `0020_p0_5_bio_birthday.sql`：`te_users.bio text`、`birthday_day/month/year integer`
- RPC：
  - `account.updateProfile#78515775` 的 `about:flags.2?string` 写入 `te_users.bio`
  - `account.updateBirthday#cc6e0c11`：`flags.0?birthday:Birthday` 存入 `day/month/year`；
    不带 birthday 即清除
  - `users.getFullUser` 返回 `userFull#b90c2afd`，`about:flags.1?string` 与
    `birthday:flags2.5?Birthday`（`birthday#6c8e1e06`）
- 冒烟新增断言：
  - `P0-5 profile: bio/birthday OK`（保存简介 → `getFullUser` 校验；设置生日 → flags2.5 置位；
    清除生日与简介后 `about` 为空且生日标志清除）
- 验证：`cargo clippy --workspace --all-targets -- -D warnings` 通过，`cargo test --workspace`
  31 个通过；测试库执行迁移 `0020` 后完整冒烟通过；生产库已执行迁移，Rust 生产服务重启后
  `/healthz` 返回 `{"db":true,"redis":true,"schema":"public","status":"ok"}`。
- 已知限制：
  - 保留字仅最小集合，未覆盖官方全部保留字与 Fragment 拍卖规则
  - `userFull` 只填 `about` 与 `birthday`，其余可选字段（`personal_photo`、`business_*` 等）未实现
  - 生日只校验 `1..=31` / `1..=12` / 年份非负，未严格校验闰年与 150 岁上限
  - 简介/生日不写 `te_update_log`、不推送同账号其他设备

## 42. 语音/音频消息（2026-11-04）

状态：**已完成**。

- 迁移 `0021_p1_1_audio.sql`：`te_media_files` 新增 `audio_voice boolean`、
  `audio_title text`、`audio_performer text`、`audio_waveform bytea`
- 上传管线：
  - `documentAttributeAudio#9852f9c6` 解析 `voice:flags.10`、`duration`、`title:flags.0`、
    `performer:flags.1`、`waveform:flags.2`，存入 `te_media_files`
  - `document#` 在 `audio_voice`/标题/艺术家任一存在时回写 `documentAttributeAudio`
- 冒烟新增断言：
  - `P1-1 voice: documentAttributeAudio round-trip OK`：A 上传 `voice.ogg` 并用
    `messages.sendMedia` 发送语音，B 收到 `messageMediaDocument`，属性中 `voice` 置位、
    `mime_type=audio/ogg`
- 验证：`cargo clippy --workspace --all-targets -- -D warnings` 通过，
  `cargo test --workspace` 31 个通过；测试库执行 `0021` 后完整冒烟通过；生产库已执行迁移，
  Rust 生产服务重启后 `/healthz` 返回 `{"db":true,"redis":true,"schema":"public","status":"ok"}`。
- 已知限制：
  - 波形按客户端上传原样保存，服务端不生成
  - 不做转码，`mime_type` 以客户端声明为准
  - 未实现 `documentAttributeAudio.thumbnail`（音频封面）

## 43. 相册 / 多图消息（2026-11-04）

状态：**已完成**。

- 迁移 `0022_p1_2_grouped_id.sql`：`te_messages` 新增 `grouped_id bigint NOT NULL DEFAULT 0`，
  并建立 `(chat_id, grouped_id) WHERE grouped_id <> 0` 部分索引
- `repo.rs`：`MessageRecord` / `MessageExtras` 增加 `grouped_id`，所有 SELECT/RETURNING/INSERT
  同步补列；`message_from_row` 读取
- `tl`：
  - `message#` 输出 `grouped_id:flags.17`（位于 `edit_date` 之后、`reactions` 之前）
  - 新增 `messages.sendMultiMedia#1bf89d74`、`inputSingleMedia#1cc6e91f`、
    `inputQuickReplyShortcut#24596d41` 构造器
- `rpc.rs`：
  - 新增 `messages.sendMultiMedia` dispatch 与 `messages_send_multi_media`
  - 解析 `peer`、可选 `reply_to`、`Vector<InputSingleMedia>`（最多 10 条，每条解析
    `media`/`random_id`/`message`/可选 entities），以及尾部的 `schedule_date` /
    `send_as` / `quick_reply_shortcut` / `effect` / `allow_paid_stars`
  - 一次请求生成同一个非零 `grouped_id`，逐条走原有发送通路（含计划消息）；
    仅最后一条作为 RPC 返回值，其余响应推送回发送者自身会话
- 冒烟新增断言：
  - `P1-2 album: two messages share grouped_id OK`：A 上传两张 PNG 后用
    `messages.sendMultiMedia` 发送，`messages.getHistory` 解析最新两条消息，
    `grouped_id` 非零且相同
- 验证：`cargo clippy --workspace --all-targets -- -D warnings` 通过，
  `cargo test --workspace` 31 个通过；测试库执行 `0022` 后完整冒烟通过；生产库已执行迁移，
  Rust 生产服务重启后 `/healthz` 返回 `{"db":true,"redis":true,"schema":"public","status":"ok"}`。
- 已知限制：
  - 未严格校验“相册内消息必须是同一 peer 的连续媒体消息”等客户端语义
  - 相册每条的 caption 独立保存，不合并
  - 定时相册逐条写入同一 `grouped_id`，未做额外一致性校验

## 44. 贴纸 / 自定义 emoji 文档属性（2026-11-04）

状态：**部分完成**（贴纸与自定义 emoji 的文档属性已支持；文本内自定义 emoji entity 未支持）。

- 迁移 `0023_p1_3_stickers.sql`：`te_media_files` 增加 `sticker`、`sticker_alt`、
  `sticker_set_id`、`sticker_set_access_hash`、`custom_emoji`、`custom_emoji_alt`
- `repo.rs`：新增 `MediaStickerInput`，`MediaRecord` / `create_media` / `find_media` 支持上面的列
- `rpc.rs`：
  - `read_document_attribute` 解析 `documentAttributeSticker`（含 mask_coords）与
    `documentAttributeCustomEmoji`，并读取 `InputStickerSetID/ShortName/Empty`
  - 上传文档时把贴纸信息写入 `te_media_files`
  - `media_bytes` 对贴纸文档不再输出 filename/image_size，改为输出对应
    `documentAttributeSticker` / `documentAttributeCustomEmoji`
- `stickers.rs`：内置 StatusPack 播种时同步写入贴纸/自定义 emoji 列（冲突时更新）
- 冒烟新增断言：
  - `P1-3 sticker: documentAttributeSticker round-trip OK`：上传一个 `.tgs` 文档并附带
    `documentAttributeSticker` 发送，`getHistory` 解析首条消息的文档属性，`sticker=true`
- 验证：`cargo clippy --workspace --all-targets -- -D warnings` 通过，
  `cargo test --workspace` 31 个通过；测试库执行 `0023` 后完整冒烟通过；生产库已执行迁移，
  生产 Rust 重启后 `/healthz` 返回 `{"db":true,"redis":true,"schema":"public","status":"ok"}`，
  `te_media_files` 中 11 条 StatusPack 文档已写入 `custom_emoji=true`
- 已知限制：
  - 消息文本里的 `messageEntityCustomEmoji` 未保存/未回传，`messages.getCustomEmojiDocuments`
    也未实现，自定义 emoji 在文本中仍显示普通字符
  - 用户自建贴纸包（`stickers.createStickerSet` 等）未实现

## 45. 投票 / 位置 / 联系人名片 / 骰子（2026-11-04）

状态：**已完成**（投票支持发送、投票、查询结果；位置/联系人/骰子为一次性媒体）。

- 迁移 `0024_p1_4_polls_geo_contact_dice.sql`：
  - `te_media_files.kind` 增加 `poll` / `geo` / `contact` / `dice`
  - `te_media_files.media_payload jsonb` 保存这些无文件媒体的内联数据
  - 新增 `te_poll_votes(media_id, user_id, option, voted_at)` 与 `te_poll_votes_media_idx`
- `repo.rs`：
  - `MediaRecord` 增加 `payload`，`find_media` 读取 `media_payload`
  - 新增 `create_special_media`、`replace_poll_vote`、`poll_option_counts`、
    `poll_voter_total`、`poll_user_options`
- `tl`：
  - 新增 `inputMediaPoll/GeoPoint/Contact/Dice`、`poll`、`pollAnswer`、`pollResults`、
    `pollAnswerVoters`、`messageMediaPoll/Geo/Contact/Dice`、`geoPoint`、
    `updateMessagePoll`、`messages.sendVote`、`messages.getPollResults` 构造器常量
  - 新增上述对象的 writer（`types::poll`、`types::poll_results`、`types::update_message_poll` 等）
- `rpc.rs`：
  - `read_input_media` 解析 `inputMediaPoll`（题目/答案/quiz 正确答案索引/关闭时间）、
    `inputMediaGeoPoint`、`inputMediaContact`、`inputMediaDice`
  - `materialize_input_media` 校验并写入特殊媒体；联系人名片会按手机号解析 `user_id`
  - `media_bytes` 输出 `messageMediaPoll`（含按查看者计算的 chosen/total_voters）、
    `messageMediaGeo`、`messageMediaContact`、`messageMediaDice`
  - 新增 `messages.sendVote`（校验选项、单/多选、已关闭，写 `te_poll_votes`，
    向私聊双方或群成员推送逐用户 `updateMessagePoll`）与 `messages.getPollResults`
- 冒烟新增断言：
  - `P1-4 poll: question/answers/vote/results round-trip OK`：发送 2 选项投票、
    `getHistory` 校验题目/答案/0 票、`sendVote` 后 `getPollResults` 校验总票数与 chosen
  - `P1-4 geo/contact/dice: file-less media round-trip OK`：经纬度、手机号/姓名、
    骰子 `value(1..6)` 与 emoticon 回读一致
- 验证：`cargo clippy --workspace --all-targets -- -D warnings` 通过，
  `cargo test --workspace` 31 个通过；测试库执行 `0024` 后完整冒烟通过；生产库已执行迁移，
  生产 Rust 重启后 `/healthz` 正常
- 已知限制：
  - 投票不支持 `messages.getPollVotes`（投票人列表）、`messages.editMessage` 修改投票、
    quiz 答案解析展示、频道 poll 的 PTS 差分
  - 投票关闭时间只存储，没有到期 worker 自动关闭
  - 位置只支持静态 `geoPoint`，未实现 `geoPointLive` / 实时位置
  - 联系人名片只按手机号做一次精确/加号匹配解析 `user_id`，不写入联系人

## 46. 消息浏览量（2026-11-04）

状态：**已完成**（`messages.getMessagesViews` 真实计数，`message#` 回传 views）。

- 迁移 `0025_p1_5_message_views.sql`：`te_messages.views bigint NOT NULL DEFAULT 0`
  （必须用 bigint，`message_record` 以 i64 解码，integer 会导致静默解析失败）
- `repo.rs`：
  - `MessageRecord` 增加 `views`
  - 所有消息 SELECT/RETURNING 列补 `views`，`message_from_row` 读取
  - 新增 `increment_message_views(chat_id, ids)`（`views = views + 1`）
    与 `message_views(chat_id, ids)`（按请求 id 顺序返回，缺失补 0）
- `tl`：
  - `MessageExtras` 增加 `views`，`message#` 在 `views > 0` 时置 flags.10
    并写 `views` + `forwards=0`
  - 新增 `MESSAGE_VIEWS#455b853d` 常量与 `types::messages_message_views(views, chats, users)`
- `rpc.rs`：
  - `messages.getMessagesViews` 改为真实实现：解析 peer/ids/increment，
    非私聊且 `increment=true` 时递增，随后回读计数并按 peer 附 chats/users
  - `message_extras_from_record` 写入 `views`
- 冒烟新增断言 `P1-5 views: getMessagesViews increments channel post views OK`：
  频道帖子初始 0 次浏览 → `increment=false` 仍为 0 → `increment=true` 变 1 →
  另一端 `getHistory` 的 `message#` 携带 views=1 → 再次非递增查询仍为 1
- 验证（2026-11-04）：`cargo clippy --workspace --all-targets -- -D warnings` 通过，
  `cargo test --workspace` 全绿，测试库冒烟输出
  `P1-5 views: getMessagesViews increments channel post views OK`；
  生产库 `yun.public` 已执行 `0025`，生产进程重启后 `/healthz` 返回 ok
- 已知限制：
  - 浏览量只在 `messages.getMessagesViews` 递增，普通 `getHistory` 不计数
  - 链接预览（`messages.getWebPage`）与频道统计（`stats.getBroadcastStats` /
    `stats.getMegagroupStats`）仍未实现

## 47. QR 登录（2026-11-04）

状态：**已完成**。

- 迁移 `0026_p2_1_qr_login.sql`：`te_login_tokens`
  （token bytea 主键、exporter_auth_key_id、api_id、created_at、expires_at、
  confirmed_user_id、used）
- `repo`：`create_login_token`（顺带清理过期行）、`confirm_login_token`、
  `take_confirmed_login_token`（原子消费最新确认 token）
- `auth.exportLoginToken`：已被确认 → 绑定 session 并返回
  `auth.loginTokenSuccess#390d5c5e`；否则返回 32 字节 token + 120 秒有效期
- `auth.importLoginToken`：已登录会话确认 token，未知/过期/已用返回
  `LOGIN_TOKEN_INVALID`
- 冒烟断言 `P2-1 QR login: export/confirm/authorize round-trip OK`：
  新 auth key 导出 token → client_b 确认 → 新 auth key 再次导出得到
  `loginTokenSuccess` 且 user id 与 B 一致 → 伪造 token 返回 400
- 验证（2026-11-04）：clippy/`cargo test --workspace` 通过，测试库迁移 `0026`
  后完整冒烟通过；生产库已执行 `0026`，生产重启后 `/healthz` ok
- 注意：桌面端 `loginToken#629f1980` 无 flags；`loginTokenSuccess` 为 `390d5c5e`

## 48. 活跃设备与踢会话（2026-11-04）

状态：**已完成**。

- 迁移 `0027_p2_3_session_metadata.sql`：`te_sessions` 增加
  `api_id`、`app_name`、`lang_code`
- `repo::SessionDevice` + `save_session` 记录设备信息；`list_user_sessions`、
  `delete_user_session`（只允许删自己的会话）、`delete_other_user_sessions`
- `account.getAuthorizations` 返回 `account.authorizations#4bff8ea0`，
  每项 `authorization#ad01d61d`（current 标志 = 当前 auth_key）
- `account.resetAuthorization`：撤销指定 auth_key（`te_auth_keys` 删除后
  会话级联删除），当前会话被撤销时立刻清空 ctx 用户
- `auth.resetAuthorizations`：撤销除当前会话外的全部授权
- **会话失效立即生效**：`repo::touch_session` 改为 `UPDATE ... RETURNING user_id`，
  监听器每条消息都用返回值代替握手套接缓存，因此被踢的连接下一个请求即 401
- 冒烟断言 `P2-3 active devices: list/reset session OK`：QR 会话与 client_b
  同时出现在列表 → client_b 撤销 QR 会话的 hash → QR 客户端立刻
  `AUTH_KEY_UNREGISTERED`
- 验证（2026-11-04）：clippy/`cargo test --workspace` 通过、测试库完整冒烟通过；
  生产库已执行 `0027`，生产重启后 `/healthz` ok
- 限制：不会主动断开 socket（靠下一请求鉴权失败）；`country`/`region` 为空

## 49. channelDifferenceTooLong 完整快照（2026-11-04）

状态：**已完成**（本项无新迁移）。

- `repo::channel_oldest_update_pts`：`SELECT min(pts) FROM te_update_log WHERE channel_id = $1`，
  结果按 `Option<i64>` 解码（`pts` 为 bigint，用 i32 解码会 500）。
- `updates.getChannelDifference`：`pts >= current_pts` → `channelDifferenceEmpty`；
  `pts + 1 < oldest` → `updates.channelDifferenceTooLong#a4bcc6fe`
  （dialog `#fc89f7f3`、最新 `limit` 条消息倒序转正序、频道 `chats`、空 `users`、`final`），
  否则按原 `channelDifference` 返回。
- TL 新增 `types::updates_channel_difference_too_long` writer。
- 冒烟新增 `parse_channel_difference_too_long`：解析顺序为
  flags → dialog（flags/peer/peerChannel id/top_message/再 6 个 i32/peerNotifySettings）
  → messages 向量。
- 冒烟断言 `P4-1 channelDifferenceTooLong: snapshot with 5 messages OK`
  （`pts = -1`），完整冒烟其余项全部通过。
- 验证（2026-11-04）：clippy `-D warnings`、`cargo test --workspace` 通过；
  测试库完整冒烟通过；生产重启后 `/healthz` 返回 `{"db":true,"redis":true,"schema":"public","status":"ok"}`。
- 限制：`updates.getDifference` 的 `differenceTooLong` 仍无完整快照；快照为最新 `limit` 条，非全量历史。

## 50. 反应通知设置与未知 RPC 日志（2026-11-04）

状态：**已完成**。

- 迁移 `0028_p4_2_reactions_notify.sql`：`te_reaction_notify_settings`
  （user_id bigint 主键、settings jsonb、updated_at）
- `account.getReactionsNotifySettings#06dd654c`：无记录返回默认
  （`reactionsNotifySettings#71e4ea58` flags=0、`notificationSoundDefault#97e8bebe`、show_previews=true）
- `account.setReactionsNotifySettings#316ce548`：解析 flags 0/1/2 三个
  `ReactionNotificationsFrom`（`#bac3a61a` contacts / `#4b9e22a0` all），
  `NotificationSound`（default/none/local title+data/ringtone id），
  以及 `show_previews` Bool；转 jsonb 落库并回显
- `repo::reaction_notify_settings` / `save_reaction_notify_settings`
  （`ON CONFLICT (user_id) DO UPDATE`）
- 未知 RPC：`RpcFailure::method_not_found` 用进程级 `HashSet<u32>` 限流，
  每个构造器只 warn 一次（`unsupported RPC method`）
- 冒烟断言 `P4-2 reactionsNotifySettings: get/set persisted OK`
  （默认值校验 → set 三项 all + 默认 sound → 再 get 回读一致）
- 验证（2026-11-04）：clippy `-D warnings`、`cargo test --workspace` 通过；
  测试库执行 `0028` 后完整冒烟通过；生产库执行 `0028` 后重启，
  `/healthz` 返回 `{"db":true,"redis":true,"schema":"public","status":"ok"}`

## 51. 管理后台用户/会话/成员管理（2026-11-04）

状态：**已完成**（Rust admin API + yun 后台接入）。

- 迁移 `0029_admin_user_management.sql`：`te_users.banned_at timestamptz NULL`
- Rust admin（Bearer 鉴权，写操作复用 RPC 内部逻辑，保证 `te_update_log`、
  PTS 与 UpdateHub 一致）：
  - `POST /admin/telegram/update-user`：名字/姓氏/用户名（空用户名清除、重名校验）
  - `POST /admin/telegram/ban-user`：封禁/解封；封禁同时删除该用户全部 auth key，
    `authorize` 对封禁账号返回 401 `USER_DEACTIVATED_BANNED`
  - `POST /admin/telegram/kick-session` / `kick-all-sessions`
  - `POST /admin/telegram/add-member` / `remove-member`：基础群与超级群/频道；
    基础群复用 `add_basic_group_member`（服务消息 + participants 更新），
    频道走 `publish_channel_update`（PTS + `te_update_log` + UpdateHub）
  - `POST /admin/telegram/promote-member`：`rights_flags > 0` 设为管理员，`0` 取消
- `repo::user_banned` / `set_user_banned`
- yun（FastAPI `/api/admin`）：只读 `telegram_user_sessions`、`telegram_chat_members`，
  上述写接口代理；`telegram_users` 增加 `banned`；后台 UI 增加
  「编辑/设备/封禁」与「成员」面板（加人、移出、设/取消管理员、单设备/全部踢下线），
  `app.js` 版本 `20261104r`
- 验证（2026-11-04）：clippy、`cargo test --workspace`、完整冒烟通过；
  测试库 HTTP 验证 update-user、ban/unban、add/remove-member、promote/demote、
  kick-all-sessions 成功，`te_chats.pts` 与 `te_update_log` 同步增长；
  生产库执行 `0029` 后重启，`/healthz` ok；yun 新路由返回 401（非 404），
  只读 SQL 与 `app.js` 语法检查通过
- 限制：未提供删除用户（级联涉及会话/消息/群主关系，按约束不擅自删生产数据）；
  管理员权限位沿用 Telegram flags，UI 默认 127

## 52. 管理后台账号详情与消息批量删除（2026-11-05）

状态：**已完成**。

- Rust：新增 `POST /admin/telegram/delete-messages` `{chat_id, message_ids[]}`，
  覆盖私聊/基础群/超级群/频道；复用 `delete_messages_in_chat`，PTS、`te_update_log`
  与 UpdateHub 与客户端删除一致；单次上限 100 条，空列表返回 400，
  全部不存在返回 404。`admin_delete_message` 改为委托 `admin_delete_messages`
- yun：新增 `GET /telegram_user_detail`（资料、统计、设备、最近会话、最近发送）与
  `POST /telegram_delete_messages`（按 chat_id 分组调用 Rust，返回删除总数）
- 后台 UI：账号行增加「详情」弹窗（编辑资料/发消息/封禁/单设备与全部踢下线）；
  消息页增加勾选列、「全选本页」与「批量删除」条；`app.js` 版本 `20261105a`
- 验证（2026-11-05）：clippy、`cargo test --workspace`、完整冒烟通过；
  测试库批量删除 chat 4 的 2 条消息（14→12，返回 `deleted=2`），空列表 400、
  不存在消息 404；生产 `/healthz` ok 且新路由可达（不存在会话返回 404）；
  yun TestClient 验证详情 200（统计/设备/会话/最近消息完整）与批量删除分组代理，
  线上新路由返回 401、静态资源版本 `20261105a`

## 53. 管理后台操作审计（2026-11-05）

状态：**已完成**。

- 迁移 `0030_admin_audit.sql`：`te_admin_audit(id, actor, action, target_user_id,
  target_chat_id, target_message_id, params jsonb, success, error, created_at)`，
  按用户/会话/时间建索引
- Rust：所有 `/admin/telegram/*` 写接口与 `/admin/system-message` 统一经
  `with_audit` 落审计；操作者取自请求头 `X-Admin-Actor`（默认 `admin`，截断 64 字符）；
  成功与失败都会记录，审计写入失败只告警，不影响主操作
- yun：`_admin_call` 透传 `X-Admin-Actor`（se 管理员账号）；`telegram_user_detail`
  增加 `audit` 字段（该账号为目标的记录，或该账号拥有会话上的操作，最近 20 条），
  并把参数压成一行中文描述
- 后台 UI：账号详情新增「操作审计」区块（成功/失败徽标、动作、摘要、操作者、时间）
  `app.js` 版本 `20261105b`
- 验证（2026-11-05）：clippy、`cargo test --workspace` 通过；生产库/测试库均执行
  `0030`；生产调用 `delete-message`（不存在会话）返回 404，审计表新增
  `audit-verify / delete_message / success=false / CHAT_ID_INVALID`；
  经 yun 调用同一接口返回 400，审计记录 actor 为真实 se 账号；
  `GET /telegram_user_detail?user_id=6` 返回 1 条审计（封禁/解封、失败）；
  静态资源版本与 `/healthz` 正常
- 限制：审计仅覆盖 Rust admin 写接口，Python 只读查询不记录；暂不提供审计导出/清理


## 54. 管理后台 Telegram 概览（2026-11-05）

状态：**已完成**。

- yun 新增只读 `GET /api/admin/telegram_overview`：一次 SQL 汇总账号（总数/封禁/今日新增/
  7 日活跃）、会话（私聊/基础群/超级群/频道/成员/用户会话）、消息（总数/今日/近 7 日/
  定时待发/含媒体）、媒体（数量与体积按图片/视频/文件）、设备（总数/15 分钟活跃/登录用户）、
  反应/审计/更新日志计数
- 后台「聊天」分组新增「概览」页签（`telegram_overview`），仪表盘卡片分区展示，
  30 秒自动刷新；进入时隐藏搜索栏与数据表格
- 验证（2026-11-05）：`node --check`、`py_compile` 通过；重启 yun 后接口 200，
  生产返回账号 7 / 会话 38 / 消息 224 / 媒体 49（约 45.5 MB）/ 设备 49；
  `/apps/admin/` 与 `app.js?v=20261105c` 返回 200 且包含新页签
- 限制：仅数据库计数，不含磁盘实际占用与真实在线连接数


## 55. 超级群 / 频道详情与设置（2026-11-05）

状态：**已完成**。

- Rust admin 新增 `POST /admin/telegram/ban-chat-user` / `create-invite` / `revoke-invite`：
  封禁默认 `flags=1` 并移出成员，支持期限；邀请链接可设人数上限/过期；三者均写
  `te_update_log`、递增频道 PTS、推送 `updateChannel`
- yun 新增 `GET /api/admin/telegram_chat_detail`（资料、统计、管理员、封禁、邀请）与
  `POST telegram_chat_ban` / `telegram_chat_invite_create` / `telegram_chat_invite_revoke`
- 后台「会话」页超级群/频道行「详情」弹窗，`app.js?v=20261105d`
- 验证（2026-11-05）：`cargo check` / `cargo build` / `node --check` / `py_compile` 通过；
  会话 37（group）、38（channel）详情 200 且管理员 1 人；创建邀请后 DB `revoked=false`、
  撤销后 `revoked=true`；封禁用户 2 后 `te_chat_bans` 有记录且成员只剩群主，解封后记录清空，
  重新加回成员恢复；审计含 `ban_chat_user` / `create_invite` / `revoke_invite`
- 限制：管理员权限仍是裸 flags；邀请固定 `request_needed=false`；成员全量仍在「成员」面板


## 56. 存储统计与清理（2026-11-05）

状态：**已完成**。

- 新增 `crates/server/src/storage.rs`：递归扫描 `data/media`（`spawn_blocking`），按顶层目录
  统计；汇总 `te_media_files`（含 thumb_size）、`te_media_thumbs`、`te_upload_parts`；
  对比引用键识别孤儿文件与 DB 缺失文件
- Rust admin 新增 `POST /admin/telegram/storage-stats` / `storage-cleanup`；清理仅删除
  未被引用且早于 `min_age_secs`（默认 3600）的文件，审计动作 `storage_cleanup`
- yun 新增 `POST /api/admin/telegram_storage_stats` / `telegram_storage_cleanup` 代理
- 后台「聊天」分组新增「存储」页（`telegram_storage`），`app.js?v=20261105e`
- 验证（2026-11-05）：`cargo check` / `build` / `node --check` / `py_compile` 通过；
  扫描 76 个文件约 46.5 MB、DB 媒体 49 条；创建 2 小时前 1 MB 测试孤儿文件后，统计
  `orphans=1`，清理返回 `deleted_files=1, deleted_bytes=1048576`，文件确认删除，再次
  扫描 `orphans=0`；审计出现成功的 `storage_cleanup`
- 限制：不删除空目录、不自动修复缺失记录，全量扫描未缓存


## 57. 批量群发（2026-11-05）

状态：**已完成**。

- Rust admin 新增 `POST /admin/telegram/broadcast`：系统助手发送，服务端去重并预检账号，
  逐账号返回 `{sent, skipped, failed:[{user_id,error}]}`，审计动作 `broadcast_message`
- yun 新增 `POST /api/admin/telegram_broadcast` 代理，兼容数组与逗号/空白分隔 ID，
  自动去重并校验单批 ≤200、文本 ≤4096
- 后台「聊天」分组新增「群发」页，含 ID 识别计数、字符计数、结果与失败列表
- 验证（2026-11-05）：向 `3,4,4,999` 发送测试文本返回 `sent=2, total=3`，999 为
  `USER_INVALID`；产生 2 条 `te_messages` 并通过批量删除接口清理为 0；审计记录成功；
  `app.js?v=20261105f` 正常加载
- 限制：仅文本、发送方固定系统助手、单批 200 个账号、无定时群发


## 58. 独立操作审计页（2026-11-05）

状态：**已完成**。

- yun 新增只读 `GET /api/admin/telegram_audit`：支持操作者、动作、结果（成功/失败）、
  目标账号、目标会话、关键词（操作者/动作/参数/错误）、起止日期与分页；返回行内
  含 `action_label` / `target_label` / `detail` / `success_label`，并附带全表动作去重计数
  `actions`
- 新增 `GET /api/admin/telegram_audit_export`：按当前筛选导出 CSV（UTF-8 BOM，最多 5000 条），
  `Content-Disposition` 文件名带时间戳
- 后台「聊天」分组新增「审计」页（`telegram_audit`），独立筛选条（操作者/动作下拉/结果/
  日期区间/关键词/查询/重置/导出 CSV），隐藏通用搜索栏；结果列使用成功/失败徽章；
  审计页不显示编辑/删除按钮（`canDelete` 已排除）
- 验证（2026-11-05）：`py_compile`、`node --check` 通过；重启 yun 后接口 200，
  当前 13 条记录；`actor=wuzhen` 11 条、成功 10 条/失败 3 条、`keyword=broadcast` 2 条、
  今日 13 条、非法日期被忽略、不存在的目标账号 0 条；导出 CSV 含 BOM、表头与数据行正确
- 限制：CSV 单次最多 5000 条；动作下拉计数是全表统计而非当前筛选结果；日期按服务器本地时区


## 59. 运营账号与权限页（2026-11-05）

状态：**已完成**。

- yun 新增只读 `GET /api/admin/telegram_operators`：基于 `users` 表返回账号/昵称/邮箱/角色/
  状态/注册时间，并 LEFT JOIN `te_admin_audit` 按 `actor = account` 统计操作总数、失败数与
  最近操作时间；支持角色、状态、关键词筛选与分页，附全表角色计数 `roles`
- 新增 `POST /api/admin/telegram_operator_update`：修改角色（se / admin / 普通用户）与
  启用状态；禁止把自己降级或禁用；启用/禁用都会清空 `users.token`，禁用立即失效
- 后台「聊天」分组新增「运营账号」页（`telegram_operators`）：角色/状态/操作数/最近操作
  列表，行内「启用/禁用」与角色下拉 + 保存角色；独立筛选条；支持新建账号（复用
  `POST /api/admin/users`，要求邮箱唯一）
- 验证（2026-11-05）：`py_compile`、`node --check` 通过；重启 yun 后接口 200，现有 20 个
  账号（普通用户 19、se 1）；创建临时账号后 keyword 命中 1 条；改角色→管理员、禁用→
  status=0 且 token 清空；修改自己角色/非法角色/非法状态均返回 400；删除临时账号后查询为 0，
  当前管理员 token 未受影响
- 限制：`users.email` 有唯一约束，新建时必须填唯一邮箱；角色权限目前只区分 `se`（后台全权）
  与其他角色（无后台管理权限）；角色变更不写 `te_admin_audit`（该表只记录 Rust admin 写操作）

## 60. 会话改标题/头像（2026-11-05）

状态：**已完成**。

- Rust 新增 `admin_update_chat` 与 `POST /admin/telegram/update-chat`：仅允许基础群/超级群/频道。
  标题复用 `messages.editChatTitle` 的服务消息流程（基础群发 `edit_title` 服务消息，
  超级群/频道发 `updateChannel`）；头像直接复用 `apply_chat_photo`，因此 PTS、`te_update_log`
  与在线推送与客户端修改完全一致；头像传 `photo_media_id=0` 表示清除
- yun 新增 `POST /api/admin/telegram_chat_update`，标题必填、最多 255 字，头像媒体 ID 需为非负整数；
  `telegram_chat_detail` 增加返回 `photo_media_id`
- 后台「会话详情」弹窗新增「会话设置」：标题输入 + 头像媒体 ID + 保存设置；基础群也显示详情入口
- 验证（2026-11-05）：`cargo check`/`clippy -D warnings`/`test`、`py_compile`、`node --check` 通过；
  创建临时基础群 → 改标题并清空头像成功，库内 `te_chats.title` 更新为 `smoke-basic-renamed`；
  不存在会话返回 404，私聊返回 400

## 61. 消息编辑（2026-11-05）

状态：**已完成**。

- Rust 把 `messages_edit_message` 的落库、PTS、`updateEditMessage` 推送逻辑抽成
  `apply_message_edit`，客户端 RPC 与新的 `admin_edit_message` 共用同一实现
- 新增 `POST /admin/telegram/edit-message`：校验会话/消息归属、服务消息不可编辑、文本 1–4096 字；
  编辑者使用会话创建者作为 actor，保证推送内容与客户端一致
- yun 新增 `POST /api/admin/telegram_edit_message`；后台消息列表新增「编辑」按钮（服务消息禁用）
- 验证（2026-11-05）：编辑私聊消息成功，库内 `te_messages.text` 变为 `smoke-edited`；
  编辑服务消息返回 400；编辑不存在的消息返回 400/404

## 62. 消息置顶/取消置顶（2026-11-05）

状态：**已完成**。

- Rust 把 `messages.updatePinnedMessage` 的私聊/基础群/频道三套 PTS 与推送逻辑抽成
  `apply_pinned_message`，客户端 RPC 与 `admin_pin_message` 共用
- 新增 `POST /admin/telegram/pin-message`：`message_id=0` 取消置顶；校验消息属于该会话；
  私聊使用 `private_user_a` 作为 actor，避免 PTS 归属错乱
- yun 新增 `POST /api/admin/telegram_pin_message`，并在 `telegram_messages` 返回 `pinned`
  （`c.pinned_msg_id = m.id`）；后台消息行新增「置顶 / 取消置顶」按钮
- 验证（2026-11-05）：置顶后 `te_chats.pinned_msg_id` 等于消息 ID，取消置顶后归零；
  私聊置顶/取消同样通过

## 63. 新建/删除会话（2026-11-05）

状态：**已完成**。

- Rust 新增 `admin_create_chat`：支持 `basic_group` / `group` / `channel`；创建者必须存在，
  成员 ID 去重并校验存在性；基础群走 `create_basic_group` + `create` 服务消息 +
  `deliver_basic_group_message`，超级群/频道走 `create_channel` + 成员入库 + 对话框 +
  `publish_channel_update`
- Rust 新增 `admin_delete_chat`：仅非私聊；先按每批 100 条调用 `delete_messages_in_chat`
  让在线成员收到删除推送并写入 `te_update_log`，再硬删除 `te_chats`，消息/成员/对话框/
  邀请/封禁/频道更新由 `ON DELETE CASCADE` 一并清理；返回删除的消息条数
- yun 新增 `POST /api/admin/telegram_chat_create` 与 `POST /api/admin/telegram_chat_delete`
- 后台会话页新增「新建会话」弹窗（类型/创建者/标题/简介/成员）与行内「删除」按钮
- 验证（2026-11-05）：创建基础群 #42 → 改名 → 置顶/取消 → 删除，库内 `te_chats` 归零；
  创建频道成功并可删除；非法类型/不存在会话返回 400/404
- 语义说明：删除是服务端级联硬删除，在线客户端会先收到消息删除更新；会话列表残余项
  在下次拉取时消失，不额外推送「会话删除」更新（MTProto 无对应构造函数）

## 64. P4-8 剩余项（删除用户 / 加入请求）

状态：**已完成（2026-11-05）**。

- **删除用户**：`admin_delete_user(user_id, dry_run)`；`dry_run` 仅统计拥有的群/频道、
  私聊、发送消息数与媒体数；系统助手账号拒绝；仍拥有非私聊会话返回 400 `USER_OWNS_CHATS`。
  执行时先按私聊删除消息（推送 + `te_update_log`），删除私聊，再删除其他会话中的消息并
  清理指向它们的 `pinned_msg_id`，将媒体 `owner_user_id` 置空，最后删除 `te_users`，
  其余由外键级联
- **加入请求**：迁移 `0031_join_requests.sql` 新增 `te_join_requests`（chat+user 唯一，
  pending/approved/rejected）；`exportChatInvite` 支持 `request_needed`（flag bit3），
  `checkChatInvite` 返回该标记，`importChatInvite` 命中时只写 pending 请求、不加入；
  `admin_review_join_request` 通过时补成员/对话框/频道更新，拒绝只改状态
- yun：`telegram_user_delete`（dry_run 预览 + 执行）、`telegram_join_requests` 列表、
  `telegram_join_request_review`；会话详情返回 `pending_join_requests`；邀请创建支持
  `request_needed`；账号行内「删除」、会话详情审批按钮、邀请「需要审批」勾选

### 验证记录（2026-11-05）

- 测试 schema（`telegram_server.test`，第二实例 3811/3812）播种用户 #101、私聊 #9001、
  3 条消息、1 个媒体、群 #9002 与 pending 申请：
  - `delete-user` dry_run → `private_chats=[9001]`、`messages=2`、`media=1`
  - 执行 → `deleted=3`；用户/会话/消息全部消失，媒体 `owner_user_id=NULL`，审计写入
  - `review-join-request` 通过 → 成员/对话框/`te_update_log(channel_id=9002)` 写入，
    `status=approved`；重复审批返回 400 `JOIN_REQUEST_HANDLED`
  - 拒绝用例 → `status=rejected`，未加入
  - `create-invite request_needed=true` → `te_chat_invites.request_needed=true`
- 生产 `/healthz` 与 yun 代理：`telegram_join_requests` 返回空列表；
  `telegram_user_delete` dry_run 返回真实影响（未执行）；不存在用户 404、系统账号 400、
  不存在会话审批 400 `CHAT_ID_INVALID`；生产未新增临时数据
- 测试数据清理：删除测试会话/用户/媒体后，测试 schema 相关计数归零

## 65. P2-2 两步验证（SRP）（2026-11-05）

状态：**已完成（2026-11-05）**。

- 迁移 `0032_two_step_verification.sql`：`te_users` 增加密码相关列；已应用到
  `yun.public` 与 `telegram_server.test`，并在两处 `te_schema_migrations` 记录
- `crates/server/src/srp.rs`：Telegram SRP-6a（SHA-256、2048 位安全素数、`g=3`），
  服务器保存 verifier；`start()` 返回 `srp_id` 与 `g_b`，`check()` 校验 `A`/`M1`
- RPC：`account.getPassword`（完整 `account.password`）、`auth.checkPassword`、
  `account.updatePasswordSettings`（设置/修改/清除）、`account.getPasswordSettings`；
  `auth.signIn` 在账号启用 2FA 时返回 `401 SESSION_PASSWORD_NEEDED`
- 自动化验证：
  - `cargo test -p tsrv-server srp`：5 个用例通过（正确密码、错误密码、失效 srp_id、
    算法参数、verifier 边界）
  - `cargo clippy -p tsrv-server --all-targets -- -D warnings` 通过
  - 生产 `/healthz` 返回 `{"db":true,"redis":true,"schema":"public","status":"ok"}`
- 手工验证建议（需真实客户端）：登录 → 设置 → 隐私与安全 → 两步验证，设置密码后
  退出重登应出现密码页；错误密码提示错误，正确密码进入；关闭两步验证后直接登录
- 限制：SRP 挑战与待登录用户保存在内存（10/30 分钟），服务器重启后需重新登录；
  未实现恢复邮箱、Passkey 与邮箱验证码

## 66. P1-3 消息格式化实体（2026-11-05）

状态：**已完成（2026-11-05）**。

- 复用既有 `te_messages.entities` JSONB 列，按 hex 数组保存原始 `MessageEntity` 构造器
- `messages.sendMessage` / `messages.sendMedia` / `messages.sendMultiMedia` /
  `messages.editMessage` 解析 `entities:flags.3`；`message#` 以 `entities:flags.7`
  原样回传，历史、实时推送、转发与定时消息一致
- 覆盖 `messageEntityPre/TextUrl/MentionName/CustomEmoji/Blockquote/FormattedDate/
  DiffReplace` 等构造器；`inputMessageEntityMentionName` 自动转换为
  `messageEntityMentionName`
- 偏移/长度按 UTF-16 校验，越界实体丢弃；编辑消息不带 entities 时清空旧实体
- 自动化验证：
  - `cargo test --workspace`：全绿（新增 `message_entities_are_serialized_after_text`）
  - `cargo clippy --workspace --all-targets -D warnings` 通过
  - 完整冒烟新增断言 `P1-3 message entities: send/echo/edit-clear OK`
  - 生产 Rust 已用新二进制重启，`/healthz` 返回
    `{"db":true,"redis":true,"schema":"public","status":"ok"}`
- 限制：草稿（`messages.saveDraft`）仍不保存 entities；实体只做原样回传，
  不做富文本渲染校验







