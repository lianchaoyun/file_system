# 实现路线图

## P0 项目骨架与基础设施

状态：**已完成**。

目标：

- Rust workspace 可编译
- 配置加载
- 日志
- PostgreSQL/Redis 连接
- `3801` listener
- 健康检查

交付：

- `cargo check` 通过
- `cargo test` 通过
- `scripts/dev.ps1`
- 测试 schema 初始化

预计：2-4 天

## P1 MTProto 握手与登录

状态：**已完成**（2026-11-03）。

已交付：

- TCP abridged / intermediate / padded intermediate
- Telegram Desktop 混淆传输（AES-CTR deobfuscation）
- RSA + DH 完整握手
- auth key / server salt / session 入库
- 同一连接 persistent + temporary auth key
- `auth.bindTempAuthKey`（P1 返回 boolTrue；P7 已实现持久化绑定与 key 失效处理）
- `auth.sendCode` / `auth.signIn` / `auth.signUp`，固定验证码 `12345`；未注册号码的 `auth.signIn` 返回 `auth.authorizationSignUpRequired`，桌面端据此进入注册页
- `help.getConfig` / `help.getNearestDc` / `langpack` / `messages.getDialogs` 等登录后基础 RPC
- `scripts/smoke.ps1` 覆盖握手 + 登录 + 空会话列表
- 真实 Telegram Desktop 使用独立 `tdata` 指向 `127.0.0.1:3801`，已验证进入主界面

目标：

- TCP abridged/intermediate
- auth key 握手
- auth key 持久化
- `auth.sendCode`
- `auth.signIn`
- `auth.signUp`
- 固定验证码 `12345`
- 客户端能进入主界面

交付：

- 冒烟 1-6 通过
- auth key 和 authorization 入库
- 未知 RPC 返回正确错误

预计：2-4 周

## P2 一对一文本聊天

状态：**已完成**（2026-11-03，`updates.getDifference` 目前返回空差量，历史由 `getDialogs` / `getHistory` 恢复）。

已交付：

- `messages.getDialogs` / `getPeerDialogs` / `getPinnedDialogs`
- `messages.getHistory`
- `messages.sendMessage`
- `messages.readHistory`
- `updates.getState`
- PTS 按用户递增，消息 / 会话 / 未读写入 PostgreSQL
- 实时 `updateNewMessage` 推送到在线连接
- 双向私聊、会话列表、历史、未读数冒烟通过
- 真实 Telegram Desktop 显示私聊会话、双向消息、未读数和历史

目标：

- `messages.getDialogs`
- `messages.getHistory`
- `messages.sendMessage`
- `messages.readHistory`
- `updates.getState`
- `updates.getDifference`
- PTS / seq / date
- 断线重连

交付：

- 两个测试账号互发文本
- 历史和未读数正确
- 冒烟 7-9、20-22 通过

预计：4-6 周

## P3 群组与频道

状态：**已完成**（2026-11-03）。

已交付：

- `channels.createChannel`（超级群 / 广播频道）
- `channels.inviteToChannel` / `joinChannel` / `leaveChannel`
- `channels.getFullChannel` / `getParticipants`
- 超级群成员可发文本、频道仅所有者可广播
- 群组/频道会话列表、历史消息、未读数
- 频道 PTS 与实时 `updateNewChannelMessage`
- `chats.access_hash` / `chats.pts` 迁移
- 真实 Telegram Desktop 显示超级群和广播频道、双向群消息、频道广播、发送者与 Seen 状态

目标：

- `channels.createChannel`
- 群组成员
- 频道订阅
- 群组文本
- 频道广播文本
- 基础权限

交付：

- 冒烟 10-15 通过
- 普通成员不能在频道发消息
- 非成员不能读频道历史

预计：4-6 周

## P4 图片与视频

状态：**已完成**（2026-11-03）。

已交付：

- `upload.saveFilePart` / `upload.saveBigFilePart` 分片上传与临时分片清理
- `upload.getFile` 按 offset/limit 读取，支持 `inputPhotoFileLocation` / `inputDocumentFileLocation` / `inputFileLocation`
- `messages.sendMedia` / `messages.uploadMedia`
- `inputMediaUploadedPhoto` / `inputMediaUploadedDocument` 解析
- Photo / PhotoSize / Document / DocumentAttribute / MessageMedia 序列化
- 图片（PNG/JPEG）尺寸检测、MP4 宽高与时长解析
- `media_files` 入库、sha256 校验、`data/media/files` 存储
- 私聊、群组、频道消息均携带媒体，会话列表/历史/实时推送同步显示
- 冒烟测试覆盖多分片 PNG、`saveBigFilePart` MP4、群组图片，双端下载并比较 sha256
- 真实 Telegram Desktop 显示 `Photo, 1×1` 和 `Video, sample.mp4, 00:01, 640×480, 100 B`

目标：

- `upload.saveFilePart`
- `upload.saveBigFilePart`
- `upload.getFile`
- `messages.sendMedia`
- 图片缩略图
- 视频按文件上传/下载

交付：

- 冒烟 16-19 通过
- sha256 校验通过
- 上传临时文件清理

说明：缩略图生成本阶段未实现；照片使用单档 `photoSize("m")`，视频使用 `documentAttributeVideo` 携带尺寸与时长。客户端的 `upload.getFileHashes` 返回空列表。

预计：3-5 周

## P5 客户端兼容与稳定

状态：**已完成**（2026-11-03）。

已交付：

- Telegram Desktop 重新登录、会话列表、私聊/群组/频道、图片/视频消息
- Android 客户端（`telegram-afat-debug-selfhost.apk`）通过自定义服务器 `127.0.0.1:3801` 登录
- Android 会话列表显示私聊、超级群、频道和图片/视频预览
- 桌面端与 Android 同时在线，B 发送的消息两端实时收到
- `msgs_ack` 回环修复：服务端不再确认客户端的确认消息
- `user` flags 修复：只有当前账号设置 `self` 位，避免 Android 把其他用户显示为“收藏夹”
- 常用可选 RPC 兼容桩：主题、表情状态、贴纸集、聊天筛选、国家列表、通知设置等
- 30 分钟健康检查与在线稳定性记录（`data/p5-stability.log`）

已知限制（记录在 `04-test-plan.md`）：

- LDPlayer14 的 Android 14 镜像在频繁 UI 操作后会出现 `Too many Binders sent to SYSTEM` 并杀死 Telegram 进程，属于模拟器限制
- 清理 Android 应用数据后，tgnet 偶尔复用旧 auth key，服务端返回 `unknown auth_key_id`，需重新登录或重启模拟器
- 同一账号多设备之间的发出消息同步尚未实现（当前推送主要面向接收方；P6 已实现）
- `auth.bindTempAuthKey` 仍只返回 `boolTrue`，暂未持久化临时 key 绑定关系（P7 已修复）

目标：

- Telegram Desktop 登录/聊天
- Android 登录/聊天
- 双端在线
- 30 分钟稳定性
- 日志与错误码整理

交付：

- 手工验收清单通过
- 已知问题清单
- 第一版发布说明

预计：4-6 周

## P6 同一账号多设备同步

状态：**已完成**（2026-11-03）。

已交付：

- `RpcContext` 记录 MTProto `session_id`
- `UpdateHub` 支持 `exclude_session_id`，避免发送方连接收到自己的同步推送
- 私聊：发送成功后向发送者账号的其他在线 session 推送 `updateNewMessage`（`out=true`）
- 群组/频道：发送成功后向发送者账号的其他在线 session 推送 `updateNewChannelMessage`
- 接收方所有在线 session 都会收到推送
- 冒烟客户端新增 A2（同账号第二 session）：
  - B 的消息同时到达 A1/A2
  - A2 发出的消息同步到 A1
  - A1 发出的消息同步到 A2，且 A1 自己不重复收到
  - 群组消息同步到 A2
- 真实 Telegram Desktop 验证：桌面端作为 A 的第三个 session，实时收到 `multi-device from A2`、`multi-device from A1`、`multi-device group`

目标：

- 多端登录同一账号
- 自己发出的消息同步到其他在线设备

交付：

- 冒烟 demo A1/A2
- 真实桌面端显示同步消息

## P7 临时 auth key 持久化与失效

状态：**已完成**（2026-11-03）。

已交付：

- `p_q_inner_data_temp` / `p_q_inner_data_temp_dc` 解析 `expires_in`，写入 `auth_keys.expires_at`
- 永久 key 写入 `expires_at = 0`，临时 key 写入绝对过期时间
- 迁移 `0005_p7_temp_keys.sql`：`auth_keys.expires_at` + `temp_auth_key_bindings`
- `auth.bindTempAuthKey`：
  - 解析 `bind_auth_key_inner`
  - 校验 `nonce` / temp key / perm key / `temp_session_id` / `expires_at`
  - 使用 old-MTProto x=0 密钥调度解密（与官方服务端一致）
  - 持久化 temp→perm 绑定，拒绝一把 temp 绑定到不同 perm
  - 在绑定和 `auth.signIn` 时双向复制 session / update_states
- 临时 key 过期：
  - 边缘在握手/连接复用/逐帧处理时检查 `auth_keys.expires_at`
  - 过期返回 transport `-404` 并关闭连接，Telegram Desktop 会销毁临时 key 并重新握手
- 冒烟覆盖绑定、非法密文、重复绑定、持久化重连、过期断言、transport `-404`
- 真实 Telegram Desktop 验证：临时 key 过期后自动重建并成功绑定永久 key，绑定落库且账号在线
- `tsrv-migrate` 迁移运行器：按 `schema_migrations` 增量执行，兼容已手工迁移的 `dev` / `test`

目标：

- 临时 key 生命周期可持久化
- `auth.bindTempAuthKey` 真正生效
- 临时 key 失效后官方客户端能自动恢复

交付：

- 单元测试 + 冒烟 + 真实桌面端验证
- 数据模型 / 测试记录 / 发布说明更新

## P8 媒体缩略图与文件哈希

状态：**已完成**（2026-11-03）。

已交付：

- 迁移 `0006_p8_media_thumbs.sql`：`thumb_width` / `thumb_height` / `thumb_size`
- 图片组装后生成 320px 内 JPEG 缩略图，小图不放大
- `messageMediaPhoto` 返回 `photoSize("m")` + `photoSize("x")`
- 文档 `thumbs` 返回缩略图
- `upload.getFile` 按 `thumb_size` 区分缩略图/原图
- `upload.getFileHashes` 返回请求偏移处 1MB 范围的 SHA-256
- 单元测试覆盖缩略图生成；真实桌面端解析到 m/x 两档

目标：

- 桌面/Android 图片列表直接显示缩略图
- 断点续传/文件校验具备 hash 基础

## P9 消息操作

状态：**已完成**（2026-11-03）。

已交付：

- 迁移 `0007_p9_message_actions.sql`：回复、编辑、转发来源字段 + `chats.pinned_msg_id`
- 回复：`inputReplyToMessage` → `messageReplyHeader`
- 编辑：`messages.editMessage` 文本编辑 + `edit_date` + `updateEditMessage`
- 删除：`messages.deleteMessages` / `channels.deleteMessages` + 顶消息刷新
- 转发：私聊/频道来源 → `messageFwdHeader`，支持用户和频道两种 from
- 置顶：`messages.updatePinnedMessage` + `updatePinnedMessages` / `updatePinnedChannelMessages`
- `messages.getMessages` / `channels.getMessages` 支持按 id 获取并过滤权限
- 冒烟覆盖回复、编辑、删除、转发、置顶、频道转发
- 真实 Telegram Desktop 同步收到 edit/delete/forward/pin 更新

目标：

- 官方客户端常用消息操作可用
- 多端同步覆盖编辑、删除、转发、置顶

## P10 PTS 增量同步

状态：**已完成**（2026-11-03）。

已交付：

- 迁移 `0008_p10_update_log.sql`：`update_log` 按 user / channel 保存每个 PTS 的完整 Update
- 新消息、编辑、删除、置顶写入 update_log
- `updates.getState` 返回 PTS、日期、seq、总未读数
- `updates.getDifference`：
  - `difference` / `differenceSlice` / `differenceTooLong`
  - 超过 1000 条切片并返回 intermediate_state
  - 历史缺口过大强制客户端重新拉取
- `updates.getChannelDifference`：`channelDifference` / `channelDifferenceEmpty`
- 冒烟覆盖离线补齐与频道补齐；桌面端持续在线

目标：

- 客户端离线/重连后按 PTS 补齐消息与操作
- 为后续 `updates.getDifference` 完整语义打基础

## P11 媒体 caption 编辑与转发参数

状态：**已完成**（2026-11-03）。

已交付：

- `messages.editMessage` 支持 `media` 参数，保留原 photo，只更新 caption 与 `edit_date`
- `messages.forwardMessages` 支持 `reply_to`（`inputReplyToMessage`）
- `messages.forwardMessages` 支持 `drop_media_captions`
- 冒烟覆盖媒体 caption 编辑、带 reply_to 转发
- 真实 Telegram Desktop 收到 caption edit（保留 `messageMediaPhoto`）和带 reply 头的转发

目标：

- 官方客户端常用编辑/转发操作可用
- 保持已有媒体不丢失

## P12 界面语言包（2026-11-03）

状态：**已完成**。

已交付：

- `langpack.getLanguages` 返回可用语言列表（`en` + `zh-hans`）
- `langpack.getLanguage` 返回单个语言的元数据（`langPackLanguage`）
- `langpack.getLangPack` 返回完整 `langPackDifference`（约 8800 条 `langPackString`）
- `langpack.getStrings` 按 key 精准返回字符串
- `langpack.getDifference` 支持客户端缓存版本增量（`from_version >= 1` 返回空差异）
- 语言包文件放在 `data/langpacks/<lang>.strings`（`TSRV_LANGPACK_DIR` 可覆盖），服务启动时加载并缓存编码结果
- `zh-hans` 语言包来自 `https://translations.telegram.org/zh-hans/tdesktop/export`
- 冒烟覆盖 4 个 langpack RPC；`langpack.getLangPack` 返回 8858 条字符串

注意：

- 语言包在启动时加载，新增语言文件后需要重启服务
- 切换语言后桌面端会自行重启，重启后通过 `langpack.getDifference` 命中缓存

## P13 系统助手与默认好友（2026-11-03）

状态：**已完成**。

已交付：

- 服务启动自动创建系统账号 `+10000000000`（系统助手），每个用户首次登录/注册后自动建立私聊并收到欢迎消息
- `contacts.search`：按名字 / 手机号 / 用户名搜索用户，桌面端“新建聊天”可用
- `messages.getEmojiKeywords`、`messages.exportChatInvite`（返回 `https://t.me/+<随机>`）
- 开发用接口 `POST http://127.0.0.1:3802/admin/system-message`，让系统助手给任意用户发消息，用于真机验证（配置 `TSRV_ADMIN_TOKEN` 后需带 `Authorization: Bearer <token>`）

待办：

- `messages.createChat`（基础群）需要 `chat#` + `peerChat` 模型，尚未实现
- `messages.searchGlobal`、头像上传 `photos.uploadProfilePhoto` 仍为空/未实现

## P14 基础群 / 全局搜索 / 头像（2026-11-03）

状态：**已完成**。

已交付：

- `messages.createChat`（基础群，`chat#` + `peerChat`）
- `messages.getChats` / `messages.getFullChat`
- 基础群发消息、历史、已读、会话列表、全局搜索
- `messages.searchGlobal` 跨会话文本搜索
- 基础群的编辑/置顶/删除（`messages.editMessage` / `messages.updatePinnedMessage` /
  `messages.deleteMessages` 均按 `peerChat` 逐成员推送 `updateEditMessage` /
  `updatePinnedMessages` / `updateDeleteMessages`）
- `messages.getMessages` 对基础群返回 `message#` + `chat#`（而非 channel 构造器）
- `photos.uploadProfilePhoto` / `photos.updateProfilePhoto`，`user#` 带头像
- `photos.getUserPhotos`（个人资料照片页）
- 客户端源码定制（同时编译）：账号上限 3/6 → **10**，所有账号按 Premium 处理
  - 产物：`E:\game\Telegram\td_telegram\out\Release\Telegram.exe`（2026-11-03 构建）
  - 注：Release 链接 262 MB 静态 Qt 时 32 位 `link.exe` 会 `LNK1102`（内存不足），
    本次通过单线程 `/m:1` + 关闭 `GenerateDebugInformation` 链接成功；
    CMake 重新生成 `Telegram.vcxproj` 后需要再次关闭调试信息

待办：

- 视频/文档替换媒体、schedule / send_as
- Premium 真实内容（贴纸、emoji 状态、Stories、礼物、语音转写）
- Android 30 分钟双端稳定性复验

## P15 基础群成员管理与服务消息（2026-11-03）

状态：**已完成**。

已交付：

- `messages.addChatUser` / `messages.deleteChatUser` / `messages.editChatTitle`
- `messages.unpinAllMessages`（私聊 / 基础群 / 超级群）
- migration `0011`：服务消息字段，重建 `messageService#` 的
  `ChatCreate` / `ChatAddUser` / `ChatDeleteUser` / `ChatEditTitle`
- 成员变化推送 `updateChatParticipants`，服务消息让新成员立即出现在会话列表
- `messages.getMessages` 的基础群返回 `message#` + `chat#`
- `messages.deleteHistory` / `messages.deleteChat` 清空历史与删除会话
- `messages.editMessage` 的 `media` 替换（上传/已有照片或文档/清空）

待办（剩余）：

- 视频/文档替换媒体（已支持基础替换）、schedule / send_as
- Premium 真实内容（贴纸、emoji 状态、Stories、礼物、语音转写）
- Android 30 分钟双端稳定性复验

## P16 消息反应（2026-11-03）

状态：**已完成**。

已交付：

- `messages.sendReaction`（添加/切换/移除），返回并推送 `updateMessageReactions`
- `message#` 的 `reactions:flags.20` 在历史、`getMessages`、编辑更新中带出
- 每个查看者的 `chosen_order` 单独计算
- 冒烟覆盖添加与移除

后续：

- 消息反应（已完成）
- 群/频道头像编辑、计划消息、多档缩略图等见“下一步”

## P17 群/频道头像（2026-11-03）

状态：**已完成**。

已交付：

- `messages.editChatPhoto` / `channels.editPhoto`（上传 / 已有 / 移除）
- `chat#` / `channel#` / `chatFull` 带真实 `chatPhoto`
- `upload.getFile` 支持 `inputPeerPhotoFileLocation`
- 冒烟覆盖上传与下载比对

## P18 计划消息（2026-11-03）

状态：**已完成**。

已交付：

- `messages.scheduled_date` 迁移与待发送消息隐藏规则
- `messages.getScheduledHistory` / `sendScheduledMessages` / `deleteScheduledMessages`
- `messages.sendMessage` / `messages.sendMedia` 的 `schedule_date` 参数
- `updateNewScheduledMessage` / `updateDeleteScheduledMessages` 同步
- 后台 5 秒 worker 自动投递到期消息
- 冒烟覆盖存储、隐藏、删除、立即发送与到期自动发送

## 总计

1 名开发者：约 5-8 个月

2-3 名开发者：约 3-5 个月

## 关键风险

| 风险 | 影响 | 对策 |
|---|---|---|
| 官方客户端请求未知 RPC | 登录卡住/白屏 | 按日志逐步补；未知方法返回兼容错误 |
| PTS/update 语义错误 | 消息不刷新、未读数错误 | 先固定每会话 PTS 流，写端到端测试 |
| 群组/频道权限复杂 | UI 状态不一致 | 第一版只做 creator/member |
| 媒体协议复杂 | 上传失败/下载 404 | 先做本地文件 + Range；后做 S3 |
| 新数据库 schema 与旧服务数据迁移 | 以后替换需迁移 | 第一版独立设计，迁移阶段单独规划 |
| 重写范围失控 | 周期翻倍 | 严格按阶段和验收标准推进 |

## P19 多档媒体缩略图（2026-11-03）

状态：**已完成**。

已交付：

- `media_thumbs` 表与 `s` / `m` / `x` 三档缩略图
- 图片多档 JPEG 生成；视频通过 ffmpeg 抽帧后生成多档
- `photo#` / `document#` 多档 `photoSize`，`upload.getFile` 按档解析
- 照片 `x` 档保持原图下载，视频 `x` 档为 640px 预览
- 冒烟覆盖图片 s/m 与视频 s/m 缩略图下载

## P20 更多语言包（2026-11-03）

状态：**已完成**。新增官方 `ru` / `zh-hant` 语言包，`getLanguages` 返回 4 种语言。

## P21 运维清理与管理接口（2026-11-03）

状态：**已完成**。

- 每小时的 `update_log` / 临时 key / 残留上传分片清理
- `GET /admin/stats` 与 `POST /admin/maintenance`
- 保留期可通过环境变量调整

## P22 Premium 贴纸与 emoji 状态（2026-11-03）

状态：**已完成（第一阶段）**。

- 播种官方 StatusPack（11 个真实 `.tgs` 自定义 emoji）
- `messages.getStickerSet` / `getStickers` / `getEmojiStickers` /
  `getCustomEmojiDocuments` 返回真实文档
- `account.updateEmojiStatus` / `getDefaultEmojiStatuses` /
  `getRecentEmojiStatuses` 与 `user#` emoji status 已接入
- 冒烟覆盖贴纸集、状态设置与贴纸下载
- 后续阶段：Stories、礼物、语音转写

## P23 PTS 增量快照（2026-11-03）

状态：**已完成**。`updates.getDifference` / `updates.getChannelDifference`
把新消息拆入 `new_messages`，其余更新保留在 `other_updates`。

## P24 数据库迁移到 yun.public.te_（2026-11-03）

状态：**已完成**。

- Rust 服务端数据库从 `telegram_server.dev` 迁移到 `yun.public`
- 全部 16 张表统一 `te_` 前缀（`te_users` / `te_messages` / `te_chats` 等），
  避免与 `yun` 原有 `users` / `sessions` 冲突
- SQL、迁移文件、索引名、约束名同步改为 `te_` 前缀
- `TSRV_DB_DSN` 指向 `yun`，`TSRV_DB_SCHEMA=public`
- 迁移前后行数逐表一致；冒烟测试在 `telegram_server.test` 上通过
- 旧 `telegram_server.dev` 保留为回滚备份

## P25 在线状态 / 正在输入 / 已读回执（2026-11-04）

状态：**已完成**。

- 在线状态：进程内按 `(auth_key_id, session_id)` 统计在线会话；断开/登出自动注销，
  最后一次离线写入 `te_users.last_seen_at` 并向私聊对端推送 `updateUserStatus`
- `user#` status 返回 online / offline(was_online) / recently 三种真实状态
- 正在输入：私聊 `updateUserTyping`、基础群 `updateChatUserTyping`、
  频道 `updateChannelUserTyping`，支持 cancel 与上传进度 action
- 已读回执：私聊/基础群的 inbox、outbox 均写 `te_update_log` 并递增对应用户 PTS；
  频道只向自己其它会话同步 outbox
- 冒烟新增 4 条 P0-1 断言，完整冒烟通过

## P26 联系人 / 拉黑 / 隐私（2026-11-04）

状态：**已完成**（隐私规则仅持久化，未参与可见性计算）。

- 新增 `te_contacts`、`te_blocked_users`、`te_privacy_settings`（迁移 `0017`）
- `contacts.getContacts` 返回真实联系人；`addContact` / `deleteContacts` 即时生效
- `contacts.block` / `unblock` / `getBlocked` 可用
- 双向拉黑后私聊发送返回 `403 USER_IS_BLOCKED`，并从联系人与搜索中隐藏
- `account.setPrivacy` / `getPrivacy` 持久化 allow/disallow × all/contacts/users 规则
- 冒烟新增 4 条 P0-2 断言，完整冒烟通过

## P27 群/频道管理员、封禁、邀请链接、用户名（2026-11-04）

状态：**已完成**（加入请求审批于 P52 补齐）。

- 迁移 `0018`：`te_chat_members` 支持 `admin` + 权限 JSON；新增 `te_chat_bans`、`te_chat_invites`；
  `te_users` / `te_chats` 增加大小写不敏感唯一用户名索引
- `channels.editAdmin` / `editBanned`、管理员权限校验、封禁拦截发送与重新加入
- 真实邀请链接：`exportChatInvite` / `checkChatInvite` / `importChatInvite`
- 用户名：`account.checkUsername` / `updateUsername`、`channels.checkUsername` / `updateUsername`、
  `contacts.resolveUsername`
- `channel#` 携带 username 与 admin_rights；`getParticipants` 返回 creator/admin 角色
- 管理员/封禁变化写 `te_update_log`、递增频道 PTS 并推送 `updateChannel`
- 冒烟新增 4 条 P0-4 断言，完整冒烟通过；生产库已执行迁移
- 已知限制：加入请求（request_needed）、基础群管理员/封禁、`updateUserName` 推送、
  重新登录时按查看者回填管理员权限

## P28 草稿、会话置顶、文件夹（2026-11-04）

状态：**已完成**（文件夹仅保存原始过滤器数据）。

- 迁移 `0019`：`te_drafts`、`te_pinned_dialogs`、`te_dialog_filters`
- `messages.saveDraft` / `getAllDrafts`，空文本等价清除；草稿保存纯文本与 `reply_to`
- `messages.toggleDialogPin` / `reorderPinnedDialogs`；`getPinnedDialogs` 只返回置顶会话，
  `getDialogs` 的 `dialog#` 带 `pinned:flags.2` 并把置顶排在最前
- `messages.updateDialogFilter` / `getDialogFilters` 原样存取 `DialogFilter` 字节
- 冒烟新增 3 条 P0-3 断言，完整冒烟通过；生产库已执行迁移
- 已知限制：草稿忽略 entities/media；文件夹不参与过滤；草稿/置顶/过滤器不写 PTS、不跨设备推送

## P29 个人简介与生日（2026-11-04）

状态：**已完成**。

- 迁移 `0020`：`te_users.bio`、`birthday_day` / `birthday_month` / `birthday_year`
- `account.updateProfile` 的 `about`（flags.2）写入 `te_users.bio`
- `account.updateBirthday`（`cc6e0c11`，缺省 `birthday` 即清除）写入生日
- `users.getFullUser` 返回 `userFull.about`（flags.1）与 `birthday`（flags2.5）
- 冒烟新增 `P0-5 profile: bio/birthday OK`，完整冒烟通过；生产库已执行迁移
- 已知限制：保留字仅最小集合；`userFull` 其余可选字段未实现；生日未严格校验闰年与 150 岁上限

## P30 语音/音频消息（2026-11-04）

状态：**已完成**。

- 迁移 `0021`：`te_media_files` 增加 `audio_voice` / `audio_title` / `audio_performer` / `audio_waveform`
- `documentAttributeAudio` 解析与回写（voice、duration、title、performer、waveform）
- 冒烟新增 `P1-1 voice: documentAttributeAudio round-trip OK`，完整冒烟通过；生产库已执行迁移
- 已知限制：波形原样存储不生成；不转码；未实现音频封面 thumbnail

## P31 相册 / 多图消息（2026-11-04）

状态：**已完成**。

- 迁移 `0022`：`te_messages` 增加 `grouped_id`，并为非零分组建立部分索引
- `messages.sendMultiMedia` 解析 `Vector<InputSingleMedia>`，同一批次共享一个 `grouped_id`
- `message#` 输出 `grouped_id:flags.17`，客户端据此合并为相册
- 冒烟新增 `P1-2 album: two messages share grouped_id OK`，完整冒烟通过；生产库已执行迁移
- 已知限制：不合并 caption；定时相册逐条写入同一 group id

## P32 贴纸 / 自定义 emoji 文档属性（2026-11-04）

状态：**部分完成**。

- 迁移 `0023`：`te_media_files` 增加贴纸/自定义 emoji 属性列
- 解析 `documentAttributeSticker` / `documentAttributeCustomEmoji`，发送时原样回写
- 内置 StatusPack 播种时写入 `custom_emoji` 等列
- 冒烟新增 `P1-3 sticker: documentAttributeSticker round-trip OK`
- 未完成：文本内 `messageEntityCustomEmoji`、`messages.getCustomEmojiDocuments`、自建贴纸包

## P33 投票 / 位置 / 联系人名片 / 骰子（2026-11-04）

状态：**已完成**。

- 迁移 `0024`：`te_media_files` 允许 `poll`/`geo`/`contact`/`dice` 并增加 `media_payload jsonb`；
  新增 `te_poll_votes`
- `inputMediaPoll` / `inputMediaGeoPoint` / `inputMediaContact` / `inputMediaDice` 解析与发送
- `messageMediaPoll`（含逐查看者投票结果）、`messageMediaGeo`、`messageMediaContact`、
  `messageMediaDice` 回传
- `messages.sendVote` / `messages.getPollResults` 可用，投票结果推送给私聊双方或群成员
- 冒烟新增 `P1-4 poll: ...` 与 `P1-4 geo/contact/dice: ...` 两条断言，完整冒烟通过；
  生产库已执行迁移
- 已知限制：无 `getPollVotes`/投票编辑/自动关闭；位置不含实时位置；联系人名片不写联系人

## P34 消息浏览量（2026-11-04）

状态：**已完成**（链接预览与频道统计仍属 P1-5 剩余项）。

- 迁移 `0025`：`te_messages.views` 计数列
- `repo` 新增 `increment_message_views` / `message_views`，消息记录统一带 `views`
- `message#` 在 views>0 时输出 `views`+`forwards`（flags.10）
- `messages.getMessagesViews` 真实递增并回传 `messages.messageViews`
- 冒烟断言 `P1-5 views: getMessagesViews increments channel post views OK` 通过；
  clippy/测试全绿；生产库 `0025`（bigint）已执行，生产重启后 `/healthz` ok
- 剩余：`messages.getWebPage` 链接预览、`stats.getBroadcastStats`/`stats.getMegagroupStats` 频道统计

## P35 QR 登录（2026-11-04）

状态：**已完成**。

- 迁移 `0026`：`te_login_tokens`（token/expires/confirmed_user_id/used）
- `auth.exportLoginToken` 真实 token（32 字节、120 秒）与确认后返回
  `auth.loginTokenSuccess#390d5c5e`；`auth.importLoginToken` 确认并校验
- 冒烟断言 `P2-1 QR login: export/confirm/authorize round-trip OK` 通过
- 已知限制：未使用 `except_ids`；token 不含 DC id（单 DC 部署）

## P36 活跃设备与踢会话（2026-11-04）

状态：**已完成**。

- 迁移 `0027`：`te_sessions` 增加 `api_id`/`app_name`/`lang_code`；`SessionDevice`
- `account.getAuthorizations`（`authorization#ad01d61d`，current 标志）、
  `account.resetAuthorization`、`auth.resetAuthorizations`
- `touch_session` 改为 `RETURNING user_id`，被撤销的会话下一请求即 401
- 冒烟断言 `P2-3 active devices: list/reset session OK` 通过
- 限制：不主动断 socket；未填 country/region

## P37 channelDifferenceTooLong 完整快照（2026-11-04）

状态：**已完成**。

- `updates.getChannelDifference` 在 `pts + 1 < min(pts)` 时返回
  `updates.channelDifferenceTooLong#a4bcc6fe`：dialog + 最新 `limit` 条消息 + chats
- `repo::channel_oldest_update_pts`（min(pts) 按 i64 解码）
- TL writer `types::updates_channel_difference_too_long`
- 冒烟断言 `P4-1 channelDifferenceTooLong: snapshot with 5 messages OK` 通过
- 限制：`updates.getDifference` 的 too-long 快照未做

## P38 反应通知设置与未知 RPC 日志（2026-11-04）

状态：**已完成**。

- 迁移 `0028`：`te_reaction_notify_settings`（settings jsonb）
- `account.getReactionsNotifySettings` / `setReactionsNotifySettings`
  （`reactionsNotifySettings#71e4ea58` 全字段解析与持久化）
- 未知 RPC：每个构造器每进程只记录一次 `unsupported RPC method`
- 冒烟断言 `P4-2 reactionsNotifySettings: get/set persisted OK` 通过
- 限制：其余缺失 RPC 继续按客户端日志补

## P39 管理后台用户/会话/成员管理（2026-11-04）

状态：**已完成**。

- 迁移 `0029`：`te_users.banned_at`
- Rust admin：update-user / ban-user / kick-session / kick-all-sessions /
  add-member / remove-member / promote-member（Bearer 鉴权）
- 封禁即时撤销全部会话；`authorize` 对封禁账号返回 `USER_DEACTIVATED_BANNED`
- yun 后台：用户编辑/封禁、设备列表与踢下线、成员列表/加人/移出/管理员
- 测试库 HTTP 验证接口，生产执行 `0029` 并重启；`/healthz` ok
- 限制：删除用户见 P52；权限位为原始 flags（UI 默认 127）

## P40 管理后台账号详情与消息批量删除（2026-11-05）

状态：**已完成**。

- Rust：`POST /admin/telegram/delete-messages`（单会话 ≤100 条），复用 RPC 删除逻辑，
  PTS/update_log/UpdateHub 一致
- yun：账号详情只读接口（资料/统计/设备/最近会话/最近发送）与批量删除代理
- 后台 UI：账号详情弹窗、消息勾选 + 全选本页 + 批量删除
- 测试库实测批量删除与边界，生产重启后 `/healthz` ok；yun 线上路由与资源验证通过

## P41 管理后台操作审计（2026-11-05）

状态：**已完成**。

- 迁移 `0030`：`te_admin_audit`（操作者/动作/用户/会话/消息/参数/成功/错误/时间，含索引）
- Rust admin 写接口统一走 `with_audit`，记录成功与失败；操作者来自 `X-Admin-Actor`
- yun 代理透传管理员账号；账号详情新增最近 20 条审计（含中文摘要）
- 生产/测试库迁移完成，端到端验证失败与成功记录、详情展示

## P42 管理后台 Telegram 概览（2026-11-05）

状态：**已完成**。

- yun 新增只读 `GET /api/admin/telegram_overview`，汇总账号/会话/消息/媒体/设备计数
- 后台「聊天」分组新增「概览」页签，卡片式分区展示，30 秒自动刷新
- 验证：接口 200（账号 7、会话 38、消息 224、媒体 49 个约 45.5 MB、设备 49 台）；
  页面与 `app.js?v=20261105c` 正常加载

## P43 超级群 / 频道详情与设置（2026-11-05）

状态：**已完成**。

- Rust admin 新增 `ban-chat-user` / `create-invite` / `revoke-invite`，复用频道 PTS、
  `te_update_log` 与 `updateChannel` 推送
- yun 新增 `GET telegram_chat_detail` 与三个 POST 代理；审计新增 3 个动作
- 后台「会话」行新增「详情」弹窗：管理员设/取消、封禁并移出/解封、邀请链接创建/撤销
- 验证：会话 37/38 详情 200；邀请创建→撤销状态正确；封禁移除成员、解封恢复，审计落库

## P44 存储统计与清理（2026-11-05）

状态：**已完成**。

- 新增 `storage.rs`：扫描 `data/media` 目录、汇总 DB 媒体/缩略图/上传分片、识别孤儿与缺失文件
- Rust admin 新增 `storage-stats` / `storage-cleanup`（保留时长保护，磁盘删除写审计）
- yun 新增两个 POST 代理；后台「聊天」分组新增「存储」页，支持扫描与清理
- 验证：孤儿测试文件 1 MB 被正确识别并删除（deleted_files=1, 1048576 bytes），再次扫描归零

## P45 批量群发（2026-11-05）

状态：**已完成**。

- Rust admin 新增 `broadcast`：系统助手向 ≤200 个账号发文本，去重、预检账号、逐个收集失败
- yun 新增 `POST telegram_broadcast` 代理（兼容数组/分隔字符串，4096 字上限）
- 后台「聊天」分组新增「群发」页，展示发送结果与失败列表
- 验证：`3,4,4,999` 返回 sent=2/3、999 为 USER_INVALID；测试消息已清理；审计记录成功

## P46 独立操作审计页（2026-11-05）

状态：**已完成**。

- yun 新增 `GET telegram_audit`（操作者/动作/结果/目标/关键词/日期/分页 + 动作计数）
- yun 新增 `GET telegram_audit_export`（CSV，UTF-8 BOM，最多 5000 条）
- 后台「聊天」分组新增「审计」页，独立筛选条与导出按钮，成功/失败徽章
- 验证：13 条记录，筛选组合与计数一致；CSV 导出含 BOM 与正确表头/数据行

## P47 运营账号与权限页（2026-11-05）

状态：**已完成**。

- yun 新增 `GET telegram_operators`：users 表 + `te_admin_audit` 操作统计，支持角色/状态/
  关键词/分页
- yun 新增 `POST telegram_operator_update`：角色与启用状态修改，自降级/自禁用保护，
  禁用即清空 token
- 后台「聊天」分组新增「运营账号」页，独立筛选条、行内角色/状态操作、新建账号
- 验证：20 个账号；临时账号创建→改角色→禁用→清理全链路通过；非法参数与自保护均 400

## P48 会话改标题/头像（2026-11-05）

状态：**已完成**。

- Rust `admin_update_chat` 复用 `messages.editChatTitle` 服务消息与 `apply_chat_photo`
- 新增 `POST /admin/telegram/update-chat`，支持标题与头像媒体 ID（0=清除）
- yun `POST telegram_chat_update`；会话详情新增「会话设置」，基础群也可打开详情
- 验证：临时基础群改名 + 清空头像成功，库内标题更新；非法会话/私聊返回 400/404

## P49 消息编辑（2026-11-05）

状态：**已完成**。

- `messages_edit_message` 的落库/PTS/推送逻辑抽成 `apply_message_edit`，客户端与后台共用
- 新增 `POST /admin/telegram/edit-message` 与 yun `telegram_edit_message`
- 后台消息行新增「编辑」按钮，服务消息禁用编辑
- 验证：私聊消息编辑后库内文本变化；服务消息/不存在消息被拒绝

## P50 消息置顶/取消置顶（2026-11-05）

状态：**已完成**。

- `messages.updatePinnedMessage` 的三套推送逻辑抽成 `apply_pinned_message`
- 新增 `POST /admin/telegram/pin-message`（`message_id=0` 取消）与 yun `telegram_pin_message`
- 消息列表返回 `pinned`，行内新增置顶/取消置顶按钮
- 验证：置顶/取消后 `te_chats.pinned_msg_id` 正确变化，私聊与群聊均通过

## P51 新建/删除会话（2026-11-05）

状态：**已完成**。

- Rust `admin_create_chat` 支持基础群/超级群/频道，成员校验去重，复用现有创建/服务消息/
  频道更新流程
- Rust `admin_delete_chat` 先分批删除消息（推送 + `te_update_log`），再硬删除会话，
  依赖外键级联清理成员/对话框/邀请/封禁
- yun 新增 `telegram_chat_create` / `telegram_chat_delete`；后台新增新建会话弹窗与行内删除
- 验证：基础群创建→改名→置顶→删除、频道创建→删除全链路通过；非法类型/不存在会话被拒绝

## P52 删除用户 / 加入请求审批（2026-11-05）

状态：**已完成**。

- 删除用户：`admin_delete_user` 支持 `dry_run` 影响预览（私聊/消息/媒体），系统账号拒绝，
  仍拥有群/频道时返回 `USER_OWNS_CHATS`；执行时先删消息（推送 + `te_update_log`）、
  再删私聊、清理其他会话消息与置顶、释放媒体归属并删除账号
- 加入请求：迁移 `0031_join_requests.sql`；邀请链接支持 `request_needed`（导出 flag bit3、
  `checkChatInvite` 输出、`importChatInvite` 只建 pending 请求）；`admin_review_join_request`
  通过与拒绝，通过时补成员/对话框并推送频道更新
- yun：账号行内删除（预览 + 二次确认）、`telegram_join_requests` 列表、
  `telegram_join_request_review` 审批、会话详情待审批列表、邀请创建「需要审批」勾选
- 验证：测试 schema 播种数据验证删除级联（用户/私聊/消息删除、媒体归属置空）与
  approve/reject 全链路（成员、对话框、update_log、重复审批拒绝）；生产仅 dry_run 与
  负向用例，无新增临时数据

## P53 两步验证（SRP）（2026-11-05）

状态：**已完成**。

- 迁移 `0032_two_step_verification.sql`：`te_users` 增加 `password_srp_id`、
  `password_salt1/2`、`password_verifier`、`password_hint`、`password_g`、
  `password_updated_at`
- `crates/server/src/srp.rs`：Telegram SRP-6a（SHA-256 + 2048 位安全素数），
  服务器保存 verifier，登录时校验 `A`/`M1`
- RPC：`account.getPassword` 返回完整密码参数；`auth.signIn` 对启用 2FA 的账号返回
  `401 SESSION_PASSWORD_NEEDED`；`auth.checkPassword` 完成登录；
  `account.updatePasswordSettings` 支持设置/修改/清除密码；`account.getPasswordSettings`
- 验证：SRP 单元测试 5 个通过、`clippy -D warnings` 通过、迁移应用到生产与测试
  schema、生产 `/healthz` 正常

## P54 消息格式化实体（2026-11-05）

状态：**已完成**。

- `MessageEntity` 原始 TL 字节以 hex 数组存入 `te_messages.entities`，
  `message#` 以 `entities:flags.7` 原样回传
- 覆盖 `messages.sendMessage` / `sendMedia` / `sendMultiMedia` / `editMessage`；
  转发保留实体，编辑不带 entities 时清空
- 新增 TL 序列化单元测试；完整冒烟新增
  `P1-3 message entities: send/echo/edit-clear OK`
- 限制：草稿仍不保存 entities；用户自建贴纸包另属独立阶段

## 下一步

P14-P54 已完成（P32 部分完成），后续按优先级推进：

1. P1-5 剩余：`messages.getWebPage` 链接预览、频道统计 `stats.*`
2. ~~P1-3 剩余：消息实体 + `messages.getCustomEmojiDocuments`~~ ✅ 2026-11-05
   （剩余用户自建贴纸包，属独立阶段）
3. Premium 后续阶段：Stories、礼物、语音转写
4. P4-3 老视频缩略图回填
5. P4-8 已收尾；如需继续删除用户，可补「群主转移」后放开带群账号删除
6. P2-2 后续（可选）：恢复邮箱 / Passkey / 邮箱验证码、SRP 挑战持久化

每次迭代仍以 `cargo test`、`cargo clippy`、完整冒烟和真实客户端验证为完成标准。

## 2026-11-03 本轮完成

- 基础群：创建、成员增删、改名、编辑/置顶/删除/清空历史、服务消息
- 全局搜索、头像上传与 `photos.getUserPhotos`
- 编辑消息替换媒体（上传/已有/清空）
- 客户端定制编译：账号上限 10、全部账号 Premium（`out\Release\Telegram.exe`）
- 验证：`cargo test` 30 个通过、`clippy -D warnings` 通过、
  MTProto 冒烟 P2-P12 全量通过（含新增基础群/服务消息/媒体替换/清空历史断言）
