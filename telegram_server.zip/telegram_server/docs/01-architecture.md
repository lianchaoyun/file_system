# 总体架构设计

## 1. 目标

实现一个实验性的 Rust Telegram 服务端，优先保证：

1. 现有桌面端和 Android 客户端能够连接、登录
2. 可以完成一对一文本聊天
3. 可以创建基础群组和频道
4. 可以上传/下载图片和视频文件
5. 通过 AI 自动化冒烟测试
6. 不影响现有 Go 生产服务

## 2. 非目标

第一版明确不做：

- 多 DC
- 短信/邮件发送
- QR / Passkey / WebAuthn 登录
- Bot API
- 管理后台
- 审核、认证、收藏用户名
- 音视频通话、TURN、SFU、RTMP
- E2E secret chat
- 集群和水平扩展

## 3. 系统结构

```text
Telegram Desktop / Android
            │
            │ MTProto TCP
            ▼
┌──────────────────────────┐
│ crates/server            │
│  TCP transport + dispatch │
└────────────┬─────────────┘
             │
┌────────────▼─────────────┐
│ crates/mtproto           │
│  handshake / crypto      │
│  session / transport     │
└────────────┬─────────────┘
             │ TL request
┌────────────▼─────────────┐
│ crates/domain            │
│  auth / dialog / message │
│  channel / media         │
└───────┬────────────┬─────┘
        │            │
        ▼            ▼
  PostgreSQL      Redis
  durable state   temporary state
        │
        ▼
  media files / S3
```

## 4. 代码结构

```text
crates/tl
  - Layer 232 所需的 TL 类型
  - 序列化/反序列化
  - 错误类型和错误码
  - 测试向量

crates/mtproto
  - transport: abridged / intermediate
  - auth key exchange
  - AES-IGE / RSA / SHA / HMAC
  - encrypted envelope
  - session salt、message id、seq
  - auth key 持久化接口

crates/store
  - PostgreSQL repositories
  - migrations
  - Redis auth code / rate limit / session cache
  - media metadata

crates/domain
  - auth service
  - user service
  - dialog service
  - message service
  - channel service
  - media service
  - update service

crates/server
  - TCP listener
  - connection lifecycle
  - RPC router
  - config
  - graceful shutdown
  - health/metrics
```

## 5. MTProto

### 5.1 协议版本

- Layer 232
- MTProto 2.0
- 第一版支持 `abridged` 和 `intermediate` 两种 TCP transport
- 后续按客户端日志再补 full transport

### 5.2 握手流程

```text
client -> req_pq_multi
server -> resPQ
client -> req_DH_params
server -> server_DH_params_ok
client -> set_client_DH_params
server -> dh_gen_ok
```

需要：

- 服务端 RSA 私钥
- 大数运算
- SHA1/SHA256
- AES-IGE
- auth_key 生成与持久化
- auth_key_id 计算

### 5.3 Session

每个连接保存：

- auth_key
- session_id
- server_salt
- 最近 message id
- seq
- user_id（登录后才绑定）

持久化：

- `auth_keys`
- `sessions`
- `update_states`

Redis 只做缓存，不作为 auth key 的唯一存储。

### 5.4 RPC 分发

```text
解密 -> 提取 method -> 查路由表 -> 处理 -> 加密响应
```

要求：

- 未知方法返回明确的 `METHOD_NOT_FOUND` 或 `RPC_CALL_FAIL`
- 未登录连接只允许 `auth.*`、`help.*`
- 每个方法设置超时和最大请求大小

## 6. PostgreSQL

PostgreSQL 是唯一持久化真源。

第一版使用独立数据库：

```text
telegram_server
```

开发 / 测试使用两个 schema，而不是复制整库：

```text
dev
test
```

以后需要区分正式环境时可增加：

```text
prod
```

应用启动时设置：

```text
search_path = <schema>, public
```

这样测试可以只清空 `test` schema，不会影响 `dev`；也不修改现有：

```text
telesrv_main
```

表结构重新设计，不沿用 Go 服务的表结构。MTProto API 兼容性只取决于 RPC 返回，不取决于数据库表名。

核心表：

- `users`
- `auth_keys`
- `sessions`
- `chats`
- `chat_members`
- `messages`
- `user_dialogs`
- `media_files`
- `upload_parts`
- `update_states`
- `update_events`

详细字段见 `03-data-model.md`。

## 7. Redis

Redis 只保存可丢失的临时数据：

```text
auth:code:<phone>       固定验证码，TTL 5 分钟
auth:attempt:<phone>    尝试次数
rate:auth:<ip>          登录限流
rate:rpc:<user_id>      RPC 限流
session:<auth_key_id>   会话缓存
updates:<user_id>       可选的更新队列缓存
```

消息、用户、群组、频道和媒体元数据不能只存在 Redis。

## 8. 更新模型

简化版：

- 每个 auth key/会话保存自己的 `pts`、`qts`、`seq`、`date`
- `update_states` 以 `auth_key_id` 为主键
- `update_events` 按用户记录发生的事件
- `updates.getState` 返回当前会话状态
- `updates.getDifference` 返回 PTS 之后的事件

事件类型第一版只需要：

- `new_message`
- `read_history`
- `dialog_update`
- `channel_update`

频道消息也写入同一个用户的 update 流，第一版不做复杂的 channel PTS。

## 9. 媒体

### 9.1 上传

第一版支持：

- `upload.saveFilePart`
- `upload.saveBigFilePart`
- `messages.sendMedia`
- `upload.getFile`

上传流程：

```text
saveFilePart -> upload_parts
saveBigFilePart -> upload_parts
sendMedia -> media_files + messages
getFile -> 从本地文件/S3 读取 Range
```

### 9.2 存储

```text
data/media/<sha256前两位>/<sha256>
```

数据库保存：

- 文件 ID
- access hash
- file reference
- MIME
- 大小
- DC
- 文件属性
- 缩略图信息
- sha256

### 9.3 限制

第一版：

- 图片最大 20MB
- 视频按普通文件，最大 200MB
- 不做转码、不做流式播放、不做 HLS
- 图片生成一个缩略图；视频第一版不生成缩略图

## 10. 群组和频道

使用统一的 `chats` 表，通过 `kind` 区分：

- `private`：一对一
- `group`：群组
- `channel`：广播频道

第一版权限：

- 创建者
- 普通成员
- 频道只有创建者可以发消息
- 群组所有成员可以发文本
- 不做管理员任命、邀请链接、评论、置顶、表情回应

## 11. 安全

- 登录验证码固定仅用于实验环境
- 生产环境必须接真实 OTP
- 限制上传大小和分片数量
- 文件路径只允许由服务端生成
- MIME 只做基础校验
- 所有 SQL 使用参数化查询
- 不在日志中输出 auth key、验证码、完整手机号
- 服务默认只监听 `127.0.0.1:3801`

## 12. 配置

使用环境变量，开发默认值放在 `config/dev.env.example`：

```text
TSRV_LISTEN=127.0.0.1:3801
TSRV_DB_DSN=postgres://.../telegram_server
TSRV_DB_SCHEMA=dev
TSRV_REDIS_URL=redis://127.0.0.1:6379/1
TSRV_MEDIA_DIR=data/media
TSRV_RSA_KEY=../owpengram-232/data/server_rsa.pem
TSRV_FIXED_AUTH_CODE=12345
```

测试环境：

```text
TSRV_LISTEN=127.0.0.1:3801
TSRV_DB_DSN=.../telegram_server
TSRV_DB_SCHEMA=test
TSRV_REDIS_URL=redis://127.0.0.1:6379/2
```

## 13. 关键决策

1. **独立数据库，开发/测试分 schema**
   - 数据库名 `telegram_server`
   - 开发 schema `dev`，测试 schema `test`
   - 不沿用 Go 服务的表结构
   - 不碰生产 `telesrv_main`

2. **独立端口 3801**
   - 生产 Go 服务继续使用 2398
   - 客户端通过自定义服务器地址切换到 3801

3. **复用现有 RSA key 作为开发期测试 key**
   - 客户端已经信任当前公钥，便于快速联调
   - 正式发布前再生成独立 key

4. **先桌面端，后 Android**
   - 桌面端日志和调试更方便
   - Android 只作为兼容性验证

5. **媒体第一版按文件而不是流媒体**
   - 视频不做转码和在线播放
   - 降低第一版复杂度
