# 07 未实现功能与交接说明

> 更新时间：2026-11-04
> 适用对象：接续开发 Telegram 自建服务端（Rust）和 yun 管理后台（FastAPI + Vue）的下一个 AI。
>
> 先读本文档，再读：
> - `docs/01-architecture.md`
> - `docs/03-data-model.md`
> - `docs/04-test-plan.md`
> - `docs/05-roadmap.md`
>
> 注意：README / roadmap / release-notes 里有些“待办”已经完成（例如基础群、全局搜索、头像、多档缩略图、媒体 caption 编辑、计划消息、Premium 贴纸/emoji 状态、管理后台初版）。以本文档和当前代码为准，不要重复实现。

---

## 0. 当前状态一句话

Rust 服务端已经能支撑官方桌面端登录、私聊、基础群、超级群/频道、文本/图片/视频/文件、编辑/删除/转发/置顶/反应、计划消息、多档缩略图、语言包、Premium 贴纸/emoji 状态和 PTS 增量；yun 后台已经能查询账号/会话/消息、发文本私聊、删消息、踢基础群成员、预览图片/视频、过滤测试占位媒体。  
剩下的主要是“官方客户端日常体验”“群/频道管理”“更多消息类型”“账号安全”“Premium 后续”“生产化”，以及管理后台的用户/会话/成员管理。

---

## 1. 运行环境（接手先确认）

### 1.1 代码路径

| 项目 | 路径 |
|---|---|
| Rust 服务端 | `E:\game\Telegram\server\telegram_server` |
| Go 生产服务端 | `E:\game\Telegram\server\owpengram-232`（2398，服务名 `telesrv_main`，**不要动**） |
| 桌面客户端 | `E:\game\Telegram\td_telegram` |
| 客户端数据 | `E:\game\Telegram\users`（`desktop-main` 是生产，**不要动**；`desktop-rust-test` 是测试） |
| yun 管理后台 | `D:\project\yun\ai` |
| 后台管理页面 | `D:\project\yun\ai\public\apps\admin` |

### 1.2 端口与服务

| 端口 | 用途 |
|---|---|
| `127.0.0.1:3801` | Rust MTProto |
| `127.0.0.1:3802` | Rust health / admin HTTP |
| `0.0.0.0:80` | yun FastAPI（NSSM 服务名 `serv`） |
| `2398` | Go 生产服务端（不要占用、不要改） |

yun 服务重启方式（NSSM 会自动拉起）：

```powershell
Invoke-RestMethod -Uri 'http://127.0.0.1/api/shutdown'
```

Rust 服务是手动/后台进程启动的，停止后需要重新运行：

```powershell
cd E:\game\Telegram\server\telegram_server
$env:RUST_LOG = 'info'
.\target\debug\tsrv-server.exe
```

`.env` 会被 `dotenvy` 自动加载，里面包含 DB / Redis / media / RSA / 固定验证码 / `TSRV_ADMIN_TOKEN`。

### 1.3 数据库、Redis、媒体

- PostgreSQL 生产库：`yun`，schema `public`，所有服务端表统一 `te_` 前缀，**没有视图**。
- PostgreSQL 测试库：`telegram_server`，schema `test`（`scripts/smoke.ps1` 使用）。
- Redis：Rust 生产 DB `1`，测试 DB `2`。
- 媒体目录：`E:\game\Telegram\server\telegram_server\data\media`
  - 原文件：`files/`
  - 缩略图：`thumbs/`
  - 贴纸：`stickers/`
- yun 后台媒体预览读取的绝对路径配置在 `D:\project\yun\ai\script\config\config.toml` 的 `[telegram] media_dir`。

### 1.4 密钥与 token

不要在代码、日志、回复里打印 token 明文。需要时从以下文件读取：

- Rust：`E:\game\Telegram\server\telegram_server\.env` → `TSRV_ADMIN_TOKEN`
- yun：`D:\project\yun\ai\script\config\config.toml` → `[telegram] token`
- yun 后台管理员：`users` 表里 `role='se'` 的 `token`

Rust 所有 `/admin/*` 需要：

```http
Authorization: Bearer <TSRV_ADMIN_TOKEN>
```

或：

```http
X-Admin-Token: <TSRV_ADMIN_TOKEN>
```

### 1.5 验证命令

```powershell
cd E:\game\Telegram\server\telegram_server

# 编译 / lint / 单元测试
cargo check -p tsrv-server
cargo clippy --workspace --all-targets -- -D warnings
cargo test --workspace

# 完整冒烟（会占用 3801/3802，必须先停生产 Rust 进程）
.\scripts\smoke.ps1
```

`smoke.ps1` 会使用 `telegram_server.test` 和 Redis DB 2，跑完自动停测试服务。  
如果测试库不存在：

```powershell
# 用脚本里同样的 DSN 创建数据库 telegram_server，并执行：
$env:TSRV_DB_DSN = 'postgres://postgres:<密码>@127.0.0.1:5432/telegram_server'
$env:TSRV_DB_SCHEMA = 'test'
.\target\debug\tsrv-migrate.exe
```

本轮已经修过迁移文件的 UTF-8 BOM，fresh DB 可以正常迁移。

---

## 2. 已完成，勿重复实现

- 手机号登录/注册，固定验证码 `12345`
- TCP abridged / intermediate / padded intermediate / 桌面端混淆传输
- auth key / salt / session 入库，临时 key 绑定与失效处理
- 私聊文本、历史、未读、双向推送
- 基础群（`chat#` + `peerChat`）创建/成员/标题/头像/服务消息
- 超级群 / 广播频道创建、加入、离开、邀请、成员列表、频道 PTS
- 图片/视频/普通文件的上传、下载、多档缩略图
- 消息编辑（文本/caption/基础媒体替换）、删除、转发（基础）、置顶/取消置顶
- 消息反应
- 计划消息（发送、隐藏、立即发送、到期 worker）
- 全局搜索、联系人搜索、表情关键字、邀请链接导出（返回格式可用的假链接）
- 语言包（en / zh-hans / zh-hant / ru）
- Premium 官方 StatusPack（11 个 `.tgs`）与 emoji 状态
- PTS / `update_log` / `updates.getDifference` / `getChannelDifference` 基础增量
- 运维清理 worker、`/admin/stats`、`/admin/maintenance`
- Rust admin API：
  - `POST /admin/telegram/send-message`
  - `POST /admin/telegram/delete-message`
  - `POST /admin/telegram/kick-user`（仅基础群）
- yun 后台：
  - 「聊天 → 账号 / 会话 / 消息」查询
  - 发文本私聊、删消息、踢基础群成员
  - 图片/视频缩略图、原图、视频 Range 播放
  - 「只看真实媒体」过滤 smoke 占位媒体

---

## 3. 未实现 / 占位 / 部分实现清单

状态说明：

- ❌ 完全未实现：没有 dispatch 分支，客户端会收到 `METHOD_NOT_FOUND`
- 🟡 空实现/占位：接口有返回，但数据是空/默认值，功能不可用
- 🟠 部分实现：主流程能用，但缺少常用参数、权限或边界
- ✅ 已完成（上面第 2 节）

### P0：影响官方客户端日常体验

#### P0-1 在线状态、正在输入、已读回执

状态：✅ 已完成（2026-11-04）

现状：

- `messages.setTyping` 只返回 `boolTrue`，不解析 action，也不推送 `updateTyping` / `updateChatUserTyping`（`crates/server/src/rpc.rs` 约 444 行）。
- `account.updateStatus` 只返回 `boolTrue`，不落库、不推送（约 587 行）。
- `crates/tl/src/lib.rs` 的 `user_impl` 固定返回 `USER_STATUS_RECENTLY(0)`（约 1042–1082 行）。
- `messages_read_history`（约 2685 行）只更新本地未读数，不向对方推送 `updateReadHistoryInbox/Outbox`。

要做：

- 用 `te_users.last_seen_at` 或新表记录在线/最后上线；维护每个用户的在线会话数。
- 实现 `updateUserStatus` 推送（至少推给有会话关系的用户）。
- 解析 typing action（typing / cancel / record voice / upload 等），向私聊对方或群/频道成员推送，并带过期时间。
- 已读回执：私聊推 `updateReadHistoryInbox` 给对方、`updateReadHistoryOutbox` 给自己的其他会话；群/频道按成员推。
- 所有 update 走 `repo::log_user_update` / `log_channel_update`，保持 PTS 一致。

验收：

- 两个客户端在线：A 输入时 B 看到“正在输入”；B 打开会话后 A 看到已读；A 离线后 B 看到最后上线时间。
- 断线重连后状态仍正确。
- 冒烟新增 presence/typing/read 断言。

已完成（2026-11-04）：

- ✅ 新增 `crates/server/src/presence.rs`：按 `(auth_key_id, session_id)` 维护在线会话；
  连接建立/断开/登出用 `PresenceGuard` 自动登记与注销，并写入 `te_users.last_seen_at`
- ✅ `user_impl` 改为接受真实 status：在线 `userStatusOnline`、离线
  `userStatusOffline(was_online)`、从未上线 `userStatusRecently`
- ✅ `account.updateStatus(offline)` 落库并推送 `updateUserStatus`（推给私聊对端）
- ✅ `messages.setTyping` 解析 typing/cancel/录音/上传等 action，按私聊/基础群/频道
  推送 `updateUserTyping` / `updateChatUserTyping` / `updateChannelUserTyping`
- ✅ 已读回执：私聊与基础群的 inbox/outbox 写 `te_update_log` 并递增对应 PTS；
  频道 `/channels.readHistory` 向本人其它会话推 `updateReadChannelOutbox`，不进入频道 PTS 流
- ✅ 冒烟新增 4 条断言（online / typing / read inbox / offline last-seen），完整冒烟通过
- 已知限制：在线会话表在进程内存中，服务重启后依赖 `last_seen_at` 展示离线状态；
  频道已读不参与频道 PTS 差分（与官方 `channels.readHistory` 返回 Bool 语义一致）

#### P0-2 联系人、拉黑、隐私

状态：✅ 已完成（2026-11-04）

- 新增迁移 `0017_p0_2_contacts.sql`：`te_contacts`、`te_blocked_users`、
  `te_privacy_settings`（rules 为 JSONB），并在用户数 ≤ 500 时把现有用户播种为联系人。
- `contacts.getContacts` 改为真实联系人；`contacts.addContact` / `contacts.deleteContacts`
  立即生效；`contacts.block` / `contacts.unblock` / `contacts.getBlocked` 可用。
- `account.setPrivacy` / `account.getPrivacy` 持久化 allow/disallow × all/contacts/users。
- 双向拉黑后 `messages.sendMessage` / `sendMedia` / 定时消息返回 `403 USER_IS_BLOCKED`，
  联系人与 `contacts.search` 均不返回拉黑对象。
- 冒烟新增 4 条 P0-2 断言，完整冒烟通过；生产库已执行迁移。
- 已知限制：隐私规则只持久化，未参与 last seen/头像/手机号可见性；未知 privacy rule
  返回 400；群/频道内不区分拉黑。

#### P0-3 草稿、会话置顶、文件夹/归档

状态：✅ 已完成（2026-11-04）

已完成：

- ✅ 迁移 `0019_p0_3_drafts_pins_folders.sql`：`te_drafts(user_id, chat_id, text, reply_to, updated_at)`、
  `te_pinned_dialogs(user_id, chat_id, sort_order, pinned_at)`、
  `te_dialog_filters(user_id, filter_id, filter(bytea), updated_at)`
- ✅ `messages.saveDraft`（空文本即清除）、`messages.getAllDrafts` 返回 `updateDraftMessage` 列表
- ✅ `messages.toggleDialogPin` / `messages.reorderPinnedDialogs`；`getPinnedDialogs` 只返回真正置顶的会话；
  `messages.getDialogs` 的 `dialog#` 带 `pinned:flags.2` 且置顶排在最前
- ✅ `messages.updateDialogFilter` / `messages.getDialogFilters` 原样保存并返回 `DialogFilter` 字节
- ✅ 冒烟新增 3 条 P0-3 断言；完整冒烟通过；生产库已执行迁移、Rust 生产服务重启并健康

已知限制：

- 草稿只保存纯文本与 `reply_to`，`entities` / `media` / `no_webpage` / `effect` 被忽略
- 草稿只能保存到已存在的会话；无消息的新私聊返回 `PEER_ID_INVALID`
- 文件夹只做存储与读取，不参与会话过滤；“全部/未读/归档”内置过滤器未实现
- 草稿/置顶/过滤器是账号本地状态，不写 `te_update_log`、不影响 PTS，也不推送到同账号其他设备

验收：

- 桌面端输入未发送内容，切走再回来草稿还在。
- 置顶会话重启后仍在顶部。
- 文件夹开关能保存并过滤会话（当前只保证保存/读取）。

#### P0-4 群/频道管理员、封禁、邀请链接、加入请求

状态：✅ 已完成（2026-11-04；加入请求审批 2026-11-05 补齐，见 P4-19）

已完成（2026-11-04）：

- ✅ 迁移 `0018_p0_4_admins_invites_usernames.sql`：`te_chat_members.role` 支持 `admin`，
  新增 `admin_rights jsonb` / `rank` / `promoted_by`；新增 `te_chat_bans`、`te_chat_invites`；
  `te_users` / `te_chats` 增加大小写不敏感唯一用户名索引
- ✅ `channels.editAdmin` / `channels.editBanned`：群主或对应权限管理员可操作；
  封禁 `view_messages` 时同时踢出，`send_messages` 拦截发送与定时消息（`403 USER_BANNED_IN_CHANNEL`）
- ✅ `messages.exportChatInvite` / `checkChatInvite` / `importChatInvite` 使用真实邀请链接表，
  支持过期时间、使用次数上限与使用计数
- ✅ 用户名：`account.checkUsername` / `updateUsername`、`channels.checkUsername` / `updateUsername`、
  `contacts.resolveUsername`；`user#` 与 `channel#` 返回真实 username
- ✅ `channels.getParticipants` 返回 `channelParticipantCreator` / `channelParticipantAdmin`；
  `channel#` 携带 `admin_rights`（创建者与管理员响应）
- ✅ 管理员/封禁变化写 `te_update_log`、递增频道 PTS，并向所有在线成员推送 `updateChannel`
- ✅ 冒烟新增 4 条 P0-4 断言，完整冒烟通过；生产库已执行迁移
- 已知限制：
  - 加入请求审批已补齐（`0031_join_requests.sql`，见 P4-19）
  - 基础群仍未支持管理员与封禁（仅超级群/频道）
  - 重新登录后的普通对话列表不按查看者回填 `admin_rights`（需后续在 `getDialogs` 补）
  - 用户名修改未推送 `updateUserName`；未实现 `editExportedChatInvite`

原现状（供参考）：

- 只有 `owner` / `member` 两种角色，没有管理员权限编辑、禁言、封禁。
- `channels.checkUsername` 恒返回 `true`（约 467 行），但没有真正用户名存储。
- `messages.exportChatInvite` 只返回随机 `https://t.me/+xxx`（约 422 行），没有邀请链接表，也没有 `checkChatInvite` / `importChatInvite`。
- 没有 `channels.editAdmin` / `editBanned` / `getAdminedPublicChannels` / 加入请求。
- 没有频道评论/讨论区（`messages.getReplies` 等）。

要做：

- `te_chat_members.role` 增加 `admin`，或新增权限 JSON（禁言、发消息、邀请、置顶、删除等）。
- 实现 `channels.editAdmin` / `editBanned` / `getParticipants` 的管理员字段。
- 邀请链接表 `te_chat_invites(token, chat_id, creator_id, expires_at, usage_limit, usage_count)`；实现导出、检查、加入。
- 加入请求表 `te_join_requests`，实现审批/拒绝（如果产品需要）。
- 用户名：`te_users.username` / `te_chats.username` 唯一索引，实现 `account.checkUsername/updateUsername`、`channels.checkUsername/updateUsername`。
- 频道评论：如果需要，先设计 `te_discussion` 或复用普通群作为关联讨论组。

验收：

- 群主可以把成员设为管理员，管理员可以禁言/踢人。
- 被封禁用户不能发消息/重新加入。
- 真实邀请链接可以发给另一个账号并成功加入。
- 用户名设置后可以通过 `t.me/username` 解析（至少服务端可查）。

#### P0-5 用户名与账号资料补全

状态：✅ 已完成（2026-11-04）

已完成：

- ✅ `te_users.username` 唯一（大小写不敏感）、`user#` 返回真实 username
- ✅ `account.checkUsername` / `account.updateUsername` / `contacts.resolveUsername`
- ✅ 迁移 `0020_p0_5_bio_birthday.sql`：`te_users.bio`、`birthday_day/month/year`
- ✅ `account.updateProfile` 的 `about`（flags.2）写入 `te_users.bio`；`users.getFullUser` 返回 `userFull.about`
- ✅ `account.updateBirthday`（`cc6e0c11`，含清除）写入生日；`users.getFullUser` 以 `flags2.5` 返回 `Birthday`
- ✅ 用户名保留字最小集合（`telegram`/`admin`/`support` 等）在 `validate_username` 中

已知限制：

- 保留字仅最小集合，未覆盖官方全部保留字、拍卖/碎片（Fragment）规则
- `userFull` 只填 `about` 与 `birthday`，其余可选字段（`personal_photo`、`business_*`、`stargifts_count` 等）未实现
- 生日仅校验 1..=31 / 1..=12 / 年份非负，未严格校验闰年与 150 岁上限

验收：

- 桌面端“编辑个人资料”能保存简介，重启后仍在。
- 能设置/清除生日，客户端个人页显示。
- 用户名保留字返回 `USERNAME_PURCHASE_AVAILABLE`。

### P1：更多消息类型与媒体

#### P1-1 语音 / 音频消息

状态：✅ 已完成（2026-11-04）

已完成：

- ✅ `documentAttributeAudio` 解析出 `voice`(flags.10)、`duration`、`title`(flags.0)、
  `performer`(flags.1)、`waveform`(flags.2)，不再是 `UNSUPPORTED_DOCUMENT_ATTRIBUTE`
- ✅ 迁移 `0021_p1_1_audio.sql`：`te_media_files.audio_voice` / `audio_title` /
  `audio_performer` / `audio_waveform`
- ✅ `document#` 在音频媒体上回写 `documentAttributeAudio`，客户端可显示语音条/音乐播放器
- ✅ `messages.sendMedia` 上传音频/语音时保留属性；下载仍走 `upload.getFile`
- ✅ 冒烟新增 `P1-1 voice: documentAttributeAudio round-trip OK`

已知限制：

- 波形按客户端上传原样存储，不生成；未上传波形时客户端显示默认样式
- 不做转码，`mime_type` 以客户端声明为准
- 音频封面 `documentAttributeAudio.thumbnail` 未实现

验收：

- 桌面端发送语音消息，另一端能播放并显示时长/波形。
- 音频文件显示音乐图标、标题、艺术家。

#### P1-2 相册 / 多图消息（grouped_id）

状态：✅ 已完成（2026-11-04）

已完成：

- 迁移 `0022_p1_2_grouped_id.sql`：`te_messages.grouped_id bigint NOT NULL DEFAULT 0`，
  加 `(chat_id, grouped_id)` 部分索引
- `repo.rs` 全部消息 SELECT/RETURNING/INSERT 与 `message_from_row` 支持 `grouped_id`
- `message#` 输出 `grouped_id:flags.17`（`edit_date` 之后、`reactions` 之前）
- 新增 `messages.sendMultiMedia#1bf89d74`：解析 `Vector<InputSingleMedia>`（1-10 条），
  同一批次共享一个非零 `grouped_id`，支持 reply_to / schedule_date / send_as /
  quick_reply_shortcut / effect / allow_paid_stars 的读取
- 冒烟 `P1-2 album: two messages share grouped_id OK`：getHistory 中两条消息 group id 一致

已知限制：

- caption 不合并，逐条保存
- 不校验相册语义约束（同一 peer、连续媒体）
- 定时相册逐条写入同一 `grouped_id`

#### P1-3 贴纸发送、自定义 emoji 发送

状态：✅ 已完成（2026-11-05；用户自建贴纸包另属独立阶段）

已完成：

- 迁移 `0023_p1_3_stickers.sql`：`te_media_files` 增加 `sticker`、`sticker_alt`、
  `sticker_set_id`、`sticker_set_access_hash`、`custom_emoji`、`custom_emoji_alt`
- `read_document_attribute` 解析 `documentAttributeSticker`（含 mask_coords）和
  `documentAttributeCustomEmoji`（`InputStickerSetID/ShortName/Empty`）
- 上传文档时写入贴纸列；`media_bytes` 对贴纸/自定义 emoji 文档输出对应 attribute，
  不再输出 filename/image_size
- 内置 StatusPack 播种时写入 `custom_emoji` 等列（Prod 已有 11 条）
- 冒烟 `P1-3 sticker: documentAttributeSticker round-trip OK` 通过

已完成（2026-11-05）：

- 消息实体（`MessageEntity`）原样保存到 `te_messages.entities`，`message#` 以
  `entities:flags.7` 回传；覆盖 `sendMessage` / `sendMedia` / `sendMultiMedia` /
  `editMessage`，转发保留实体，编辑不带 entities 时清空
- `messageEntityCustomEmoji` 也随之保存/回传；`messages.getCustomEmojiDocuments`
  已实现（按 document id 返回内置贴纸文档）
- 冒烟 `P1-3 message entities: send/echo/edit-clear OK` 通过

未完成：

- 草稿（`messages.saveDraft`）仍不保存 entities
- 用户自建贴纸包（`stickers.createStickerSet` 等）仍整体未实现，属独立阶段

#### P1-4 投票、位置、联系人名片、骰子

状态：✅ 已完成（2026-11-04）

已完成：

- ✅ 迁移 `0024_p1_4_polls_geo_contact_dice.sql`：`te_media_files.kind` 增加
  `poll`/`geo`/`contact`/`dice`，新增 `media_payload jsonb` 保存无文件媒体的内联数据；
  新增 `te_poll_votes(media_id, user_id, option, voted_at)` 与 `te_poll_votes_media_idx`
- ✅ `repo.rs`：`MediaRecord` 增加 `payload`；新增 `create_special_media`、
  `replace_poll_vote`、`poll_option_counts`、`poll_voter_total`、`poll_user_options`
- ✅ `tl`：新增 `inputMediaPoll/GeoPoint/Contact/Dice`、`poll`、`pollAnswer`、`pollResults`、
  `pollAnswerVoters`、`messageMediaPoll/Geo/Contact/Dice`、`geoPoint`、`updateMessagePoll`、
  `messages.sendVote`、`messages.getPollResults` 构造器常量与 writer
- ✅ `rpc.rs`：`read_input_media` 解析四种 input media；`materialize_input_media` 校验并落库；
  `media_bytes` 输出四种 message media（投票按查看者计算 chosen / total_voters）
- ✅ `messages.sendVote`（校验选项/单多选/关闭，写 `te_poll_votes`，向私聊双方或群成员
  推送逐用户 `updateMessagePoll`）与 `messages.getPollResults` 可用
- ✅ 冒烟新增两条断言，完整冒烟通过；生产库已执行迁移，生产 Rust 已重启并健康

已知限制：

- 未实现 `messages.getPollVotes`（投票人列表）、投票消息编辑、quiz 答案解析展示；
  投票关闭时间只存储，没有到期 worker 自动关闭
- 位置只支持静态 `geoPoint`，未实现实时位置；联系人名片不写入联系人，
  只按手机号精确/加号匹配解析 `user_id`
- 频道 poll 的投票推送不进入频道 PTS 差分

#### P1-5 链接预览、浏览量、频道统计

状态：🟡（浏览量 ✅ 2026-11-04；链接预览与频道统计未做）

已完成（2026-11-04）：

- 迁移 `0025_p1_5_message_views.sql`：`te_messages.views bigint NOT NULL DEFAULT 0`
  （必须 bigint：`MessageRecord.views` 为 i64，integer 会导致解码失败）
- `repo::increment_message_views` / `repo::message_views`；消息记录统一带 `views`
- `message#` 在 views>0 时输出 `views`+`forwards`（flags.10）
- `messages.getMessagesViews` 由空实现改为真实递增 + 回读，返回
  `messages.messageViews#b6c4f543`；冒烟断言
  `P1-5 views: getMessagesViews increments channel post views OK` 通过
- 验证：clippy `-D warnings` 通过、`cargo test --workspace` 全绿；
  测试库冒烟全绿；生产库 `yun.public` 已执行 `0025`，生产 Rust 重启后 `/healthz` ok

仍要做：

- 链接预览 `messages.getWebPage` 目前仍返回空。实现需要 HTTP 抓取 title/description/image，
  缓存到表；注意 SSRF（只允许 http/https、内网地址拒绝）与超时。
- 频道统计 `stats.getBroadcastStats` / `stats.getMegagroupStats`（含 `statsGraph`、
  `statsAbsValueAndPrev`、`statsPercentValue`、`statsDateRangeDays`）作为独立阶段。
- 浏览量只在显式 `getMessagesViews(increment=true)` 时递增，`getHistory` 不计数；
  未实现 forwards 统计（恒为 0）。

#### P1-6 翻译、语音转写、AI 写作

状态：❌ / 🟡

现状：

- 没有翻译/转写接口。
- `aicompose.getTones` 只返回静态 tones，没有真正生成。

要做：需要外部服务/模型；先做接口契约和降级（返回 `TEXT_NOT_MODIFIED` 或明确错误），不要伪造成功。

### P2：账号与安全

#### P2-1 QR 登录

状态：✅ 2026-11-04

实现：

- 迁移 `0026_p2_1_qr_login.sql`：`te_login_tokens`（token bytea 主键、
  exporter_auth_key_id、api_id、created_at/expires_at、confirmed_user_id、used）
- `repo::create_login_token` / `confirm_login_token` / `take_confirmed_login_token`
  （最后一次确认原子消费，并清掉过期行）
- `auth.exportLoginToken`：先检查本 auth_key 是否已有被确认的 token，
  有则绑定 session 并返回 `auth.loginTokenSuccess#390d5c5e`；
  否则生成 32 字节 token、有效期 120 秒，返回 `auth.loginToken#629f1980`
- `auth.importLoginToken`：已登录的会话确认 token（未知/过期/已用 → `LOGIN_TOKEN_INVALID`）
- 冒烟断言 `P2-1 QR login: export/confirm/authorize round-trip OK` 通过
  （新设备导出 → 已登录端确认 → 新设备再导出拿到授权的 user，且错误 token 被拒）
- 生产库已执行 `0026`，生产重启后 `/healthz` ok

技术注意：桌面端 schema 里 `auth.loginToken#629f1980 expires:int token:bytes`
没有 flags；`loginTokenSuccess` 构造器是 `390d5c5e`（不是新版 17d32fca）。

限制：`except_ids` 未参与判断；token 未带 DC id（单 DC 部署可接受）。

#### P2-2 两步验证（2FA）

状态：✅ 2026-11-05

实现：

- 迁移 `0032_two_step_verification.sql`：`te_users` 增加 `password_srp_id`、
  `password_salt1`、`password_salt2`、`password_verifier`、`password_hint`、
  `password_g`、`password_updated_at`；`password_verifier IS NULL` 表示未启用
- `crates/server/src/srp.rs`：Telegram SRP-6a（SHA-256 + 2048 位安全素数、
  `g=3`），`start` 生成随机 2048 位 `b` 与 `g_b`，`check` 用保存的 verifier
  验证客户端 `A`/`M1`；服务器不派生密码哈希（客户端提交 `v=g^x mod p`）
- 固定盐与 Telegram 一致：`salt1 = ALGO_SALT1 + 32 字节随机数`，`salt2 = ALGO_SALT2`；
  `new_secure_algo` 返回 `securePasswordKdfAlgoPBKDF2HMACSHA512iter100000`
- RPC：`account.getPassword` 返回完整 `account.password`（`has_password`、
  `current_algo`、`srp_B`、`srp_id`、`hint`、`new_algo`、`new_secure_algo`、
  `secure_random`）；`auth.signIn` 命中启用了 2FA 的账号时返回
  `401 SESSION_PASSWORD_NEEDED` 并按 auth_key 挂起登录；`auth.checkPassword` 校验
  成功后正式建会话；`account.updatePasswordSettings` 支持设置/修改/清除密码；
  `account.getPasswordSettings` 返回空设置
- 错误码：`PASSWORD_HASH_INVALID`、`SRP_ID_INVALID`、`NEW_SALT_INVALID`、
  `NEW_SETTINGS_EMPTY`
- 验证：`cargo test -p tsrv-server srp`（5 个用例：正确密码通过、错误密码拒绝、
  srp_id 失效、算法参数校验、verifier 边界）；`clippy -D warnings` 通过；
  迁移写入 `yun.public` 与 `telegram_server.test`；生产 `/healthz` 正常

限制：SRP 的 `b`/`B` 与待登录用户只保存在内存（10/30 分钟），服务器重启后需重新
登录；未实现恢复邮箱、Passkey、邮箱验证码与 `account.resetPassword`。

#### P2-3 活跃设备 / 会话管理

状态：✅ 2026-11-04

实现：

- 迁移 `0027_p2_3_session_metadata.sql`：`te_sessions` 增加 `api_id`、`app_name`、`lang_code`
- `repo::save_session` 接受 `SessionDevice`（device_model/platform/system_version/
  app_version/api_id/app_name/lang_code），登录（含 QR）时写入
- `account.getAuthorizations#e320c158` → `account.authorizations#4bff8ea0`，
  每项 `authorization#ad01d61d`（current = 当前 auth_key）
- `account.resetAuthorization#df77f3bc`：删除 `te_auth_keys`（会话级联删除），
  只允许撤销自己的会话；撤销当前会话时清空 ctx 用户
- `auth.resetAuthorizations`：删除除当前外的全部 auth key
- **立即生效**：`repo::touch_session` 改为 `UPDATE ... RETURNING user_id`，
  监听器不再使用握手套接里的 `key.user_id`，被撤销的会话下一个请求就 401
- 冒烟断言 `P2-3 active devices: list/reset session OK` 通过

限制：删除 auth key 不会主动关闭 socket，靠下一次鉴权失败；`country`/`region` 留空。

#### P2-4 邮箱/Passkey/SMS 登录

状态：❌

现状：固定验证码 `12345`，没有短信/邮件/Passkey。

要做：这是产品/运维功能，需要外部服务；先设计验证码发送抽象层和 rate limit。

#### P2-5 Bot API / bots / inline keyboard

状态：❌

现状：

- 没有 bot 账号、Bot API、inline query、callback。
- `reply_markup` 直接 `REPLY_MARKUP_UNSUPPORTED`（约 1884 行）。

要做：工作量大，建议单独立项。先做 `te_bots` 和最小 `messages.sendMessage` 的 inline keyboard 渲染，不要一次做完整 Bot API。

#### P2-6 Secret chat / 音视频通话 / 直播

状态：❌

现状：没有 `messages.requestEncryption`、通话信令、TURN/SFU。

要做：安全模型和基础设施都重，建议放到最后或明确不做。

### P3：Premium 后续

- Stories：当前 `stories.*` 全部返回空；需要 stories 表、上传/查看/过期、隐私。
- 礼物 / Stars / 支付：当前 `payments.*` 返回空；需要真实账本、支付渠道、合规。
- 收藏 emoji 状态：`account.getCollectibleEmojiStatuses` 返回空。
- 语音转写：需要 STT 服务。
- Premium 订阅本身：目前所有用户固定带 Premium 标记，没有真实订阅/到期。

### P4：正确性、运维、稳定性

#### P4-1 `channelDifferenceTooLong` 完整快照

状态：✅ 2026-11-04

已完成：

- `repo::channel_oldest_update_pts`：按 channel 取 `min(pts)`（`bigint`，用 i64 解码）。
- `updates.getChannelDifference`：当请求 `pts + 1 < oldest` 时返回
  `updates.channelDifferenceTooLong#a4bcc6fe`，携带 `dialog#fc89f7f3`（peer = `peerChannel`、top_message = 当前 pts）、
  最新 `limit` 条消息（倒序转正序）、频道 `chats` 与空 `users`，`final` 置位。
  其余情况仍返回 `channelDifference` / `channelDifferenceEmpty`。
- TL 新增 writer `types::updates_channel_difference_too_long`；冒烟新增
  `parse_channel_difference_too_long`（读 flags → dialog 全部字段 → messages/chats/users 向量）。
- 冒烟断言 `P4-1 channelDifferenceTooLong: snapshot with 5 messages OK`
  （用 `pts = -1` 触发快照）。
- 验证（2026-11-04）：clippy/`cargo test --workspace` 通过，测试库完整冒烟通过；生产重启后 `/healthz` ok（本项无新迁移）。
- 限制：`updates.getDifference` 的 `differenceTooLong` 仍无完整快照；快照消息数受 `limit` 限制（默认 100）。

#### P4-2 缺失 RPC 与客户端日志驱动补齐

状态：✅ 2026-11-04（核心项完成，后续按日志继续补）

已完成：

- 迁移 `0028_p4_2_reactions_notify.sql`：`te_reaction_notify_settings`
  （user_id 主键、settings jsonb、updated_at）。
- `account.getReactionsNotifySettings#06dd654c`：无记录时返回默认值
  （sound = `notificationSoundDefault#97e8bebe`、show_previews = true）；
  `account.setReactionsNotifySettings#316ce548`：解析
  `reactionsNotifySettings#71e4ea58`（三个 `ReactionNotificationsFrom` 可选字段、
  `NotificationSound` 四种变体、`show_previews`），写入 jsonb 并回显。
- `repo::reaction_notify_settings` / `save_reaction_notify_settings`。
- 未知 RPC 增加限流日志：每个构造器每进程只 warn 一次
  （`unsupported RPC method`，仍返回 `METHOD_NOT_FOUND_0x...`）。
- 冒烟断言 `P4-2 reactionsNotifySettings: get/set persisted OK`。
- 验证（2026-11-04）：clippy/`cargo test --workspace` 通过，测试库完整冒烟通过；
  生产库已执行 `0028`，生产重启后 `/healthz` ok。
- 限制：其余 `METHOD_NOT_FOUND`（如 `contacts.getBirthdays` 等）仍需按客户端日志逐项补。

#### P4-3 视频缩略图与时长回填

状态：🟠

现状：

- 新上传视频会走 ffmpeg 抽帧；但老视频（如 media id 14）没有 `thumb_storage_key` / `te_media_thumbs`，后台只显示 🎬 占位。
- 部分视频 `duration` 为 0，客户端可能不显示时长。

要做：加一个 Rust 维护/管理接口，扫描缺失缩略图的视频，用 ffmpeg 回填 `te_media_thumbs` 和 `thumb_storage_key`，同时修正 duration。写操作放在 Rust，不要 Python 直接写表。

#### P4-4 Android / 真机稳定性

状态：🟠

现状：主要用 LDPlayer14 验证，30 分钟双端稳定性复验未完成；模拟器有 binder 限制。

要做：条件允许时用真机跑 30 分钟双端收发、切后台、重连、媒体上传下载。

#### P4-5 生产化

状态：❌

- 单 DC、单机本地文件；没有 S3/对象存储、集群、水平扩展。
- 没有 Prometheus/结构化指标、审计日志、告警。
- 没有登录/管理接口 rate limit（固定验证码本身不适合公网）。
- 没有自动备份/恢复演练。
- 没有 TLS/反向代理标准部署文档。

#### P4-6 管理后台用户/会话/成员管理

状态：✅ 2026-11-04

已完成：

- 迁移 `0029_admin_user_management.sql`：`te_users.banned_at timestamptz NULL`。
- Rust admin（Bearer 鉴权，写操作复用 RPC 内部逻辑，保证 `te_update_log`、PTS 与
  UpdateHub 一致）：
  - `POST /admin/telegram/update-user`：名字/姓氏/用户名（空用户名清除、重名校验）；
  - `POST /admin/telegram/ban-user`：封禁/解封，封禁同时删除全部 auth key，
    `authorize` 对封禁账号返回 401 `USER_DEACTIVATED_BANNED`；
  - `POST /admin/telegram/kick-session` / `kick-all-sessions`；
  - `POST /admin/telegram/add-member` / `remove-member`：基础群与超级群/频道，
    基础群复用 `add_basic_group_member`（服务消息 + participants 更新），
    频道走 `publish_channel_update`（PTS + `te_update_log` + UpdateHub）；
  - `POST /admin/telegram/promote-member`：`rights_flags > 0` 设管理员，`0` 取消。
- `repo::user_banned` / `set_user_banned`。
- yun 后台：`telegram_user_sessions`、`telegram_chat_members` 只读接口 + 上述写接口代理；
  `telegram_users` 增加 `banned`；UI 增加「编辑/设备/封禁」与「成员」面板
  （加人、移出、设/取消管理员、单设备/全部踢下线），`app.js` 版本 `20261104r`。
- 验证（2026-11-04）：clippy、`cargo test --workspace`、完整冒烟通过；测试库 HTTP
  验证全部接口，`te_chats.pts` 与 `te_update_log` 同步增长；生产库执行 `0029` 后重启，
  `/healthz` ok；yun 路由注册（401 而非 404）与只读 SQL、`app.js` 语法检查通过。

限制：删除用户已于 P4-19 补齐（默认 dry_run 预览，拥有群/频道时拒绝）；
管理员权限位沿用 Telegram flags（UI 默认 127）。

#### P4-7 管理后台账号详情与消息批量删除

状态：✅ 2026-11-05

已完成：

- Rust：`POST /admin/telegram/delete-messages` `{chat_id, message_ids[]}`，覆盖私聊/基础群/
  超级群/频道；复用 `delete_messages_in_chat`，PTS、`te_update_log`、UpdateHub 与客户端删除
  一致；单会话上限 100 条，空列表 400，全部不存在 404；`admin_delete_message` 委托批量实现。
- yun：`GET /telegram_user_detail`（资料、统计、设备、最近会话、最近发送）；
  `POST /telegram_delete_messages`（按 chat_id 分组调用 Rust，返回删除总数）。
- 后台 UI：账号行「详情」弹窗（编辑资料、发消息、封禁、单设备/全部踢下线）；
  消息页勾选列 + 全选本页 + 批量删除条；`app.js` 版本 `20261105a`。
- 验证：clippy/测试/完整冒烟通过；测试库批量删除 2 条（14→12）与 400/404 边界；
  生产 `/healthz` ok、新路由可达；yun TestClient 验证详情与删除分组代理，
  线上新路由 401、静态资源版本正确。

限制：批量删除为物理删除，不支持撤回；跨会话批量由 yun 分组后多次调用 Rust。

#### P4-8 管理后台操作审计

状态：✅ 2026-11-05

已完成：

- 迁移 `0030_admin_audit.sql`：`te_admin_audit`（`actor` / `action` /
  `target_user_id` / `target_chat_id` / `target_message_id` / `params jsonb` /
  `success` / `error` / `created_at`），按用户、会话、时间建索引。
- Rust：`health.rs` 的 `with_audit` 统一包裹所有 `/admin/telegram/*` 写接口与
  `/admin/system-message`；成功与失败都记录，审计写入失败只 `tracing::warn`，
  不影响主操作；操作者取自请求头 `X-Admin-Actor`（默认 `admin`，最多 64 字符）。
- yun：`_admin_call` 增加 `actor` 参数并透传 `X-Admin-Actor`（se 管理员账号）；
  `GET /telegram_user_detail` 增加 `audit`（最近 20 条，含中文动作标签与参数摘要）。
- 后台 UI：账号详情新增「操作审计」区块（成功/失败徽标、动作、摘要、操作者、时间），
  `app.js` 版本 `20261105b`。
- 验证（2026-11-05）：clippy、`cargo test --workspace` 通过；生产库与测试库均执行
  `0030`；生产对不存在会话调用删除返回 404 且审计写入失败记录；经 yun 代理调用
  返回 400，审计 actor 为真实 se 账号；账号详情接口返回审计记录；`/healthz` ok。

限制：审计只覆盖 Rust admin 写接口，Python 只读查询不记录；暂无审计导出、筛选页和
自动清理策略；审计表会持续增长，后续可放入维护 worker 的保留期清理。

#### P4-9 管理后台 Telegram 概览

状态：✅ 2026-11-05

已完成：

- yun 新增只读接口 `GET /api/admin/telegram_overview`，一次查询汇总账号、会话、消息、
  媒体、设备与其他计数：账号总数/封禁/今日新增/7 日活跃；会话按私聊、基础群、超级群、
  频道拆分；消息总数/今日/近 7 日/定时待发/含媒体；媒体数量与体积按图片/视频/文件拆分；
  设备总数与 15 分钟内活跃数、登录用户数、反应/审计/更新日志计数。
- 后台 UI「聊天」分组新增「概览」页签，使用仪表盘卡片布局按「账号与设备 / 会话 / 消息 /
  媒体 / 其它」分区展示；进入页面每 30 秒自动刷新，离开即停止；`app.js` 版本 `20261105c`。
- 验证（2026-11-05）：`node --check` 与 `py_compile` 通过；重启 yun 后接口返回 200，
  生产数据示例：账号 7（封禁 0、7 日活跃 7）、会话 38（私聊 6/基础群 5/超级群 13/频道 14）、
  消息 224（含媒体 35）、媒体 49 个共约 45.5 MB、设备 49 台；`/apps/admin/` 与
  `app.js?v=20261105c` 均返回 200 且包含新页签与加载方法。

限制：全部为数据库计数，不含磁盘实际占用与真实在线连接数（分别留待存储页与 Rust
在线连接统计）；「今日」按服务器自然日 `date_trunc('day', now())` 计算。

#### P4-10 超级群 / 频道详情与设置

状态：✅ 2026-11-05

已完成：

- Rust admin 新增三个写接口，均写入 `te_update_log`、递增频道 PTS 并推送 `updateChannel`：
  - `POST /admin/telegram/ban-chat-user`：封禁/解封；封禁默认 `flags=1` 同时移出成员，
    支持 `until_date`；群主作为操作者，禁止操作群主与基础群；
  - `POST /admin/telegram/create-invite`：生成 `https://t.me/+token` 邀请链接，
    支持人数上限与过期时间，写 `te_chat_invites`；
  - `POST /admin/telegram/revoke-invite`：校验链接归属后置 `revoked=true`。
- yun 新增 `GET /api/admin/telegram_chat_detail`：资料、创建者、成员/管理员/封禁/邀请/
  消息统计，管理员与封禁列表（含用户资料），邀请链接列表（使用次数、过期、撤销状态）。
- 新增 POST 代理：`telegram_chat_ban` / `telegram_chat_invite_create` /
  `telegram_chat_invite_revoke`，审计动作 `ban_chat_user` / `create_invite` / `revoke_invite`。
- 后台「会话」页超级群/频道行新增「详情」弹窗：管理员设/取消、封禁（天数 0=永久）与解封、
  邀请链接创建（自动复制）/复制/撤销；`app.js` 版本 `20261105d`。
- 验证（2026-11-05）：`cargo check`/`cargo build`、`node --check`、`py_compile` 通过；
  Rust 重启后 healthz 200；接口验证：会话 37（group）与 38（channel）详情均返回 200，
  管理员 1 人；创建邀请 → DB `revoked=false`，撤销后 `revoked=true`；封禁用户 2 →
  `te_chat_bans` 出现且成员列表只剩群主，解封后封禁记录清空，重新加回成员恢复原状；
  审计记录出现 `ban_chat_user`、`create_invite`、`revoke_invite`；页面与
  `app.js?v=20261105d` 返回 200 且包含详情弹窗方法。

限制：管理员权限位仍为裸 flags 输入；邀请链接固定 `request_needed=false`；详情页不展示
成员全量列表（复用「成员」面板）。

#### P4-11 存储统计与清理

状态：✅ 2026-11-05

已完成：

- 新增 `storage.rs`：递归扫描 `data/media`，按顶层目录（files/thumbs/stickers/uploads 等）
  统计文件数与体积；汇总 `te_media_files`（含缩略图体积）、`te_media_thumbs`、
  `te_upload_parts` 记录；对比数据库引用键，识别孤儿文件与缺失文件。
- Rust admin 新增 `POST /admin/telegram/storage-stats`（只读扫描，文件遍历放在
  `spawn_blocking`）与 `POST /admin/telegram/storage-cleanup`（仅删除未被引用且超过
  `min_age_secs`（默认 1 小时）的文件，避免误删上传中的临时文件），清理写审计
  `storage_cleanup`。
- yun 新增 `POST /api/admin/telegram_storage_stats` / `telegram_storage_cleanup` 代理。
- 后台「聊天」分组新增「存储」页：磁盘占用/目录分布/DB 统计/孤儿/缺失文件列表，
  支持重新扫描与按时长清理；`app.js` 版本 `20261105e`。
- 验证（2026-11-05）：`cargo check`/`build`、`node --check`、`py_compile` 通过；
  扫描结果 76 个文件共约 46.5 MB，DB 媒体 49 条；手工创建 2 小时前的
  `orphan-test/old.bin`（1 MB）后统计到孤儿 1 个，清理接口删除 1 个/1048576 字节，
  文件确认不存在，再次扫描孤儿归零；审计出现 `storage_cleanup` 成功记录。

限制：只清理文件，不删除空目录；缺失文件只报告不自动修复；大目录扫描为全量遍历，
生产可改为缓存或定时任务。

#### P4-12 批量群发

状态：✅ 2026-11-05

已完成：

- Rust admin 新增 `POST /admin/telegram/broadcast`（yun 侧 `telegram_broadcast`）：
  由系统助手向最多 200 个账号发送同一段文本；服务端去重、预检账号存在性，
  逐个返回 `{sent, skipped, failed:[{user_id,error}]}`，单账号失败不影响整批；
  写审计 `broadcast_message`（含文本预览、长度与目标列表）。
- yun 接口兼容数组与逗号/空白分隔的 ID 字符串，自动去重并校验 4096 字上限。
- 后台「聊天」分组新增「群发」页：接收账号 ID、消息内容、字符计数、发送结果与失败列表。
- 验证（2026-11-05）：向 `3,4,4,999` 发送测试文本，返回 `sent=2, total=3`、999 为
  `USER_INVALID`；`te_messages` 生成 2 条系统消息，随后通过批量删除接口清理为 0；
  审计出现 `broadcast_message` 成功记录；页面与 `app.js?v=20261105f` 正常加载。

限制：仅文本、发送方固定为系统助手、单批 200 个账号；不做定时群发与发送进度持久化。

#### P4-13 独立操作审计页

状态：✅ 2026-11-05

已完成：

- yun 新增 `GET /api/admin/telegram_audit`：支持操作者、动作、结果、目标账号/会话、
  关键词、起止日期与分页；返回 `action_label` / `target_label` / `detail` /
  `success_label`，并附带全表动作去重计数 `actions`。
- yun 新增 `GET /api/admin/telegram_audit_export`：按当前筛选导出 CSV（UTF-8 BOM，
  最多 5000 条），文件名带时间戳。
- 后台「聊天」分组新增「审计」页，独立筛选条（操作者/动作/结果/日期区间/关键词/
  查询/重置/导出），结果列显示成功/失败徽章；审计页不显示编辑/删除按钮。
- 验证（2026-11-05）：`py_compile`、`node --check` 通过；重启 yun 后接口 200，
  当前 13 条记录；`actor=wuzhen` 11 条、成功 10/失败 3、`keyword=broadcast` 2 条、
  今日 13 条、非法日期被忽略、不存在的目标账号 0 条；导出 CSV 含 BOM 与正确表头/数据行。

限制：CSV 单次最多 5000 条；动作下拉计数为全表统计，不随筛选变化；日期按服务器本地时区。

#### P4-14 运营账号与权限页

状态：✅ 2026-11-05

已完成：

- yun 新增 `GET /api/admin/telegram_operators`：基于 `users` 表返回账号/昵称/邮箱/角色/
  状态/注册时间，并按 `actor = account` 汇总 `te_admin_audit` 的操作总数、失败数和最近
  操作时间；支持角色、状态、关键词筛选与分页。
- yun 新增 `POST /api/admin/telegram_operator_update`：修改角色（se / admin / 普通用户）
  与启用状态；禁止把自己降级或禁用；启用/禁用都会清空 `users.token`。
- 后台「聊天」分组新增「运营账号」页：独立筛选条、行内启用/禁用、角色下拉 + 保存角色、
  新建账号（复用 `POST /api/admin/users`，邮箱必填且唯一）。
- 验证（2026-11-05）：`py_compile`、`node --check` 通过；现有 20 个账号（普通用户 19、
  se 1）；临时账号创建→改角色→禁用→删除全链路通过；自降级/非法角色/非法状态均返回 400；
  当前管理员 token 未受影响。

限制：`users.email` 有唯一约束；角色权限只区分 `se`（后台全权）与其他角色（无后台管理
权限）；角色/状态变更不写 `te_admin_audit`（该表只记录 Rust admin 写操作）。

#### P4-15 会话改标题/头像

状态：✅ 2026-11-05

已完成：

- Rust `admin_update_chat` + `POST /admin/telegram/update-chat`，复用 `messages.editChatTitle`
  服务消息与 `apply_chat_photo`，PTS/`te_update_log`/在线推送与客户端一致。
- yun `POST /api/admin/telegram_chat_update`，详情接口新增 `photo_media_id`。
- 后台会话详情新增「会话设置」，基础群也可打开详情。
- 验证：临时基础群改标题并清空头像成功；私聊/不存在会话被拒绝。

#### P4-16 消息编辑

状态：✅ 2026-11-05

已完成：

- `messages_edit_message` 的核心逻辑抽成 `apply_message_edit`，客户端与 `admin_edit_message` 共用。
- 新增 `POST /admin/telegram/edit-message` 与 yun `telegram_edit_message`；后台消息行新增「编辑」。
- 验证：私聊消息编辑后库内文本更新；服务消息与不存在消息被拒绝。

#### P4-17 消息置顶/取消置顶

状态：✅ 2026-11-05

已完成：

- `messages.updatePinnedMessage` 的三套逻辑抽成 `apply_pinned_message`。
- 新增 `POST /admin/telegram/pin-message`（`message_id=0` 取消）与 yun `telegram_pin_message`。
- 消息列表返回 `pinned`，行内新增置顶/取消置顶按钮。
- 验证：置顶/取消后 `te_chats.pinned_msg_id` 正确变化。

#### P4-18 新建/删除会话

状态：✅ 2026-11-05

已完成：

- Rust `admin_create_chat` 支持基础群/超级群/频道；`admin_delete_chat` 先分批删除消息推送，
  再硬删除会话，依赖外键级联清理成员/对话框/邀请/封禁。
- yun `telegram_chat_create` / `telegram_chat_delete`；后台新增新建会话弹窗与行内删除。
- 验证：基础群创建→改名→置顶→删除、频道创建→删除全链路通过。

限制：删除为服务端级联硬删除，在线端先收到消息删除更新；不额外推送「会话删除」更新
（MTProto 无对应构造函数），会话列表残余项在下次拉取时消失。

#### P4-19 删除用户 / 加入请求审批

状态：✅ 2026-11-05

**删除用户**

- Rust `admin_delete_user(user_id, dry_run)`：`dry_run` 只统计 `owned_chats` / `private_chats` /
  消息数 / 媒体数；系统助手账号拒绝删除；仍拥有非私聊会话时返回 `USER_OWNS_CHATS`。
- 真正执行时：先按私聊删除消息（复用 `delete_messages_in_chat`，写 update_log 并推送），
  删除私聊会话，再删除该用户在其他会话中发送的消息并清理指向它们的置顶，
  最后把其媒体 `owner_user_id` 置空并删除账号，其余依赖外键级联。
- `POST /admin/telegram/delete-user`（`dry_run` 默认 `true`）；yun
  `POST /api/admin/telegram_user_delete`；后台账号行新增「删除」按钮，先预览影响再二次确认。
- 验证：测试 schema 播种用户/私聊/消息/媒体 → dry_run 统计 → 执行后用户、会话、消息全删，
  媒体归属置空，审计记录写入。

**加入请求审批**

- 迁移 `migrations/0031_join_requests.sql`：`te_join_requests`（`chat_id + user_id` 唯一，
  `status` pending/approved/rejected，记录 `about`、`requested_at`、`reviewed_at`、`reviewer`）。
- 邀请链接支持 `request_needed`：导出 RPC 解析 flags bit3 并写入 `te_chat_invites`，
  `checkChatInvite` 返回 `chatInvite.request_needed`；`importChatInvite` 命中 request_needed 时
  只创建/重置 pending 请求，不加入、不消耗次数，返回空 updates。
- `POST /admin/telegram/review-join-request`：通过时补成员、会话对话框并推送频道更新，
  拒绝只改状态；仅 pending 可处理，重复审批返回 `JOIN_REQUEST_HANDLED`。
- yun `GET /api/admin/telegram_join_requests`（只读，按会话/状态筛选）、
  `POST /api/admin/telegram_join_request_review`；会话详情返回 `pending_join_requests`，
  邀请创建区新增「需要管理员审批」勾选，详情内可直接通过/拒绝。
- 验证：测试 schema 播种 pending 请求 → 通过后成员/对话框/update_log 写入且状态 approved，
  重复审批 400；拒绝后状态 rejected 且未加入。

---

## 4. yun 管理后台未实现

当前代码：`D:\project\yun\ai\src\serv\api\routes\telegram_admin.py`  
当前页面：`D:\project\yun\ai\public\apps\admin\index.html` / `js\app.js` / `css\style.css`

### 4.1 已有

- `GET /api/admin/telegram_users` / `telegram_chats` / `telegram_messages`
- `GET /api/admin/telegram_overview`（账号/会话/消息/媒体/设备总量统计）
- `POST /api/admin/telegram_send_message` / `telegram_delete_message` / `telegram_kick_user`
- `POST /api/admin/telegram_update_user` / `telegram_ban_user` / `telegram_kick_session` /
  `telegram_kick_all_sessions` / `telegram_add_member` / `telegram_remove_member` /
  `telegram_promote_member` / `telegram_delete_messages` / `telegram_chat_ban` /
  `telegram_chat_invite_create` / `telegram_chat_invite_revoke` / `telegram_broadcast`
- `GET /api/admin/telegram_user_sessions` / `telegram_chat_members` / `telegram_user_detail` /
  `telegram_chat_detail` / `telegram_audit` / `telegram_audit_export` / `telegram_operators`
- `POST /api/admin/telegram_operator_update`（角色/启用状态，自保护 + 清空 token）
- `POST /api/admin/telegram_chat_update` / `telegram_edit_message` / `telegram_pin_message` /
  `telegram_chat_create` / `telegram_chat_delete` / `telegram_user_delete` /
  `telegram_join_request_review`
- `GET /api/admin/telegram_join_requests`（待审批/已处理申请列表，按会话与状态筛选）
- `POST /api/admin/telegram_storage_stats` / `telegram_storage_cleanup`
- `GET /api/admin/telegram_media`（thumb/full，支持 Range）
- 消息页「只看真实媒体」、图片/视频弹窗预览
- 媒体占位（1×1 图片、<4KB 视频）文字提示
- 用户：编辑资料（名字/姓氏/用户名）、封禁/解封、设备列表与单设备/全部踢下线
- 账号详情：资料、统计（会话/消息/创建/设备）、设备、最近会话、最近发送、操作审计
- 消息：勾选 / 全选本页 / 批量删除（按会话分组，单会话 ≤100 条）
- 成员：成员列表、加人、移出、设置/取消管理员（基础群 + 超级群/频道）
- 超级群/频道详情：资料与统计、管理员列表（设/取消）、封禁列表（封禁并移出/解封）、
  邀请链接（创建/复制/撤销，支持人数上限）
- 存储：媒体目录占用与目录分布、DB 媒体/缩略图/上传分片计数、孤儿文件与缺失文件检测，
  支持按保留时长清理孤儿文件
- 群发：系统助手向最多 200 个账号批量发送文本，自动去重、逐个返回失败原因
- 审计：独立审计页支持操作者/动作/结果/目标/关键词/日期筛选、分页与 CSV 导出；
  账号详情仍展示最近 20 条
- 运营账号：users 表账号列表（角色/状态/操作统计/最近操作），行内启用/禁用、
  角色下拉修改、新建账号（邮箱唯一），禁止自降级/自禁用
- 会话：详情内改标题/头像，行内新建/删除会话（基础群/超级群/频道）
- 消息：编辑、置顶/取消置顶（服务消息不可编辑）
- 账号：行内删除（先 dry_run 预览私聊/消息/媒体影响，仍需二次确认；拥有群/频道时拒绝）
- 加入请求：邀请链接可勾选「需要管理员审批」，会话详情列出待审批申请并通过/拒绝

### 4.2 未实现

| 功能 | 建议接口 / 说明 |
|---|---|
| 删除用户 | ✅ 2026-11-05（见 P4-19）；仍拥有群/频道时需先转移或删除会话 |
| 会话改标题/头像 | ✅ 2026-11-05（见 P4-15） |
| 消息编辑/置顶 | ✅ 2026-11-05（见 P4-16 / P4-17）；发媒体/转发未做 |
| 新建/删除会话 | ✅ 2026-11-05（见 P4-18） |
| 频道公开用户名/订阅者列表 | 邀请链接与成员列表已支持；公开用户名修改复用 `channels.updateUsername` |
| 加入请求审批 | ✅ 2026-11-05（见 P4-19）；客户端 `importChatInvite` 已接 request_needed |
| 实时在线连接数 | 概览页用 `te_sessions.last_active_at` 15 分钟窗口近似；真实连接数需 Rust 暴露 |
| 媒体库/下载 | 存储页已支持磁盘占用与孤儿清理；仍缺跨会话媒体列表与批量下载 |
| 批量操作 | 批量踢人；批量删除消息已支持（单会话 ≤100 条/次） |

### 4.3 后台约束

- 查询可以直接读 `te_*`。
- **写操作必须走 Rust admin API**，由 Rust 维护 PTS、`te_update_log`、dialogs、UpdateHub 推送。
- 新增 Rust admin 接口时，复用现有 `rpc.rs` 的私有逻辑（如 `delete_messages_in_chat`、`remove_basic_group_member`），不要复制一套简化逻辑。
- 前端新增按钮放在 `telegramActions` 分支，保持 `app.js` 版本号更新。
- 媒体预览读取 `data/media`，只读，不写 DB。

---

## 5. 硬性约束（违反会破坏一致性）

1. **数据库**：所有服务端表、索引、约束、SQL 查询使用 `te_` 前缀；schema 是 `yun.public`；不要创建视图。
2. **写操作**：任何会改 `te_messages` / `te_chats` / `te_chat_members` / `te_user_dialogs` / PTS 的操作，必须走 Rust RPC 或 Rust admin API；Python 只做鉴权和代理。
3. **PTS/update_log**：新增消息/编辑/删除/已读/反应/成员变化时，必须同步写对应 `te_update_log` 并推送 UpdateHub。
4. **媒体**：Rust 媒体目录是 `data/media`；storage_key 是相对路径；不要接受 `..`、绝对路径、盘符。
5. **不要动**：
   - Go 生产 `2398` / `telesrv_main`
   - `E:\game\Telegram\users\desktop-main`（生产客户端数据）
   - 生产数据库里的真实用户数据（删除/批量修改前必须先问）
6. **测试**：优先用 `telegram_server.test`；跑 smoke 前先停生产 Rust 进程，跑完重启。
7. **密钥**：不要打印/提交 token、DB 密码、RSA 私钥。
8. **文档**：每完成一个阶段，更新 `docs/04-test-plan.md` 和 `docs/05-roadmap.md`，并勾选本文档对应条目。
9. **代码风格**：沿用现有 axum/sqlx/axum middleware、`RpcFailure`、`repo::` 分层；新增依赖前先确认必要。

---

## 6. 建议开发顺序

1. ~~**P0-1 在线/输入/已读**（体验最明显）~~ ✅ 2026-11-04
2. ~~**P0-2 联系人/拉黑/隐私**~~ ✅ 2026-11-04
3. ~~**P0-4 群/频道管理员 + 邀请链接 + 用户名**~~ ✅ 2026-11-04
4. ~~**P0-3 草稿/置顶/文件夹**~~ ✅ 2026-11-04
5. ~~**P0-5 用户名与账号资料补全**~~ ✅ 2026-11-04
6. ~~**P1-1 语音/音频**~~ ✅ 2026-11-04、~~**P1-2 相册**~~ ✅ 2026-11-04、~~**P1-3 贴纸/消息实体**~~ ✅ 2026-11-05
7. ~~**P1-4 投票/位置/联系人名片/骰子**~~ ✅ 2026-11-04
8. ~~**P1-5 浏览量**~~ ✅ 2026-11-04（剩余链接预览与频道统计）
9. ~~**P2-1 QR 登录**~~ ✅ 2026-11-04；~~**P2-3 活跃设备**~~ ✅ 2026-11-04；
   ~~**P2-2 2FA**~~ ✅ 2026-11-05
10. ~~**P4-1 channelDifferenceTooLong**~~ ✅ 2026-11-04；~~**P4-2 缺失 RPC**~~ ✅ 2026-11-04（核心项完成，日志驱动继续）
11. ~~**yun 后台用户/会话/成员管理**~~ ✅ 2026-11-04（见 P4-6；删除用户见 P4-19）
12. ~~**账号详情 + 消息批量删除 + 操作审计**~~ ✅ 2026-11-05（见 P4-7 / P4-8）
13. ~~**Telegram 概览页**~~ ✅ 2026-11-05（见 P4-9）
14. ~~**超级群/频道详情与设置**~~ ✅ 2026-11-05（见 P4-10）
15. ~~**存储统计与清理**~~ ✅ 2026-11-05（见 P4-11）
16. ~~**批量群发**~~ ✅ 2026-11-05（见 P4-12）
17. ~~**独立操作审计页**~~ ✅ 2026-11-05（见 P4-13）
18. ~~**运营账号与权限**~~ ✅ 2026-11-05（见 P4-14）
19. ~~**会话改标题/头像**~~ ✅ 2026-11-05（见 P4-15）
20. ~~**消息编辑**~~ ✅ 2026-11-05（见 P4-16）
21. ~~**消息置顶/取消置顶**~~ ✅ 2026-11-05（见 P4-17）
22. ~~**新建/删除会话**~~ ✅ 2026-11-05（见 P4-18）
23. ~~**删除用户 / 加入请求审批**~~ ✅ 2026-11-05（见 P4-19）
24. **P3 Premium、Bot API、Calls、生产化**（大阶段，单独立项）

每完成一项必须：

- `cargo check` / `clippy` / `cargo test`
- 受影响路径的 HTTP 或 MTProto 冒烟
- 更新文档
- 汇报改了哪些文件、跑了哪些命令、结果、剩余风险

---

## 7. 验收清单

### 7.1 Rust

```powershell
cd E:\game\Telegram\server\telegram_server
cargo check -p tsrv-server
cargo clippy --workspace --all-targets -- -D warnings
cargo test --workspace
```

### 7.2 冒烟

```powershell
# 先停生产 Rust（占用 3801/3802）
$pid = (Get-NetTCPConnection -State Listen -LocalPort 3801 | Select-Object -First 1 -ExpandProperty OwningProcess)
Stop-Process -Id $pid -Force
.\scripts\smoke.ps1
# 再重启生产
$env:RUST_LOG='info'; .\target\debug\tsrv-server.exe
```

### 7.3 admin API

```powershell
cd E:\game\Telegram\server\telegram_server

$line = Get-Content .env | Where-Object { $_ -like 'TSRV_ADMIN_TOKEN=*' }
$token = ($line -split '=', 2)[1]
$h = @{ Authorization = "Bearer $token" }

Invoke-RestMethod -Uri 'http://127.0.0.1:3802/healthz'
Invoke-RestMethod -Uri 'http://127.0.0.1:3802/admin/stats' -Headers $h
```

### 7.4 yun 后台

```powershell
Invoke-RestMethod -Uri 'http://127.0.0.1/api/shutdown'
Start-Sleep -Seconds 8
Invoke-WebRequest -Uri 'http://127.0.0.1/apps/admin/' -UseBasicParsing
```

### 7.5 媒体

```text
GET /api/admin/telegram_media?media_id=<id>&variant=thumb&token=<se token>
GET /api/admin/telegram_media?media_id=<id>&variant=full&token=<se token>
```

视频必须支持 `Range: bytes=0-1023` 返回 `206`。

---

## 8. 给下一个 AI 的提示词（可直接复制）

```text
你是接续开发「自建 Telegram 服务端 + yun 管理后台」的 AI。

第一步：先读交接文档
E:\game\Telegram\server\telegram_server\docs\07-handover-unimplemented.md
再读同目录的 01-architecture.md、03-data-model.md、04-test-plan.md、05-roadmap.md。
然后读代码：
- E:\game\Telegram\server\telegram_server\crates\server\src\rpc.rs
- E:\game\Telegram\server\telegram_server\crates\server\src\repo.rs
- E:\game\Telegram\server\telegram_server\crates\server\src\health.rs
- E:\game\Telegram\server\telegram_server\crates\tl\src\lib.rs
- D:\project\yun\ai\src\serv\api\routes\telegram_admin.py
- D:\project\yun\ai\public\apps\admin\js\app.js
- D:\project\yun\ai\public\apps\admin\index.html

工作目标：按交接文档第 6 节的顺序逐项实现未完成功能，从 P0-1（在线状态/正在输入/已读回执）开始。不要一次做完全部，完成一项、验证一项，再进入下一项。

必须遵守：
1. 数据库表/索引/约束/SQL 全部使用 te_ 前缀，schema 是 yun.public，不要建视图。
2. 任何修改 te_messages / te_chats / te_chat_members / te_user_dialogs / PTS 的写操作，必须走 Rust RPC 或 Rust admin API；Python 后台只做鉴权和代理，不能直接写 te_*。
3. 新增消息/编辑/删除/已读/反应/成员变化时，必须同步写 te_update_log 并推送 UpdateHub，保持 PTS 一致。
4. 媒体目录是 E:\game\Telegram\server\telegram_server\data\media；只接受相对 storage_key，拒绝 ..、绝对路径、盘符。
5. 不要动 Go 生产服务 2398 / telesrv_main，不要动 E:\game\Telegram\users\desktop-main，不要未经确认删除/批量修改生产数据。
6. 不要打印 token、密码、私钥；需要时从 .env 和 D:\project\yun\ai\script\config\config.toml 读取。
7. 跑 scripts\smoke.ps1 前先停占用 3801/3802 的 Rust 进程，跑完重启生产 Rust。
8. 每完成一项：cargo check、cargo clippy --workspace --all-targets -- -D warnings、cargo test --workspace；必要时跑 smoke；后台改动重启 serv 并用 HTTP 验证。
9. 每完成一项更新 docs/04-test-plan.md、docs/05-roadmap.md，并勾选 07-handover-unimplemented.md 对应条目。
10. 如果某项需要产品决策、会破坏数据或需要外部服务（短信/支付/STT/对象存储），先停下来用一句话问我，不要自行假设。

每轮回复请汇报：
- 改了哪些文件
- 跑了哪些命令、结果如何
- 客户端/HTTP 验证结果
- 剩余风险或未完成点

现在从交接文档 P0-1 开始。
```
