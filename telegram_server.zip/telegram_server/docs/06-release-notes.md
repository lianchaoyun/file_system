# 第一版发布说明（P11）

日期：2026-11-03

## 范围

本版本是 Rust 自建 Telegram 服务端的第一版实验交付，覆盖：

- 手机号登录 / 注册（固定验证码 `12345`）
- 一对一文本聊天
- 超级群与广播频道
- 图片上传 / 发送 / 下载
- 视频作为普通文件上传 / 下载
- 图片 JPEG 缩略图、文档缩略图、`upload.getFileHashes`
- 回复 / 文本编辑 / 删除 / 转发 / 置顶
- 媒体 caption 编辑、转发 `reply_to` / `drop_media_captions`
- `updates.getState` / `updates.getDifference` / `updates.getChannelDifference` 增量同步
- 同一账号多设备同步
- 临时 auth key 持久化、`auth.bindTempAuthKey` 与过期自动恢复
- Telegram Desktop 与 Android 客户端
- PostgreSQL / Redis 持久化
- 实时 `updateNewMessage` / `updateNewChannelMessage` 推送

未包含：

- 短信 / 邮件 / Passkey / QR 登录
- Bot API
- 音视频通话
- 视频缩略图、多档缩略图
- 视频/文档替换媒体、转发 schedule / send_as
- difference 的 `new_messages` / `channelDifferenceTooLong` 完整快照
- 多 DC、集群、水平扩展
- 管理后台

## 运行

```powershell
# 开发模式（.env，schema=dev，端口 3801/3802）
.\scripts\dev.ps1

# 单元测试
.\scripts\test.ps1

# 全量冒烟
.\scripts\smoke.ps1
```

健康检查：`http://127.0.0.1:3802/healthz`

测试账号：

```text
A：+1 415 555 0100
B：+1 415 555 0101
验证码：12345
```

## 客户端

Desktop：

```text
E:\game\Telegram\users\desktop-rust-test
```

该目录使用独立 `tdata`，自定义服务器指向 `127.0.0.1:3801`。

Android：

```powershell
E:\game\leidian\LDPlayer14\adb.exe install -r E:\game\Telegram\ta_telegram\dist\telegram-afat-debug-selfhost.apk
E:\game\leidian\LDPlayer14\adb.exe reverse tcp:3801 tcp:3801
```

登录页选择“服务器”，填写 `127.0.0.1:3801`。

## 验证

- `cargo test --workspace`：26 个测试通过
- `cargo clippy --workspace --all-targets -- -D warnings`：无警告
- `scripts/smoke.ps1`：P2 / P3 / P4 / P6 / P7 / P8 / P9 / P10 / P11 全量通过
- Telegram Desktop：登录、私聊、群组、频道、图片/视频消息
- Android：登录、会话列表、群组/频道、媒体预览、实时未读推送
- 30 分钟健康与在线稳定性记录：`data/p5-stability.log`

- 同一账号多设备同步（P6）：
  - 发送方其他在线 session 实时收到自己发出的私聊/群组消息
  - 接收方所有在线 session 同时收到推送
  - 发送连接通过 `exclude_session_id` 避免重复
  - 真实 Telegram Desktop 作为第三 session 验证通过
- 临时 auth key（P7）：
  - `p_q_inner_data_temp` 的生命周期写入 `auth_keys.expires_at`
  - `auth.bindTempAuthKey` 持久化 temp→perm 绑定并继承 session
  - 临时 key 过期时返回 transport `-404`，桌面端自动重建并绑定
  - 冒烟覆盖非法密文、重复绑定、持久化重连、过期断言
  - 真实 Telegram Desktop 验证通过（`resolved_user=Some(1)`，绑定落库且在线）
- 媒体缩略图与文件哈希（P8）：
  - 上传图片生成 320px 内 JPEG 缩略图，小图不放大
  - `messageMediaPhoto` 返回 `photoSize("m")` + `photoSize("x")`
  - `thumb_size="m"` 下载缩略图，空 `thumb_size` 下载原图
  - `upload.getFileHashes` 返回 1MB 范围 SHA-256
  - 真实桌面端解析到 m/x 两档 `photoSize`
- 消息操作（P9）：
  - 回复：`messageReplyHeader`
  - 文本编辑：`edit_date` + `updateEditMessage` / `updateEditChannelMessage`
  - 删除：`messages.deleteMessages` / `channels.deleteMessages` + 顶消息刷新
  - 转发：`messageFwdHeader`，支持 `peerUser` / `peerChannel` + `channel_post`
  - 置顶：`messages.updatePinnedMessage` + `updatePinnedMessages` / `updatePinnedChannelMessages`
  - 冒烟覆盖全部操作；真实桌面端同步收到 edit/delete/forward/pin 更新
- PTS 增量同步（P10）：
  - `update_log` 持久化每用户/每频道 Update
  - `updates.getState` / `getDifference` / `getChannelDifference`
  - difference / differenceSlice / differenceTooLong
  - 冒烟覆盖离线补齐与频道补齐
- 媒体 caption 与转发参数（P11）：
  - `messages.editMessage` 带 media 保留原 photo，只更新 caption
  - `messages.forwardMessages` 支持 `reply_to` 与 `drop_media_captions`
  - 真实桌面端收到 caption edit 与带 reply 头的转发
- 兼容性修复：

- 修复 `msgs_ack` 回环：服务端只确认内容消息，不再确认客户端的确认
- 修复 `user.self` 位：只有当前账号设置 self，避免 Android 把其他用户显示为“收藏夹”
- 增加常用可选 RPC 兼容空结果：
  - `account.getThemes`
  - `account.getDefaultEmojiStatuses`
  - `messages.getFeaturedStickers` / `getFeaturedEmojiStickers`
  - `messages.getStickerSet`
  - `messages.getPeerSettings`
  - `messages.getDialogFilters`
  - `messages.getAvailableReactions`
  - `messages.getAttachMenuBots`
  - `messages.getEmojiGroups` / `getEmojiStickerGroups`
  - `messages.getQuickReplies`
  - `contacts.getTopPeers`
  - `help.getPeerColors` / `getPeerProfileColors`
  - `help.getCountriesList`
  - `help.getPromoData`

## 已知问题

1. LDPlayer14 Android 14 镜像在频繁 UI 操作后可能触发 `Too many Binders sent to SYSTEM`，Telegram 进程被系统杀死。属于模拟器限制。
2. `pm clear` 后 tgnet 偶尔复用旧 auth key，服务端返回 `unknown auth_key_id` 并重连。重新登录或重启模拟器可恢复。
3. P7 之前只返回 `boolTrue` 的历史临时 key 绑定不会自动回溯修复；旧 `tdata` 需要补 session 或重新登录。
4. Android 私聊标题在旧缓存下可能仍显示“Saved Messages”；服务端已修复，需清理缓存后复验。
5. 临时 key 过期数据尚未定时清理，长期运行会累积 `auth_keys` / `temp_auth_key_bindings` 记录。
6. 视频缩略图未生成，缩略图只有 `m` 一档，小图不放大。
7. 媒体编辑仅支持 photo caption，视频/文档替换媒体未实现。
8. 转发暂不支持 schedule / send_as 等可选参数；`reply_to` 与 `drop_media_captions` 已支持。
9. 回复暂不支持 quote / story / monoforum 等 `inputReplyTo*` 变体。
10. `update_log` 从 P10 开始记录；更早的频道 PTS 缺口可能返回空差异，`new_messages` 固定为空。

## 生产影响

- 本版本只使用 `3801/3802` 测试端口
- 只使用 `telegram_server` 数据库的 `dev` / `test` schema
- 不修改生产 Go 服务 `2398/2401/2600` 和 `telesrv_main`
