#![allow(dead_code)]
use crate::seek::tdx_data::TdxDayData;
use crate::seek::my_tt::{KlineData, sma, hhv, llv, ref_ as ref_vec, macd, cross};
use serde_json::{json, Value};

pub trait Strategy: Send + Sync {
    fn name(&self) -> &str;
    fn id(&self) -> u32;
    fn scan(&self, data: &[TdxDayData]) -> (bool, Option<Value>);
}

pub struct StrategyScanner { pub strategies: Vec<Box<dyn Strategy>> }

impl StrategyScanner {
    pub fn new() -> Self { Self { strategies: vec![] } }
    pub fn with_all_strategies(mut self) -> Self {
        self.strategies.push(Box::new(TrendBreakoutStrategy));
        self.strategies.push(Box::new(StrongAccelerationStrategy));
        self.strategies.push(Box::new(MultiFactorResonanceStrategy));
        self.strategies.push(Box::new(DeepPitReversalStrategy));
        self.strategies.push(Box::new(StrongBreakoutStrategy));
        self
    }
    pub fn scan_all(&self, data: &[TdxDayData]) -> Vec<(u32, String, Value)> {
        self.strategies.iter().filter_map(|s| {
            let (m, e) = s.scan(data);
            if m { Some((s.id(), s.name().to_string(), e.unwrap_or(json!({})))) } else { None }
        }).collect()
    }
    pub fn len(&self) -> usize { self.strategies.len() }
}

struct TrendBreakoutStrategy;
impl Strategy for TrendBreakoutStrategy {
    fn id(&self) -> u32 { 1 } fn name(&self) -> &str { "趋势突破" }
    fn scan(&self, data: &[TdxDayData]) -> (bool, Option<Value>) {
        let k = KlineData::from(data); let i = k.n-1;
        
        // 趋势: 价格在MA60上方且MA60向上
        let ma5 = sma(&k.close, 5);
        let ma10 = sma(&k.close, 10);
        let ma20 = sma(&k.close, 20);
        let ma60 = sma(&k.close, 60);
        let ma60_ref5 = ref_vec(&ma60, 5);
        let cond_trend = k.close[i] > ma60[i] && ma60[i] > ma60_ref5[i];
        
        // 形态: 站上5/10/20均线，昨天在5日或10日下方（突破）
        let prev_close = ref_vec(&k.close, 1);
        let cond_shape = k.close[i] > ma5[i] && k.close[i] > ma10[i] && k.close[i] > ma20[i] 
            && (prev_close[i] < ma5[i] || prev_close[i] < ma10[i]);
        
        // 放量: 今日成交量是10日最高
        let vol_hhv10 = hhv(&k.vol, 10);
        let cond_vol = k.vol[i] == vol_hhv10[i];
        
        // 涨幅: 今日上涨 > 3%
        let gain_pct = (k.close[i] / k.open[i] - 1.0) * 100.0;
        let cond_gain = gain_pct > 3.0;
        
        let is_match = cond_trend && cond_shape && cond_vol && cond_gain;
        (is_match, Some(json!({"gain_pct": gain_pct})))
    }
}

struct StrongAccelerationStrategy;
impl Strategy for StrongAccelerationStrategy {
    fn id(&self) -> u32 { 2 } fn name(&self) -> &str { "强势起爆" }
    fn scan(&self, data: &[TdxDayData]) -> (bool, Option<Value>) {
        let k = KlineData::from(data); let i = k.n-1;
        
        // 波段涨幅: 从20日低点到现在涨幅
        let llv20 = llv(&k.low, 20);
        let wave_gain = (k.close[i] - llv20[i]) / llv20[i] * 100.0;
        let prev_wave_gain = (k.close[i-1] - llv20[i-1]) / llv20[i-1] * 100.0;
        
        // 昨天波段涨幅 < 阈值 <= 今天波段涨幅 (阈值=50)
        let threshold = 50.0;
        let cond_threshold = prev_wave_gain < threshold && threshold <= wave_gain;
        
        // 均线多头
        let ma5 = sma(&k.close, 5);
        let ma10 = sma(&k.close, 10);
        let ma20 = sma(&k.close, 20);
        let cond_ma = ma5[i] > ma10[i] && ma10[i] > ma20[i];
        
        let is_match = wave_gain > 30.0 && cond_threshold && cond_ma;
        (is_match, Some(json!({"wave_gain": wave_gain})))
    }
}

struct MultiFactorResonanceStrategy;
impl Strategy for MultiFactorResonanceStrategy {
    fn id(&self) -> u32 { 3 } fn name(&self) -> &str { "多因子共振" }
    fn scan(&self, data: &[TdxDayData]) -> (bool, Option<Value>) {
        let k = KlineData::from(data); let i = k.n-1;
        
        // 饱和度: 离20日高低点区间的位置
        let llv20 = llv(&k.low, 20);
        let hhv20 = hhv(&k.high, 20);
        let sat_vol = (k.close[i] - llv20[i]) / (hhv20[i] - llv20[i]) * 100.0;
        let cond_sat = sat_vol > 60.0;
        
        // 均线多头
        let ma5 = sma(&k.close, 5);
        let ma10 = sma(&k.close, 10);
        let ma20 = sma(&k.close, 20);
        let cond_ma = ma5[i] > ma10[i] && ma10[i] > ma20[i];
        
        // 站上MA10
        let cond_above_ma10 = k.close[i] > ma10[i];
        
        // 突破10日高点
        let hhv10 = hhv(&k.high, 10);
        let hhv10_ref = ref_vec(&hhv10, 1);
        let cond_break = k.close[i] > hhv10_ref[i];
        
        let is_match = cond_sat && cond_ma && cond_above_ma10 && cond_break;
        (is_match, Some(json!({"sat_vol": sat_vol})))
    }
}

struct DeepPitReversalStrategy;
impl Strategy for DeepPitReversalStrategy {
    fn id(&self) -> u32 { 4 } fn name(&self) -> &str { "坑底起爆" }
    fn scan(&self, data: &[TdxDayData]) -> (bool, Option<Value>) {
        let k = KlineData::from(data); let i = k.n-1;
        
        // 1. 乖离率 < -7%
        let ma60 = sma(&k.close, 60);
        let bias = (k.close[i] - ma60[i]) / ma60[i] * 100.0;
        let cond_oversold = bias < -7.0;
        
        // 2. 地量判断: 成交量 < 1.5倍20日均量
        let v_ma20 = sma(&k.vol, 20);
        let _is_land_vol = k.vol[i] < v_ma20[i] * 1.5;
        
        // 3. 启动信号: 站上5日线 AND 量比 > 1.1 AND 收红
        let ma5 = sma(&k.close, 5);
        let v_ma5 = sma(&k.vol, 5);
        let v_ma5_ref = ref_vec(&v_ma5, 1);
        let vol_ratio = if v_ma5_ref[i] > 0.0 { k.vol[i] / v_ma5_ref[i] } else { 0.0 };
        
        let cond_launch = k.close[i] > ma5[i] && vol_ratio > 1.1 && k.close[i] > k.open[i];
        
        // 4. 今日涨幅 > 1%
        let today_change = (k.close[i] / k.close[i-1] - 1.0) * 100.0;
        let cond_positive = today_change > 1.0;
        
        let is_match = cond_oversold && cond_launch && cond_positive;
        (is_match, Some(json!({"bias": bias, "vol_ratio": vol_ratio, "today_change": today_change})))
    }
}

struct StrongBreakoutStrategy;
impl Strategy for StrongBreakoutStrategy {
    fn id(&self) -> u32 { 5 } fn name(&self) -> &str { "强势启动" }
    fn scan(&self, data: &[TdxDayData]) -> (bool, Option<Value>) {
        let k = KlineData::from(data); let i = k.n-1;
        
        // 1. 均线多头: MA5 > MA10 > MA20
        let ma5 = sma(&k.close, 5);
        let ma10 = sma(&k.close, 10);
        let ma20 = sma(&k.close, 20);
        let cond_ma = k.close[i] > ma5[i] && ma5[i] > ma10[i] && ma10[i] > ma20[i];
        
        // 2. 放量: VOL > V_MA20 * 1.5 AND VOL > V_MA5
        let v_ma5 = sma(&k.vol, 5);
        let v_ma20 = sma(&k.vol, 20);
        let cond_vol = k.vol[i] > v_ma20[i] * 1.5 && k.vol[i] > v_ma5[i];
        
        // 3. 突破20日高点: CLOSE 上穿昨天的20日最高价
        let hhv20 = hhv(&k.high, 20);
        let hhv20_ref = ref_vec(&hhv20, 1);
        let cond_break = cross(&k.close, &hhv20_ref)[i];
        
        // 4. MACD强势: DIF > DEA AND MACD_VAL > 0
        let (_, _dea, macd_val) = macd(&k.close, 12, 26, 9);
        let cond_macd = macd_val[i] > 0.0; // DIF > DEA 在 macd 函数中已处理
        
        let is_match = cond_ma && cond_vol && cond_break && cond_macd;
        let vol_ratio = if v_ma20[i] > 0.0 { k.vol[i] / v_ma20[i] } else { 0.0 };
        (is_match, Some(json!({
            "ma5_ma20": ma5[i] / ma20[i],
            "vol_ratio": vol_ratio,
            "macd": macd_val[i]
        })))
    }
}