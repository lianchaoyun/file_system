//! 寻优后台服务模块
//! 支持独立进程运行或嵌入 iced 应用

pub mod opt_queue;
pub mod opt_worker;
pub mod tdx_data;
pub mod my_tt;
pub mod strategy_opt;
pub mod strategy_scan;
pub mod opt_data;

// TdxDayData → my_tt::KlineData 零拷贝转换
impl From<&[tdx_data::TdxDayData]> for my_tt::KlineData {
    fn from(data: &[tdx_data::TdxDayData]) -> Self {
        my_tt::KlineData::from_raw(
            data.iter().map(|d| d.close as f64).collect(),
            data.iter().map(|d| d.open as f64).collect(),
            data.iter().map(|d| d.high as f64).collect(),
            data.iter().map(|d| d.low as f64).collect(),
            data.iter().map(|d| d.vol as f64).collect(),
        )
    }
}

use crate::log;
use std::sync::Arc;
use std::sync::atomic::{AtomicBool, Ordering};

pub use opt_queue::OptQueueManager as OptQueue;
pub use opt_worker::OptWorker;

/// 寻优服务管理器
/// 支持在 iced 应用中嵌入运行
pub struct OptServer {
    queue: Arc<OptQueue>,
    worker: OptWorker,
    stop_flag: Arc<AtomicBool>,
}

impl OptServer {
    /// 创建并初始化寻优服务
    pub async fn new(pool: Arc<bb8::Pool<bb8_redis::RedisConnectionManager>>) -> Result<Self, String> {
        //println!("[OptServer] 初始化中...");

        // 预加载权息库
        if let Ok(_) = crate::seek::tdx_data::init_tdx_config() {
            log!("[OptServer] 预加载权息库...");
            let provider = crate::seek::tdx_data::TdxDataProvider::new();
            provider.preload_gbbq();
            log!("[OptServer] 权息库加载完成");
        }

        let queue = Arc::new(OptQueue::new(pool));
        let worker = OptWorker::new(queue.clone());
        let stop_flag = Arc::new(AtomicBool::new(false));

        //println!("[OptServer] 初始化完成");
        Ok(Self { queue, worker, stop_flag })
    }

    /// 启动服务（阻塞，使用内部停止标志）
    pub async fn run(&self) {
        self.worker.run_with_stop(self.stop_flag.clone()).await;
    }

    /// 启动服务（阻塞，使用外部停止标志）
    pub async fn run_with_stop(&self, stop_flag: Arc<AtomicBool>) {
        self.worker.run_with_stop(stop_flag).await;
    }

    /// 停止服务
    pub fn stop(&self) {
        self.stop_flag.store(true, Ordering::SeqCst);
        log!("[OptServer] 停止信号已发送");
    }

    /// 获取队列管理器（用于查询任务状态等）
    pub fn queue(&self) -> &Arc<OptQueue> {
        &self.queue
    }
}

/// 启动独立的 opt_server 进程
pub async fn run_standalone() {
    dotenv::dotenv().ok();
    let redis_url = std::env::var("REDIS_URL")
        .unwrap_or_else(|_| "redis://127.0.0.1/".to_string());

    let manager = bb8_redis::RedisConnectionManager::new(redis_url).unwrap();
    let pool = Arc::new(bb8::Pool::builder()
        .max_size(10)
        .build(manager)
        .await
        .expect("Failed to create Redis pool"));

    log!("[OptServer] Redis 连接池初始化完成");

    let server = OptServer::new(pool).await.expect("Failed to create OptServer");
    server.run().await;
}
