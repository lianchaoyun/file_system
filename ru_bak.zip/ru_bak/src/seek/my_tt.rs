//! MyTT 麦语言-通达信-同花顺指标实现 Rust 版本
//! 函数名和参数尽量与 Python 版保持一致
//!
//! 迁移自 `src/opt/my_tt.rs`，已移除 TdxDayData 耦合
//! 原 opt 模块通过 `From<&[TdxDayData]>` 转换接入

use std::f64::consts::PI;

// ==================== K线数据结构 ====================

/// K线数据结构（不依赖任何外部类型）
#[derive(Clone)]
pub struct KlineData {
    pub close: Vec<f64>,
    pub open: Vec<f64>,
    pub high: Vec<f64>,
    pub low: Vec<f64>,
    pub vol: Vec<f64>,
    pub n: usize,
}

impl KlineData {
    /// 从原始 OHLCV 数组构建
    pub fn from_raw(
        close: Vec<f64>,
        open: Vec<f64>,
        high: Vec<f64>,
        low: Vec<f64>,
        vol: Vec<f64>,
    ) -> Self {
        let n = close.len();
        Self { n, close, open, high, low, vol }
    }

    pub fn last(&self) -> Option<LastKline> {
        if self.n == 0 { return None; }
        let i = self.n - 1;
        Some(LastKline {
            close: self.close[i],
            open: self.open[i],
            high: self.high[i],
            low: self.low[i],
            vol: self.vol[i],
            prev_close: if i > 0 { self.close[i - 1] } else { self.close[i] },
        })
    }
}

/// 最新一根K线数据
pub struct LastKline {
    pub close: f64,
    pub open: f64,
    pub high: f64,
    pub low: f64,
    pub vol: f64,
    pub prev_close: f64,
}

// ==================== 0级：核心工具函数 ====================

/// 四舍五入取D位小数
pub fn rd(n: f64, d: i32) -> f64 {
    let p = 10_f64.powi(d);
    (n * p).round() / p
}

/// 返回序列倒数第N个值
pub fn ret(s: &[f64], n: usize) -> f64 {
    if s.is_empty() || n == 0 || n > s.len() {
        return f64::NAN;
    }
    s[s.len() - n]
}

/// 绝对值
pub fn abs(s: &[f64]) -> Vec<f64> {
    s.iter().map(|x| x.abs()).collect()
}

/// 自然对数
pub fn ln(s: &[f64]) -> Vec<f64> {
    s.iter().map(|x| x.ln()).collect()
}

/// 幂运算
pub fn pow(s: &[f64], n: f64) -> Vec<f64> {
    s.iter().map(|x| x.powf(n)).collect()
}

/// 平方根
pub fn sqrt(s: &[f64]) -> Vec<f64> {
    s.iter().map(|x| x.sqrt()).collect()
}

/// 正弦(弧度)
pub fn sin(s: &[f64]) -> Vec<f64> {
    s.iter().map(|x| x.sin()).collect()
}

/// 余弦(弧度)
pub fn cos(s: &[f64]) -> Vec<f64> {
    s.iter().map(|x| x.cos()).collect()
}

/// 正切(弧度)
pub fn tan(s: &[f64]) -> Vec<f64> {
    s.iter().map(|x| x.tan()).collect()
}

/// 序列取最大值
pub fn max(s1: &[f64], s2: &[f64]) -> Vec<f64> {
    s1.iter().zip(s2.iter()).map(|(a, b)| a.max(*b)).collect()
}

/// 序列取最小值
pub fn min(s1: &[f64], s2: &[f64]) -> Vec<f64> {
    s1.iter().zip(s2.iter()).map(|(a, b)| a.min(*b)).collect()
}

/// 序列布尔判断
pub fn if_<T: Into<Vec<f64>>>(cond: &[bool], a: T, b: T) -> Vec<f64> {
    let a = a.into();
    let b = b.into();
    cond.iter()
        .zip(a.iter().zip(b.iter()))
        .map(|(c, (av, bv))| if *c { *av } else { *bv })
        .collect()
}

/// 对序列整体下移动N,返回序列
pub fn ref_(s: &[f64], n: usize) -> Vec<f64> {
    if n == 0 {
        return s.to_vec();
    }
    let mut result = vec![f64::NAN; n];
    if n < s.len() {
        result.extend_from_slice(&s[..s.len() - n]);
    }
    result
}

/// 前一个值减后一个值
pub fn diff(s: &[f64], n: usize) -> Vec<f64> {
    let mut result = vec![f64::NAN; n];
    for i in n..s.len() {
        result.push(s[i] - s[i - n]);
    }
    result
}

/// 求序列的N天标准差
pub fn std(s: &[f64], n: usize) -> Vec<f64> {
    let mut result = vec![f64::NAN; n - 1];
    for i in (n - 1)..s.len() {
        let slice = &s[i + 1 - n..=i];
        let mean = slice.iter().sum::<f64>() / n as f64;
        let variance = slice.iter().map(|x| (x - mean).powi(2)).sum::<f64>() / n as f64;
        result.push(variance.sqrt());
    }
    result
}

/// 年化波动率（日收益率的滚动标准差×√252，默认21日窗口）
pub fn annualized_volatility(close: &[f64], window: usize) -> f64 {
    if close.len() < window + 1 {
        return 0.0;
    }
    let returns: Vec<f64> = close.windows(2)
        .map(|w| w[1] / w[0] - 1.0)
        .collect();
    let vol_series = std(&returns, window);
    vol_series.last().copied().filter(|v| v.is_finite()).unwrap_or(0.0) * (252.0_f64).sqrt()
}

/// 对序列求N天累计和
pub fn sum(s: &[f64], n: usize) -> Vec<f64> {
    if n == 0 {
        // 全部累加
        let mut result = Vec::with_capacity(s.len());
        let mut acc = 0.0;
        for x in s {
            acc += x;
            result.push(acc);
        }
        return result;
    }
    let mut result = vec![f64::NAN; n - 1];
    for i in (n - 1)..s.len() {
        let sum: f64 = s[i + 1 - n..=i].iter().sum();
        result.push(sum);
    }
    result
}

/// 返回序列S最后的值组成常量序列
pub fn const_(s: &[f64]) -> Vec<f64> {
    if s.is_empty() {
        return vec![];
    }
    vec![s[s.len() - 1]; s.len()]
}

/// HHV 最近N天最高价
pub fn hhv(s: &[f64], n: usize) -> Vec<f64> {
    if n == 0 || s.is_empty() {
        return vec![];
    }
    let mut result = vec![f64::NAN; n - 1.min(s.len())];
    for i in (n - 1).min(s.len())..s.len() {
        let start = i + 1 - n;
        let max_val = s[start..=i].iter().fold(f64::NAN, |acc, &x| acc.max(x));
        result.push(max_val);
    }
    result
}

/// LLV 最近N天最低价
pub fn llv(s: &[f64], n: usize) -> Vec<f64> {
    if n == 0 || s.is_empty() {
        return vec![];
    }
    let mut result = vec![f64::NAN; n - 1.min(s.len())];
    for i in (n - 1).min(s.len())..s.len() {
        let start = i + 1 - n;
        let min_val = s[start..=i].iter().fold(f64::INFINITY, |acc, &x| acc.min(x));
        result.push(min_val);
    }
    result
}

/// 求N周期内S最高值到当前周期数
pub fn hhv_bars(s: &[f64], n: usize) -> Vec<f64> {
    let mut result = vec![0.0; n - 1.min(s.len())];
    for i in (n - 1).min(s.len())..s.len() {
        let start = i + 1 - n;
        let slice = &s[start..=i];
        let max_idx = slice
            .iter()
            .enumerate()
            .rev()
            .max_by(|(_, a), (_, b)| a.partial_cmp(b).unwrap())
            .map(|(idx, _)| idx)
            .unwrap_or(0);
        result.push(max_idx as f64);
    }
    result
}

/// 求N周期内S最低值到当前周期数
pub fn llv_bars(s: &[f64], n: usize) -> Vec<f64> {
    let mut result = vec![0.0; n - 1.min(s.len())];
    for i in (n - 1).min(s.len())..s.len() {
        let start = i + 1 - n;
        let slice = &s[start..=i];
        let min_idx = slice
            .iter()
            .enumerate()
            .rev()
            .min_by(|(_, a), (_, b)| a.partial_cmp(b).unwrap())
            .map(|(idx, _)| idx)
            .unwrap_or(0);
        result.push(min_idx as f64);
    }
    result
}

/// HHV支持N为序列版本
pub fn hhv_var(s: &[f64], n: &[f64]) -> Vec<f64> {
    let len = s.len().min(n.len());
    let mut result = vec![f64::NAN; len];
    for i in 0..len {
        let period = n[i] as usize;
        if !n[i].is_nan() && period > 0 && period <= i + 1 {
            let start = i + 1 - period;
            let max_val = s[start..=i].iter().fold(f64::NAN, |acc, &x| acc.max(x));
            result[i] = max_val;
        }
    }
    result
}

/// LLV支持N为序列版本
pub fn llv_var(s: &[f64], n: &[f64]) -> Vec<f64> {
    let len = s.len().min(n.len());
    let mut result = vec![f64::NAN; len];
    for i in 0..len {
        let period = n[i] as usize;
        if !n[i].is_nan() && period > 0 && period <= i + 1 {
            let start = i + 1 - period;
            let min_val = s[start..=i].iter().fold(f64::INFINITY, |acc, &x| acc.min(x));
            result[i] = min_val;
        }
    }
    result
}

/// 简单移动平均 (2参数版本，与通达信一致)
pub fn sma(s: &[f64], period: usize) -> Vec<f64> {
    let mut result = vec![f64::NAN; s.len()];
    if period == 0 || s.len() < period { return result; }

    let mut sum = 0.0;
    for i in 0..period {
        sum += s[i];
    }

    for i in (period - 1)..s.len() {
        if i >= period {
            sum = sum - s[i - period] + s[i];
        }
        result[i] = sum / period as f64;
    }
    result
}

/// N日简单移动平均
pub fn ma(s: &[f64], n: usize) -> Vec<f64> {
    if n == 0 || s.is_empty() {
        return vec![];
    }
    let mut result = vec![f64::NAN; n - 1.min(s.len())];
    for i in (n - 1).min(s.len())..s.len() {
        let sum: f64 = s[i + 1 - n..=i].iter().sum();
        result.push(sum / n as f64);
    }
    result
}

/// 指数移动平均
pub fn ema(s: &[f64], n: usize) -> Vec<f64> {
    if n == 0 || s.is_empty() {
        return vec![];
    }
    let alpha = 2.0 / (n as f64 + 1.0);
    let mut result = Vec::with_capacity(s.len());
    let mut ema_val = s[0];
    result.push(ema_val);

    for i in 1..s.len() {
        ema_val = alpha * s[i] + (1.0 - alpha) * ema_val;
        result.push(ema_val);
    }
    result
}

/// 中国式SMA (3参数版本)
pub fn sma_cn(s: &[f64], n: usize, m: usize) -> Vec<f64> {
    if n == 0 || s.is_empty() {
        return vec![];
    }
    let alpha = m as f64 / n as f64;
    let mut result = Vec::with_capacity(s.len());
    let mut sma_val = s[0];
    result.push(sma_val);

    for i in 1..s.len() {
        sma_val = alpha * s[i] + (1.0 - alpha) * sma_val;
        result.push(sma_val);
    }
    result
}

/// 加权移动平均
pub fn wma(s: &[f64], n: usize) -> Vec<f64> {
    if n == 0 || s.is_empty() {
        return vec![];
    }
    let mut result = vec![f64::NAN; n - 1.min(s.len())];
    let denominator = n as f64 * (n as f64 + 1.0) / 2.0;

    for i in (n - 1).min(s.len())..s.len() {
        let start = i + 1 - n;
        let mut weighted_sum = 0.0;
        for (j, &val) in s[start..=i].iter().enumerate() {
            weighted_sum += val * (j + 1) as f64;
        }
        result.push(weighted_sum * 2.0 / denominator);
    }
    result
}

/// 动态移动平均
pub fn dma(s: &[f64], a: &[f64]) -> Vec<f64> {
    if s.is_empty() || a.is_empty() {
        return vec![];
    }
    let mut result = vec![s[0]; s.len()];
    for i in 1..s.len() {
        let alpha = if i < a.len() { a[i] } else { a[a.len() - 1] };
        let alpha = if alpha.is_nan() || alpha <= 0.0 || alpha >= 1.0 {
            1.0
        } else {
            alpha
        };
        result[i] = alpha * s[i] + (1.0 - alpha) * result[i - 1];
    }
    result
}

/// 偏差自适应移动平均线 DSMA
pub fn dsma(s: &[f64], n: usize) -> Vec<f64> {
    if s.is_empty() || n == 0 {
        return vec![];
    }
    let a1 = (-1.414 * PI * 2.0 / n as f64).exp();
    let b1 = 2.0 * a1 * (1.414 * PI * 2.0 / n as f64).cos();
    let c2 = b1;
    let c3 = -a1 * a1;
    let c1 = 1.0 - c2 - c3;

    let mut zeros = vec![0.0; s.len()];
    for i in 1..s.len() - 1 {
        zeros[i + 1] = s[i + 1] - s[i - 1];
    }
    zeros[0] = 0.0;
    zeros[1] = s[1] - s[0];

    let mut filt = vec![0.0; s.len()];
    for i in 2..s.len() {
        filt[i] = c1 * (zeros[i] + zeros[i - 1]) / 2.0 + c2 * filt[i - 1] + c3 * filt[i - 2];
    }

    let rms = s
        .windows(n)
        .enumerate()
        .map(|(i, w)| {
            if i + n > s.len() {
                return f64::NAN;
            }
            let sum_sq: f64 = w.iter().map(|&x| x * x).sum();
            (sum_sq / n as f64).sqrt()
        })
        .collect::<Vec<f64>>();

    let mut scaled_filt = vec![0.0; s.len()];
    for i in 0..s.len() {
        let r = if i < rms.len() && !rms[i].is_nan() && rms[i] != 0.0 {
            rms[i]
        } else {
            1.0
        };
        scaled_filt[i] = filt[i] / r;
    }

    let alpha1: Vec<f64> = scaled_filt.iter().map(|x| x.abs() * 5.0 / n as f64).collect();
    dma(s, &alpha1)
}

/// 平均绝对偏差
pub fn avedev(s: &[f64], n: usize) -> Vec<f64> {
    if n == 0 || s.is_empty() {
        return vec![];
    }
    let mut result = vec![f64::NAN; n - 1.min(s.len())];
    for i in (n - 1).min(s.len())..s.len() {
        let slice = &s[i + 1 - n..=i];
        let mean = slice.iter().sum::<f64>() / n as f64;
        let abs_dev: f64 = slice.iter().map(|x| (x - mean).abs()).sum();
        result.push(abs_dev / n as f64);
    }
    result
}

/// 返回S序列N周期线性回归斜率
pub fn slope(s: &[f64], n: usize) -> Vec<f64> {
    if n == 0 || s.len() < n {
        return vec![];
    }
    let mut result = vec![f64::NAN; n - 1];
    for i in (n - 1)..s.len() {
        let slice = &s[i + 1 - n..=i];
        let x_mean = (n - 1) as f64 / 2.0;
        let y_mean = slice.iter().sum::<f64>() / n as f64;
        let mut numerator = 0.0;
        let mut denominator = 0.0;
        for (j, &y) in slice.iter().enumerate() {
            let x = j as f64;
            numerator += (x - x_mean) * (y - y_mean);
            denominator += (x - x_mean).powi(2);
        }
        result.push(if denominator != 0.0 { numerator / denominator } else { 0.0 });
    }
    result
}

/// 返回S序列N周期线性回归后的预测值
pub fn forcast(s: &[f64], n: usize) -> Vec<f64> {
    if n == 0 || s.len() < n {
        return vec![];
    }
    let mut result = vec![f64::NAN; n - 1];
    for i in (n - 1)..s.len() {
        let slice = &s[i + 1 - n..=i];
        let x_mean = (n - 1) as f64 / 2.0;
        let y_mean = slice.iter().sum::<f64>() / n as f64;
        let mut numerator = 0.0;
        let mut denominator = 0.0;
        for (j, &y) in slice.iter().enumerate() {
            let x = j as f64;
            numerator += (x - x_mean) * (y - y_mean);
            denominator += (x - x_mean).powi(2);
        }
        let slope = if denominator != 0.0 { numerator / denominator } else { 0.0 };
        // 预测第N个值 (索引N-1)
        result.push(y_mean + slope * (n - 1) as f64);
    }
    result
}

/// N日前的值 (向前移动N位)
pub fn prev(s: &[f64], n: usize) -> Vec<f64> {
    ref_(s, n)
}

/// 条件求和 (统计n周期内满足条件的次数)
pub fn sum_cond(cond: &[bool], n: usize) -> Vec<f64> {
    count(cond, n)
}

/// 从前A日到前B日一直满足条件
pub fn last(cond: &[bool], a: usize, b: usize) -> Vec<bool> {
    if a <= b || b >= a {
        return vec![false; cond.len()];
    }
    let mut result = vec![false; cond.len()];
    for i in a..cond.len() {
        let all_true = cond[i - a..=i - b].iter().all(|&x| x);
        result.push(all_true);
    }
    result
}

// ==================== 1级：应用层函数 ====================

/// 最近N天满足条件的天数
pub fn count(s: &[bool], n: usize) -> Vec<f64> {
    sum(
        &s.iter()
            .map(|&x| if x { 1.0 } else { 0.0 })
            .collect::<Vec<f64>>(),
        n,
    )
}

/// 最近N天是否都是True
pub fn every(s: &[bool], n: usize) -> Vec<bool> {
    s.iter()
        .enumerate()
        .map(|(i, _)| {
            if i + 1 < n {
                false
            } else {
                s[i + 1 - n..=i].iter().all(|&x| x)
            }
        })
        .collect()
}

/// N日内是否存在一天为True
pub fn exist(s: &[bool], n: usize) -> Vec<bool> {
    s.iter()
        .enumerate()
        .map(|(i, &_val)| {
            if i + 1 < n {
                false
            } else {
                s[i + 1 - n..=i].iter().any(|&x| x)
            }
        })
        .collect()
}

/// FILTER函数
pub fn filter_(s: &mut [f64], n: usize) {
    for i in 0..s.len() {
        if i + n < s.len() && s[i] != 0.0 {
            for j in i + 1..=i + n {
                s[j] = 0.0;
            }
        }
    }
}

/// 上一次条件成立到当前的周期
pub fn barslast(s: &[bool]) -> Vec<f64> {
    let mut result = Vec::with_capacity(s.len());
    let mut last_true_idx: Option<usize> = None;

    for (i, &val) in s.iter().enumerate() {
        let cur = if val {
            last_true_idx = Some(i);
            0
        } else {
            if let Some(idx) = last_true_idx {
                i - idx
            } else {
                i + 1
            }
        };
        result.push(cur as f64);
    }
    result
}

/// 统计连续满足条件的周期数
pub fn barslastcount(s: &[bool]) -> Vec<f64> {
    let mut result = Vec::with_capacity(s.len());
    let mut count = 0_i32;

    for &val in s.iter() {
        if val {
            count += 1;
        } else {
            count = 0;
        }
        result.push(count as f64);
    }
    result
}

/// N周期内第一次条件成立到现在的周期数
pub fn barssincen(s: &[bool], n: usize) -> Vec<f64> {
    let mut result = Vec::with_capacity(s.len());

    for i in 0..s.len() {
        if i + 1 < n {
            result.push(0.0);
        } else {
            let slice = &s[i + 1 - n..=i];
            let first_true_idx = slice.iter().position(|&x| x);
            match first_true_idx {
                Some(idx) => result.push((n - 1 - idx) as f64),
                None => result.push(0.0),
            }
        }
    }
    result
}

/// 判断向上金叉/向下死叉
pub fn cross(s1: &[f64], s2: &[f64]) -> Vec<bool> {
    if s1.len() != s2.len() || s1.len() < 2 {
        return vec![false; s1.len()];
    }
    let mut result = vec![false; s1.len()];
    for i in 1..s1.len() {
        result[i] = s1[i - 1] <= s2[i - 1] && s1[i] > s2[i];
    }
    result
}

/// 两条线维持一定周期后交叉
pub fn longcross(s1: &[f64], s2: &[f64], n: usize) -> Vec<bool> {
    if s1.len() != s2.len() || s1.len() < n {
        return vec![false; s1.len()];
    }
    let last_result = last(
        &s1.iter()
            .zip(s2.iter())
            .map(|(a, b)| a < b)
            .collect::<Vec<bool>>(),
        n,
        1,
    );
    cross(s1, s2)
        .iter()
        .zip(last_result.iter())
        .map(|(&c, &l)| c && l)
        .collect()
}

/// 当条件成立时取当前值，否则取上次成立时的值
pub fn valuewhen(s: &[bool], x: &[f64]) -> Vec<f64> {
    let mut result = Vec::with_capacity(s.len());
    let mut last_val: f64 = f64::NAN;

    for (&cond, &val) in s.iter().zip(x.iter()) {
        if cond {
            last_val = val;
        }
        result.push(last_val);
    }
    result
}

/// S处于A和B之间时为真
pub fn between(s: &[f64], a: &[f64], b: &[f64]) -> Vec<bool> {
    s.iter()
        .zip(a.iter().zip(b.iter()))
        .map(|(&sv, (&av, &bv))| ((av < sv) && (sv < bv)) || ((av > sv) && (sv > bv)))
        .collect()
}

/// 当前值是近多少周期内最大
pub fn toprange(s: &[f64]) -> Vec<f64> {
    let mut result = vec![0.0; s.len()];
    for i in 1..s.len() {
        let mut count = 0;
        for &val in s[..i].iter().rev() {
            if val >= s[i] {
                break;
            }
            count += 1;
        }
        result[i] = count as f64;
    }
    result
}

/// 当前值是近多少周期内最小
pub fn lowrange(s: &[f64]) -> Vec<f64> {
    let mut result = vec![0.0; s.len()];
    for i in 1..s.len() {
        let mut count = 0;
        for &val in s[..i].iter().rev() {
            if val <= s[i] {
                break;
            }
            count += 1;
        }
        result[i] = count as f64;
    }
    result
}

// ==================== 2级：技术指标函数 ====================

/// MACD指标
pub fn macd(close: &[f64], short: usize, long: usize, m: usize) -> (Vec<f64>, Vec<f64>, Vec<f64>) {
    let ema_short = ema(close, short);
    let ema_long = ema(close, long);
    let dif: Vec<f64> = ema_short.iter().zip(ema_long.iter()).map(|(a, b)| a - b).collect();
    let dea = ema(&dif, m);
    let macd: Vec<f64> = dif.iter().zip(dea.iter()).map(|(a, b)| (a - b) * 2.0).collect();
    (
        dif.iter().map(|&x| rd(x, 3)).collect(),
        dea.iter().map(|&x| rd(x, 3)).collect(),
        macd.iter().map(|&x| rd(x, 3)).collect(),
    )
}

/// KDJ指标
pub fn kdj(
    close: &[f64],
    high: &[f64],
    low: &[f64],
    n: usize,
    m1: usize,
    m2: usize,
) -> (Vec<f64>, Vec<f64>, Vec<f64>) {
    let n = n.max(1);
    let rsv = close
        .iter()
        .zip(llv(low, n).iter().zip(hhv(high, n).iter()))
        .map(|(c, (ll, hh))| {
            if hh - ll == 0.0 || hh.is_nan() || ll.is_nan() {
                50.0
            } else {
                (c - ll) / (hh - ll) * 100.0
            }
        })
        .collect::<Vec<f64>>();

    let k = ema(&rsv, m1 * 2 - 1);
    let d = ema(&k, m2 * 2 - 1);
    let j: Vec<f64> = k.iter().zip(d.iter()).map(|(k, d)| k * 3.0 - d * 2.0).collect();

    (k, d, j)
}

/// RSI指标
pub fn rsi(close: &[f64], n: usize) -> Vec<f64> {
    let n = n.max(1);
    let diff = diff(close, 1);
    let abs_diff: Vec<f64> = diff.iter().map(|x| x.abs()).collect();
    let sma_abs = sma_cn(&abs_diff, n, 1);
    let result: Vec<f64> = sma_abs
        .iter()
        .zip(
            diff.iter()
                .map(|x| if *x > 0.0 { *x } else { 0.0 })
                .collect::<Vec<f64>>()
                .iter(),
        )
        .map(|(abs, pos)| {
            if *abs < 1e-10 {
                0.0
            } else {
                pos / abs * 100.0
            }
        })
        .collect();
    result.iter().map(|&x| rd(x, 2)).collect()
}

/// W&R威廉指标
pub fn wr(close: &[f64], high: &[f64], low: &[f64], n: usize, n1: usize) -> (Vec<f64>, Vec<f64>) {
    let wr1: Vec<f64> = close
        .iter()
        .zip(hhv(high, n).iter().zip(llv(low, n).iter()))
        .map(|(c, (hh, ll))| {
            if hh - ll == 0.0 || hh.is_nan() || ll.is_nan() {
                0.0
            } else {
                (hh - c) / (hh - ll) * 100.0
            }
        })
        .collect();

    let wr2: Vec<f64> = close
        .iter()
        .zip(hhv(high, n1).iter().zip(llv(low, n1).iter()))
        .map(|(c, (hh, ll))| {
            if hh - ll == 0.0 || hh.is_nan() || ll.is_nan() {
                0.0
            } else {
                (hh - c) / (hh - ll) * 100.0
            }
        })
        .collect();

    (
        wr1.iter().map(|&x| rd(x, 2)).collect(),
        wr2.iter().map(|&x| rd(x, 2)).collect(),
    )
}

/// BIAS乖离率
pub fn bias(close: &[f64], l1: usize, l2: usize, l3: usize) -> (Vec<f64>, Vec<f64>, Vec<f64>) {
    let ma1 = ma(close, l1);
    let ma2 = ma(close, l2);
    let ma3 = ma(close, l3);

    let bias1: Vec<f64> = close
        .iter()
        .zip(ma1.iter())
        .map(|(c, m)| if *m == 0.0 { 0.0 } else { (c - m) / m * 100.0 })
        .collect();
    let bias2: Vec<f64> = close
        .iter()
        .zip(ma2.iter())
        .map(|(c, m)| if *m == 0.0 { 0.0 } else { (c - m) / m * 100.0 })
        .collect();
    let bias3: Vec<f64> = close
        .iter()
        .zip(ma3.iter())
        .map(|(c, m)| if *m == 0.0 { 0.0 } else { (c - m) / m * 100.0 })
        .collect();

    (
        bias1.iter().map(|&x| rd(x, 2)).collect(),
        bias2.iter().map(|&x| rd(x, 2)).collect(),
        bias3.iter().map(|&x| rd(x, 2)).collect(),
    )
}

/// BOLL布林带
pub fn boll(close: &[f64], n: usize, p: usize) -> (Vec<f64>, Vec<f64>, Vec<f64>) {
    let mid = ma(close, n);
    let std_n = std(close, n);
    let upper: Vec<f64> = mid.iter().zip(std_n.iter()).map(|(m, s)| m + s * p as f64).collect();
    let lower: Vec<f64> = mid.iter().zip(std_n.iter()).map(|(m, s)| m - s * p as f64).collect();

    (
        upper.iter().map(|&x| rd(x, 2)).collect(),
        mid.iter().map(|&x| rd(x, 2)).collect(),
        lower.iter().map(|&x| rd(x, 2)).collect(),
    )
}

/// PSY心理线
pub fn psy(close: &[f64], n: usize, m: usize) -> (Vec<f64>, Vec<f64>) {
    let cond: Vec<bool> = close
        .iter()
        .zip(ref_(close, 1).iter())
        .map(|(c, p)| c > p)
        .collect();
    let psy_vals: Vec<f64> = count(&cond, n)
        .iter()
        .map(|x| x / n as f64 * 100.0)
        .collect();
    let psyma = ma(&psy_vals, m);

    (
        psy_vals.iter().map(|&x| rd(x, 2)).collect(),
        psyma.iter().map(|&x| rd(x, 2)).collect(),
    )
}

/// CCI顺势指标
pub fn cci(close: &[f64], high: &[f64], low: &[f64], n: usize) -> Vec<f64> {
    let tp: Vec<f64> = high
        .iter()
        .zip(low.iter().zip(close.iter()))
        .map(|(h, (l, c))| (h + l + c) / 3.0)
        .collect();
    let tp_ma = ma(&tp, n);
    let tp_avedev: Vec<f64> = tp.iter().zip(tp_ma.iter()).map(|(t, m)| (t - m).abs()).collect();
    let result: Vec<f64> = tp
        .iter()
        .zip(tp_ma.iter().zip(tp_avedev.iter()))
        .map(|(t, (m, ad))| {
            if *ad == 0.0 || ad.is_nan() {
                0.0
            } else {
                (t - m) / (0.015 * ad)
            }
        })
        .collect();
    result
}

/// ATR真实波动
pub fn atr(close: &[f64], high: &[f64], low: &[f64], n: usize) -> Vec<f64> {
    let tr1: Vec<f64> = high.iter().zip(low.iter()).map(|(h, l)| h - l).collect();
    let tr2: Vec<f64> = high
        .iter()
        .zip(ref_(close, 1).iter())
        .map(|(h, c)| (h - c).abs())
        .collect();
    let tr3: Vec<f64> = low
        .iter()
        .zip(ref_(close, 1).iter())
        .map(|(l, c)| (l - c).abs())
        .collect();

    let tr: Vec<f64> = tr1
        .iter()
        .zip(tr2.iter().zip(tr3.iter()))
        .map(|(t1, (t2, t3))| t1.max(*t2).max(*t3))
        .collect();

    ma(&tr, n)
}

/// BBI多空指标
pub fn bbi(close: &[f64], m1: usize, m2: usize, m3: usize, m4: usize) -> Vec<f64> {
    let ma1 = ma(close, m1);
    let ma2 = ma(close, m2);
    let ma3 = ma(close, m3);
    let ma4 = ma(close, m4);

    ma1.iter()
        .zip(
            ma2.iter()
                .zip(ma3.iter().zip(ma4.iter())),
        )
        .map(|(a1, (a2, (a3, a4)))| (a1 + a2 + a3 + a4) / 4.0)
        .collect()
}

/// DMI动向指标
pub fn dmi(
    close: &[f64],
    high: &[f64],
    low: &[f64],
    m1: usize,
    m2: usize,
) -> (Vec<f64>, Vec<f64>, Vec<f64>, Vec<f64>) {
    let tr = sum(
        &high
            .iter()
            .zip(low.iter().zip(ref_(close, 1).iter()))
            .map(|(h, (l, p))| {
                let t1 = h - l;
                let t2 = (h - p).abs();
                let t3 = (l - p).abs();
                t1.max(t2).max(t3)
            })
            .collect::<Vec<f64>>(),
        m1,
    );

    let hd = high
        .iter()
        .zip(ref_(high, 1).iter())
        .map(|(h, ph)| h - ph)
        .collect::<Vec<f64>>();
    let ld = ref_(low, 1)
        .iter()
        .zip(low.iter())
        .map(|(pl, l)| pl - l)
        .collect::<Vec<f64>>();

    let dmp = sum(
        &hd.iter()
            .zip(ld.iter())
            .map(|(h, l)| if *h > 0.0 && h > l { *h } else { 0.0 })
            .collect::<Vec<f64>>(),
        m1,
    );
    let dmm = sum(
        &ld.iter()
            .zip(hd.iter())
            .map(|(l, h)| if *l > 0.0 && l > h { *l } else { 0.0 })
            .collect::<Vec<f64>>(),
        m1,
    );

    let pdi: Vec<f64> = dmp
        .iter()
        .zip(tr.iter())
        .map(|(d, t)| if *t == 0.0 { 0.0 } else { d / t * 100.0 })
        .collect();
    let mdi: Vec<f64> = dmm
        .iter()
        .zip(tr.iter())
        .map(|(d, t)| if *t == 0.0 { 0.0 } else { d / t * 100.0 })
        .collect();

    let adx = ma(
        &pdi
            .iter()
            .zip(mdi.iter())
            .map(|(p, m)| if p + m == 0.0 { 0.0 } else { (m - p).abs() / (p + m) * 100.0 })
            .collect::<Vec<f64>>(),
        m2,
    );
    let adxr = adx
        .iter()
        .zip(ref_(&adx, m2).iter())
        .map(|(a, ra)| (a + ra) / 2.0)
        .collect();

    (pdi, mdi, adx, adxr)
}

/// 唐安奇通道
pub fn taq(high: &[f64], low: &[f64], n: usize) -> (Vec<f64>, Vec<f64>, Vec<f64>) {
    let up = hhv(high, n);
    let down = llv(low, n);
    let mid: Vec<f64> = up.iter().zip(down.iter()).map(|(u, d)| (u + d) / 2.0).collect();
    (up, mid, down)
}

/// 肯特纳交易通道
pub fn ktn(close: &[f64], high: &[f64], low: &[f64], n: usize, m: usize) -> (Vec<f64>, Vec<f64>, Vec<f64>) {
    let tp: Vec<f64> = high
        .iter()
        .zip(low.iter().zip(close.iter()))
        .map(|(h, (l, c))| (h + l + c) / 3.0)
        .collect();
    let mid = ema(&tp, n);
    let atr_n = atr(close, high, low, m);
    let upper: Vec<f64> = mid.iter().zip(atr_n.iter()).map(|(m, a)| m + 2.0 * a).collect();
    let lower: Vec<f64> = mid.iter().zip(atr_n.iter()).map(|(m, a)| m - 2.0 * a).collect();
    (upper, mid, lower)
}

/// TRIX三重指数平滑平均线
pub fn trix(close: &[f64], m1: usize, m2: usize) -> (Vec<f64>, Vec<f64>) {
    let tr1 = ema(close, m1);
    let tr2 = ema(&tr1, m1);
    let tr3 = ema(&tr2, m1);
    let trix: Vec<f64> = tr3
        .iter()
        .zip(ref_(&tr3, 1).iter())
        .map(|(t, rt)| if *rt == 0.0 { 0.0 } else { (t - rt) / rt * 100.0 })
        .collect();
    let trma = ma(&trix, m2);
    (trix, trma)
}

/// VR容量比率
pub fn vr(close: &[f64], vol: &[f64], m1: usize) -> Vec<f64> {
    let lc = ref_(close, 1);
    let vol_pos: Vec<f64> = close
        .iter()
        .zip(lc.iter().zip(vol.iter()))
        .map(|(c, (l, v))| if c > l { *v } else { 0.0 })
        .collect();
    let vol_neg: Vec<f64> = close
        .iter()
        .zip(lc.iter().zip(vol.iter()))
        .map(|(c, (l, v))| if c <= l { *v } else { 0.0 })
        .collect();

    let sum_pos = sum(&vol_pos, m1);
    let sum_neg = sum(&vol_neg, m1);

    sum_pos
        .iter()
        .zip(sum_neg.iter())
        .map(|(p, n)| if *n == 0.0 { 100.0 } else { p / n * 100.0 })
        .collect()
}

/// CR价格动量指标
pub fn cr(close: &[f64], high: &[f64], low: &[f64], n: usize) -> Vec<f64> {
    let mid = ref_(high, 1)
        .iter()
        .zip(low.iter().zip(close.iter()))
        .map(|(h, (l, c))| (h + l + c) / 3.0)
        .collect::<Vec<f64>>();

    let h_mid: Vec<f64> = high.iter().zip(mid.iter()).map(|(h, m)| h - m).collect();
    let m_l: Vec<f64> = mid.iter().zip(low.iter()).map(|(m, l)| m - l).collect();

    let sum_h = sum(
        &h_mid.iter().map(|x| if *x > 0.0 { *x } else { 0.0 }).collect::<Vec<f64>>(),
        n,
    );
    let sum_l = sum(
        &m_l.iter().map(|x| if *x > 0.0 { *x } else { 0.0 }).collect::<Vec<f64>>(),
        n,
    );

    sum_h
        .iter()
        .zip(sum_l.iter())
        .map(|(h, l)| if *l == 0.0 { 100.0 } else { h / l * 100.0 })
        .collect()
}

/// EMV简易波动指标
pub fn emv(high: &[f64], low: &[f64], vol: &[f64], n: usize, m: usize) -> (Vec<f64>, Vec<f64>) {
    let vol_ma = ma(vol, n);
    let volume: Vec<f64> = vol_ma
        .iter()
        .zip(vol.iter())
        .map(|(m, v)| if *v == 0.0 { 0.0 } else { m / v })
        .collect();

    let mid = high
        .iter()
        .zip(low.iter().zip(ref_(&high.iter().zip(low.iter()).map(|(h, l)| h + l).collect::<Vec<f64>>(), 1).iter()))
        .map(|(h, (l, pm))| 100.0 * (h + l - pm) / (h + l))
        .collect::<Vec<f64>>();

    let hl_ma = ma(
        &high.iter().zip(low.iter()).map(|(h, l)| h - l).collect::<Vec<f64>>(),
        n,
    );

    let emv: Vec<f64> = volume
        .iter()
        .zip(mid.iter().zip(hl_ma.iter()))
        .map(|(v, (m, hl))| {
            if *hl == 0.0 {
                0.0
            } else {
                m * v * (m - m) / hl
            }
        })
        .collect();

    let ma_emv = ma(&emv, m);
    (emv, ma_emv)
}

/// DPO区间震荡线
pub fn dpo(close: &[f64], m1: usize, m2: usize, m3: usize) -> (Vec<f64>, Vec<f64>) {
    let ma_m1 = ma(close, m1);
    let dpo_val: Vec<f64> = close
        .iter()
        .zip(ref_(&ma_m1, m2).iter())
        .map(|(c, m)| c - m)
        .collect();
    let madpo = ma(&dpo_val, m3);
    (dpo_val, madpo)
}

/// BRAR情绪指标
pub fn brar(open: &[f64], close: &[f64], high: &[f64], low: &[f64], m1: usize) -> (Vec<f64>, Vec<f64>) {
    let ar: Vec<f64> = {
        let h_o: Vec<f64> = high.iter().zip(open.iter()).map(|(h, o)| h - o).collect();
        let o_l: Vec<f64> = open.iter().zip(low.iter()).map(|(o, l)| o - l).collect();
        let sum_h_o = sum(&h_o, m1);
        let sum_o_l = sum(&o_l, m1);
        sum_h_o
            .iter()
            .zip(sum_o_l.iter())
            .map(|(h, l)| if *l == 0.0 { 100.0 } else { h / l * 100.0 })
            .collect()
    };

    let br: Vec<f64> = {
        let h_pc: Vec<f64> = high
            .iter()
            .zip(ref_(close, 1).iter())
            .map(|(h, pc)| if h - pc > 0.0 { h - pc } else { 0.0 })
            .collect();
        let pc_l: Vec<f64> = ref_(close, 1)
            .iter()
            .zip(low.iter())
            .map(|(pc, l)| if pc - l > 0.0 { pc - l } else { 0.0 })
            .collect();
        let sum_h_pc = sum(&h_pc, m1);
        let sum_pc_l = sum(&pc_l, m1);
        sum_h_pc
            .iter()
            .zip(sum_pc_l.iter())
            .map(|(h, l)| if *l == 0.0 { 100.0 } else { h / l * 100.0 })
            .collect()
    };

    (ar, br)
}

/// DFMA平行线差指标
pub fn dfma(close: &[f64], n1: usize, n2: usize, m: usize) -> (Vec<f64>, Vec<f64>) {
    let dif: Vec<f64> = ma(close, n1)
        .iter()
        .zip(ma(close, n2).iter())
        .map(|(a, b)| a - b)
        .collect();
    let difma = ma(&dif, m);
    (dif, difma)
}

/// MTM动量指标
pub fn mtm(close: &[f64], n: usize, m: usize) -> (Vec<f64>, Vec<f64>) {
    let mtm_val: Vec<f64> = close
        .iter()
        .zip(ref_(close, n).iter())
        .map(|(c, rc)| c - rc)
        .collect();
    let mtmma = ma(&mtm_val, m);
    (mtm_val, mtmma)
}

/// MASS梅斯线
pub fn mass(high: &[f64], low: &[f64], n1: usize, n2: usize, m: usize) -> (Vec<f64>, Vec<f64>) {
    let hl = high.iter().zip(low.iter()).map(|(h, l)| h - l).collect::<Vec<f64>>();
    let ma1 = ma(&hl, n1);
    let ma_ma1 = ma(&ma1, n1);
    let mass_val: Vec<f64> = sum(
        &ma1.iter()
            .zip(ma_ma1.iter())
            .map(|(a, b)| if *b == 0.0 { 0.0 } else { a / b })
            .collect::<Vec<f64>>(),
        n2,
    );
    let ma_mass = ma(&mass_val, m);
    (mass_val, ma_mass)
}

/// ROC变动率指标
pub fn roc(close: &[f64], n: usize, m: usize) -> (Vec<f64>, Vec<f64>) {
    let roc_val: Vec<f64> = close
        .iter()
        .zip(ref_(close, n).iter())
        .map(|(c, rc)| {
            if *rc == 0.0 {
                0.0
            } else {
                (c - rc) / rc * 100.0
            }
        })
        .collect();
    let maroc = ma(&roc_val, m);
    (roc_val, maroc)
}

/// EXPMA指数平均数
pub fn expma(close: &[f64], n1: usize, n2: usize) -> (Vec<f64>, Vec<f64>) {
    (ema(close, n1), ema(close, n2))
}

/// OBV能量潮
pub fn obv(close: &[f64], vol: &[f64]) -> Vec<f64> {
    let mut result = Vec::with_capacity(close.len());
    let mut obv_val = 0.0;

    for i in 0..close.len() {
        if i == 0 {
            result.push(vol[i] / 10000.0);
        } else {
            if close[i] > close[i - 1] {
                obv_val += vol[i];
            } else if close[i] < close[i - 1] {
                obv_val -= vol[i];
            }
            result.push(obv_val / 10000.0);
        }
    }
    result
}

/// MFI资金流量指标
pub fn mfi(close: &[f64], high: &[f64], low: &[f64], vol: &[f64], n: usize) -> Vec<f64> {
    let typ: Vec<f64> = high
        .iter()
        .zip(low.iter().zip(close.iter()))
        .map(|(h, (l, c))| (h + l + c) / 3.0)
        .collect();
    let typ_ref = ref_(&typ, 1);

    let pos: Vec<f64> = typ
        .iter()
        .zip(typ_ref.iter().zip(vol.iter()))
        .map(|(t, (pt, v))| if t > pt { t * v } else { 0.0 })
        .collect();
    let neg: Vec<f64> = typ
        .iter()
        .zip(typ_ref.iter().zip(vol.iter()))
        .map(|(t, (pt, v))| if t < pt { t * v } else { 0.0 })
        .collect();

    let sum_pos = sum(&pos, n);
    let sum_neg = sum(&neg, n);

    sum_pos
        .iter()
        .zip(sum_neg.iter())
        .map(|(p, n)| {
            if *n == 0.0 {
                100.0
            } else {
                let v1 = p / n;
                100.0 - 100.0 / (1.0 + v1)
            }
        })
        .collect()
}

/// ASI振动升降指标
#[allow(clippy::many_single_char_names)]
pub fn asi(
    open: &[f64],
    close: &[f64],
    high: &[f64],
    low: &[f64],
    m1: usize,
    m2: usize,
) -> (Vec<f64>, Vec<f64>) {
    let lc = ref_(close, 1);
    let aa: Vec<f64> = high.iter().zip(lc.iter()).map(|(h, l)| (h - l).abs()).collect();
    let bb: Vec<f64> = low.iter().zip(lc.iter()).map(|(l, lc_val)| (l - lc_val).abs()).collect();
    let cc: Vec<f64> = high
        .iter()
        .zip(ref_(low, 1).iter())
        .map(|(h, pl)| (h - pl).abs())
        .collect();
    let dd: Vec<f64> = lc
        .iter()
        .zip(ref_(open, 1).iter())
        .map(|(lc_val, po)| (lc_val - po).abs())
        .collect();

    let r: Vec<f64> = aa
        .iter()
        .zip(bb.iter().zip(cc.iter().zip(dd.iter())))
        .map(|(a_val, (b_val, (c_val, d_val)))| {
            if a_val > b_val && a_val > c_val {
                a_val + b_val / 2.0 + d_val / 4.0
            } else if b_val > c_val && b_val > a_val {
                b_val + a_val / 2.0 + d_val / 4.0
            } else {
                c_val + d_val / 4.0
            }
        })
        .collect();

    let x: Vec<f64> = close
        .iter()
        .zip(lc.iter().zip(open.iter().zip(ref_(open, 1).iter())))
        .map(|(c, (lc_val, (o, po)))| c - lc_val + (c - o) / 2.0 + lc_val - po)
        .collect();

    let si: Vec<f64> = x
        .iter()
        .zip(r.iter().zip(high.iter().zip(low.iter())))
        .map(|(x_val, (r_val, (_h_val, _l_val)))| {
            let max_ab = aa.iter().zip(bb.iter()).map(|(a_val, b_val)| a_val.max(*b_val)).fold(0.0_f64, |acc, x| acc.max(x));
            if *r_val == 0.0 {
                0.0
            } else {
                16.0 * x_val / r_val * max_ab
            }
        })
        .collect();

    let asi = sum(&si, m1);
    let asit = ma(&asi, m2);
    (asi, asit)
}

/// XSII薛斯通道II
pub fn xsii(close: &[f64], high: &[f64], low: &[f64], n: usize, m: usize) -> (Vec<f64>, Vec<f64>, Vec<f64>, Vec<f64>) {
    let tp = high.iter().zip(low.iter().zip(close.iter())).map(|(h, (l, c))| (2.0 * c + h + l) / 4.0).collect::<Vec<f64>>();
    let aa = ma(&tp, 5);
    let td1: Vec<f64> = aa.iter().map(|a| a * n as f64 / 100.0).collect();
    let td2: Vec<f64> = aa.iter().map(|a| a * (200 - n) as f64 / 100.0).collect();

    let cc: Vec<f64> = close.iter().zip(ma(close, 20).iter()).map(|(c, m20)| {
        if *m20 == 0.0 { 0.0 } else { ((2.0 * c + high.iter().find(|_| true).unwrap_or(c) + low.iter().find(|_| true).unwrap_or(c)) / 4.0 - m20).abs() / m20 }
    }).collect();

    let dd = dma(close, &cc);
    let td3: Vec<f64> = dd.iter().map(|d| d * (1.0 + m as f64 / 100.0)).collect();
    let td4: Vec<f64> = dd.iter().map(|d| d * (1.0 - m as f64 / 100.0)).collect();

    (td1, td2, td3, td4)
}

/// SumBars函数 - 将X向前累加直到大于等于A
pub fn sumbars(x: &[f64], a: &[f64]) -> Vec<i32> {
    let len = x.len().min(a.len());
    let mut result = vec![0; len];

    // 倒转输入
    let mut x_rev = x[..len].to_vec();
    x_rev.reverse();
    let mut a_rev = a[..len].to_vec();
    a_rev.reverse();

    // 计算累加和
    let mut sigma: Vec<f64> = vec![0.0; len + 1];
    for i in 0..len {
        sigma[i + 1] = sigma[i] + x_rev[i];
    }

    for i in 0..len {
        let target = a_rev[i] + sigma[i];
        // 二分查找
        let mut low = i + 1;
        let mut high = len;
        while low < high {
            let mid = (low + high) / 2;
            if sigma[mid] < target {
                low = mid + 1;
            } else {
                high = mid;
            }
        }
        if low < len - i {
            result[len - i - 1] = (low + 1) as i32;
        }
    }
    result
}

/// SAR抛物转向
pub fn sar(high: &[f64], low: &[f64], n: usize, s: usize, m: usize) -> Vec<f64> {
    if high.len() < n || low.len() < n {
        return vec![];
    }
    let f_step = s as f64 / 100.0;
    let f_max = m as f64 / 100.0;
    let len = high.len();
    let mut result = vec![f64::NAN; len];
    let mut af = f_step;
    let mut is_long = high[n - 1] > high[n - 2];
    let mut b_first = true;

    let s_hhv = ref_(&hhv(high, n), 1);
    let s_llv = ref_(&llv(low, n), 1);

    for i in n..len {
        if b_first {
            af = f_step;
            result[i] = if is_long { s_llv[i] } else { s_hhv[i] };
            b_first = false;
        } else {
            let ep = if is_long { s_hhv[i] } else { s_llv[i] };
            if (is_long && high[i] > ep) || (!is_long && low[i] < ep) {
                af = (af + f_step).min(f_max);
            }
            result[i] = result[i - 1] + af * (ep - result[i - 1]);
        }

        if (is_long && low[i] < result[i]) || (!is_long && high[i] > result[i]) {
            is_long = !is_long;
            b_first = true;
        }
    }
    result
}

/// 通达信SAR算法
pub fn tdx_sar(high: &[f64], low: &[f64], iaf_step: usize, iaf_limit: usize) -> Vec<f64> {
    if high.is_empty() || low.is_empty() {
        return vec![];
    }
    let af_step = iaf_step as f64 / 100.0;
    let af_limit = iaf_limit as f64 / 100.0;
    let len = high.len();
    let mut result = vec![0.0; len];
    let mut bull = true;
    let mut af = af_step;
    let mut ep = high[0];
    result[0] = low[0];

    for i in 1..len {
        if bull {
            if high[i] > ep {
                ep = high[i];
                af = (af + af_step).min(af_limit);
            }
        } else {
            if low[i] < ep {
                ep = low[i];
                af = (af + af_step).min(af_limit);
            }
        }
        result[i] = result[i - 1] + af * (ep - result[i - 1]);

        if bull {
            result[i] = result[i - 1].max(result[i].min(low[i]).min(low[i - 1]));
        } else {
            result[i] = result[i - 1].min(result[i].max(high[i]).max(high[i - 1]));
        }

        if bull {
            if low[i] < result[i] {
                bull = false;
                let tmp_sar = ep;
                ep = low[i];
                af = af_step;
                result[i] = if high[i - 1] == tmp_sar {
                    tmp_sar
                } else {
                    tmp_sar + af * (ep - tmp_sar)
                };
            }
        } else {
            if high[i] > result[i] {
                bull = true;
                ep = high[i];
                af = af_step;
                result[i] = low[i].min(low[i - 1]);
            }
        }
    }
    result
}
