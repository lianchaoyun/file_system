//! 寻优工作器
//! 后台定时轮询队列，处理寻优任务

use crate::seek::opt_data::OptTaskData;
use crate::seek::opt_queue::{OptQueueItem, OptQueueManager};
use crate::seek::tdx_data::{AdjType, TdxDataProvider};
use crate::seek::strategy_opt::run_opt_with_progress;
use crate::{log, err};
use std::sync::Arc;
use std::sync::atomic::{AtomicBool, Ordering};
use tokio::time::{interval, Duration};

pub struct OptWorker {
    queue: Arc<OptQueueManager>,
}

impl OptWorker {
    pub fn new(queue: Arc<OptQueueManager>) -> Self {
        Self { queue }
    }

    /// 启动工作器主循环（支持停止信号）
    pub async fn run_with_stop(&self, stop_flag: Arc<AtomicBool>) {
        //println!("[OptWorker] 寻优工作器启动，每 1 秒检查队列...");

        let mut ticker = interval(Duration::from_secs(1));

        loop {
            // 检查停止信号
            if stop_flag.load(Ordering::SeqCst) {
                log!("[OptWorker] 收到停止信号，退出循环");
                break;
            }

            tokio::select! {
                _ = ticker.tick() => {
                    // 检查当前是否有任务在运行
                    if let Ok(running) = self.queue.is_running().await {
                        if running {
                            continue;
                        }
                    } else {
                        continue;
                    }

                    // 尝试从队列获取任务
                    match self.queue.pop().await {
                        Ok(Some(item)) => {
                            self.process_task(item).await;
                        }
                        Ok(None) => {
                            // 队列为空，跳过
                        }
                        Err(e) => {
                            err!("[OptWorker] 获取任务失败: {}", e);
                        }
                    }
                }
            }
        }
    }

    /// 启动工作器主循环（永不停止，用于独立进程）
    pub async fn run(&self) {
        let never_stop = Arc::new(AtomicBool::new(false));
        self.run_with_stop(never_stop).await;
    }

    /// 处理单个寻优任务
    async fn process_task(&self, item: OptQueueItem) {
        let start_time = std::time::Instant::now();
        log!("[OptWorker] 开始处理任务: task_id={}, symbol={}", item.task_id, item.symbol);

        // 初始化任务状态
        let mut task = OptTaskData {
            task_id: item.task_id.clone(),
            status: "running".to_string(),
            progress: 0.0,
            total: item.max_combinations,
            processed: 0,
            error: None,
            results: vec![],
        };

        // 更新状态：开始
        let _ = self.queue.update_task(&task).await;

        // 获取 K 线数据
        let data_provider = TdxDataProvider::new();
        let adj = match item.adj_type.as_str() {
            "forward" => AdjType::Forward,
            "backward" => AdjType::Backward,
            _ => AdjType::None,
        };

        let kline = match data_provider.get_kline(&item.symbol, adj, Some(1000)) {
            Ok(k) => k,
            Err(e) => {
                task.status = "error".to_string();
                task.error = Some(format!("获取K线失败: {}", e));
                let _ = self.queue.update_task(&task).await;
                let _ = self.queue.add_to_history(&item.task_id).await;
                return;
            }
        };

        if kline.len() < 65 {
            task.status = "error".to_string();
            task.error = Some("K线数据不足".to_string());
            let _ = self.queue.update_task(&task).await;
            let _ = self.queue.add_to_history(&item.task_id).await;
            return;
        }

        // 在单独线程中运行寻优（带进度回调）
        let kline_clone = kline.clone();
        let (progress_tx, progress_rx) = std::sync::mpsc::channel::<(usize, usize)>();
        let (result_tx, mut result_rx) = tokio::sync::mpsc::channel::<Vec<crate::seek::strategy_opt::OptimizationResult>>(1);
        let total_combinations = item.max_combinations;
        let task_id_for_progress = item.task_id.clone();
        std::thread::spawn(move || {
            let results = run_opt_with_progress(
                &kline_clone,
                total_combinations,
                |current, total| {
                    let _ = progress_tx.send((current, total));
                },
            );
            // 新线程不在 tokio runtime 中，需要创建临时 runtime 来发送
            let rt = tokio::runtime::Runtime::new().unwrap();
            rt.block_on(async {
                let _ = result_tx.send(results).await;
            });
        });

        // 异步等待结果，同时轮询处理进度更新
        let queue_for_progress = self.queue.clone();
        let task_id_for_progress = task_id_for_progress.clone();
        let mut opt_results: Option<Vec<crate::seek::strategy_opt::OptimizationResult>> = None;
        let mut last_progress = 0.0; // 记录上次的进度，防止减少

        loop {
            tokio::select! {
                // 优先检查结果
                result = result_rx.recv() => {
                    if let Some(r) = result {
                        opt_results = Some(r);
                    }
                    break;
                }
                // 定时检查进度
                _ = tokio::time::sleep(Duration::from_millis(100)) => {
                    if let Ok((current, total)) = progress_rx.try_recv() {
                        if let Ok(mut t) = queue_for_progress.get_task(&task_id_for_progress).await {
                            if t.status == "running" {
                                // 只更新进度，不减少
                                let new_progress = (current as f64 / total as f64 * 75.0).min(75.0);
                                if new_progress > last_progress {
                                    last_progress = new_progress;
                                    t.processed = current;
                                    t.progress = new_progress;
                                    let _ = queue_for_progress.update_task(&t).await;
                                }
                            }
                        }
                    }
                }
            }
        }

        let results = opt_results.unwrap_or_default();
        let total = results.len();
        let processed_total = item.max_combinations;

        // 更新进度到 80%
        task.progress = 80.0;
        task.processed = processed_total;
        let _ = self.queue.update_task(&task).await;

        // 取 Top4 + 中间3 + 尾部3
        let mut selected = Vec::new();
        for r in results.iter().take(4) { selected.push(r); }
        if total >= 7 {
            let mid = total / 2;
            selected.push(&results[mid - 1]);
            selected.push(&results[mid]);
            selected.push(&results[mid + 1]);
        }
        if total >= 10 {
            for r in results.iter().rev().take(3) { selected.push(r); }
        }

        // 转换为 JSON
        let json_results: Vec<serde_json::Value> = selected.iter().enumerate().map(|(i, &r)| {
            let rank_type = if i < 4 { "top" } else if i < 7 { "mid" } else { "tail" };
            let rank = if i < 4 { i + 1 } else if i < 7 { i - 3 } else { i - 6 };

            let mut params = serde_json::Map::new();
            params.insert("ma_fast".into(), serde_json::json!(r.params.ma_fast));
            params.insert("ma_slow".into(), serde_json::json!(r.params.ma_slow));
            params.insert("ma_slope_period".into(), serde_json::json!(r.params.ma_slope_period));
            params.insert("macd_short".into(), serde_json::json!(r.params.macd_short));
            params.insert("macd_long".into(), serde_json::json!(r.params.macd_long));
            params.insert("macd_signal".into(), serde_json::json!(r.params.macd_signal));
            params.insert("obv_ma_period".into(), serde_json::json!(r.params.obv_ma_period));
            params.insert("breakout_days".into(), serde_json::json!(r.params.breakout_days));
            params.insert("up_streak_window".into(), serde_json::json!(r.params.up_streak_window));
            params.insert("up_streak_days".into(), serde_json::json!(r.params.up_streak_days));
            params.insert("down_streak_window".into(), serde_json::json!(r.params.down_streak_window));
            params.insert("down_streak_days".into(), serde_json::json!(r.params.down_streak_days));
            params.insert("increase_rate".into(), serde_json::json!(r.params.increase_rate));
            params.insert("decrease_rate".into(), serde_json::json!(r.params.decrease_rate));
            params.insert("weight_up".into(), serde_json::json!(r.params.weight_up));
            params.insert("weight_down".into(), serde_json::json!(r.params.weight_down));
            params.insert("buy_1".into(), serde_json::json!(r.params.buy_1));
            params.insert("buy_2".into(), serde_json::json!(r.params.buy_2));
            params.insert("buy_3".into(), serde_json::json!(r.params.buy_3));
            params.insert("buy_4".into(), serde_json::json!(r.params.buy_4));
            params.insert("buy_5".into(), serde_json::json!(r.params.buy_5));
            params.insert("buy_6".into(), serde_json::json!(r.params.buy_6));
            params.insert("buy_7".into(), serde_json::json!(r.params.buy_7));
            params.insert("buy_8".into(), serde_json::json!(r.params.buy_8));
            params.insert("buy_9".into(), serde_json::json!(r.params.buy_9));
            params.insert("buy_10".into(), serde_json::json!(r.params.buy_10));
            params.insert("buy_11".into(), serde_json::json!(r.params.buy_11));
            params.insert("sell_1".into(), serde_json::json!(r.params.sell_1));
            params.insert("sell_2".into(), serde_json::json!(r.params.sell_2));
            params.insert("sell_3".into(), serde_json::json!(r.params.sell_3));
            params.insert("sell_4".into(), serde_json::json!(r.params.sell_4));
            params.insert("sell_5".into(), serde_json::json!(r.params.sell_5));
            params.insert("sell_6".into(), serde_json::json!(r.params.sell_6));
            params.insert("sell_7".into(), serde_json::json!(r.params.sell_7));
            params.insert("sell_8".into(), serde_json::json!(r.params.sell_8));
            params.insert("sell_9".into(), serde_json::json!(r.params.sell_9));
            params.insert("sell_10".into(), serde_json::json!(r.params.sell_10));
            params.insert("sell_11".into(), serde_json::json!(r.params.sell_11));

            serde_json::json!({
                "rank_type": rank_type,
                "rank": rank,
                "sharpe": r.sharpe,
                "ann_ret": r.performance.ann_ret_pct,
                "max_dd": r.performance.max_dd_pct,
                "trade_count": r.performance.trade_count,
                "params": params,
            })
        }).collect();

        // 保存完成结果
        task.status = "completed".to_string();
        task.progress = 100.0;
        task.results = json_results;
        let _ = self.queue.update_task(&task).await;
        let _ = self.queue.add_to_history(&item.task_id).await;

        log!("[OptWorker] 任务完成: task_id={}, 处理={}, 结果数={}, 耗时={:.2}s",
                 item.task_id, processed_total, selected.len(), start_time.elapsed().as_secs_f64());
    }
}
