//! 回测引擎模块
//! 参考 quant_backtest.py 实现
use std::time::{SystemTime, UNIX_EPOCH};
use crate::seek::my_tt::{KlineData, sma, macd, obv, hhv, llv, prev, sum_cond, slope};
use crate::seek::tdx_data::TdxDayData;
use crate::log;
use rayon::iter::{ParallelIterator, IntoParallelRefIterator, IndexedParallelIterator};

// ==================== 配置结构 ====================

#[derive(Clone, Default)]
pub struct YunStrategy {
    pub initial_cash: f64,
    pub ma_fast: usize,
    pub ma_slow: usize,
    pub macd_short: usize,
    pub macd_long: usize,
    pub macd_signal: usize,
    pub obv_ma_period: usize,
    pub breakout_days: usize,
    pub ma_slope_period: usize,
    pub up_streak_window: usize,
    pub up_streak_days: usize,
    pub down_streak_window: usize,
    pub down_streak_days: usize,
    pub increase_rate: f64,
    pub decrease_rate: f64,
    pub weight_up: f64,
    pub weight_down: f64,
    // 各信号权重 (0=不使用, 1=普通权重, 2=双倍权重, 3=三倍权重)
    pub buy_1: usize,
    pub buy_2: usize,
    pub buy_3: usize,
    pub buy_4: usize,
    pub buy_5: usize,
    pub buy_6: usize,
    pub buy_7: usize,
    pub buy_8: usize,
    pub buy_9: usize,
    pub buy_10: usize,
    pub buy_11: usize,
    pub sell_1: usize,
    pub sell_2: usize,
    pub sell_3: usize,
    pub sell_4: usize,
    pub sell_5: usize,
    pub sell_6: usize,
    pub sell_7: usize,
    pub sell_8: usize,
    pub sell_9: usize,
    pub sell_10: usize,
    pub sell_11: usize,
}

impl YunStrategy {
    pub fn default_strategy() -> Self {
        Self {
            initial_cash: 100000.0,
            ma_fast: 20,
            ma_slow: 60,
            macd_short: 12,
            macd_long: 26,
            macd_signal: 9,
            obv_ma_period: 30,
            breakout_days: 3,
            ma_slope_period: 10,
            up_streak_window: 5,
            up_streak_days: 3,
            down_streak_window: 5,
            down_streak_days: 3,
            increase_rate: 0.8,
            decrease_rate: 0.8,
            weight_up: 0.8,
            weight_down: 0.8,
            // 默认权重: 全部设为1
            buy_1: 1,
            buy_2: 1,
            buy_3: 1,
            buy_4: 1,
            buy_5: 1,
            buy_6: 1,
            buy_7: 1,
            buy_8: 1,
            buy_9: 1,
            buy_10: 1,
            buy_11: 1,
            sell_1: 1,
            sell_2: 1,
            sell_3: 1,
            sell_4: 1,
            sell_5: 1,
            sell_6: 1,
            sell_7: 1,
            sell_8: 1,
            sell_9: 1,
            sell_10: 1,
            sell_11: 1,
        }
    }
}

/// 回测结果
#[derive(Debug, Clone, Default)]
pub struct BacktestResult {
    pub sharpe: f64,
    pub ann_ret_pct: f64,
    pub max_dd_pct: f64,
    pub trade_count: i32,
    /// 买卖标记: 1=买入, -1=卖出, 0=无操作
    pub signals: Vec<i32>,
    /// 资产曲线 (每日净值)
    pub equity: Vec<f64>,
}

// ==================== 辅助函数 ====================

/// 判断条件为真返回1.0，否则0.0
fn if_true(cond: bool) -> f64 {
    if cond { 1.0 } else { 0.0 }
}

/// 将布尔数组转为 0/1 数组
fn bool_to_f64(arr: &[bool]) -> Vec<f64> {
    arr.iter().map(|&b| if_true(b)).collect()
}

// ==================== 买入信号 1-11 (参考 Python Plugins) ====================

/// 1.快线 > 慢线
fn buy_1(close: &[f64], cfg: &YunStrategy) -> Vec<f64> {
    let ma_f = sma(close, cfg.ma_fast);
    let ma_s = sma(close, cfg.ma_slow);
    bool_to_f64(&ma_f.iter().zip(ma_s.iter()).map(|(f, s)| !f.is_nan() && !s.is_nan() && *f > *s).collect::<Vec<_>>())
}

/// 2.dif > dea
fn buy_2(close: &[f64], cfg: &YunStrategy) -> Vec<f64> {
    let (dif, dea, _) = macd(close, cfg.macd_short, cfg.macd_long, cfg.macd_signal);
    bool_to_f64(&dif.iter().zip(dea.iter()).map(|(d, e)| !d.is_nan() && !e.is_nan() && *d > *e).collect::<Vec<_>>())
}

/// 3.obv > MA(obv)
fn buy_3(close: &[f64], vol: &[f64], cfg: &YunStrategy) -> Vec<f64> {
    let obv_val = obv(close, vol);
    let obv_ma = sma(&obv_val, cfg.obv_ma_period);
    bool_to_f64(&obv_val.iter().zip(obv_ma.iter()).map(|(o, m)| !o.is_nan() && !m.is_nan() && *o > *m).collect::<Vec<_>>())
}

/// 4.close > open
fn buy_4(close: &[f64], open: &[f64]) -> Vec<f64> {
    bool_to_f64(&close.iter().zip(open.iter()).map(|(c, o)| *c > *o).collect::<Vec<_>>())
}

/// 5.n天阳线数
fn buy_5(close: &[f64], open: &[f64], cfg: &YunStrategy) -> Vec<f64> {
    let cond: Vec<bool> = close.iter().zip(open.iter()).map(|(c, o)| *c > *o).collect();
    let sum_arr = sum_cond(&cond, cfg.up_streak_window);
    cond.iter().zip(sum_arr.iter()).map(|(c, s)| {
        if_true(*c && !s.is_nan() && *s >= cfg.up_streak_days as f64)
    }).collect()
}

/// 6.创n天新高
fn buy_6(high: &[f64], close: &[f64], open: &[f64], cfg: &YunStrategy) -> Vec<f64> {
    let hhv_n = hhv(high, cfg.breakout_days);
    let ref_hhv_1 = prev(&hhv_n, 1);
    let ref_hhv_2 = prev(&hhv_n, 2);
    let ref_close_1 = prev(close, 1);
    let ref_open_1 = prev(open, 1);

    let n = high.len();
    let mut result = vec![0.0; n];
    for i in 1..n {
        let break_u1 = high[i] > ref_hhv_1[i];
        let break_u2 = ref_close_1[i] < ref_open_1[i] && high[i] > ref_hhv_2[i] && close[i] > open[i];
        result[i] = if_true(break_u1 || break_u2);
    }
    result
}

/// 7.上涨x%
fn buy_7(close: &[f64], open: &[f64], cfg: &YunStrategy) -> Vec<f64> {
    bool_to_f64(&close.iter().zip(open.iter()).map(|(c, o)| {
        !o.is_nan() && *o > 0.0 && (*c - *o) / *o * 100.0 > cfg.increase_rate
    }).collect::<Vec<_>>())
}

/// 8.close > MA(close)快线
fn buy_8(close: &[f64], cfg: &YunStrategy) -> Vec<f64> {
    let ma = sma(close, cfg.ma_fast);
    bool_to_f64(&close.iter().zip(ma.iter()).map(|(c, m)| !c.is_nan() && !m.is_nan() && *c > *m).collect::<Vec<_>>())
}

/// 9.close > MA(close)慢线
fn buy_9(close: &[f64], cfg: &YunStrategy) -> Vec<f64> {
    let ma = sma(close, cfg.ma_slow);
    bool_to_f64(&close.iter().zip(ma.iter()).map(|(c, m)| !c.is_nan() && !m.is_nan() && *c > *m).collect::<Vec<_>>())
}

/// 10.斜率向上快线
fn buy_10(close: &[f64], cfg: &YunStrategy) -> Vec<f64> {
    let ma = sma(close, cfg.ma_fast);
    let slope_val = slope(&ma, cfg.ma_slope_period);
    bool_to_f64(&slope_val.iter().map(|s| !s.is_nan() && *s > 0.0).collect::<Vec<_>>())
}

/// 11.斜率向上慢线
fn buy_11(close: &[f64], cfg: &YunStrategy) -> Vec<f64> {
    let ma = sma(close, cfg.ma_slow);
    let slope_val = slope(&ma, cfg.ma_slope_period);
    bool_to_f64(&slope_val.iter().map(|s| !s.is_nan() && *s > 0.0).collect::<Vec<_>>())
}

// ==================== 卖出信号 1-11 ====================

/// 1.快线 < 慢线
fn sell_1(close: &[f64], cfg: &YunStrategy) -> Vec<f64> {
    let ma_f = sma(close, cfg.ma_fast);
    let ma_s = sma(close, cfg.ma_slow);
    bool_to_f64(&ma_f.iter().zip(ma_s.iter()).map(|(f, s)| !f.is_nan() && !s.is_nan() && *f < *s).collect::<Vec<_>>())
}

/// 2.dif < dea
fn sell_2(close: &[f64], cfg: &YunStrategy) -> Vec<f64> {
    let (dif, dea, _) = macd(close, cfg.macd_short, cfg.macd_long, cfg.macd_signal);
    bool_to_f64(&dif.iter().zip(dea.iter()).map(|(d, e)| !d.is_nan() && !e.is_nan() && *d < *e).collect::<Vec<_>>())
}

/// 3.obv < MA(obv)
fn sell_3(close: &[f64], vol: &[f64], cfg: &YunStrategy) -> Vec<f64> {
    let obv_val = obv(close, vol);
    let obv_ma = sma(&obv_val, cfg.obv_ma_period);
    bool_to_f64(&obv_val.iter().zip(obv_ma.iter()).map(|(o, m)| !o.is_nan() && !m.is_nan() && *o < *m).collect::<Vec<_>>())
}

/// 4.close < open
fn sell_4(close: &[f64], open: &[f64]) -> Vec<f64> {
    bool_to_f64(&close.iter().zip(open.iter()).map(|(c, o)| *c < *o).collect::<Vec<_>>())
}

/// 5.n天阴线数
fn sell_5(close: &[f64], open: &[f64], cfg: &YunStrategy) -> Vec<f64> {
    let cond: Vec<bool> = close.iter().zip(open.iter()).map(|(c, o)| *c < *o).collect();
    let sum_arr = sum_cond(&cond, cfg.down_streak_window);
    cond.iter().zip(sum_arr.iter()).map(|(c, s)| {
        if_true(*c && !s.is_nan() && *s >= cfg.down_streak_days as f64)
    }).collect()
}

/// 6.创n天新低
fn sell_6(low: &[f64], close: &[f64], open: &[f64], cfg: &YunStrategy) -> Vec<f64> {
    let llv_n = llv(low, cfg.breakout_days);
    let ref_llv_1 = prev(&llv_n, 1);
    let ref_llv_2 = prev(&llv_n, 2);
    let ref_close_1 = prev(close, 1);
    let ref_open_1 = prev(open, 1);

    let n = low.len();
    let mut result = vec![0.0; n];
    for i in 1..n {
        let break_d1 = low[i] < ref_llv_1[i];
        let break_d2 = ref_close_1[i] > ref_open_1[i] && low[i] < ref_llv_2[i] && close[i] < open[i];
        result[i] = if_true(break_d1 || break_d2);
    }
    result
}

/// 7.下跌x%
fn sell_7(close: &[f64], open: &[f64], cfg: &YunStrategy) -> Vec<f64> {
    bool_to_f64(&close.iter().zip(open.iter()).map(|(c, o)| {
        !o.is_nan() && *o > 0.0 && (*c - *o) / *o * 100.0 < -cfg.decrease_rate
    }).collect::<Vec<_>>())
}

/// 8.close < MA(close)快线
fn sell_8(close: &[f64], cfg: &YunStrategy) -> Vec<f64> {
    let ma = sma(close, cfg.ma_fast);
    bool_to_f64(&close.iter().zip(ma.iter()).map(|(c, m)| !c.is_nan() && !m.is_nan() && *c < *m).collect::<Vec<_>>())
}

/// 9.close < MA(close)慢线
fn sell_9(close: &[f64], cfg: &YunStrategy) -> Vec<f64> {
    let ma = sma(close, cfg.ma_slow);
    bool_to_f64(&close.iter().zip(ma.iter()).map(|(c, m)| !c.is_nan() && !m.is_nan() && *c < *m).collect::<Vec<_>>())
}

/// 10.斜率向下快线
fn sell_10(close: &[f64], cfg: &YunStrategy) -> Vec<f64> {
    let ma = sma(close, cfg.ma_fast);
    let slope_val = slope(&ma, cfg.ma_slope_period);
    bool_to_f64(&slope_val.iter().map(|s| !s.is_nan() && *s < 0.0).collect::<Vec<_>>())
}

/// 11.斜率向下慢线
fn sell_11(close: &[f64], cfg: &YunStrategy) -> Vec<f64> {
    let ma = sma(close, cfg.ma_slow);
    let slope_val = slope(&ma, cfg.ma_slope_period);
    bool_to_f64(&slope_val.iter().map(|s| !s.is_nan() && *s < 0.0).collect::<Vec<_>>())
}

// ==================== 得分计算 ====================

/// 计算加权得分 (参考 Python 的 get_signal_payload 和加权逻辑)
fn calculate_scores(data: &[TdxDayData], cfg: &YunStrategy) -> (Vec<f64>, Vec<f64>) {
    let k = KlineData::from(data);
    let n = k.close.len();

    // 买入信号 1-11
    let s1 = buy_1(&k.close, cfg);
    let s2 = buy_2(&k.close, cfg);
    let s3 = buy_3(&k.close, &k.vol, cfg);
    let s4 = buy_4(&k.close, &k.open);
    let s5 = buy_5(&k.close, &k.open, cfg);
    let s6 = buy_6(&k.high, &k.close, &k.open, cfg);
    let s7 = buy_7(&k.close, &k.open, cfg);
    let s8 = buy_8(&k.close, cfg);
    let s9 = buy_9(&k.close, cfg);  // 使用 ma_slow
    let s10 = buy_10(&k.close, cfg);
    let s11 = buy_11(&k.close, cfg);  // 使用 ma_slow

    // 卖出信号 1-11
    let d1 = sell_1(&k.close, cfg);
    let d2 = sell_2(&k.close, cfg);
    let d3 = sell_3(&k.close, &k.vol, cfg);
    let d4 = sell_4(&k.close, &k.open);
    let d5 = sell_5(&k.close, &k.open, cfg);
    let d6 = sell_6(&k.low, &k.close, &k.open, cfg);
    let d7 = sell_7(&k.close, &k.open, cfg);
    let d8 = sell_8(&k.close, cfg);
    let d9 = sell_9(&k.close, cfg);  // 使用 ma_slow
    let d10 = sell_10(&k.close, cfg);
    let d11 = sell_11(&k.close, cfg);  // 使用 ma_slow

    // 各信号权重
    let w = [
        cfg.buy_1 as f64, cfg.buy_2 as f64, cfg.buy_3 as f64, cfg.buy_4 as f64, cfg.buy_5 as f64,
        cfg.buy_6 as f64, cfg.buy_7 as f64, cfg.buy_8 as f64, cfg.buy_9 as f64, cfg.buy_10 as f64, cfg.buy_11 as f64,
    ];
    let wd = [
        cfg.sell_1 as f64, cfg.sell_2 as f64, cfg.sell_3 as f64, cfg.sell_4 as f64, cfg.sell_5 as f64,
        cfg.sell_6 as f64, cfg.sell_7 as f64, cfg.sell_8 as f64, cfg.sell_9 as f64, cfg.sell_10 as f64, cfg.sell_11 as f64,
    ];

    // 总权重
    let total_wu: f64 = w.iter().sum();
    let total_wd: f64 = wd.iter().sum();

    // 信号数组引用
    let signals: [&[f64]; 11] = [&s1, &s2, &s3, &s4, &s5, &s6, &s7, &s8, &s9, &s10, &s11];
    let sell_signals: [&[f64]; 11] = [&d1, &d2, &d3, &d4, &d5, &d6, &d7, &d8, &d9, &d10, &d11];

    let mut l_score = vec![0.0; n];
    let mut s_score = vec![0.0; n];

    for i in 0..n {
        // 加权买入得分
        let mut buy_weighted = 0.0;
        for j in 0..11 {
            buy_weighted += signals[j][i] * w[j];
        }
        l_score[i] = if total_wu > 0.0 { buy_weighted / total_wu } else { 0.0 };

        // 加权卖出得分
        let mut sell_weighted = 0.0;
        for j in 0..11 {
            sell_weighted += sell_signals[j][i] * wd[j];
        }
        s_score[i] = if total_wd > 0.0 { sell_weighted / total_wd } else { 0.0 };
    }

    (l_score, s_score)
}

// ==================== 性能计算 ====================

fn get_performance(net_values: &[f64], trade_count: i32) -> BacktestResult {
    if net_values.len() < 2 {
        return BacktestResult::default();
    }

    let first = net_values[0];
    let last = net_values.last().unwrap();

    if first.is_nan() || first <= 0.0 || last.is_nan() {
        return BacktestResult::default();
    }

    let total_ret = (last / first) - 1.0;
    let days = net_values.len() as f64;
    let ann_ret = ((1.0 + total_ret).powf(242.0 / days) - 1.0) * 100.0;

    // 最大回撤
    let mut peak = first;
    let mut max_dd = 0.0;
    for &val in net_values {
        if val.is_nan() { continue; }
        if val > peak { peak = val; }
        let dd = (val - peak) / peak;
        if dd < max_dd { max_dd = dd; }
    }

    // 夏普比率
    let mut daily_returns = Vec::with_capacity(net_values.len() - 1);
    for i in 1..net_values.len() {
        let prev = net_values[i - 1];
        let curr = net_values[i];
        if prev.is_nan() || curr.is_nan() || prev == 0.0 { continue; }
        daily_returns.push((curr - prev) / prev);
    }

    if daily_returns.is_empty() {
        return BacktestResult {
            sharpe: 0.0,
            ann_ret_pct: ann_ret * 100.0,
            max_dd_pct: max_dd * 100.0,
            trade_count,
            signals: vec![],
            equity: vec![],
        };
    }

    let mean_ret = daily_returns.iter().sum::<f64>() / daily_returns.len() as f64;
    let variance = daily_returns.iter().map(|r| (r - mean_ret).powi(2)).sum::<f64>() / daily_returns.len() as f64;
    let std = variance.sqrt();

    let sharpe = if std != 0.0 {
        (mean_ret / std) * (242.0_f64.sqrt())
    } else {
        0.0
    };

    BacktestResult {
        sharpe: (sharpe * 100.0).round() / 100.0,
        ann_ret_pct: (ann_ret * 100.0).round() / 100.0,
        max_dd_pct: (max_dd * 100.0).round() / 100.0,
        trade_count,
        signals: vec![],
        equity: vec![],
    }
}

// ==================== 回测函数 ====================

/// 运行回测
///
/// # Arguments
/// * `data` - K线数据
/// * `params` - 策略参数，None 则使用默认策略
pub fn run_backtest(data: &[TdxDayData], params: Option<&StrategyParams>) -> BacktestResult {
    let cfg = match params {
        Some(p) => YunStrategy::from(p.clone()),
        None => YunStrategy::default_strategy(),
    };

    let (l_score, s_score) = calculate_scores(data, &cfg);
    let close = {
        let k = KlineData::from(data);
        k.close
    };
    let n = close.len();

    let mut equity = vec![0.0; n];
    let mut signals = vec![0; n]; // 1=买入, -1=卖出, 0=无操作
    let mut cash = cfg.initial_cash;
    let mut pos = 0.0;
    let mut trades = 0;

    for i in 0..n {
        if l_score[i] >= cfg.weight_up && pos == 0.0 && close[i] > 0.0 {
            pos = (cash / close[i] as f64).floor();
            cash -= pos * close[i] as f64;
            trades += 1;
            signals[i] = 1; // 买入
        } else if s_score[i] >= cfg.weight_down && pos > 0.0 {
            cash += pos * close[i] as f64;
            pos = 0.0;
            trades += 1;
            signals[i] = -1; // 卖出
        }
        equity[i] = cash + pos * close[i] as f64;
    }

    let perf = get_performance(&equity, trades);

    BacktestResult {
        sharpe: perf.sharpe,
        ann_ret_pct: perf.ann_ret_pct,
        max_dd_pct: perf.max_dd_pct,
        trade_count: perf.trade_count,
        signals,
        equity,
    }
}

// ==========================================
// 4. 参数寻优入口
// ==========================================


/// 寻优参数网格
#[derive(Clone, Debug)]
pub struct ParamsGrid {
    pub ma_fast: Vec<usize>,
    pub ma_slow: Vec<usize>,
    pub macd_short: Vec<usize>,
    pub macd_long: Vec<usize>,
    pub macd_signal: Vec<usize>,
    pub obv_ma_period: Vec<usize>,
    pub breakout_days: Vec<usize>,
    pub ma_slope_period: Vec<usize>,
    pub up_streak_window: Vec<usize>,
    pub up_streak_days: Vec<usize>,
    pub down_streak_window: Vec<usize>,
    pub down_streak_days: Vec<usize>,
    pub increase_rate: Vec<f64>,
    pub decrease_rate: Vec<f64>,
    pub weight_up: Vec<f64>,
    pub weight_down: Vec<f64>,
    // 权重参数 (0=不使用, 1=普通, 2=双倍, 3=三倍)
    pub buy_weight: Vec<usize>,
    pub sell_weight: Vec<usize>,
}

impl Default for ParamsGrid {
    fn default() -> Self {
        Self {
            ma_fast: (5..60).step_by(1).collect(),
            ma_slow: (30..120).step_by(1).collect(),
            macd_short: (8..26).step_by(1).collect(),
            macd_long: (12..60).step_by(1).collect(),
            macd_signal: (5..30).step_by(1).collect(),
            obv_ma_period: (5..60).step_by(1).collect(),
            breakout_days: (2..12).step_by(1).collect(),
            ma_slope_period: (2..12).step_by(1).collect(),
            up_streak_window: (5..12).step_by(1).collect(),
            up_streak_days: (3..8).step_by(1).collect(),
            down_streak_window: (5..12).step_by(1).collect(),
            down_streak_days: (3..8).step_by(1).collect(),
            increase_rate: vec![0.6, 0.7, 0.8, 0.9, 1.0, 1.1, 1.2, 1.3, 1.4, 1.5, 1.8, 2.0],
            decrease_rate: vec![0.6, 0.7, 0.8, 0.9, 1.0, 1.1, 1.2, 1.3, 1.4, 1.5, 1.8, 2.0],
            weight_up: vec![0.65, 0.75, 0.85, 0.95],
            weight_down: vec![0.5, 0.65, 0.85, 0.95],
            // 权重选项
            buy_weight: vec![0, 1, 2, 3],
            sell_weight: vec![0, 1, 2, 3],
        }
    }
}

/// 单组参数配置
#[derive(Clone, Debug)]
pub struct StrategyParams {
    pub ma_fast: usize,
    pub ma_slow: usize,
    pub macd_short: usize,
    pub macd_long: usize,
    pub macd_signal: usize,
    pub obv_ma_period: usize,
    pub breakout_days: usize,
    pub ma_slope_period: usize,
    pub up_streak_window: usize,
    pub up_streak_days: usize,
    pub down_streak_window: usize,
    pub down_streak_days: usize,
    pub increase_rate: f64,
    pub decrease_rate: f64,
    pub weight_up: f64,
    pub weight_down: f64,
    // 各信号权重
    pub buy_1: usize,
    pub buy_2: usize,
    pub buy_3: usize,
    pub buy_4: usize,
    pub buy_5: usize,
    pub buy_6: usize,
    pub buy_7: usize,
    pub buy_8: usize,
    pub buy_9: usize,
    pub buy_10: usize,
    pub buy_11: usize,
    pub sell_1: usize,
    pub sell_2: usize,
    pub sell_3: usize,
    pub sell_4: usize,
    pub sell_5: usize,
    pub sell_6: usize,
    pub sell_7: usize,
    pub sell_8: usize,
    pub sell_9: usize,
    pub sell_10: usize,
    pub sell_11: usize,
}

/// 寻优结果
#[derive(Debug)]
pub struct OptimizationResult {
    pub params: StrategyParams,
    pub performance: BacktestResult,
    pub sharpe: f64,
}

impl From<StrategyParams> for YunStrategy {
    fn from(p: StrategyParams) -> Self {
        YunStrategy {
            initial_cash: 100000.0,
            ma_fast: p.ma_fast,
            ma_slow: p.ma_slow,
            macd_short: p.macd_short,
            macd_long: p.macd_long,
            macd_signal: p.macd_signal,
            obv_ma_period: p.obv_ma_period,
            breakout_days: p.breakout_days,
            ma_slope_period: p.ma_slope_period,
            up_streak_window: p.up_streak_window,
            up_streak_days: p.up_streak_days,
            down_streak_window: p.down_streak_window,
            down_streak_days: p.down_streak_days,
            increase_rate: p.increase_rate,
            decrease_rate: p.decrease_rate,
            weight_up: p.weight_up,
            weight_down: p.weight_down,
            buy_1: p.buy_1,
            buy_2: p.buy_2,
            buy_3: p.buy_3,
            buy_4: p.buy_4,
            buy_5: p.buy_5,
            buy_6: p.buy_6,
            buy_7: p.buy_7,
            buy_8: p.buy_8,
            buy_9: p.buy_9,
            buy_10: p.buy_10,
            buy_11: p.buy_11,
            sell_1: p.sell_1,
            sell_2: p.sell_2,
            sell_3: p.sell_3,
            sell_4: p.sell_4,
            sell_5: p.sell_5,
            sell_6: p.sell_6,
            sell_7: p.sell_7,
            sell_8: p.sell_8,
            sell_9: p.sell_9,
            sell_10: p.sell_10,
            sell_11: p.sell_11,
        }
    }
}

/// 使用指定参数运行回测
fn run_with_params(data: &[TdxDayData], params: &StrategyParams) -> OptimizationResult {
    let performance = run_backtest(data, Some(params));
    let sharpe = performance.sharpe;

    OptimizationResult {
        params: params.clone(),
        performance,
        sharpe,
    }
}

/// 生成随机参数组合
fn generate_random_params(grid: &ParamsGrid, seed: u64) -> StrategyParams {
    fn rand_idx(len: usize, seed: &mut u64) -> usize {
        *seed = seed.wrapping_mul(1103515245).wrapping_add(12345);
        (*seed as usize) % len
    }

    let mut s = seed;

    StrategyParams {
        ma_fast: grid.ma_fast[rand_idx(grid.ma_fast.len(), &mut s)],
        ma_slow: grid.ma_slow[rand_idx(grid.ma_slow.len(), &mut s)],
        macd_short: grid.macd_short[rand_idx(grid.macd_short.len(), &mut s)],
        macd_long: grid.macd_long[rand_idx(grid.macd_long.len(), &mut s)],
        macd_signal: grid.macd_signal[rand_idx(grid.macd_signal.len(), &mut s)],
        obv_ma_period: grid.obv_ma_period[rand_idx(grid.obv_ma_period.len(), &mut s)],
        breakout_days: grid.breakout_days[rand_idx(grid.breakout_days.len(), &mut s)],
        ma_slope_period: grid.ma_slope_period[rand_idx(grid.ma_slope_period.len(), &mut s)],
        up_streak_window: grid.up_streak_window[rand_idx(grid.up_streak_window.len(), &mut s)],
        up_streak_days: grid.up_streak_days[rand_idx(grid.up_streak_days.len(), &mut s)],
        down_streak_window: grid.down_streak_window[rand_idx(grid.down_streak_window.len(), &mut s)],
        down_streak_days: grid.down_streak_days[rand_idx(grid.down_streak_days.len(), &mut s)],
        increase_rate: grid.increase_rate[rand_idx(grid.increase_rate.len(), &mut s)],
        decrease_rate: grid.decrease_rate[rand_idx(grid.decrease_rate.len(), &mut s)],
        weight_up: grid.weight_up[rand_idx(grid.weight_up.len(), &mut s)],
        weight_down: grid.weight_down[rand_idx(grid.weight_down.len(), &mut s)],
        // 权重参数 (0, 1, 2, 3)
        buy_1: grid.buy_weight[rand_idx(grid.buy_weight.len(), &mut s)],
        buy_2: grid.buy_weight[rand_idx(grid.buy_weight.len(), &mut s)],
        buy_3: grid.buy_weight[rand_idx(grid.buy_weight.len(), &mut s)],
        buy_4: grid.buy_weight[rand_idx(grid.buy_weight.len(), &mut s)],
        buy_5: grid.buy_weight[rand_idx(grid.buy_weight.len(), &mut s)],
        buy_6: grid.buy_weight[rand_idx(grid.buy_weight.len(), &mut s)],
        buy_7: grid.buy_weight[rand_idx(grid.buy_weight.len(), &mut s)],
        buy_8: grid.buy_weight[rand_idx(grid.buy_weight.len(), &mut s)],
        buy_9: grid.buy_weight[rand_idx(grid.buy_weight.len(), &mut s)],
        buy_10: grid.buy_weight[rand_idx(grid.buy_weight.len(), &mut s)],
        buy_11: grid.buy_weight[rand_idx(grid.buy_weight.len(), &mut s)],

        sell_1: grid.sell_weight[rand_idx(grid.sell_weight.len(), &mut s)],
        sell_2: grid.sell_weight[rand_idx(grid.sell_weight.len(), &mut s)],
        sell_3: grid.sell_weight[rand_idx(grid.sell_weight.len(), &mut s)],
        sell_4: grid.sell_weight[rand_idx(grid.sell_weight.len(), &mut s)],
        sell_5: grid.sell_weight[rand_idx(grid.sell_weight.len(), &mut s)],
        sell_6: grid.sell_weight[rand_idx(grid.sell_weight.len(), &mut s)],
        sell_7: grid.sell_weight[rand_idx(grid.sell_weight.len(), &mut s)],
        sell_8: grid.sell_weight[rand_idx(grid.sell_weight.len(), &mut s)],
        sell_9: grid.sell_weight[rand_idx(grid.sell_weight.len(), &mut s)],
        sell_10: grid.sell_weight[rand_idx(grid.sell_weight.len(), &mut s)],
        sell_11: grid.sell_weight[rand_idx(grid.sell_weight.len(), &mut s)],
    }
}

/// 参数寻优入口
pub fn run_opt(data: &[TdxDayData], max_combinations: usize, show_log: bool) -> Vec<OptimizationResult> {
    let grid = ParamsGrid::default();
    let k = KlineData::from(data);

    if show_log {
        log!("K线数据: {} 条", k.n);
        log!("开始参数寻优, 最大组合数: {}", max_combinations);
    }

    // 生成参数组合
    let mut all_params = Vec::with_capacity(max_combinations);
    let base_seed = SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_nanos() as u64;
    for i in 0..max_combinations {
        all_params.push(generate_random_params(&grid, base_seed.wrapping_add(i as u64)));
    }

    // 并行计算 (使用 rayon)
    use rayon::prelude::*;
    let results: Vec<OptimizationResult> = all_params
        .par_iter()
        .map(|params| run_with_params(data, params))
        .collect();

    // 按夏普比率排序
    let mut sorted = results;
    sorted.sort_by(|a, b| b.sharpe.partial_cmp(&a.sharpe).unwrap());

    if show_log {
        log!("\n========== 寻优完成 ==========");
        if let Some(best) = sorted.first() {
            log!("最优夏普比率: {:.2}", best.sharpe);
            log!("最优参数: {:?}", best.params);
        }
    }

    sorted
}

/// 带进度回调的参数寻优
/// progress_callback(current, total) - 每处理完一组就调用
pub fn run_opt_with_progress<F>(
    data: &[TdxDayData],
    max_combinations: usize,
    progress_callback: F,
) -> Vec<OptimizationResult>
where
    F: Fn(usize, usize) + Send + Sync,
{
    let grid = ParamsGrid::default();

    // 生成参数组合
    let base_seed = SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_nanos() as u64;
    let all_params: Vec<_> = (0..max_combinations)
        .map(|i| generate_random_params(&grid, base_seed.wrapping_add(i as u64)))
        .collect();

    // 分批并行处理，每1000组报告一次进度
    let batch_size = 1000;
    let total = max_combinations;
    let results: Vec<OptimizationResult> = all_params
        .par_iter()
        .with_min_len(batch_size)
        .enumerate()
        .map(|(idx, params)| {
            let result = run_with_params(data, params);
            // 每批或最后一批时触发回调
            if (idx + 1) % batch_size == 0 || idx + 1 == total {
                progress_callback(idx + 1, total);
            }
            result
        })
        .collect();

    // 按夏普比率排序
    let mut sorted = results;
    sorted.sort_by(|a, b| b.sharpe.partial_cmp(&a.sharpe).unwrap());

    sorted
}

/// 打印最优参数
pub fn print_best_results(results: &[OptimizationResult], top_n: usize) {
    log!("\n========== Top {} 最优参数 ==========", top_n);
    for (i, res) in results.iter().take(top_n).enumerate() {
        log!("\n#{:2} Sharpe: {:.2} | 年化: {:.2}% | 最大回撤: {:.2}% | 交易次数: {}",
            i + 1, res.sharpe, res.performance.ann_ret_pct, res.performance.max_dd_pct, res.performance.trade_count);
        log!("   ma_fast={}, ma_slow={}, macd=({}/{}/{}), obv={}",
            res.params.ma_fast, res.params.ma_slow, res.params.macd_short,
            res.params.macd_long, res.params.macd_signal, res.params.obv_ma_period);
        log!("   breakout={}, slope={}, streak=({}/{}, {}/{})",
            res.params.breakout_days, res.params.ma_slope_period,
            res.params.up_streak_window, res.params.up_streak_days,
            res.params.down_streak_window, res.params.down_streak_days);
        log!("   rate=({:.1}/{:.1}), weight=({:.2}/{:.2})",
            res.params.increase_rate, res.params.decrease_rate,
            res.params.weight_up, res.params.weight_down);
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::seek::tdx_data::TdxDayData;

    fn mock_kline() -> Vec<TdxDayData> {
        let mut data = Vec::new();
        let base = 10.0f32;
        for i in 0..100u32 {
            let t = i as f32;
            data.push(TdxDayData {
                date: 20240000 + i,
                open: base + t * 0.1,
                close: base + t * 0.1 + 0.5,
                high: base + t * 0.1 + 1.0,
                low: base + t * 0.1 - 0.5,
                vol: 1000000,
            });
        }
        data
    }

    fn mock_cfg() -> YunStrategy {
        YunStrategy {
            initial_cash: 100000.0,
            ma_fast: 5,
            ma_slow: 10,
            macd_short: 12,
            macd_long: 26,
            macd_signal: 9,
            obv_ma_period: 30,
            breakout_days: 3,
            ma_slope_period: 5,
            up_streak_window: 5,
            up_streak_days: 3,
            down_streak_window: 5,
            down_streak_days: 3,
            increase_rate: 0.5,
            decrease_rate: 0.5,
            weight_up: 0.8,
            weight_down: 0.8,
            buy_1: 1, buy_2: 1, buy_3: 1, buy_4: 1, buy_5: 1,
            buy_6: 1, buy_7: 1, buy_8: 1, buy_9: 1, buy_10: 1, buy_11: 1,
            sell_1: 1, sell_2: 1, sell_3: 1, sell_4: 1, sell_5: 1,
            sell_6: 1, sell_7: 1, sell_8: 1, sell_9: 1, sell_10: 1, sell_11: 1,
        }
    }

    #[test]
    fn test_backtest_basic() {
        let data = mock_kline();
        let result = run_backtest(&data, None);
        println!("Backtest result: {:?}", result);
        assert!(result.trade_count >= 0);
    }

    #[test]
    fn test_buy_signals() {
        let close = vec![10.0, 11.0, 12.0, 13.0, 14.0, 15.0, 16.0, 17.0, 18.0, 19.0, 20.0];
        let open = vec![9.0, 10.0, 11.0, 12.0, 13.0, 14.0, 15.0, 16.0, 17.0, 18.0, 19.0];
        let _vol = vec![1000.0; 11];
        let cfg = mock_cfg();

        // buy_1: ma_fast > ma_slow
        let s1 = buy_1(&close, &cfg);
        assert_eq!(s1.len(), 11);

        // buy_4: close > open
        let s4 = buy_4(&close, &open);
        assert_eq!(s4.len(), 11);
        assert_eq!(s4[0], 1.0); // 10 > 9
    }

    #[test]
    fn test_weighted_scores() {
        let data = mock_kline();
        let cfg = mock_cfg();
        let (l_score, s_score) = calculate_scores(&data, &cfg);
        assert_eq!(l_score.len(), 100);
        assert_eq!(s_score.len(), 100);
    }
}

