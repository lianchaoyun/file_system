//! Redis 任务队列管理

use crate::seek::opt_data::{OptTaskData, OPT_KEY_PREFIX, OPT_EXPIRE_SECS};
use crate::log;
use bb8::Pool;
use bb8_redis::RedisConnectionManager;
use redis::AsyncCommands;
use serde::{Deserialize, Serialize};
use std::sync::Arc;

const OPT_QUEUE_KEY: &str = "opt:queue";

#[derive(Serialize, Deserialize, Clone)]
pub struct OptQueueItem {
    pub task_id: String,
    pub symbol: String,
    pub adj_type: String,
    pub max_combinations: usize,
    pub created_at: i64,
}

/// 寻优任务队列
pub struct OptQueueManager {
    redis_pool: Arc<Pool<RedisConnectionManager>>,
}

impl OptQueueManager {
    pub fn new(redis_pool: Arc<Pool<RedisConnectionManager>>) -> Self {
        Self { redis_pool }
    }

    /// 添加任务到队列
    pub async fn push(&self, item: OptQueueItem) -> Result<(), String> {
        let mut redis = self.redis_pool.get().await.map_err(|e| e.to_string())?;
        let json = serde_json::to_string(&item).map_err(|e| e.to_string())?;
        redis.lpush::<_, _, ()>(OPT_QUEUE_KEY, &json).await.map_err(|e| e.to_string())?;
        log!("[OptQueue] 任务入队: task_id={}", item.task_id);
        Ok(())
    }

    /// 从队列取出任务（FIFO）
    pub async fn pop(&self) -> Result<Option<OptQueueItem>, String> {
        let mut redis = self.redis_pool.get().await.map_err(|e| e.to_string())?;
        let json: Option<String> = redis.rpop(OPT_QUEUE_KEY, None).await.map_err(|e| e.to_string())?;

        match json {
            Some(j) => {
                let item: OptQueueItem = serde_json::from_str(&j).map_err(|e| e.to_string())?;
                Ok(Some(item))
            }
            None => Ok(None),
        }
    }

    /// 查看队列长度
    pub async fn len(&self) -> Result<usize, String> {
        let mut redis = self.redis_pool.get().await.map_err(|e| e.to_string())?;
        let len: isize = redis.llen(OPT_QUEUE_KEY).await.map_err(|e| e.to_string())?;
        Ok(len as usize)
    }

    /// 更新任务状态
    pub async fn update_task(&self, task: &OptTaskData) -> Result<(), String> {
        let mut redis = self.redis_pool.get().await.map_err(|e| e.to_string())?;
        let json = serde_json::to_string(task).map_err(|e| e.to_string())?;

        let key_current = format!("{}current", OPT_KEY_PREFIX);
        let key_task = format!("{}{}", OPT_KEY_PREFIX, task.task_id);

        redis.set_ex::<_, _, ()>(&key_current, &json, OPT_EXPIRE_SECS)
            .await
            .map_err(|e| e.to_string())?;
        redis.set_ex::<_, _, ()>(&key_task, &json, OPT_EXPIRE_SECS)
            .await
            .map_err(|e| e.to_string())?;
        Ok(())
    }

    /// 检查当前是否有任务在运行
    pub async fn is_running(&self) -> Result<bool, String> {
        let mut redis = self.redis_pool.get().await.map_err(|e| e.to_string())?;
        let key = format!("{}current", OPT_KEY_PREFIX);

        if let Ok(json) = redis.get::<_, String>(&key).await {
            if let Ok(task) = serde_json::from_str::<OptTaskData>(&json) {
                return Ok(task.status == "running");
            }
        }
        Ok(false)
    }

    /// 添加到历史列表
    pub async fn add_to_history(&self, task_id: &str) -> Result<(), String> {
        let mut redis = self.redis_pool.get().await.map_err(|e| e.to_string())?;
        let list_key = format!("{}list", OPT_KEY_PREFIX);
        redis.lpush::<_, _, ()>(&list_key, task_id).await.map_err(|e| e.to_string())?;
        redis.ltrim::<_, ()>(&list_key, 0, 49).await.map_err(|e| e.to_string())?;
        Ok(())
    }

    /// 获取指定任务详情
    pub async fn get_task(&self, task_id: &str) -> Result<OptTaskData, String> {
        let mut redis = self.redis_pool.get().await.map_err(|e| e.to_string())?;
        let key = format!("{}{}", OPT_KEY_PREFIX, task_id);
        let json = redis.get::<_, String>(&key).await.map_err(|e| e.to_string())?;
        serde_json::from_str(&json).map_err(|e| e.to_string())
    }
}
