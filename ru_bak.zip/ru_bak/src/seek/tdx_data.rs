//! 通达信数据提供者模块（备用实现，目前通过 Python/pytdx 使用）
#![allow(dead_code)]

//! 负责：K线文件读取、权息库加载、前复权计算

use crate::log;
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::fs::File;
use std::io::{self, Read};
use std::path::{Path, PathBuf};
use std::process::Command;
use std::sync::OnceLock;

/// 复权类型
#[derive(Debug, Clone, Copy, PartialEq, Default)]
pub enum AdjType {
    /// 不复权
    #[default]
    None,
    /// 前复权
    Forward,
    /// 后复权
    Backward,
}

/// K线单日数据结构
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TdxDayData {
    pub date: u32,
    pub open: f32,
    pub high: f32,
    pub low: f32,
    pub close: f32,
    pub vol: u32,
}

/// 权息数据项
#[derive(Debug, Clone)]
pub struct GbbqItem {
    pub date: u32,
    pub song_zhu: f32,   // 送股
    pub cash: f32,       // 派息(现金分红)
    pub pei_gu: f32,     // 配股
    pub pei_price: f32,  // 配股价
}

/// 权息库单例
static GBBQ_MAP: OnceLock<HashMap<String, Vec<GbbqItem>>> = OnceLock::new();
/// 通达信配置单例
static TDX_CONFIG: OnceLock<TdxConfig> = OnceLock::new();

/// 通达信配置（必须从环境变量读取）
#[derive(Clone)]
struct TdxConfig {
    tdx_root: String,
    decrypt_script: String,
    decrypt_json: String,
}

/// 初始化通达信配置（必须在程序启动时调用）
pub fn init_tdx_config() -> Result<(), String> {
    dotenv::dotenv().ok();
    let config = TdxConfig {
        tdx_root: std::env::var("TDX_ROOT").map_err(|e| format!("TDX_ROOT not set: {}", e))?,
        decrypt_script: std::env::var("DECRYPT_SCRIPT").map_err(|e| format!("DECRYPT_SCRIPT not set: {}", e))?,
        decrypt_json: std::env::var("DECRYPT_JSON").map_err(|e| format!("DECRYPT_JSON not set: {}", e))?,
    };
    TDX_CONFIG.set(config).map_err(|_| "TDX config already initialized")?;
    Ok(())
}

/// 获取通达信配置（懒加载）
fn get_tdx_config() -> &'static TdxConfig {
    TDX_CONFIG.get_or_init(|| {
        dotenv::dotenv().ok();
        TdxConfig {
            tdx_root: std::env::var("TDX_ROOT").expect("TDX_ROOT not set in .env"),
            decrypt_script: std::env::var("DECRYPT_SCRIPT").expect("DECRYPT_SCRIPT not set in .env"),
            decrypt_json: std::env::var("DECRYPT_JSON").expect("DECRYPT_JSON not set in .env"),
        }
    })
}

/// 通达信数据提供者
pub struct TdxDataProvider;

impl TdxDataProvider {
    /// 创建新的数据提供者
    pub fn new() -> Self {
        Self
    }

    /// 获取 K 线数据（可指定复权类型和数量）
    /// 
    /// # Arguments
    /// * `code` - 股票代码
    /// * `adj` - 复权类型
    /// * `count` - 返回数量，None 表示返回全部
    pub fn get_kline(&self, code: &str, adj: AdjType, count: Option<usize>) -> io::Result<Vec<TdxDayData>> {
        let path = self.get_path_by_code(code).ok_or_else(|| {
            io::Error::new(io::ErrorKind::InvalidInput, format!("无效代码: {}", code))
        })?;

        let mut data = self.read_day_file(&path)?;

        match adj {
            AdjType::Forward => data = self.apply_forward_adjustment(code, data),
            AdjType::Backward => data = self.apply_backward_adjustment(code, data),
            AdjType::None => {}
        }

        // 限制返回数量（取最新的）
        if let Some(n) = count {
            if n < data.len() {
                data = data[data.len() - n..].to_vec();
            }
        }

        Ok(data)
    }

    /// 批量获取多只股票的K线数据
    pub fn get_klines(&self, codes: &[&str], adj: AdjType, count: Option<usize>) -> HashMap<String, Vec<TdxDayData>> {
        let mut results = HashMap::new();
        for code in codes {
            if let Ok(data) = self.get_kline(code, adj, count) {
                results.insert(code.to_string(), data);
            }
        }
        results
    }

    /// 获取权息库数据（用于外部访问）
    pub fn get_gbbq(&self, code: &str) -> Option<&Vec<GbbqItem>> {
        Self::load_gbbq_map().get(code)
    }

    /// 初始化权息库（可选，提前加载）
    pub fn preload_gbbq(&self) {
        Self::load_gbbq_map();
    }

    // ==================== 内部方法 ====================

    /// 根据股票代码获取K线文件路径
    fn get_path_by_code(&self, code: &str) -> Option<PathBuf> {
        let (dir, prefix) = match code {
            c if c.starts_with("60") || c.starts_with("68") => ("sh", "sh"),
            c if c.starts_with("00") || c.starts_with("30") => ("sz", "sz"),
            c if c.starts_with("920") || c.starts_with("8") || c.starts_with("4") => ("bj", "bj"),
            _ => return None,
        };

        let config = get_tdx_config();
        Some(PathBuf::from(&config.tdx_root)
            .join("vipdoc")
            .join(dir)
            .join("lday")
            .join(format!("{}{}.day", prefix, code)))
    }

    /// 读取通达信日线文件（二进制格式）
    fn read_day_file(&self, path: &Path) -> io::Result<Vec<TdxDayData>> {
        
        let mut file = File::open(path)?;
        let mut buffer = [0u8; 32];
        let mut results = Vec::with_capacity(4000);

        while file.read_exact(&mut buffer).is_ok() {
            results.push(TdxDayData {
                date: u32::from_le_bytes(buffer[0..4].try_into().unwrap()),
                open: u32::from_le_bytes(buffer[4..8].try_into().unwrap()) as f32 / 100.0,
                high: u32::from_le_bytes(buffer[8..12].try_into().unwrap()) as f32 / 100.0,
                low: u32::from_le_bytes(buffer[12..16].try_into().unwrap()) as f32 / 100.0,
                close: u32::from_le_bytes(buffer[16..20].try_into().unwrap()) as f32 / 100.0,
                vol: u32::from_le_bytes(buffer[24..28].try_into().unwrap()),
            });
        }
        Ok(results)
    }

    /// 加载权息库（懒加载单例）
    /// 使用 Python 脚本解密加密的 gbbq 文件，然后读取 JSON
    fn load_gbbq_map() -> &'static HashMap<String, Vec<GbbqItem>> {
        GBBQ_MAP.get_or_init(|| {
            let config = get_tdx_config();
            let gbbq_path = PathBuf::from(&config.tdx_root).join("T0002/hq_cache/gbbq");
            let json_path = PathBuf::from(&config.decrypt_json);

            // 检查是否需要解密：源文件更新时重新解密
            let need_decrypt = match (std::fs::metadata(&gbbq_path), std::fs::metadata(&json_path)) {
                (Ok(src), Ok(dst)) => {
                    // 如果源文件比目标文件新，需要重新解密
                    src.modified().map(|s| dst.modified().map(|d| s > d).unwrap_or(true)).unwrap_or(true)
                },
                _ => true, // 任一文件不存在，都需要解密
            };

            if need_decrypt {
                log!("[权息] 正在解密 gbbq 文件...");
                let _ = Command::new("python")
                    .arg(&config.decrypt_script)
                    .arg(&gbbq_path)
                    .arg(&json_path)
                    .output();
                log!("[权息] 解密完成");
            } else {
                log!("[权息] 使用缓存的 gbbq 文件");
            }

            // 2. 读取解密后的 JSON 文件
            let mut map: HashMap<String, Vec<GbbqItem>> = HashMap::new();

            if let Ok(file) = File::open(&json_path) {
                if let Ok(content) = std::io::read_to_string(file) {
                    if let Ok(data) = serde_json::from_str::<HashMap<String, Vec<serde_json::Value>>>(&content) {
                        for (code, items) in data {
                            let gbbq_items: Vec<GbbqItem> = items
                                .iter()
                                .filter_map(|item| {
                                    Some(GbbqItem {
                                        date: item.get("date")?.as_u64()? as u32,
                                        song_zhu: item.get("song_zhu")?.as_f64()? as f32,
                                        cash: item.get("cash")?.as_f64()? as f32,
                                        pei_gu: item.get("pei_gu")?.as_f64()? as f32,
                                        pei_price: item.get("pei_price")?.as_f64()? as f32,
                                    })
                                })
                                .collect();
                            if !gbbq_items.is_empty() {
                                map.insert(code, gbbq_items);
                            }
                        }
                    }
                }
            }

            log!("加载权息: {} 只股票", map.len());
            map
        })
    }

    /// 应用前复权
    /// 算法：从最新日期往最早日期处理除权事件
    /// 每个除权只影响该除权日之前的所有数据
    /// 注意：gbbq 中的 song_zhu/cash/pei_gu 是每10股的比例，需要除以10转为每股
    fn apply_forward_adjustment(&self, code: &str, mut data: Vec<TdxDayData>) -> Vec<TdxDayData> {
        if data.is_empty() {
            return data;
        }

        let gbbq = Self::load_gbbq_map();
        if let Some(items) = gbbq.get(code) {
            // 按日期降序：先处理最新的除权
            let mut sorted_items: Vec<_> = items.iter().collect();
            sorted_items.sort_by_key(|a| std::cmp::Reverse(a.date));

            // 累积复权因子（从1.0开始，表示当前已处理的所有除权的因子乘积）
            let mut cum_factor = 1.0f32;

            for item in sorted_items {
                // 找到除权日或之后的第一个交易日索引
                // 注意：除权日当天价格已经除权，所以只调整该日期之前的数据
                if let Some(idx) = data.iter().position(|d| d.date >= item.date) {
                    if idx == 0 {
                        continue; // 除权日在第一条数据之前，无法调整
                    }

                    // 除权日前一天的收盘价（此时已经被之前处理过的除权调整过，需要还原）
                    let adjusted_pre_close = data[idx - 1].close;
                    let original_pre_close = adjusted_pre_close / cum_factor;

                    // 转为每股比例（gbbq数据是每10股）
                    let song_per_share = item.song_zhu / 10.0;
                    let cash_per_share = item.cash / 10.0;
                    let pei_per_share = item.pei_gu / 10.0;

                    // 计算本次除权的复权因子
                    let numerator = original_pre_close - cash_per_share + pei_per_share * item.pei_price;
                    let denominator = original_pre_close * (1.0 + song_per_share + pei_per_share);

                    if denominator.abs() < f32::EPSILON {
                        continue;
                    }

                    let factor = numerator / denominator;
                    let new_cum_factor = cum_factor * factor;

                    // 将除权日之前的所有数据：先还原到原始价格，再乘以新的累积因子
                    for i in 0..idx {
                        data[i].open = data[i].open / cum_factor * new_cum_factor;
                        data[i].high = data[i].high / cum_factor * new_cum_factor;
                        data[i].low = data[i].low / cum_factor * new_cum_factor;
                        data[i].close = data[i].close / cum_factor * new_cum_factor;
                    }

                    cum_factor = new_cum_factor;
                }
            }
        }
        data
    }

    /// 应用后复权
    /// 注意：gbbq 中的 song_zhu/cash/pei_gu 是每10股的比例，需要除以10转为每股
    fn apply_backward_adjustment(&self, code: &str, mut data: Vec<TdxDayData>) -> Vec<TdxDayData> {
        let gbbq = Self::load_gbbq_map();
        if let Some(items) = gbbq.get(code) {
            // 按日期升序：先处理最早的除权
            let mut sorted_items: Vec<_> = items.iter().collect();
            sorted_items.sort_by_key(|a| a.date);

            let mut total_factor = 1.0f32;

            for item in sorted_items {
                if let Some(idx) = data.iter().position(|d| d.date >= item.date) {
                    if idx == 0 { continue; }

                    // 除权日前一天的收盘价（此时后面的数据已经被之前的除权调整过了）
                    let adjusted_pre_close = data[idx - 1].close;
                    let original_pre_close = adjusted_pre_close / total_factor;

                    // 转为每股比例
                    let song_per_share = item.song_zhu / 10.0;
                    let cash_per_share = item.cash / 10.0;
                    let pei_per_share = item.pei_gu / 10.0;

                    let numerator = original_pre_close * (1.0 + song_per_share + pei_per_share);
                    let denominator = original_pre_close - cash_per_share + pei_per_share * item.pei_price;

                    if denominator.abs() < f32::EPSILON {
                        continue;
                    }

                    let factor = numerator / denominator;
                    total_factor *= factor;

                    // 将除权日及之后的所有数据统一乘以最新的 total_factor
                    let old_partial_factor = total_factor / factor;
                    for i in idx..data.len() {
                        data[i].open = data[i].open / old_partial_factor * total_factor;
                        data[i].high = data[i].high / old_partial_factor * total_factor;
                        data[i].low = data[i].low / old_partial_factor * total_factor;
                        data[i].close = data[i].close / old_partial_factor * total_factor;
                    }
                }
            }
        }
        data
    }
}

impl Default for TdxDataProvider {
    fn default() -> Self {
        Self::new()
    }
}
