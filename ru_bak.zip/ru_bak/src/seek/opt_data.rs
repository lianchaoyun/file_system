//! 寻优任务数据结构（共享）

use serde::{Deserialize, Serialize};

pub const OPT_KEY_PREFIX: &str = "opt:task:";
pub const OPT_EXPIRE_SECS: u64 = 86400; // 24小时过期
pub const OPT_QUEUE_KEY: &str = "opt:queue";

#[derive(Serialize, Deserialize, Clone)]
pub struct OptTaskData {
    pub task_id: String,
    pub status: String,
    pub progress: f64,
    pub total: usize,
    pub processed: usize,
    pub error: Option<String>,
    pub results: Vec<serde_json::Value>,
}

impl Default for OptTaskData {
    fn default() -> Self {
        Self {
            task_id: String::new(),
            status: "idle".to_string(),
            progress: 0.0,
            total: 0,
            processed: 0,
            error: None,
            results: vec![],
        }
    }
}

#[derive(Serialize)]
pub struct OptStatusResponse {
    pub task_id: String,
    pub status: String,
    pub progress: f64,
    pub total: usize,
    pub processed: usize,
    pub error: Option<String>,
    pub results: Vec<serde_json::Value>,
}

impl Default for OptStatusResponse {
    fn default() -> Self {
        OptTaskData::default().into()
    }
}

impl From<OptTaskData> for OptStatusResponse {
    fn from(t: OptTaskData) -> Self {
        Self {
            task_id: t.task_id,
            status: t.status,
            progress: t.progress,
            total: t.total,
            processed: t.processed,
            error: t.error,
            results: t.results,
        }
    }
}
