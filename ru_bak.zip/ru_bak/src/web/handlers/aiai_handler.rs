//! 管理后台 API —— trade_accounts / trade_strategies / logs
//!
//! 直接从 web 层提供，不经过 aiai 引擎。

use axum::{Json, extract::{State, Path}};

use crate::web::AppState;
use crate::models::user::ApiResponse;
use crate::models::aiai::{TradeAccountRow, StrategyConfigRow};
use crate::repositories::aiai_repo::AiaiRepository;

// ═══════════════════════════════════════════════
//  账户 CRUD
// ═══════════════════════════════════════════════

pub(crate) async fn list_accounts(
    State(state): State<AppState>,
) -> Json<ApiResponse<Vec<TradeAccountRow>>> {
    let repo = AiaiRepository::new(state.mysql_pool.clone());
    match repo.list_accounts().await {
        Ok(rows) => Json(ApiResponse::success(rows)),
        Err(e) => Json(ApiResponse::fail(e)),
    }
}

pub(crate) async fn save_account(
    State(state): State<AppState>,
    Json(data): Json<TradeAccountRow>,
) -> Json<ApiResponse<String>> {
    if data.exchange.is_empty() {
        return Json(ApiResponse::fail("exchange 不能为空"));
    }
    let repo = AiaiRepository::new(state.mysql_pool.clone());
    match repo.upsert_account(data).await {
        Ok(_) => Json(ApiResponse::success("ok".to_string())),
        Err(e) => Json(ApiResponse::fail(e)),
    }
}

pub(crate) async fn delete_account(
    State(state): State<AppState>,
    Path(id): Path<i64>,
) -> Json<ApiResponse<String>> {
    let repo = AiaiRepository::new(state.mysql_pool.clone());
    match repo.delete_account(id).await {
        Ok(_) => Json(ApiResponse::success("ok".to_string())),
        Err(e) => Json(ApiResponse::fail(e)),
    }
}

// ═══════════════════════════════════════════════
//  策略 CRUD
// ═══════════════════════════════════════════════

pub(crate) async fn list_strategies_all(
    State(state): State<AppState>,
) -> Json<ApiResponse<Vec<StrategyConfigRow>>> {
    let repo = AiaiRepository::new(state.mysql_pool.clone());
    match repo.list_strategies_all().await {
        Ok(rows) => Json(ApiResponse::success(rows)),
        Err(e) => Json(ApiResponse::fail(e)),
    }
}

pub(crate) async fn save_strategy(
    State(state): State<AppState>,
    Json(data): Json<StrategyConfigRow>,
) -> Json<ApiResponse<String>> {
    let repo = AiaiRepository::new(state.mysql_pool.clone());
    match repo.upsert_strategy(data).await {
        Ok(_) => Json(ApiResponse::success("ok".to_string())),
        Err(e) => Json(ApiResponse::fail(e)),
    }
}

pub(crate) async fn delete_strategy(
    State(state): State<AppState>,
    Path(id): Path<i64>,
) -> Json<ApiResponse<String>> {
    let repo = AiaiRepository::new(state.mysql_pool.clone());
    match repo.delete_strategy(id).await {
        Ok(_) => Json(ApiResponse::success("ok".to_string())),
        Err(e) => Json(ApiResponse::fail(e)),
    }
}

// ═══════════════════════════════════════════════
//  日志查看
// ═══════════════════════════════════════════════

#[derive(serde::Serialize)]
pub(crate) struct LogEntry {
    pub line: usize,
    pub content: String,
}

pub(crate) async fn get_logs() -> Json<ApiResponse<Vec<LogEntry>>> {
    let log_path = format!("logs/aiai.log.{}", chrono::Local::now().format("%Y-%m-%d"));
    match tokio::fs::read_to_string(&log_path).await {
        Ok(content) => {
            let entries: Vec<LogEntry> = content
                .lines()
                .rev()
                .take(200)
                .enumerate()
                .map(|(i, line)| LogEntry {
                    line: i,
                    content: line.to_string(),
                })
                .collect();
            Json(ApiResponse::success(entries))
        }
        Err(_) => Json(ApiResponse::success(vec![])),
    }
}
