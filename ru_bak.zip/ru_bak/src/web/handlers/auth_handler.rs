use crate::models::user::{ApiResponse, LoginResponse, LogoutRequest, OptionItem, OptionsRequest, RegisterRequest, RegisterResponse, UpdateUserRequest, UserProfileRequest, UserProfileResponse};
use crate::web::AppState;
use crate::error::AppError;
use crate::models::user::LoginRequest;
use axum::extract::{ConnectInfo, Query, State};
use axum::Json;
use std::net::SocketAddr;
use crate::utils::cache::get_cache;
use crate::utils::maker::extract_client_ip;

pub async fn ping() -> Json<ApiResponse<()>> {
    Json(ApiResponse::<()>::success(()))
}

pub async fn login(
    State(state): State<AppState>,
    ConnectInfo(addr): ConnectInfo<SocketAddr>,
    Json(form_data): Json<LoginRequest>,
) -> Result<Json<ApiResponse<serde_json::Value>>, AppError> {
    get_cache().insert(format!("{}_ip", form_data.request_id), extract_client_ip(&addr));
    let response: LoginResponse = state.auth_service.login(form_data).await?;
    let json = serde_json::to_value(response).map_err(|e| AppError::BadRequest(e.to_string()))?;
    Ok(Json(ApiResponse::success(json)))
}

pub async fn register(
    State(state): State<AppState>,
    ConnectInfo(addr): ConnectInfo<SocketAddr>,
    Json(form_data): Json<RegisterRequest>,
) -> Result<Json<ApiResponse<serde_json::Value>>, AppError> {
    get_cache().insert(format!("{}_ip", form_data.request_id), extract_client_ip(&addr));
    let response: RegisterResponse = state.auth_service.register(form_data).await?;
    let json = serde_json::to_value(response).map_err(|e| AppError::BadRequest(e.to_string()))?;
    Ok(Json(ApiResponse::success(json)))
}

pub async fn user(
    State(state): State<AppState>,
    ConnectInfo(addr): ConnectInfo<SocketAddr>,
    Query(form_data): Query<UserProfileRequest>,
) -> Result<Json<ApiResponse<serde_json::Value>>, AppError> {
    get_cache().insert(format!("{}_ip", form_data.request_id), extract_client_ip(&addr));
    let response: UserProfileResponse = state.auth_service.get_profile(form_data).await?;
    let json = serde_json::to_value(response).map_err(|e| AppError::BadRequest(e.to_string()))?;
    Ok(Json(ApiResponse::success(json)))
}

pub async fn logout(
    State(state): State<AppState>,
    Query(form_data): Query<LogoutRequest>,
) -> Result<Json<ApiResponse<()>>, AppError> {
    state.auth_service.logout(form_data).await?;
    Ok(Json(ApiResponse::success(())))
}

pub async fn update_user(
    State(state): State<AppState>,
    ConnectInfo(addr): ConnectInfo<SocketAddr>,
    Json(form_data): Json<UpdateUserRequest>,
) -> Result<Json<ApiResponse<serde_json::Value>>, AppError> {
    get_cache().insert(format!("{}_ip", form_data.request_id), extract_client_ip(&addr));
    let response: UserProfileResponse = state.auth_service.update_profile(form_data).await?;
    let json = serde_json::to_value(response).map_err(|e| AppError::BadRequest(e.to_string()))?;
    Ok(Json(ApiResponse::success(json)))
}

pub async fn options(
    State(state): State<AppState>,
    Query(form_data): Query<OptionsRequest>,
) -> Result<Json<ApiResponse<serde_json::Value>>, AppError> {
    let response: OptionItem = state.auth_service.get_option(form_data).await?;
    let json = serde_json::to_value(response).map_err(|e| AppError::BadRequest(e.to_string()))?;
    Ok(Json(ApiResponse::success(json)))
}
