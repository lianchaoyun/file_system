use axum::extract::{Query, State};
use axum::Json;
use serde::{Deserialize, Serialize};
use chrono::TimeZone;
use sqlx::MySqlPool;
use crate::web::AppState;
use crate::error::AppError;
use crate::seek::tdx_data::{AdjType, TdxDataProvider};
use crate::seek::strategy_opt::run_backtest;
use crate::models::user::ApiResponse;

/// 股票信息
#[derive(Debug, Serialize, Deserialize)]
pub struct StockInfo {
    pub code: String,
    pub name: String,
}

/// K线数据响应结构
#[derive(Debug, Serialize, Deserialize)]
pub struct KlineData {
    /// 时间戳 (秒)
    pub time: i64,
    /// 开盘价
    pub open: f32,
    /// 最高价
    pub high: f32,
    /// 最低价
    pub low: f32,
    /// 收盘价
    pub close: f32,
    /// 成交量
    pub volume: f32,
}

/// K线响应（包含股票信息和K线数据）
#[derive(Debug, Serialize)]
pub struct KlineResponse {
    pub stock: StockInfo,
    pub kline: Vec<KlineData>,
}

/// K线查询参数
#[derive(Debug, Deserialize)]
pub struct KlineQuery {
    /// 股票代码，如 600000
    pub code: String,
    /// 复权类型: none, forward (默认前复权)
    #[serde(default = "default_adj")]
    pub adj: String,
}

fn default_adj() -> String {
    "none".to_string()
}

/// 将通达信日期格式转换为时间戳
/// date: YYYYMMDD 格式
fn date_to_timestamp(date: u32) -> i64 {
    let year = (date / 10000) as i32;
    let month = ((date % 10000) / 100) as u32;
    let day = (date % 100) as u32;
    
    chrono::Utc.with_ymd_and_hms(year, month, day, 0, 0, 0)
        .single()
        .map(|dt| dt.timestamp())
        .unwrap_or(0)
}

/// 从数据库获取股票名称
async fn get_stock_name_from_db(pool: &MySqlPool, code: &str) -> String {
    sqlx::query_scalar::<_, String>("SELECT name FROM stock_basic WHERE code = ? LIMIT 1")
        .bind(code)
        .fetch_optional(pool)
        .await
        .ok()
        .flatten()
        .unwrap_or_else(|| code.to_string())
}

/// GET /api/kline?code=600000&adj=forward
pub async fn get_kline(
    State(state): State<AppState>,
    Query(query): Query<KlineQuery>,
) -> Result<Json<ApiResponse<KlineResponse>>, AppError> {
    let provider = TdxDataProvider::new();
    
    let adj_type = match query.adj.to_lowercase().as_str() {
        "forward" | "qfq" => AdjType::Forward,
        "backward" | "hfq" => AdjType::Backward,
        _ => AdjType::None,
    };
    
    // 从数据库获取股票名称
    let name = get_stock_name_from_db(&state.mysql_pool, &query.code).await;
    let stock_info = StockInfo {
        code: query.code.clone(),
        name,
    };
    
    match provider.get_kline(&query.code, adj_type, None) {
        Ok(data) => {
            let klines: Vec<KlineData> = data.into_iter().map(|d| {
                KlineData {
                    time: date_to_timestamp(d.date),
                    open: d.open,
                    high: d.high,
                    low: d.low,
                    close: d.close,
                    volume: d.vol as f32,
                }
            }).collect();
            
            let response = KlineResponse { stock: stock_info, kline: klines };
            Ok(Json(ApiResponse::success(response)))
        }
        Err(e) => {
            Err(AppError::BadRequest(format!("K线数据获取失败: {}", e)))
        }
    }
}

/// 随机获取一只股票
pub async fn get_random_stock(
    State(state): State<AppState>,
) -> Result<Json<ApiResponse<serde_json::Value>>, AppError> {
    let result = sqlx::query_scalar::<_, String>(
        "SELECT code FROM stock_basic ORDER BY RAND() LIMIT 1"
    )
    .fetch_optional(&state.mysql_pool)
    .await;

    match result {
        Ok(Some(code)) => Ok(Json(ApiResponse::success(serde_json::json!({ "code": code })))),
        Ok(None) => Ok(Json(ApiResponse::success(serde_json::json!({ "code": "000001" })))),
        Err(e) => Err(AppError::BadRequest(e.to_string())),
    }
}

/// GET /api/kline/batch?codes=600000,000001&adj=forward
pub async fn get_kline_batch(
    State(state): State<AppState>,
    Query(query): Query<BatchKlineQuery>,
) -> Result<Json<ApiResponse<serde_json::Value>>, AppError> {
    let provider = TdxDataProvider::new();
    
    let adj_type = match query.adj.to_lowercase().as_str() {
        "forward" | "qfq" => AdjType::Forward,
        "backward" | "hfq" => AdjType::Backward,
        _ => AdjType::None,
    };
    
    let codes: Vec<&str> = query.codes.split(',').map(|s| s.trim()).collect();
    let results = provider.get_klines(&codes, adj_type, None);
    
    let mut response_map = serde_json::Map::new();
    for (code, data) in results {
        let name = get_stock_name_from_db(&state.mysql_pool, &code).await;
        let stock_info = StockInfo {
            code: code.clone(),
            name,
        };
        let klines: Vec<KlineData> = data.into_iter().map(|d| {
            KlineData {
                time: date_to_timestamp(d.date),
                open: d.open,
                high: d.high,
                low: d.low,
                close: d.close,
                volume: d.vol as f32,
            }
        }).collect();
        let item = KlineResponse { stock: stock_info, kline: klines };
        response_map.insert(code, serde_json::json!(item));
    }
    
    Ok(Json(ApiResponse::success(serde_json::Value::Object(response_map))))
}

/// 批量查询参数
#[derive(Debug, Deserialize)]
pub struct BatchKlineQuery {
    /// 股票代码列表，逗号分隔，如 600000,000001
    pub codes: String,
    /// 复权类型: none, forward
    #[serde(default = "default_adj")]
    pub adj: String,
}

// ==================== 回测接口 ====================

/// 回测查询参数
#[derive(Debug, Deserialize)]
pub struct BacktestQuery {
    /// 股票代码，如 600000
    pub code: String,
    /// 复权类型: none, forward (默认前复权)
    #[serde(default = "default_adj")]
    pub adj: String,
    /// MA快线周期
    #[serde(default)]
    pub ma_fast: Option<usize>,
    /// MA慢线周期
    #[serde(default)]
    pub ma_slow: Option<usize>,
    /// MA斜率周期
    #[serde(default)]
    pub ma_slope_period: Option<usize>,
    /// MACD短期
    #[serde(default)]
    pub macd_short: Option<usize>,
    /// MACD长期
    #[serde(default)]
    pub macd_long: Option<usize>,
    /// MACD信号线
    #[serde(default)]
    pub macd_signal: Option<usize>,
    /// OBV均线周期
    #[serde(default)]
    pub obv_ma_period: Option<usize>,
    /// 突破天数
    #[serde(default)]
    pub breakout_days: Option<usize>,
    /// 上涨连续窗口
    #[serde(default)]
    pub up_streak_window: Option<usize>,
    /// 上涨连续天数
    #[serde(default)]
    pub up_streak_days: Option<usize>,
    /// 下跌连续窗口
    #[serde(default)]
    pub down_streak_window: Option<usize>,
    /// 下跌连续天数
    #[serde(default)]
    pub down_streak_days: Option<usize>,
    /// 涨幅比例
    #[serde(default)]
    pub increase_rate: Option<f64>,
    /// 跌幅比例
    #[serde(default)]
    pub decrease_rate: Option<f64>,
    /// 上涨权重
    #[serde(default)]
    pub weight_up: Option<f64>,
    /// 下跌权重
    #[serde(default)]
    pub weight_down: Option<f64>,
    /// 买入条件1
    #[serde(default)]
    pub buy_1: Option<usize>,
    /// 买入条件2
    #[serde(default)]
    pub buy_2: Option<usize>,
    /// 买入条件3
    #[serde(default)]
    pub buy_3: Option<usize>,
    /// 买入条件4
    #[serde(default)]
    pub buy_4: Option<usize>,
    /// 买入条件5
    #[serde(default)]
    pub buy_5: Option<usize>,
    /// 买入条件6
    #[serde(default)]
    pub buy_6: Option<usize>,
    /// 买入条件7
    #[serde(default)]
    pub buy_7: Option<usize>,
    /// 买入条件8
    #[serde(default)]
    pub buy_8: Option<usize>,
    /// 买入条件9
    #[serde(default)]
    pub buy_9: Option<usize>,
    /// 买入条件10
    #[serde(default)]
    pub buy_10: Option<usize>,
    /// 买入条件11
    #[serde(default)]
    pub buy_11: Option<usize>,
    /// 卖出条件1
    #[serde(default)]
    pub sell_1: Option<usize>,
    /// 卖出条件2
    #[serde(default)]
    pub sell_2: Option<usize>,
    /// 卖出条件3
    #[serde(default)]
    pub sell_3: Option<usize>,
    /// 卖出条件4
    #[serde(default)]
    pub sell_4: Option<usize>,
    /// 卖出条件5
    #[serde(default)]
    pub sell_5: Option<usize>,
    /// 卖出条件6
    #[serde(default)]
    pub sell_6: Option<usize>,
    /// 卖出条件7
    #[serde(default)]
    pub sell_7: Option<usize>,
    /// 卖出条件8
    #[serde(default)]
    pub sell_8: Option<usize>,
    /// 卖出条件9
    #[serde(default)]
    pub sell_9: Option<usize>,
    /// 卖出条件10
    #[serde(default)]
    pub sell_10: Option<usize>,
    /// 卖出条件11
    #[serde(default)]
    pub sell_11: Option<usize>,
}

use crate::seek::strategy_opt::StrategyParams;

/// 回测结果响应
#[derive(Debug, Serialize)]
pub struct BacktestResponse {
    pub stock: StockInfo,
    pub result: BacktestResultData,
}

/// 回测结果数据
#[derive(Debug, Serialize)]
pub struct BacktestResultData {
    pub sharpe: f64,
    pub ann_ret_pct: f64,
    pub max_dd_pct: f64,
    pub trade_count: i32,
    pub signals: Vec<SignalData>,
    pub equity: Vec<EquityData>,
}

/// 信号数据
#[derive(Debug, Serialize)]
pub struct SignalData {
    pub time: i64,
    pub signal: i32, // 1=买入, -1=卖出
}

/// 资产曲线数据
#[derive(Debug, Serialize)]
pub struct EquityData {
    pub time: i64,
    pub equity: f64,
}

/// GET /api/backtest?code=600000&adj=forward
pub async fn get_backtest(
    State(state): State<AppState>,
    Query(query): Query<BacktestQuery>,
) -> Result<Json<ApiResponse<BacktestResponse>>, AppError> {
    let provider = TdxDataProvider::new();

    let adj_type = match query.adj.to_lowercase().as_str() {
        "forward" | "qfq" => AdjType::Forward,
        "backward" | "hfq" => AdjType::Backward,
        _ => AdjType::None,
    };

    // 获取股票名称
    let name = get_stock_name_from_db(&state.mysql_pool, &query.code).await;
    let stock_info = StockInfo {
        code: query.code.clone(),
        name,
    };

    match provider.get_kline(&query.code, adj_type, None) {
        Ok(data) => {
            // 构建策略参数
            let strategy_params = StrategyParams {
                ma_fast: query.ma_fast.unwrap_or(20),
                ma_slow: query.ma_slow.unwrap_or(60),
                ma_slope_period: query.ma_slope_period.unwrap_or(5),
                macd_short: query.macd_short.unwrap_or(12),
                macd_long: query.macd_long.unwrap_or(26),
                macd_signal: query.macd_signal.unwrap_or(9),
                obv_ma_period: query.obv_ma_period.unwrap_or(30),
                breakout_days: query.breakout_days.unwrap_or(3),
                up_streak_window: query.up_streak_window.unwrap_or(5),
                up_streak_days: query.up_streak_days.unwrap_or(3),
                down_streak_window: query.down_streak_window.unwrap_or(5),
                down_streak_days: query.down_streak_days.unwrap_or(3),
                increase_rate: query.increase_rate.unwrap_or(1.0),
                decrease_rate: query.decrease_rate.unwrap_or(1.0),
                weight_up: query.weight_up.unwrap_or(0.85),
                weight_down: query.weight_down.unwrap_or(0.85),
                buy_1: query.buy_1.unwrap_or(1),
                buy_2: query.buy_2.unwrap_or(1),
                buy_3: query.buy_3.unwrap_or(1),
                buy_4: query.buy_4.unwrap_or(1),
                buy_5: query.buy_5.unwrap_or(1),
                buy_6: query.buy_6.unwrap_or(1),
                buy_7: query.buy_7.unwrap_or(1),
                buy_8: query.buy_8.unwrap_or(1),
                buy_9: query.buy_9.unwrap_or(1),
                buy_10: query.buy_10.unwrap_or(1),
                buy_11: query.buy_11.unwrap_or(1),
                sell_1: query.sell_1.unwrap_or(1),
                sell_2: query.sell_2.unwrap_or(1),
                sell_3: query.sell_3.unwrap_or(1),
                sell_4: query.sell_4.unwrap_or(1),
                sell_5: query.sell_5.unwrap_or(1),
                sell_6: query.sell_6.unwrap_or(1),
                sell_7: query.sell_7.unwrap_or(1),
                sell_8: query.sell_8.unwrap_or(1),
                sell_9: query.sell_9.unwrap_or(1),
                sell_10: query.sell_10.unwrap_or(1),
                sell_11: query.sell_11.unwrap_or(1),
            };

            // 运行回测
            let backtest_result = run_backtest(&data, Some(&strategy_params));

            // 转换信号数据
            let signals: Vec<SignalData> = backtest_result.signals.iter().enumerate()
                .filter(|(_, &s)| s != 0)
                .map(|(i, &s)| SignalData {
                    time: date_to_timestamp(data[i].date),
                    signal: s,
                })
                .collect();

            // 转换资产曲线
            let equity: Vec<EquityData> = backtest_result.equity.iter().enumerate()
                .map(|(i, &e)| EquityData {
                    time: date_to_timestamp(data[i].date),
                    equity: e,
                })
                .collect();

            let backtest_data = BacktestResultData {
                sharpe: backtest_result.sharpe,
                ann_ret_pct: backtest_result.ann_ret_pct,
                max_dd_pct: backtest_result.max_dd_pct,
                trade_count: backtest_result.trade_count,
                signals,
                equity,
            };

            let response = BacktestResponse {
                stock: stock_info,
                result: backtest_data,
            };

            Ok(Json(ApiResponse::success(response)))
        }
        Err(e) => {
            Err(AppError::BadRequest(format!("回测数据获取失败: {}", e)))
        }
    }
}
