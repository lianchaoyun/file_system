//! 参数寻优 API Handler
//! POST /api/optimize - 启动寻优任务（添加到队列）
//! GET /api/optimize/status - 查询寻优进度
//! GET /api/optimize/history/{task_id} - 按ID查询历史结果
//! GET /api/optimize/list - 列出最近记录

use crate::web::AppState;
use crate::error::AppError;
use crate::seek::opt_data::{OptStatusResponse, OptTaskData, OPT_KEY_PREFIX, OPT_EXPIRE_SECS, OPT_QUEUE_KEY};
use crate::utils::maker::generate_short_id;
use axum::extract::{Path, State};
use axum::Json;
use serde::Deserialize;
use redis::AsyncCommands;
use tracing::info;

#[derive(Deserialize)]
pub struct OptimizeRequest {
    pub symbol: String,
    pub adj_type: Option<String>,
    pub max_combinations: Option<usize>,
}

/// 启动寻优任务（添加到队列，由 opt_server 后台服务处理）
pub async fn start_optimize(
    State(state): State<AppState>,
    Json(req): Json<OptimizeRequest>,
) -> Result<Json<serde_json::Value>, AppError> {
    let mut redis = state.redis_pool.get().await
        .map_err(|_| AppError::BadRequest("Redis连接失败".into()))?;

    let symbol = req.symbol.clone();
    let adj_type = req.adj_type.clone().unwrap_or_else(|| "forward".to_string());
    let max_combinations = req.max_combinations.unwrap_or(100000);
    let task_id = generate_short_id();
    let task_id_for_response = task_id.clone();

    info!("[OPT] 收到寻优请求: symbol={}, adj_type={}, max_combinations={}, task_id={}",
          symbol, adj_type, max_combinations, task_id);

    // 初始化任务状态（pending 等待队列处理）
    let task_data = OptTaskData {
        task_id: task_id.clone(),
        status: "pending".to_string(),
        progress: 0.0,
        total: max_combinations,
        processed: 0,
        error: None,
        results: vec![],
    };

    // 保存到 Redis
    let task_key = format!("{}current", OPT_KEY_PREFIX);
    let task_json = serde_json::to_string(&task_data).unwrap();
    let _: Result<(), _> = redis.set_ex(&task_key, &task_json, OPT_EXPIRE_SECS).await;
    let _: Result<(), _> = redis.set_ex(&format!("{}{}", OPT_KEY_PREFIX, &task_id), &task_json, OPT_EXPIRE_SECS).await;

    // 添加到任务队列
    let queue_item = serde_json::json!({
        "task_id": task_id,
        "symbol": symbol,
        "adj_type": adj_type,
        "max_combinations": max_combinations,
        "created_at": chrono::Utc::now().timestamp(),
    });
    let _: Result<(), _> = redis.lpush::<_, _, ()>(OPT_QUEUE_KEY, &queue_item.to_string()).await;

    info!("[OPT] 任务已加入队列: task_id={}", task_id_for_response);

    Ok(Json(serde_json::json!({
        "errcode": 0,
        "errmsg": "寻优任务已加入队列",
        "task_id": task_id_for_response
    })))
}

/// 查询当前寻优进度
pub async fn get_status(
    State(state): State<AppState>,
) -> Result<Json<OptStatusResponse>, AppError> {
    let mut redis = state.redis_pool.get().await
        .map_err(|_| AppError::BadRequest("Redis连接失败".into()))?;

    let task_key = format!("{}current", OPT_KEY_PREFIX);

    match redis.get::<_, String>(&task_key).await {
        Ok(json_str) => {
            match serde_json::from_str::<OptTaskData>(&json_str) {
                Ok(task) => Ok(Json(OptStatusResponse::from(task))),
                Err(_) => Ok(Json(OptStatusResponse::default())),
            }
        }
        Err(_) => Ok(Json(OptStatusResponse::default())),
    }
}

/// 按 task_id 查询历史任务结果
pub async fn get_history(
    State(state): State<AppState>,
    Path(task_id): Path<String>,
) -> Result<Json<OptStatusResponse>, AppError> {
    let mut redis = state.redis_pool.get().await
        .map_err(|_| AppError::BadRequest("Redis连接失败".into()))?;

    let task_key = format!("{}{}", OPT_KEY_PREFIX, task_id);

    match redis.get::<_, String>(&task_key).await {
        Ok(json_str) => {
            match serde_json::from_str::<OptTaskData>(&json_str) {
                Ok(task) => Ok(Json(OptStatusResponse::from(task))),
                Err(_) => Err(AppError::BadRequest("任务不存在".into())),
            }
        }
        Err(_) => Err(AppError::BadRequest("任务不存在".into())),
    }
}

/// 列出最近的寻优记录
pub async fn get_list(
    State(state): State<AppState>,
) -> Result<Json<serde_json::Value>, AppError> {
    let mut redis = state.redis_pool.get().await
        .map_err(|_| AppError::BadRequest("Redis连接失败".into()))?;

    // 获取当前任务
    let task_key = format!("{}current", OPT_KEY_PREFIX);
    let current = redis.get::<_, String>(&task_key).await.ok()
        .and_then(|s| serde_json::from_str::<OptTaskData>(&s).ok());

    // 获取历史列表
    let list_key = format!("{}list", OPT_KEY_PREFIX);
    let list: Vec<String> = redis.lrange(&list_key, 0, 9).await.unwrap_or_default();

    let mut tasks = vec![];
    for tid in list.iter().take(10) {
        if let Ok(json_str) = redis.get::<_, String>(&format!("{}{}", OPT_KEY_PREFIX, tid)).await {
            if let Ok(task) = serde_json::from_str::<OptTaskData>(&json_str) {
                if task.status == "completed" {
                    let ann_ret = task.results.first()
                        .and_then(|r| r.get("ann_ret"))
                        .and_then(|v| v.as_f64())
                        .unwrap_or(0.0);
                    let sharpe = task.results.first()
                        .and_then(|r| r.get("sharpe"))
                        .and_then(|v| v.as_f64())
                        .unwrap_or(0.0);
                    tasks.push(serde_json::json!({
                        "task_id": task.task_id,
                        "status": task.status,
                        "total": task.total,
                        "processed": task.processed,
                        "ann_ret": ann_ret,
                        "sharpe": sharpe,
                    }));
                }
            }
        }
    }

    let current_info = current.map(|t| serde_json::json!({
        "task_id": t.task_id,
        "status": t.status,
        "progress": t.progress,
        "total": t.total,
        "processed": t.processed,
    }));

    Ok(Json(serde_json::json!({
        "errcode": 0,
        "current": current_info,
        "history": tasks
    })))
}
