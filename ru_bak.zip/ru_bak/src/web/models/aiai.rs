//! aiai 量化交易模块的数据模型（web 层通用）

use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct TradeAccountRow {
    pub id: i64,
    pub name: String,
    pub exchange: String,
    pub api_key: String,
    pub secret_key: String,
    pub passphrase: String,
    pub login_id: String,
    pub login_pwd: String,
    pub is_testnet: i32,
    pub enabled: i32,
    pub sort_order: i32,
    pub remark: String,
    pub created_at: Option<String>,
    pub updated_at: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct StrategyConfigRow {
    pub id: i64,
    pub name: String,
    pub enabled: i32,
    pub priority: i32,
    pub sort_order: i32,
    pub market_type: String,
    pub symbols: String,
    pub timeframes: String,
    pub data_source: String,
    pub market_extra: String,
    pub factor_type: String,
    pub factor_extra: String,
    pub portfolio_type: String,
    pub portfolio_extra: String,
    pub risk_type: String,
    pub risk_extra: String,
    pub execution_type: String,
    pub execution_extra: String,
    pub account_id: i64,
    pub initial_balance: f64,
    pub created_at: Option<String>,
    pub updated_at: Option<String>,
}

/// trade_data_source 表行（供 data_layer 从 DB 加载活跃数据源）
#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct DataSourceRow {
    pub id: u64,
    pub source_type: String,
    pub symbol: String,
    pub timeframes: String,
    pub enabled: i32,
    pub sort_order: i32,
    pub remark: Option<String>,
    pub created_at: Option<String>,
    pub updated_at: Option<String>,
}
