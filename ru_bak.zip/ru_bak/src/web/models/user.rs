use chrono::{DateTime, Utc};
use serde::{self, Deserialize, Serialize};
use sqlx::FromRow;

#[derive(Debug, Serialize)]
pub struct ApiResponse<T: Serialize> {
    pub code: u32,
    pub msg: String,
    pub data: Option<T>,
}

impl<T: Serialize> ApiResponse<T> {
    pub fn success(data: T) -> Self {
        Self {
            code: 200,
            msg: "success".to_string(),
            data: Some(data),
        }
    }
    pub fn fail(msg: impl Into<String>) -> Self {
        Self {
            code: 400,
            msg: msg.into(),
            data: None,
        }
    }
}

#[derive(Debug, Serialize, Deserialize, FromRow, Clone)]
pub struct User {
    pub id: u64,
    pub account: Option<String>,
    pub email: Option<String>,
    pub password: String,
    pub token: Option<String>,
    pub nickname: Option<String>,
    pub avatar_url: Option<String>,
    pub bio: Option<String>,
    pub register_time: DateTime<Utc>,
    pub update_time: DateTime<Utc>,
    pub activation_key: Option<String>,
    pub status: i32,
    pub balance: f64,
}

#[derive(Debug, Deserialize)]
pub struct LoginRequest {
    pub account: String,
    pub password: String,
    pub request_id: String,
}

#[derive(Debug, Serialize)]
pub struct LoginResponse {
    pub id: u64,
    pub account: Option<String>,
    pub token: String,
    pub nickname: Option<String>,
    pub email: Option<String>,
    pub avatar_url: Option<String>,
    pub bio: Option<String>,
    pub register_time: DateTime<Utc>,
    pub update_time: DateTime<Utc>,
    pub balance: f64,
}

#[derive(Debug, Deserialize)]
pub struct RegisterRequest {
    pub account: String,
    pub password: String,
    pub request_id: String,
}

#[derive(Debug, Serialize)]
pub struct RegisterResponse {
    pub id: u64,
    pub account: String,
}

#[derive(Debug, Deserialize)]
pub struct UserProfileRequest {
    pub id: u64,
    pub token: String,
    pub request_id: String,
}

#[derive(Debug, Serialize)]
pub struct UserProfileResponse {
    pub token: Option<String>,
    pub id: u64,
    pub account: Option<String>,
    pub email: Option<String>,
    pub nickname: Option<String>,
    pub avatar_url: Option<String>,
    pub register_time: DateTime<Utc>,
    pub bio: Option<String>,
    pub balance: f64,
}

#[derive(Debug, Deserialize)]
pub struct LogoutRequest {
    pub token: String,
}

#[derive(Debug, Deserialize)]
pub struct UpdateUserRequest {
    pub token: String,
    pub id: Option<u64>,
    pub nickname: Option<String>,
    pub avatar_url: Option<String>,
    pub bio: Option<String>,
    pub account: Option<String>,
    pub email: Option<String>,
    pub password: Option<String>,
    pub password_new: Option<String>,
    pub request_id: String,
}

#[derive(Debug, Deserialize)]
pub struct OptionsRequest {
    pub group: Option<String>,
    pub name: Option<String>,
}

#[derive(Debug, Serialize, Deserialize, FromRow, Clone)]
pub struct OptionItem {
    pub group: Option<String>,
    pub name: Option<String>,
    pub value: Option<String>,
}
