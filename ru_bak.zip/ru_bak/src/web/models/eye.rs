//! eye 量化桌面应用的数据模型（数据库表映射，web 层通用）
//!
//! 注：ScheduledTask 留在 eye/models.rs，因其依赖 cron crate。

// ── 持仓 ──────────────────────────────────────────────

#[derive(Debug, Clone)]
pub struct PositionRecord {
    pub market: String,
    pub symbol: String,
    pub name: String,
    pub direction: String,
    pub quantity: f64,
    pub avg_price: f64,
    pub current_price: f64,
    pub market_value: f64,
    #[allow(dead_code)]
    pub update_time: String,
    pub first_buy_time: String,
}

// ── 自选股 ────────────────────────────────────────────

#[derive(Debug, Clone)]
pub struct WatchlistRecord {
    pub id: i64,
    pub market: String,
    pub symbol: String,
    pub name: String,
    pub is_monitoring: bool,
    pub monitor_status: String,
    pub monitor_params: String,
    pub current_price: f64,
    pub remark: String,
    pub update_time: String,
    pub create_at: String,
}

// ── 复盘 ──────────────────────────────────────────────

#[derive(Debug, Clone)]
pub struct FupanRecord {
    pub id: i64,
    pub market: String,
    pub symbol: String,
    pub name: String,
    pub create_at: String,
}

// ── 任务 ──────────────────────────────────────────────

#[derive(Debug, Clone)]
pub struct Task {
    pub id: u64,
    pub name: String,
    pub description: String,
    pub exec_type: String,
    pub command: String,
    pub working_dir: String,
    pub cron_expr: String,
    pub enabled: bool,
    pub status: String,
    #[allow(dead_code)]
    pub last_run: String,
    #[allow(dead_code)]
    pub last_result: String,
}

// ── 任务日志 ──────────────────────────────────────────

#[derive(Debug, Clone)]
pub struct TaskLogEntry {
    pub id: u64,
    #[allow(dead_code)]
    pub task_id: u64,
    pub task_name: String,
    pub status: String,
    pub output: String,
    pub error: String,
    pub start_time: String,
    #[allow(dead_code)]
    pub end_time: String,
    pub duration_ms: i64,
}

// ── 扫描策略 ──────────────────────────────────────────

#[derive(Debug, Clone)]
pub struct ScanStrategy {
    #[allow(dead_code)]
    pub id: u64,
    #[allow(dead_code)]
    pub code: String,
    pub name: String,
    #[allow(dead_code)]
    pub enabled: bool,
}

// ── 扫描结果 ──────────────────────────────────────────

#[derive(Debug, Clone)]
pub struct ScanResult {
    #[allow(dead_code)]
    pub id: u64,
    pub stock_code: String,
    pub stock_name: String,
    #[allow(dead_code)]
    pub strategy_id: u64,
    pub strategy_name: String,
    pub price: f64,
    pub change_pct: f64,
    pub sharpe: f64,
    pub annual_return: f64,
    #[allow(dead_code)]
    pub extra_data: String,
    pub scan_time: String,
}

/// 扫描结果输入（用于批量插入）
#[derive(Debug, Clone)]
#[allow(dead_code)]
pub struct ScanResultInput {
    pub stock_code: String,
    pub stock_name: String,
    pub strategy_id: u64,
    pub price: f64,
    pub change_pct: f64,
    pub sharpe: f64,
    pub annual_return: f64,
    pub extra_data: String,
}

impl From<&ScanResult> for ScanResultInput {
    fn from(r: &ScanResult) -> Self {
        Self {
            stock_code: r.stock_code.clone(),
            stock_name: r.stock_name.clone(),
            strategy_id: r.strategy_id,
            price: r.price,
            change_pct: r.change_pct,
            sharpe: r.sharpe,
            annual_return: r.annual_return,
            extra_data: r.extra_data.clone(),
        }
    }
}
