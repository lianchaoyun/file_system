use crate::error::AppError;
use crate::models::user::{OptionItem, UpdateUserRequest, User};
use sqlx::MySqlPool;
use crate::utils::cache::get_cache;

#[derive(Debug, Clone)]
pub struct UserRepository {
    pool: MySqlPool,
}

impl UserRepository {
    pub fn new(pool: MySqlPool) -> Self {
        Self { pool }
    }

    pub async fn find_by_account(&self, account: &str) -> Result<Option<User>, AppError> {
        let user = sqlx::query_as::<_, User>("SELECT * FROM users WHERE account = ?")
            .bind(account)
            .fetch_optional(&self.pool)
            .await?;
        Ok(user)
    }

    pub async fn find_by_token(&self, token: &str) -> Result<Option<User>, AppError> {
        let user = sqlx::query_as::<_, User>("SELECT * FROM users WHERE token = ?")
            .bind(token)
            .fetch_optional(&self.pool)
            .await?;
        Ok(user)
    }

    pub async fn update_token(
        &self,
        request_id: &str,
        id: u64,
        token: Option<&str>,
    ) -> Result<(), AppError> {
        let ip = get_cache().get(&format!("{}_ip", request_id));
        sqlx::query("UPDATE users SET token = ?,last_login_ip = ?,last_login_time = NOW(),login_times=login_times+1 WHERE ID = ?")
            .bind(token)
            .bind(ip)
            .bind(id)
            .execute(&self.pool)
            .await?;
        Ok(())
    }

    pub async fn create_user_by_account(
        &self,
        request_id: &str,
        account: &str,
        hashed_password: &str,
    ) -> Result<u64, sqlx::Error> {
        let ip = get_cache().get(&format!("{}_ip", request_id));
        let user_id = sqlx::query!(
            r#"INSERT INTO users (account, password, register_ip, register_time) VALUES (?, ?, ?, NOW())"#,
            account,
            hashed_password,
            ip
        )
        .execute(&self.pool)
        .await?
        .last_insert_id();
        Ok(user_id)
    }

    pub async fn create_user_by_email(
        &self,
        request_id: &str,
        email: &str,
        hashed_password: &str,
    ) -> Result<u64, sqlx::Error> {
        let ip = get_cache().get(&format!("{}_ip", request_id));
        let user_id = sqlx::query!(
            r#"INSERT INTO users (email, password, register_ip, register_time) VALUES (?, ?, ?, NOW())"#,
            email,
            hashed_password,
            ip
        )
        .execute(&self.pool)
        .await?
        .last_insert_id();
        Ok(user_id)
    }

    pub async fn update_user(&self, user: UpdateUserRequest) -> Result<Option<u64>, sqlx::Error> {
        let rows_affected = sqlx::query!(
            r#"UPDATE users SET avatar_url = COALESCE(?, avatar_url), account = COALESCE(?, account), email = COALESCE(?, email), nickname = COALESCE(?, nickname), bio = COALESCE(?, bio), update_time = NOW() WHERE id = ?"#,
            user.avatar_url,
            user.account,
            user.email,
            user.nickname,
            user.bio,
            user.id
        )
        .execute(&self.pool)
        .await?
        .rows_affected();

        if rows_affected == 0 {
            return Err(sqlx::Error::RowNotFound);
        }
        Ok(Some(rows_affected))
    }

    pub async fn update_password(&self, user: UpdateUserRequest) -> Result<Option<u64>, sqlx::Error> {
        let rs = sqlx::query("UPDATE users SET password = ? WHERE ID = ?")
            .bind(user.password_new)
            .bind(user.id)
            .execute(&self.pool)
            .await?;
        let rows_affected = rs.rows_affected();
        if rows_affected == 0 {
            return Err(sqlx::Error::RowNotFound);
        }
        Ok(Some(rows_affected))
    }

    pub async fn find_options(&self, name: &str, group: &str) -> Result<Option<OptionItem>, AppError> {
        let data = sqlx::query_as::<_, OptionItem>("SELECT * FROM options WHERE name = ? AND `group` = ?")
            .bind(name)
            .bind(group)
            .fetch_optional(&self.pool)
            .await?;
        Ok(data)
    }
}
