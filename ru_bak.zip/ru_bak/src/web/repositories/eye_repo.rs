//! Eye 量化桌面应用的数据访问层 —— 持仓/自选股/复盘/任务/扫描 CRUD
//!
//! 所有 eye 二进制的数据库操作统一在此处，供 eye 和 web 层共用。

use sqlx::{Row, MySqlPool};
use crate::models::eye::*;

#[derive(Debug, Clone)]
pub struct EyeRepository {
    pool: MySqlPool,
}

impl EyeRepository {
    pub fn new(pool: MySqlPool) -> Self {
        Self { pool }
    }

    // ═══════════════════════════════════════
    //  持仓操作
    // ═══════════════════════════════════════

    pub async fn load_positions(&self) -> Result<Vec<PositionRecord>, String> {
        let query = r#"
            SELECT
                COALESCE(market, '') as market,
                COALESCE(symbol, '') as symbol,
                COALESCE(name, '') as name,
                COALESCE(direction, '') as direction,
                CAST(COALESCE(quantity, 0) AS CHAR) as quantity,
                CAST(COALESCE(avg_price, 0) AS CHAR) as avg_price,
                CAST(COALESCE(current_price, 0) AS CHAR) as current_price,
                CAST(COALESCE(market_value, 0) AS CHAR) as market_value,
                COALESCE(DATE_FORMAT(update_time, '%Y-%m-%d %H:%i'), '') as update_time,
                COALESCE(DATE_FORMAT(first_buy_time, '%Y-%m-%d %H:%i'), '') as first_buy_time
            FROM positions
            WHERE quantity > 0
            ORDER BY COALESCE(market_value, 0) DESC
        "#;

        let rows = sqlx::query(query).fetch_all(&self.pool).await
            .map_err(|e| format!("查询 positions 失败: {}", e))?;

        let parse_f64 = |s: &str| -> f64 { s.parse().unwrap_or(0.0) };
        Ok(rows.iter().map(|row| PositionRecord {
            market: row.get::<&str, _>("market").to_string(),
            symbol: row.get::<&str, _>("symbol").to_string(),
            name: row.get::<&str, _>("name").to_string(),
            direction: row.get::<&str, _>("direction").to_string(),
            quantity: parse_f64(&row.get::<&str, _>("quantity")),
            avg_price: parse_f64(&row.get::<&str, _>("avg_price")),
            current_price: parse_f64(&row.get::<&str, _>("current_price")),
            market_value: parse_f64(&row.get::<&str, _>("market_value")),
            update_time: row.get::<&str, _>("update_time").to_string(),
            first_buy_time: row.get::<&str, _>("first_buy_time").to_string(),
        }).collect())
    }

    pub async fn get_positions_by_market(&self, market: &str) -> Result<Vec<PositionRecord>, String> {
        let query = r#"
            SELECT
                id,
                market,
                symbol,
                COALESCE(name, '') as name,
                direction,
                CAST(quantity AS DOUBLE) as quantity,
                CAST(avg_price AS DOUBLE) as avg_price,
                CAST(current_price AS DOUBLE) as current_price,
                CAST(market_value AS DOUBLE) as market_value,
                COALESCE(DATE_FORMAT(update_time, '%Y-%m-%d %H:%i'), '') as update_time,
                COALESCE(DATE_FORMAT(first_buy_time, '%Y-%m-%d'), '') as first_buy_time
            FROM positions
            WHERE market = ? AND quantity > 0
            ORDER BY market_value DESC
        "#;

        let rows = sqlx::query(query).bind(market).fetch_all(&self.pool).await
            .map_err(|e| format!("查询 positions 失败: {}", e))?;

        Ok(rows.iter().map(|row| PositionRecord {
            market: row.get("market"),
            symbol: row.get("symbol"),
            name: row.get("name"),
            direction: row.get("direction"),
            quantity: row.get("quantity"),
            avg_price: row.get("avg_price"),
            current_price: row.get("current_price"),
            market_value: row.get("market_value"),
            update_time: row.get("update_time"),
            first_buy_time: row.get("first_buy_time"),
        }).collect())
    }

    // ═══════════════════════════════════════
    //  自选股操作
    // ═══════════════════════════════════════

    pub async fn load_watchlist(&self) -> Result<Vec<WatchlistRecord>, String> {
        let query = r#"
            SELECT
                id,
                COALESCE(market, '') as market,
                COALESCE(symbol, '') as symbol,
                COALESCE(name, '') as name,
                is_monitoring,
                COALESCE(monitor_status, 'idle') as monitor_status,
                COALESCE(monitor_params, '') as monitor_params,
                CAST(COALESCE(current_price, 0) AS CHAR) as current_price,
                COALESCE(remark, '') as remark,
                COALESCE(DATE_FORMAT(update_time, '%Y-%m-%d %H:%i'), '') as update_time,
                COALESCE(DATE_FORMAT(create_at, '%Y-%m-%d %H:%i'), '') as create_at
            FROM watchlist
            ORDER BY id DESC
        "#;

        let rows = sqlx::query(query).fetch_all(&self.pool).await
            .map_err(|e| format!("查询 watchlist 失败: {}", e))?;

        let parse_f64 = |s: &str| -> f64 { s.parse().unwrap_or(0.0) };
        Ok(rows.iter().map(|row| WatchlistRecord {
            id: row.get::<i64, _>("id"),
            market: row.get::<&str, _>("market").to_string(),
            symbol: row.get::<&str, _>("symbol").to_string(),
            name: row.get::<&str, _>("name").to_string(),
            is_monitoring: row.get::<bool, _>("is_monitoring"),
            monitor_status: row.get::<&str, _>("monitor_status").to_string(),
            monitor_params: String::from_utf8_lossy(&row.get::<Vec<u8>, _>("monitor_params")).to_string(),
            current_price: parse_f64(&row.get::<&str, _>("current_price")),
            remark: row.get::<&str, _>("remark").to_string(),
            update_time: row.get::<&str, _>("update_time").to_string(),
            create_at: row.get::<&str, _>("create_at").to_string(),
        }).collect())
    }

    pub async fn get_watchlist_by_market(&self, market: &str) -> Result<Vec<WatchlistRecord>, String> {
        let query = r#"
            SELECT
                id, market, symbol,
                COALESCE(name, '') as name,
                is_monitoring,
                COALESCE(monitor_status, 'idle') as monitor_status,
                COALESCE(monitor_params, '') as monitor_params,
                CAST(0.0 AS DOUBLE) as current_price,
                COALESCE(remark, '') as remark,
                COALESCE(DATE_FORMAT(update_time, '%Y-%m-%d %H:%i'), '') as update_time,
                COALESCE(DATE_FORMAT(create_at, '%Y-%m-%d'), '') as create_at
            FROM watchlist
            WHERE market = ?
            ORDER BY id
        "#;

        let rows = sqlx::query(query).bind(market).fetch_all(&self.pool).await
            .map_err(|e| format!("查询 watchlist 失败: {}", e))?;

        Ok(rows.iter().map(|row| WatchlistRecord {
            id: row.get("id"),
            market: row.get("market"),
            symbol: row.get("symbol"),
            name: row.get("name"),
            is_monitoring: row.get("is_monitoring"),
            monitor_status: row.get("monitor_status"),
            monitor_params: String::from_utf8_lossy(&row.get::<Vec<u8>, _>("monitor_params")).to_string(),
            current_price: row.get("current_price"),
            remark: row.get("remark"),
            update_time: row.get("update_time"),
            create_at: row.get("create_at"),
        }).collect())
    }

    pub async fn add_to_watchlist(&self, market: &str, symbol: &str, name: &str, remark: &str, is_monitoring: bool, monitor_params: &str) -> Result<(), String> {
        // 检查是否已存在
        let existing = sqlx::query("SELECT id FROM watchlist WHERE symbol = ?")
            .bind(symbol)
            .fetch_one(&self.pool)
            .await;
        if existing.is_ok() {
            return Err("该股票已在自选列表中".to_string());
        }

        let monitor_params_opt = if monitor_params.is_empty() { None } else { Some(monitor_params) };
        sqlx::query(
            "INSERT INTO watchlist (market, symbol, name, remark, is_monitoring, monitor_params, current_price, update_time) VALUES (?, ?, ?, ?, ?, ?, 0, NOW())"
        )
        .bind(market).bind(symbol).bind(name).bind(remark)
        .bind(is_monitoring).bind(monitor_params_opt)
        .execute(&self.pool).await
        .map_err(|e| format!("添加 watchlist 失败: {}", e))?;
        Ok(())
    }

    pub async fn delete_from_watchlist(&self, symbol: &str) -> Result<(), String> {
        sqlx::query("DELETE FROM watchlist WHERE symbol = ?")
            .bind(symbol)
            .execute(&self.pool).await
            .map_err(|e| format!("删除 watchlist 失败: {}", e))?;
        Ok(())
    }

    pub async fn update_watchlist(&self, original_symbol: &str, market: &str, symbol: &str, name: &str, remark: &str, is_monitoring: bool, monitor_params: &str) -> Result<(), String> {
        if original_symbol != symbol {
            let existing = sqlx::query("SELECT id FROM watchlist WHERE symbol = ?")
                .bind(symbol)
                .fetch_one(&self.pool)
                .await;
            if existing.is_ok() {
                return Err("该股票代码已在自选列表中".to_string());
            }
        }

        let monitor_params_opt = if monitor_params.is_empty() { None } else { Some(monitor_params) };
        sqlx::query(
            "UPDATE watchlist SET market = ?, symbol = ?, name = ?, remark = ?, is_monitoring = ?, monitor_params = ? WHERE symbol = ?"
        )
        .bind(market).bind(symbol).bind(name).bind(remark)
        .bind(is_monitoring).bind(monitor_params_opt).bind(original_symbol)
        .execute(&self.pool).await
        .map_err(|e| format!("修改 watchlist 失败: {}", e))?;
        Ok(())
    }

    // ═══════════════════════════════════════
    //  复盘操作
    // ═══════════════════════════════════════

    pub async fn load_fupan_list(&self) -> Result<Vec<FupanRecord>, String> {
        let query = r#"
            SELECT id, market, symbol,
                   COALESCE(name, '') as name,
                   COALESCE(create_at, '') as create_at
            FROM stock_fupan
            ORDER BY id ASC
        "#;

        let rows = sqlx::query(query).fetch_all(&self.pool).await
            .map_err(|e| format!("查询 stock_fupan 失败: {}", e))?;

        Ok(rows.iter().map(|row| FupanRecord {
            id: row.get("id"),
            market: row.get("market"),
            symbol: row.get("symbol"),
            name: row.get("name"),
            create_at: row.get("create_at"),
        }).collect())
    }

    pub async fn add_to_fupan(&self, market: &str, symbol: &str, name: &str) -> Result<(), String> {
        sqlx::query("INSERT INTO stock_fupan (market, symbol, name) VALUES (?, ?, ?)")
            .bind(market).bind(symbol).bind(name)
            .execute(&self.pool).await
            .map_err(|e| format!("添加 stock_fupan 失败: {}", e))?;
        Ok(())
    }

    pub async fn delete_from_fupan(&self, id: i64) -> Result<(), String> {
        sqlx::query("DELETE FROM stock_fupan WHERE id = ?")
            .bind(id)
            .execute(&self.pool).await
            .map_err(|e| format!("删除 stock_fupan 失败: {}", e))?;
        Ok(())
    }

    pub async fn clear_fupan_list(&self) -> Result<(), String> {
        sqlx::query("DELETE FROM stock_fupan")
            .execute(&self.pool).await
            .map_err(|e| format!("清空 stock_fupan 失败: {}", e))?;
        Ok(())
    }

    // ═══════════════════════════════════════
    //  任务操作
    // ═══════════════════════════════════════

    pub async fn load_tasks(&self) -> Result<Vec<Task>, String> {
        let query = r#"
            SELECT
                id,
                COALESCE(name, '') as name,
                COALESCE(description, '') as description,
                COALESCE(exec_type, 'shell') as exec_type,
                COALESCE(command, '') as command,
                COALESCE(working_dir, '') as working_dir,
                COALESCE(cron_expr, '0 * * * *') as cron_expr,
                enabled,
                COALESCE(status, 'idle') as status,
                COALESCE(DATE_FORMAT(last_run, '%Y-%m-%d %H:%i:%s'), '') as last_run,
                COALESCE(last_result, '') as last_result
            FROM task
            ORDER BY id DESC
        "#;

        let rows = sqlx::query(query).fetch_all(&self.pool).await
            .map_err(|e| format!("查询 task 失败: {}", e))?;

        Ok(rows.iter().map(|row| Task {
            id: row.get::<u64, _>("id"),
            name: row.get::<&str, _>("name").to_string(),
            description: row.get::<&str, _>("description").to_string(),
            exec_type: row.get::<&str, _>("exec_type").to_string(),
            command: row.get::<&str, _>("command").to_string(),
            working_dir: row.get::<&str, _>("working_dir").to_string(),
            cron_expr: row.get::<&str, _>("cron_expr").to_string(),
            enabled: row.get::<i8, _>("enabled") != 0,
            status: row.get::<&str, _>("status").to_string(),
            last_run: row.get::<&str, _>("last_run").to_string(),
            last_result: row.get::<&str, _>("last_result").to_string(),
        }).collect())
    }

    pub async fn load_enabled_tasks(&self) -> Result<Vec<Task>, String> {
        let query = r#"
            SELECT id, name, exec_type, command, COALESCE(working_dir, '') as working_dir, cron_expr
            FROM task WHERE enabled = 1
        "#;

        let rows = sqlx::query(query).fetch_all(&self.pool).await
            .map_err(|e| format!("查询 task 失败: {}", e))?;

        Ok(rows.iter().map(|row| Task {
            id: row.get::<u64, _>("id"),
            name: row.get::<&str, _>("name").to_string(),
            description: String::new(),
            exec_type: row.get::<&str, _>("exec_type").to_string(),
            command: row.get::<&str, _>("command").to_string(),
            working_dir: row.get::<&str, _>("working_dir").to_string(),
            cron_expr: row.get::<&str, _>("cron_expr").to_string(),
            enabled: true,
            status: "idle".to_string(),
            last_run: String::new(),
            last_result: String::new(),
        }).collect())
    }

    pub async fn get_task_by_id(&self, task_id: u64) -> Result<Option<(String, String, String, Option<String>)>, String> {
        let query = "SELECT name, exec_type, command, working_dir FROM task WHERE id = ?";
        let row = sqlx::query(query).bind(task_id).fetch_one(&self.pool).await;
        match row {
            Ok(row) => Ok(Some((
                row.get::<String, _>("name"),
                row.get::<String, _>("exec_type"),
                row.get::<String, _>("command"),
                row.get::<Option<String>, _>("working_dir"),
            ))),
            Err(_) => Ok(None),
        }
    }

    pub async fn add_task(&self, name: &str, description: &str, exec_type: &str, command: &str, working_dir: &str, cron_expr: &str) -> Result<(), String> {
        sqlx::query(
            "INSERT INTO task (name, description, exec_type, command, working_dir, cron_expr, enabled, status) VALUES (?, ?, ?, ?, ?, ?, 1, 'idle')"
        )
        .bind(name).bind(description).bind(exec_type).bind(command)
        .bind(working_dir).bind(cron_expr)
        .execute(&self.pool).await
        .map_err(|e| format!("插入 task 失败: {}", e))?;
        Ok(())
    }

    pub async fn update_task(&self, task_id: u64, name: &str, description: &str, exec_type: &str, command: &str, working_dir: &str, cron_expr: &str) -> Result<(), String> {
        sqlx::query(
            "UPDATE task SET name = ?, description = ?, exec_type = ?, command = ?, working_dir = ?, cron_expr = ? WHERE id = ?"
        )
        .bind(name).bind(description).bind(exec_type).bind(command)
        .bind(working_dir).bind(cron_expr).bind(task_id)
        .execute(&self.pool).await
        .map_err(|e| format!("更新 task 失败: {}", e))?;
        Ok(())
    }

    pub async fn delete_task(&self, task_id: u64) -> Result<(), String> {
        sqlx::query("DELETE FROM task WHERE id = ?")
            .bind(task_id)
            .execute(&self.pool).await
            .map_err(|e| format!("删除 task 失败: {}", e))?;
        Ok(())
    }

    pub async fn toggle_task_enabled(&self, task_id: u64, enabled: bool) -> Result<(), String> {
        let new_enabled: i8 = if enabled { 0 } else { 1 };
        sqlx::query("UPDATE task SET enabled = ? WHERE id = ?")
            .bind(new_enabled).bind(task_id)
            .execute(&self.pool).await
            .map_err(|e| format!("更新 task enabled 失败: {}", e))?;
        Ok(())
    }

    // ── 任务执行相关（供 tasks.rs 使用）──

    pub async fn update_task_status_running(&self, task_id: u64) {
        let _ = sqlx::query("UPDATE task SET status = 'running' WHERE id = ?")
            .bind(task_id)
            .execute(&self.pool)
            .await;
    }

    pub async fn insert_task_log(&self, task_id: u64) -> Option<i64> {
        sqlx::query("INSERT INTO task_log (task_id, status, start_time) VALUES (?, 'running', NOW())")
            .bind(task_id)
            .execute(&self.pool)
            .await
            .ok()
            .map(|r| r.last_insert_id() as i64)
    }

    pub async fn update_task_log(&self, log_id: i64, status: &str, output: &str, error: &str, duration_ms: i64) {
        let _ = sqlx::query(
            "UPDATE task_log SET status = ?, output = ?, error = ?, end_time = NOW(), duration_ms = ? WHERE id = ?"
        )
        .bind(status).bind(output).bind(error).bind(duration_ms).bind(log_id)
        .execute(&self.pool)
        .await;
    }

    pub async fn update_task_result(&self, task_id: u64, status: &str, last_result: &str) {
        let _ = sqlx::query("UPDATE task SET status = ?, last_run = NOW(), last_result = ? WHERE id = ?")
            .bind(status).bind(last_result).bind(task_id)
            .execute(&self.pool)
            .await;
    }

    // ═══════════════════════════════════════
    //  任务日志
    // ═══════════════════════════════════════

    pub async fn load_task_logs(&self, page: u32, page_size: u32) -> Result<(Vec<TaskLogEntry>, u32), String> {
        // 总数
        let count_rows = sqlx::query("SELECT COUNT(*) as total FROM task_log")
            .fetch_all(&self.pool).await
            .map_err(|e| format!("查询 task_log 总数失败: {}", e))?;
        let total = if count_rows.is_empty() { 0 } else { count_rows[0].get::<i64, _>("total") as u32 };

        // 分页
        let offset = (page - 1) * page_size;
        let rows = sqlx::query(
            r#"
            SELECT
                tl.id, tl.task_id,
                COALESCE(t.name, '') as task_name,
                tl.status,
                COALESCE(tl.output, '') as output,
                COALESCE(tl.error, '') as error,
                COALESCE(DATE_FORMAT(tl.start_time, '%Y-%m-%d %H:%i:%s'), '') as start_time,
                COALESCE(DATE_FORMAT(tl.end_time, '%Y-%m-%d %H:%i:%s'), '') as end_time,
                COALESCE(tl.duration_ms, 0) as duration_ms
            FROM task_log tl
            LEFT JOIN task t ON tl.task_id = t.id
            ORDER BY tl.start_time DESC
            LIMIT ? OFFSET ?
            "#
        )
        .bind(page_size as i64).bind(offset as i64)
        .fetch_all(&self.pool).await
        .map_err(|e| format!("查询 task_log 失败: {}", e))?;

        let logs: Vec<TaskLogEntry> = rows.iter().map(|row| TaskLogEntry {
            id: row.get::<u64, _>("id"),
            task_id: row.get::<u64, _>("task_id"),
            task_name: row.get::<&str, _>("task_name").to_string(),
            status: row.get::<&str, _>("status").to_string(),
            output: row.get::<&str, _>("output").to_string(),
            error: row.get::<&str, _>("error").to_string(),
            start_time: row.get::<&str, _>("start_time").to_string(),
            end_time: row.get::<&str, _>("end_time").to_string(),
            duration_ms: row.get::<i64, _>("duration_ms"),
        }).collect();

        Ok((logs, total))
    }

    pub async fn delete_task_log(&self, log_id: u64) -> Result<(), String> {
        sqlx::query("DELETE FROM task_log WHERE id = ?")
            .bind(log_id)
            .execute(&self.pool).await
            .map_err(|e| format!("删除 task_log 失败: {}", e))?;
        Ok(())
    }

    pub async fn clear_all_task_logs(&self) -> Result<(), String> {
        sqlx::query("DELETE FROM task_log")
            .execute(&self.pool).await
            .map_err(|e| format!("清空 task_log 失败: {}", e))?;
        Ok(())
    }

    // ═══════════════════════════════════════
    //  扫描策略
    // ═══════════════════════════════════════

    pub async fn load_scan_strategies(&self) -> Result<Vec<ScanStrategy>, String> {
        let query = "SELECT id, code, name, enabled FROM scan_strategy WHERE enabled = 1 ORDER BY id";
        let rows = sqlx::query(query).fetch_all(&self.pool).await
            .map_err(|e| format!("查询 scan_strategy 失败: {}", e))?;

        Ok(rows.iter().map(|row| ScanStrategy {
            id: row.get::<u64, _>("id"),
            code: row.get::<&str, _>("code").to_string(),
            name: row.get::<&str, _>("name").to_string(),
            enabled: row.get::<i8, _>("enabled") != 0,
        }).collect())
    }

    pub async fn load_all_scan_strategies(&self) -> Result<Vec<ScanStrategy>, String> {
        let query = "SELECT id, code, name, enabled FROM scan_strategy ORDER BY id";
        let rows = sqlx::query(query).fetch_all(&self.pool).await
            .map_err(|e| format!("查询 scan_strategy 失败: {}", e))?;

        Ok(rows.iter().map(|row| ScanStrategy {
            id: row.get::<u64, _>("id"),
            code: row.get::<&str, _>("code").to_string(),
            name: row.get::<&str, _>("name").to_string(),
            enabled: row.get::<i8, _>("enabled") != 0,
        }).collect())
    }

    // ═══════════════════════════════════════
    //  扫描结果
    // ═══════════════════════════════════════

    pub async fn load_all_scan_results(&self) -> Result<Vec<ScanResult>, String> {
        let query = r#"
            SELECT
                sr.id,
                COALESCE(sr.stock_code, '') as stock_code,
                COALESCE(sr.stock_name, '') as stock_name,
                sr.strategy_id,
                COALESCE(ss.name, '') as strategy_name,
                CAST(COALESCE(sr.price, 0) AS CHAR) as price,
                CAST(COALESCE(sr.change_pct, 0) AS CHAR) as change_pct,
                CAST(COALESCE(sr.sharpe, 0) AS CHAR) as sharpe,
                CAST(COALESCE(sr.annual_return, 0) AS CHAR) as annual_return,
                COALESCE(sr.extra_data, '') as extra_data,
                COALESCE(DATE_FORMAT(sr.scan_time, '%Y-%m-%d %H:%i:%s'), '') as scan_time
            FROM scan_result sr
            LEFT JOIN scan_strategy ss ON sr.strategy_id = ss.id
            ORDER BY sr.scan_date DESC, sr.strategy_id, sr.sharpe DESC
        "#;

        let rows = sqlx::query(query).fetch_all(&self.pool).await
            .map_err(|e| format!("查询 scan_result 失败: {}", e))?;

        let parse_f64 = |s: &str| -> f64 { s.parse().unwrap_or(0.0) };
        Ok(rows.iter().map(|row| ScanResult {
            id: row.get::<u64, _>("id"),
            stock_code: row.get::<&str, _>("stock_code").to_string(),
            stock_name: row.get::<&str, _>("stock_name").to_string(),
            strategy_id: row.get::<u64, _>("strategy_id"),
            strategy_name: row.get::<&str, _>("strategy_name").to_string(),
            price: parse_f64(&row.get::<&str, _>("price")),
            change_pct: parse_f64(&row.get::<&str, _>("change_pct")),
            sharpe: parse_f64(&row.get::<&str, _>("sharpe")),
            annual_return: parse_f64(&row.get::<&str, _>("annual_return")),
            extra_data: row.get::<&str, _>("extra_data").to_string(),
            scan_time: row.get::<&str, _>("scan_time").to_string(),
        }).collect())
    }

    pub async fn delete_all_scan_results(&self) -> Result<(), String> {
        sqlx::query("DELETE FROM scan_result")
            .execute(&self.pool).await
            .map_err(|e| format!("清空 scan_result 失败: {}", e))?;
        Ok(())
    }

    pub async fn batch_insert_scan_results(&self, results: &[ScanResultInput]) -> Result<(), String> {
        if results.is_empty() {
            return Ok(());
        }

        for result in results {
            let sql = r#"INSERT INTO scan_result
                (stock_code, stock_name, strategy_id, price, change_pct, sharpe, annual_return, extra_data, scan_date, scan_time)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, CURDATE(), NOW())"#;

            let _ = sqlx::query(sql)
                .bind(&result.stock_code)
                .bind(&result.stock_name)
                .bind(result.strategy_id)
                .bind(result.price)
                .bind(result.change_pct)
                .bind(result.sharpe)
                .bind(result.annual_return)
                .bind(&result.extra_data)
                .execute(&self.pool)
                .await;
        }
        Ok(())
    }

    pub async fn get_scan_results_by_strategy(&self, strategy_id: u64) -> Result<Vec<ScanResult>, String> {
        let query = r#"
            SELECT DISTINCT
                sr.stock_code,
                COALESCE(sr.stock_name, '') as stock_name,
                sr.strategy_id,
                COALESCE(ss.name, '') as strategy_name
            FROM scan_result sr
            LEFT JOIN scan_strategy ss ON sr.strategy_id = ss.id
            WHERE sr.strategy_id = ?
        "#;

        let rows = sqlx::query(query).bind(strategy_id).fetch_all(&self.pool).await
            .map_err(|e| format!("查询 scan_result 失败: {}", e))?;

        Ok(rows.iter().map(|row| ScanResult {
            id: 0,
            stock_code: row.get::<String, _>("stock_code"),
            stock_name: row.get::<String, _>("stock_name"),
            strategy_id: row.get::<u64, _>("strategy_id"),
            strategy_name: row.get::<String, _>("strategy_name"),
            price: 0.0,
            change_pct: 0.0,
            sharpe: 0.0,
            annual_return: 0.0,
            extra_data: String::new(),
            scan_time: String::new(),
        }).collect())
    }
}
