//! aiai 数据访问层 —— trade_accounts / trade_strategies 的 CRUD
//!
//! 供 web handlers（管理后台 API）和 aiai 引擎（策略加载）共用。

use sqlx::{Row, MySqlPool, QueryBuilder};

use std::collections::HashMap;

use crate::models::aiai::{TradeAccountRow, StrategyConfigRow, DataSourceRow};

/// 账户余额缓存行（从 trade_accounts 余额缓存字段读取）
#[derive(Debug, Clone)]
pub struct AccountBalanceCache {
    pub name: String,
    pub exchange: String,
    pub is_testnet: bool,
    pub total_equity: f64,
    pub available_cash: f64,
    pub frozen_margin: f64,
    pub equity_updated_at: Option<String>,
}

#[derive(Debug, Clone)]
pub struct AiaiRepository {
    pool: MySqlPool,
}

impl AiaiRepository {
    pub fn new(pool: MySqlPool) -> Self {
        Self { pool }
    }

    // ═══════════════════════════════════════
    //  账户 CRUD
    // ═══════════════════════════════════════

    pub async fn list_accounts(&self) -> Result<Vec<TradeAccountRow>, String> {
        let rows = sqlx::query(
            r#"SELECT CAST(id AS SIGNED) as id, name, exchange, api_key, secret_key, passphrase,
                      login_id, login_pwd,
                      CAST(is_testnet AS SIGNED) as is_testnet,
                      CAST(enabled AS SIGNED) as enabled,
                      CAST(sort_order AS SIGNED) as sort_order, remark,
                      DATE_FORMAT(created_at, '%Y-%m-%d %H:%i:%s') as created_at,
                      DATE_FORMAT(updated_at, '%Y-%m-%d %H:%i:%s') as updated_at
               FROM trade_accounts ORDER BY sort_order DESC, created_at DESC"#
        )
        .fetch_all(&self.pool).await
        .map_err(|e| format!("查询 trade_accounts 失败: {}", e))?;

        Ok(rows.iter().map(|r| TradeAccountRow {
            id: r.try_get("id").unwrap_or_default(),
            name: r.try_get("name").unwrap_or_default(),
            exchange: r.try_get("exchange").unwrap_or_default(),
            api_key: r.try_get("api_key").unwrap_or_default(),
            secret_key: r.try_get("secret_key").unwrap_or_default(),
            passphrase: r.try_get("passphrase").unwrap_or_default(),
            login_id: r.try_get("login_id").unwrap_or_default(),
            login_pwd: r.try_get("login_pwd").unwrap_or_default(),
            is_testnet: r.try_get("is_testnet").unwrap_or(1),
            enabled: r.try_get("enabled").unwrap_or(1),
            sort_order: r.try_get("sort_order").unwrap_or(0),
            remark: r.try_get("remark").unwrap_or_default(),
            created_at: r.try_get("created_at").ok(),
            updated_at: r.try_get("updated_at").ok(),
        }).collect())
    }

    pub async fn upsert_account(&self, data: TradeAccountRow) -> Result<(), String> {
        if data.id > 0 {
            sqlx::query(
                "UPDATE trade_accounts SET name=?, exchange=?, api_key=?, secret_key=?, passphrase=?,
                 login_id=?, login_pwd=?, is_testnet=?, enabled=?, sort_order=?, remark=?, updated_at=NOW() WHERE id=?"
            )
            .bind(&data.name).bind(&data.exchange).bind(&data.api_key).bind(&data.secret_key)
            .bind(&data.passphrase).bind(&data.login_id).bind(&data.login_pwd).bind(data.is_testnet).bind(data.enabled).bind(data.sort_order).bind(&data.remark).bind(data.id)
            .execute(&self.pool).await
            .map_err(|e| format!("更新 trade_accounts 失败: {}", e))?;
        } else {
            sqlx::query(
                "INSERT INTO trade_accounts (name,exchange,api_key,secret_key,passphrase,login_id,login_pwd,is_testnet,enabled,sort_order,remark,created_at,updated_at)
                 VALUES (?,?,?,?,?,?,?,?,?,?,?,NOW(),NOW())"
            )
            .bind(&data.name).bind(&data.exchange).bind(&data.api_key)
            .bind(&data.secret_key).bind(&data.passphrase).bind(&data.login_id).bind(&data.login_pwd).bind(data.is_testnet).bind(data.enabled).bind(data.sort_order).bind(&data.remark)
            .execute(&self.pool).await
            .map_err(|e| format!("插入 trade_accounts 失败: {}", e))?;
        }
        Ok(())
    }

    pub async fn delete_account(&self, id: i64) -> Result<(), String> {
        sqlx::query("DELETE FROM trade_accounts WHERE id = ?")
            .bind(id)
            .execute(&self.pool).await
            .map_err(|e| format!("删除 trade_accounts 失败: {}", e))?;
        Ok(())
    }

    // ═══════════════════════════════════════
    //  策略 CRUD
    // ═══════════════════════════════════════

    pub async fn list_strategies_all(&self) -> Result<Vec<StrategyConfigRow>, String> {
        let rows = sqlx::query(
            r#"SELECT CAST(id AS SIGNED) as id, name, CAST(enabled AS SIGNED) as enabled,
                      CAST(priority AS SIGNED) as priority,
                      CAST(sort_order AS SIGNED) as sort_order,
                      market_type, symbols,
                      timeframes, data_source,
                      factor_type,
                      portfolio_type,
                      risk_type,
                      execution_type,
                      CAST(account_id AS SIGNED) as account_id, initial_balance,
                      DATE_FORMAT(created_at, '%Y-%m-%d %H:%i:%s') as created_at,
                      DATE_FORMAT(updated_at, '%Y-%m-%d %H:%i:%s') as updated_at
               FROM trade_strategies ORDER BY sort_order DESC, priority DESC, id ASC"#
        )
        .fetch_all(&self.pool).await
        .map_err(|e| format!("查询 trade_strategies 失败: {}", e))?;

        Ok(rows.iter().map(|r| StrategyConfigRow {
            id: r.try_get("id").unwrap_or_default(),
            name: r.try_get("name").unwrap_or_default(),
            enabled: r.try_get("enabled").unwrap_or(1),
            priority: r.try_get("priority").unwrap_or(0),
            sort_order: r.try_get("sort_order").unwrap_or(0),
            market_type: r.try_get("market_type").unwrap_or_default(),
            symbols: r.try_get("symbols").unwrap_or_default(),
            timeframes: r.try_get("timeframes").unwrap_or_default(),
            data_source: r.try_get("data_source").unwrap_or_default(),
            market_extra: String::new(),
            factor_type: r.try_get("factor_type").unwrap_or_default(),
            factor_extra: String::new(),
            portfolio_type: r.try_get("portfolio_type").unwrap_or_default(),
            portfolio_extra: String::new(),
            risk_type: r.try_get("risk_type").unwrap_or_default(),
            risk_extra: String::new(),
            execution_type: r.try_get("execution_type").unwrap_or_default(),
            execution_extra: String::new(),
            account_id: r.try_get("account_id").unwrap_or(0),
            initial_balance: r.try_get::<f64, _>("initial_balance").unwrap_or(1000000.0),
            created_at: r.try_get("created_at").ok(),
            updated_at: r.try_get("updated_at").ok(),
        }).collect())
    }

    /// 加载所有启用的策略行（供 aiai 引擎启动时使用）
    pub async fn load_enabled_strategies(&self) -> Result<Vec<StrategyConfigRow>, String> {
        let rows = sqlx::query(
            r#"SELECT CAST(id AS SIGNED) as id, name, CAST(enabled AS SIGNED) as enabled,
                      CAST(priority AS SIGNED) as priority,
                      CAST(sort_order AS SIGNED) as sort_order,
                      market_type, symbols,
                      timeframes, data_source,
                      factor_type,
                      portfolio_type,
                      risk_type,
                      execution_type,
                      CAST(account_id AS SIGNED) as account_id, initial_balance,
                      DATE_FORMAT(created_at, '%Y-%m-%d %H:%i:%s') as created_at,
                      DATE_FORMAT(updated_at, '%Y-%m-%d %H:%i:%s') as updated_at
               FROM trade_strategies WHERE enabled = 1
               ORDER BY sort_order DESC, priority DESC, id ASC"#
        )
        .fetch_all(&self.pool).await
        .map_err(|e| format!("查询 trade_strategies 失败: {}", e))?;

        Ok(rows.iter().map(|r| StrategyConfigRow {
            id: r.try_get("id").unwrap_or_default(),
            name: r.try_get("name").unwrap_or_default(),
            enabled: r.try_get("enabled").unwrap_or(1),
            priority: r.try_get("priority").unwrap_or(0),
            sort_order: r.try_get("sort_order").unwrap_or(0),
            market_type: r.try_get("market_type").unwrap_or_default(),
            symbols: r.try_get("symbols").unwrap_or_default(),
            timeframes: r.try_get("timeframes").unwrap_or_default(),
            data_source: r.try_get("data_source").unwrap_or_default(),
            market_extra: String::new(),
            factor_type: r.try_get("factor_type").unwrap_or_default(),
            factor_extra: String::new(),
            portfolio_type: r.try_get("portfolio_type").unwrap_or_default(),
            portfolio_extra: String::new(),
            risk_type: r.try_get("risk_type").unwrap_or_default(),
            risk_extra: String::new(),
            execution_type: r.try_get("execution_type").unwrap_or_default(),
            execution_extra: String::new(),
            account_id: r.try_get("account_id").unwrap_or(0),
            initial_balance: r.try_get::<f64, _>("initial_balance").unwrap_or(1000000.0),
            created_at: r.try_get("created_at").ok(),
            updated_at: r.try_get("updated_at").ok(),
        }).collect())
    }

    pub async fn upsert_strategy(&self, data: StrategyConfigRow) -> Result<(), String> {
        if data.id > 0 {
            sqlx::query(
                r#"UPDATE trade_strategies SET name=?, enabled=?, priority=?, sort_order=?, market_type=?, symbols=?,
                   timeframes=?, data_source=?,
                   factor_type=?, portfolio_type=?, risk_type=?, execution_type=?,
                   account_id=?, initial_balance=?, updated_at=NOW() WHERE id=?"#
            )
            .bind(&data.name).bind(data.enabled).bind(data.priority).bind(data.sort_order).bind(&data.market_type).bind(&data.symbols)
            .bind(&data.timeframes).bind(&data.data_source)
            .bind(&data.factor_type).bind(&data.portfolio_type).bind(&data.risk_type).bind(&data.execution_type)
            .bind(data.account_id).bind(data.initial_balance).bind(data.id)
            .execute(&self.pool).await
            .map_err(|e| format!("更新 trade_strategies 失败: {}", e))?;
        } else {
            sqlx::query(
                r#"INSERT INTO trade_strategies (name,enabled,priority,sort_order,market_type,symbols,
                   timeframes,data_source,
                   factor_type,portfolio_type,risk_type,execution_type,
                   account_id,initial_balance,created_at,updated_at)
                   VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,NOW(),NOW())"#
            )
            .bind(&data.name).bind(data.enabled).bind(data.priority).bind(data.sort_order).bind(&data.market_type).bind(&data.symbols)
            .bind(&data.timeframes).bind(&data.data_source)
            .bind(&data.factor_type).bind(&data.portfolio_type).bind(&data.risk_type).bind(&data.execution_type)
            .bind(data.account_id).bind(data.initial_balance)
            .execute(&self.pool).await
            .map_err(|e| format!("插入 trade_strategies 失败: {}", e))?;
        }
        Ok(())
    }

    pub async fn delete_strategy(&self, id: i64) -> Result<(), String> {
        sqlx::query("DELETE FROM trade_strategies WHERE id = ?")
            .bind(id)
            .execute(&self.pool).await
            .map_err(|e| format!("删除 trade_strategies 失败: {}", e))?;
        Ok(())
    }

    // ═══════════════════════════════════════
    //  数据源 CRUD
    // ═══════════════════════════════════════

    /// 加载所有启用的数据源，按 source_type 分组返回
    pub async fn load_active_data_sources(&self) -> Result<HashMap<String, Vec<DataSourceRow>>, String> {
        let rows = sqlx::query(
            r#"SELECT id, source_type, symbol, timeframes, enabled,
                      CAST(sort_order AS SIGNED) as sort_order, remark,
                      DATE_FORMAT(created_at, '%Y-%m-%d %H:%i:%s') as created_at,
                      DATE_FORMAT(updated_at, '%Y-%m-%d %H:%i:%s') as updated_at
               FROM trade_data_source WHERE enabled = 1
               ORDER BY sort_order DESC, source_type, symbol"#
        )
        .fetch_all(&self.pool).await
        .map_err(|e| format!("查询 trade_data_source 失败: {}", e))?;

        let list: Vec<DataSourceRow> = rows.iter().map(|r| DataSourceRow {
            id: r.try_get("id").unwrap_or_default(),
            source_type: r.try_get("source_type").unwrap_or_default(),
            symbol: r.try_get("symbol").unwrap_or_default(),
            timeframes: r.try_get("timeframes").unwrap_or_default(),
            enabled: r.try_get("enabled").unwrap_or(1),
            sort_order: r.try_get("sort_order").unwrap_or(0),
            remark: r.try_get("remark").ok(),
            created_at: r.try_get("created_at").ok(),
            updated_at: r.try_get("updated_at").ok(),
        }).collect();

        // 按 source_type 分组
        let mut grouped: HashMap<String, Vec<DataSourceRow>> = HashMap::new();
        for row in list {
            grouped.entry(row.source_type.clone()).or_default().push(row);
        }
        Ok(grouped)
    }

    /// 列出全部 trade_data_source（包括禁用的，供管理后台使用）
    pub async fn list_data_sources(&self) -> Result<Vec<DataSourceRow>, String> {
        let rows = sqlx::query(
            r#"SELECT id, source_type, symbol, timeframes, enabled,
                      CAST(sort_order AS SIGNED) as sort_order, remark,
                      DATE_FORMAT(created_at, '%Y-%m-%d %H:%i:%s') as created_at,
                      DATE_FORMAT(updated_at, '%Y-%m-%d %H:%i:%s') as updated_at
               FROM trade_data_source ORDER BY sort_order DESC, source_type, symbol"#
        )
        .fetch_all(&self.pool).await
        .map_err(|e| format!("查询 trade_data_source 失败: {}", e))?;

        Ok(rows.iter().map(|r| DataSourceRow {
            id: r.try_get("id").unwrap_or_default(),
            source_type: r.try_get("source_type").unwrap_or_default(),
            symbol: r.try_get("symbol").unwrap_or_default(),
            timeframes: r.try_get("timeframes").unwrap_or_default(),
            enabled: r.try_get("enabled").unwrap_or(1),
            sort_order: r.try_get("sort_order").unwrap_or(0),
            remark: r.try_get("remark").ok(),
            created_at: r.try_get("created_at").ok(),
            updated_at: r.try_get("updated_at").ok(),
        }).collect())
    }

    pub async fn upsert_data_source(&self, data: DataSourceRow) -> Result<(), String> {
        let cnt: (i32,) = sqlx::query_as("SELECT COUNT(*) FROM trade_data_source WHERE id = ?")
            .bind(data.id)
            .fetch_one(&self.pool).await
            .map_err(|e| format!("查询 trade_data_source 失败: {}", e))?;

        if cnt.0 > 0 {
            sqlx::query(
                "UPDATE trade_data_source SET source_type=?, symbol=?, timeframes=?, enabled=?, sort_order=?, remark=?, updated_at=NOW() WHERE id=?"
            )
            .bind(&data.source_type).bind(&data.symbol).bind(&data.timeframes)
            .bind(data.enabled).bind(data.sort_order).bind(&data.remark).bind(data.id)
            .execute(&self.pool).await
            .map_err(|e| format!("更新 trade_data_source 失败: {}", e))?;
        } else {
            sqlx::query(
                "INSERT INTO trade_data_source (source_type,symbol,timeframes,enabled,sort_order,remark,created_at,updated_at) VALUES (?,?,?,?,?,?,NOW(),NOW())"
            )
            .bind(&data.source_type).bind(&data.symbol).bind(&data.timeframes)
            .bind(data.enabled).bind(data.sort_order).bind(&data.remark)
            .execute(&self.pool).await
            .map_err(|e| format!("插入 trade_data_source 失败: {}", e))?;
        }
        Ok(())
    }

    /// 切换启用/禁用状态
    pub async fn toggle_data_source(&self, id: u64, active: bool) -> Result<(), String> {
        sqlx::query("UPDATE trade_data_source SET enabled = ?, updated_at = NOW() WHERE id = ?")
            .bind(active as i32)
            .bind(id)
            .execute(&self.pool).await
            .map_err(|e| format!("切换 trade_data_source 状态失败: {}", e))?;
        Ok(())
    }

    pub async fn delete_data_source(&self, id: u64) -> Result<(), String> {
        sqlx::query("DELETE FROM trade_data_source WHERE id = ?")
            .bind(id)
            .execute(&self.pool).await
            .map_err(|e| format!("删除 trade_data_source 失败: {}", e))?;
        Ok(())
    }

    // ═══════════════════════════════════════
    //  账户余额缓存（供引擎写回 DB，看板读 DB 兜底）
    // ═══════════════════════════════════════

    /// 更新 trade_accounts 的余额缓存字段（引擎每次结算后异步调用）
    pub async fn update_account_balance(
        &self,
        account_id: i64,
        total_equity: f64,
        available_cash: f64,
        frozen_margin: f64,
    ) -> Result<(), String> {
        sqlx::query(
            r#"UPDATE trade_accounts
               SET total_equity = ?, available_cash = ?, frozen_margin = ?,
                   equity_updated_at = NOW()
               WHERE id = ?"#
        )
        .bind(total_equity)
        .bind(available_cash)
        .bind(frozen_margin)
        .bind(account_id)
        .execute(&self.pool).await
        .map_err(|e| format!("更新账户余额缓存失败: {e}"))?;
        Ok(())
    }

    /// 加载所有账户的 id→name 映射（供策略列表填充账户名称）
    pub async fn load_account_names_map(&self) -> Result<HashMap<i64, String>, String> {
        let rows = sqlx::query("SELECT CAST(id AS SIGNED) as id, name FROM trade_accounts")
            .fetch_all(&self.pool).await
            .map_err(|e| format!("查询账户名称失败: {e}"))?;
        let mut map = HashMap::new();
        for r in &rows {
            let id: i64 = r.try_get("id").unwrap_or_default();
            let name: String = r.try_get("name").unwrap_or_default();
            map.insert(id, name);
        }
        Ok(map)
    }

    /// 查询账户余额缓存（看板兜底用）
    ///
    /// `account_ids` 为空时加载所有账户，否则仅查询指定账户。
    pub async fn load_account_balances_map(
        &self,
        account_ids: &[i64],
    ) -> Result<HashMap<i64, AccountBalanceCache>, String> {
        fn row_to_cache(r: &sqlx::mysql::MySqlRow) -> AccountBalanceCache {
            AccountBalanceCache {
                name: r.try_get("name").unwrap_or_default(),
                exchange: r.try_get("exchange").unwrap_or_default(),
                is_testnet: r.try_get::<i32, _>("is_testnet").unwrap_or(1) == 1,
                total_equity: r.try_get::<f64, _>("total_equity").unwrap_or(0.0),
                available_cash: r.try_get::<f64, _>("available_cash").unwrap_or(0.0),
                frozen_margin: r.try_get::<f64, _>("frozen_margin").unwrap_or(0.0),
                equity_updated_at: r.try_get("equity_updated_at").ok(),
            }
        }

        if account_ids.is_empty() {
            let rows = sqlx::query(
                r#"SELECT CAST(id AS SIGNED) as id, name, exchange,
                          CAST(is_testnet AS SIGNED) as is_testnet,
                          COALESCE(total_equity, 0) as total_equity,
                          COALESCE(available_cash, 0) as available_cash,
                          COALESCE(frozen_margin, 0) as frozen_margin,
                          DATE_FORMAT(equity_updated_at, '%Y-%m-%d %H:%i:%s') as equity_updated_at
                   FROM trade_accounts"#
            )
            .fetch_all(&self.pool).await
            .map_err(|e| format!("查询账户余额缓存失败: {e}"))?;
            let mut map = HashMap::new();
            for r in &rows {
                let id: i64 = r.try_get("id").unwrap_or_default();
                map.insert(id, row_to_cache(r));
            }
            return Ok(map);
        }

        let mut builder = QueryBuilder::new(
            r#"SELECT CAST(id AS SIGNED) as id, name, exchange,
                      CAST(is_testnet AS SIGNED) as is_testnet,
                      COALESCE(total_equity, 0) as total_equity,
                      COALESCE(available_cash, 0) as available_cash,
                      COALESCE(frozen_margin, 0) as frozen_margin,
                      DATE_FORMAT(equity_updated_at, '%Y-%m-%d %H:%i:%s') as equity_updated_at
               FROM trade_accounts WHERE id IN ("#
        );
        let mut separated = builder.separated(", ");
        for id in account_ids {
            separated.push_bind(id);
        }
        separated.push_unseparated(")");

        let rows = builder.build().fetch_all(&self.pool).await
            .map_err(|e| format!("查询账户余额缓存失败: {e}"))?;
        let mut map = HashMap::new();
        for r in &rows {
            let id: i64 = r.try_get("id").unwrap_or_default();
            map.insert(id, row_to_cache(r));
        }
        Ok(map)
    }
}
