//! Web 核心库 - 供 web 和 eye bin 复用 (Axum 版本)

use crate::log;
use axum::{routing::{get, post, delete}, Router, middleware};
use axum::extract::Request;
use axum::http::header;
use axum::middleware::Next;
use tower_http::cors::{Any, CorsLayer};
use tower_http::services::ServeDir;
use sqlx::mysql::MySqlPoolOptions;
use std::net::{SocketAddr, ToSocketAddrs};
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::Arc;
use std::time::Duration;
use crate::utils::redis::init_redis_pool;
use crate::services::auth_service::AuthService;
use bb8::Pool;
use bb8_redis::RedisConnectionManager;

/// 应用共享状态
#[derive(Clone)]
pub struct AppState {
    pub auth_service: Arc<AuthService>,
    pub mysql_pool: sqlx::MySqlPool,
    pub redis_pool: Arc<Pool<RedisConnectionManager>>,
}

/// Web 服务器句柄（用于停止服务器）
pub struct ServerHandle {
    pub stop_flag: Arc<AtomicBool>,
}

/// 路由配置（供 spawn_server 和 serve 共用）
fn build_router(state: AppState, static_dir: &str) -> Router {
    let cors = CorsLayer::new()
        .allow_origin(Any)
        .allow_methods(Any)
        .allow_headers(Any);

    Router::new()
        // auth
        .route("/api/ping", get(crate::handlers::auth_handler::ping))
        .route("/api/login", post(crate::handlers::auth_handler::login))
        .route("/api/register", post(crate::handlers::auth_handler::register))
        .route("/api/user", get(crate::handlers::auth_handler::user))
        .route("/api/logout", get(crate::handlers::auth_handler::logout))
        .route("/api/update_user", post(crate::handlers::auth_handler::update_user))
        .route("/api/options", get(crate::handlers::auth_handler::options))
        // kline
        .route("/api/kline", get(crate::handlers::kline_handler::get_kline))
        .route("/api/kline/batch", get(crate::handlers::kline_handler::get_kline_batch))
        .route("/api/backtest", get(crate::handlers::kline_handler::get_backtest))
        .route("/api/stock/random", get(crate::handlers::kline_handler::get_random_stock))
        // optimize
        .route("/api/optimize", post(crate::handlers::optimize_handler::start_optimize))
        .route("/api/optimize/status", get(crate::handlers::optimize_handler::get_status))
        .route("/api/optimize/history/{task_id}", get(crate::handlers::optimize_handler::get_history))
        .route("/api/optimize/list", get(crate::handlers::optimize_handler::get_list))
        // 量化管理后台（账户/策略 CRUD + 日志）
        .route("/api/admin/accounts", get(crate::handlers::aiai_handler::list_accounts).post(crate::handlers::aiai_handler::save_account))
        .route("/api/admin/accounts/{id}", delete(crate::handlers::aiai_handler::delete_account))
        .route("/api/admin/strategies", get(crate::handlers::aiai_handler::list_strategies_all).post(crate::handlers::aiai_handler::save_strategy))
        .route("/api/admin/strategies/{id}", delete(crate::handlers::aiai_handler::delete_strategy))
        .route("/api/admin/logs", get(crate::handlers::aiai_handler::get_logs))
        .layer(cors)
        // 开发阶段：禁用静态文件缓存，跳过 /api/ 路由避免影响 WebSocket
        .layer(middleware::from_fn(no_cache))
        // 静态文件服务作为兜底（必须在 with_state 之前）
        .fallback_service(ServeDir::new(static_dir))
        .with_state(state)
}

/// 开发阶段：对静态文件禁用浏览器缓存，跳过 /api/ 路由
async fn no_cache(req: Request, next: Next) -> axum::response::Response {
    let path = req.uri().path().to_string();
    let mut resp = next.run(req).await;
    if !path.starts_with("/api/") {
        resp.headers_mut().insert(
            header::CACHE_CONTROL,
            header::HeaderValue::from_static("no-cache, no-store, must-revalidate"),
        );
    }
    resp
}

/// 启动 Web 服务器并返回控制句柄
/// stop_flag 设置为 true 时，服务器会优雅停止
/// restart_counter 用于在重启时让旧服务器主动退出
/// rt: 可选的外部 Tokio Runtime，传入时共享 Runtime，None 时内部自建
/// ext_fn: 可选的外部路由扩展函数（fn(Router) -> Router），在 fallback_service 后调用
/// mysql_pool: 可选的预创建 MySQL 连接池（Some 则复用，None 则自建）
pub fn spawn_server<A: ToSocketAddrs>(
    bind_addr: A,
    stop_flag: Arc<AtomicBool>,
    running: Arc<AtomicBool>,
    restart_counter: Arc<std::sync::atomic::AtomicUsize>,
    _counter: usize,
    rt: Option<&tokio::runtime::Runtime>,
    ext_fn: Option<fn(Router) -> Router>,
    mysql_pool: Option<sqlx::MySqlPool>,
) {
    // 转换为字符串以便跨线程传递
    let bind_addr = bind_addr.to_socket_addrs().unwrap().next().unwrap();
    let bind_str = bind_addr.to_string();

    // 核心服务器逻辑（无绑定/握手以外的所有异步初始化）
    let serve = move || async move {
        // 加载 .env 配置
        dotenv::dotenv().ok();

        // 预加载权息库（避免首次请求时慢）
        if let Ok(_) = crate::seek::tdx_data::init_tdx_config() {
            let provider = crate::seek::tdx_data::TdxDataProvider::new();
            provider.preload_gbbq();
            log!("[Web服务] 权息库加载完成");
        }

        // 创建服务器资源
        let config = crate::config::Config::from_env().expect("Failed to load configuration");

        let mysql_pool = match mysql_pool {
            Some(pool) => pool,
            None => {
                MySqlPoolOptions::new()
                    .max_connections(10)
                    .connect(&config.database_url)
                    .await
                    .expect("Failed to create MySQL pool")
            }
        };

        let redis_pool_raw = init_redis_pool(&config.redis_url).await;
        let redis_pool = Arc::new(redis_pool_raw);

        let user_repo = crate::repositories::user_repo::UserRepository::new(mysql_pool.clone());
        let auth_service = AuthService::new(
            user_repo,
            redis_pool.clone(),
            config.jwt_secret,
            config.jwt_expires_in,
        );

        let static_dir = config.static_dir.clone();
        let state = AppState {
            auth_service: Arc::new(auth_service),
            mysql_pool: mysql_pool.clone(),
            redis_pool: redis_pool.clone(),
        };

        let router = build_router(state, &static_dir);

        // 应用外部路由扩展（如 aiai 实时策略数据 API）
        let router = if let Some(f) = ext_fn { f(router) } else { router };

        // 绑定 TCP 监听
        let listener = tokio::net::TcpListener::bind(&bind_str)
            .await
            .expect("Failed to bind");

        // 获取 socket 地址用于 ConnectInfo
        let local_addr = listener.local_addr().unwrap();
        let app = router.into_make_service_with_connect_info::<SocketAddr>();

        // 递增计数器
        restart_counter.fetch_add(1, Ordering::SeqCst);
        let new_counter = restart_counter.load(Ordering::SeqCst);

        // 标记为运行中
        running.store(true, Ordering::SeqCst);
        log!("[Web服务] 服务器启动成功 http://{}", local_addr);

        // 构建优雅关闭信号
        let stop_flag_clone = stop_flag.clone();
        let restart_counter_clone = restart_counter.clone();
        let shutdown_signal = async move {
            loop {
                tokio::time::sleep(Duration::from_millis(100)).await;
                if stop_flag_clone.load(Ordering::SeqCst) {
                    log!("[Web] 收到停止信号，正在关闭服务器...");
                    break;
                }
                // 检查是否已被更新的实例取代
                let current_counter = restart_counter_clone.load(Ordering::SeqCst);
                if current_counter > new_counter {
                    log!("[Web] 检测到新的服务器实例，退出");
                    break;
                }
            }
        };

        // 运行服务器
        axum::serve(listener, app)
            .with_graceful_shutdown(shutdown_signal)
            .await
            .expect("Server error");

        // 服务器停止时重置状态
        running.store(false, Ordering::SeqCst);
        log!("[Web服务] 服务器已停止");
    };

    match rt {
        Some(runtime) => {
            // 共享 Runtime：直接 spawn，不新建线程
            runtime.spawn(serve());
        }
        None => {
            // 独立 Runtime：新线程 + 自建 Runtime
            std::thread::spawn(move || {
                let rt_inner = tokio::runtime::Builder::new_current_thread()
                    .enable_all()
                    .build()
                    .expect("Failed to create tokio runtime");
                rt_inner.block_on(serve());
            });
        }
    }
}

/// 运行 Web 服务器（独立启动，阻塞当前线程）
pub async fn serve<A: ToSocketAddrs + tokio::net::ToSocketAddrs>(bind_addr: A) -> std::io::Result<()> {
    let config = crate::config::Config::from_env().expect("Failed to load configuration");

    let mysql_pool = MySqlPoolOptions::new()
        .max_connections(10)
        .connect(&config.database_url)
        .await
        .expect("Failed to create MySQL pool");

    let redis_pool = Arc::new(init_redis_pool(&config.redis_url).await);

    let user_repo = crate::repositories::user_repo::UserRepository::new(mysql_pool.clone());
    let auth_service = AuthService::new(
        user_repo,
        redis_pool.clone(),
        config.jwt_secret,
        config.jwt_expires_in,
    );

    let static_dir = config.static_dir.clone();
    let state = AppState {
        auth_service: Arc::new(auth_service),
        mysql_pool: mysql_pool.clone(),
        redis_pool: redis_pool.clone(),
    };

    let router = build_router(state, &static_dir);
    let app = router.into_make_service_with_connect_info::<SocketAddr>();

    let listener = tokio::net::TcpListener::bind(bind_addr).await?;
    log!("[Web] 启动 Web API 服务器 http://{}", listener.local_addr()?);

    axum::serve(listener, app).await
}
