use crate::models::user::{
    LogoutRequest, OptionItem, OptionsRequest, RegisterRequest,
    RegisterResponse, UpdateUserRequest, UserProfileResponse, UserProfileRequest,
};
use crate::repositories::user_repo::UserRepository;
use crate::error::AppError;
use crate::models::user::{LoginRequest, LoginResponse, User};
use bb8::Pool;
use bb8_redis::RedisConnectionManager;
use bcrypt::verify;
use chrono::{Duration, Utc};
use jsonwebtoken::{encode, EncodingKey, Header};
use tracing::info;
use std::sync::Arc;
use crate::utils::verify::{is_account, is_email};
use crate::utils::cache::get_cache;

#[derive(Debug, Clone)]
pub struct AuthService {
    user_repo: UserRepository,
    redis_pool: Arc<Pool<RedisConnectionManager>>,
    jwt_secret: String,
    jwt_expires_in: i64,
}

impl AuthService {
    pub fn new(
        user_repo: UserRepository,
        redis_pool: Arc<Pool<RedisConnectionManager>>,
        jwt_secret: String,
        jwt_expires_in: i64,
    ) -> Self {
        Self {
            user_repo,
            redis_pool,
            jwt_secret,
            jwt_expires_in,
        }
    }

    pub async fn login(&self, login_data: LoginRequest) -> Result<LoginResponse, AppError> {
        let by_email = is_email(&login_data.account);
        let by_account = is_account(&login_data.account);

        if !by_email && !by_account {
            return Err(AppError::ResponseError(400, "账户不合法".into()));
        }

        let user = self
            .user_repo
            .find_by_account(&login_data.account)
            .await?
            .ok_or_else(|| {
                if by_email {
                    AppError::ResponseError(400, "Email不存在".into())
                } else {
                    AppError::ResponseError(400, "账户不存在".into())
                }
            })?;

        if login_data.password != user.password {
            return Err(AppError::ResponseError(400, "密码错误".into()));
        }

        if user.status != 0 {
            return Err(AppError::ResponseError(400, "账户不可用".to_string()));
        }

        let token = self.generate_token(&user)?;

        self.user_repo
            .update_token(&login_data.request_id, user.id, Some(&token))
            .await?;

        self.cache_user(&token, &user).await?;

        Ok(LoginResponse {
            id: user.id,
            account: user.account,
            nickname: user.nickname,
            email: user.email,
            avatar_url: user.avatar_url,
            register_time: user.register_time,
            update_time: user.update_time,
            token,
            bio: user.bio,
            balance: user.balance,
        })
    }

    fn generate_token(&self, user: &User) -> Result<String, AppError> {
        let expiration = Utc::now() + Duration::seconds(self.jwt_expires_in);
        let claims = serde_json::json!({
            "sub": user.id,
            "exp": expiration.timestamp(),
            "account": user.account,
        });

        let token = encode(
            &Header::default(),
            &claims,
            &EncodingKey::from_secret(self.jwt_secret.as_ref()),
        )
        .map_err(|e| AppError::BadRequest(format!("JWT encode error: {}", e)))?;

        Ok(token)
    }

    async fn cache_user(&self, token: &str, user: &User) -> Result<(), AppError> {
        get_cache().insert(token.to_string(), serde_json::to_string(&user).unwrap());

        let redis_pool = self.redis_pool.clone();
        let user_json = serde_json::to_string(&user).unwrap();
        let token_owned = token.to_string();
        let ttl = self.jwt_expires_in as u64;
        tokio::spawn(async move {
            if let Ok(mut conn) = redis_pool.get().await {
                use redis::AsyncCommands;
                let key = format!("user:{}", token_owned);
                let _: Result<(), _> = conn.set_ex(&key, &user_json, ttl).await;
            }
        });

        Ok(())
    }

    pub async fn register(&self, register_data: RegisterRequest) -> Result<RegisterResponse, AppError> {
        let by_email = is_email(&register_data.account);
        let by_account = is_account(&register_data.account);

        if !by_email && !by_account {
            return Err(AppError::ResponseError(400, "账户不合法".into()));
        }

        if self
            .user_repo
            .find_by_account(&register_data.account)
            .await?
            .is_some()
        {
            return Err(AppError::ResponseError(400, if by_email { "Email已存在" } else { "账号已存在" }.into()));
        }

        let hashed_pwd = register_data.password.clone();

        let id = if by_account {
            self.user_repo
                .create_user_by_account(&register_data.request_id, &register_data.account, &hashed_pwd)
                .await?
        } else {
            self.user_repo
                .create_user_by_email(&register_data.request_id, &register_data.account, &hashed_pwd)
                .await?
        };

        Ok(RegisterResponse {
            id,
            account: register_data.account,
        })
    }

    pub async fn get_profile(&self, form_data: UserProfileRequest) -> Result<UserProfileResponse, AppError> {
        let user = self
            .user_repo
            .find_by_token(&form_data.token)
            .await?
            .ok_or_else(|| AppError::BadRequest("token无效".into()))?;

        if user.id != form_data.id {
            return Err(AppError::BadRequest("用户不存在".into()));
        }

        Ok(UserProfileResponse {
            token: user.token,
            id: user.id,
            account: user.account,
            email: user.email,
            nickname: user.nickname,
            avatar_url: user.avatar_url,
            register_time: user.register_time,
            bio: user.bio,
            balance: user.balance,
        })
    }

    pub async fn logout(&self, logout_data: LogoutRequest) -> Result<(), AppError> {
        let user = self
            .user_repo
            .find_by_token(&logout_data.token)
            .await
            .map_err(|_e| AppError::ResponseError(400, "查询失败".into()))?
            .ok_or_else(|| AppError::ResponseError(400, "无效的token".into()))?;

        self.user_repo
            .update_token("", user.id, None)
            .await
            .map_err(|_e| AppError::ResponseError(400, "更新token失败".into()))?;
        Ok(())
    }

    pub async fn update_profile(&self, form_data: UpdateUserRequest) -> Result<UserProfileResponse, AppError> {
        let current_user = self
            .user_repo
            .find_by_token(&form_data.token)
            .await?
            .ok_or_else(|| AppError::BadRequest("token无效".into()))?;

        let mut updated_user = form_data;
        updated_user.id = Some(current_user.id);

        if updated_user.password_new.is_some() {
            if !verify(updated_user.password.as_deref().unwrap_or_default(), &current_user.password)
                .map_err(|e| AppError::BadRequest(format!("密码验证失败: {}", e)))? {
                return Err(AppError::ResponseError(400, "当前密码错误".into()));
            }
            updated_user.password = updated_user.password_new.clone();
            updated_user.password_new = None;

            self.user_repo
                .update_password(updated_user)
                .await
                .map_err(|_e| AppError::ResponseError(400, "更新密码失败".into()))?;
        } else {
            self.user_repo
                .update_user(updated_user)
                .await
                .map_err(|_e| AppError::ResponseError(400, "更新资料失败".to_string()))?;
        }

        Ok(UserProfileResponse {
            token: current_user.token,
            id: current_user.id,
            account: current_user.account,
            email: current_user.email,
            nickname: current_user.nickname,
            avatar_url: current_user.avatar_url,
            register_time: current_user.register_time,
            bio: current_user.bio,
            balance: current_user.balance,
        })
    }

    pub async fn get_option(&self, form_data: OptionsRequest) -> Result<OptionItem, AppError> {
        let data = self
            .user_repo
            .find_options(&form_data.name.unwrap_or_default(), &form_data.group.unwrap_or_default())
            .await?
            .ok_or_else(|| AppError::BadRequest("不存在".into()))?;
        info!("{:?}", data);

        Ok(OptionItem {
            group: data.group,
            name: data.name,
            value: data.value,
        })
    }
}
