//! 应用配置（供 binary 程序使用）
//! 从 .env 文件加载配置，支持环境变量覆盖
#![allow(dead_code)]

use std::env;
use std::sync::OnceLock;

static APP_CONFIG: OnceLock<AppConfig> = OnceLock::new();

#[derive(Debug, Clone)]
pub struct AppConfig {
    pub database_url: String,
    pub redis_url: String,
    pub font_path: String,
    pub icon_path: String,
    pub ai_root: String,
    pub dcf_path: String,
    pub scan_csv_path: String,
}

impl AppConfig {
    pub fn load() -> &'static Self {
        APP_CONFIG.get_or_init(|| {
            dotenv::dotenv().ok();
            Self {
                database_url: env::var("DATABASE_URL").expect("DATABASE_URL not set in .env"),
                redis_url: env::var("REDIS_URL").expect("REDIS_URL not set in .env"),
                font_path: env::var("FONT_PATH").expect("FONT_PATH not set in .env"),
                icon_path: env::var("ICON_PATH").expect("ICON_PATH not set in .env"),
                ai_root: env::var("AI_ROOT").expect("AI_ROOT not set in .env"),
                dcf_path: env::var("DCF_PATH").expect("DCF_PATH not set in .env"),
                scan_csv_path: env::var("SCAN_CSV_PATH").expect("SCAN_CSV_PATH not set in .env"),
            }
        })
    }
}

impl Default for AppConfig {
    fn default() -> Self {
        panic!("AppConfig must be loaded from .env file")
    }
}
