#![allow(dead_code)]

use bb8_redis::{bb8, RedisConnectionManager};

pub async fn init_redis_pool(redis_url: &str) -> bb8::Pool<RedisConnectionManager> {
    let manager = RedisConnectionManager::new(redis_url)
        .expect("Invalid Redis URL");
    
    bb8::Pool::builder()
        .build(manager)
        .await
        .expect("Failed to create Redis pool")
}

#[tokio::test]
async fn test() -> Result<(), Box<dyn std::error::Error>> {
    use redis::AsyncCommands;
    let manager = bb8_redis::RedisConnectionManager::new("redis://192.168.8.8/")?;
    let pool = bb8::Pool::builder()
        .max_size(15)
        .build(manager)
        .await?;
    let mut conn = pool.get().await?;
    let _: () = conn.set("async_key", "async_value").await?;
    let value: String = conn.get("async_key").await?;
    println!("Async got value: {}", value);
    Ok(())
}