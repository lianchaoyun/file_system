#![allow(dead_code)]

use axum::http::StatusCode;
use axum::response::{IntoResponse, Response};
use axum::Json;
use sqlx::error::Error as SqlxError;
use redis::RedisError;
use bcrypt::BcryptError;
use std::fmt;
use serde_json::json;

#[derive(Debug)]
pub enum AppError {
    SqlxError(SqlxError),
    RedisError(RedisError),
    BcryptError(BcryptError),
    BadRequest(String),
    ResponseError(i64, String),
}

impl fmt::Display for AppError {
    fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
        match self {
            AppError::SqlxError(err) => write!(f, "Database error: {}", err),
            AppError::RedisError(err) => write!(f, "Redis error: {}", err),
            AppError::BcryptError(err) => write!(f, "Bcrypt error: {}", err),
            AppError::BadRequest(msg) => write!(f, "Bad request: {}", msg),
            AppError::ResponseError(code, msg) => write!(f, "Error response:[code={}] {}", code, msg),
        }
    }
}

impl IntoResponse for AppError {
    fn into_response(self) -> Response {
        match self {
            AppError::BadRequest(msg) => {
                (StatusCode::BAD_REQUEST, Json(json!(msg))).into_response()
            }
            AppError::ResponseError(code, msg) => {
                (StatusCode::OK, Json(json!({ "code": code, "msg": msg }))).into_response()
            }
            _ => (StatusCode::INTERNAL_SERVER_ERROR, Json(json!("Internal server error"))).into_response(),
        }
    }
}

impl From<SqlxError> for AppError {
    fn from(err: SqlxError) -> Self {
        AppError::SqlxError(err)
    }
}

impl From<RedisError> for AppError {
    fn from(err: RedisError) -> Self {
        AppError::RedisError(err)
    }
}

impl From<BcryptError> for AppError {
    fn from(err: BcryptError) -> Self {
        AppError::BcryptError(err)
    }
}

impl From<bb8::RunError<RedisError>> for AppError {
    fn from(err: bb8::RunError<RedisError>) -> Self {
        AppError::BadRequest(format!("Redis pool error: {:?}", err))
    }
}
