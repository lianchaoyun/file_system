#![allow(dead_code)]

use bcrypt::{hash, verify};
use regex::Regex;


pub fn hash_password(password: &str,is_simple:bool) -> Result<String, bcrypt::BcryptError> {
    if is_simple{
        Ok(password.to_string())
    }else{
        hash(password, 12)
    }
       
}

pub fn hash_password_verify(password: &str,hashed_password: &str,is_simple:bool) -> bool {
    if is_simple {
        password == hashed_password
    } else {
        verify(password, hashed_password).is_ok_and(|is_valid| is_valid)
    }
}


pub fn is_email(account: &str) -> bool {
    let re = Regex::new(r"^[^@\s]+@[^@\s]+\.[^@\s]+$").unwrap();
    re.is_match(account)
}
pub fn is_account(username: &str) -> bool {
    let re = Regex::new(r"^[a-zA-Z][a-zA-Z0-9_-]{2,19}$").unwrap();
    re.is_match(username)
}


pub fn validate_password(password: &str, is_strong:bool) -> Result<(), String> {
    let min_length = 6;
    let max_length = 64;

    if password.len() < min_length {
        return Err(format!("密码必须至少包含{}个字符", min_length));
    }

    if password.len() > max_length {
        return Err(format!("密码不能超过{}个字符", max_length));
    }
    if is_strong {
        let has_upper = Regex::new(r"[A-Z]").unwrap().is_match(password);
        let has_lower = Regex::new(r"[a-z]").unwrap().is_match(password);
        let has_digit = Regex::new(r"[0-9]").unwrap().is_match(password);
        let has_special = Regex::new(r"[^A-Za-z0-9]").unwrap().is_match(password);

        if !(has_upper && has_lower && has_digit && has_special) {
            return Err("密码必须包含大写字母、小写字母、数字和特殊字符".to_string());
        }
    }

    Ok(())
}









