#![allow(dead_code)]

use serde::{Deserialize, Serialize};



#[derive(Debug, Serialize, Deserialize)]
struct User {
    id: u64,
    name: String,
    is_active: bool,
    tags: Vec<String>,
}


#[test]
fn process_dynamic_json() {
    use serde_json::json;
    // 创建动态JSON
    let mut data = json!({
        "name": "John Doe",
        "age": 30,
        "phones": [
            "+44 1234567",
            "+44 2345678"
        ]
    });

    // 修改值
    data["age"] = json!(31);
    data["phones"].as_array_mut().unwrap().push(json!("+44 3456789"));

    // 访问值
    println!("Name: {}", data["name"]);
    println!("Second phone: {}", data["phones"][1]);

    // 序列化为字符串
    println!("{}", data.to_string());
}

#[test]
fn test() {
    // 序列化
    let user = User {
        id: 42,
        name: "Alice".to_string(),
        is_active: true,
        tags: vec!["admin".to_string(), "rustacean".to_string()],
    };
    
    let json_str = serde_json::to_string(&user).unwrap();
    println!("Serialized: {}", json_str);
    // 输出: {"id":42,"name":"Alice","is_active":true,"tags":["admin","rustacean"]}

    // 反序列化
    let json_str = r#"
        {
            "id": 99,
            "name": "Bob",
            "is_active": false,
            "tags": ["user"]
        }
    "#;
    
    let user: User = serde_json::from_str(json_str).unwrap();
    println!("Deserialized: {:?}", user);

    process_dynamic_json()
}