#![allow(dead_code, unused_imports)]

use std::net::SocketAddr;

pub fn generate_short_id() -> String {
    // 格式: timestamp(10位) + 随机(4位)，共14位数字
    let ts = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .unwrap()
        .as_secs();
    let rand: u32 = (ts % 10000) as u32;
    format!("{}{:04}", ts % 100_000_0000, rand)
}

pub fn extract_client_ip(addr: &SocketAddr) -> String {
    addr.ip().to_string()
}
