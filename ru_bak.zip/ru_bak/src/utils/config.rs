#![allow(dead_code)]

use std::env;

#[derive(Debug, Clone)]
pub struct Config {
    pub database_url: String,
    pub redis_url: String,
    pub jwt_secret: String,
    pub jwt_expires_in: i64,
    pub static_dir: String,
    // 通达信配置
    pub tdx_root: String,
    pub decrypt_script: String,
    pub decrypt_json: String,
    // 应用路径配置
    pub font_path: String,
    pub icon_path: String,
    pub ai_root: String,
    pub dcf_path: String,
    pub scan_csv_path: String,
}

impl Config {
    pub fn from_env() -> Result<Self, env::VarError> {
        Ok(Self {
            database_url: env::var("DATABASE_URL")?,
            redis_url: env::var("REDIS_URL")?,
            jwt_secret: env::var("JWT_SECRET")?,
            jwt_expires_in: env::var("JWT_EXPIRES_IN")?.parse().unwrap_or(86400),
            static_dir: env::var("STATIC_DIR").unwrap_or_else(|_| "./static".to_string()),
            tdx_root: env::var("TDX_ROOT").unwrap_or_else(|_| r"D:\app\chinastock".to_string()),
            decrypt_script: env::var("DECRYPT_SCRIPT").unwrap_or_else(|_| r"D:\project\yun\ai\src\lib\tdx\gbbq\decrypt_gbbq.py".to_string()),
            decrypt_json: env::var("DECRYPT_JSON").unwrap_or_else(|_| r"D:\project\yun\ai\src\lib\tdx\gbbq\gbbq_decrypted.json".to_string()),
            font_path: env::var("FONT_PATH").unwrap_or_else(|_| r"C:\Windows\Fonts\msyh.ttc".to_string()),
            icon_path: env::var("ICON_PATH").unwrap_or_else(|_| r"D:\project\yun\server\data\icon.ico".to_string()),
            ai_root: env::var("AI_ROOT").unwrap_or_else(|_| r"D:\project\yun\ai".to_string()),
            dcf_path: env::var("DCF_PATH").unwrap_or_else(|_| r"D:\app\东方财富\mainfree.exe".to_string()),
            scan_csv_path: env::var("SCAN_CSV_PATH").unwrap_or_else(|_| r"D:\project\yun\ai\data\report\scan_all.csv".to_string()),
        })
    }
}