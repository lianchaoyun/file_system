#![allow(dead_code)]

use moka::sync::Cache;
use once_cell::sync::OnceCell;

static GLOBAL_CACHE: OnceCell<Cache<String, String>> = OnceCell::new();
pub fn get_cache() -> &'static Cache<String, String> {
    GLOBAL_CACHE.get_or_init(|| {
        Cache::builder()
            .max_capacity(10_000)
            .time_to_live(std::time::Duration::from_secs(3600))
            .build()
    })
}

#[test]
fn test() {
    let cache1 = get_cache();
    cache1.insert("key1".to_string(), "value1".to_string());
    if let Some(value) = cache1.get("key1") {
        println!("Got: {}", value);
    }
    // 原子操作
    cache1.run_pending_tasks(); // 执行后台维护任务
}