//! 统一日志系统
//!
//! 同时输出到控制台（stdout）和文件，通过 RUST_LOG 控制级别。
//! 调用 `init_logging` 后，用简洁函数输出：
//!
//!   log!("启动成功，账户余额 {balance}");
//!   warn!("风险警告");
//!   err!("数据库连接失败");
//!
//! 初始化（main.rs）：
//!   let _guard = web::utils::log::init(Some("aiai"));
//!
//! 控制级别：
//!   set RUST_LOG=debug
//!   set RUST_LOG=aiai::ws=debug

use std::path::PathBuf;
use tracing_appender::rolling::{Rotation, RollingFileAppender};
use tracing_subscriber::{fmt, prelude::*, EnvFilter};

// ── 自定义本地时间格式 ────────────────────────────────

/// 本地时间格式化：`2026-05-23 17:14:40`
struct LocalTimer;
impl fmt::time::FormatTime for LocalTimer {
    fn format_time(&self, w: &mut fmt::format::Writer<'_>) -> std::fmt::Result {
        let now = chrono::Local::now();
        write!(w, "{}", now.format("%Y-%m-%d %H:%M:%S"))
    }
}

// ── 简洁日志宏 ────────────────────────────────────────

/// 简洁日志（= tracing::info!）
#[macro_export]
macro_rules! log {
    ($($arg:tt)*) => { tracing::info!($($arg)*) };
}

/// 简洁警告（= tracing::warn!）
#[macro_export]
macro_rules! wrn {
    ($($arg:tt)*) => { tracing::warn!($($arg)*) };
}

/// 简洁错误（= tracing::error!）
#[macro_export]
macro_rules! err {
    ($($arg:tt)*) => { tracing::error!($($arg)*) };
}

// ── LogGuard ──────────────────────────────────────────

/// 日志文件输出的 _guard，调用方必须保持存活（通常 main 中 `let _guard = ...`）
pub struct LogGuard {
    _guard: tracing_appender::non_blocking::WorkerGuard,
}

// ── 初始化 ────────────────────────────────────────────

/// 快捷初始化：控制台 + 文件双输出
///
/// `log_name`: 为 `Some("aiai")` 则日志文件为 `./logs/aiai.log`，`None` 用 `app`。
pub fn init(log_name: Option<&str>) -> LogGuard {
    let name = log_name.unwrap_or("app");
    init_full(name, None)
}

/// 完整参数版
pub fn init_full(log_name: &str, logs_dir: impl Into<Option<PathBuf>>) -> LogGuard {
    let dir = logs_dir.into().unwrap_or_else(|| PathBuf::from("logs"));

    let _ = std::fs::create_dir_all(&dir);

    // 文件日志 —— 按天轮转
    let file_appender = RollingFileAppender::new(Rotation::DAILY, &dir, &format!("{log_name}.log"));
    let (non_blocking, guard) = tracing_appender::non_blocking(file_appender);

    // EnvFilter：从 RUST_LOG 读取，无环境变量时默认 INFO
    let env_filter = EnvFilter::try_from_default_env()
        .unwrap_or_else(|_| EnvFilter::new("info"));

    let subscriber = tracing_subscriber::registry()
        // 控制台层（stdout，带颜色）
        .with(
            fmt::layer()
                .with_writer(std::io::stdout)
                .with_ansi(true)
                .with_timer(LocalTimer)
                .with_filter(env_filter),
        )
        // 文件层（无颜色）
        .with(
            fmt::layer()
                .with_writer(non_blocking)
                .with_ansi(false)
                .with_timer(LocalTimer),
        );

    tracing::subscriber::set_global_default(subscriber)
        .expect("Failed to set tracing subscriber");

    tracing::info!("📝 日志系统已启动 | 目录: {:?} | 文件: {log_name}.log", dir);
    tracing::info!("💡 设置 RUST_LOG 控制级别: trace / debug / info / warn / error");
    tracing::info!("🖥 控制台 + 📄 文件 双输出已就绪");

    LogGuard { _guard: guard }
}
