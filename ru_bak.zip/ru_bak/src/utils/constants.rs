#![allow(dead_code)]

pub mod response_code {
    pub const SUCCESS: u32 = 200;
    pub const BAD_REQUEST: u32 = 400;
    pub const UNAUTHORIZED: u32 = 401;
}

