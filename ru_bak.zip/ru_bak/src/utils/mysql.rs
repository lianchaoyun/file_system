#[tokio::test]
async fn test() -> Result<(), sqlx::Error> {
    // 创建连接池
/*    let pool = MySqlPool::connect("mysql://root:423522@192.168.8.8:3306/o").await?;
    
    // 查询数据
    let users = sqlx::query_as::<_, User>("SELECT ID as id,user_login,user_email FROM users WHERE ID = ?")
        .bind(1)
        .fetch_all(&pool)
        .await?;
    
    for user in users {
        println!("{:?}", user);
        println!("id: {}, login: {}, email: {}", user.id, user.user_login, user.user_email);
    }*/
    
/*
    sqlx::query("INSERT INTO users (name, email) VALUES (?, ?)")
        .bind("Alice")
        .bind("alice@example.com")
        .execute(&pool)
        .await?;




    let mut tx = pool.begin().await?;
    
    // 扣款
    sqlx::query("UPDATE accounts SET balance = balance - ? WHERE id = ?")
        .bind(amount)
        .bind(from)
        .execute(&mut *tx)
        .await?;
    
    // 存款
    sqlx::query("UPDATE accounts SET balance = balance + ? WHERE id = ?")
        .bind(amount)
        .bind(to)
        .execute(&mut *tx)
        .await?;
    
    tx.commit().await?;


     */

    Ok(())
}