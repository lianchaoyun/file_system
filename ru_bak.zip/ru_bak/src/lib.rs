//! ru —— 多市场量化交易 + Web API 全栈平台

// ── 根级工具模块 ──────────────────────────────────
#[path = "utils/config.rs"]
pub mod config;

#[path = "utils/error.rs"]
pub mod error;

#[path = "utils/app_config.rs"]
pub mod app_config;

#[path = "utils/log.rs"]
pub mod log;

// ── Web 子模块（挂载到 crate 根）────────────────────
#[path = "web/handlers/mod.rs"]
pub mod handlers;

#[path = "web/models/mod.rs"]
pub mod models;

#[path = "web/repositories/mod.rs"]
pub mod repositories;

#[path = "web/services/mod.rs"]
pub mod services;

// ── utils 剩余子模块（cache, verify 等仍走 crate::utils::）───
#[path = "utils/mod.rs"]
pub mod utils;

// ── seek ─────────────────────────────────────────
#[path = "seek/mod.rs"]
pub mod seek;

// ── web 公共 API（serve, spawn_server, AppState）────
#[path = "web/lib.rs"]
pub mod web;
