import pandas as pd


def load_csv(path="./lib/data/kdata/1.csv"):
    data_ = pd.read_csv(path, parse_dates=['datetime'], index_col="datetime")
    return data_

def load_feather(path=None):
    data_ = pd.read_feather(path)
    return data_



def load_hik(market_code = None,show_log=False):
    from hikyuu import sm
    from hikyuu.interactive import Datetime
    from lib.hik.lib_hik import get_stock_kdata, get_query, get_random_stock
    if not market_code:
        market_code = get_random_stock()
    if show_log:
        print(sm[market_code])
    data_ = get_stock_kdata(market_code, get_query(start=Datetime('2017-01-01'), end=Datetime())).to_df()
    return data_



def load_yfinance():
    import yfinance as yf
    dat = yf.Ticker("MSFT")
    print(dat.history(period='1mo'))


def load_e():
    import efinance as ef
    stock_code = '600519'
    ef.stock.get_quote_history(stock_code)
    print(ef.stock.get_quote_history(stock_code))