import backtrader as bt
from btrader import BaseStrategy


class TestStrategy(BaseStrategy):
    def __init__(self):
        super().__init__()
        self.show_log = False
        self.trade_units = 100  # 每次交易的股数
        #self.yd = self.getdatabyname('1d')

    def next(self):
        current_datetime = self.data.datetime.date(0)

        # 1. 获取当前 1D K 线的时间
       # current_1d_datetime = self.yd.datetime.date(0)

        # 打印时间用于观察
        print(f'当前K线时间: {current_datetime.strftime("%Y-%m-%d %H:%M:%S")} | 最新日线时间: {current_datetime.strftime("%Y-%m-%d %H:%M:%S")}')






    def notify_order(self, order):
        super().notify_order(order)
        if order.status in [order.Completed]:
            pass