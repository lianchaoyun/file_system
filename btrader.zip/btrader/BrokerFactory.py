
def set_broker(cerebro,cash = 100000.0):
    cerebro.broker.setcash(cash) # 初始资金
    cerebro.broker.set_slippage_perc(perc=0.05) # 百分比滑点
    cerebro.broker.setcommission(commission=0.00008)