import backtrader as bt
from lib.btrader.BaseStrategy import BaseStrategy

from lib.indi.MyTT import *


class TestStrategy(BaseStrategy):
    c = None
    order = None
    def __init__(self):
        super().__init__()
        c= self
        self.show_log = True
        c.bar_count = 0
        c.atr_period = 20  # ATR周期
        c.risk_per_trade = 0.01  # 单笔风险 1%
        # 均线参数
        c.p_ma1 = 20  # 均线1
        c.p_ma2 = 60  # 均线2
        # MACD 参数
        c.p_macd_short = 12  # MACD快线
        c.p_macd_long = 26  # MACD慢线
        c.p_macd_mid = 9  # MACD信号线
        # OBV 参数
        c.p_obv_ma = 30  # OBV均值天数
        # 突破与连涨连跌参数
        c.p_bt_days = 3  # 突破天数
        c.p_rise_total = 5  # 连涨统计天数
        c.p_rise_days = 3  # 连涨天数
        c.p_fall_total = 5  # 连跌统计天数
        c.p_fall_days = 3  # 连跌天数
        # 涨跌幅阈值
        c.p_inc = 0.8  # 当天涨幅
        c.p_dec = 0.8  # 当天跌幅
        # 权重参数
        c.p_wt = 8  # 上涨权重
        c.p_ft = 8  # 下跌权重
        # 均线斜率参数
        c.p_slp_ma = 10  # 均线斜率
        data0 = self.datas[0]
        #self.ma1 = bt.indicators.MovingAverageSimple(data0, period=c.p_ma1)
        #self.ma2 = bt.indicators.MovingAverageSimple(data0, period=c.p_ma2)


    def next(self):
        data = self.datas[0]
        print(data.datetime.date(0))



        if self.order:
            return



    def notify_order(self, order):
        super().notify_order(order)
        if order.status in [order.Completed]:
            self.order = None

    def notify_trade(self, trade):
        if trade.isclosed:
            self.log(f'交易结束, 毛利润 {trade.pnl:.2f}, 净利润 {trade.pnlcomm:.2f}')
