import backtrader as bt
import pandas as pd

from btrader import BaseStrategy


class TestStrategy(BaseStrategy):
    def __init__(self):
        super().__init__()
        self.sma20 = bt.indicators.SMA(
            self.data.close,
            period=20
        )

        self.macd = bt.ind.MACD(self.data.close,period_me1=12,period_me2=26,period_signal=9)
        self.macd_line = self.macd.macd
        self.signal_line = self.macd.signal
        self.histogram = bt.ind.MACDHisto( self.macd)

        self.rsi = bt.ind.RSI(
            self.data.close,
            period=14,
            upperband=70,
            lowerband=30
        )

    def next(self):
        dt = self.datas[0].datetime.date(0)
        pos = self.getposition()
        cash = self.broker.getcash()
        value = self.broker.getvalue()
        close = self.data.close[0]

        open = self.data.open[0]
        high = self.data.high[0]
        low = self.data.low[0]
        volume = self.data.volume[0]

        # self.log(f"{value:>8.0f}  {pos.size:>8}  {close:>8.2f}  {open:>8.2f}  {high:>8.2f}  {low:>8.2f}  {volume:>12.2f}", True, dt, len(self.data))

        #if self.data.close[0] > self.sma20[0]:  # 价格在生命线上方
        #    self.buy(size=100)
        #elif self.data.close[0] < self.sma20[0]:  # 价格在生命线下方
        #    if pos.size >= 100:
        #        self.sell(size=100)
        highs = max(self.data.high.get(size=10))
        lows = max(self.data.low.get(size=10))
        dp = (highs - close)/highs
        lp = (lows - close)/lows
        if dp > 0.1:
            self.buy(size=1000)
        elif lp < 0.1:
            if pos.size > 1000:
                self.sell(size=1000)


        self.log(f"{value:>8.0f}  {pos.size:>8}  {close:>8.2f}  {open:>8.2f}  {high:>8.2f}  {low:>8.2f}  {volume:>12.2f}", True, dt, len(self.data))


