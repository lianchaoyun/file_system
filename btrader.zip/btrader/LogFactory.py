import pandas as pd
from  lib.indi.MyTT_yun import *


def log_kdata(data_, log_type="df"):
    if log_type == "string":
        print(data_.to_string())
    elif log_type == "df":
        print(data_)


# 打印分析结果
def log_reault(cerebro, results, show_plot=False, print_value=False):
    strat = results[0]
    trade_analysis = strat.analyzers.trades.get_analysis()
    if trade_analysis.total.total > 0:
        print(
            '年化/回撤/胜率: %.2f%%/ %.2f%%/ %.2f%%' % (
                strat.analyzers.returns.get_analysis()['rnorm100'],
                strat.analyzers.drawdown.get_analysis()['max']['drawdown'],
                trade_analysis.get("won", {}).get("total", 0) /
                abs(trade_analysis.get("total", {}).get("closed", 0.01)) * 100),
            '夏普比率:%s' % strat.analyzers.sharpe.get_analysis()['sharperatio']
        )
        # 获取观察者的数据
        if print_value:
            observer_data = cerebro.runstrats[0][0].observers[0]  # 第一个观察者
            value_history = observer_data.lines.value.array  # 总资产历史数据
            print("资产曲线:", value_history)
            cash_history = observer_data.lines.cash.array  # 总资产历史数
            print("现金曲线:", cash_history)

            trans_dict = strat.analyzers.trans.get_analysis()
            trades_list = []
            for date, amounts in trans_dict.items():
                for trade in amounts:
                    # trade 结构: [amount, price, sid, symbol, value]
                    trades_list.append({
                        'Date': date,
                        'Amount': trade[0],  # 正数为买入，负数为卖出
                        'Price': trade[1],  # 成交价格
                        'Value': trade[4]  # 成交额
                    })
            print(pd.DataFrame(trades_list))


    # 绘制结果
    if show_plot:
        cerebro.plot(style='candlestick', volume=True)


def result_data(cerebro, df, results):
    df.index.name = 'time'

    df['total_asset'] = 0.0
    df['cash'] = 0.0
    df['signal'] = ''

    strat = results[0]
    trade_analysis = strat.analyzers.trades.get_analysis()
    
    # 从 broker 获取数据
    value_history = []
    cash_history = []
    
    try:
        # 从观察者获取
        strat_obj = cerebro.runstrats[0][0]
        if hasattr(strat_obj, 'observers'):
            observers = strat_obj.observers
            
            for obs in observers:
                obs_type = type(obs).__name__
                # Broker 观察者只有 cash，Value 观察者只有 value
                # CashValueObserver 两者都有
                if obs_type in ('Broker',):
                    try:
                        if hasattr(obs.lines, 'cash'):
                            cash_history = list(obs.lines.cash.array)
                    except:
                        pass
                elif obs_type in ('Value',):
                    try:
                        if hasattr(obs.lines, 'value'):
                            value_history = list(obs.lines.value.array)
                    except:
                        pass
                elif obs_type in ('CashValue', 'CashValueObserver'):
                    try:
                        if hasattr(obs.lines, 'cash'):
                            cash_history = list(obs.lines.cash.array)
                        if hasattr(obs.lines, 'value'):
                            value_history = list(obs.lines.value.array)
                    except:
                        pass
    except:
        pass
    
    # 如果观察者数据为空，使用 broker 当前值填充
    if not value_history:
        current_value = strat.broker.getvalue()
        current_cash = strat.broker.getcash()
        df['total_asset'] = current_value
        df['cash'] = current_cash
    else:
        # Backtrader 观察者数据：lines.array[0] 是最新数据
        # 反向对应：array[i] 对应 df 的第 len(df)-1-i 行
        value_history = list(value_history)
        cash_history = list(cash_history)
        
        # 跳过末尾的 nan
        last_valid_idx = len(value_history) - 1
        for i in range(len(value_history) - 1, -1, -1):
            if not pd.isna(value_history[i]):
                last_valid_idx = i
                break
        
        value_history = value_history[:last_valid_idx + 1]
        cash_history = cash_history[:last_valid_idx + 1]
        
        # 截取到 df 的长度
        if len(value_history) > len(df):
            value_history = value_history[-len(df):]
            cash_history = cash_history[-len(df):]
        
        # 反向填充
        for i, (v, c) in enumerate(zip(value_history, cash_history)):
            df_idx = len(df) - len(value_history) + i
            if not pd.isna(v):
                df.iloc[df_idx, df.columns.get_loc('total_asset')] = v
            if not pd.isna(c):
                df.iloc[df_idx, df.columns.get_loc('cash')] = c

    # 处理交易信号
    trans_dict = strat.analyzers.trans.get_analysis()
    transaction_signs = []
    for date, amounts in trans_dict.items():
        buy = False
        sell = False
        for trade in amounts:
            if trade[0] > 0:
                buy = True
            if trade[0] < 0:
                sell = True

        sign = "T" if buy and sell else ("B" if buy else "S")
        transaction_signs.append({'datetime': date, 'signal': sign})

    if not transaction_signs:
        return df

    signs_df = pd.DataFrame(transaction_signs)
    signs_df = signs_df.set_index('datetime')
    
    # 尝试匹配日期
    def get_signal(dt):
        if pd.isna(dt):
            return ''
        if dt in signs_df.index:
            return signs_df.loc[dt, 'signal']
        dt_str = pd.Timestamp(dt).strftime('%Y-%m-%d %H:%M:%S')
        if dt_str in signs_df.index:
            return signs_df.loc[dt_str, 'signal']
        dt_date = pd.Timestamp(dt).date()
        for idx in signs_df.index:
            if pd.Timestamp(idx).date() == dt_date:
                return signs_df.loc[idx, 'signal']
        return ''
    
    df['signal'] = df.index.map(get_signal)
    return df