import backtrader as bt

from btrader import BaseStrategy


class TestStrategy(BaseStrategy):
    def __init__(self):
        super().__init__()
        self.show_log  =  False
        self.sma = bt.indicators.SimpleMovingAverage(self.data.close, period=15)

    def next(self):
        dt = self.datas[0].datetime.date(0)  # 获取当前的回测时间点
        position = self.getposition()
        cash = self.broker.getcash()  # 获取当前现金
        value = self.broker.getvalue()  # 获取当前总资产价值
        close = self.data.close[0]  # 当前价格
        size = int(cash / close)

        # 当收盘价高于SMA时买入
        if self.data.close[0] > self.sma[0]:
            self.buy(exectype=bt.Order.Market, size=100)
        # 当收盘价低于SMA时卖出
        elif self.data.close[0] < self.sma[0]:
            if position.size >= 100:
                self.sell(exectype=bt.Order.Market, size=100)

