import backtrader as bt


# 添加分析器
def set_analyzer_list(cerebro):
    cerebro.addanalyzer(bt.analyzers.Transactions, _name='trans')
    cerebro.addanalyzer(bt.analyzers.Returns, _name='returns')  # 年化收益率
    cerebro.addanalyzer(bt.analyzers.DrawDown, _name='drawdown')  # 回测
    cerebro.addanalyzer(bt.analyzers.TradeAnalyzer, _name='trades')  # 交易记录
    cerebro.addanalyzer(bt.analyzers.SharpeRatio, _name='sharpe')  # 夏普比率

