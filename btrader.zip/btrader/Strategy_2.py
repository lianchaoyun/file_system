import backtrader as bt
from btrader import BaseStrategy


class TestStrategy(BaseStrategy):
    def __init__(self):
        super().__init__()
        self.show_log = False
        self.base_price = None  # 基准价格
        self.grid_size = 0.01  # 1%的网格大小
        self.trade_units = 100  # 每次交易的股数
        self.initial_investment_ratio = 0.5  # 初始投资比例50%

    def next(self):
        # 如果是第一个数据点，设置基准价格并进行初始买入
        if self.base_price is None:
            self.base_price = self.data.close[0]
            cash = self.broker.getcash()
            value = self.broker.getvalue()
            close = self.data.close[0]

            # 计算初始买入数量（总资产的50%）
            investment_amount = value * self.initial_investment_ratio
            size = int(investment_amount / close)
            print("计算"+str(cash)
                  +"-"+ str(value)
                  +"-" + str(close)
                  +"-"+ str(investment_amount)
                  + "-" + str(size)
                  )
            if size > 0:
                self.buy(exectype=bt.Order.Market, size=size)
                self.log(f'初始买入: {size}股 @ {close}, 基准价: {self.base_price}')
            return

        current_price = self.data.close[0]
        position = self.getposition()

        # 计算当前价格相对于基准价格的涨跌百分比
        price_change = (current_price - self.base_price) / self.base_price

        # 计算当前处于哪个网格层级
        grid_level = int(round(price_change / self.grid_size))

        # 计算目标持仓量 (每上涨1%减少100股，每下跌1%增加100股)
        target_size = position.size - grid_level * self.trade_units

        # 计算需要交易的量
        trade_size = target_size - position.size

        if trade_size > 0:
            # 需要买入
            self.buy(exectype=bt.Order.Market, size=trade_size)
            self.log(f'网格买入: {trade_size}股 @ {current_price}, 网格层级: {grid_level}')
        elif trade_size < 0:
            # 需要卖出
            if position.size >= abs(trade_size):  # 确保有足够持仓可以卖出
                self.sell(exectype=bt.Order.Market, size=abs(trade_size))
                self.log(f'网格卖出: {abs(trade_size)}股 @ {current_price}, 网格层级: {grid_level}')

        # 更新基准价格为当前价格，以便下一次计算
        if trade_size != 0:
            self.base_price = current_price

        # 记录交易历史供后续导出

    def notify_order(self, order):
        super().notify_order(order)
        if order.status in [order.Completed]:
            pass