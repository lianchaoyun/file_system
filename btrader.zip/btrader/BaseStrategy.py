import backtrader as bt


class BaseStrategy(bt.Strategy):
    def __init__(self):
        self.bug_trades = 0
        self.sell_trades = 0
        self.failed_trades = 0
        self.show_log = False

    def notify_order(self, order):
        if order.status in [order.Submitted, order.Accepted]:
            # 订单已提交/接受 - 无需操作
            return
        if order.status in [order.Completed]:
            if order.isbuy():
                self.log(
                    f'买{order.executed.size}  {order.executed.price:.2f}',
                    self.show_log)
                self.bug_trades += 1
            elif order.issell():
                self.log(
                    f'卖{order.executed.size}  {order.executed.price:.2f}',
                    self.show_log)
                self.sell_trades += 1
        elif order.status in [order.Canceled, order.Margin, order.Rejected]:
            self.log(f'订单失败【{order.Status[order.status]}】',
                     self.show_log)
            self.failed_trades += 1

    def log(self, txt, show=True, dt=None, index=None):
        if not show:
            return
        dt = dt or self.datas[0].datetime.date(0)
        if index:
            print(f"{index:>4} {dt.isoformat()}, {txt}")
        else:
            print(f"{dt.isoformat()}, {txt}")

    def stop(self):
        self.log(
            f"最终资产: {self.broker.getvalue():.2f} 买/卖/失败/长度: {self.bug_trades}/{self.sell_trades}/{self.failed_trades}/{len(self.data)}",
            True)
