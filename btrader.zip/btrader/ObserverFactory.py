from backtrader import Observer
import backtrader as bt


class CashValueObserver(Observer):
    lines = ('cash', 'value')
    plotinfo = dict(plot=False, subplot=True)

    def next(self):
        self.lines.cash[0] = self._owner.broker.getcash()
        self.lines.value[0] = self._owner.broker.getvalue()


# 添加观察者
def set_observer_list(cerebro):
    # 添加自定义的 CashValueObserver
    cerebro.addobserver(CashValueObserver)
    # 添加 Backtrader 内置的 Broker 观察者（记录 cash）
    cerebro.addobserver(bt.observers.Broker)
    # 添加 Backtrader 内置的 Value 观察者（记录总资产）
    cerebro.addobserver(bt.observers.Value)
