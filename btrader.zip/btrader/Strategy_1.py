import backtrader as bt

from lib.btrader.BaseStrategy import BaseStrategy


class TestStrategy(BaseStrategy):
    def __init__(self):
        super().__init__()
        self.show_log = False

        # 海龟交易参数
        self.entry_period = 10  # 入市通道周期
        self.exit_period = 10  # 退出通道周期
        self.atr_period = 20  # ATR周期
        self.risk_factor = 0.02  # 风险因子(每次交易风险占总资金的2%)
        self.position_size = 0  # 头寸规模

        # 计算指标
        self.high_20 = bt.indicators.Highest(self.data.high, period=self.entry_period)
        self.low_20 = bt.indicators.Lowest(self.data.low, period=self.entry_period)
        self.high_10 = bt.indicators.Highest(self.data.high, period=self.exit_period)
        self.low_10 = bt.indicators.Lowest(self.data.low, period=self.exit_period)
        self.atr = bt.indicators.ATR(self.data, period=self.atr_period)

        # 跟踪变量
        self.last_buy_price = 0  # 上次买入价格
        self.unit = 0  # 交易单位
        self.max_units = 4  # 最大加仓次数

    def next(self):
        dt = self.datas[0].datetime.date(0)
        pos = self.getposition()
        cash = self.broker.getcash()
        value = self.broker.getvalue()
        close = self.data.close[0]

        # 计算头寸规模 (1N = 1ATR)
        N = self.atr[0]
        if N > 0:
            self.unit = int((value * self.risk_factor) / (N * self.data.close[0]))

        # 入场信号: 价格突破20日高点
        if len(self.data.close) > self.entry_period:
            if not pos and self.data.close[0] > self.high_20[-1]:
                # 首次买入
                size = min(self.unit, int(cash / close))
                if size > 0:
                    self.buy(size=size)
                    self.last_buy_price = close
                    self.position_size = 1

            # 加仓信号: 价格比上次买入高0.5N且未达到最大加仓次数
            elif (0 < pos.size < self.max_units * self.unit and
                  close > self.last_buy_price + 0.5 * N):
                size = min(self.unit, int(cash / close))
                if size > 0:
                    self.buy(size=size)
                    self.last_buy_price = close
                    self.position_size += 1

        # 退出信号: 价格跌破10日低点
        if pos.size > 0 and self.data.close[0] < self.low_10[-1]:
            self.close()
            self.position_size = 0



    def notify_trade(self, trade):
        if trade.isclosed:
            self.log(f'交易结束, 毛利润 {trade.pnl:.2f}, 净利润 {trade.pnlcomm:.2f}')