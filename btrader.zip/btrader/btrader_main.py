import backtrader as bt
import pandas as pd

from lib.btrader import DataFactory
from lib.btrader import ObserverFactory
from lib.btrader import AnalyzerFactory
from lib.btrader import LogFactory
from lib.btrader import BrokerFactory
from lib.btrader.Strategy_w import TestStrategy

cerebra = bt.Cerebro()

# 设置数据
# data_ = DataFactory.load_hik(show_log=True,market_code="SZ002847")
data_ = DataFactory.load_csv("./data/kdata_01.csv")

#data_ = DataFactory.load_feather("./stock/SOLUSDC/1h.feather")

#print(data_)
data0 = bt.feeds.PandasData(dataname=data_,timeframe=bt.TimeFrame.Days, compression=60)
a = cerebra.adddata(data0)


#data1_ = DataFactory.load_feather("./stock/SOLUSDC/1d.feather")
#data1 =  bt.feeds.PandasData(dataname=data1_,timeframe=bt.TimeFrame.Days, compression=1)
#print(data1_.to_string())
#cerebra.adddata(data1 ,"1d")

LogFactory.log_kdata(data_, "no")

# 设置分析器
AnalyzerFactory.set_analyzer_list(cerebra)

# 设置观察者
ObserverFactory.set_observer_list(cerebra)

# 设置策略
cerebra.addstrategy(TestStrategy)
# 设置经纪人
BrokerFactory.set_broker(cerebra, 100000)

# 运行回测
results = cerebra.run()

# 记录回测结果
LogFactory.log_reault(cerebra, results, False, False)


returnData = LogFactory.result_data(cerebra, data_,results)
returnData = returnData.fillna(0)
print(returnData.to_string())
returnData.to_csv("./data/backtesting_result.csv")