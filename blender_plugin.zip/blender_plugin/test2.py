import bpy


def get_armature_data():
    """
    Reads the bone data from the selected armature and prints it to the console.
    """
    # Check if an armature is selected
    if not bpy.context.active_object or bpy.context.active_object.type != 'ARMATURE':
        print("Please select an Armature object.")
        return

    armature_obj = bpy.context.active_object
    armature_data = armature_obj.data

    print("### Armature Data Start ###")
    print(f"Rig Name: {armature_obj.name}")

    # Switch to edit mode to get accurate head/tail positions
    bpy.ops.object.mode_set(mode='EDIT')

    bone_data = {}
    for bone in armature_data.edit_bones:
        parent_name = bone.parent.name if bone.parent else None

        # We store the data as a dictionary
        bone_data[bone.name] = {
            "head": (round(bone.head.x, 4), round(bone.head.y, 4), round(bone.head.z, 4)),
            "tail": (round(bone.tail.x, 4), round(bone.tail.y, 4), round(bone.tail.z, 4)),
            "parent": parent_name
        }

    # Print the data in a Python dictionary format
    print("bone_data = {")
    for name, data in bone_data.items():
        print(f'    "{name}": {{"head": {data["head"]}, "tail": {data["tail"]}, "parent": "{data["parent"]}"}},')
    print("}")

    # Switch back to object mode
    bpy.ops.object.mode_set(mode='OBJECT')

    print("### Armature Data End ###")
    print("Please copy the dictionary content between the start/end markers and send it to me.")


# Run the function
if __name__ == "__main__":
    get_armature_data()