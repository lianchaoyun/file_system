import bpy
import os

def export_mesh_data_to_file():
    """
    Exports the vertex, face, and normal data of the active object
    to a file named a.txt on the user's desktop.
    """
    # 1. 检查是否有活动的选中物体
    obj = bpy.context.active_object
    if not obj or obj.type != 'MESH':
        print("错误: 请先选中一个网格物体（Mesh Object）。")
        return

    mesh = obj.data

    # 2. 获取桌面路径
    desktop_path = os.path.join(os.path.expanduser('~'), 'Desktop')
    output_file_path = os.path.join(desktop_path, 'a.txt')

    # 3. 收集网格信息
    verts = [v.co.xyz for v in mesh.vertices]
    faces = [p.vertices for p in mesh.polygons]
    # 法线可能在顶点或面上，这里我们获取顶点法线
    normals = [v.normal.xyz for v in mesh.vertices]

    # 4. 将信息写入文件
    print(f"正在将网格数据写入文件: {output_file_path}")
    try:
        with open(output_file_path, 'w', encoding='utf-8') as f:
            f.write(f"### Blender Mesh Data for '{obj.name}' ###\n\n")

            # 写入顶点信息
            f.write(f"verts = [\n")
            for v in verts:
                f.write(f"    ({v.x:.6f}, {v.y:.6f}, {v.z:.6f}),\n")
            f.write(f"]\n\n")

            # 写入面信息
            f.write(f"faces = [\n")
            for face in faces:
                # 将面索引转换为元组格式
                f.write(f"    ({', '.join(map(str, face))}),\n")
            f.write(f"]\n\n")

            # 写入法线信息
            f.write(f"normals = [\n")
            for n in normals:
                f.write(f"    ({n.x:.6f}, {n.y:.6f}, {n.z:.6f}),\n")
            f.write(f"]\n")
        print("数据已成功写入文件。")
    except Exception as e:
        print(f"写入文件时出错: {e}")

# 执行函数
export_mesh_data_to_file()