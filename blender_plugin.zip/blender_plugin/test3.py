import bpy


def create_armature_from_data():
    """
    Creates an armature based on the provided dictionary data.
    """
    # Check if we are in object mode
    if bpy.context.mode != 'OBJECT':
        bpy.ops.object.mode_set(mode='OBJECT')

    # Data copied from the user's log
    bone_data = {
        "mixamorig:Hips": {"head": (-0.0, 104.2749, 1.5543), "tail": (-0.0, 114.8332, 1.6907), "parent": None},
        "mixamorig:Spine": {"head": (-0.0, 114.4565, 1.6858), "tail": (-0.0, 124.3504, 0.2151),
                            "parent": "mixamorig:Hips"},
        "mixamorig:Spine1": {"head": (-0.0, 124.3504, 0.2151), "tail": (-0.0, 133.5712, -1.1555),
                             "parent": "mixamorig:Spine"},
        "mixamorig:Spine2": {"head": (-0.0, 133.5712, -1.1555), "tail": (-0.0, 147.1711, -2.8202),
                             "parent": "mixamorig:Spine1"},
        "mixamorig:Neck": {"head": (-0.0, 150.3116, -3.2046), "tail": (-0.0, 160.0036, -4.3909),
                           "parent": "mixamorig:Spine2"},
        "mixamorig:Head": {"head": (-0.0, 159.9295, -1.5195), "tail": (-0.0, 183.0361, -4.3478),
                           "parent": "mixamorig:Neck"},
        "mixamorig:HeadTop_End": {"head": (-0.0, 181.9669, 5.9816), "tail": (-0.0, 205.0734, 3.1533),
                                  "parent": "mixamorig:Head"},
        "mixamorig:RightShoulder": {"head": (-4.57, 144.5861, -3.3164), "tail": (-15.1628, 144.0613, -5.5485),
                                    "parent": "mixamorig:Spine2"},
        "mixamorig:RightArm": {"head": (-15.1628, 144.0613, -5.5485), "tail": (-43.0044, 144.0613, -5.5485),
                               "parent": "mixamorig:RightShoulder"},
        "mixamorig:RightForeArm": {"head": (-43.0044, 144.0613, -5.5485), "tail": (-71.3332, 144.0613, -5.5485),
                                   "parent": "mixamorig:RightArm"},
        "mixamorig:RightHand": {"head": (-71.3332, 144.0613, -5.5485), "tail": (-79.56, 144.0613, -5.5485),
                                "parent": "mixamorig:RightForeArm"},
        "mixamorig:RightHandThumb1": {"head": (-73.798, 142.4873, -2.8666), "tail": (-77.0132, 140.6145, -0.9424),
                                      "parent": "mixamorig:RightHand"},
        "mixamorig:RightHandThumb2": {"head": (-77.0132, 140.6145, -0.9424), "tail": (-79.668, 139.0865, 0.5703),
                                      "parent": "mixamorig:RightHandThumb1"},
        "mixamorig:RightHandThumb3": {"head": (-79.668, 139.0865, 0.5703), "tail": (-81.6868, 137.9345, 1.6783),
                                      "parent": "mixamorig:RightHandThumb2"},
        "mixamorig:RightHandThumb4": {"head": (-81.6868, 137.9345, 1.6783), "tail": (-83.5749, 136.7892, 3.0026),
                                      "parent": "mixamorig:RightHandThumb3"},
        "mixamorig:RightHandIndex1": {"head": (-80.4415, 143.5434, -3.2887), "tail": (-84.1415, 143.5434, -3.2874),
                                      "parent": "mixamorig:RightHand"},
        "mixamorig:RightHandIndex2": {"head": (-84.1415, 143.5434, -3.2874), "tail": (-86.9915, 143.5435, -3.288),
                                      "parent": "mixamorig:RightHandIndex1"},
        "mixamorig:RightHandIndex3": {"head": (-86.9915, 143.5435, -3.288), "tail": (-89.7637, 143.5434, -3.288),
                                      "parent": "mixamorig:RightHandIndex2"},
        "mixamorig:RightHandIndex4": {"head": (-89.7637, 143.5434, -3.288), "tail": (-92.5359, 143.5434, -3.2885),
                                      "parent": "mixamorig:RightHandIndex3"},
        "mixamorig:RightHandMiddle1": {"head": (-80.8657, 144.0612, -5.5485), "tail": (-84.5657, 144.0612, -5.5448),
                                       "parent": "mixamorig:RightHand"},
        "mixamorig:RightHandMiddle2": {"head": (-84.5657, 144.0612, -5.5448), "tail": (-87.5157, 144.0613, -5.5469),
                                       "parent": "mixamorig:RightHandMiddle1"},
        "mixamorig:RightHandMiddle3": {"head": (-87.5157, 144.0613, -5.5469), "tail": (-90.4623, 144.0613, -5.547),
                                       "parent": "mixamorig:RightHandMiddle2"},
        "mixamorig:RightHandMiddle4": {"head": (-90.4623, 144.0613, -5.547), "tail": (-93.409, 144.0613, -5.5481),
                                       "parent": "mixamorig:RightHandMiddle3"},
        "mixamorig:RightHandRing1": {"head": (-80.4368, 144.0182, -7.4136), "tail": (-83.8161, 144.0182, -7.4147),
                                     "parent": "mixamorig:RightHand"},
        "mixamorig:RightHandRing2": {"head": (-83.8161, 144.0182, -7.4147), "tail": (-86.7058, 144.0182, -7.4143),
                                     "parent": "mixamorig:RightHandRing1"},
        "mixamorig:RightHandRing3": {"head": (-86.7058, 144.0182, -7.4143), "tail": (-89.3446, 144.0182, -7.4134),
                                     "parent": "mixamorig:RightHandRing2"},
        "mixamorig:RightHandRing4": {"head": (-89.3446, 144.0182, -7.4134), "tail": (-91.9834, 144.0182, -7.4082),
                                     "parent": "mixamorig:RightHandRing3"},
        "mixamorig:RightHandPinky1": {"head": (-79.4099, 143.5746, -9.3548), "tail": (-83.0099, 143.5746, -9.3585),
                                      "parent": "mixamorig:RightHand"},
        "mixamorig:RightHandPinky2": {"head": (-83.0099, 143.5746, -9.3585), "tail": (-85.1098, 143.5745, -9.3643),
                                      "parent": "mixamorig:RightHandPinky1"},
        "mixamorig:RightHandPinky3": {"head": (-85.1098, 143.5745, -9.3643), "tail": (-87.2256, 143.5745, -9.3679),
                                      "parent": "mixamorig:RightHandPinky2"},
        "mixamorig:RightHandPinky4": {"head": (-87.2256, 143.5745, -9.3679), "tail": (-89.3414, 143.5745, -9.3714),
                                      "parent": "mixamorig:RightHandPinky3"},
        "mixamorig:LeftShoulder": {"head": (4.5704, 144.5859, -3.3164), "tail": (15.1628, 144.0613, -5.5485),
                                   "parent": "mixamorig:Spine2"},
        "mixamorig:LeftArm": {"head": (15.1628, 144.0613, -5.5485), "tail": (43.0043, 144.0613, -5.5485),
                              "parent": "mixamorig:LeftShoulder"},
        "mixamorig:LeftForeArm": {"head": (43.0043, 144.0613, -5.5485), "tail": (71.3332, 144.0612, -5.5484),
                                  "parent": "mixamorig:LeftArm"},
        "mixamorig:LeftHand": {"head": (71.3332, 144.0612, -5.5485), "tail": (79.561, 144.0612, -5.5484),
                               "parent": "mixamorig:LeftForeArm"},
        "mixamorig:LeftHandThumb1": {"head": (73.7993, 142.4851, -2.8667), "tail": (77.0171, 140.613, -0.9502),
                                     "parent": "mixamorig:LeftHand"},
        "mixamorig:LeftHandThumb2": {"head": (77.0171, 140.613, -0.9502), "tail": (79.6731, 139.0842, 0.5643),
                                     "parent": "mixamorig:LeftHandThumb1"},
        "mixamorig:LeftHandThumb3": {"head": (79.6731, 139.0842, 0.5643), "tail": (81.694, 137.9301, 1.6794),
                                     "parent": "mixamorig:LeftHandThumb2"},
        "mixamorig:LeftHandThumb4": {"head": (81.694, 137.9301, 1.6794), "tail": (83.6029, 136.7793, 2.9799),
                                     "parent": "mixamorig:LeftHandThumb3"},
        "mixamorig:LeftHandIndex1": {"head": (80.4425, 143.5432, -3.2886), "tail": (84.1425, 143.5432, -3.2889),
                                     "parent": "mixamorig:LeftHand"},
        "mixamorig:LeftHandIndex2": {"head": (84.1425, 143.5432, -3.2889), "tail": (86.9925, 143.5432, -3.2886),
                                     "parent": "mixamorig:LeftHandIndex1"},
        "mixamorig:LeftHandIndex3": {"head": (86.9925, 143.5432, -3.2886), "tail": (89.7673, 143.5432, -3.2886),
                                     "parent": "mixamorig:LeftHandIndex2"},
        "mixamorig:LeftHandIndex4": {"head": (89.7673, 143.5432, -3.2886), "tail": (92.5422, 143.5432, -3.2887),
                                     "parent": "mixamorig:LeftHandIndex3"},
        "mixamorig:LeftHandMiddle1": {"head": (80.8666, 144.0613, -5.5484), "tail": (84.5666, 144.0613, -5.5486),
                                      "parent": "mixamorig:LeftHand"},
        "mixamorig:LeftHandMiddle2": {"head": (84.5666, 144.0613, -5.5486), "tail": (87.5166, 144.0613, -5.5487),
                                      "parent": "mixamorig:LeftHandMiddle1"},
        "mixamorig:LeftHandMiddle3": {"head": (87.5166, 144.0613, -5.5487), "tail": (90.4694, 144.0613, -5.5486),
                                      "parent": "mixamorig:LeftHandMiddle2"},
        "mixamorig:LeftHandMiddle4": {"head": (90.4694, 144.0613, -5.5486), "tail": (93.4223, 144.0613, -5.5484),
                                      "parent": "mixamorig:LeftHandMiddle3"},
        "mixamorig:LeftHandRing1": {"head": (80.4377, 144.0182, -7.4135), "tail": (83.5877, 144.0182, -7.4135),
                                    "parent": "mixamorig:LeftHand"},
        "mixamorig:LeftHandRing2": {"head": (83.5877, 144.0182, -7.4135), "tail": (86.5377, 144.0182, -7.4134),
                                    "parent": "mixamorig:LeftHandRing1"},
        "mixamorig:LeftHandRing3": {"head": (86.5377, 144.0182, -7.4134), "tail": (89.182, 144.0182, -7.4134),
                                    "parent": "mixamorig:LeftHandRing2"},
        "mixamorig:LeftHandRing4": {"head": (89.182, 144.0182, -7.4134), "tail": (91.8263, 144.0182, -7.4133),
                                    "parent": "mixamorig:LeftHandRing3"},
        "mixamorig:LeftHandPinky1": {"head": (79.4109, 143.5744, -9.3547), "tail": (83.0109, 143.5744, -9.34),
                                     "parent": "mixamorig:LeftHand"},
        "mixamorig:LeftHandPinky2": {"head": (83.0109, 143.5744, -9.34), "tail": (85.1109, 143.5744, -9.3323),
                                     "parent": "mixamorig:LeftHandPinky1"},
        "mixamorig:LeftHandPinky3": {"head": (85.1109, 143.5744, -9.3323), "tail": (87.2364, 143.5744, -9.3248),
                                     "parent": "mixamorig:LeftHandPinky2"},
        "mixamorig:LeftHandPinky4": {"head": (87.2364, 143.5744, -9.3248), "tail": (89.3619, 143.5744, -9.3185),
                                     "parent": "mixamorig:LeftHandPinky3"},
        "mixamorig:RightUpLeg": {"head": (-8.2078, 97.5232, -0.0452), "tail": (-8.2078, 53.1531, 0.3007),
                                 "parent": "mixamorig:Hips"},
        "mixamorig:RightLeg": {"head": (-8.2078, 53.1531, 0.3007), "tail": (-8.2078, 8.7294, -2.7428),
                               "parent": "mixamorig:RightUpLeg"},
        "mixamorig:RightFoot": {"head": (-8.2078, 8.7294, -2.7428), "tail": (-8.2078, 0.0007, 7.9677),
                                "parent": "mixamorig:RightLeg"},
        "mixamorig:RightToeBase": {"head": (-8.2078, 0.0007, 7.9677), "tail": (-8.2078, 0.0001, 17.2458),
                                   "parent": "mixamorig:RightFoot"},
        "mixamorig:RightToe_End": {"head": (-8.2078, 0.0001, 17.2458), "tail": (-8.2078, -0.0006, 26.524),
                                   "parent": "mixamorig:RightToeBase"},
        "mixamorig:LeftUpLeg": {"head": (8.2078, 97.5232, -0.0452), "tail": (8.2078, 53.1531, 0.3017),
                                "parent": "mixamorig:Hips"},
        "mixamorig:LeftLeg": {"head": (8.2078, 53.1531, 0.3017), "tail": (8.2078, 8.7295, -2.7427),
                              "parent": "mixamorig:LeftUpLeg"},
        "mixamorig:LeftFoot": {"head": (8.2078, 8.7295, -2.7427), "tail": (8.2078, 0.0008, 7.9679),
                               "parent": "mixamorig:LeftLeg"},
        "mixamorig:LeftToeBase": {"head": (8.2078, 0.0008, 7.9679), "tail": (8.2078, 0.0001, 17.246),
                                  "parent": "mixamorig:LeftFoot"},
        "mixamorig:LeftToe_End": {"head": (8.2078, 0.0001, 17.246), "tail": (8.2078, -0.0005, 26.5242),
                                  "parent": "mixamorig:LeftToeBase"},
    }

    # Create a new armature
    bpy.ops.object.armature_add(enter_editmode=True)
    armature = bpy.context.active_object
    armature.name = "Mixamo_Generated_Rig"
    armature_data = armature.data
    armature_data.name = "ArmatureData"

    # Create the bones
    for name, data in bone_data.items():
        bone = armature_data.edit_bones.new(name)
        bone.head = data['head']
        bone.tail = data['tail']

        # Set the parent
        parent_name = data.get('parent')
        if parent_name and parent_name != "None":
            if parent_name in armature_data.edit_bones:
                bone.parent = armature_data.edit_bones[parent_name]
            else:
                print(f"Warning: Parent bone '{parent_name}' not found for '{name}'.")

    # Exit edit mode
    bpy.ops.object.mode_set(mode='OBJECT')

    # Select the rig and set it to active
    bpy.context.view_layer.objects.active = armature
    armature.select_set(True)

    print("Armature generated successfully from provided data!")


# Run the function
if __name__ == "__main__":
    create_armature_from_data()