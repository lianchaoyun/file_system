import bpy
import os
import re


def parse_data_from_file_and_rebuild_mesh():
    """
    Parses a mesh data file (verts, faces) and rebuilds the object in Blender.
    """
    # 1. 获取桌面路径和文件路径
    desktop_path = os.path.join(os.path.expanduser('~'), 'Desktop')
    input_file_path = os.path.join(desktop_path, 'a.txt')

    if not os.path.exists(input_file_path):
        print(f"错误: 文件 '{input_file_path}' 不存在。请确认文件已保存到桌面。")
        return

    # 2. 读取并解析文件内容
    verts_list = []
    faces_list = []

    try:
        with open(input_file_path, 'r', encoding='utf-8') as f:
            data_string = f.read()
    except Exception as e:
        print(f"读取文件时出错: {e}")
        return

    print("成功读取文件。开始解析数据...")

    # 使用正则表达式解析 verts 数组
    verts_match = re.search(r"verts = \[([\s\S]*?)\]", data_string)
    if verts_match:
        verts_content = verts_match.group(1)
        verts_pattern = re.compile(
            r'\(([-+]?\d+\.\d+e?[-+]?\d*), ([-+]?\d+\.\d+e?[-+]?\d*), ([-+]?\d+\.\d+e?[-+]?\d*)\)')
        verts_matches = verts_pattern.findall(verts_content)
        for x_str, y_str, z_str in verts_matches:
            verts_list.append((float(x_str), float(y_str), float(z_str)))

    # 使用正则表达式解析 faces 数组
    faces_match = re.search(r"faces = \[([\s\S]*?)\]", data_string)
    if faces_match:
        faces_content = faces_match.group(1)
        faces_pattern = re.compile(r'\(([\d, ]+)\)')
        faces_matches = faces_pattern.findall(faces_content)
        for face_str in faces_matches:
            indices = tuple(map(int, face_str.split(',')))
            faces_list.append(indices)

    if not verts_list or not faces_list:
        print("错误: 文件中没有找到顶点或面数据。请检查文件格式。")
        return

    print(f"解析完成。找到 {len(verts_list)} 个顶点和 {len(faces_list)} 个面。")

    # 3. 创建新的网格和物体
    mesh_name = "Reconstructed_Object"
    # 如果同名网格已存在，先移除
    if mesh_name in bpy.data.meshes:
        bpy.data.meshes.remove(bpy.data.meshes[mesh_name])

    new_mesh = bpy.data.meshes.new(mesh_name)
    new_object = bpy.data.objects.new(mesh_name, new_mesh)

    # 4. 填充网格数据
    new_mesh.from_pydata(verts_list, [], faces_list)
    new_mesh.update()
    new_mesh.validate()

    # 5. 将新物体添加到场景中
    scene = bpy.context.collection
    scene.objects.link(new_object)

    # 6. 设置新物体为活动对象并选中
    bpy.context.view_layer.objects.active = new_object
    new_object.select_set(True)

    print(f"物体 '{new_object.name}' 已成功在场景中重建。")


# 执行函数
parse_data_from_file_and_rebuild_mesh()