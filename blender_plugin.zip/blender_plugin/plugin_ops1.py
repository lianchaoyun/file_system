bl_info = {
    "name": "Scene Rotator",
    "author": "Your Name",
    "version": (1, 0),
    "blender": (4, 1, 0),
    "location": "3D Viewport > Sidebar > Scene Rotator Tab",
    "description": "Rotates all selected objects in the scene by a set amount.",
    "warning": "",
    "doc_url": "",
    "category": "Object",
}

import bpy
import math

# --- 运算符 (Operator) ---
# This is the class that performs the actual rotation operation
class RotateSceneOperator(bpy.types.Operator):
    """Rotates the entire scene (all objects) by a fixed angle around the Z-axis."""
    bl_idname = "object.rotate_scene_30_degrees"
    bl_label = "Rotate Scene 30 Degrees"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        # Iterate over all objects in the scene
        for obj in context.scene.objects:
            # Ensure the object is visible and selectable
            if obj.type in {'MESH', 'CURVE', 'SURFACE', 'META', 'FONT', 'HAIR', 'POINTCLOUD', 'VOLUME'} and not obj.hide_get():
                # Rotate around its local Z-axis by 30 degrees
                obj.rotation_euler.z += math.radians(30)

        self.report({'INFO'}, "Scene rotated by 30 degrees!")
        return {'FINISHED'}

# --- 面板 (Panel) ---
# This is the class that displays the button in the UI
class RotateScenePanel(bpy.types.Panel):
    bl_label = "Scene Rotator"
    bl_idname = "PT_RotateScenePanel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Scene Tools"

    def draw(self, context):
        layout = self.layout
        row = layout.row()
        # Create a button that calls the RotateSceneOperator
        row.operator(RotateSceneOperator.bl_idname)

# --- Register and Unregister ---
# Blender calls these functions to load and unload the addon
classes = (
    RotateSceneOperator,
    RotateScenePanel
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    print("Scene Rotator Plugin Registered!")

def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    print("Scene Rotator Plugin Unregistered!")

if __name__ == "__main__":
    # First, attempt to unregister all classes from a previous run.
    # We use a try-except block to gracefully handle cases where classes
    # have not been registered yet (e.g., first run).
    try:
        unregister()
        print("Previous classes unregistered.")
    except RuntimeError:
        print("No classes were registered, performing initial registration.")

    # Then, register all classes for the current run.
    register()