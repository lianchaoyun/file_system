import bpy

scene = bpy.context.scene

objects = bpy.data.objects

cube = bpy.data.objects["Cube"]

print(cube.name)


# 创建立方体
#bpy.ops.mesh.primitive_cube_add(size=2, location=(0, 0, 0))

# 创建光源
#bpy.ops.object.light_add(type='SUN', location=(0, 0, 5))




bpy.ops.object.simple_operator()
