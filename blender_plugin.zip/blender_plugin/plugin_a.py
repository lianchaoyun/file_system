
bl_info = {
    "name": "爱插件",
    "author": "yun",
    "version": (1, 0),
    "blender": (4, 5, 0),
    "location": "3D Viewport > Sidebar > Scene Rotator Tab",
    "description": "爱插件.",
    "warning": "",
    "doc_url": "",
    "category": "Object",
}

import bpy
import math
from mathutils import Quaternion


# --- 运算符 (Operator) ---
class RotateSceneOperator(bpy.types.Operator):
    bl_idname = "object.rotate_scene_30_degrees"
    bl_label = "旋转"
    bl_options = {'REGISTER', 'UNDO'}


    def test(self):
        for area in bpy.context.screen.areas:
            if area.type == 'VIEW_3D':
                print(area)
                 # 获取3D视图的region_3d数据
                rv3d = area.spaces[0].region_3d

                # 视图旋转（使用四元数）
                rv3d.view_rotation = Quaternion((0.707, 0, 0, 0.707))  # 45度绕Z轴

                # 视图平移
                rv3d.view_location = (1.0, 2.0, 3.0)

                # 视图缩放
                rv3d.view_distance = 10.0  # 相机距离



    def execute(self, context):
        #bpy.ops.view3d.view_orbit(type='ORBITUP', orbit_amount=math.radians(30))
        self.test()
        for obj in context.scene.objects:
            if obj.type in {'MESH', 'CURVE', 'SURFACE', 'META', 'FONT', 'HAIR', 'POINTCLOUD','VOLUME'} and not obj.hide_get():
                obj.rotation_euler.z += math.radians(30)
        self.report({'INFO'}, "Scene rotated by 30 degrees!")
        return {'FINISHED'}





# --- 面板 (Panel) ---
class AiPanel(bpy.types.Panel):
    bl_label = "爱插件"
    bl_idname = "PT_AiPanel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "开发插件"

    def draw(self, context):
        layout = self.layout

        # 旋转按钮
        row = layout.row()
        row.operator(RotateSceneOperator.bl_idname)

        # 添加一个分隔线
        layout.separator()

        # 垂直布局(默认)
        col = layout.column()
        col.label(text="垂直排列1")
        col.label(text="垂直排列2")

        # 水平布局
        row = layout.row()
        row.label(text="水平排列1")
        row.label(text="水平排列2")

        # 网格布局
        grid = layout.grid_flow(columns=2, even_columns=True)
        grid.label(text="网格1")
        grid.label(text="网格2")

        # 卸载按钮
        #row = layout.row()
        #row.operator(UninstallAddonOperator.bl_idname)


# --- 注册与注销 ---
classes = (
    RotateSceneOperator,
    AiPanel
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    print("爱插件注册!")


def unregister():
    for cls in reversed(classes):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass
    print("爱插件卸载!")


# 脚本主入口，用于测试和热重载
if __name__ == "__main__":
    try:
        unregister()
    except Exception:
        pass
    register()