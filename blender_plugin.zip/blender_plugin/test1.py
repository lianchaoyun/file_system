import bpy
from math import radians
from mathutils import Quaternion

# 旋转控制参数
ROTATION_SPEED = 1  # 度/帧
stop_rotation = False  # 停止标志


def rotate_view():
    global stop_rotation
    if stop_rotation:
        return

    # 获取3D视图
    for area in bpy.context.screen.areas:
        if area.type == 'VIEW_3D':
            rv3d = area.spaces[0].region_3d
            # 绕Z轴匀速旋转（转换为四元数）
            rot_quat = Quaternion((0, 0, 1), radians(ROTATION_SPEED))
            rv3d.view_rotation = rv3d.view_rotation @ rot_quat
            break

    # 每帧调用自身（实现动画）
    bpy.app.timers.register(rotate_view, first_interval=1 / 60)


# 启动旋转
rotate_view()


# 停止旋转的函数（可在Python控制台调用）
def stop_auto_rotate():
    global stop_rotation
    stop_rotation = True