/*
 Navicat Premium Dump SQL

 Source Server         : mysql-local
 Source Server Type    : MySQL
 Source Server Version : 90701 (9.7.1)
 Source Host           : localhost:3306
 Source Schema         : yun

 Target Server Type    : MySQL
 Target Server Version : 90701 (9.7.1)
 File Encoding         : 65001

 Date: 07/08/2026 15:32:48
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for claw_llm_models
-- ----------------------------
DROP TABLE IF EXISTS `claw_llm_models`;
CREATE TABLE `claw_llm_models`  (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `model_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `base_url` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `model` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `api_key` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '',
  `max_tokens` int NULL DEFAULT 4096,
  `temperature` float NULL DEFAULT 0.7,
  `timeout` int NULL DEFAULT 120,
  `is_active` tinyint NULL DEFAULT 0,
  `supports_tools` int NULL DEFAULT 1,
  `created_at` datetime NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `model_id`(`model_id` ASC) USING BTREE,
  INDEX `idx_model_id`(`model_id` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 24 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of claw_llm_models
-- ----------------------------
INSERT INTO `claw_llm_models` VALUES (20, 'gpt-oss_20b', 'gpt-oss:20b', 'http://localhost:11434/v1', 'gpt-oss:20b', 'ollama', 4096, 0.7, 120, 0, 1, '2026-07-30 17:14:45', '2026-08-01 10:52:33');
INSERT INTO `claw_llm_models` VALUES (21, 'lfm2_24b', 'lfm2:24b', 'http://localhost:11434/v1', 'lfm2:24b', 'ollama', 4096, 0.7, 120, 0, 1, '2026-07-30 17:14:45', '2026-07-30 17:39:12');
INSERT INTO `claw_llm_models` VALUES (22, 'qwen3.5_9b', 'qwen3.5:9b', 'http://localhost:11434/v1', 'qwen3.5:9b', 'ollama', 4096, 0.7, 120, 1, 1, '2026-07-30 17:14:45', '2026-08-01 10:52:33');
INSERT INTO `claw_llm_models` VALUES (23, 'satgeze_qwenpaw-9b-heretic-1m_latest', 'satgeze/qwenpaw-9b-heretic-1m:latest', 'http://localhost:11434/v1', 'satgeze/qwenpaw-9b-heretic-1m:latest', 'ollama', 4096, 0.7, 120, 0, 1, '2026-07-30 17:14:45', '2026-07-30 17:34:53');

-- ----------------------------
-- Table structure for claw_messages
-- ----------------------------
DROP TABLE IF EXISTS `claw_messages`;
CREATE TABLE `claw_messages`  (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `session_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `role` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `thinking` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL,
  `created_at` datetime NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `idx_session_id`(`session_id` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 265 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of claw_messages
-- ----------------------------
INSERT INTO `claw_messages` VALUES (262, 'session-2026-08-01T03-52-37-603Z', 'user', '你好', NULL, '2026-08-01 11:09:51');
INSERT INTO `claw_messages` VALUES (263, 'session-2026-08-01T03-52-37-603Z', 'user', '你好', NULL, '2026-08-01 11:14:49');
INSERT INTO `claw_messages` VALUES (264, 'session-2026-08-01T03-52-37-603Z', 'assistant', '你好！我是龙虾，一个有工具调用能力的AI助手。我可以帮你：\n\n- **执行 Bash 命令**（系统操作、文件处理等）\n- **查询天气信息**（指定城市）\n- **发送 HTTP 请求**（获取网页或 API 数据）\n- **管理定时任务**（添加/删除/查看 cron 任务）\n- **获取项目状态信息**（扩展数、技能列表、MCP 清单等）\n\n请问有什么可以帮你的？', NULL, '2026-08-01 11:14:59');

-- ----------------------------
-- Table structure for claw_sessions
-- ----------------------------
DROP TABLE IF EXISTS `claw_sessions`;
CREATE TABLE `claw_sessions`  (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `session_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `title` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '新对话',
  `model_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `created_at` datetime NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `session_id`(`session_id` ASC) USING BTREE,
  INDEX `idx_session_id`(`session_id` ASC) USING BTREE,
  INDEX `idx_model_id`(`model_id` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 18 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of claw_sessions
-- ----------------------------
INSERT INTO `claw_sessions` VALUES (17, 'session-2026-08-01T03-52-37-603Z', '你好', NULL, '2026-08-01 10:52:38', '2026-08-01 11:14:59');

-- ----------------------------
-- Table structure for claw_token_usage
-- ----------------------------
DROP TABLE IF EXISTS `claw_token_usage`;
CREATE TABLE `claw_token_usage`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `session_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `engine_name` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `prompt_tokens` int NOT NULL,
  `completion_tokens` int NOT NULL,
  `total_tokens` int NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `tokenusage_session_id`(`session_id` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 41 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of claw_token_usage
-- ----------------------------
INSERT INTO `claw_token_usage` VALUES (39, 'session-2026-07-20T09-56-48-102Z', 'react', 143, 79, 222, '2026-07-20 16:57:01');
INSERT INTO `claw_token_usage` VALUES (40, 'session-2026-07-30T10-14-54-633Z', 'crewai', 3, 159, 162, '2026-07-30 17:37:39');

SET FOREIGN_KEY_CHECKS = 1;
