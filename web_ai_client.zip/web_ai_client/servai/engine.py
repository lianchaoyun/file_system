﻿"""
AI 引擎 — 统一入口（Facade）
根据配置委托给具体引擎实现

外部调用方式不变:
    from src.servai.engine import chat_stream, chat_non_stream, reset_session
"""
import logging
import httpx
from typing import AsyncGenerator

from openai import AsyncOpenAI
from .memory import clear_history
from src.servai.config import get_ollama_config

logger = logging.getLogger("claw.ai_engine")

# ── OpenAI 客户端管理（共享，各引擎复用）──────────────────────

_client_cache: dict[str, AsyncOpenAI] = {}
_cached_config_hash: str = ""


def _get_client() -> AsyncOpenAI:
    """
    获取当前激活模型的 OpenAI 客户端。
    自动检测模型切换并重建客户端。
    """
    global _cached_config_hash
    llm_config = get_ollama_config()
    config_str = f"{llm_config['base_url']}|{llm_config['api_key']}|{llm_config['timeout']}"

    if config_str != _cached_config_hash:
        logger.info(f"🔄 模型配置已变更，重建客户端: {llm_config['base_url']}")
        _client_cache.clear()
        _cached_config_hash = config_str

    cache_key = llm_config.get("model_id", "default")
    if cache_key not in _client_cache:
        _client_cache[cache_key] = AsyncOpenAI(
            base_url=llm_config["base_url"],
            api_key=llm_config["api_key"],
            timeout=httpx.Timeout(llm_config["timeout"], connect=10.0),
        )
    return _client_cache[cache_key]


# ── 统一入口（委托给工厂选择的引擎）──────────────────────────

async def chat_stream(
    session_id: str,
    user_message: str,
    enable_tools: bool = True,
) -> AsyncGenerator[dict, None]:
    """流式对话 — 委托给当前激活的引擎"""
    from .factory import get_active_engine
    engine = get_active_engine()
    async for event in engine.chat_stream(session_id, user_message, enable_tools):
        yield event


async def chat_non_stream(
    session_id: str,
    user_message: str,
    enable_tools: bool = True,
) -> dict:
    """非流式对话 — 委托给当前激活的引擎"""
    from .factory import get_active_engine
    engine = get_active_engine()
    return await engine.chat_non_stream(session_id, user_message, enable_tools)


def reset_session(session_id: str):
    """重置会话"""
    clear_history(session_id)
