﻿# -*- coding: utf-8 -*-
"""
MCP 扩展包

每一个子目录是一个 MCP 实例:
  - market_data_duckdb   市场行情数据（DuckDB K线 + Qlib 选股）
  - client               MCP stdio 客户端

McpManager（claw/mcp_manager.py）会自动扫描此目录发现实例。
每个实例子包只需在 __init__.py 中导出 MCP_CONFIG 字典即可。
"""

from src.servai.mcps.market_data_duckdb import run

__all__ = ["run"]
