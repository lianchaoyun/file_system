# -*- coding: utf-8 -*-
"""
市场行情数据 MCP Server（DuckDB）
使用 FastMCP 高阶层 (mcp 1.x 推荐写法)
"""
import os
import sys
import json
import logging
from datetime import datetime
from typing import Literal

# ============================================================
# 路径初始化
# ============================================================
_PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "..", ".."))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

# ============================================================
# 日志
# ============================================================
_LOG_DIR = os.path.join(_PROJECT_ROOT, "data", "logs","claw", "mcp_market_data")
os.makedirs(_LOG_DIR, exist_ok=True)
_LOG_FILE = os.path.join(_LOG_DIR, f"log_{datetime.now().strftime('%Y%m%d')}.log")

_file_handler = logging.FileHandler(_LOG_FILE, encoding="utf-8")
_file_handler.setLevel(logging.DEBUG)
_file_handler.setFormatter(logging.Formatter("%(asctime)s %(message)s", datefmt="%H:%M:%S"))
_file_logger = logging.getLogger("mcp_market_data")
_file_logger.addHandler(_file_handler)
_file_logger.setLevel(logging.DEBUG)
_file_logger.propagate = False


def _log(msg: str):
    print(f"[{datetime.now().strftime('%H:%M:%S')}] {msg}", file=sys.stderr, flush=True)
    _file_logger.info(msg)


from src.common.duck_utils import KlineDB

_DB_PATH = os.path.join(_PROJECT_ROOT, "data", "db", "duck", "kline.duckdb")


def _normalize_symbol(symbol: str) -> str:
    """自动补齐交易所后缀：6开头→.SH, 0/3开头→.SZ，已有后缀直接返回"""
    if "." in symbol:
        return symbol
    if symbol.startswith("6"):
        return symbol + ".SH"
    return symbol + ".SZ"


def _normalize_period(p: str) -> str:
    """容错：把 LLM 可能传的别名（d/D/day/daily）统一转到 '1d'"""
    p_lower = p.lower()
    if p_lower in ("d", "day", "daily", "日线", "日"):
        return "1d"
    if p_lower in ("h", "hour", "hourly", "60m", "60min", "小时"):
        return "1h"
    if p_lower in ("m", "min", "minute", "分钟", "分"):
        return "1m"
    if p_lower in ("15min", "15分钟", "15分"):
        return "15m"
    # 已经是合法值的直接返回
    if p in ("1m", "15m", "1h", "1d"):
        return p
    return p  # 不认识的保留原值，让 pydantic 报错


# ============================================================
# FastMCP 高阶层
# ============================================================
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("market-data-duckdb")


@mcp.tool()
def list_symbols() -> str:
    """列出 DuckDB K线数据库中所有可用的股票代码"""
    import duckdb
    con = duckdb.connect(_DB_PATH)
    try:
        df = con.execute("SELECT DISTINCT symbol FROM kline ORDER BY symbol").df()
        symbols = df["symbol"].tolist() if not df.empty else []
        return json.dumps({
            "count": len(symbols),
            "symbols": symbols[:200],
            "truncated": len(symbols) > 200,
        }, ensure_ascii=False, indent=2)
    finally:
        con.close()


@mcp.tool()
def query_kline(symbol: str, period: Literal["1m", "15m", "1h", "1d"] = "1d",
                 start_time: str = None, end_time: str = None,
                 limit: int = 100) -> str:
    """查询指定股票的K线数据。period 只能选: 1m(1分钟) | 15m(15分钟) | 1h(1小时) | 1d(日线)"""
    symbol = _normalize_symbol(symbol)
    period = _normalize_period(period)
    with KlineDB(_DB_PATH) as db:
        rows = db.query_kline(
            symbol=symbol, period=period,
            start_time=start_time, end_time=end_time,
            limit=min(limit, 500),
        )
    if not rows:
        return json.dumps({"symbol": symbol, "count": 0, "message": "无数据"}, ensure_ascii=False)
    for r in rows:
        if "time" in r and r["time"] is not None:
            r["time"] = str(r["time"])
    return json.dumps({
        "symbol": symbol, "period": period, "total_returned": len(rows),
        "preview": rows[:5],
        "summary": {"latest": rows[0]["time"], "close_latest": rows[0].get("close")} if rows else None,
    }, ensure_ascii=False, indent=2)


@mcp.tool()
def get_kline_stats(symbol: str, period: Literal["1m", "15m", "1h", "1d"] = "1d") -> str:
    """获取指定股票某周期的统计信息。period 只能选: 1m | 15m | 1h | 1d"""
    symbol = _normalize_symbol(symbol)
    period = _normalize_period(period)
    import duckdb
    con = duckdb.connect(_DB_PATH)
    try:
        row = con.execute("""
            SELECT COUNT(*) AS total, MIN(time), MAX(time), MIN(low), MAX(high), AVG(close)
            FROM kline WHERE symbol = ? AND period = ?
        """, [symbol, period]).fetchone()
        if not row or row[0] == 0:
            return json.dumps({"symbol": symbol, "total": 0, "message": "无数据"}, ensure_ascii=False)
        return json.dumps({
            "symbol": symbol, "period": period, "total": int(row[0]),
            "first_date": str(row[1]), "last_date": str(row[2]),
            "min_price": round(float(row[3]), 2), "max_price": round(float(row[4]), 2),
            "avg_close": round(float(row[5]), 2),
        }, ensure_ascii=False, indent=2)
    finally:
        con.close()


@mcp.tool()
def get_latest_kline(symbol: str, period: Literal["1m", "15m", "1h", "1d"] = "1d") -> str:
    """获取指定股票最新一条K线数据。period 只能选: 1m | 15m | 1h | 1d(日线，默认)"""
    symbol = _normalize_symbol(symbol)
    period = _normalize_period(period)
    with KlineDB(_DB_PATH) as db:
        row = db.get_latest_kline(symbol, period)
    if not row:
        return json.dumps({"symbol": symbol, "found": False})
    if "time" in row and row["time"] is not None:
        row["time"] = str(row["time"])
    return json.dumps(row, ensure_ascii=False, indent=2, default=str)


@mcp.tool()
def get_symbol_periods(symbol: str) -> str:
    """查询某只股票有哪些可用周期的K线数据"""
    symbol = _normalize_symbol(symbol)
    import duckdb
    con = duckdb.connect(_DB_PATH)
    try:
        df = con.execute("SELECT DISTINCT period FROM kline WHERE symbol = ? ORDER BY period", [symbol]).df()
        periods = df["period"].tolist() if not df.empty else []
        return json.dumps({"symbol": symbol, "periods": periods}, ensure_ascii=False)
    finally:
        con.close()


@mcp.tool()
def run_stock_selection(mode: str, target_date: str = None) -> str:
    """运行 Qlib + LightGBM 选股工作流。mode: predict 或 backtest"""
    from src.ts.tdx.tdx_workflow import run_backtest, run_predict
    if mode == "backtest":
        run_backtest()
        return json.dumps({"mode": "backtest", "status": "completed"}, ensure_ascii=False)
    else:
        run_predict(target_date=target_date)
        return json.dumps({"mode": "predict", "status": "completed"}, ensure_ascii=False)


def run():
    _log("🚀 Market Data MCP Server 启动 (DuckDB)")
    _log(f"   DuckDB 路径: {_DB_PATH}")
    mcp.run(transport="stdio")


if __name__ == "__main__":
    run()
