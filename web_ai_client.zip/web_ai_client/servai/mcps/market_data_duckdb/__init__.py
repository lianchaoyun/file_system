# -*- coding: utf-8 -*-
"""
市场行情数据 MCP Server（基于 DuckDB）

提供:
  - list_symbols        列出数据库中所有股票代码
  - query_kline         查询K线数据
  - get_kline_stats     获取K线统计信息
  - get_latest_kline    获取最新K线
  - get_symbol_periods  获取可用周期列表
  - run_stock_selection 运行 Qlib 选股工作流
"""

from .server import run

# MCP 实例元信息（供 McpManager 自动发现）
MCP_CONFIG = {
    "id": "market_data_duckdb",
    "name": "市场行情数据",
    "description": "DuckDB K线数据查询 + Qlib/LightGBM 选股工作流",
}

__all__ = ["run", "MCP_CONFIG"]
