﻿"""
ReAct 引擎 — 多轮工具循环
最轻量、最可控的实现，适合日常对话和工具调用

支持最多 MAX_TOOL_ROUNDS 轮工具调用，LLM 可根据中间结果决定是否继续调用
"""
import json
import logging
from typing import AsyncGenerator

from .base import BaseEngine
from .memory import get_chat_messages, add_message
from src.servai.config import get_ollama_config

logger = logging.getLogger("claw.engine.react")

MAX_TOOL_ROUNDS = 5

SYSTEM_PROMPT = """你是龙虾，一个有工具调用能力的AI助手。

你有两类工具：
1. 内置技能（skills）：run_bash, get_weather, http_request, manage_schedule
2. 外部工具（mcp）：list_symbols, query_kline, get_kline_stats, get_latest_kline, get_symbol_periods, run_stock_selection

核心规则：
- 用户问数据 → 必须调 tool 获取，绝对禁止编造
- 用户问股票 → 直接调股票工具，不要解释如何使用工具
- 用最简单的参数，有默认值的不传

回复风格：简洁、专业、中文。"""


def _clean_response(content: str) -> str:
    """清理模型输出的特殊标签"""
    for tag in ('<response>', '</response>'):
        content = content.replace(tag, '')
    return content.strip()


class ReactEngine(BaseEngine):
    """ReAct 多轮工具循环引擎"""

    async def chat_stream(
        self,
        session_id: str,
        user_message: str,
        enable_tools: bool = True,
    ) -> AsyncGenerator[dict, None]:
        from src.servai.skills.manager import get_tool_definitions as get_skill_tools, execute_tool_call
        from .mcp import McpManager
        from .engine import _get_client
        from .memory import add_token_usage

        _mcp = McpManager.get_instance()

        # 保存用户消息
        add_message(session_id, "user", user_message)

        # 获取 LLM 配置和客户端
        llm_config = get_ollama_config()
        client = _get_client()

        # 构建消息列表
        messages = get_chat_messages(session_id, SYSTEM_PROMPT)

        # 构建请求参数
        kwargs = {
            "model": llm_config["model"],
            "messages": messages,
            "max_tokens": llm_config["max_tokens"],
            "temperature": llm_config["temperature"],
            "stream": True,
            "stream_options": {"include_usage": True},  # 启用 usage 统计
        }

        # 如果启用工具且模型支持，添加工具定义
        if enable_tools and llm_config.get("supports_tools", True):
            skill_tools = list(get_skill_tools())
            mcp_tools = list(_mcp.get_tool_definitions()) if _mcp else []
            all_tools = skill_tools + mcp_tools
            if all_tools:
                kwargs["tools"] = all_tools
                kwargs["tool_choice"] = "auto"
                logger.info(f"🔧 [react] 工具已加载: skill={len(skill_tools)}个, mcp={len(mcp_tools)}个")

        try:
            # ── 多轮工具循环 ─
            total_prompt_tokens = 0
            total_completion_tokens = 0
            
            for round_idx in range(MAX_TOOL_ROUNDS):
                # 调用 LLM（流式），自动处理 tools 不兼容的模型
                try:
                    stream = await client.chat.completions.create(**kwargs)
                except Exception as e:
                    err_msg = str(e)
                    if "tools" in kwargs and "tools" in err_msg.lower() and "support" in err_msg.lower():
                        logger.warning(f"模型 {llm_config['model']} 不支持 tools，降级为纯文本")
                        kwargs.pop("tools", None)
                        kwargs.pop("tool_choice", None)
                        stream = await client.chat.completions.create(**kwargs)
                    else:
                        raise

                full_content_raw = ""
                tool_calls_acc: dict[int, dict] = {}

                async for chunk in stream:
                    # 捕获 usage 信息（最后一个 chunk）
                    if hasattr(chunk, 'usage') and chunk.usage:
                        total_prompt_tokens += chunk.usage.prompt_tokens or 0
                        total_completion_tokens += chunk.usage.completion_tokens or 0
                        logger.debug(f"[react] 捕获到 usage: prompt={chunk.usage.prompt_tokens}, completion={chunk.usage.completion_tokens}")
                    
                    delta = chunk.choices[0].delta if chunk.choices else None
                    if delta is None:
                        continue

                    # 文本内容
                    if delta.content:
                        full_content_raw += delta.content
                        yield {"type": "delta", "content": delta.content}

                    # 工具调用
                    if delta.tool_calls:
                        for tc in delta.tool_calls:
                            idx = tc.index
                            if idx not in tool_calls_acc:
                                tool_calls_acc[idx] = {
                                    "id": tc.id or "",
                                    "function": {"name": "", "arguments": ""}
                                }
                            if tc.id:
                                tool_calls_acc[idx]["id"] = tc.id
                            if tc.function:
                                if tc.function.name:
                                    tool_calls_acc[idx]["function"]["name"] = tc.function.name
                                if tc.function.arguments:
                                    tool_calls_acc[idx]["function"]["arguments"] += tc.function.arguments

                # 没有工具调用 → 最终回复，退出循环
                if not tool_calls_acc:
                    clean_final = _clean_response(full_content_raw)
                    if clean_final:
                        add_message(session_id, "assistant", clean_final)
                    break

                # ── 有工具调用 → 执行工具 ──
                tool_calls = [tool_calls_acc[i] for i in sorted(tool_calls_acc.keys())]

                # 发送工具调用事件
                for tc in tool_calls:
                    func_name = tc["function"]["name"]
                    source = "mcp" if (_mcp and _mcp.has_tool(func_name)) else "skill"
                    yield {
                        "type": "tool_call",
                        "source": source,
                        "name": func_name,
                        "arguments": tc["function"]["arguments"]
                    }

                # 执行工具并收集结果
                tool_results = []
                for tc in tool_calls:
                    func_name = tc["function"]["name"]

                    if _mcp and _mcp.has_tool(func_name):
                        # MCP 工具
                        try:
                            args = json.loads(tc["function"]["arguments"])
                        except json.JSONDecodeError:
                            args = {}
                        content = await _mcp.execute_tool(func_name, args)
                        tool_results.append({
                            "role": "tool",
                            "tool_call_id": tc.get("id", ""),
                            "content": content,
                        })
                        yield {"type": "tool_result", "source": "mcp", "content": content}
                    else:
                        # Skills 工具
                        result = await execute_tool_call(tc)
                        tool_results.append(result)
                        yield {"type": "tool_result", "source": "skill", "content": result["content"]}

                # 将工具调用和结果添加到消息列表（供下一轮 LLM 使用）
                clean_tool_response = _clean_response(full_content_raw)
                messages.append({
                    "role": "assistant",
                    "content": clean_tool_response or None,
                    "tool_calls": [
                        {
                            "id": tc["id"],
                            "type": "function",
                            "function": {
                                "name": tc["function"]["name"],
                                "arguments": tc["function"]["arguments"]
                            }
                        }
                        for tc in tool_calls
                    ]
                })
                messages.extend(tool_results)

                # 最后一轮仍未结束 → 提示
                if round_idx == MAX_TOOL_ROUNDS - 1:
                    yield {"type": "delta", "content": "\n[已达最大工具调用轮次]"}

            # 记录 token 使用量
            if total_prompt_tokens > 0 or total_completion_tokens > 0:
                add_token_usage(
                    session_id=session_id,
                    engine_name="react",
                    prompt_tokens=total_prompt_tokens,
                    completion_tokens=total_completion_tokens,
                    total_tokens=total_prompt_tokens + total_completion_tokens,
                )
                logger.info(f" [react] Token: prompt={total_prompt_tokens}, completion={total_completion_tokens}")

            yield {"type": "done"}

        except Exception as e:
            logger.error(f"ReAct 引擎错误: {e}")
            yield {"type": "error", "content": str(e)}
