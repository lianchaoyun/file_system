﻿"""
AI 服务独立启动入口 — FastAPI 微服务
提供 /v1/chat、/v1/agents、/v1/mcps 等 HTTP 接口
用法: python -m src.servai.run
      或 uvicorn src.servai.run:app --host 0.0.0.0 --port 6961
"""
import sys
import os
import logging

from src.common.paths import PROJECT_ROOT_STR, SRC_DIR_STR

_SRC_DIR = SRC_DIR_STR
PROJECT_ROOT = PROJECT_ROOT_STR
if _SRC_DIR not in sys.path:
    sys.path.insert(0, _SRC_DIR)
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

import uvicorn
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager

from src.servai.config import get_server_config
from src.servai.mcp import McpManager
from src.servai.agent import AgentManager

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
)
logger = logging.getLogger("servai")

_server_config = get_server_config()


# ── 生命周期管理 ──────────────────────────────────────────────

@asynccontextmanager
async def lifespan(app: FastAPI):
    """AI 服务启动/关闭生命周期"""
    logger.info("🤖 AI 服务启动中...")

    # 启动 MCP 实例
    if _server_config.get("enable_mcp", True):
        try:
            await McpManager.get_instance().start_all()
        except Exception as e:
            logger.warning(f"⚠️ MCP 启动部分失败: {e}")
    else:
        logger.info("⏸️ MCP 已禁用")

    # 发现 Agent
    AgentManager.get_instance().discover()

    logger.info("✅ AI 服务已就绪")
    yield

    logger.info("🛑 AI 服务关闭中...")
    await McpManager.get_instance().stop_all()
    logger.info("👋 AI 服务已关闭")


# ── 创建 FastAPI 应用 ─────────────────────────────────────────

app = FastAPI(
    title="龙虾 AI 引擎",
    description="AI 对话、MCP 工具、Agent 运行微服务",
    version="0.2.0",
    lifespan=lifespan,
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ── 注册路由 ─────────────────────────────────────────────────

from src.servai.api import api_router
app.include_router(api_router)


# ── 启动入口 ─────────────────────────────────────────────────

def start():
    """启动 AI 微服务"""
    try:
        uvicorn.run(
            "src.servai.run:app",
            host=_server_config["host"],
            port=_server_config["port"],
            reload=_server_config["reload"],
            log_level="info",
        )
    except KeyboardInterrupt:
        logger.info("AI 服务已关闭")


if __name__ == "__main__":
    start()
