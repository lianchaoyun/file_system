﻿"""
Agent 管理桥接
将 extensions/agents/ 注册的 Agent 接入 claw 运行时
"""
import logging
from typing import Optional

from src.servai.agents.registry import get_all_agents as _discover, run_agent as _run

logger = logging.getLogger("claw.agent_manager")


class AgentManager:
    """
    Agent 管理器（应用级单例）
    负责发现和调用所有注册的 Agent
    """

    _instance: Optional["AgentManager"] = None

    def __init__(self):
        self._agents: list[dict] = []
        self._agent_map: dict[str, dict] = {}
        self._ready = False

    @classmethod
    def get_instance(cls) -> "AgentManager":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def discover(self):
        """发现并缓存所有 Agent"""
        self._agents = _discover()
        self._agent_map = {a["id"]: a for a in self._agents}
        self._ready = True
        if self._agents:
            names = ", ".join(f"{a['name']}({a['id']})" for a in self._agents)
            logger.info("🤖 发现 %d 个 Agent: %s", len(self._agents), names)
        else:
            logger.info("🤖 未发现 Agent")

    @property
    def is_ready(self) -> bool:
        return self._ready

    def get_status(self) -> list[dict]:
        """获取所有 Agent 状态"""
        return [
            {
                "id": a["id"],
                "name": a["name"],
                "description": a.get("description", ""),
                "icon": a.get("icon", ""),
                "tools": a.get("tools", []),
                "class": a.get("class", ""),
            }
            for a in self._agents
        ]

    def has_agent(self, agent_id: str) -> bool:
        return agent_id in self._agent_map

    async def run(self, agent_id: str, task: str) -> str:
        """运行指定 Agent"""
        return await _run(agent_id, task)
