﻿"""
引擎工厂 — 根据配置选择并实例化引擎
支持运行时切换，带可用性检测
"""
import os
import logging
from typing import Optional

from .base import BaseEngine

logger = logging.getLogger("claw.engine.factory")

# ── 引擎元信息 ────────────────────────────────────────────────

_ENGINE_META = {
    "react": {
        "label": "ReAct 多轮循环",
        "desc": "最轻量可控，适合日常对话和工具调用",
        "icon": "fa-solid fa-arrows-spin",
    },
    "langgraph": {
        "label": "LangGraph 状态图",
        "desc": "条件分支、循环重试、状态持久化",
        "icon": "fa-solid fa-diagram-project",
    },
    "crewai": {
        "label": "CrewAI 多Agent",
        "desc": "多角色协作，适合复杂分析任务",
        "icon": "fa-solid fa-users",
    },
}

# 持久化 key
_ENGINE_DB_KEY = "active_engine"

# ── 内部状态 ──────────────────────────────────────────────────

_engine_cache: dict[str, BaseEngine] = {}
_active_engine: Optional[BaseEngine] = None
_active_name: str = ""


# ── 持久化 ────────────────────────────────────────────────────

def _read_engine_name() -> str:
    """从 rawdata 表读取当前活跃引擎名称"""
    try:
        from src.common.mysql_utils import RawData
        row = RawData.select().where(RawData.raw_key == _ENGINE_DB_KEY).first()
        if row and row.raw_value and row.raw_value in _ENGINE_META:
            return row.raw_value
    except Exception:
        pass
    return "react"


def _write_engine_name(name: str):
    """写入当前活跃引擎名称到 rawdata 表"""
    from src.common.mysql_utils import RawData
    try:
        row = RawData.select().where(RawData.raw_key == _ENGINE_DB_KEY).first()
        if row:
            row.raw_value = name
            row.save()
        else:
            RawData.create(raw_key=_ENGINE_DB_KEY, raw_value=name)
    except Exception as e:
        logger.error(f"写入引擎设置失败: {e}")


# ── 可用性检测 ────────────────────────────────────────────────

def _check_engine(name: str) -> dict:
    """检查单个引擎是否可用"""
    meta = _ENGINE_META.get(name, {"label": name, "desc": "", "icon": "fa-solid fa-cube"})
    info = {"name": name, **meta, "available": False, "error": None}

    if name == "react":
        info["available"] = True
    elif name == "langgraph":
        missing = []
        try:
            import langgraph  # noqa: F401
        except ImportError:
            missing.append("langgraph")
        try:
            import langchain_openai  # noqa: F401
        except ImportError:
            missing.append("langchain-openai")
        if missing:
            info["error"] = f"缺少依赖: pip install {' '.join(missing)}"
        else:
            info["available"] = True
    elif name == "crewai":
        try:
            import crewai  # noqa: F401
            info["available"] = True
        except ImportError:
            info["error"] = "缺少依赖: pip install crewai"

    return info


# ── 公开 API ──────────────────────────────────────────────────

def list_engines() -> list[dict]:
    """列出所有引擎及其可用状态"""
    return [_check_engine(n) for n in _ENGINE_META]


def get_active_engine_name() -> str:
    """获取当前激活的引擎名称"""
    return _read_engine_name()


def set_active_engine(name: str) -> bool:
    """切换活跃引擎，返回是否成功"""
    global _active_engine, _active_name
    if name not in _ENGINE_META:
        return False
    check = _check_engine(name)
    if not check["available"]:
        return False
    _write_engine_name(name)
    # 清除缓存，下次 get_active_engine 会重新加载
    _active_engine = None
    _active_name = ""
    return True


def get_engine(name: str = None) -> BaseEngine:
    """获取指定引擎实例（懒加载 + 缓存）"""
    import importlib

    if name is None:
        name = _read_engine_name()

    if name not in _ENGINE_META:
        logger.warning(f"未知引擎 '{name}'，回退到 react")
        name = "react"

    if name in _engine_cache:
        return _engine_cache[name]

    module_map = {
        "react": ("src.servai.engine_react", "ReactEngine"),
        "langgraph": ("src.servai.engine_langgraph", "LangGraphEngine"),
        "crewai": ("src.servai.engine_crewai", "CrewAIEngine"),
    }
    module_path, class_name = module_map[name]

    try:
        mod = importlib.import_module(module_path)
        engine_cls = getattr(mod, class_name)
        engine = engine_cls()
        _engine_cache[name] = engine
        logger.info(f"🔧 引擎已加载: {_ENGINE_META[name]['label']} ({name})")
        return engine
    except Exception as e:
        logger.error(f"❌ 加载引擎 '{name}' 失败: {e}")
        if name != "react":
            return get_engine("react")
        raise


def get_active_engine() -> BaseEngine:
    """获取当前激活的引擎（自动检测切换）"""
    global _active_engine, _active_name
    current_name = _read_engine_name()

    if current_name != _active_name:
        logger.info(f"🔄 引擎切换: {_active_name or 'none'} → {current_name}")
        _active_engine = get_engine(current_name)
        _active_name = current_name

    return _active_engine
