"""
技能管理器
负责技能注册、调度和工具调用分发
"""
import json
import logging
from typing import Any

from .builtin import ALL_TOOLS, TOOL_EXECUTORS

# scheduler 延迟导入 — servai 不直接依赖 src.serv
_claw_scheduler = None


def _get_scheduler():
    """延迟获取 scheduler 模块，避免启动时循环依赖"""
    global _claw_scheduler
    if _claw_scheduler is None:
        try:
            from src.serv import scheduler as _sched
            _claw_scheduler = _sched
        except ImportError:
            logger.warning("⚠️ scheduler 模块不可用，manage_schedule 工具将无法使用")
            _claw_scheduler = False
    return _claw_scheduler if _claw_scheduler is not False else None

logger = logging.getLogger("claw.skill_manager")


async def execute_tool_call(tool_call: dict) -> dict:
    """
    执行单个工具调用
    
    参数:
        tool_call: {"id": "call_xxx", "function": {"name": "xxx", "arguments": "{...}"}}
    
    返回:
        {"role": "tool", "tool_call_id": "call_xxx", "content": "result"}
    """
    func_name = tool_call["function"]["name"]
    try:
        arguments = json.loads(tool_call["function"]["arguments"])
    except json.JSONDecodeError:
        arguments = {}

    logger.info(f"🔧 执行工具: {func_name}({arguments})")

    executor = TOOL_EXECUTORS.get(func_name)
    if executor is None:
        if func_name == "manage_schedule":
            content = await _handle_schedule(arguments)
        else:
            content = f"[错误] 未知工具: {func_name}"
    else:
        try:
            if func_name == "http_request":
                content = await executor(**arguments)
            else:
                content = executor(**arguments)
        except Exception as e:
            content = f"[错误] 工具执行失败: {e}"

    return {
        "role": "tool",
        "tool_call_id": tool_call.get("id", ""),
        "content": str(content)
    }


async def execute_tool_calls(tool_calls: list[dict]) -> list[dict]:
    """批量执行工具调用"""
    results = []
    for tc in tool_calls:
        result = await execute_tool_call(tc)
        results.append(result)
    return results


async def _handle_schedule(arguments: dict) -> str:
    """处理定时任务管理"""
    sched = _get_scheduler()
    if sched is None:
        return "[错误] 调度器模块不可用，无法管理定时任务"

    action = arguments.get("action", "list")

    if action == "list":
        tasks = sched.list_schedules()
        if not tasks:
            return "当前没有定时任务"
        lines = ["当前定时任务:"]
        for t in tasks:
            lines.append(f"  - {t['name']}: cron={t['trigger']} → {t.get('command', '无')}")
        return "\n".join(lines)

    elif action == "add":
        name = arguments.get("task_name", "")
        cron = arguments.get("cron", "")
        command = arguments.get("command", "")
        if not name or not cron:
            return "[错误] 添加任务需要 task_name 和 cron 参数"
        sched.add_schedule(name, cron, command)
        return f"✅ 定时任务 '{name}' 已添加: cron={cron}, command={command}"

    elif action == "remove":
        name = arguments.get("task_name", "")
        if not name:
            return "[错误] 删除任务需要 task_name 参数"
        sched.remove_schedule(name)
        return f"🗑️ 定时任务 '{name}' 已删除"

    return f"[错误] 未知操作: {action}"


def get_tool_definitions() -> list[dict]:
    """获取所有工具定义（用于 function calling）"""
    return ALL_TOOLS
