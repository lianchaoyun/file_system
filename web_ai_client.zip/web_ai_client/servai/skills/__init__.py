﻿# -*- coding: utf-8 -*-
"""
技能（Skills）扩展包

提供:
  - builtin   内置技能定义（bash、weather、http、schedule）
  - manager   技能管理器（注册、调度、工具调用分发）
"""

from src.servai.skills.builtin import ALL_TOOLS, TOOL_EXECUTORS
from src.servai.skills.manager import get_tool_definitions, execute_tool_call, execute_tool_calls

__all__ = [
    "ALL_TOOLS",
    "TOOL_EXECUTORS",
    "get_tool_definitions",
    "execute_tool_call",
    "execute_tool_calls",
]
