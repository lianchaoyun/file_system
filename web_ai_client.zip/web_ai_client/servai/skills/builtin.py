﻿"""
技能定义
每个技能是一个可调用的工具，支持 function calling 协议
"""
import subprocess
import json
from typing import Any


# ── Bash 命令执行 ────────────────────────────────────────────

BASH_TOOL = {
    "type": "function",
    "function": {
        "name": "run_bash",
        "description": "在服务器上执行 Bash 命令并返回输出。谨慎使用，避免破坏性操作。",
        "parameters": {
            "type": "object",
            "properties": {
                "command": {
                    "type": "string",
                    "description": "要执行的 shell 命令"
                }
            },
            "required": ["command"]
        }
    }
}


def run_bash(command: str) -> str:
    """执行 Bash 命令"""
    try:
        result = subprocess.run(
            command, shell=True, capture_output=True, text=True, timeout=30
        )
        output = result.stdout.strip() or result.stderr.strip()
        return output[:2000] if output else "(无输出)"
    except subprocess.TimeoutExpired:
        return "[错误] 命令执行超时 (30秒)"
    except Exception as e:
        return f"[错误] 命令执行失败: {e}"


# ── 天气查询 ──────────────────────────────────────────────────

WEATHER_TOOL = {
    "type": "function",
    "function": {
        "name": "get_weather",
        "description": "查询指定城市的天气信息（模拟数据，实际使用需接入天气 API）",
        "parameters": {
            "type": "object",
            "properties": {
                "city": {
                    "type": "string",
                    "description": "城市名称，如 Beijing, Shanghai"
                }
            },
            "required": ["city"]
        }
    }
}


def get_weather(city: str) -> str:
    """查询天气（模拟）"""
    # 模拟天气数据
    weather_data = {
        "beijing": "北京: ☀️ 晴, 28°C, 湿度 45%, 风力 3级",
        "shanghai": "上海: ⛅ 多云, 25°C, 湿度 70%, 风力 2级",
        "shenzhen": "深圳: 🌧️ 阵雨, 30°C, 湿度 85%, 风力 4级",
        "guangzhou": "广州: ⛅ 多云转晴, 32°C, 湿度 75%, 风力 2级",
        "hangzhou": "杭州: ☀️ 晴, 27°C, 湿度 55%, 风力 3级",
        "chengdu": "成都: 🌧️ 小雨, 22°C, 湿度 80%, 风力 2级",
    }
    key = city.lower().replace(" ", "")
    return weather_data.get(key, f"{city}: 暂无天气数据，请检查城市名称")


# ── HTTP 请求 ─────────────────────────────────────────────────

HTTP_TOOL = {
    "type": "function",
    "function": {
        "name": "http_request",
        "description": "发送 HTTP GET 请求获取网页或 API 数据",
        "parameters": {
            "type": "object",
            "properties": {
                "url": {
                    "type": "string",
                    "description": "请求的 URL"
                }
            },
            "required": ["url"]
        }
    }
}


async def http_request(url: str) -> str:
    """HTTP 请求（异步）"""
    try:
        import httpx
        async with httpx.AsyncClient(timeout=15) as client:
            resp = await client.get(url, follow_redirects=True)
            resp.raise_for_status()
            content = resp.text[:3000]
            return content if content else "(空响应)"
    except Exception as e:
        return f"[错误] HTTP 请求失败: {e}"


# ── 定时任务管理 ──────────────────────────────────────────────

SCHEDULE_TOOL = {
    "type": "function",
    "function": {
        "name": "manage_schedule",
        "description": "管理定时任务：添加、删除、列出定时任务",
        "parameters": {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": ["add", "remove", "list"],
                    "description": "操作类型：add(添加), remove(删除), list(列出)"
                },
                "task_name": {
                    "type": "string",
                    "description": "任务名称"
                },
                "cron": {
                    "type": "string",
                    "description": "Cron 表达式，如 '*/5 * * * *' 表示每5分钟"
                },
                "command": {
                    "type": "string",
                    "description": "要定时执行的命令"
                }
            },
            "required": ["action"]
        }
    }
}


# ── 项目信息 ──────────────────────────────────────────────────

PROJECT_INFO_TOOL = {
    "type": "function",
    "function": {
        "name": "project_info",
        "description": "获取龙虾项目基本信息，包括扩展数量、技能数量、MCP 数量等运行时状态",
        "parameters": {
            "type": "object",
            "properties": {
                "detail": {
                    "type": "string",
                    "enum": ["summary", "skills", "mcps", "all"],
                    "description": "信息类型：summary(概览), skills(技能列表), mcps(MCP列表), all(全部)"
                }
            },
            "required": []
        }
    }
}


def project_info(detail: str = "summary") -> str:
    """获取项目运行时信息"""
    import os
    from src.common.paths import SRC_DIR_STR
    lines = ["📊 龙虾 运行时状态"]

    ext_dir = os.path.join(SRC_DIR_STR, "ai")
    exts = [d for d in os.listdir(ext_dir)
            if os.path.isdir(os.path.join(ext_dir, d)) and not d.startswith("_")]

    if detail in ("summary", "all"):
        lines.append(f"  扩展包: {len(exts)} 个 ({', '.join(exts)})")
        lines.append(f"  内置技能: {len(ALL_TOOLS)} 个")
        # 尝试获取 MCP 信息
        try:
            from src.servai.mcp import McpManager
            mgr = McpManager.get_instance()
            status = mgr.get_status()
            running = sum(1 for s in status if s["status"] == "running")
            lines.append(f"  MCP 实例: {len(status)} 个 (运行中: {running})")
        except Exception:
            lines.append(f"  MCP 实例: (无法获取)")

    if detail in ("skills", "all"):
        lines.append("\n📦 内置技能列表:")
        for tool in ALL_TOOLS:
            name = tool["function"]["name"]
            desc = tool["function"]["description"].split("。")[0]
            lines.append(f"  - {name}: {desc}")

    if detail in ("mcps", "all"):
        lines.append("\n🔌 MCP 实例:")
        try:
            from src.servai.mcp import McpManager
            for s in McpManager.get_instance().get_status():
                icon = "✅" if s["status"] == "running" else "❌"
                lines.append(f"  {icon} {s['id']}: {s['tool_count']} 个工具 [{s['status']}]")
        except Exception:
            lines.append("  (MCP 管理器未就绪)")

    return "\n".join(lines)


# ── 工具注册表 ────────────────────────────────────────────────

# 所有工具定义（用于 function calling）
ALL_TOOLS = [BASH_TOOL, WEATHER_TOOL, HTTP_TOOL, SCHEDULE_TOOL, PROJECT_INFO_TOOL]

# 工具执行映射
TOOL_EXECUTORS = {
    "run_bash": run_bash,
    "get_weather": get_weather,
    "http_request": http_request,
    "project_info": project_info,
    "manage_schedule": None,  # 由 scheduler 模块处理
}
