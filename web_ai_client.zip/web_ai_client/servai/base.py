"""
AI 引擎统一接口
所有引擎实现必须继承 BaseEngine 并实现 chat_stream 方法
"""
import logging
from abc import ABC, abstractmethod
from typing import AsyncGenerator

logger = logging.getLogger("claw.engine.base")


class BaseEngine(ABC):
    """AI 引擎基类，定义统一的事件流接口"""

    @abstractmethod
    async def chat_stream(
        self,
        session_id: str,
        user_message: str,
        enable_tools: bool = True,
    ) -> AsyncGenerator[dict, None]:
        """
        流式对话，yield 事件字典:
        - {"type": "delta", "content": "..."}          → 文本增量
        - {"type": "tool_call", "name": "...", ...}     → 工具调用开始
        - {"type": "tool_result", "content": "..."}     → 工具执行结果
        - {"type": "done"}                              → 对话完成
        - {"type": "error", "content": "..."}           → 错误
        """
        ...

    async def chat_non_stream(
        self,
        session_id: str,
        user_message: str,
        enable_tools: bool = True,
    ) -> dict:
        """非流式对话（默认实现：消费流式事件）"""
        full_content = ""
        tool_results = []

        async for event in self.chat_stream(session_id, user_message, enable_tools):
            if event["type"] == "delta":
                full_content += event["content"]
            elif event["type"] == "tool_result":
                tool_results.append(event["content"])
            elif event["type"] == "error":
                return {"reply": f"❌ {event['content']}", "tool_results": tool_results}

        return {"reply": full_content, "tool_results": tool_results}

    def reset_session(self, session_id: str):
        """重置会话"""
        from .memory import clear_history
        clear_history(session_id)
