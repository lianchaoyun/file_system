"""
技能/工具列表接口
GET /v1/skills — 列出所有技能和 MCP 工具定义
"""
import logging

from fastapi import APIRouter

from src.servai.skills.manager import get_tool_definitions as get_skill_tools
from src.servai.mcp import McpManager

logger = logging.getLogger("servai.skills")

router = APIRouter(prefix="/skills", tags=["技能管理"])


@router.get("")
async def list_skills():
    """列出所有技能/工具（含 MCP 工具），带完整参数定义"""
    skills = [
        {
            "name": t["function"]["name"],
            "description": t["function"]["description"],
            "parameters": t["function"].get("parameters", {}),
            "source": "skill",
        }
        for t in get_skill_tools()
    ]
    mcp_tools = [
        {
            "name": t["function"]["name"],
            "description": t["function"]["description"],
            "parameters": t["function"].get("parameters", {}),
            "source": "mcp",
        }
        for t in McpManager.get_instance().get_tool_definitions()
    ]
    return {"skills": skills + mcp_tools}
