"""
MCP 管理接口
GET /v1/mcps — 列出所有 MCP 实例及其状态
"""
import logging

from fastapi import APIRouter

from src.servai.mcp import McpManager

logger = logging.getLogger("servai.mcps")

router = APIRouter(prefix="/mcps", tags=["MCP管理"])


@router.get("")
async def get_mcp_status():
    """列出所有 MCP 实例及其状态"""
    return {"mcps": McpManager.get_instance().get_status()}
