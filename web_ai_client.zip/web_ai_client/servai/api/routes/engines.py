"""
引擎管理接口
GET  /v1/engines        — 列出所有引擎及可用性
GET  /v1/engines/active — 获取当前激活引擎
POST /v1/engines/switch — 切换引擎
"""
import logging

from fastapi import APIRouter

from src.servai.factory import list_engines, get_active_engine_name, set_active_engine

logger = logging.getLogger("servai.engines")

router = APIRouter(prefix="/engines", tags=["引擎管理"])


@router.get("")
async def get_engines():
    """获取引擎状态：所有引擎可用性"""
    return {
        "active": get_active_engine_name(),
        "engines": list_engines(),
    }


@router.get("/active")
async def get_active():
    """获取当前激活引擎"""
    return {"active": get_active_engine_name()}


@router.post("/switch")
async def switch_engine(body: dict):
    """切换活跃引擎"""
    engine_name = body.get("engine", "").strip()
    if not engine_name:
        return {"status": "error", "message": "引擎名称不能为空"}

    ok = set_active_engine(engine_name)
    if not ok:
        return {"status": "error", "message": f"无法切换到 '{engine_name}'，请检查依赖是否已安装"}

    logger.info(f"🔄 引擎已切换: {engine_name}")
    return {"status": "ok", "active": engine_name}
