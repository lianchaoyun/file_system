"""
Token 统计接口
GET  /v1/token/stats   — 获取 Token 统计
POST /v1/token/reset   — 重置统计
"""
import logging

from fastapi import APIRouter

from src.servai.memory import get_token_stats, reset_token_stats

logger = logging.getLogger("servai.token")

router = APIRouter(prefix="/token", tags=["Token统计"])


@router.get("/stats")
async def get_stats(days: int = 7):
    """获取 Token 使用统计"""
    stats = get_token_stats(days=days)
    return {"status": "ok", "data": stats}


@router.post("/reset")
async def reset_stats():
    """重置 Token 统计"""
    reset_token_stats()
    return {"status": "ok", "message": "Token 统计已清空"}
