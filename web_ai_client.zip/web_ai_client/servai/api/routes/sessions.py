"""
会话管理接口
GET    /v1/sessions              — 列出所有会话
POST   /v1/sessions              — 创建会话
DELETE /v1/sessions/{id}         — 删除会话
POST   /v1/sessions/{id}/clear   — 清除会话消息
GET    /v1/sessions/{id}/messages — 获取会话历史
PUT    /v1/sessions/{id}         — 更新会话（标题/模型）
"""
import logging
from datetime import datetime, timezone

from fastapi import APIRouter
from fastapi.responses import JSONResponse

from src.servai.engine import reset_session
from src.servai.memory import list_sessions, get_history, clear_history, save_history

logger = logging.getLogger("servai.sessions")

router = APIRouter(prefix="/sessions", tags=["会话管理"])


@router.get("")
async def get_sessions():
    """获取所有会话列表"""
    sessions = list_sessions()
    return {"sessions": sessions}


@router.post("")
async def create_session(request: dict):
    """创建新会话"""
    sid = request.get("id") if request else None
    model_id = request.get("model_id") if request else None
    if not sid:
        sid = "session-" + datetime.now(timezone.utc).isoformat().replace(":", "-")
    save_history(sid, [])
    from src.servai.memory import get_or_create_session
    get_or_create_session(sid, model_id=model_id)
    logger.info(f"📝 创建会话: {sid}")
    return {"id": sid, "status": "created"}


@router.delete("/{session_id}")
async def delete_session(session_id: str):
    """删除会话"""
    logger.info(f"🗑️ 删除会话: {session_id}")
    ok = clear_history(session_id)
    if not ok:
        return JSONResponse(
            status_code=500,
            content={"status": "error", "message": f"无法删除会话 {session_id}"}
        )
    return {"status": "ok", "deleted": session_id}


@router.post("/{session_id}/clear")
async def clear_session(session_id: str):
    """清除会话消息"""
    reset_session(session_id)
    return {"status": "ok"}


@router.get("/{session_id}/messages")
async def get_session_messages(session_id: str):
    """获取会话历史消息"""
    history = get_history(session_id)
    messages = [
        {"role": m["role"], "content": m["content"]}
        for m in history if m["role"] in ("user", "assistant")
    ]
    return {"session_id": session_id, "messages": messages}


@router.put("/{session_id}")
async def update_session(session_id: str, request: dict):
    """更新会话（标题、模型绑定等）"""
    from src.common.mysql_utils import ClawSessions
    try:
        updates = {}
        if "title" in request:
            updates["title"] = request["title"]
        if "model_id" in request:
            updates["model_id"] = request["model_id"]
        if updates:
            updates["updated_at"] = datetime.now()
            ClawSessions.update(**updates).where(
                ClawSessions.session_id == session_id
            ).execute()
        return {"status": "ok"}
    except Exception as e:
        logger.error(f"更新会话失败: {e}")
        return JSONResponse(status_code=500, content={"status": "error", "message": str(e)})
