"""
Agent 管理接口
GET  /v1/agents              — 列出所有 Agent
POST /v1/agents/{id}/run     — 运行指定 Agent
"""
import logging

from fastapi import APIRouter
from fastapi.responses import JSONResponse

from src.servai.agent import AgentManager

logger = logging.getLogger("servai.agents")

router = APIRouter(prefix="/agents", tags=["Agent管理"])


@router.get("")
async def list_agents():
    """列出所有已发现的 Agent"""
    return {"agents": AgentManager.get_instance().get_status()}


@router.post("/{agent_id}/run")
async def run_agent(agent_id: str, request: dict):
    """运行指定 Agent"""
    task = request.get("task", "").strip()
    if not task:
        return JSONResponse(status_code=400, content={"status": "error", "message": "缺少 task 参数"})

    mgr = AgentManager.get_instance()
    if not mgr.has_agent(agent_id):
        return JSONResponse(status_code=404, content={"status": "error", "message": f"Agent '{agent_id}' 不存在"})

    try:
        result = await mgr.run(agent_id, task)
        return {"status": "ok", "agent_id": agent_id, "result": result}
    except Exception as e:
        logger.error(f"❌ Agent [{agent_id}] 运行异常: {e}")
        return JSONResponse(status_code=500, content={"status": "error", "message": str(e)})
