"""
AI 聊天接口（流式 & 非流式）
POST /v1/chat          — 非流式
POST /v1/chat/stream   — 流式 SSE
"""
import json
import logging

from fastapi import APIRouter, Request
from fastapi.responses import StreamingResponse

from src.servai.engine import chat_stream, chat_non_stream

logger = logging.getLogger("servai.chat")

router = APIRouter(prefix="/chat", tags=["聊天"])


@router.post("")
async def chat_endpoint(request: dict):
    """
    非流式聊天
    Body: {"message": "...", "session_id": "...", "enable_tools": true}
    """
    message = request.get("message", "").strip()
    session_id = request.get("session_id", "default")
    enable_tools = request.get("enable_tools", True)

    if not message:
        return {"error": "消息不能为空"}

    result = await chat_non_stream(session_id, message, enable_tools)
    return {
        "session_id": session_id,
        "reply": result["reply"],
        "tool_results": result.get("tool_results", []),
    }


@router.post("/stream")
async def chat_stream_endpoint(request: Request):
    """
    流式聊天 (SSE)
    Body: {"message": "...", "session_id": "...", "enable_tools": true}
    """
    data = await request.json()
    message = data.get("message", "").strip()
    session_id = data.get("session_id", "default")
    enable_tools = data.get("enable_tools", True)

    if not message:
        return {"error": "消息不能为空"}

    async def event_generator():
        async for event in chat_stream(session_id, message, enable_tools):
            yield f"data: {json.dumps(event, ensure_ascii=False)}\n\n"
        yield "data: [DONE]\n\n"

    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )
