"""
模型配置接口（servai 侧）
GET  /v1/models/active — 获取当前激活模型配置
POST /v1/models/reload — 通知 servai 重建客户端缓存（模型切换后由 serv 调用）
"""
import logging

from fastapi import APIRouter

from src.servai.config import get_ollama_config
from src.servai.engine import _get_client

logger = logging.getLogger("servai.models")

router = APIRouter(prefix="/models", tags=["模型配置"])


@router.get("/active")
async def get_active_model():
    """获取当前激活的模型配置"""
    config = get_ollama_config()
    return {"active_model": config}


@router.post("/reload")
async def reload_client():
    """通知 servai 重建 OpenAI 客户端缓存（模型切换后调用）"""
    _get_client()
    logger.info("🔄 servai 客户端缓存已重建")
    return {"status": "ok", "message": "客户端缓存已重建"}
