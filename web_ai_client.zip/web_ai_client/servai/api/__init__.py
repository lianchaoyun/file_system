"""
servai API 路由 — 统一暴露所有 AI 服务接口
"""
from fastapi import APIRouter

from .routes.chat import router as chat_router
from .routes.agents import router as agents_router
from .routes.mcps import router as mcps_router
from .routes.sessions import router as sessions_router
from .routes.engines import router as engines_router
from .routes.token import router as token_router
from .routes.models import router as models_router
from .routes.skills import router as skills_router

api_router = APIRouter(prefix="/v1")

api_router.include_router(chat_router)
api_router.include_router(agents_router)
api_router.include_router(mcps_router)
api_router.include_router(sessions_router)
api_router.include_router(engines_router)
api_router.include_router(token_router)
api_router.include_router(models_router)
api_router.include_router(skills_router)
