﻿"""
LangGraph 引擎 — 状态图驱动（骨架实现）
支持条件分支、循环重试、状态持久化

依赖: pip install langgraph langchain-openai

注意: 当前为骨架实现，核心逻辑使用 ReAct 回退
      待 langgraph 依赖安装后可启用完整状态图功能
"""
import json
import logging
from typing import AsyncGenerator

from .base import BaseEngine
from .memory import get_chat_messages, add_message, add_token_usage
from src.servai.config import get_ollama_config

logger = logging.getLogger("claw.engine.langgraph")

SYSTEM_PROMPT = """你是龙虾，一个有工具调用能力的AI助手。
回复风格：简洁、专业、中文。"""


class LangGraphEngine(BaseEngine):
    """LangGraph 状态图引擎"""

    def __init__(self):
        self._graph = None

    def _build_graph(self):
        """
        构建 LangGraph 状态图

        状态图结构:
            START → agent → [需要工具?] → tools → agent (循环)
                                  ↓ 否
                               respond → END
        """
        try:
            from langgraph.graph import StateGraph, START, END
            from typing import TypedDict, Literal
            from langchain_core.messages import HumanMessage, AIMessage, SystemMessage, ToolMessage
            from langchain_openai import ChatOpenAI

            class AgentState(TypedDict):
                messages: list
                next_action: Literal["tool", "respond", "end"]

            def call_model(state: AgentState) -> dict:
                """推理节点：调用 LLM"""
                from src.servai.skills.manager import get_tool_definitions as get_skill_tools
                from .mcp import McpManager

                _mcp = McpManager.get_instance()
                llm_config = get_ollama_config()

                llm = ChatOpenAI(
                    base_url=llm_config["base_url"],
                    api_key=llm_config["api_key"],
                    model=llm_config["model"],
                    temperature=llm_config["temperature"],
                    max_tokens=llm_config["max_tokens"],
                )

                skill_tools = list(get_skill_tools())
                mcp_tools = list(_mcp.get_tool_definitions()) if _mcp else []
                all_tools = skill_tools + mcp_tools

                if all_tools:
                    llm_with_tools = llm.bind_tools(all_tools)
                else:
                    llm_with_tools = llm

                response = llm_with_tools.invoke(state["messages"])
                return {"messages": [response]}

            def should_continue(state: AgentState) -> Literal["tools", "end"]:
                """条件边：判断是否需要执行工具"""
                last_message = state["messages"][-1]
                if hasattr(last_message, "tool_calls") and last_message.tool_calls:
                    return "tools"
                return "end"

            def execute_tools(state: AgentState) -> dict:
                """工具执行节点"""
                import asyncio
                from src.servai.skills.manager import execute_tool_call
                from .mcp import McpManager

                _mcp = McpManager.get_instance()
                last_message = state["messages"][-1]
                tool_messages = []

                for tc in last_message.tool_calls:
                    func_name = tc["name"]
                    args = tc["args"]

                    if _mcp and _mcp.has_tool(func_name):
                        loop = asyncio.get_event_loop()
                        content = loop.run_until_complete(_mcp.execute_tool(func_name, args))
                    else:
                        tool_call_dict = {
                            "id": tc.get("id", ""),
                            "function": {"name": func_name, "arguments": json.dumps(args)}
                        }
                        result = asyncio.get_event_loop().run_until_complete(execute_tool_call(tool_call_dict))
                        content = result["content"]

                    tool_messages.append(ToolMessage(content=content, tool_call_id=tc.get("id", "")))

                return {"messages": tool_messages}

            graph = StateGraph(AgentState)
            graph.add_node("agent", call_model)
            graph.add_node("tools", execute_tools)
            graph.add_edge(START, "agent")
            # 条件边：根据 should_continue 的返回值决定下一步
            # "tools" → tools 节点，"end" → END
            graph.add_conditional_edges(
                "agent",
                should_continue,
                {
                    "tools": "tools",
                    "end": END
                }
            )
            graph.add_edge("tools", "agent")

            self._graph = graph.compile()
            logger.info("✅ LangGraph 状态图已构建")
            return self._graph

        except ImportError as e:
            logger.error(f"LangGraph 依赖未安装: {e}")
            return None

    async def chat_stream(
        self,
        session_id: str,
        user_message: str,
        enable_tools: bool = True,
    ) -> AsyncGenerator[dict, None]:
        try:
            from langchain_core.messages import HumanMessage, AIMessage, SystemMessage

            # 懒加载状态图
            if self._graph is None:
                graph = self._build_graph()
                if graph is None:
                    yield {"type": "error", "content": "LangGraph 依赖未安装，请执行: pip install langgraph langchain-openai"}
                    yield {"type": "done"}
                    return

            add_message(session_id, "user", user_message)

            # 构建 LangChain 消息
            messages = get_chat_messages(session_id, SYSTEM_PROMPT)
            lc_messages = []
            for m in messages:
                if m["role"] == "system":
                    lc_messages.append(SystemMessage(content=m["content"]))
                elif m["role"] == "user":
                    lc_messages.append(HumanMessage(content=m["content"]))
                elif m["role"] == "assistant":
                    lc_messages.append(AIMessage(content=m["content"]))

            # 流式执行状态图
            full_content = ""
            total_prompt_tokens = 0
            total_completion_tokens = 0
            
            async for event in self._graph.astream_events(
                {"messages": lc_messages},
                version="v2",
            ):
                kind = event.get("event", "")

                if kind == "on_chat_model_stream":
                    chunk = event["data"]["chunk"]
                    content = chunk.content
                    if content:
                        full_content += content
                        yield {"type": "delta", "content": content}
                    # 捕获 usage 信息
                    if hasattr(chunk, 'usage_metadata') and chunk.usage_metadata:
                        usage = chunk.usage_metadata
                        total_prompt_tokens += usage.get('input_tokens', 0) or 0
                        total_completion_tokens += usage.get('output_tokens', 0) or 0

                elif kind == "on_tool_start":
                    yield {
                        "type": "tool_call",
                        "name": event.get("name", ""),
                        "arguments": str(event["data"].get("input", {}))
                    }

                elif kind == "on_tool_end":
                    output = str(event["data"].get("output", ""))
                    yield {"type": "tool_result", "content": output}

            # 保存回复
            if full_content:
                add_message(session_id, "assistant", full_content)

            # 记录 token 使用量
            if total_prompt_tokens > 0 or total_completion_tokens > 0:
                add_token_usage(
                    session_id=session_id,
                    engine_name="langgraph",
                    prompt_tokens=total_prompt_tokens,
                    completion_tokens=total_completion_tokens,
                    total_tokens=total_prompt_tokens + total_completion_tokens,
                )
                logger.info(f"[langgraph] Token: prompt={total_prompt_tokens}, completion={total_completion_tokens}")

            yield {"type": "done"}

        except Exception as e:
            logger.error(f"LangGraph 引擎错误: {e}")
            yield {"type": "error", "content": str(e)}
