"""
servai 独立配置模块
直接从 config.toml 和 MySQL DB 读取配置，不再依赖 src.serv
"""
import os
import sys
import logging

from src.common.paths import PROJECT_ROOT_STR, CONFIG_TOML_STR

_PROJECT_ROOT = PROJECT_ROOT_STR
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

from src.common.config_utils import ConfigReader

_CONFIG_PATH = CONFIG_TOML_STR
_reader = ConfigReader(_CONFIG_PATH)

logger = logging.getLogger("servai.config")


# ════════════════════════════════════════════════════════════════
#  LLM 运行配置（从 DB 读取激活模型）
# ════════════════════════════════════════════════════════════════

def get_ollama_config() -> dict:
    """
    获取当前激活的 LLM 配置（从 DB 读取）。
    若没有激活模型，返回硬编码默认值。
    """
    try:
        from src.common.mysql_utils import ClawLlmModels

        active = ClawLlmModels.get_or_none(ClawLlmModels.is_active == 1)
        if active:
            return {
                "model_id": active.model_id,
                "base_url": active.base_url,
                "model": active.model,
                "api_key": active.api_key,
                "max_tokens": active.max_tokens,
                "temperature": active.temperature,
                "timeout": active.timeout,
                "supports_tools": bool(active.supports_tools),
            }
    except Exception as e:
        logger.warning(f"从 DB 读取模型配置失败: {e}")

    return {
        "model_id": "default",
        "base_url": "http://localhost:11434/v1",
        "model": "",
        "api_key": "ollama",
        "max_tokens": 4096,
        "temperature": 0.7,
        "timeout": 120,
        "supports_tools": True,
    }


# ════════════════════════════════════════════════════════════════
#  Server 基础设施配置（config.toml）
# ════════════════════════════════════════════════════════════════

def get_server_config() -> dict:
    """获取 AI 服务配置"""
    _default_file_dir = os.path.join(os.path.dirname(_PROJECT_ROOT), "file")
    return {
        "host": _reader.get("servai", "server", "host", default="0.0.0.0"),
        "port": _reader.get("servai", "server", "port", default=6961),
        "reload": _reader.get("servai", "server", "reload", default=False),
        "file_dir": _reader.get("claw", "server", "file_dir", default=_default_file_dir),
        "enable_mcp": _reader.get("claw", "enable_mcp", default=True),
        "enable_scheduler": _reader.get("claw", "enable_scheduler", default=True),
    }


def get_memory_config() -> dict:
    """获取记忆配置"""
    return {
        "max_history": _reader.get("claw", "memory", "max_history", default=20),
        "max_system_tokens": _reader.get("claw", "memory", "max_system_tokens", default=2000),
        "summary_threshold": _reader.get("claw", "memory", "summary_threshold", default=10),
        "redis_prefix": _reader.get("claw", "memory", "redis_prefix", default="claw:mem:"),
    }
