"""
MCP stdio 客户端
通过子进程 stdio 连接 MCP Server，完成协议握手、工具发现和调用

关键设计：所有 stdio_client 生命周期在同一个 asyncio Task 内完成，
避免 mcp SDK 的 anyio cancel scope 跨 task 错误。
主 task 通过 asyncio.Queue + Future 与后台 task 通信。
"""
import sys
import os
import asyncio
import logging

logger = logging.getLogger("claw.mcp_client")


class McpClient:
    """
    单个 MCP 实例的 stdio 客户端

    用法:
        client = McpClient("market_data_duckdb", "src...server", project_root="...")
        tools = await client.connect()      # 启动后台 task → 握手 → 发现工具
        result = await client.call_tool("list_symbols", {})
        await client.disconnect()
    """

    def __init__(self, instance_id: str, server_module: str, project_root: str = ""):
        self.instance_id = instance_id
        self.server_module = server_module
        self.project_root = project_root

        # 后台 task
        self._task: asyncio.Task | None = None

        # 消息队列: 主 task ↔ 后台 task
        self._req_queue: asyncio.Queue = asyncio.Queue()
        self._ready_event = asyncio.Event()

        # 连接结果（后台 task 写入，主 task 读取）
        self._connect_result: list | Exception | None = None

        self._connected = False

    # ── 连接 ─────────────────────────────────────────────────

    async def connect(self) -> list:
        """
        启动后台 task 并等待 MCP 握手完成。
        返回 MCP Tool 对象列表。
        """
        self._connect_result = None
        self._ready_event.clear()

        self._task = asyncio.create_task(self._background())
        # 等待后台 task 就绪（connect_result 被设置）
        await self._ready_event.wait()

        if isinstance(self._connect_result, Exception):
            raise self._connect_result

        tools = self._connect_result or []
        self._connected = True
        return tools

    async def _background(self):
        """
        后台 task：执行整个 stdio_client + ClientSession 生命周期。
        所有 MCP 协议操作都在此 task 内完成，避免 cancel scope 跨 task。
        """
        from mcp import ClientSession, StdioServerParameters
        from mcp.client.stdio import stdio_client as _stdio_client

        # 构建子进程启动参数
        boot_code = f"from {self.server_module} import run; run()"

        env = os.environ.copy()
        if self.project_root:
            # 确保子进程能找到 src 包
            existing = env.get("PYTHONPATH", "")
            env["PYTHONPATH"] = self.project_root + (os.pathsep + existing if existing else "")

        server_params = StdioServerParameters(
            command=sys.executable,
            args=["-c", boot_code],
            env=env,
        )

        try:
            async with _stdio_client(server_params) as (read, write):
                async with ClientSession(read, write) as session:
                    await session.initialize()
                    tools_result = await session.list_tools()
                    tools = list(tools_result.tools) if tools_result.tools else []

                    logger.info(
                        "📡 [%s] MCP 连接成功, 发现 %d 个工具",
                        self.instance_id, len(tools),
                    )
                    logger.debug(
                        "  工具列表: %s",
                        ", ".join(t.name for t in tools),
                    )

                    # 通知主 task：连接成功
                    self._connect_result = tools
                    self._ready_event.set()

                    # ── 主循环：处理工具调用请求 ──
                    while True:
                        item = await self._req_queue.get()
                        if item is None:  # 关闭信号
                            break

                        tool_name, arguments, future = item
                        try:
                            result = await session.call_tool(tool_name, arguments)
                            texts = []
                            for block in result.content:
                                if hasattr(block, "text"):
                                    texts.append(block.text)
                                else:
                                    texts.append(str(block))
                            future.set_result("\n".join(texts))
                        except Exception as e:
                            future.set_exception(e)

        except Exception as e:
            logger.error("❌ [%s] 后台 task 异常: %s", self.instance_id, e)
            if self._connect_result is None:
                # 连接阶段失败，通知主 task
                self._connect_result = e
                self._ready_event.set()
            self._connected = False

    # ── 工具调用 ─────────────────────────────────────────────

    async def call_tool(self, name: str, arguments: dict) -> str:
        """通过队列向后台 task 发送调用请求，返回结果文本"""
        if not self._connected or self._task is None:
            raise RuntimeError(f"[{self.instance_id}] MCP 未连接")

        future: asyncio.Future = asyncio.Future()
        await self._req_queue.put((name, arguments, future))
        return await future

    # ── 断开 ────────────────────────────────────────────────

    async def disconnect(self):
        """关闭连接和后台 task"""
        self._connected = False

        if self._task and not self._task.done():
            # 发送关闭信号
            try:
                await self._req_queue.put(None)
            except Exception:
                pass

            try:
                await asyncio.wait_for(self._task, timeout=5.0)
            except asyncio.TimeoutError:
                logger.warning("[%s] 后台 task 关闭超时，强制取消", self.instance_id)
                self._task.cancel()
            except Exception as e:
                logger.debug("[%s] 关闭异常: %s", self.instance_id, e)

        self._task = None
        logger.info("🔌 [%s] MCP 已断开", self.instance_id)

    @property
    def is_connected(self) -> bool:
        return self._connected and self._task is not None and not self._task.done()
