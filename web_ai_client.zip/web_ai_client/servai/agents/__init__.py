﻿# -*- coding: utf-8 -*-
"""
Agent 扩展包

每个 Agent 是一个可独立运行的自动化任务单元，具有:
  - 名称、描述
  - 可选的系统提示
  - 可调用的工具集

目录结构:
  - agent.py            Agent 基类
  - registry.py         Agent 注册表（自动发现）
  - demo/               Demo Agent 示例
"""

from src.servai.agents.agent import BaseAgent
from src.servai.agents.registry import get_all_agents, get_agent, run_agent

__all__ = [
    "BaseAgent",
    "get_all_agents",
    "get_agent",
    "run_agent",
]
