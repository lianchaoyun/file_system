"""
Agent 基类
"""
import logging
from abc import ABC, abstractmethod
from typing import Optional

logger = logging.getLogger("claw.agent")


class BaseAgent(ABC):
    """Agent 基类，所有 Agent 必须继承此类"""

    # 元信息（子类必须定义）
    name: str = ""
    description: str = ""
    icon: str = "fa-solid fa-user-astronaut"

    # 可选：Agent 使用的工具列表
    tools: list[str] = []

    # 可选：系统提示
    system_prompt: str = ""

    def __init__(self):
        pass

    @abstractmethod
    async def run(self, task: str, **kwargs) -> str:
        """
        执行 Agent 任务

        参数:
            task: 任务描述
            **kwargs: 额外参数

        返回:
            执行结果字符串
        """
        ...

    def get_info(self) -> dict:
        """获取 Agent 元信息"""
        return {
            "name": self.name,
            "description": self.description,
            "icon": self.icon,
            "tools": self.tools,
        }

    def __repr__(self):
        return f"<Agent: {self.name}>"
