﻿# -*- coding: utf-8 -*-
"""
Demo: 代码统计 Agent
统计指定目录下的代码行数、文件数、语言分布
"""
import os
from src.servai.agents.agent import BaseAgent

# 导出 AGENT_CLASS 以便注册表自动发现
AGENT_CLASS = None  # 占位，下方定义


class CodeStatsAgent(BaseAgent):
    """代码统计代理"""

    name = "代码统计"
    description = "分析项目目录的代码统计信息：文件数、代码行数、各语言分布"
    icon = "fa-solid fa-chart-bar"
    tools = ["run_bash", "project_info"]
    system_prompt = "你是一个代码分析专家，擅长统计和分析代码仓库。"

    # 语言识别映射
    LANG_MAP = {
        ".py": "Python", ".js": "JavaScript", ".ts": "TypeScript",
        ".vue": "Vue", ".jsx": "React JSX", ".tsx": "React TSX",
        ".html": "HTML", ".css": "CSS", ".scss": "SCSS",
        ".java": "Java", ".go": "Go", ".rs": "Rust",
        ".php": "PHP", ".rb": "Ruby", ".c": "C", ".cpp": "C++",
        ".h": "C/C++ Header", ".sql": "SQL", ".sh": "Shell",
        ".yaml": "YAML", ".yml": "YAML", ".json": "JSON",
        ".toml": "TOML", ".md": "Markdown", ".xml": "XML",
        ".dockerfile": "Dockerfile", ".Dockerfile": "Dockerfile",
        ".env": "Env", ".cfg": "Config", ".ini": "Config",
    }

    async def run(self, task: str, **kwargs) -> str:
        """执行代码统计任务"""
        # 从 task 或 kwargs 获取目录路径
        target = kwargs.get("target_dir", "")
        if not target:
            # 尝试从 task 描述中提取
            words = task.split()
            for w in words:
                w = w.strip('"').strip("'")
                if os.path.isdir(w):
                    target = w
                    break

        if not target:
            target = os.getcwd()

        target = os.path.abspath(target)
        if not os.path.isdir(target):
            return f"[错误] 目录不存在: {target}"

        # 统计
        stats = self._scan_dir(target)

        lines = [
            f"📊 代码统计: {target}",
            f"━━━━━━━━━━━━━━━━━━━━",
            f"总文件数: {stats['total_files']}",
            f"总代码行: {stats['total_lines']}",
            f"总空白行: {stats['blank_lines']}",
            f"有效代码: {stats['code_lines']}",
            f"",
            f"📂 语言分布:",
        ]

        for lang, info in sorted(stats["languages"].items(),
                                  key=lambda x: x[1]["lines"], reverse=True):
            pct = (info["lines"] / max(stats["total_lines"], 1)) * 100
            bar = "█" * max(1, int(pct / 5))
            lines.append(
                f"  {bar} {lang:15s} "
                f"{info['files']:4d} 文件  "
                f"{info['lines']:6d} 行  ({pct:5.1f}%)"
            )

        return "\n".join(lines)

    def _scan_dir(self, directory: str, max_files: int = 2000) -> dict:
        """扫描目录统计"""
        stats = {
            "total_files": 0,
            "total_lines": 0,
            "blank_lines": 0,
            "code_lines": 0,
            "languages": {},
        }

        skip_dirs = {".git", "__pycache__", "node_modules", ".venv",
                      "vendor", "storage", ".codebuddy", "dist", "build",
                      ".idea", ".vscode", ".DS_Store"}

        try:
            for root, dirs, files in os.walk(directory):
                # 跳过忽略目录
                dirs[:] = [d for d in dirs if d not in skip_dirs and not d.startswith(".")]

                for f in files:
                    if stats["total_files"] >= max_files:
                        return stats

                    filepath = os.path.join(root, f)
                    _, ext = os.path.splitext(f)
                    ext_lower = ext.lower()

                    # Dockerfile 特殊处理
                    if f.lower() == "dockerfile":
                        ext_lower = ".dockerfile"
                    elif not ext_lower:
                        continue  # 跳过无扩展名文件

                    lang = self.LANG_MAP.get(ext_lower, f"其他 ({ext_lower})")

                    stats["total_files"] += 1
                    try:
                        with open(filepath, "r", encoding="utf-8", errors="ignore") as fh:
                            file_lines = 0
                            file_blanks = 0
                            for line in fh:
                                stats["total_lines"] += 1
                                file_lines += 1
                                if line.strip() == "":
                                    stats["blank_lines"] += 1
                                    file_blanks += 1
                    except Exception:
                        continue

                    stats["code_lines"] += (file_lines - file_blanks)

                    if lang not in stats["languages"]:
                        stats["languages"][lang] = {"files": 0, "lines": 0}
                    stats["languages"][lang]["files"] += 1
                    stats["languages"][lang]["lines"] += file_lines

        except Exception as e:
            pass  # 权限等错误静默跳过

        return stats


AGENT_CLASS = CodeStatsAgent
