﻿"""
Agent 注册表
自动发现 extensions/agents/ 下所有子包中的 Agent
"""
import os
import importlib
import logging
from typing import Optional

logger = logging.getLogger("claw.agent_registry")


# ── 自动发现 ─────────────────────────────────────────────────

def _discover_agents() -> dict[str, type]:
    """
    扫描 extensions/agents/ 目录，自动发现所有 Agent 子类
    """
    agents_dir = os.path.dirname(os.path.abspath(__file__))
    discovered = {}

    for name in os.listdir(agents_dir):
        sub_dir = os.path.join(agents_dir, name)
        if name.startswith("_") or not os.path.isdir(sub_dir):
            continue
        if not os.path.exists(os.path.join(sub_dir, "__init__.py")):
            continue

        try:
            module = importlib.import_module(f"src.servai.agents.{name}")
            # 查找模块中导出的 AGENT_CLASS
            if hasattr(module, "AGENT_CLASS"):
                agent_cls = module.AGENT_CLASS
                discovered[name] = agent_cls
                logger.debug(f"  📦 发现 Agent: {name} → {agent_cls.__name__}")
        except Exception as e:
            logger.warning(f"  ⚠️ 跳过 Agent '{name}': {e}")

    return discovered


# ── 缓存 ────────────────────────────────────────────────────

_agent_registry: dict[str, type] = {}
_agent_instances: dict[str, object] = {}


def _ensure_discovered():
    """确保已发现所有 Agent"""
    global _agent_registry
    if not _agent_registry:
        _agent_registry = _discover_agents()


# ── API ─────────────────────────────────────────────────────

def get_all_agents() -> list[dict]:
    """获取所有已发现的 Agent 元信息"""
    _ensure_discovered()
    result = []
    for agent_id, agent_cls in _agent_registry.items():
        agent = agent_cls()
        info = agent.get_info()
        info["id"] = agent_id
        info["class"] = agent_cls.__name__
        result.append(info)
    return result


def get_agent(agent_id: str) -> Optional[object]:
    """获取指定 Agent 实例"""
    _ensure_discovered()
    if agent_id not in _agent_registry:
        return None
    if agent_id not in _agent_instances:
        _agent_instances[agent_id] = _agent_registry[agent_id]()
    return _agent_instances[agent_id]


async def run_agent(agent_id: str, task: str, **kwargs) -> str:
    """运行指定 Agent"""
    agent = get_agent(agent_id)
    if agent is None:
        return f"[错误] Agent '{agent_id}' 不存在"
    logger.info(f"🤖 执行 Agent [{agent_id}]: {task[:80]}...")
    try:
        result = await agent.run(task, **kwargs)
        return result
    except Exception as e:
        logger.error(f"❌ Agent [{agent_id}] 执行失败: {e}")
        return f"[错误] Agent 执行失败: {e}"
