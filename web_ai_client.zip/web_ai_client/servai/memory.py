"""
对话记忆管理 (DB 版本)
- 基于 MySQL 存储会话与消息
- Token 估算与自动裁剪
- 支持对话摘要压缩
"""
import os
import sys
import time
import logging
from typing import Optional
from datetime import datetime

# 确保项目根路径可导入
from src.common.paths import SRC_DIR_STR
_SRC_DIR = SRC_DIR_STR
if _SRC_DIR not in sys.path:
    sys.path.insert(0, _SRC_DIR)

from peewee import fn
from src.common.mysql_utils import ClawSessions, ClawMessages, TokenUsage, db
from src.servai.config import get_memory_config

logger = logging.getLogger("claw.memory")

_config = get_memory_config()
MAX_HISTORY = _config["max_history"]
MAX_SYSTEM_TOKENS = _config["max_system_tokens"]
SUMMARY_THRESHOLD = _config["summary_threshold"]


def _estimate_tokens(text: str) -> int:
    """简易 token 估算：中文 ~1 char/token, 英文 ~4 chars/token"""
    chinese = sum(1 for c in text if '\u4e00' <= c <= '\u9fff')
    other = len(text) - chinese
    return chinese + max(1, other // 4)


# ── 会话操作 ──────────────────────────────────────────────────

def get_or_create_session(session_id: str, model_id: str = None) -> dict:
    """获取或创建会话，返回 dict"""
    try:
        sess = ClawSessions.get_or_none(ClawSessions.session_id == session_id)
        if sess is None:
            sess = ClawSessions.create(
                session_id=session_id,
                title='新对话',
                model_id=model_id,
            )
        return {
            "session_id": sess.session_id,
            "title": sess.title,
            "model_id": sess.model_id,
            "created_at": str(sess.created_at) if sess.created_at else None,
            "updated_at": str(sess.updated_at) if sess.updated_at else None,
        }
    except Exception as e:
        logger.error(f"获取/创建会话失败 {session_id}: {e}")
        return {"session_id": session_id, "title": "新对话", "model_id": None}


def update_session_title(session_id: str, title: str):
    """更新会话标题"""
    try:
        ClawSessions.update(
            title=title,
            updated_at=datetime.now()
        ).where(ClawSessions.session_id == session_id).execute()
    except Exception as e:
        logger.error(f"更新会话标题失败 {session_id}: {e}")


def get_session_model(session_id: str) -> Optional[str]:
    """获取会话绑定的模型 ID"""
    try:
        sess = ClawSessions.get_or_none(ClawSessions.session_id == session_id)
        if sess:
            return sess.model_id
    except Exception as e:
        logger.error(f"获取会话模型失败 {session_id}: {e}")
    return None


def list_sessions() -> list[dict]:
    """列出所有会话（按更新时间倒序）"""
    try:
        rows = ClawSessions.select().order_by(ClawSessions.updated_at.desc())
        return [
            {
                "id": r.session_id,
                "title": r.title,
                "model_id": r.model_id,
                "msg_count": ClawMessages.select().where(
                    ClawMessages.session_id == r.session_id
                ).count(),
            }
            for r in rows
        ]
    except Exception as e:
        logger.error(f"列出会话失败: {e}")
        return []


def save_history(session_id: str, history: list[dict]):
    """
    保存会话历史（兼容旧接口，用于创建空会话等场景）。
    新代码应直接用 add_message() 逐条添加。
    """
    try:
        ClawSessions.get_or_create(session_id=session_id, defaults={"title": "新对话"})
        # 清除旧消息
        ClawMessages.delete().where(ClawMessages.session_id == session_id).execute()
        # 批量插入
        now = datetime.now()
        rows = [
            {
                "session_id": session_id,
                "role": m["role"],
                "content": m["content"],
                "thinking": m.get("thinking"),
                "created_at": now,
            }
            for m in history
        ]
        if rows:
            ClawMessages.insert_many(rows).execute()
        # 更新会话时间
        ClawSessions.update(updated_at=now).where(
            ClawSessions.session_id == session_id
        ).execute()
    except Exception as e:
        logger.error(f"保存会话失败 {session_id}: {e}")


# ── 消息操作 ──────────────────────────────────────────────────

def get_history(session_id: str) -> list[dict]:
    """获取会话历史消息"""
    try:
        rows = ClawMessages.select().where(
            ClawMessages.session_id == session_id
        ).order_by(ClawMessages.id.asc())
        return [
            {"role": r.role, "content": r.content, "ts": r.created_at.timestamp() if r.created_at else time.time()}
            for r in rows
        ]
    except Exception as e:
        logger.error(f"获取历史失败 {session_id}: {e}")
        return []


def add_message(session_id: str, role: str, content: str, thinking: str = None):
    """添加一条消息"""
    try:
        ClawMessages.create(
            session_id=session_id,
            role=role,
            content=content,
            thinking=thinking,
        )
        # 更新会话时间 & 自动设置标题（用第一条用户消息前50字）
        ClawSessions.update(updated_at=datetime.now()).where(
            ClawSessions.session_id == session_id
        ).execute()
        # 如果是第一条用户消息，自动设标题
        if role == "user":
            sess = ClawSessions.get_or_none(ClawSessions.session_id == session_id)
            if sess and sess.title == "新对话":
                title = content[:50].replace("\n", " ").strip()
                if title:
                    ClawSessions.update(title=title).where(
                        ClawSessions.session_id == session_id
                    ).execute()
    except Exception as e:
        logger.error(f"添加消息失败 {session_id}: {e}")

    # 裁剪历史（保留最近 N 条）
    _trim_history(session_id)


def _trim_history(session_id: str):
    """裁剪历史：保留最近 N 条消息"""
    try:
        count = ClawMessages.select().where(
            ClawMessages.session_id == session_id
        ).count()
        if count > MAX_HISTORY * 2:
            # 保留最近 MAX_HISTORY 条
            # MySQL 不支持 LIMIT & IN/ANY/SOME subquery，所以分两步执行
            keep_ids = list(
                ClawMessages.select(ClawMessages.id)
                .where(ClawMessages.session_id == session_id)
                .order_by(ClawMessages.id.desc())
                .limit(MAX_HISTORY)
                .tuples()  # 返回元组列表 [(id1,), (id2,), ...]
            )
            # 提取 ID 列表
            keep_id_list = [row[0] for row in keep_ids]
            
            if keep_id_list:
                # 删除不在保留列表中的消息
                ClawMessages.delete().where(
                    ClawMessages.session_id == session_id,
                    ~ClawMessages.id.in_(keep_id_list)  # 使用 NOT IN
                ).execute()
                logger.info(f"📏 裁剪会话 {session_id}: {count} → {MAX_HISTORY}")
    except Exception as e:
        logger.error(f"裁剪历史失败 {session_id}: {e}")


def get_chat_messages(session_id: str, system_prompt: str = "") -> list[dict]:
    """获取适合发给 LLM 的消息列表"""
    history = get_history(session_id)
    messages = []
    if system_prompt:
        messages.append({"role": "system", "content": system_prompt})
    for m in history:
        if m["role"] in ("user", "assistant", "system"):
            messages.append({"role": m["role"], "content": m["content"]})
    return messages


def clear_history(session_id: str) -> bool:
    """清除会话（删除会话和所有消息），返回是否成功"""
    try:
        ClawMessages.delete().where(ClawMessages.session_id == session_id).execute()
        ClawSessions.delete().where(ClawSessions.session_id == session_id).execute()
        logger.info(f"🗑️ 已删除会话: {session_id}")
        return True
    except Exception as e:
        logger.error(f"删除会话失败 {session_id}: {e}")
        return False


def summarize_history(session_id: str) -> Optional[str]:
    """生成历史摘要（占位）"""
    history = get_history(session_id)
    if len(history) < SUMMARY_THRESHOLD:
        return None
    return None


# ── Token 统计 ──────────────────────────────────────────────────

# 自动创建表（如果不存在）
try:
    db.create_tables([TokenUsage], safe=True)
    logger.info("✅ token_usage 表已就绪")
except Exception as e:
    logger.warning(f"创建 token_usage 表失败: {e}")


def add_token_usage(session_id: str, engine_name: str, prompt_tokens: int, completion_tokens: int, total_tokens: int):
    """记录一次对话的 token 使用量"""
    try:
        TokenUsage.create(
            session_id=session_id,
            engine_name=engine_name,
            prompt_tokens=prompt_tokens,
            completion_tokens=completion_tokens,
            total_tokens=total_tokens,
        )
        logger.debug(f"✅ Token 使用量已记录: {engine_name} prompt={prompt_tokens}, completion={completion_tokens}")
    except Exception as e:
        logger.error(f"记录 token 使用量失败: {e}")


def get_token_stats(days: int = 7) -> dict:
    """获取最近 N 天的 token 统计"""
    from datetime import timedelta
    
    end_date = datetime.now()
    start_date = end_date - timedelta(days=days)
    
    # 总计
    total_prompt = TokenUsage.select(fn.SUM(TokenUsage.prompt_tokens)).where(
        TokenUsage.created_at >= start_date
    ).scalar() or 0
    
    total_completion = TokenUsage.select(fn.SUM(TokenUsage.completion_tokens)).where(
        TokenUsage.created_at >= start_date
    ).scalar() or 0
    
    total_all = TokenUsage.select(fn.SUM(TokenUsage.total_tokens)).where(
        TokenUsage.created_at >= start_date
    ).scalar() or 0
    
    # 按引擎分组
    by_engine = {}
    for row in TokenUsage.select(
        TokenUsage.engine_name,
        fn.SUM(TokenUsage.total_tokens).alias('sum_tokens')
    ).where(
        TokenUsage.created_at >= start_date
    ).group_by(TokenUsage.engine_name):
        by_engine[row.engine_name] = row.sum_tokens
    
    return {
        "period_days": days,
        "total_prompt_tokens": int(total_prompt),
        "total_completion_tokens": int(total_completion),
        "total_tokens": int(total_all),
        "by_engine": by_engine,
    }


def reset_token_stats():
    """清空所有 token 统计"""
    TokenUsage.delete().execute()
    logger.info("✅ Token 统计已清空")
