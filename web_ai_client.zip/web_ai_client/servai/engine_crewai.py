"""
CrewAI 引擎 — 多Agent协作（骨架实现）
适合需要多角色协作的复杂任务

依赖: pip install crewai

注意: 当前为骨架实现
      待 crewai 依赖安装后可启用完整多Agent协作功能
"""
import json
import logging
from typing import AsyncGenerator

from .base import BaseEngine
from .memory import get_chat_messages, add_message, add_token_usage, _estimate_tokens
from src.servai.config import get_ollama_config

logger = logging.getLogger("claw.engine.crewai")

SYSTEM_PROMPT = """你是龙虾，一个有工具调用能力的AI助手。
回复风格：简洁、专业、中文。"""


class CrewAIEngine(BaseEngine):
    """CrewAI 多Agent协作引擎"""

    def _build_crew(self, task_description: str):
        """
        根据任务动态构建 Crew

        当前默认配置:
        - 研究员 Agent: 收集和分析信息
        - 回复助手 Agent: 基于研究结果生成回复
        """
        try:
            from crewai import Agent, Task, Crew, Process
            from crewai.llm import LLM
        except ImportError:
            return None

        llm_config = get_ollama_config()

        # 构建 LLM（使用 Ollama）
        # CrewAI 支持多种 provider，Ollama 使用 'ollama' provider
        llm = LLM(
            model=f"ollama/{llm_config['model']}",  # ollama/ 前缀表示使用 Ollama provider
            base_url=llm_config["base_url"].replace('/v1', ''),  # Ollama 不需要 /v1 后缀
        )

        researcher = Agent(
            role="研究员",
            goal="收集和分析相关信息",
            backstory="你是一个专业的信息收集和分析专家，擅长从各种数据源提取关键信息。",
            verbose=False,
            llm=llm,  # 指定 LLM
        )

        responder = Agent(
            role="回复助手",
            goal="基于研究结果给出简洁专业的回复",
            backstory="你是一个善于总结的沟通专家，能将复杂信息转化为简洁易懂的回复。",
            verbose=False,
            llm=llm,  # 指定 LLM
        )

        research_task = Task(
            description=task_description,
            expected_output="详细的研究结果和分析",
            agent=researcher,
        )

        response_task = Task(
            description="基于研究结果，用简洁专业的中文回复用户",
            expected_output="简洁的中文回复",
            agent=responder,
        )

        return Crew(
            agents=[researcher, responder],
            tasks=[research_task, response_task],
            process=Process.sequential,
            verbose=False,
        )

    async def chat_stream(
        self,
        session_id: str,
        user_message: str,
        enable_tools: bool = True,
    ) -> AsyncGenerator[dict, None]:
        try:
            # 检查依赖
            try:
                import crewai  # noqa: F401
            except ImportError:
                yield {"type": "error", "content": "CrewAI 依赖未安装，请执行: pip install crewai"}
                yield {"type": "done"}
                return

            add_message(session_id, "user", user_message)

            yield {"type": "delta", "content": "🤔 正在组织多Agent协作...\n"}

            # 构建并执行 Crew
            crew = self._build_crew(user_message)
            if crew is None:
                yield {"type": "error", "content": "Crew 构建失败"}
                yield {"type": "done"}
                return

            import asyncio
            loop = asyncio.get_event_loop()
            result = await loop.run_in_executor(None, lambda: crew.kickoff())

            reply = str(result)
            yield {"type": "delta", "content": reply}

            # 保存回复
            if reply:
                add_message(session_id, "assistant", reply)

            # CrewAI 不直接暴露 usage，使用估算
            # 尝试从 result 获取 usage（某些版本支持）
            prompt_tokens = 0
            completion_tokens = 0
            
            if hasattr(result, 'usage') and result.usage:
                # CrewAI 新版本可能支持
                try:
                    prompt_tokens = result.usage.get('prompt_tokens', 0) or 0
                    completion_tokens = result.usage.get('completion_tokens', 0) or 0
                except Exception:
                    pass
            
            # 如果没有 usage 信息，使用估算
            if prompt_tokens == 0 and completion_tokens == 0:
                prompt_tokens = _estimate_tokens(user_message)
                completion_tokens = _estimate_tokens(reply)
                logger.debug(f"[crewai] Token 使用估算值: prompt={prompt_tokens}, completion={completion_tokens}")
            
            if prompt_tokens > 0 or completion_tokens > 0:
                add_token_usage(
                    session_id=session_id,
                    engine_name="crewai",
                    prompt_tokens=prompt_tokens,
                    completion_tokens=completion_tokens,
                    total_tokens=prompt_tokens + completion_tokens,
                )
                logger.info(f"[crewai] Token: prompt={prompt_tokens}, completion={completion_tokens}")

            yield {"type": "done"}

        except Exception as e:
            logger.error(f"CrewAI 引擎错误: {e}")
            yield {"type": "error", "content": str(e)}
