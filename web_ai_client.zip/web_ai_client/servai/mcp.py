﻿"""
MCP 管理器
负责 MCP 实例的生命周期管理（启停子进程）、工具发现、调用路由
"""
import os
import sys
import json
import logging
import asyncio
from typing import Optional

from src.servai.mcp_client import McpClient

logger = logging.getLogger("claw.mcp_manager")

# 项目根路径
from src.common.paths import PROJECT_ROOT_STR
_PROJECT_ROOT = PROJECT_ROOT_STR

# ── MCP 工具定义 → OpenAI function calling 格式转换 ────────────

def _mcp_tool_to_openai(tool) -> dict:
    """将 MCP Tool 对象转为 OpenAI function calling 工具定义"""
    return {
        "type": "function",
        "function": {
            "name": tool.name,
            "description": tool.description or "",
            "parameters": tool.inputSchema if tool.inputSchema else {"type": "object", "properties": {}},
        },
    }


# ── MCP 实例自动发现 ──────────────────────────────────────────

def _discover_instances() -> dict:
    """
    扫描 extensions/mcps/ 下所有子包，收集带有 MCP_CONFIG 的实例

    返回: {instance_id: {id, name, description, server_module}}
    """
    import importlib
    import pkgutil
    import src.servai.mcps as mcps_pkg

    registry = {}

    for loader, name, is_pkg in pkgutil.iter_modules(mcps_pkg.__path__):
        if not is_pkg:
            continue

        try:
            mod = importlib.import_module(f"src.servai.mcps.{name}")
            config = getattr(mod, "MCP_CONFIG", None)
            if config and isinstance(config, dict) and "id" in config:
                instance_id = config["id"]
                if config.get("enabled", True) is False:
                    logger.info("⏸️ 跳过已禁用的 MCP 实例: %s", instance_id)
                    continue
                config["server_module"] = f"src.servai.mcps.{name}.server"
                registry[instance_id] = config
                logger.info("📦 发现 MCP 实例: %s → %s", instance_id, config["server_module"])
        except Exception as e:
            logger.warning("⚠️ 跳过 MCP 包 '%s': %s", name, e)

    return registry


# ── McpManager ─────────────────────────────────────────────────

class McpManager:
    """
    MCP 实例管理器（应用级单例）

    用法:
        manager = McpManager.get_instance()
        await manager.start_all()                       # 启动所有 MCP 实例
        tools = manager.get_tool_definitions()           # 获取 OpenAI 格式工具列表
        result = await manager.execute_tool("list_symbols", {})  # 调用工具
        await manager.stop_all()                         # 停止所有
    """

    _instance: Optional["McpManager"] = None

    def __init__(self):
        self._clients: dict[str, McpClient] = {}          # instance_id → McpClient
        self._tool_defs: list[dict] = []                  # OpenAI 格式工具缓存
        self._tool_routing: dict[str, str] = {}           # tool_name → instance_id
        self._instances_meta: dict[str, dict] = {}        # 实例元信息

    # ── 单例 ───────────────────────────────────────────────

    @classmethod
    def get_instance(cls) -> "McpManager":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    # ── 启停 ───────────────────────────────────────────────

    async def start_all(self):
        """扫描并启动所有 MCP 实例"""
        self._instances_meta = _discover_instances()

        if not self._instances_meta:
            logger.info("📡 无 MCP 实例需要启动")
            return

        # 并行启动所有实例
        tasks = []
        for instance_id in self._instances_meta:
            tasks.append(self._start_one(instance_id))

        results = await asyncio.gather(*tasks, return_exceptions=True)

        for instance_id, result in zip(self._instances_meta.keys(), results):
            if isinstance(result, Exception):
                logger.error("❌ [%s] 启动失败: %s", instance_id, result)

        logger.info("✅ MCP 管理就绪: %d/%d 实例运行中",
                     sum(1 for c in self._clients.values() if c.is_connected),
                     len(self._instances_meta))

    async def _start_one(self, instance_id: str):
        """启动单个 MCP 实例并发现工具"""
        meta = self._instances_meta[instance_id]
        server_module = meta["server_module"]

        client = McpClient(instance_id, server_module, project_root=_PROJECT_ROOT)
        try:
            mcp_tools = await asyncio.wait_for(client.connect(), timeout=30.0)
        except asyncio.TimeoutError:
            logger.error("❌ [%s] 连接超时 (30s)", instance_id)
            await client.disconnect()
            return
        except Exception as e:
            logger.error("❌ [%s] 连接失败: %s", instance_id, e)
            await client.disconnect()
            return

        # 缓存客户端和工具定义
        self._clients[instance_id] = client

        for t in mcp_tools:
            openai_def = _mcp_tool_to_openai(t)
            self._tool_defs.append(openai_def)
            self._tool_routing[t.name] = instance_id

        logger.info("✅ [%s] 已启动, 注册 %d 个工具", instance_id, len(mcp_tools))

    async def stop_all(self):
        """停止所有 MCP 实例"""
        for instance_id, client in list(self._clients.items()):
            try:
                await client.disconnect()
            except Exception as e:
                logger.warning("[%s] 关闭异常: %s", instance_id, e)

        self._clients.clear()
        self._tool_defs.clear()
        self._tool_routing.clear()
        logger.info("🛑 所有 MCP 实例已停止")

    # ── 工具定义 ────────────────────────────────────────────

    def get_tool_definitions(self) -> list[dict]:
        """获取所有 MCP 工具定义（OpenAI function calling 格式）"""
        return self._tool_defs

    # ── 工具调用 ────────────────────────────────────────────

    async def execute_tool(self, tool_name: str, arguments: dict) -> str:
        """
        将工具调用路由到对应的 MCP 实例并执行

        返回: 工具执行结果字符串
        """
        instance_id = self._tool_routing.get(tool_name)
        if instance_id is None:
            return f"[MCP错误] 未知工具: {tool_name}"

        client = self._clients.get(instance_id)
        if client is None or not client.is_connected:
            return f"[MCP错误] 实例 '{instance_id}' 未连接"

        try:
            result = await client.call_tool(tool_name, arguments)
            logger.info("🔧 [%s] %s(%s) → %d chars", instance_id, tool_name, arguments, len(result))
            return result
        except Exception as e:
            logger.error("❌ [%s] %s 执行失败: %s", instance_id, tool_name, e)
            return f"[MCP错误] 工具执行失败: {e}"

    def has_tool(self, tool_name: str) -> bool:
        """检查工具是否由 MCP 提供"""
        return tool_name in self._tool_routing

    # ── 状态 ────────────────────────────────────────────────

    def get_status(self) -> list[dict]:
        """获取所有 MCP 实例状态"""
        result = []
        for instance_id, meta in self._instances_meta.items():
            client = self._clients.get(instance_id)
            tool_names = [name for name, iid in self._tool_routing.items() if iid == instance_id]
            result.append({
                "id": instance_id,
                "name": meta.get("name", instance_id),
                "description": meta.get("description", ""),
                "status": "running" if (client and client.is_connected) else "stopped",
                "tool_count": len(tool_names),
                "tools": tool_names,
            })
        return result
