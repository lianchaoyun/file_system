/**
 * ================================================================
 * 侧边栏菜单配置
 * ================================================================
 */

(function () {
    'use strict';

    window.MENU_CONFIG = {
        /** 主导航菜单项 */
        items: [
            { id: 'chat',       label: '聊天', icon: 'fa-regular fa-comment-dots' },
            { id: 'extensions', label: '扩展', icon: 'fa-solid fa-puzzle-piece' },
            { id: 'task',       label: '任务', icon: 'fa-regular fa-clock' },
        ],

        /** 根据 id 获取菜单项标签 */
        getLabel: function (id) {
            if (id === 'settings') return '底部设置';
            var found = this.items.find(function (item) { return item.id === id; });
            return found ? found.label : '';
        }
    };
})();
