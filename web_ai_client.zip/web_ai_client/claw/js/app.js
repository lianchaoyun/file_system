(function () {
    'use strict';

    function initApp() {
        // 登录检查：未登录跳转 yunhub
        var userStr = localStorage.getItem('user');
        if (!userStr) {
            window.location.href = '/apps/yunhub/login.html?redirect=/apps/claw/';
            return;
        }
        var user;
        try {
            user = JSON.parse(userStr);
        } catch (e) {
            localStorage.removeItem('user');
            window.location.href = '/apps/yunhub/login.html?redirect=/apps/claw/';
            return;
        }
        if (!user.token) {
            localStorage.removeItem('user');
            window.location.href = '/apps/yunhub/login.html?redirect=/apps/claw/';
            return;
        }

        if (typeof Vue === 'undefined') {
            document.getElementById('app').innerHTML =
                '<div style="padding:40px;text-align:center;color:#ff6b6b;">' +
                '<h3>Vue 3 加载失败</h3><p>请检查网络连接</p></div>';
            return;
        }

        if (!window.renderMarkdown) {
            window.renderMarkdown = function (c) { return c || ''; };
        }
        if (!window.MENU_CONFIG) {
            window.MENU_CONFIG = { items: [], financialTabs: [], getLabel: function () { return ''; } };
        }

        const { createApp } = Vue;
        const store = window.ClawStore;

        const app = createApp({
            setup() {
                store.init();

                return { store };
            }
        });

        // 注册组件
        var comps = window.ClawComponents;
        if (comps) {
            if (comps.Sidebar)     app.component('claw-sidebar', comps.Sidebar);
            if (comps.ChatPanel)   app.component('claw-chat', comps.ChatPanel);
            if (comps.SettingsPanel) app.component('claw-settings', comps.SettingsPanel);
            if (comps.ExtensionsPanel) app.component('claw-extensions', comps.ExtensionsPanel);
            if (comps.Placeholder) app.component('claw-placeholder', comps.Placeholder);
            if (comps.TaskPage)    app.component('claw-task-page', comps.TaskPage);
        }

        try {
            app.mount('#app');
            console.log('[app] 龙虾 v3 已启动 ✓');
        } catch (err) {
            console.error('[app] 挂载失败:', err);
            document.getElementById('app').innerHTML =
                '<div style="padding:40px;text-align:center;color:#ff6b6b;">' +
                '<h3>应用挂载失败</h3><pre>' + err.message + '</pre></div>';
        }
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function () { setTimeout(initApp, 0); });
    } else {
        setTimeout(initApp, 0);
    }

})();
