/**
 * ================================================================
 * Markdown 渲染引擎 —— Marked 12+ 兼容版
 * ================================================================
 * 依赖: marked.js, highlight.js (通过 CDN 全局引入)
 */

(function () {
    'use strict';

    if (typeof marked === 'undefined') {
        console.warn('[renderer] marked 尚未加载，渲染引擎暂停初始化');
        return;
    }

    // ── Marked v12 实例化 (兼容新旧 API) ──
    let md;
    try {
        if (typeof marked.Marked === 'function') {
            md = new marked.Marked({
                gfm: true,
                breaks: true,
                pedantic: false,
                renderer: buildRenderer()
            });

        } else {
            // 回退到旧 API (v12 仍兼容)
            md = {
                parse: function (src) { return marked.parse(src); }
            };
            marked.setOptions({
                gfm: true,
                breaks: true,
                pedantic: false,
                renderer: buildRenderer()
            });
        }
    } catch (e) {
        console.warn('[renderer] marked 初始化异常，使用纯文本降级:', e, e.stack);
        window.renderMarkdown = function (c) { return (c || '').replace(/\n/g, '<br>'); };
        return;
    }

    function buildRenderer() {
        const r = new marked.Renderer();

        r.code = function (obj) {
            let code = '', lang = '';
            if (typeof obj === 'string') {
                code = obj;
                lang = '';
            } else if (obj && typeof obj === 'object') {
                code = obj.text || obj.code || '';
                lang = (obj.lang || '').trim();
            }

            let highlighted, autoResult;
            if (typeof hljs !== 'undefined') {
                // 如果 lang 为空或 hljs 不认识，用 highlightAuto 自动检测
                var useLang = lang && hljs.getLanguage(lang) ? lang : undefined;
                try {
                    if (useLang) {
                        highlighted = hljs.highlight(code, { language: useLang, ignoreIllegals: true }).value;
                    } else {
                        autoResult = hljs.highlightAuto(code);
                        highlighted = autoResult.value;
                    }
                } catch (e) {
                    console.warn('[renderer] hljs 高亮失败 lang=' + lang + ':', e.message);
                    autoResult = hljs.highlightAuto(code);
                    highlighted = autoResult.value;
                }
            } else {
                highlighted = code.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
            }

            // 用 hidden placeholder 标记语言，后续后处理组装 header bar
            var displayLang = lang || (autoResult && autoResult.relevance > 2 ? autoResult.language : '') || '';
            var codeClass = displayLang || (autoResult && autoResult.language) || '';
            var langMarker = displayLang ? ' data-lang="' + displayLang + '"' : '';

            return '<pre class="hljs"' + langMarker + '><code class="language-' + codeClass + '">' + highlighted + '</code></pre>';
        };

        // 链接：新窗口打开 + 安全属性
        r.link = function (obj) {
            var href = (obj && obj.href) ? obj.href : '';
            var title = (obj && obj.title) ? obj.title : '';
            var text = (obj && obj.text) ? obj.text : '';
            var titleAttr = title ? ' title="' + title + '"' : '';
            return '<a href="' + href + '" target="_blank" rel="noopener noreferrer"' + titleAttr + '>' + text + '</a>';
        };

        return r;
    }

    // ── LLM 输出格式预处理 ──
    function sanitizeMarkdown(text) {
        if (!text || typeof text !== 'string') return text;

        // 先保护代码块，只对代码块外的内容做修正，避免误伤代码内容
        var codeBlocks = [];
        var placeholder = '%%CB' + Date.now() + '_';
        var idx = 0;

        // 提取所有 fenced code blocks
        text = text.replace(/(```[\s\S]*?```)/g, function(match) {
            codeBlocks.push(match);
            return placeholder + (idx++) + '%%';
        });

        // ── 对非代码块部分做格式修正 ──

        // 1. --- 水平线后紧跟非横线字符时插入空行: ---### → ---\n\n###
        text = text.replace(/---([^\n\-])/g, '---\n\n$1');
        text = text.replace(/---(-+)/g, '---');

        // 2. 标题行后无空格: ###标题 → ### 标题
        text = text.replace(/^([ \t]*#{1,6})([^\s#\n])/gm, '$1 $2');

        // 3. 标题前缺失换行：仅匹配 ##~######（不含单 # 避免 C# 误伤）
        text = text.replace(/([^\n#])(#{2,6})([^\s#\n])/g, '$1\n\n$2 $3');

        // 4. 列表项前确保有换行
        text = text.replace(/([^\n\-\d])(\d+\.\s)/g, '$1\n$2');
        text = text.replace(/([^\n\-*])([-*]\s)/g, '$1\n$2');

        // 5. 清理连续 3 个以上的空行
        text = text.replace(/\n{4,}/g, '\n\n\n');

        // ── 还原代码块，并修正代码块内外粘连 ──
        for (var i = 0; i < codeBlocks.length; i++) {
            var key = placeholder + i + '%%';
            var replacement = codeBlocks[i];

            // 跳过纯空白/空代码块（LLM 可能输出 ```  ``` 这类空壳）
            var inner = replacement.replace(/```[\s\S]*?```/, function(m) {
                return m.replace(/^```\w*\n?/, '').replace(/\n?```$/, '');
            });
            if (inner.trim() === '') {
                text = text.replace(key, '');
                continue;
            }

            // 修正代码块内部：开标记后换行、闭标记前换行
            replacement = replacement.replace(/^(```\w*)([^\n])/gm, '$1\n$2');
            replacement = replacement.replace(/([^\n`])(```)$/gm, '$1\n$2');

            // 修复流式截断的语言标签: ```bas\nh\n... → ```bash\n...
            if (typeof hljs !== 'undefined') {
                replacement = replacement.replace(/^```(\w+)\n(.)\n/gm, function(m, partial, nextChar) {
                    var candidate = partial + nextChar;
                    if (hljs.getLanguage(candidate)) {
                        return '```' + candidate + '\n';
                    }
                    return m;
                });
            }

            // 确保代码块前后有空行，避免和列表项/段落粘连导致错位
            replacement = '\n\n' + replacement.trim() + '\n\n';

            text = text.replace(key, replacement);
        }

        return text;
    }

    // ── 挂载到全局 ──
    window.renderMarkdown = function (content) {
        if (!content) return '';
        try {
            var sanitized = sanitizeMarkdown(content);
            var result = md.parse(sanitized);
            // marked v12 可能返回 Promise
            if (result instanceof Promise) {
                console.error('[renderer] ⚠️ parse 返回了 Promise！');
                return content;
            }
            if (typeof result !== 'string') return content;

            // 后处理：给 hljs 代码块加 header bar（语言名 + 复制按钮）
            result = result.replace(
                /<pre class="hljs"( data-lang="([^"]*)")?><code class="language-([^"]*)">([\s\S]*?)<\/code><\/pre>/g,
                function (m, dataAttr, lang, langClass, codeContent) {
                    var langName = lang || langClass || '';
                    // 无语言标识：不套 wrapper，保持简洁
                    if (!lang) {
                        return '<pre class="hljs"><code class="language-' + langName + '">' +
                            codeContent + '</code></pre>';
                    }
                    // 有语言标识：套 wrapper + header bar + 复制按钮
                    var header = '<div class="code-block-header">' +
                        '<span class="code-lang-name">' + lang + '</span>' +
                        '<button class="code-copy-btn" onclick="window.copyCodeBlock(this)" title="复制代码">' +
                            '<i class="fa-solid fa-copy"></i><span>复制</span>' +
                        '</button>' +
                    '</div>';
                    return '<div class="code-block-wrapper">' + header +
                        '<pre class="hljs"><code class="language-' + langName + '">' +
                        codeContent + '</code></pre></div>';
                }
            );

            return result;
        } catch (err) {
            console.error('[renderer] 渲染抛异常:', err.message);
            return (content || '').replace(/\n/g, '<br>');
        }
    };

    // ── 代码块复制功能 ──
    window.copyCodeBlock = function (btn) {
        var wrapper = btn.closest('.code-block-wrapper');
        if (!wrapper) return;
        var codeEl = wrapper.querySelector('pre code');
        if (!codeEl) return;
        var text = codeEl.textContent || codeEl.innerText || '';

        navigator.clipboard.writeText(text).then(function () {
            var span = btn.querySelector('span');
            var original = span.textContent;
            span.textContent = '已复制';
            btn.classList.add('copied');
            setTimeout(function () {
                span.textContent = original;
                btn.classList.remove('copied');
            }, 2000);
        }).catch(function () {
            // 降级方案：创建临时 textarea
            var ta = document.createElement('textarea');
            ta.value = text;
            ta.style.position = 'fixed';
            ta.style.opacity = '0';
            document.body.appendChild(ta);
            ta.select();
            document.execCommand('copy');
            document.body.removeChild(ta);
        });
    };

})();
