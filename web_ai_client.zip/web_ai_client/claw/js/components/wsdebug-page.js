/**
 * ================================================================
 * 调试页面 —— 独立全页面组件 (占满内容区)
 * ================================================================
 * WebSocket / 命令行调试工具，作为独立的左侧 tab 页面
 */
(function () {
    'use strict';

    var { ref, nextTick } = Vue;

    window.ClawComponents = window.ClawComponents || {};
    window.ClawComponents.WSDebugPage = {
        name: 'WSDebugPage',
        template: /*html*/`
<div class="wsdebug-page">
    <div class="wsdebug-page-inner">
        <!-- Tab 栏 -->
        <div class="wsdebug-tabs">
            <button v-for="(cfg, id) in wsTargets" :key="id" class="wsdebug-tab" :class="{ active: wsActiveTab === id }" @click="switchWsTab(id)">{{ cfg.label }}</button>
        </div>

        <!-- 状态栏 -->
        <div class="wsdebug-statusbar">
            <span class="wsdebug-dot" :class="{ connected: wsConnected }"></span>
            <span class="wsdebug-status-label">{{ wsConnected ? '已连接' : '未连接' }}</span>
            <span class="wsdebug-tab-badge">{{ wsTargets[wsActiveTab].label }}</span>
            <input class="wsdebug-url" v-model="wsUrl" :placeholder="wsTargets[wsActiveTab].defaultUrl" spellcheck="false" />
            <button v-if="!wsConnected" class="wsdebug-btn-connect" @click="wsToggleConnection">连接</button>
            <button v-else class="wsdebug-btn-disconnect" @click="wsToggleConnection">断开</button>
        </div>

        <!-- 快捷命令 -->
        <div class="wsdebug-quick">
            <button v-for="(entry, i) in wsTargets[wsActiveTab].quickCmds" :key="i" class="wsdebug-quick-btn" @click="sendWsQuickCmd(entry)">{{ entry.label }}</button>
        </div>

        <!-- 输出区 -->
        <div class="wsdebug-output" ref="wsOutputEl">
            <div v-if="wsLogs.length === 0" class="wsdebug-empty">暂无消息</div>
            <div v-for="(log, i) in wsLogs" :key="i" class="wsdebug-msg" :class="log.cls">
                <span class="wsdebug-log-tab">[{{ log.tab }}]</span>
                [{{ log.time }}] {{ log.text }}
            </div>
        </div>

        <!-- 底部工具栏 -->
        <div class="wsdebug-toolbar">
            <label class="wsdebug-autoscroll">
                <input type="checkbox" v-model="wsAutoScroll" />
                <span>自动滚动</span>
            </label>
            <button class="wsdebug-tool-btn" @click="wsLogs = []">清空</button>
        </div>

        <!-- 输入行 -->
        <div class="wsdebug-inputrow">
            <textarea ref="wsCmdTextarea" class="wsdebug-cmdinput" v-model="wsCmdInput" :placeholder="wsTargets[wsActiveTab].placeholder" rows="1" @input="autoResizeWs" @keydown="onWsKeydown"></textarea>
            <button class="wsdebug-btn-send" @click="wsSendRaw" :disabled="!wsConnected">发送</button>
        </div>
    </div>
</div>`,
        setup: function () {
            // ═══ WebSocket 状态 ═══
            var wsActiveTab = ref(localStorage.getItem('claw_debugTab') || 'web');
            Vue.watch(wsActiveTab, function (val) {
                localStorage.setItem('claw_debugTab', val);
            });
            var wsProtocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
            var wsUrl = ref(wsProtocol + '//' + window.location.host + '/ws/cmd');
            var wsCmdInput = ref('');
            var wsLogs = ref([]);
            var wsConnected = ref(false);
            var wsAutoScroll = ref(true);
            var wsSocket = null;
            var wsOutputEl = ref(null);
            var wsCmdTextarea = ref(null);

            var wsTargets = {
                web: {
                    label: 'Web 服务',
                    defaultUrl: wsProtocol + '//' + window.location.host + '/ws/cmd',
                    placeholder: '{"cmd":"ping","args":[]}',
                    quickCmds: [
                        { label: 'ping', cmd: 'ping' }, { label: 'echo', cmd: 'echo', args: ['Hello'] },
                        { label: 'time', cmd: 'time' }, { label: 'exec:dir', cmd: 'exec', args: ['dir'] },
                        { label: 'exec:echo', cmd: 'exec', args: ['echo', '%USERNAME%'] },
                    ],
                },
                market: {
                    label: '行情数据',
                    defaultUrl: 'ws://127.0.0.1:6968',
                    placeholder: '{"cmd":"subscribe_kline","symbols":["btcusdt"],"intervals":["1m"]}',
                    quickCmds: [
                        { label: 'K线 BTC 1m', cmd: 'subscribe_kline', payload: { symbols: ['btcusdt'], intervals: ['1m'] } },
                        { label: 'K线 BTC 5m', cmd: 'subscribe_kline', payload: { symbols: ['btcusdt'], intervals: ['5m'] } },
                        { label: '历史 BTC 1m', cmd: 'fetch_history', payload: { symbols: ['btcusdt'], interval: '1m', limit: 10 } },
                        { label: 'Tick BTC', cmd: 'subscribe_tick', payload: { symbols: ['btcusdt'] } },
                        { label: '取消 BTC 1m', cmd: 'unsubscribe', payload: { keys: ['kline:btcusdt:1m'] } },
                    ],
                },
            };

            function addWsLog(msg, cls) {
                var label = wsTargets[wsActiveTab.value].label;
                wsLogs.value.push({ time: new Date().toLocaleTimeString(), text: msg, cls: cls, tab: label });
            }
            function scrollWsBottom() {
                nextTick(function () {
                    if (wsAutoScroll.value && wsOutputEl.value)
                        wsOutputEl.value.scrollTop = wsOutputEl.value.scrollHeight;
                });
            }
            function wsConnect() {
                var url = wsUrl.value.trim();
                if (!url) return;
                addWsLog('正在连接 ' + url + ' ...', 'system');
                try {
                    wsSocket = new WebSocket(url);
                    wsSocket.onopen = function () { addWsLog('连接成功', 'system'); wsConnected.value = true; };
                    wsSocket.onmessage = function (e) {
                        try {
                            var data = JSON.parse(e.data);
                            if (data.type === 'kline') {
                                var d = data.data || {};
                                addWsLog('← K线' + (data.interval ? ' [' + data.interval + ']' : '') + ' | ' + data.symbol + ' | o=' + d.open + ' h=' + d.high + ' l=' + d.low + ' c=' + d.close + ' v=' + d.volume, 'recv push');
                            } else if (data.type === 'tick') {
                                var td = data.data || {};
                                addWsLog('← Tick | ' + data.symbol + ' | price=' + td.price + ' v=' + td.volume, 'recv push');
                            } else if (data.type === 'history') {
                                var cnt = 0;
                                var keys = Object.keys(data.data || {});
                                keys.forEach(function (k) { cnt += (data.data[k] || []).length; });
                                addWsLog('← 历史数据 ' + data.interval + ' | ' + keys.join(',') + ' 共 ' + cnt + ' 条', 'recv');
                            } else {
                                addWsLog('← ' + JSON.stringify(data), 'recv');
                            }
                        } catch (err) { addWsLog('← ' + e.data, 'recv'); }
                        scrollWsBottom();
                    };
                    wsSocket.onerror = function () { addWsLog('连接错误', 'system error'); };
                    wsSocket.onclose = function () { addWsLog('连接已关闭', 'system'); wsConnected.value = false; wsSocket = null; };
                } catch (err) { addWsLog('连接失败: ' + err.message, 'system error'); }
            }
            function wsDisconnect() { if (wsSocket) { wsSocket.close(); wsSocket = null; } }
            function wsToggleConnection() { if (wsSocket && wsSocket.readyState === WebSocket.OPEN) wsDisconnect(); else wsConnect(); }
            function wsSendRaw() {
                var text = wsCmdInput.value.trim();
                if (!text) return;
                if (!wsSocket || wsSocket.readyState !== WebSocket.OPEN) { addWsLog('未连接', 'system error'); return; }
                addWsLog('→ ' + text, 'sent');
                wsSocket.send(text);
                wsCmdInput.value = '';
                scrollWsBottom();
            }
            function sendWsQuickCmd(entry) {
                if (wsActiveTab.value === 'market') {
                    var req = { cmd: entry.cmd };
                    Object.keys(entry.payload || {}).forEach(function (k) { req[k] = entry.payload[k]; });
                    wsCmdInput.value = JSON.stringify(req);
                } else {
                    wsCmdInput.value = JSON.stringify({ cmd: entry.cmd, args: entry.args || [] });
                }
                wsSendRaw();
            }
            function switchWsTab(tabId) {
                if (wsActiveTab.value === tabId) return;
                wsDisconnect();
                wsActiveTab.value = tabId;
                wsUrl.value = wsTargets[tabId].defaultUrl;
                addWsLog('—— 切换到 [' + wsTargets[tabId].label + '] ——', 'system');
            }
            function autoResizeWs() {
                if (wsCmdTextarea.value) {
                    wsCmdTextarea.value.style.height = 'auto';
                    wsCmdTextarea.value.style.height = wsCmdTextarea.value.scrollHeight + 'px';
                }
            }
            function onWsKeydown(e) {
                if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    wsSendRaw();
                    nextTick(function () { if (wsCmdTextarea.value) wsCmdTextarea.value.style.height = 'auto'; });
                }
            }

            return {
                wsActiveTab, wsUrl, wsCmdInput, wsLogs, wsConnected, wsAutoScroll,
                wsOutputEl, wsCmdTextarea, wsTargets,
                wsToggleConnection, sendWsQuickCmd, wsSendRaw, switchWsTab,
                autoResizeWs, onWsKeydown,
            };
        }
    };

    console.log('[wsdebug-page] 调试页面组件已就绪 ✓');
})();
