/**
 * Agent 面板 —— 展示所有 Agent 并支持执行任务
 */
(function () {
    'use strict';

    window.ClawComponents = window.ClawComponents || {};
    window.ClawComponents.AgentPanel = {
        template: /* html */`
<div class="settings-panel">
    <div class="settings-container">
        <h2 class="settings-title"><i class="fa-solid fa-user-astronaut"></i> Agent 代理</h2>
        <p class="settings-desc">自动化任务代理，可执行多步骤任务。点击运行按钮触发。</p>

        <!-- 加载中 -->
        <div v-if="s.agentsLoading" class="model-empty">
            <i class="fa-solid fa-spinner fa-spin"></i> 加载中...
        </div>

        <!-- 无 Agent -->
        <div v-else-if="s.agents.length === 0" class="model-empty">
            <p><i class="fa-solid fa-circle-exclamation" style="color:var(--text-dim);"></i></p>
            <p>暂无已注册 Agent</p>
            <p style="font-size:12px;margin-top:4px;">在 extensions/agents/ 下添加 Agent 子包即可自动发现</p>
        </div>

        <!-- Agent 卡片列表 -->
        <div v-else class="model-list">
            <div
                v-for="agent in s.agents"
                :key="agent.id"
                class="model-card"
            >
                <div class="model-card-header">
                    <span class="model-card-name">
                        <i :class="agent.icon" style="margin-right:8px;color:var(--accent);"></i>
                        {{ agent.name }}
                    </span>
                    <span style="font-size:11px;color:var(--text-dim);">
                        {{ agent.class }}
                    </span>
                </div>
                <div class="model-card-body">
                    <div class="model-card-field" style="flex:1;min-width:100%;">
                        <label>描述</label>
                        <span>{{ agent.description }}</span>
                    </div>
                    <div class="model-card-field" v-if="agent.tools && agent.tools.length">
                        <label>可用工具</label>
                        <span style="font-family:'Fira Code',Consolas,monospace;font-size:11px;">
                            {{ agent.tools.join(', ') }}
                        </span>
                    </div>
                </div>
                <div class="model-card-actions">
                    <button
                        class="btn btn-primary btn-sm"
                        @click="openRunDialog(agent)"
                        :disabled="s.agentRunning === agent.id"
                    >
                        <i :class="['fa-solid', s.agentRunning === agent.id ? 'fa-spinner fa-spin' : 'fa-play']"></i>
                        {{ s.agentRunning === agent.id ? '执行中...' : '运行' }}
                    </button>
                </div>

                <!-- 运行结果 -->
                <div v-if="s.agentResult && s.activeAgentId === agent.id" class="agent-result">
                    <pre>{{ s.agentResult }}</pre>
                    <button class="btn btn-ghost btn-sm" @click="s.agentResult = null" style="margin-top:8px;">
                        <i class="fa-solid fa-xmark"></i> 关闭
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- ═══ 运行 Agent 弹窗 ═══ -->
    <div v-if="runDialogOpen" class="modal-overlay" @click.self="runDialogOpen = false">
        <div class="modal-box">
            <div class="modal-header">
                <h3>
                    <i :class="selectedAgent.icon" style="margin-right:8px;"></i>
                    运行 Agent: {{ selectedAgent.name }}
                </h3>
                <button class="modal-close" @click="runDialogOpen = false">
                    <i class="fa-solid fa-xmark"></i>
                </button>
            </div>
            <div class="modal-body">
                <div class="form-group">
                    <label>任务描述 <span class="req">*</span></label>
                    <textarea
                        v-model="runTask"
                        rows="3"
                        placeholder="描述 Agent 要执行的任务..."
                        style="width:100%;box-sizing:border-box;"
                    ></textarea>
                </div>
                <button
                    class="btn btn-primary"
                    style="width:100%;justify-content:center;"
                    @click="executeAgent()"
                    :disabled="!runTask.trim() || s.agentRunning"
                >
                    <i :class="['fa-solid', s.agentRunning ? 'fa-spinner fa-spin' : 'fa-play']"></i>
                    {{ s.agentRunning ? '执行中...' : '执行任务' }}
                </button>
            </div>
        </div>
    </div>
</div>`,
        data() {
            return {
                runDialogOpen: false,
                selectedAgent: {},
                runTask: '',
            };
        },
        setup() {
            const s = window.ClawStore;
            if (s.agents.length === 0 && !s.agentsLoading) {
                s.loadAgents();
            }
            return { s };
        },
        methods: {
            openRunDialog(agent) {
                this.selectedAgent = agent;
                this.runTask = '';
                this.runDialogOpen = true;
            },
            async executeAgent() {
                const s = window.ClawStore;
                const agentId = this.selectedAgent.id;
                const task = this.runTask.trim();
                if (!task || s.agentRunning) return;

                this.runDialogOpen = false;
                s.agentRunning = agentId;
                s.activeAgentId = agentId;
                s.agentResult = null;

                try {
                    const res = await fetch('/api/agents/' + agentId + '/run', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ task: task })
                    });
                    const data = await res.json();
                    if (data.status === 'ok') {
                        s.agentResult = data.result;
                    } else {
                        s.agentResult = '[错误] ' + (data.message || '未知错误');
                    }
                } catch (err) {
                    console.error('[agent panel] 执行失败:', err);
                    s.agentResult = '[错误] 请求失败: ' + err.message;
                } finally {
                    s.agentRunning = null;
                }
            }
        }
    };

})();
