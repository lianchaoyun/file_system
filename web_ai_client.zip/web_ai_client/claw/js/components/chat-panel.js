/**
 * 聊天面板组件 —— 会话列表 / 消息列表 / 流式输出 / 输入框
 */
(function () {
    'use strict';

    window.ClawComponents = window.ClawComponents || {};
    window.ClawComponents.ChatPanel = {
        template: /* html */`
<div class="main-panel">
    <!-- 左侧：会话列表 -->
    <div class="chat-session-panel">
        <div class="chat-session-header">
            <span class="chat-session-title">聊天记录</span>
            <button class="chat-session-new-btn" @click="s.newSession()" title="新建对话">
                <i class="fa-solid fa-plus"></i>
            </button>
        </div>
        <div class="chat-session-scroll">
            <div
                v-for="sess in s.sessions"
                :key="sess.id"
                :class="['session-item', { active: s.sessionId === sess.id, 'menu-open': openMenuId === sess.id }]"
                @click="s.switchSession(sess.id)"
            >
                <div class="session-item-main">
                    <template v-if="editingSessionId === sess.id">
                        <input
                            class="session-edit-input"
                            v-model="editTitle"
                            @keydown="onEditKeydown($event, sess.id)"
                            @blur="commitEdit(sess.id)"
                            @click.stop
                        />
                    </template>
                    <template v-else>
                        <span class="session-item-title">{{ sess.title || sess.id }}</span>
                        <span class="session-item-meta">
                            {{ s.formatSessionDate(sess.id) }} · {{ sess.msg_count }}条
                        </span>
                    </template>
                </div>
                <!-- 更多菜单按钮 -->
                <div class="session-menu-wrap" v-if="editingSessionId !== sess.id">
                    <button
                        class="session-menu-btn"
                        @click.stop="toggleMenu(sess.id)"
                        title="更多操作"
                    >
                        <i class="fa-solid fa-ellipsis"></i>
                    </button>
                    <!-- 下拉菜单 -->
                    <div v-if="openMenuId === sess.id" class="session-dropdown">
                        <button class="session-dropdown-item" @click.stop="startEdit(sess); closeMenu()">
                            <i class="fa-solid fa-pen"></i>
                            <span>编辑标题</span>
                        </button>
                        <button class="session-dropdown-item delete" @click.stop="s.deleteSession(sess.id); closeMenu()">
                            <i class="fa-solid fa-trash-can"></i>
                            <span>删除</span>
                        </button>
                    </div>
                </div>
            </div>
            <div v-if="s.sessions.length === 0 && !s.sessionsLoading" class="session-empty">
                暂无历史记录
            </div>
            <div v-if="s.sessionsLoading" class="session-empty">加载中...</div>
        </div>
    </div>

    <!-- 右侧：聊天区域 -->
    <div class="chat-body">
        <div class="panel-body">
            <!-- 无选中会话 → 空状态 -->
            <div v-if="!s.sessionId" class="chat-empty-state">
                <div class="chat-empty-icon">
                    <i class="fa-solid fa-comments"></i>
                </div>
                <h2 class="chat-empty-title">开始对话</h2>
                <p class="chat-empty-desc">
                    选择左侧已有会话，或在下方输入框直接开始与龙虾交流。
                </p>
                <button class="chat-empty-btn" @click="s.newSession()">
                    <i class="fa-solid fa-plus"></i>
                    新建会话
                </button>
            </div>

            <!-- 有选中会话 → 消息列表 -->
            <div v-else class="chat-messages" @wheel="onWheel">
                <div class="chat-messages-inner">
                <div
                    v-for="(msg, idx) in s.messages"
                    :key="idx"
                    :class="['message-wrapper', msg.role]"
                >
                    <div class="avatar">
                        <i :class="['fa-solid', msg.role === 'user' ? 'fa-user' : 'fa-robot']"></i>
                    </div>
                    <div class="message-bubble">
                        <div class="msg-meta" v-if="msg.role !== 'user'">龙虾</div>
                        <div class="msg-content markdown-body" v-html="msg.html"></div>
                    </div>
                </div>

                <!-- AI 实时流式输出 -->
                <div v-if="s.streaming" class="message-wrapper assistant">
                    <div class="avatar">
                        <i class="fa-solid fa-robot"></i>
                    </div>
                    <div class="message-bubble">
                        <div class="msg-meta">
                            龙虾
                            <span class="thinking-dot"></span>
                        </div>
                        <div class="msg-content markdown-body" v-html="s.streamHtml"></div>
                    </div>
                </div>
                </div>
                <!-- 回到底部浮动按钮 -->
                <transition name="fade">
                    <button v-if="s.atBottom" class="scroll-to-bottom-btn"
                            @click="s.scrollBottom(true)" title="回到底部">
                        <i class="fa-solid fa-arrow-down"></i>
                    </button>
                </transition>
            </div>
        </div>

        <!-- 底部输入框（始终可见） -->
        <div class="chat-input-area">
            <div class="input-card-box">
                <textarea
                    v-model="s.inputText"
                    placeholder="在这里输入消息，敲击回车或点击右侧发送..."
                    rows="2"
                    @keydown.enter.prevent="s.sendMessage()"
                ></textarea>
                <div class="input-actions-bar">
                    <div class="input-actions-left">
                        <label class="upload-btn" title="上传文件">
                            <i class="fa-solid fa-paperclip"></i>
                            <input type="file" style="display:none" @change="s.onFileUpload" />
                        </label>
                        <div class="engine-picker-wrap">
                            <button class="model-picker-btn engine-picker-btn" @click="s.toggleChatEngineDropdown()" title="切换引擎">
                                <i :class="s.getActiveEngineMeta().icon"></i>
                                <span class="engine-picker-name">{{ s.getActiveEngineMeta().label }}</span>
                                <i class="fa-solid fa-caret-up"></i>
                            </button>
                            <div v-if="s.chatEngineDropdown" class="model-dropdown-up engine-dropdown-up">
                                <div
                                    v-for="e in s.engineList"
                                    :key="e.name"
                                    :class="['model-dropdown-item', 'engine-option', { active: e.name === s.activeEngine, disabled: !e.available }]"
                                    @click="selectEngine(e)"
                                >
                                    <i :class="e.icon"></i>
                                    <span class="model-dropdown-name">{{ e.label }}</span>
                                    <span v-if="!e.available" class="option-unavailable">(不可用)</span>
                                    <span v-if="e.name === s.activeEngine" class="model-dropdown-badge">当前</span>
                                </div>
                                <div v-if="s.engineList.length === 0" class="model-dropdown-empty">
                                    加载中...
                                </div>
                            </div>
                        </div>
                        <div class="model-picker-wrap">
                            <button class="model-picker-btn" @click="s.toggleChatModelDropdown()" title="切换模型">
                                <i class="fa-solid fa-microchip"></i>
                                <span class="model-picker-name">{{ (s.modelList.find(function(m){return m.is_active;}) || {}).name || '未选择' }}</span>
                                <i class="fa-solid fa-caret-up"></i>
                            </button>
                            <div v-if="s.chatModelDropdown" class="model-dropdown-up">
                                <div
                                    v-for="m in s.modelList"
                                    :key="m.model_id"
                                    :class="['model-dropdown-item', { active: m.is_active }]"
                                    @click="s.switchModel(m.model_id)"
                                >
                                    <span class="model-dropdown-name">{{ m.name || m.model_id }}</span>
                                    <span v-if="m.is_active" class="model-dropdown-badge">当前</span>
                                </div>
                                <div v-if="s.modelList.length === 0" class="model-dropdown-empty">
                                    暂无模型
                                </div>
                            </div>
                        </div>
                    </div>
                    <button
                        class="send-btn"
                        :class="{ active: s.inputText.trim() && !s.streaming }"
                        :disabled="!s.inputText.trim() || s.streaming"
                        @click="s.sendMessage()"
                        title="发送消息"
                    >
                        <i class="fa-solid fa-paper-plane"></i>
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>`,
        setup() {
            const s = window.ClawStore;
            const { watch, nextTick, ref } = Vue;
            const editingSessionId = ref(null);
            const editTitle = ref('');
            const openMenuId = ref(null);

            function toggleMenu(sid) {
                openMenuId.value = openMenuId.value === sid ? null : sid;
            }

            function closeMenu() {
                openMenuId.value = null;
            }

            function startEdit(sess) {
                editingSessionId.value = sess.id;
                editTitle.value = sess.title || sess.id;
                Vue.nextTick(function () {
                    var inp = document.querySelector('.session-edit-input');
                    if (inp) { inp.focus(); inp.select(); }
                });
            }

            function commitEdit(sid) {
                var t = editTitle.value.trim();
                if (t) s.renameSession(sid, t);
                editingSessionId.value = null;
                editTitle.value = '';
            }

            function cancelEdit() {
                editingSessionId.value = null;
                editTitle.value = '';
            }

            function onEditKeydown(e, sid) {
                if (e.key === 'Enter') { commitEdit(sid); }
                else if (e.key === 'Escape') { cancelEdit(); }
            }

            function selectEngine(engine) {
                if (!engine.available) return;
                s.switchEngine(engine.name);
                // 关闭下拉框
                setTimeout(function() {
                    s.chatEngineDropdown = false;
                }, 100);
            }

            // wheel 事件是用户真实意图，不会被 Vue DOM 更新误触发
            var wheelTimer = null;
            function onWheel(e) {
                var el = e.currentTarget;
                // 向上滚动 → 标记用户离开
                if (e.deltaY < 0) {
                    s.setAtBottom(true);
                }
                // 防抖检测是否滚回底部
                clearTimeout(wheelTimer);
                wheelTimer = setTimeout(function () {
                    var dist = el.scrollHeight - el.scrollTop - el.clientHeight;
                    if (dist < 60) s.setAtBottom(false);
                }, 150);
            }

            // 消息变化后自动滚动到底部（受 userScrolledAway 保护）
            watch(
                function () { return s.messages; },
                function () {
                    nextTick(function () {
                        s.scrollBottom();
                    });
                },
                { deep: false }
            );
            return { s, editingSessionId, editTitle, openMenuId, toggleMenu, closeMenu, startEdit, commitEdit, cancelEdit, onEditKeydown, selectEngine, onWheel };
        }
    };

})();
