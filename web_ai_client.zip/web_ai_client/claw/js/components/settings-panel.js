/**
 * 设置面板组件 —— 模型管理 / 编辑弹窗 / 扫描弹窗
 */
(function () {
    'use strict';

    window.ClawComponents = window.ClawComponents || {};
    window.ClawComponents.SettingsPanel = {
        template: /* html */`
<div class="settings-layout">
    <!-- ═══ 左侧导航 ═══ -->
    <div class="settings-nav">
        <button class="settings-nav-back" title="返回" @click="s.activeTab = 'chat'">
            <i class="fa-solid fa-arrow-left"></i>
        </button>
        <div class="settings-nav-menu">
            <button v-for="t in settingTabs" :key="t.key"
                    :class="['settings-nav-item', { active: activeSettingTab === t.key }]"
                    @click="activeSettingTab = t.key">
                <i :class="t.icon"></i>
                <span>{{ t.label }}</span>
            </button>
        </div>
    </div>

    <!-- ═══ 右侧内容 ═══ -->
    <div class="settings-content">
    <!-- ═══ Tab 1: 模型配置 ═══ -->
    <div class="settings-container" v-show="activeSettingTab === 'model'">
        <div class="settings-top-row">
            <div>
                <h2 class="settings-title"><i class="fa-solid fa-sliders"></i> 模型配置</h2>
                <p class="settings-desc">管理 AI 模型连接，切换当前使用的模型</p>
            </div>
            <div class="settings-top-actions">
                <button class="btn btn-primary" @click="s.openModelEditor(null)">
                    <i class="fa-solid fa-plus"></i> 添加模型
                </button>
                <button class="btn btn-ghost" @click="s.scanModels()" :disabled="s.scanning">
                    <i :class="['fa-solid', s.scanning ? 'fa-spinner fa-spin' : 'fa-magnifying-glass']"></i>
                    {{ s.scanning ? '扫描中...' : '扫描可用模型' }}
                </button>
            </div>
        </div>

        <!-- 模型列表 -->
        <div class="model-list">
            <div
                v-for="m in s.modelList"
                :key="m.model_id"
                :class="['model-card', { active: m.is_active }]"
            >
                <div class="model-card-header">
                    <div class="model-card-header-left">
                        <span class="model-card-name">{{ m.name || m.model_id }}</span>
                        <span v-if="m.is_active" class="model-card-active-badge">当前使用</span>
                        <span class="model-card-model">{{ m.model }}</span>
                    </div>
                    <div class="model-card-header-right">
                        <button v-if="!m.is_active" class="btn-icon btn-icon-primary" title="设为当前" @click="s.switchModel(m.model_id)">
                            <i class="fa-solid fa-check"></i>
                        </button>
                        <button class="btn-icon" title="编辑" @click="s.openModelEditor(m)">
                            <i class="fa-solid fa-pen-to-square"></i>
                        </button>
                        <button class="btn-icon btn-icon-danger" title="删除" @click="s.deleteModel(m.model_id)">
                            <i class="fa-solid fa-trash"></i>
                        </button>
                    </div>
                </div>
                <div class="model-card-body">
                    <div class="model-card-field">
                        <label>API URL</label>
                        <span>{{ m.base_url }}</span>
                    </div>
                    <div class="model-card-field">
                        <label>温度</label>
                        <span>{{ m.temperature }}</span>
                    </div>
                    <div class="model-card-field">
                        <label>Max Tokens</label>
                        <span>{{ m.max_tokens }}</span>
                    </div>
                    <div class="model-card-field">
                        <label>工具调用</label>
                        <span :class="m.supports_tools ? 'tag-green' : 'tag-red'">
                            {{ m.supports_tools ? '✓ 支持' : '✗ 不支持' }}
                        </span>
                    </div>
                </div>

            </div>
            <div v-if="s.modelList.length === 0" class="model-empty">
                暂无模型配置，请添加第一个模型
            </div>
        </div>



        <!-- ═══ 扫描模型弹窗 ═══ -->
        <div v-if="s.scanDialogOpen" class="modal-overlay" @click.self="s.scanDialogOpen = false">
            <div class="modal-box modal-scan">
                <div class="modal-header">
                    <h3>🔍 扫描可用模型</h3>
                    <button class="modal-close" @click="s.scanDialogOpen = false">
                        <i class="fa-solid fa-xmark"></i>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="scan-form">
                        <div class="form-group">
                            <label>API 地址</label>
                            <input v-model="s.scanBaseUrl" placeholder="http://localhost:11434/v1">
                        </div>
                        <div class="form-group">
                            <label>API Key</label>
                            <input v-model="s.scanApiKey" placeholder="ollama">
                        </div>
                        <button class="btn btn-primary" @click="s.scanModels()" :disabled="s.scanning">
                            <i :class="['fa-solid', s.scanning ? 'fa-spinner fa-spin' : 'fa-magnifying-glass']"></i>
                            {{ s.scanning ? '扫描中...' : '开始扫描' }}
                        </button>
                    </div>
                    <div v-if="s.scanResult.length > 0" class="scan-result-list">
                        <div class="scan-result-header">
                            <span>扫描到 {{ s.scanResult.length }} 个可用模型</span>
                            <div>
                                <button class="btn btn-sm btn-ghost" @click="s.selectAllScan()">全选</button>
                                <button class="btn btn-sm btn-ghost" @click="s.deselectAllScan()">取消全选</button>
                            </div>
                        </div>
                        <div class="scan-result-scroll">
                            <label
                                v-for="m in s.scanResult"
                                :key="m.id"
                                class="scan-model-item"
                            >
                                <input type="checkbox" v-model="s.selectedScanModels[m.id]">
                                <div class="scan-model-info">
                                    <span class="scan-model-name">{{ m.id }}</span>
                                    <span class="scan-model-by" v-if="m.owned_by">{{ m.owned_by }}</span>
                                </div>
                            </label>
                        </div>
                        <button
                            class="btn btn-primary"
                            style="margin-top:12px;width:100%;"
                            @click="s.importScannedModels()"
                        >
                            <i class="fa-solid fa-download"></i>
                            导入选中模型
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <!-- ═══ 模型编辑弹窗 ═══ -->
        <div v-if="s.modelEditorOpen" class="modal-overlay" @click.self="s.modelEditorOpen = false">
            <div class="modal-box">
                <div class="modal-header">
                    <h3>{{ s.editingModel ? '编辑模型' : '添加模型' }}</h3>
                    <button class="modal-close" @click="s.modelEditorOpen = false">
                        <i class="fa-solid fa-xmark"></i>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label>模型 ID <span class="req">*</span></label>
                        <input v-model="s.modelForm.model_id" placeholder="如 local-deepseek" :disabled="!!s.editingModel">
                    </div>
                    <div class="form-group">
                        <label>显示名称</label>
                        <input v-model="s.modelForm.name" placeholder="如 DeepSeek-R1 (本地)">
                    </div>
                    <div class="form-group">
                        <label>API 地址 <span class="req">*</span></label>
                        <input v-model="s.modelForm.base_url" placeholder="http://localhost:11434/v1">
                    </div>
                    <div class="form-group">
                        <label>模型名称 <span class="req">*</span></label>
                        <input v-model="s.modelForm.model" placeholder="如 deepseek-r1:7b">
                    </div>
                    <div class="form-group">
                        <label>API Key</label>
                        <input v-model="s.modelForm.api_key" placeholder="ollama">
                    </div>
                    <div class="form-row">
                        <div class="form-group form-group-half">
                            <label>Max Tokens</label>
                            <input v-model.number="s.modelForm.max_tokens" type="number" placeholder="4096">
                        </div>
                        <div class="form-group form-group-half">
                            <label>Temperature</label>
                            <input v-model.number="s.modelForm.temperature" type="number" step="0.1" min="0" max="2" placeholder="0.7">
                        </div>
                    </div>
                    <div class="form-group">
                        <label>超时 (秒)</label>
                        <input v-model.number="s.modelForm.timeout" type="number" placeholder="120">
                    </div>
                    <div class="form-group form-checkbox">
                        <label class="checkbox-label">
                            <input type="checkbox" v-model="s.modelForm.supports_tools">
                            <span>支持工具调用 (Function Calling)</span>
                        </label>
                        <p class="form-hint">gemma 等部分模型不支持，需关闭此项</p>
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-ghost" @click="s.modelEditorOpen = false">取消</button>
                    <button class="btn btn-primary" @click="s.saveModel()" :disabled="!s.modelForm.model_id || !s.modelForm.base_url || !s.modelForm.model || s.modelSaving">
                        {{ s.modelSaving ? '保存中...' : '保存' }}
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- ═══ Tab 3: 调试工具 ═══ -->
    <div class="settings-container" v-show="activeSettingTab === 'debug'">
        <div class="settings-top-row">
            <div>
                <h2 class="settings-title"><i class="fa-solid fa-bug"></i> 调试工具</h2>
                <p class="settings-desc">HTTP / WebSocket 通信测试</p>
            </div>
        </div>

        <div class="debug-card">
            <!-- 目标切换 pills -->
            <div class="debug-pills">
                <button :class="['debug-pill', { active: dbgMode === 'http' }]"
                        @click="dbgMode = 'http'">HTTP 测试</button>
                <button :class="['debug-pill', { active: dbgMode === 'ws' }]"
                        @click="dbgMode = 'ws'">WS 测试</button>
            </div>

            <!-- ══ HTTP 测试 ══ -->
            <div v-show="dbgMode === 'http'">
                <!-- 请求栏 -->
                <div class="debug-http-bar">
                    <select class="debug-http-method" v-model="httpMethod">
                        <option>GET</option><option>POST</option><option>PUT</option><option>DELETE</option>
                    </select>
                    <input class="debug-url" v-model="httpUrl" placeholder="http://localhost:8080/api/..." spellcheck="false" @keydown.enter="sendHttp" />
                    <button class="debug-btn-send" @click="sendHttp" :disabled="httpSending">
                        <i v-if="httpSending" class="fa-solid fa-spinner fa-spin"></i>
                        <span v-else>发送</span>
                    </button>
                </div>
                <!-- Body (POST/PUT) -->
                <div v-if="httpMethod === 'POST' || httpMethod === 'PUT'" class="debug-http-bodybar">
                    <textarea class="debug-http-body" v-model="httpBody" placeholder='{"key":"value"}'></textarea>
                </div>
                <!-- 快捷命令 -->
                <div class="debug-quick">
                    <button v-for="(entry, i) in httpQuickCmds" :key="i"
                            class="debug-quick-btn" @click="applyHttpQuick(entry)">{{ entry.label }}</button>
                </div>
                <!-- 响应区 -->
                <div class="debug-output" ref="httpOutputEl">
                    <div v-if="!httpResponse" class="debug-empty">发送 HTTP 请求查看响应</div>
                    <div v-else>
                        <div class="debug-msg system">{{ httpResponse.status }} {{ httpResponse.statusText }}</div>
                        <pre class="debug-http-resp">{{ httpResponse.body }}</pre>
                    </div>
                </div>
                <!-- 工具栏 -->
                <div class="debug-toolbar">
                    <span class="debug-http-time" v-if="httpResponse">{{ httpResponse.time }}ms</span>
                    <span class="debug-http-time" v-else></span>
                    <button class="debug-tool-btn" @click="httpResponse = null">清空</button>
                </div>
            </div>

            <!-- ══ WS 测试 ══ -->
            <div v-show="dbgMode === 'ws'">
                <!-- 连接栏 -->
                <div class="debug-connectbar">
                    <span class="debug-dot" :class="{ connected: wsConnected }"></span>
                    <span class="debug-status">{{ wsConnected ? '已连接' : '未连接' }}</span>
                    <input class="debug-url" v-model="wsUrl" :placeholder="wsDefaultUrl" spellcheck="false" />
                    <button v-if="!wsConnected" class="debug-btn-connect" @click="wsToggleConnection">连接</button>
                    <button v-else class="debug-btn-disconnect" @click="wsToggleConnection">断开</button>
                </div>
                <!-- 快捷命令 -->
                <div class="debug-quick">
                    <button v-for="(entry, i) in wsQuickCmds" :key="i"
                            class="debug-quick-btn" @click="sendWsQuickCmd(entry)">{{ entry.label }}</button>
                </div>
                <!-- 输出区 -->
                <div class="debug-output" ref="wsOutputEl">
                    <div v-if="wsLogs.length === 0" class="debug-empty">连接后发送命令查看结果</div>
                    <div v-for="(log, i) in wsLogs" :key="i" class="debug-msg" :class="log.cls">
                        [{{ log.time }}] {{ log.text }}
                    </div>
                </div>
                <!-- 工具栏 -->
                <div class="debug-toolbar">
                    <label class="debug-autoscroll">
                        <input type="checkbox" v-model="wsAutoScroll" />
                        <span>自动滚动</span>
                    </label>
                    <button class="debug-tool-btn" @click="wsLogs = []">清空</button>
                </div>
                <!-- 输入行 -->
                <div class="debug-inputrow">
                    <textarea ref="wsCmdTextarea" class="debug-cmdinput" v-model="wsCmdInput"
                              placeholder='{"cmd":"subscribe_kline","symbols":["btcusdt"],"intervals":["1m"]}'
                              rows="1" @input="autoResizeWs" @keydown="onWsKeydown"></textarea>
                    <button class="debug-btn-send" @click="wsSendRaw" :disabled="!wsConnected">发送</button>
                </div>
            </div>
        </div>
    </div>

    <!-- ═══ Tab: 引擎配置 ═══ -->
    <div class="settings-container" v-show="activeSettingTab === 'engine'">
        <div class="settings-top-row">
            <div>
                <h2 class="settings-title"><i class="fa-solid fa-gears"></i> 引擎配置</h2>
                <p class="settings-desc">切换 AI 推理引擎，不同引擎有不同的推理策略和能力</p>
            </div>
        </div>

        <div v-if="s.engineLoading" class="model-empty">
            <i class="fa-solid fa-spinner fa-spin"></i> 加载中...
        </div>
        <div v-else class="engine-list">
            <div
                v-for="eng in s.engineList"
                :key="eng.name"
                :class="['engine-card', { active: eng.name === s.activeEngine, unavailable: !eng.available }]"
                @click="eng.available && s.switchEngine(eng.name)"
            >
                <div class="engine-card-header">
                    <div class="engine-card-left">
                        <i :class="eng.icon" class="engine-card-icon"></i>
                        <div>
                            <span class="engine-card-name">{{ eng.label }}</span>
                            <span class="engine-card-id">{{ eng.name }}</span>
                        </div>
                    </div>
                    <div class="engine-card-right">
                        <span v-if="eng.name === s.activeEngine" class="engine-badge-active">当前使用</span>
                        <span v-else-if="!eng.available" class="engine-badge-unavailable">
                            <i class="fa-solid fa-circle-exclamation"></i> 依赖未安装
                        </span>
                        <button v-else class="btn-icon btn-icon-primary" title="切换到此引擎" @click.stop="s.switchEngine(eng.name)">
                            <i class="fa-solid fa-check"></i>
                        </button>
                    </div>
                </div>
                <div class="engine-card-desc">{{ eng.desc }}</div>
                <div v-if="!eng.available && eng.error" class="engine-card-error">
                    <code>{{ eng.error }}</code>
                </div>
            </div>
        </div>
    </div>

    <!-- ═══ Tab 3: Token 统计 ═══ -->
    <div class="settings-container" v-show="activeSettingTab === 'token'">
        <div class="settings-top-row">
            <div>
                <h2 class="settings-title"><i class="fa-solid fa-chart-pie"></i> Token 统计</h2>
                <p class="settings-desc">查看 AI 对话的 Token 使用量，按引擎分类统计</p>
            </div>
            <div class="settings-top-actions">
                <button class="btn btn-ghost" @click="s.loadTokenStats()" :disabled="s.tokenLoading" title="刷新">
                    <i class="fa-solid fa-arrows-rotate" :class="{'fa-spin': s.tokenLoading}"></i>
                </button>
                <button class="btn btn-ghost" @click="s.resetTokenStats()" :disabled="s.tokenLoading">
                    <i class="fa-solid fa-trash-can"></i> 清空统计
                </button>
            </div>
        </div>

        <div v-if="s.tokenLoading" class="model-empty">
            <i class="fa-solid fa-spinner fa-spin"></i> 加载中...
        </div>
        <div v-else-if="!s.tokenStats" class="model-empty">
            <i class="fa-solid fa-chart-simple"></i>
            <p>暂无统计数据</p>
        </div>
        <div v-else class="token-stats">
            <!-- 总览卡片 -->
            <div class="token-overview">
                <div class="token-card">
                    <div class="token-card-icon"><i class="fa-solid fa-arrow-up"></i></div>
                    <div class="token-card-label">提示词 Tokens</div>
                    <div class="token-card-value prompt">{{ formatNumber(s.tokenStats.total_prompt_tokens) }}</div>
                </div>
                <div class="token-card">
                    <div class="token-card-icon"><i class="fa-solid fa-arrow-down"></i></div>
                    <div class="token-card-label">回复 Tokens</div>
                    <div class="token-card-value completion">{{ formatNumber(s.tokenStats.total_completion_tokens) }}</div>
                </div>
                <div class="token-card total">
                    <div class="token-card-icon"><i class="fa-solid fa-layer-group"></i></div>
                    <div class="token-card-label">总计 Tokens</div>
                    <div class="token-card-value">{{ formatNumber(s.tokenStats.total_tokens) }}</div>
                </div>
            </div>

            <!-- 按引擎分组 -->
            <div v-if="Object.keys(s.tokenStats.by_engine).length > 0" class="token-by-engine">
                <h3 class="token-section-title">按引擎统计（最近 {{ s.tokenStats.period_days }} 天）</h3>
                <div class="engine-token-list">
                    <div v-for="(tokens, engine) in s.tokenStats.by_engine" :key="engine" class="engine-token-item">
                        <div class="engine-token-name">{{ getEngineLabel(engine) }}</div>
                        <div class="engine-token-bar-wrap">
                            <div class="engine-token-bar" :style="{ width: (tokens / s.tokenStats.total_tokens * 100) + '%' }"></div>
                        </div>
                        <div class="engine-token-value">{{ formatNumber(tokens) }}</div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    </div><!-- /.settings-content -->
</div><!-- /.settings-layout -->`,
        setup() {
            const s = window.ClawStore;

            const activeSettingTab = Vue.ref(localStorage.getItem('claw_settingTab') || 'model');
            Vue.watch(activeSettingTab, function (val) {
                localStorage.setItem('claw_settingTab', val);
                // 切换到 Token 统计 Tab 时自动加载数据
                if (val === 'token' && !s.tokenStats) {
                    s.loadTokenStats();
                }
            }, { immediate: true });  // 页面加载时立即检查
            const settingTabs = [
                { key: 'model', label: '模型配置', icon: 'fa-solid fa-sliders' },
                { key: 'engine', label: '引擎配置', icon: 'fa-solid fa-gears' },
                { key: 'token', label: 'Token 统计', icon: 'fa-solid fa-chart-pie' },
                { key: 'debug', label: '调试工具', icon: 'fa-solid fa-bug' },
            ];

            // Token 工具函数
            function formatNumber(num) {
                if (num >= 1000000) return (num / 1000000).toFixed(2) + 'M';
                if (num >= 1000) return (num / 1000).toFixed(1) + 'K';
                return num.toString();
            }

            function getEngineLabel(engineName) {
                var found = s.engineList.find(function(e) { return e.name === engineName; });
                return found ? found.label : engineName;
            }

            // Token 工具函数
            function formatNumber(num) {
                if (num >= 1000000) return (num / 1000000).toFixed(2) + 'M';
                if (num >= 1000) return (num / 1000).toFixed(1) + 'K';
                return num.toString();
            }

            function getEngineLabel(engineName) {
                var found = s.engineList.find(function(e) { return e.name === engineName; });
                return found ? found.label : engineName;
            }

            // ═══ 调试工具 ═══
            var dbgMode = Vue.ref('http');
            var wsProtocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';

            // ── HTTP 测试 ──
            var httpUrl = Vue.ref(wsProtocol.replace('ws', 'http') + '//' + window.location.host + '/api/health');
            var httpMethod = Vue.ref('GET');
            var httpBody = Vue.ref('');
            var httpResponse = Vue.ref(null);
            var httpSending = Vue.ref(false);
            var httpOutputEl = Vue.ref(null);
            var httpQuickCmds = [
                { label: '健康检查', url: wsProtocol.replace('ws', 'http') + '//' + window.location.host + '/api/health', method: 'GET', body: '' },
                { label: '模型列表', url: wsProtocol.replace('ws', 'http') + '//' + window.location.host + '/api/models', method: 'GET', body: '' },
                { label: 'POST JSON', url: wsProtocol.replace('ws', 'http') + '//' + window.location.host + '/api/echo', method: 'POST', body: '{"msg":"hello"}' },
            ];
            function applyHttpQuick(entry) {
                httpUrl.value = entry.url;
                httpMethod.value = entry.method;
                httpBody.value = entry.body || '';
            }
            async function sendHttp() {
                if (httpSending.value) return;
                var url = httpUrl.value.trim();
                if (!url) return;
                httpSending.value = true;
                var start = Date.now();
                try {
                    var opts = { method: httpMethod.value, headers: {} };
                    if ((httpMethod.value === 'POST' || httpMethod.value === 'PUT') && httpBody.value.trim()) {
                        opts.headers['Content-Type'] = 'application/json';
                        opts.body = httpBody.value;
                    }
                    var res = await fetch(url, opts);
                    var text = await res.text();
                    try { text = JSON.stringify(JSON.parse(text), null, 2); } catch (e) { /* plain text */ }
                    httpResponse.value = { status: res.status, statusText: res.statusText, body: text, time: Date.now() - start };
                } catch (err) {
                    httpResponse.value = { status: 0, statusText: 'Error', body: err.message, time: Date.now() - start };
                }
                httpSending.value = false;
            }

            // ── WS 测试（行情数据） ──
            var wsDefaultUrl = 'ws://127.0.0.1:6968';
            var wsUrl = Vue.ref(wsDefaultUrl);
            var wsCmdInput = Vue.ref('');
            var wsLogs = Vue.ref([]);
            var wsConnected = Vue.ref(false);
            var wsAutoScroll = Vue.ref(true);
            var wsSocket = null;
            var wsOutputEl = Vue.ref(null);
            var wsCmdTextarea = Vue.ref(null);

            var wsQuickCmds = [
                { label: 'K线 BTC 1m', cmd: 'subscribe_kline', payload: { symbols: ['btcusdt'], intervals: ['1m'] } },
                { label: 'K线 BTC 5m', cmd: 'subscribe_kline', payload: { symbols: ['btcusdt'], intervals: ['5m'] } },
                { label: '历史 BTC 1m', cmd: 'fetch_history', payload: { symbols: ['btcusdt'], interval: '1m', limit: 10 } },
                { label: 'Tick BTC', cmd: 'subscribe_tick', payload: { symbols: ['btcusdt'] } },
                { label: '取消 BTC 1m', cmd: 'unsubscribe', payload: { keys: ['kline:btcusdt:1m'] } },
            ];

            function addWsLog(msg, cls) {
                wsLogs.value.push({ time: new Date().toLocaleTimeString(), text: msg, cls: cls });
            }
            function scrollWsBottom() {
                Vue.nextTick(function () {
                    if (wsAutoScroll.value && wsOutputEl.value)
                        wsOutputEl.value.scrollTop = wsOutputEl.value.scrollHeight;
                });
            }
            function wsConnect() {
                var url = wsUrl.value.trim();
                if (!url) return;
                addWsLog('正在连接 ' + url + ' ...', 'system');
                if (wsSocket) { try { wsSocket.close(); } catch (e) { /* ignore */ } wsSocket = null; }
                try {
                    wsSocket = new WebSocket(url);
                    wsSocket.onopen = function () { addWsLog('连接成功', 'system'); wsConnected.value = true; };
                    wsSocket.onmessage = function (e) {
                        try {
                            var data = JSON.parse(e.data);
                            if (data.type === 'kline') {
                                var d = data.data || {};
                                addWsLog('← K线' + (data.interval ? ' [' + data.interval + ']' : '') + ' | ' + data.symbol + ' | o=' + d.open + ' h=' + d.high + ' l=' + d.low + ' c=' + d.close + ' v=' + d.volume, 'recv push');
                            } else if (data.type === 'tick') {
                                var td = data.data || {};
                                addWsLog('← Tick | ' + data.symbol + ' | price=' + td.price + ' v=' + td.volume, 'recv push');
                            } else if (data.type === 'history') {
                                var cnt = 0;
                                var keys = Object.keys(data.data || {});
                                keys.forEach(function (k) { cnt += (data.data[k] || []).length; });
                                addWsLog('← 历史数据 ' + data.interval + ' | ' + keys.join(',') + ' 共 ' + cnt + ' 条', 'recv');
                            } else {
                                addWsLog('← ' + JSON.stringify(data), 'recv');
                            }
                        } catch (err) { addWsLog('← ' + e.data, 'recv'); }
                        scrollWsBottom();
                    };
                    wsSocket.onerror = function () { addWsLog('连接错误', 'system error'); };
                    wsSocket.onclose = function () { addWsLog('连接已关闭', 'system'); wsConnected.value = false; wsSocket = null; };
                } catch (err) { addWsLog('连接失败: ' + err.message, 'system error'); }
            }
            function wsDisconnect() {
                if (wsSocket) { try { wsSocket.close(); } catch (e) { /* ignore */ } wsSocket = null; wsConnected.value = false; }
            }
            function wsToggleConnection() {
                if (wsSocket && wsSocket.readyState === WebSocket.OPEN) wsDisconnect(); else wsConnect();
            }
            function wsSendRaw() {
                var text = wsCmdInput.value.trim();
                if (!text) return;
                if (!wsSocket || wsSocket.readyState !== WebSocket.OPEN) { addWsLog('未连接', 'system error'); return; }
                addWsLog('→ ' + text, 'sent');
                wsSocket.send(text);
                wsCmdInput.value = '';
                scrollWsBottom();
            }
            function sendWsQuickCmd(entry) {
                var req = { cmd: entry.cmd };
                Object.keys(entry.payload || {}).forEach(function (k) { req[k] = entry.payload[k]; });
                wsCmdInput.value = JSON.stringify(req);
                wsSendRaw();
            }
            function autoResizeWs() {
                if (wsCmdTextarea.value) {
                    wsCmdTextarea.value.style.height = 'auto';
                    wsCmdTextarea.value.style.height = wsCmdTextarea.value.scrollHeight + 'px';
                }
            }
            function onWsKeydown(e) {
                if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    wsSendRaw();
                    Vue.nextTick(function () { if (wsCmdTextarea.value) wsCmdTextarea.value.style.height = 'auto'; });
                }
            }

            return { s, activeSettingTab, settingTabs,
                dbgMode, httpUrl, httpMethod, httpBody, httpResponse, httpSending, httpOutputEl,
                httpQuickCmds, applyHttpQuick, sendHttp,
                wsDefaultUrl, wsUrl, wsCmdInput, wsLogs, wsConnected, wsAutoScroll,
                wsOutputEl, wsCmdTextarea, wsQuickCmds,
                wsToggleConnection, sendWsQuickCmd, wsSendRaw,
                autoResizeWs, onWsKeydown,
                // Token 工具函数
                formatNumber, getEngineLabel };
        }
    };

})();
