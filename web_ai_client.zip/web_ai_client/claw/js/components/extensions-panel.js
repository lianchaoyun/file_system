/**
 * 扩展面板 —— 统一页面，顶部 Tab 切换「代理 / 技能 / MCP」
 */
(function () {
    'use strict';

    window.ClawComponents = window.ClawComponents || {};
    window.ClawComponents.ExtensionsPanel = {
        template: /* html */`
<div class="settings-panel">
    <!-- ═══ 顶部 Tab 栏 ═══ -->
    <div class="settings-tab-bar">
        <button
            v-for="tab in tabs"
            :key="tab.id"
            :class="['settings-tab-btn', { active: activeSub === tab.id }]"
            @click="switchTab(tab.id)"
        >
            <i :class="tab.icon"></i> {{ tab.label }}
        </button>
    </div>

    <!-- ══════════════════════════════════════
         代理 子面板
         ══════════════════════════════════════ -->
    <div v-if="activeSub === 'agents'" class="settings-container">
        <p class="settings-desc">自动化任务代理，可执行多步骤任务。点击运行按钮触发。</p>

        <div v-if="s.agentsLoading" class="model-empty">
            <i class="fa-solid fa-spinner fa-spin"></i> 加载中...
        </div>
        <div v-else-if="s.agents.length === 0" class="model-empty">
            <p><i class="fa-solid fa-circle-exclamation" style="color:var(--text-dim);"></i></p>
            <p>暂无已注册 Agent</p>
            <p style="font-size:12px;margin-top:4px;">在 extensions/agents/ 下添加 Agent 子包即可自动发现</p>
        </div>
        <div v-else class="model-list">
            <div v-for="agent in s.agents" :key="agent.id" class="model-card">
                <div class="model-card-header">
                    <div class="model-card-header-left">
                        <span class="model-card-name">
                            <i :class="agent.icon" style="margin-right:8px;color:var(--accent);"></i>
                            {{ agent.name }}
                        </span>
                        <span class="model-card-model">{{ agent.class }}</span>
                    </div>
                    <div class="model-card-header-right">
                        <button
                            class="btn-icon btn-icon-primary"
                            title="运行"
                            @click="openRunDialog(agent)"
                            :disabled="s.agentRunning === agent.id"
                        >
                            <i :class="['fa-solid', s.agentRunning === agent.id ? 'fa-spinner fa-spin' : 'fa-play']"></i>
                        </button>
                    </div>
                </div>
                <div class="model-card-body">
                    <div class="model-card-field model-card-field-row" style="flex:1;min-width:100%;">
                        <span>{{ agent.description }}</span>
                    </div>
                    <div class="model-card-field model-card-field-row" v-if="agent.tools && agent.tools.length">
                        <label>可用工具</label>
                        <span style="font-family:'Fira Code',Consolas,monospace;font-size:11px;">
                            {{ agent.tools.join(', ') }}
                        </span>
                    </div>
                </div>
                <div v-if="s.agentResult && s.activeAgentId === agent.id" class="agent-result">
                    <pre>{{ s.agentResult }}</pre>
                    <button class="btn btn-ghost btn-sm" @click="s.agentResult = null" style="margin-top:8px;">
                        <i class="fa-solid fa-xmark"></i> 关闭
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- ══════════════════════════════════════
         技能 子面板
         ══════════════════════════════════════ -->
    <div v-else-if="activeSub === 'skills'" class="settings-container">
        <p class="settings-desc">所有 LLM 可调用的工具（来自内置 Skills 和 MCP 扩展）</p>

        <div v-if="s.toolsLoading" class="model-empty">
            <i class="fa-solid fa-spinner fa-spin"></i> 加载中...
        </div>
        <div v-else-if="s.tools.length === 0" class="model-empty">
            <p><i class="fa-solid fa-circle-exclamation" style="color:var(--text-dim);"></i></p>
            <p>暂无已注册工具</p>
        </div>
        <div v-else class="model-list">
            <div v-for="(t, idx) in s.tools" :key="idx" class="model-card">
                <div class="model-card-header">
                    <span class="model-card-name">
                        <code style="color:var(--accent);">{{ t.name }}</code>
                    </span>
                    <span class="model-card-source">{{ t.source }}</span>
                </div>
                <div class="model-card-body">
                    <div class="model-card-field" style="flex:1;min-width:100%;">
                        <label>描述</label>
                        <span>{{ t.description || '(无描述)' }}</span>
                    </div>
                    <div v-if="t.params && t.params.length" class="model-card-field" style="flex:1;min-width:100%;margin-top:8px;">
                        <label>参数定义</label>
                        <table class="params-table">
                            <thead>
                                <tr>
                                    <th>参数</th>
                                    <th>类型</th>
                                    <th>必填</th>
                                    <th>默认值</th>
                                    <th>说明</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr v-for="p in t.params" :key="p.name">
                                    <td><code>{{ p.name }}</code></td>
                                    <td>{{ p.type || '-' }}</td>
                                    <td>{{ p.required ? '✅' : '-' }}</td>
                                    <td><code v-if="p.default != null">{{ p.default }}</code><span v-else>-</span></td>
                                    <td class="param-desc">{{ p.description || '-' }}</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- ══════════════════════════════════════
         MCP 子面板
         ══════════════════════════════════════ -->
    <div v-else-if="activeSub === 'mcp'" class="settings-container">
        <p class="settings-desc">MCP（Model Context Protocol）扩展实例，由 Claw 自动管理生命周期</p>

        <div v-if="s.mcpsLoading" class="model-empty">
            <i class="fa-solid fa-spinner fa-spin"></i> 加载中...
        </div>
        <div v-else-if="s.mcps.length === 0" class="model-empty">
            <p><i class="fa-solid fa-circle-exclamation" style="color:var(--text-dim);"></i></p>
            <p>暂无 MCP 实例</p>
            <p style="font-size:12px;margin-top:4px;">在 extensions/mcps/ 下添加 MCP 子包即可自动发现</p>
        </div>
        <div v-else class="model-list">
            <div
                v-for="mcp in s.mcps"
                :key="mcp.id"
                :class="['model-card', { active: mcp.status === 'running' }]"
            >
                <div class="model-card-header">
                    <span class="model-card-name">{{ mcp.name || mcp.id }}</span>
                    <span :class="mcp.status === 'running' ? 'tag-green' : 'tag-red'">
                        <i :class="['fa-solid', mcp.status === 'running' ? 'fa-circle-check' : 'fa-circle-xmark']"></i>
                        {{ mcp.status === 'running' ? '运行中' : '已停止' }}
                    </span>
                </div>
                <div class="model-card-body">
                    <div class="model-card-field">
                        <label>工具数量</label>
                        <span>{{ mcp.tool_count }}</span>
                    </div>
                    <div class="model-card-field" v-if="mcp.tools && mcp.tools.length">
                        <label>工具列表</label>
                        <span style="font-family:'Fira Code',Consolas,monospace;font-size:11px;">
                            {{ mcp.tools.join(', ') }}
                        </span>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- ═══ 运行 Agent 弹窗（独立于子面板，全局模态） ═══ -->
    <div v-if="runDialogOpen" class="modal-overlay" @click.self="runDialogOpen = false">
        <div class="modal-box">
            <div class="modal-header">
                <h3>
                    <i :class="selectedAgent.icon" style="margin-right:8px;"></i>
                    运行 Agent: {{ selectedAgent.name }}
                </h3>
                <button class="modal-close" @click="runDialogOpen = false">
                    <i class="fa-solid fa-xmark"></i>
                </button>
            </div>
            <div class="modal-body">
                <div class="form-group">
                    <label>任务描述 <span class="req">*</span></label>
                    <textarea
                        v-model="runTask"
                        rows="3"
                        placeholder="描述 Agent 要执行的任务..."
                        style="width:100%;box-sizing:border-box;"
                    ></textarea>
                </div>
                <button
                    class="btn btn-primary"
                    style="width:100%;justify-content:center;"
                    @click="executeAgent()"
                    :disabled="!runTask.trim() || s.agentRunning"
                >
                    <i :class="['fa-solid', s.agentRunning ? 'fa-spinner fa-spin' : 'fa-play']"></i>
                    {{ s.agentRunning ? '执行中...' : '执行任务' }}
                </button>
            </div>
        </div>
    </div>
</div>`,
        data() {
            return {
                activeSub: localStorage.getItem('claw_extTab') || 'agents',
                runDialogOpen: false,
                selectedAgent: {},
                runTask: '',
                tabs: [
                    { id: 'agents', label: '代理', icon: 'fa-solid fa-user-astronaut' },
                    { id: 'skills', label: '技能', icon: 'fa-solid fa-screwdriver-wrench' },
                    { id: 'mcp',    label: 'MCP',  icon: 'fa-solid fa-plug' },
                ],
            };
        },
        setup() {
            const s = window.ClawStore;
            return { s };
        },
        methods: {
            switchTab(tabId) {
                this.activeSub = tabId;
                localStorage.setItem('claw_extTab', tabId);
            },
            openRunDialog(agent) {
                this.selectedAgent = agent;
                this.runTask = '';
                this.runDialogOpen = true;
            },
            async executeAgent() {
                const s = window.ClawStore;
                const agentId = this.selectedAgent.id;
                const task = this.runTask.trim();
                if (!task || s.agentRunning) return;

                this.runDialogOpen = false;
                s.agentRunning = agentId;
                s.activeAgentId = agentId;
                s.agentResult = null;

                try {
                    const res = await fetch('/api/agents/' + agentId + '/run', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ task: task })
                    });
                    const data = await res.json();
                    if (data.status === 'ok') {
                        s.agentResult = data.result;
                    } else {
                        s.agentResult = '[错误] ' + (data.message || '未知错误');
                    }
                } catch (err) {
                    console.error('[extensions panel] 执行失败:', err);
                    s.agentResult = '[错误] 请求失败: ' + err.message;
                } finally {
                    s.agentRunning = null;
                }
            }
        }
    };

})();
