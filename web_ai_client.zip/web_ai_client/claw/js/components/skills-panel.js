/**
 * 技能/工具面板 —— 展示所有已注册的工具（Skills + MCP），含参数定义
 */
(function () {
    'use strict';

    window.ClawComponents = window.ClawComponents || {};
    window.ClawComponents.SkillsPanel = {
        template: /* html */`
<div class="settings-panel">
    <div class="settings-container">
        <h2 class="settings-title"><i class="fa-solid fa-screwdriver-wrench"></i> 已注册工具</h2>
        <p class="settings-desc">所有 LLM 可调用的工具（来自内置 Skills 和 MCP 扩展）</p>

        <!-- 加载中 -->
        <div v-if="s.toolsLoading" class="model-empty">
            <i class="fa-solid fa-spinner fa-spin"></i> 加载中...
        </div>

        <!-- 无工具 -->
        <div v-else-if="s.tools.length === 0" class="model-empty">
            <p><i class="fa-solid fa-circle-exclamation" style="color:var(--text-dim);"></i></p>
            <p>暂无已注册工具</p>
        </div>

        <!-- 工具列表 -->
        <div v-else class="model-list">
            <div v-for="(t, idx) in s.tools" :key="idx" class="model-card">
                <div class="model-card-header">
                    <span class="model-card-name">
                        <code style="color:var(--accent);">{{ t.name }}</code>
                    </span>
                    <span class="model-card-source">{{ t.source }}</span>
                </div>
                <div class="model-card-body">
                    <div class="model-card-field" style="flex:1;min-width:100%;">
                        <label>描述</label>
                        <span>{{ t.description || '(无描述)' }}</span>
                    </div>
                    <!-- 参数表格 -->
                    <div v-if="t.params && t.params.length" class="model-card-field" style="flex:1;min-width:100%;margin-top:8px;">
                        <label>参数定义</label>
                        <table class="params-table">
                            <thead>
                                <tr>
                                    <th>参数</th>
                                    <th>类型</th>
                                    <th>必填</th>
                                    <th>默认值</th>
                                    <th>说明</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr v-for="p in t.params" :key="p.name">
                                    <td><code>{{ p.name }}</code></td>
                                    <td>{{ p.type || '-' }}</td>
                                    <td>{{ p.required ? '✅' : '-' }}</td>
                                    <td><code v-if="p.default != null">{{ p.default }}</code><span v-else>-</span></td>
                                    <td class="param-desc">{{ p.description || '-' }}</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>`,
        setup() {
            const s = window.ClawStore;
            if (s.tools.length === 0 && !s.toolsLoading) {
                s.loadTools();
            }
            return { s };
        }
    };

})();
