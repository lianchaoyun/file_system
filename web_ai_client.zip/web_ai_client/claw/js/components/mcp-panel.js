/**
 * MCP 实例状态面板 —— 展示所有 MCP 实例及其工具
 */
(function () {
    'use strict';

    window.ClawComponents = window.ClawComponents || {};
    window.ClawComponents.McpPanel = {
        template: /* html */`
<div class="settings-panel">
    <div class="settings-container">
        <h2 class="settings-title"><i class="fa-solid fa-plug"></i> MCP 实例</h2>
        <p class="settings-desc">MCP（Model Context Protocol）扩展实例，由 Claw 自动管理生命周期</p>

        <!-- 加载中 -->
        <div v-if="s.mcpsLoading" class="model-empty">
            <i class="fa-solid fa-spinner fa-spin"></i> 加载中...
        </div>

        <!-- 无实例 -->
        <div v-else-if="s.mcps.length === 0" class="model-empty">
            <p><i class="fa-solid fa-circle-exclamation" style="color:var(--text-dim);"></i></p>
            <p>暂无 MCP 实例</p>
            <p style="font-size:12px;margin-top:4px;">在 extensions/mcps/ 下添加 MCP 子包即可自动发现</p>
        </div>

        <!-- 实例卡片列表 -->
        <div v-else class="model-list">
            <div
                v-for="mcp in s.mcps"
                :key="mcp.id"
                :class="['model-card', { active: mcp.status === 'running' }]"
            >
                <div class="model-card-header">
                    <span class="model-card-name">{{ mcp.name || mcp.id }}</span>
                    <span :class="mcp.status === 'running' ? 'tag-green' : 'tag-red'">
                        <i :class="['fa-solid', mcp.status === 'running' ? 'fa-circle-check' : 'fa-circle-xmark']"></i>
                        {{ mcp.status === 'running' ? '运行中' : '已停止' }}
                    </span>
                </div>
                <div class="model-card-body">
                    <div class="model-card-field">
                        <label>工具数量</label>
                        <span>{{ mcp.tool_count }}</span>
                    </div>
                    <div class="model-card-field" v-if="mcp.tools && mcp.tools.length">
                        <label>工具列表</label>
                        <span style="font-family:'Fira Code',Consolas,monospace;font-size:11px;">
                            {{ mcp.tools.join(', ') }}
                        </span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>`,
        setup() {
            const s = window.ClawStore;
            // 首次挂载时加载
            if (s.mcps.length === 0 && !s.mcpsLoading) {
                s.loadMcps();
            }
            return { s };
        }
    };

})();
