/**
 * 占位面板 —— 非聊天/设置 Tab 的占位显示
 */
(function () {
    'use strict';

    window.ClawComponents = window.ClawComponents || {};
    window.ClawComponents.Placeholder = {
        template: /* html */`
<div class="placeholder-panel">
    <i class="fa-solid fa-cubes" style="font-size:48px;margin-bottom:16px;color:var(--accent);"></i>
    <h2>{{ s.getActiveLabel() }} 业务面板占位</h2>
    <p style="color:var(--text-dim);">Cobuddy 可在此处直接嵌入对应的业务组件。</p>
</div>`,
        setup() {
            const s = window.ClawStore;
            return { s };
        }
    };

})();
