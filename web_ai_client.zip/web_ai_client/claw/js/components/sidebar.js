/**
 * 侧边栏组件 —— Logo / 菜单 / 设置 / 折叠
 */
(function () {
    'use strict';

    window.ClawComponents = window.ClawComponents || {};
    window.ClawComponents.Sidebar = {
        template: /* html */`
<aside :class="['sidebar', { 'collapsed': isCollapsed }]">

    <div class="sidebar-logo" @click="goYunHub" title="返回 YunHub 首页">
        <div class="logo-box">
            <span class="logo-icon"><i class="fa-solid fa-robot"></i></span>
            <span class="logo-text">龙虾</span>
            <span class="logo-badge">PRO</span>
        </div>
    </div>

    <nav class="sidebar-menu">
        <template v-for="item in s.menuItems" :key="item.id">
            <div v-if="item.divider" class="menu-divider">
                <span v-if="item.label" class="menu-divider-label">{{ item.label }}</span>
                <span v-else class="menu-divider-line"></span>
            </div>
            <button
                v-else-if="!item.external"
                :class="['menu-item', { active: s.activeTab === item.id }]"
                @click="s.activeTab = item.id"
                :title="isCollapsed ? item.label : ''"
            >
                <span class="menu-icon"><i :class="item.icon"></i></span>
                <span class="menu-label">{{ item.label }}</span>
            </button>
            <a
                v-else
                :class="['menu-item']"
                :href="item.url"
                :title="isCollapsed ? item.label : ''"
            >
                <span class="menu-icon"><i :class="item.icon"></i></span>
                <span class="menu-label">{{ item.label }}</span>
            </a>
        </template>
    </nav>

    <div class="sidebar-spacer"></div>

    <div class="sidebar-footer">
        <button
            :class="['menu-item', { active: s.activeTab === 'settings' }]"
            @click="s.activeTab = 'settings'"
            :title="isCollapsed ? '设置' : ''"
        >
            <span class="menu-icon"><i class="fa-solid fa-gear"></i></span>
            <span class="menu-label">设置</span>
        </button>
    </div>

    <div class="sidebar-user" v-if="s.currentUser">
        <!-- 侧边栏头像 - 使用真实图片 -->
        <img 
            v-if="s.currentUser.avatar_url"
            :src="s.currentUser.avatar_url" 
            alt="avatar"
            class="sidebar-user-avatar sidebar-user-avatar-img"
            @click="toggleUserMenu"
            :title="isCollapsed ? '点击显示用户菜单' : ''"
        />
        <!-- 如果没有头像，显示首字母 -->
        <span 
            v-else
            class="sidebar-user-avatar" 
            @click="toggleUserMenu"
            :title="isCollapsed ? '点击显示用户菜单' : ''"
        >{{ (s.currentUser.account || '?')[0] }}</span>
        <div class="sidebar-user-info" v-if="!isCollapsed">
            <span class="sidebar-user-name">{{ s.currentUser.account }}</span>
            <span class="sidebar-user-role">{{ s.currentUser.role || 'user' }}</span>
        </div>

        <!-- 用户菜单弹窗 - 居中浮动 -->
        <div v-if="showUserMenu" class="user-menu-overlay" @click="closeUserMenu">
            <div class="user-menu-modal" @click.stop>
                <button class="user-menu-close" @click="closeUserMenu">
                    <i class="fa-solid fa-xmark"></i>
                </button>
                
                <div class="user-menu-email">{{ s.currentUser.email || '' }}</div>
                
                <!-- 弹窗大头像 - 使用真实图片 -->
                <div class="user-menu-avatar-large-wrapper">
                    <img 
                        v-if="s.currentUser.avatar_url"
                        :src="s.currentUser.avatar_url" 
                        alt="avatar"
                        class="user-menu-avatar-large user-menu-avatar-img"
                    />
                    <div v-else class="user-menu-avatar-large">
                        {{ (s.currentUser.account || '?')[0] }}
                        <span class="avatar-edit-icon"><i class="fa-solid fa-camera"></i></span>
                    </div>
                    <span v-if="s.currentUser.avatar_url" class="avatar-edit-icon"><i class="fa-solid fa-camera"></i></span>
                </div>
                
                <div class="user-menu-greeting">{{ s.currentUser.account }}, 您好!</div>
                
                <div class="user-menu-actions">
                    <button class="user-action-btn user-action-logout" @click="s.doLogout">
                        <i class="fa-solid fa-arrow-right-from-bracket"></i>
                        <span>退出账号</span>
                    </button>
                </div>
            </div>
        </div>
    </div>
</aside>`,
        setup() {
            const s = window.ClawStore;
            const goYunHub = () => { window.location.href = '/'; };
            const showUserMenu = Vue.ref(false);

            console.log('[Sidebar] 组件初始化');
            console.log('[Sidebar] currentUser:', s.currentUser);
            console.log('[Sidebar] isCollapsed (ref):', s.isCollapsed);
            console.log('[Sidebar] isCollapsed (value):', s.isCollapsed.value);
            console.log('[Sidebar] localStorage user:', localStorage.getItem('user'));

            function toggleUserMenu() {
                console.log('[Sidebar] ========== 点击头像 ==========');
                console.log('[Sidebar] toggleUserMenu called, current:', showUserMenu.value);
                showUserMenu.value = !showUserMenu.value;
                console.log('[Sidebar] after toggle:', showUserMenu.value);
                console.log('[Sidebar] showUserMenu.value === true?', showUserMenu.value === true);
            }

            function closeUserMenu() {
                console.log('[Sidebar] closeUserMenu');
                showUserMenu.value = false;
            }

            // 点击外部关闭菜单
            function handleClickOutside(e) {
                if (showUserMenu.value && !e.target.closest('.user-menu-modal') && !e.target.closest('.sidebar-user-avatar')) {
                    console.log('[Sidebar] click outside, closing menu');
                    closeUserMenu();
                }
            }

            Vue.onMounted(() => {
                document.addEventListener('click', handleClickOutside);
            });

            Vue.onUnmounted(() => {
                document.removeEventListener('click', handleClickOutside);
            });

            return { 
                s, 
                goYunHub, 
                isCollapsed: s.isCollapsed, // 保持响应式引用
                showUserMenu,
                toggleUserMenu,
                closeUserMenu
            };
        }
    };

})();
