/**
 * ================================================================
 * 任务页面 —— 独立全页面组件 (占满内容区)
 * ================================================================
 * 从 financial-view.js 中提取，作为独立的左侧 tab 页面
 */
(function () {
    'use strict';

    var { ref, computed, watch, onMounted } = Vue;

    var API_BASE = '';
    var SELECTED_TERM_KEY = 'claw_task_selected_term_id';

    window.ClawComponents = window.ClawComponents || {};
    window.ClawComponents.TaskPage = {
        name: 'TaskPage',
        template: /*html*/`
<div class="task-page">
    <div class="task-page-inner">
        <!-- 工具栏 -->
        <div class="task-toolbar">
            <div class="task-category-tabs">
                <span class="task-cat-tab" :class="{ active: selectedTermId === null }"
                      @click="selectedTermId = null; taskPage=1; fetchTasks()">全部</span>
                <span v-if="hasUncategorized" class="task-cat-tab" :class="{ active: selectedTermId === 0 }"
                      @click="selectedTermId = 0; taskPage=1; fetchTasks()">未分类</span>
                <span v-for="cat in taskCategories" :key="cat.term_id"
                      class="task-cat-tab"
                      :class="{ active: selectedTermId === cat.term_id }"
                      @click="selectedTermId = cat.term_id; taskPage=1; fetchTasks()">
                    {{ cat.name }}
                </span>
            </div>
            <div class="task-toolbar-row">
                <input class="task-search-input" v-model="taskSearch" placeholder="搜索任务..." @keyup.enter="taskPage=1; fetchTasks()" />
                <span class="task-total-count">共 {{ taskTotal }} 条</span>
                <div style="flex:1"></div>
                <label class="task-toggle-switch" :class="{ on: showHidden }" @click="showHidden = !showHidden" title="显示隐藏">
                    <span class="task-toggle-knob"></span>
                </label>
                <span class="task-filter-label" @click="showHidden = !showHidden">隐藏</span>
                <button class="task-toolbar-btn task-btn-create" @click="openTaskCreate" title="新建任务">
                    <i class="fa-solid fa-plus"></i>
                </button>
                <button class="task-toolbar-btn" @click="taskPage=1; fetchTasks()" title="刷新">
                    <i class="fa-solid fa-rotate"></i>
                </button>
            </div>
        </div>

        <!-- 任务列表 -->
        <div class="task-list" v-if="!taskLoading">
            <div v-if="displayTasks.length === 0" class="task-empty">{{ showHidden ? '暂无任务' : '没有可见任务' }}</div>
            <div v-for="task in displayTasks" :key="task.id" class="task-item">
                <div class="task-item-left">
                    <label class="task-toggle-switch" :class="{ on: task.enabled === 1 }" @click.stop="toggleTask(task)">
                        <span class="task-toggle-knob"></span>
                    </label>
                    <div class="task-item-info">
                        <div class="task-item-name-row">
                            <span class="task-item-name">{{ task.name }}</span>
                            <span class="task-dot" :class="taskStatusClass(task.run_status)"></span>
                            <span class="task-status-text" :class="taskStatusClass(task.run_status)">{{ taskStatusText(task.run_status) }}</span>
                        </div>
                        <div class="task-item-meta">
                            <span>Cron: {{ task.cron_expr }}</span>
                            <span>类型: {{ task.exec_type }}</span>
                            <span>{{ task.run_mode === 'external' ? '弹窗' : '内部' }}</span>
                            <span v-if="task.last_run">上次: {{ fmtDateTime(task.last_run) }}</span>
                        </div>
                    </div>
                </div>
                <div class="task-item-right">
                    <button class="task-btn run" @click.stop="triggerExecute(task)">
                        <svg width="10" height="10" viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg>
                        执行
                    </button>
                    <div class="task-actions-wrap">
                        <button class="task-btn" @click.stop="toggleTaskActions(task.id)">⋮</button>
                        <div v-if="showTaskActions && actionsTaskId === task.id" class="task-actions-dropdown" @click.stop>
                            <div class="task-dropdown-item" @click="openTaskLogs(task)">📋 日志</div>
                            <div class="task-dropdown-item" @click="openTaskEdit(task)">✏️ 编辑</div>
                            <div class="task-dropdown-item" @click="toggleHiddenTask(task)">{{ task.hidden === 1 ? '👁 显示' : '🙈 隐藏' }}</div>
                            <div class="task-dropdown-item danger" @click="deleteTask(task)">🗑 删除</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div v-else class="task-loading">加载中...</div>

        <!-- 分页 -->
        <div class="task-pagination" v-if="taskPageCount > 1">
            <button :disabled="taskPage <= 1" @click="changeTaskPage(taskPage - 1)">‹</button>
            <span>{{ taskPage }} / {{ taskPageCount }}</span>
            <button :disabled="taskPage >= taskPageCount" @click="changeTaskPage(taskPage + 1)">›</button>
        </div>
    </div>

    <!-- 任务编辑弹窗 -->
    <div v-if="showTaskEditModal" class="task-modal-overlay" @click.self="showTaskEditModal = false">
        <div class="task-modal task-edit-modal">
            <div class="task-modal-header">
                <h3>{{ isTaskCreate ? '新增任务' : '编辑任务' }}</h3>
                <button class="task-modal-close" @click="showTaskEditModal = false">✕</button>
            </div>
            <div class="task-modal-body">
                <div class="task-form-group">
                    <label>任务名称 <span class="task-required">*</span></label>
                    <input v-model="taskEditForm.name" placeholder="例：每日数据同步" />
                    <span class="task-form-error" v-if="taskEditErrors.name">{{ taskEditErrors.name }}</span>
                </div>
                <div class="task-form-group">
                    <label>任务描述</label>
                    <textarea v-model="taskEditForm.desc" rows="2" placeholder="可选的描述信息"></textarea>
                </div>
                <div class="task-form-group">
                    <label>任务分类</label>
                    <select v-model="taskEditForm.term_id">
                        <option :value="0">未分类</option>
                        <option v-for="cat in taskCategories" :key="cat.term_id"
                                :value="cat.term_id">{{ cat.name }}</option>
                    </select>
                </div>
                <div class="task-form-group">
                    <label>执行类型</label>
                    <select v-model="taskEditForm.exec_type">
                        <option value="shell">Shell 命令</option>
                        <option value="http">HTTP 请求</option>
                    </select>
                </div>
                <div class="task-form-group" v-if="taskEditForm.exec_type === 'shell'">
                    <label>执行模式</label>
                    <select v-model="taskEditForm.run_mode">
                        <option value="external">外部弹窗执行</option>
                        <option value="internal">内部静默执行</option>
                    </select>
                </div>
                <div class="task-form-group">
                    <label>{{ taskEditForm.exec_type === 'shell' ? '执行命令' : '请求 URL' }} <span class="task-required">*</span></label>
                    <textarea v-model="taskEditForm.command" rows="3" :placeholder="taskEditForm.exec_type === 'shell' ? '例：cd /app && python sync.py' : '例：https://example.com/api/sync'"></textarea>
                    <span class="task-form-error" v-if="taskEditErrors.command">{{ taskEditErrors.command }}</span>
                </div>
                <div class="task-form-group" v-if="taskEditForm.exec_type === 'shell'">
                    <label>工作目录</label>
                    <input v-model="taskEditForm.working_dir" placeholder="例：/home/user/scripts" />
                </div>
                <div class="task-form-group">
                    <label>Cron 表达式</label>
                    <div class="task-cron-row">
                        <input v-model="taskEditForm.cron_expr" placeholder="例：0 3 * * *" />
                        <select @change="setCronPreset($event.target.value)">
                            <option value="">快捷选择</option>
                            <option v-for="p in cronPresets" :key="p.value" :value="p.value">{{ p.label }} ({{ p.value }})</option>
                        </select>
                    </div>
                </div>
            </div>
            <div class="task-modal-footer">
                <button class="task-btn-cancel" @click="showTaskEditModal = false">取消</button>
                <button class="task-btn-primary" @click="submitTaskForm" :disabled="taskEditSubmitting">{{ taskEditSubmitting ? '提交中...' : '保存' }}</button>
            </div>
        </div>
    </div>

    <!-- 日志弹窗 -->
    <div v-if="showTaskLogModal" class="task-modal-overlay" @click.self="showTaskLogModal = false">
        <div class="task-modal task-log-modal">
            <div class="task-modal-header">
                <h3>执行日志 — {{ logTaskName }}</h3>
                <button class="task-toolbar-btn" @click="fetchTaskLogs" title="刷新">↻</button>
                <button class="task-toolbar-btn" @click="clearTaskLogs" title="清空">清空</button>
                <button class="task-modal-close" @click="showTaskLogModal = false">✕</button>
            </div>
            <div class="task-log-body" v-if="!taskLogLoading">
                <div v-if="taskLogs.length === 0" class="task-empty">暂无日志</div>
                <div v-for="log in taskLogs" :key="log.id" class="task-log-row" @click="openLogDetail(log)">
                    <span class="task-log-dot" :class="logStatusClass(log.status)"></span>
                    <span class="task-log-status">{{ log.status }}</span>
                    <span class="task-log-time">{{ fmtDateTime(log.start_time) }}</span>
                    <span class="task-log-duration">{{ fmtDuration(log.duration_ms) }}</span>
                    <span class="task-log-more">→</span>
                </div>
            </div>
            <div v-else class="task-loading">加载中...</div>
            <div class="task-pagination" v-if="logPageCount > 1">
                <button :disabled="logPage <= 1" @click="changeLogPage(logPage - 1)">‹</button>
                <span>{{ logPage }} / {{ logPageCount }}</span>
                <button :disabled="logPage >= logPageCount" @click="changeLogPage(logPage + 1)">›</button>
            </div>
        </div>
    </div>

    <!-- 日志详情弹窗 -->
    <div v-if="showLogDetailModal" class="task-modal-overlay" @click.self="showLogDetailModal = false">
        <div class="task-modal task-detail-modal">
            <div class="task-modal-header">
                <h3>日志详情 #{{ detailLog.id }}</h3>
                <button class="task-modal-close" @click="showLogDetailModal = false">✕</button>
            </div>
            <div class="task-modal-body" v-if="detailLog">
                <div class="task-detail-row"><label>状态：</label><span :class="logStatusClass(detailLog.status)">{{ detailLog.status }}</span></div>
                <div class="task-detail-row"><label>开始：</label><span>{{ fmtDateTime(detailLog.start_time) }}</span></div>
                <div class="task-detail-row"><label>结束：</label><span>{{ fmtDateTime(detailLog.end_time) }}</span></div>
                <div class="task-detail-row"><label>耗时：</label><span>{{ fmtDuration(detailLog.duration_ms) }}</span></div>
                <div class="task-detail-section" v-if="detailLog.output"><h4>标准输出</h4><pre class="task-log-output">{{ detailLog.output }}</pre></div>
                <div class="task-detail-section" v-if="detailLog.error"><h4>错误输出</h4><pre class="task-log-error">{{ detailLog.error }}</pre></div>
            </div>
        </div>
    </div>

    <!-- 命令弹窗 -->
    <div v-if="showCmdPopup" class="task-modal-overlay" @click.self="showCmdPopup = false">
        <div class="task-modal task-cmd-popup">
            <div class="task-modal-header">
                <h3>已启动执行</h3>
                <button class="task-modal-close" @click="showCmdPopup = false">✕</button>
            </div>
            <div class="task-modal-body">
                <p class="task-cmd-hint">{{ cmdPopupMode === 'external' ? '命令已在独立窗口中运行：' : '命令已在后台静默执行：' }}</p>
                <div class="task-cmd-copy-row">
                    <code class="task-cmd-text">{{ cmdPopupText }}</code>
                    <button class="task-btn-copy" @click="copyCmd">复制</button>
                </div>
            </div>
        </div>
    </div>
</div>`,
        setup: function () {
            var finStore = window.FinancialStore;

            // ═══ 状态 ═══
            var taskLoading = ref(false);
            var taskSearch = ref('');
            var taskPage = ref(1), taskLimit = 20, taskTotal = ref(0);
            var showHidden = ref(false);
            var selectedTermId = ref(null);
            var taskCategories = ref([]);
            var hasUncategorized = ref(false);
            var showTaskActions = ref(false), actionsTaskId = ref(null);
            var showTaskEditModal = ref(false), isTaskCreate = ref(false), taskEditSubmitting = ref(false), editingTaskId = ref(null);
            var taskEditForm = ref({ name: '', desc: '', exec_type: 'shell', run_mode: 'external', command: '', working_dir: '', cron_expr: '0 * * * *', term_id: 0 });
            var taskEditErrors = ref({});
            var showTaskLogModal = ref(false), logTaskId = ref(null), logTaskName = ref('');
            var taskLogs = ref([]), taskLogLoading = ref(false), logPage = ref(1), logTotal = ref(0), logLimit = 15;
            var showLogDetailModal = ref(false), detailLog = ref(null);
            var showCmdPopup = ref(false), cmdPopupText = ref(''), cmdPopupMode = ref('');

            var cronPresets = [
                { label: '每分钟', value: '* * * * *' }, { label: '每5分钟', value: '*/5 * * * *' },
                { label: '每15分钟', value: '*/15 * * * *' }, { label: '每30分钟', value: '*/30 * * * *' },
                { label: '每小时', value: '0 * * * *' }, { label: '每2小时', value: '0 */2 * * *' },
                { label: '每天0点', value: '0 0 * * *' }, { label: '每天6点', value: '0 6 * * *' },
                { label: '每天9点', value: '0 9 * * *' }, { label: '每周一9点', value: '0 9 * * 1' },
                { label: '每月1号0点', value: '0 0 1 * *' },
            ];

            var taskPageCount = computed(function () { return Math.ceil(taskTotal.value / taskLimit) || 1; });
            var displayTasks = computed(function () {
                if (showHidden.value) return finStore.taskList;
                return (finStore.taskList || []).filter(function (t) { return t.hidden !== 1; });
            });
            var logPageCount = computed(function () { return Math.ceil(logTotal.value / logLimit) || 1; });

            // ═══ 辅助函数 ═══
            function taskStatusClass(s) { var map = { idle: 'gray', running: 'blue', success: 'green', failed: 'red' }; return map[s] || 'gray'; }
            function taskStatusText(s) { var map = { idle: '空闲', running: '运行中', success: '成功', failed: '失败' }; return map[s] || s; }
            function logStatusClass(s) { var map = { running: 'blue', success: 'green', failed: 'red' }; return map[s] || 'gray'; }
            function fmtDateTime(d) { if (!d) return '-'; return d.replace('T', ' ').substring(0, 19); }
            function fmtDuration(ms) { if (ms == null) return '-'; if (ms < 1000) return ms + 'ms'; return (ms / 1000).toFixed(1) + 's'; }

            // ═══ API 方法 ═══
            async function fetchTasks() {
                taskLoading.value = true;
                try {
                    var params = new URLSearchParams({ page: taskPage.value, limit: taskLimit });
                    if (taskSearch.value.trim()) params.set('search', taskSearch.value.trim());
                    if (selectedTermId.value !== null) params.set('term_id', selectedTermId.value);
                    var res = await fetch(API_BASE + '/tasks?' + params).then(function (r) { return r.json(); });
                    if (res.code === 0) { finStore.taskList = res.data.items || []; taskTotal.value = res.data.total || 0; }
                } catch (e) { console.error('获取任务列表失败:', e); }
                finally { taskLoading.value = false; }
            }
            async function fetchTaskCategories() {
                try {
                    var res = await fetch(API_BASE + '/terms?group=task').then(function (r) { return r.json(); });
                    if (res.code === 0) taskCategories.value = res.data || [];
                } catch (e) {}
            }
            async function checkUncategorized() {
                try {
                    var params = new URLSearchParams({ term_id: 0, limit: 1 });
                    if (!showHidden.value) params.set('hidden', 0);
                    var res = await fetch(API_BASE + '/tasks?' + params).then(function (r) { return r.json(); });
                    if (res.code === 0) hasUncategorized.value = (res.data.total || 0) > 0;
                } catch (e) {}
            }
            async function toggleTask(task) {
                try {
                    var res = await fetch(API_BASE + '/tasks/toggle?id=' + task.id).then(function (r) { return r.json(); });
                    if (res.code === 0) task.enabled = res.data.enabled;
                } catch (e) {}
            }
            async function triggerExecute(task) {
                showTaskActions.value = false;
                var origStatus = task.run_status;
                task.run_status = 'running';
                try {
                    var res = await fetch(API_BASE + '/tasks/execute?id=' + task.id).then(function (r) { return r.json(); });
                    if (res.code === 0) {
                        await fetchTasks();
                        if (task.run_mode === 'internal') {
                            var dirHint = task.working_dir ? 'cd /d ' + task.working_dir + ' && ' : '';
                            cmdPopupText.value = dirHint + task.command;
                            cmdPopupMode.value = 'internal';
                            showCmdPopup.value = true;
                        }
                    } else { task.run_status = origStatus; alert(res.msg || '执行失败'); }
                } catch (e) { task.run_status = origStatus; }
            }
            async function deleteTask(task) {
                showTaskActions.value = false;
                if (!confirm('确定删除任务「' + task.name + '」？')) return;
                try { await fetch(API_BASE + '/tasks/delete?id=' + task.id).then(function (r) { return r.json(); }); await fetchTasks(); } catch (e) {}
            }
            function toggleTaskActions(taskId) {
                if (showTaskActions.value && actionsTaskId.value === taskId) showTaskActions.value = false;
                else { actionsTaskId.value = taskId; showTaskActions.value = true; }
            }

            function openTaskCreate() {
                isTaskCreate.value = true;
                editingTaskId.value = null;
                taskEditForm.value = { name: '', desc: '', exec_type: 'shell', run_mode: 'external', command: '', working_dir: '', cron_expr: '0 * * * *', term_id: 0 };
                taskEditErrors.value = {};
                showTaskEditModal.value = true;
            }
            function openTaskEdit(task) {
                showTaskActions.value = false;
                isTaskCreate.value = false;
                editingTaskId.value = task.id;
                taskEditForm.value = {
                    name: task.name, desc: task.desc || '', exec_type: task.exec_type || 'shell',
                    run_mode: task.run_mode || 'external', command: task.command,
                    working_dir: task.working_dir || '', cron_expr: task.cron_expr || '0 * * * *',
                    term_id: task.term_id || 0,
                };
                taskEditErrors.value = {};
                showTaskEditModal.value = true;
            }
            async function submitTaskForm() {
                var errs = {};
                if (!taskEditForm.value.name.trim()) errs.name = '名称不能为空';
                if (!taskEditForm.value.command.trim()) errs.command = '命令不能为空';
                if (Object.keys(errs).length) { taskEditErrors.value = errs; return; }
                taskEditSubmitting.value = true;
                try {
                    var url = isTaskCreate.value ? API_BASE + '/tasks/create' : API_BASE + '/tasks/update?id=' + editingTaskId.value;
                    var body = JSON.stringify({
                        name: taskEditForm.value.name.trim(), desc: taskEditForm.value.desc.trim() || null,
                        exec_type: taskEditForm.value.exec_type, run_mode: taskEditForm.value.run_mode,
                        command: taskEditForm.value.command.trim(), working_dir: taskEditForm.value.working_dir.trim() || null,
                        cron_expr: taskEditForm.value.cron_expr,
                        term_id: taskEditForm.value.term_id,
                    });
                    var res = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: body }).then(function (r) { return r.json(); });
                    if (res.code === 0) { showTaskEditModal.value = false; await fetchTasks(); }
                    else alert(res.msg || '操作失败');
                } catch (e) { alert('网络错误'); }
                finally { taskEditSubmitting.value = false; }
            }
            function setCronPreset(val) { if (val) taskEditForm.value.cron_expr = val; }

            async function openTaskLogs(task) {
                showTaskActions.value = false;
                logTaskId.value = task.id; logTaskName.value = task.name;
                logPage.value = 1; showTaskLogModal.value = true;
                await fetchTaskLogs();
            }
            async function fetchTaskLogs() {
                taskLogLoading.value = true;
                try {
                    var params = new URLSearchParams({ task_id: logTaskId.value, page: logPage.value, limit: logLimit });
                    var res = await fetch(API_BASE + '/task-logs?' + params).then(function (r) { return r.json(); });
                    if (res.code === 0) { taskLogs.value = res.data.items || []; logTotal.value = res.data.total || 0; }
                } catch (e) {}
                finally { taskLogLoading.value = false; }
            }
            async function clearTaskLogs() {
                if (!confirm('确定清空「' + logTaskName.value + '」的全部日志？')) return;
                try {
                    await fetch(API_BASE + '/task-logs/clear?task_id=' + logTaskId.value).then(function (r) { return r.json(); });
                    await fetchTaskLogs();
                } catch (e) {}
            }
            function openLogDetail(log) { detailLog.value = log; showLogDetailModal.value = true; }
            async function toggleHiddenTask(task) {
                showTaskActions.value = false;
                try {
                    var res = await fetch(API_BASE + '/tasks/toggle-hidden?id=' + task.id).then(function (r) { return r.json(); });
                    if (res.code === 0) task.hidden = res.data.hidden;
                } catch (e) {}
            }
            function changeTaskPage(p) { taskPage.value = p; fetchTasks(); }
            function changeLogPage(p) { logPage.value = p; fetchTaskLogs(); }
            function copyCmd() { navigator.clipboard.writeText(cmdPopupText.value)['catch'](function () {}); }

            // ═══ 初始化 ═══
            watch(showHidden, async function () {
                await checkUncategorized();
                if (selectedTermId.value === 0 && !hasUncategorized.value) {
                    selectedTermId.value = null;
                    taskPage.value = 1;
                    fetchTasks();
                }
            });
            watch(selectedTermId, function (val) {
                if (val === null || val === undefined) {
                    localStorage.removeItem(SELECTED_TERM_KEY);
                } else {
                    localStorage.setItem(SELECTED_TERM_KEY, String(val));
                }
            });
            onMounted(async function () {
                await Promise.all([fetchTaskCategories(), checkUncategorized()]);
                var saved = localStorage.getItem(SELECTED_TERM_KEY);
                if (saved !== null) {
                    var savedId = Number(saved);
                    if (savedId === 0 && hasUncategorized.value) {
                        selectedTermId.value = 0;
                    } else if (savedId && taskCategories.value.some(function (c) { return c.term_id === savedId; })) {
                        selectedTermId.value = savedId;
                    } else {
                        selectedTermId.value = null;
                    }
                }
                fetchTasks();
            });

            return {
                taskLoading, taskSearch, taskPage, taskTotal, taskPageCount,
                showHidden, selectedTermId, taskCategories, hasUncategorized, displayTasks,
                showTaskActions, actionsTaskId,
                showTaskEditModal, isTaskCreate, taskEditSubmitting, taskEditForm, taskEditErrors,
                showTaskLogModal, logTaskId, logTaskName, taskLogs, taskLogLoading, logPage, logTotal, logPageCount,
                showLogDetailModal, detailLog,
                showCmdPopup, cmdPopupText, cmdPopupMode, cronPresets,
                fetchTasks, fetchTaskCategories, toggleTask, triggerExecute, deleteTask, toggleTaskActions,
                openTaskCreate, openTaskEdit, submitTaskForm, setCronPreset,
                openTaskLogs, fetchTaskLogs, clearTaskLogs, openLogDetail,
                toggleHiddenTask, changeTaskPage, changeLogPage, copyCmd,
                taskStatusClass, taskStatusText, logStatusClass, fmtDateTime, fmtDuration,
            };
        }
    };

    console.log('[task-page] 任务页面组件已就绪 ✓');
})();
