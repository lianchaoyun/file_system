/**
 * ================================================================
 * 龙虾 —— 全局响应式状态仓库
 * ================================================================
 * 所有共享状态 + API 方法集中管理，组件通过 inject 访问
 */
(function () {
    'use strict';

    const { ref, nextTick, watch } = Vue;

    // ════════════════════════════════════════
    //  用户 / 认证
    // ════════════════════════════════════════
    const currentUser = ref((function () {
        try {
            var u = JSON.parse(localStorage.getItem('user'));
            if (!u || !u.token) return null;
            // 确保有昵称和账号字段
            return {
                account: u.account || u.username || '',
                nickname: u.nickname || u.name || u.account || '',
                email: u.email || '',
                role: u.role || 'user',
                token: u.token,
                ...u  // 保留其他字段
            };
        } catch (e) { 
            return null; 
        }
    })());

    function doLogout() {
        localStorage.removeItem('user');
        localStorage.removeItem('yun_token');
        window.location.href = '/apps/yunhub/login.html?redirect=/apps/claw/';
    }

    // ════════════════════════════════════════
    //  侧边栏 / 路由
    // ════════════════════════════════════════
    const isCollapsed = ref(true); // 默认折叠状态（重要！）
    const mobileSidebarOpen = ref(false);
    const activeTab = ref(localStorage.getItem('claw_activeTab') || 'chat');
    const menuItems = ref(window.MENU_CONFIG ? window.MENU_CONFIG.items : []);

    // tab 变化时持久化
    watch(activeTab, function (val) {
        localStorage.setItem('claw_activeTab', val);
        mobileSidebarOpen.value = false; // 移动端切换 tab 后关闭侧边栏
    });

    // ════════════════════════════════════════
    //  会话
    // ════════════════════════════════════════
    const sessions = ref([]);
    const sessionId = ref(localStorage.getItem('claw_sessionId') || 'default');
    const sessionsLoading = ref(false);

    // 会话切换时持久化
    watch(sessionId, function (val) {
        if (val && val !== 'default') {
            localStorage.setItem('claw_sessionId', val);
        }
    });

    // ════════════════════════════════════════
    //  消息
    // ════════════════════════════════════════
    const messages = ref([]);
    const inputText = ref('');
    const streaming = ref(false);
    const streamContent = ref('');
    const streamHtml = ref('');
    const userScrolledAway = ref(false);
    function setUserScrolledAway(v) { userScrolledAway.value = v; }

    /** 预渲染消息的 html 字段 */
    function preRenderMsg(msg) {
        if (msg.html) return msg;
        var copy = Object.assign({}, msg);
        copy.html = window.renderMarkdown
            ? window.renderMarkdown(copy.content || '')
            : (copy.content || '');
        return copy;
    }

    function scrollBottom(force) {
        if (force) userScrolledAway.value = false;
        nextTick(function () {
            if (!force && userScrolledAway.value) return;
            var el = document.querySelector('.chat-messages');
            if (el) {
                el.scrollTop = el.scrollHeight;
            }
        });
    }

    // ════════════════════════════════════════
    //  模型管理
    // ════════════════════════════════════════
    const modelList = ref([]);
    const activeModel = ref(null);
    const chatModelDropdown = ref(false);  // 聊天面板模型下拉
    const modelEditorOpen = ref(false);
    const editingModel = ref(null);
    const modelSaving = ref(false);
    const modelForm = ref({
        model_id: '', name: '', base_url: '', model: '',
        api_key: 'ollama', max_tokens: 4096, temperature: 0.7, timeout: 120,
        supports_tools: true,
    });

    // ════════════════════════════════════════
    //  模型扫描
    // ════════════════════════════════════════
    const scanning = ref(false);
    const scanResult = ref([]);
    const scanDialogOpen = ref(false);
    const scanBaseUrl = ref('http://localhost:11434/v1');
    const scanApiKey = ref('ollama');
    const selectedScanModels = ref({});

    // ════════════════════════════════════════
    //  会话 API
    // ════════════════════════════════════════

    async function loadSessions() {
        sessionsLoading.value = true;
        try {
            const res = await fetch('/api/sessions');
            if (!res.ok) throw new Error('HTTP ' + res.status);
            const data = await res.json();
            sessions.value = data.sessions || [];
        } catch (err) {
            console.error('[store] 加载会话列表失败:', err);
            sessions.value = [];
        } finally {
            sessionsLoading.value = false;
        }
    }

    async function loadMessages(sid) {
        try {
            const res = await fetch('/api/sessions/' + sid + '/messages');
            if (!res.ok) throw new Error('HTTP ' + res.status);
            const data = await res.json();
            let list = data.messages && data.messages.length > 0
                ? data.messages
                : [{ role: 'assistant', content: '开始新的对话吧！' }];
            list = list.map(preRenderMsg);
            messages.value = list;
        } catch (err) {
            console.error('[store] 加载消息失败:', err);
            messages.value = [{ role: 'assistant', content: '历史消息加载失败。', html: '<p>历史消息加载失败。</p>' }];
        }
    }

    async function switchSession(sid) {
        if (sid === sessionId.value) return;
        sessionId.value = sid;
        activeTab.value = 'chat';
        streaming.value = false;
        streamContent.value = '';
        streamHtml.value = '';
        inputText.value = '';
        await loadMessages(sid);
        scrollBottom(true);
    }

    async function newSession() {
        const ts = new Date().toISOString().replace(/[:.]/g, '-');
        const sid = 'session-' + ts;
        sessions.value.unshift({ id: sid, title: '新对话', msg_count: 0 });
        sessionId.value = sid;
        messages.value = [preRenderMsg({ role: 'assistant', content: '开始新的对话吧！' })];
        activeTab.value = 'chat';
        inputText.value = '';
        streaming.value = false;
        streamContent.value = '';
        streamHtml.value = '';
        try {
            await fetch('/api/sessions', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ id: sid })
            });
        } catch (e) {
            console.error('[store] 持久化新会话失败:', e);
        }
    }

    async function renameSession(sid, newTitle) {
        if (!newTitle || !newTitle.trim()) return;
        const title = newTitle.trim();
        // 乐观更新本地
        const sess = sessions.value.find(function (s) { return s.id === sid; });
        const oldTitle = sess ? sess.title : '';
        if (sess) sess.title = title;
        try {
            const res = await fetch('/api/sessions/' + sid, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ title: title })
            });
            if (!res.ok) {
                if (sess) sess.title = oldTitle;
                console.error('[store] 重命名会话失败, HTTP', res.status);
            }
        } catch (e) {
            console.error('[store] 重命名会话请求失败:', e);
            if (sess) sess.title = oldTitle;
        }
    }

    async function deleteSession(sid) {
        let deleted = false;
        try {
            const res = await fetch('/api/sessions/' + sid, { method: 'DELETE' });
            if (res.ok) deleted = true;
            else console.error('[store] 删除会话失败, HTTP', res.status);
        } catch (e) {
            console.error('[store] 删除会话请求失败:', e);
        }
        if (!deleted) { alert('删除失败，请稍后重试'); return; }
        sessions.value = sessions.value.filter(function (s) { return s.id !== sid; });
        if (sessionId.value === sid) {
            if (sessions.value.length > 0) {
                switchSession(sessions.value[0].id);
            } else {
                sessionId.value = '';
            }
        }
    }

    function formatSessionDate(sid) {
        // session id 格式: session-2026-06-21T09-13-38-078Z
        const m = sid.match(/(\d{4}-\d{2}-\d{2})T(\d{2})-(\d{2})-(\d{2})/);
        if (m) return m[1] + ' ' + m[2] + ':' + m[3] + ':' + m[4];
        const m2 = sid.match(/(\d{4}-\d{2}-\d{2})T(\d{2})-(\d{2})/);
        if (m2) return m2[1] + ' ' + m2[2] + ':' + m2[3];
        return sid.slice(0, 24);
    }

    // ════════════════════════════════════════
    //  消息操作
    // ════════════════════════════════════════

    async function sendMessage() {
        const text = inputText.value.trim();
        if (!text || streaming.value) return;
        if (!sessionId.value) await newSession();

        messages.value.push(preRenderMsg({ role: 'user', content: text }));
        inputText.value = '';
        scrollBottom(true);

        if (window.runLiveStream) {
            window.runLiveStream(text, {
                streaming: streaming,
                streamContent: streamContent,
                streamHtml: streamHtml,
                messages: messages,
                sessionId: sessionId.value,
                scrollBottom: scrollBottom
            });
        } else {
            console.warn('[store] runLiveStream 未加载');
        }
    }

    function onFileUpload(event) {
        const file = event.target.files[0];
        if (!file) return;
        const isImage = file.type.startsWith('image/');
        let content, html;
        if (isImage) {
            const url = URL.createObjectURL(file);
            content = '🖼️ 图片: ' + file.name;
            html = '<div style="margin-bottom:8px"><img src="' + url + '" alt="' + file.name + '" style="max-width:320px;max-height:240px;border-radius:8px;cursor:pointer" onclick="window.open(this.src,\'_blank\')" /></div>';
        } else {
            content = '📎 上传文件: ' + file.name + ' (' + (file.size / 1024).toFixed(1) + ' KB)';
            html = null;
        }
        messages.value.push(preRenderMsg({
            role: 'user',
            content: content,
            html: html
        }));
        scrollBottom(true);
        event.target.value = '';
        if (window.runLiveStream) {
            window.runLiveStream('请分析上传的文件: ' + file.name, {
                streaming: streaming, streamContent: streamContent,
                streamHtml: streamHtml, messages: messages,
                sessionId: sessionId.value, scrollBottom: scrollBottom
            });
        }
    }

    function getActiveLabel() {
        return window.MENU_CONFIG ? window.MENU_CONFIG.getLabel(activeTab.value) : '';
    }

    // ════════════════════════════════════════
    //  MCP / 技能 数据
    // ════════════════════════════════════════
    const mcps = ref([]);
    const mcpsLoading = ref(false);
    const tools = ref([]);
    const toolsLoading = ref(false);

    async function loadMcps() {
        if (mcpsLoading.value) return;
        mcpsLoading.value = true;
        try {
            const res = await fetch('/api/mcps');
            if (!res.ok) throw new Error('HTTP ' + res.status);
            const data = await res.json();
            mcps.value = (data.mcps || []).map(function (m) {
                return {
                    id: m.id || m.name || '?',
                    name: m.name || m.id || '?',
                    status: m.status || 'unknown',
                    tool_count: m.tool_count || 0,
                    tools: m.tools || [],
                };
            });
        } catch (err) {
            console.error('[store] 加载 MCP 状态失败:', err);
            mcps.value = [];
        } finally {
            mcpsLoading.value = false;
        }
    }

    async function loadTools() {
        if (toolsLoading.value) return;
        toolsLoading.value = true;
        try {
            const res = await fetch('/api/skills');
            if (!res.ok) throw new Error('HTTP ' + res.status);
            const data = await res.json();
            tools.value = (data.skills || []).map(function (t) {
                return {
                    name: t.name || '?',
                    description: t.description || '',
                    source: t.source || '',
                    params: flattenParams(t.parameters) || [],
                };
            });
        } catch (err) {
            console.error('[store] 加载工具列表失败:', err);
            tools.value = [];
        } finally {
            toolsLoading.value = false;
        }
    }

    /** 把 JSON Schema 的 properties 扁平化为 [{name, type, required, default, description}] */
    function flattenParams(schema) {
        if (!schema || !schema.properties) return [];
        var props = schema.properties;
        var required = Array.isArray(schema.required) ? schema.required : [];
        var result = [];
        Object.keys(props).forEach(function (key) {
            var p = props[key];
            var typeStr = p.type || '';
            // Literal enum → 追加可选值
            if (Array.isArray(p.enum) && p.enum.length) {
                typeStr = typeStr ? typeStr + ' (' + p.enum.join('|') + ')' : p.enum.join('|');
            }
            result.push({
                name: key,
                type: typeStr,
                required: required.indexOf(key) >= 0,
                default: p.default != null ? String(p.default) : null,
                description: p.description || '',
            });
        });
        return result;
    }

    // ════════════════════════════════════════
    //  引擎管理
    // ════════════════════════════════════════
    const engineList = ref([]);
    const activeEngine = ref('react');
    const engineLoading = ref(false);
    const chatEngineDropdown = ref(false);  // 聊天面板引擎下拉

    async function loadEngines() {
        engineLoading.value = true;
        try {
            const res = await fetch('/api/engine');
            if (!res.ok) throw new Error('HTTP ' + res.status);
            const data = await res.json();
            engineList.value = data.engines || [];
            activeEngine.value = data.active || 'react';
        } catch (err) {
            console.error('[store] 加载引擎列表失败:', err);
        } finally {
            engineLoading.value = false;
        }
    }

    async function switchEngine(engineName) {
        if (engineName === activeEngine.value) return;
        try {
            const res = await fetch('/api/engine/switch', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ engine: engineName })
            });
            const data = await res.json();
            if (data.status === 'ok') {
                activeEngine.value = engineName;
                await loadEngines();
            } else {
                alert('切换失败: ' + (data.message || '未知错误'));
            }
        } catch (err) {
            console.error('[store] 切换引擎失败:', err);
            alert('切换引擎失败');
        }
    }

    function getActiveEngineMeta() {
        var found = engineList.value.find(function (e) { return e.name === activeEngine.value; });
        return found || { name: 'react', label: 'ReAct 多轮循环', desc: '', icon: 'fa-solid fa-arrows-spin', available: true };
    }

    function toggleChatEngineDropdown() {
        chatEngineDropdown.value = !chatEngineDropdown.value;
    }

    // ════════════════════════════════════════
    //  Token 统计
    // ════════════════════════════════════════
    const tokenStats = ref(null);
    const tokenLoading = ref(false);

    async function loadTokenStats(days = 7) {
        tokenLoading.value = true;
        try {
            const res = await fetch(`/api/token/stats?days=${days}`);
            if (!res.ok) throw new Error('HTTP ' + res.status);
            const data = await res.json();
            tokenStats.value = data.data || null;
        } catch (err) {
            console.error('[store] 加载 token 统计失败:', err);
            tokenStats.value = null;
        } finally {
            tokenLoading.value = false;
        }
    }

    async function resetTokenStats() {
        try {
            const res = await fetch('/api/token/reset', { method: 'POST' });
            if (!res.ok) throw new Error('HTTP ' + res.status);
            await loadTokenStats();
        } catch (err) {
            console.error('[store] 重置 token 统计失败:', err);
            alert('重置失败');
        }
    }

    // ════════════════════════════════════════
    //  Agent 数据
    // ════════════════════════════════════════
    const agents = ref([]);
    const agentsLoading = ref(false);
    const agentRunning = ref(null);
    const agentResult = ref(null);
    const activeAgentId = ref(null);

    async function loadAgents() {
        if (agentsLoading.value) return;
        agentsLoading.value = true;
        try {
            const res = await fetch('/api/agents');
            if (!res.ok) throw new Error('HTTP ' + res.status);
            const data = await res.json();
            agents.value = data.agents || [];
        } catch (err) {
            console.error('[store] 加载 Agent 列表失败:', err);
            agents.value = [];
        } finally {
            agentsLoading.value = false;
        }
    }

    // ════════════════════════════════════════
    //  模型 API
    // ════════════════════════════════════════

    async function loadModels(opts) {
        opts = opts || {};
        try {
            var res = await fetch('/api/models');
            if (!res.ok) throw new Error('HTTP ' + res.status);
            var data = await res.json();
            modelList.value = data.models || [];
            if (!opts.noSort) {
                var activeIdx = -1;
                var active = null;
                for (var i = 0; i < modelList.value.length; i++) {
                    if (modelList.value[i].is_active) { activeIdx = i; active = modelList.value[i]; break; }
                }
                // 激活的模型排第一位
                if (activeIdx > 0) {
                    modelList.value.splice(activeIdx, 1);
                    modelList.value.unshift(active);
                }
            }
            if (active) {
                activeModel.value = active;
            } else {
                try {
                    var ar = await fetch('/api/models/active');
                    if (ar.ok) { var ad = await ar.json(); activeModel.value = ad.active_model || null; }
                } catch (e) { /* ignore */ }
            }
        } catch (err) {
            console.error('[store] 加载模型列表失败:', err);
        }
    }

    async function switchModel(modelId) {
        try {
            var res = await fetch('/api/models/switch', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ model_id: modelId })
            });
            if (!res.ok) {
                var errData = await res.json();
                alert('切换失败: ' + (errData.message || '未知错误'));
                return;
            }
            await loadModels({ noSort: true });
            chatModelDropdown.value = false;
        } catch (err) {
            console.error('[store] 切换模型失败:', err);
            alert('切换模型失败');
        }
    }

    function toggleChatModelDropdown() {
        chatModelDropdown.value = !chatModelDropdown.value;
    }

    function closeChatModelDropdown() {
        chatModelDropdown.value = false;
    }

    function openModelEditor(model) {
        if (model) {
            editingModel.value = model;
            modelForm.value = {
                model_id: model.model_id || '', name: model.name || '',
                base_url: model.base_url || '', model: model.model || '',
                api_key: model.api_key || 'ollama',
                max_tokens: model.max_tokens || 4096,
                temperature: model.temperature != null ? model.temperature : 0.7,
                timeout: model.timeout || 120,
                supports_tools: model.supports_tools != null ? model.supports_tools : true,
            };
        } else {
            editingModel.value = null;
            modelForm.value = {
                model_id: '', name: '', base_url: 'http://localhost:11434/v1', model: '',
                api_key: 'ollama', max_tokens: 4096, temperature: 0.7, timeout: 120,
                supports_tools: true,
            };
        }
        modelEditorOpen.value = true;
    }

    async function saveModel() {
        var form = modelForm.value;
        if (!form.model_id || !form.base_url || !form.model) {
            alert('请填写必填字段'); return;
        }
        modelSaving.value = true;
        try {
            var method = editingModel.value ? 'PUT' : 'POST';
            var url = editingModel.value
                ? '/api/models/' + encodeURIComponent(form.model_id) : '/api/models';
            var res = await fetch(url, {
                method: method, headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(form)
            });
            if (!res.ok) {
                var errData = await res.json();
                alert('保存失败: ' + (errData.message || '未知错误'));
                return;
            }
            modelEditorOpen.value = false;
            await loadModels();
        } catch (err) {
            console.error('[store] 保存模型失败:', err);
            alert('保存模型失败');
        } finally {
            modelSaving.value = false;
        }
    }

    async function deleteModel(modelId) {
        var isActive = modelList.value.find(function (m) { return m.model_id === modelId && m.is_active; });
        var confirmMsg = isActive
            ? '将删除当前正在使用的模型 "' + modelId + '"，删除后会自动切换到第一个可用模型。确定吗？'
            : '确定要删除模型 "' + modelId + '" 吗？';
        if (!confirm(confirmMsg)) return;
        try {
            var res = await fetch('/api/models/' + encodeURIComponent(modelId), { method: 'DELETE' });
            if (!res.ok) {
                var errData = await res.json();
                alert('删除失败: ' + (errData.message || '未知错误'));
                return;
            }
            await loadModels();
            // 删除的是当前激活模型 → 自动切到第一个
            if (isActive && modelList.value.length > 0) {
                await switchModel(modelList.value[0].model_id);
            }
        } catch (err) {
            console.error('[store] 删除模型失败:', err);
            alert('删除失败');
        }
    }

    // ════════════════════════════════════════
    //  模型扫描
    // ════════════════════════════════════════

    async function scanModels() {
        var url = scanBaseUrl.value.trim();
        if (!url) { alert('请填写 API 地址'); return; }
        scanning.value = true;
        scanResult.value = [];
        selectedScanModels.value = {};
        try {
            var res = await fetch('/api/models/scan', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ base_url: url, api_key: scanApiKey.value || 'ollama' })
            });
            var data = await res.json();
            if (!res.ok) { alert('扫描失败: ' + (data.message || '未知错误')); return; }
            scanResult.value = data.models || [];
            scanDialogOpen.value = true;
        } catch (err) {
            console.error('[store] 扫描模型失败:', err);
            alert('扫描模型失败，请检查 API 地址是否可达');
        } finally {
            scanning.value = false;
        }
    }

    async function importScannedModels() {
        var selected = scanResult.value.filter(function (m) { return selectedScanModels.value[m.id]; });
        if (selected.length === 0) { alert('请至少选择一个模型'); return; }
        var successCount = 0, failCount = 0;
        for (var i = 0; i < selected.length; i++) {
            var m = selected[i];
            var modelId = m.id.replace(/[^a-zA-Z0-9._-]/g, '_');
            try {
                var res = await fetch('/api/models', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        model_id: modelId, name: m.id, base_url: scanBaseUrl.value.trim(),
                        model: m.id, api_key: scanApiKey.value || 'ollama',
                        max_tokens: 4096, temperature: 0.7, timeout: 120,
                        supports_tools: true,
                    })
                });
                if (res.ok) successCount++; else failCount++;
            } catch (err) { failCount++; }
        }
        alert('导入完成: 成功 ' + successCount + ' 个, 失败 ' + failCount + ' 个');
        scanDialogOpen.value = false;
        await loadModels();
    }

    function selectAllScan() {
        var obj = {};
        scanResult.value.forEach(function (m) { obj[m.id] = true; });
        selectedScanModels.value = obj;
    }

    function deselectAllScan() {
        selectedScanModels.value = {};
    }

    // ════════════════════════════════════════
    //  初始化
    // ════════════════════════════════════════

    async function init() {
        await loadSessions();
        await loadModels();
        await loadEngines();
        if (sessions.value.length > 0) {
            // 恢复上次选中的会话，若已不存在则回退到第一个
            var lastId = localStorage.getItem('claw_sessionId');
            var found = lastId && sessions.value.find(function (s) { return s.id === lastId; });
            sessionId.value = found ? lastId : sessions.value[0].id;
            await loadMessages(sessionId.value);
        } else {
            sessionId.value = '';
        }
        scrollBottom(true);

        // 点击模型选择器以外 → 关闭下拉
        document.addEventListener('click', function (e) {
            if (chatModelDropdown.value && !e.target.closest('.model-picker-wrap')) {
                chatModelDropdown.value = false;
            }
            if (chatEngineDropdown.value && !e.target.closest('.engine-picker-wrap')) {
                chatEngineDropdown.value = false;
            }
        });
    }

    // tab 切换时自动刷新数据
    watch(activeTab, function (val) {
        if (val === 'chat') loadSessions();
        if (val === 'settings') loadModels();
        if (val === 'extensions') { loadMcps(); loadTools(); loadAgents(); }

        // 金融 tab → 同步金融子面板
        syncFinancialTab(val);
    }, { immediate: true });

    /** 同步金融子面板 */
    function syncFinancialTab(tabId) {
        var menu = window.MENU_CONFIG;
        if (!menu || !menu.financialTabs) return;
        if (menu.financialTabs.indexOf(tabId) < 0) return;

        var finStore = window.FinancialStore;
        if (finStore && menu.finSubTab) {
            var sub = menu.finSubTab[tabId];
            if (sub && finStore.activeFinancialTab !== sub) {
                finStore.activeFinancialTab = sub;
            }
        }
    }

    // ════════════════════════════════════════
    //  导出 (用 reactive 包裹，模板中 ref 自动解包)
    // ════════════════════════════════════════

    window.ClawStore = Vue.reactive({
        // 用户
        currentUser, doLogout,
        // 侧边栏
        isCollapsed, mobileSidebarOpen, activeTab, menuItems,
        // 会话
        sessions, sessionId, sessionsLoading,
        loadSessions, switchSession, newSession, renameSession, deleteSession, formatSessionDate,
        // 消息
        messages, inputText, streaming, streamHtml,
        sendMessage, onFileUpload, getActiveLabel, scrollBottom,
        atBottom: userScrolledAway, setAtBottom: setUserScrolledAway,
        // 模型
        modelList, activeModel, chatModelDropdown, loadModels, switchModel, deleteModel,
        toggleChatModelDropdown, closeChatModelDropdown,
        modelEditorOpen, editingModel, modelSaving, modelForm,
        openModelEditor, saveModel,
        // 扫描
        scanning, scanResult, scanDialogOpen, scanBaseUrl, scanApiKey,
        selectedScanModels, scanModels, importScannedModels,
        selectAllScan, deselectAllScan,
        // MCP / 技能
        mcps, mcpsLoading, loadMcps,
        tools, toolsLoading, loadTools,
        // Agent
        agents, agentsLoading, agentRunning, agentResult, activeAgentId, loadAgents,
        // 引擎
        engineList, activeEngine, engineLoading, chatEngineDropdown,
        loadEngines, switchEngine, getActiveEngineMeta, toggleChatEngineDropdown,
        // Token 统计
        tokenStats, tokenLoading, loadTokenStats, resetTokenStats,
        // 初始化
        init
    });

    console.log('[store] 状态仓库已就绪 ✓');
})();
