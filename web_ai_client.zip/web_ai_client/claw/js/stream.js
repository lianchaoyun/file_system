/**
 * ================================================================
 * Ollama 流式通信引擎 (v2)
 * ================================================================
 * 调用 POST /api/chat/stream，解析 SSE 事件，实时渲染
 */

(function () {
    'use strict';

    /**
     * 调用 Ollama 流式接口
     * @param {string} userPrompt  - 用户输入
     * @param {object} context     - Vue 响应式上下文
     */
    window.runLiveStream = async function (userPrompt, context) {
        context.streaming.value = true;
        context.streamContent.value = '';   // 纯文本/Markdown 源（不包含 HTML）
        context.streamHtml.value = '';

        try {
            const response = await fetch('/api/chat/stream', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    message: userPrompt,
                    session_id: context.sessionId || 'default'
                })
            });

            if (!response.ok) {
                const errText = await response.text().catch(() => '');
                throw new Error('HTTP ' + response.status + ': ' + (errText || response.statusText));
            }

            const reader = response.body.getReader();
            const decoder = new TextDecoder();
            let buffer = '';

            while (true) {
                const { done, value } = await reader.read();
                if (done) break;

                buffer += decoder.decode(value, { stream: true });

                const lines = buffer.split('\n');
                buffer = lines.pop() || ''; // 保留不完整的最后一行

                for (const line of lines) {
                    if (!line.startsWith('data: ')) continue;

                    const jsonStr = line.slice(6).trim();
                    if (jsonStr === '[DONE]') continue;
                    if (!jsonStr) continue;

                    try {
                        const event = JSON.parse(jsonStr);
                        processEvent(event, context);
                    } catch (e) {
                        console.warn('[stream] JSON 解析失败:', line.slice(0, 120));
                    }
                }
            }

        } catch (err) {
            console.error('[stream] 请求失败:', err);
            var errContent = '❌ 连接失败: ' + err.message;
            context.messages.value.push({
                role: 'assistant',
                content: errContent,
                html: render(errContent)
            });
        } finally {
            context.streaming.value = false;
            context.streamContent.value = '';
            context.streamHtml.value = '';
            context.scrollBottom();
        }
    };

    /**
     * 渲染：将纯文本源转成 HTML
     */
    var renderCallCount = 0;
    function render(content) {
        renderCallCount++;
        if (!content) { console.log('[stream] render#' + renderCallCount + ' 空内容'); return ''; }
        if (!window.renderMarkdown) {
            console.warn('[stream] render#' + renderCallCount + ' ⚠️ renderMarkdown未就绪! 返回原文');
            return content;
        }
        var result = window.renderMarkdown(content);
        var isSame = result === content;
        console.log('[stream] render#' + renderCallCount + ' len=' + content.length +
            ' 结果len=' + (result ? result.length : 0) +
            ' 是否原文=' + isSame +
            ' 结果前60:', String(result).slice(0, 60));
        return result;
    }

    /**
     * 处理单个 SSE 事件
     *
     * 核心原则：streamContent 只存纯文本/Markdown，绝不混入 HTML。
     * streamHtml 始终 = renderMarkdown(streamContent)。
     */
    function processEvent(event, ctx) {
        console.log('[stream] 收到事件 type=' + event.type +
            (event.content ? ' content前30:' + String(event.content).slice(0, 30) : '') +
            (event.name ? ' name=' + event.name : ''));
        switch (event.type) {

            case 'delta':
                // 文本增量 → 追加到纯文本源
                ctx.streamContent.value += event.content;
                ctx.streamHtml.value = render(ctx.streamContent.value);
                ctx.scrollBottom();
                break;

            case 'tool_call':
                // 工具调用 → 区分 Skill 和 MCP，用不同 Markdown 标记
                {
                    var isMcp = event.source === 'mcp';
                    var icon = isMcp ? '🔌 MCP工具' : '⚙️ 技能工具';
                    ctx.streamContent.value +=
                        '\n\n> ' + icon + ': **' + event.name + '**\n>\n> ```\n> ' +
                        (event.arguments || '{}') + '\n> ```\n\n';
                    ctx.streamHtml.value = render(ctx.streamContent.value);
                    ctx.scrollBottom();
                }
                break;

            case 'tool_result':
                // 工具返回 → 区分 Skill 和 MCP
                {
                    var isMcpResult = event.source === 'mcp';
                    var label = isMcpResult ? '📋 MCP返回' : '📋 技能返回';
                    ctx.streamContent.value +=
                        '> ' + label + ':\n>\n> ' +
                        (event.content || '').replace(/\n/g, '\n> ') +
                        '\n\n';
                    ctx.streamHtml.value = render(ctx.streamContent.value);
                    ctx.scrollBottom();
                }
                break;

            case 'done':
                // 对话完成 → 归档纯文本源到消息历史（带预渲染 HTML）
                if (ctx.streamContent.value.trim()) {
                    var content = ctx.streamContent.value;
                    var html = render(content);
                    console.log('[stream] done事件 归档消息 content前80:', content.slice(0, 80));
                    console.log('[stream] done事件 归档消息 html前80:', String(html).slice(0, 80));
                    console.log('[stream] done事件 html是否等于content?', html === content);
                    ctx.messages.value.push({
                        role: 'assistant',
                        content: content,
                        html: html
                    });
                    console.log('[stream] done事件 已push, messages总数=', ctx.messages.value.length);
                    ctx.streamContent.value = '';
                    ctx.streamHtml.value = '';
                } else {
                    console.log('[stream] done事件 streamContent为空，跳过归档');
                }
                ctx.scrollBottom();
                break;

            case 'error':
                // 服务端错误
                var errText = '❌ ' + event.content;
                ctx.messages.value.push({
                    role: 'assistant',
                    content: errText,
                    html: render(errText)
                });
                ctx.streamContent.value = '';
                ctx.streamHtml.value = '';
                ctx.scrollBottom();
                break;
        }
    }

})();
