"""技术指标插件库 - 买卖信号生成（流水线模式）

每个信号有语义化名字，一眼知道含义：
  - ma_fast_above_slow:   MA快线在慢线之上
  - macd_dif_above_dea:   MACD DIF > DEA（金叉）
  - obv_above_ma:         OBV > MA(OBV)
  - close_above_open:     收阳
  - up_streak:            连阳达标
  - breakout_high:        突破前高
  - increase_pct:         涨幅达标
  - close_above_ma_fast:  收盘价在快线之上
  - close_above_ma_slow:  收盘价在慢线之上
  - ma_fast_slope_up:     快线斜率向上
  - ma_slow_slope_up:     慢线斜率向上
"""

from src.common.MyTT import *

# ═══════════════════════════════════════════════
# 买入信号注册表（流水线工位，有序可插拔）
# ═══════════════════════════════════════════════
BUY_SIGNALS = {}


def _register_buy(name: str):
    """买入信号注册装饰器"""
    def decorator(func):
        BUY_SIGNALS[name] = func
        return func
    return decorator


@_register_buy('ma_fast_above_slow')    # 1. MA快线 > 慢线
def _buy_ma_fast_above_slow(df, cfg):
    return IF(MA(df['close'], cfg.ma_fast) > MA(df['close'], cfg.ma_slow), 1, 0)

@_register_buy('macd_dif_above_dea')    # 2. MACD DIF > DEA
def _buy_macd_dif_above_dea(df, cfg):
    dif, dea, _ = MACD(df['close'], cfg.macd_short, cfg.macd_long, cfg.macd_signal)
    return IF(dif > dea, 1, 0)

@_register_buy('obv_above_ma')          # 3. OBV > MA(OBV)
def _buy_obv_above_ma(df, cfg):
    obv = OBV(df['close'], df['volume'])
    return IF(obv > MA(obv, cfg.obv_ma_period), 1, 0)

@_register_buy('close_above_open')      # 4. 收阳
def _buy_close_above_open(df, cfg):
    return IF(df['close'] > df['open'], 1, 0)

@_register_buy('up_streak')             # 5. 连阳达标
def _buy_up_streak(df, cfg):
    return IF(SUM(df['close'] > df['open'], cfg.up_streak_window) >= cfg.up_streak_days, 1, 0)

@_register_buy('breakout_high')         # 6. 突破前高
def _buy_breakout_high(df, cfg):
    high, close, open_p = df['high'].values, df['close'].values, df['open'].values
    break_u = (high > REF(HHV(high, cfg.breakout_days), 1)) | (
        (REF(close, 1) < REF(open_p, 1)) & (high > REF(HHV(high, 2), 1)) & (close > open_p))
    return IF(break_u, 1, 0)

@_register_buy('increase_pct')          # 7. 涨幅达标
def _buy_increase_pct(df, cfg):
    return IF(((df['close'] - df['open']) / df['open'] * 100) > cfg.increase_rate, 1, 0)

@_register_buy('close_above_ma_fast')   # 8. 收盘价在快线之上
def _buy_close_above_ma_fast(df, cfg):
    return IF(df['close'] > MA(df['close'], cfg.ma_fast), 1, 0)

@_register_buy('close_above_ma_slow')   # 9. 收盘价在慢线之上
def _buy_close_above_ma_slow(df, cfg):
    return IF(df['close'] > MA(df['close'], cfg.ma_slow), 1, 0)

@_register_buy('ma_fast_slope_up')      # 10. 快线斜率向上
def _buy_ma_fast_slope_up(df, cfg):
    return IF(SLOPE(MA(df['close'], cfg.ma_fast), cfg.ma_slope_period) > 0, 1, 0)

@_register_buy('ma_slow_slope_up')      # 11. 慢线斜率向上
def _buy_ma_slow_slope_up(df, cfg):
    return IF(SLOPE(MA(df['close'], cfg.ma_slow), cfg.ma_slope_period) > 0, 1, 0)


# ═══════════════════════════════════════════════
# 卖出信号注册表
# ═══════════════════════════════════════════════
SELL_SIGNALS = {}


def _register_sell(name: str):
    """卖出信号注册装饰器"""
    def decorator(func):
        SELL_SIGNALS[name] = func
        return func
    return decorator


@_register_sell('ma_fast_below_slow')   # 1. MA快线 < 慢线
def _sell_ma_fast_below_slow(df, cfg):
    return IF(MA(df['close'], cfg.ma_fast) < MA(df['close'], cfg.ma_slow), 1, 0)

@_register_sell('macd_dif_below_dea')   # 2. MACD DIF < DEA
def _sell_macd_dif_below_dea(df, cfg):
    dif, dea, _ = MACD(df['close'], cfg.macd_short, cfg.macd_long, cfg.macd_signal)
    return IF(dif < dea, 1, 0)

@_register_sell('obv_below_ma')         # 3. OBV < MA(OBV)
def _sell_obv_below_ma(df, cfg):
    obv = OBV(df['close'], df['volume'])
    return IF(obv < MA(obv, cfg.obv_ma_period), 1, 0)

@_register_sell('close_below_open')     # 4. 收阴
def _sell_close_below_open(df, cfg):
    return IF(df['close'] < df['open'], 1, 0)

@_register_sell('down_streak')          # 5. 连阴达标
def _sell_down_streak(df, cfg):
    return IF(SUM(df['close'] < df['open'], cfg.down_streak_window) >= cfg.down_streak_days, 1, 0)

@_register_sell('breakout_low')         # 6. 跌破前低
def _sell_breakout_low(df, cfg):
    low, close, open_p = df['low'].values, df['close'].values, df['open'].values
    break_d = (low < REF(LLV(low, cfg.breakout_days), 1)) | (
        (REF(close, 1) > REF(open_p, 1)) & (low < REF(LLV(low, 2), 1)) & (close < open_p))
    return IF(break_d, 1, 0)

@_register_sell('decrease_pct')         # 7. 跌幅达标
def _sell_decrease_pct(df, cfg):
    return IF(((df['close'] - df['open']) / df['open'] * 100) < -cfg.decrease_rate, 1, 0)

@_register_sell('close_below_ma_fast')  # 8. 收盘价在快线之下
def _sell_close_below_ma_fast(df, cfg):
    return IF(df['close'] < MA(df['close'], cfg.ma_fast), 1, 0)

@_register_sell('close_below_ma_slow')  # 9. 收盘价在慢线之下
def _sell_close_below_ma_slow(df, cfg):
    return IF(df['close'] < MA(df['close'], cfg.ma_slow), 1, 0)

@_register_sell('ma_fast_slope_down')   # 10. 快线斜率向下
def _sell_ma_fast_slope_down(df, cfg):
    return IF(SLOPE(MA(df['close'], cfg.ma_fast), cfg.ma_slope_period) < 0, 1, 0)

@_register_sell('ma_slow_slope_down')   # 11. 慢线斜率向下
def _sell_ma_slow_slope_down(df, cfg):
    return IF(SLOPE(MA(df['close'], cfg.ma_slow), cfg.ma_slope_period) < 0, 1, 0)



def get_all_buy_plugins():
    """获取所有买入插件（兼容旧代码）"""
    return list(BUY_SIGNALS.values())


def get_all_sell_plugins():
    """获取所有卖出插件（兼容旧代码）"""
    return list(SELL_SIGNALS.values())
