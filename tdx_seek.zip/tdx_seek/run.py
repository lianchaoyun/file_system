"""量化回测入口

用法：
  python quant_backtest.py
  python quant_backtest.py --market tdx --symbol 003026 --period 1d
  python quant_backtest.py --market crypto --symbol BTCUSDT --period 1h
  python quant_backtest.py --market future --symbol v2609 --period 1h --grid-size 5000
"""

import sys
import os
import argparse

# 确保项目根路径可导入
from src.common.paths import PROJECT_ROOT_STR
PROJECT_ROOT = PROJECT_ROOT_STR
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from src.stocka.tdx_seek.runner import run_seek


def main():
    parser = argparse.ArgumentParser(
        description='量化策略回测系统',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  %(prog)s
  %(prog)s --market tdx --symbol 003026 --period 1d
  %(prog)s --market crypto --symbol BTCUSDT --period 1h --count 2000
  %(prog)s --market future --symbol v2609 --period 1h --grid-size 5000
        """
    )

    parser.add_argument('--market', type=str, default='tdx',
                        choices=['tdx', 'future', 'crypto'],
                        help='市场类型 (默认: tdx)')
    parser.add_argument('--symbol', type=str, default='003026.SZ',
                        help='交易对符号 (默认: 003026.SZ)')
    parser.add_argument('--period', type=str, default='1d',
                        help='K线周期 (默认: 1d)')
    parser.add_argument('--count', type=int, default=2000,
                        help='K线数量 (默认: 2000)')
    parser.add_argument('--grid-size', type=int, default=1_000_0,
                        help='最大网格大小 (默认: 10000)')
    parser.add_argument('--show-log', action='store_true', default=True,
                        help='显示K线数据日志')

    args = parser.parse_args()

    best_row = run_seek(
        market=args.market,
        symbol=args.symbol,
        period=args.period,
        count=args.count,
        show_log=args.show_log,
        MAX_GRID_SIZE=args.grid_size
    )

    if best_row is not None:
        #print(best_row.to_dict())
        #print(best_row.to_string)
        pass


if __name__ == '__main__':
    main()
