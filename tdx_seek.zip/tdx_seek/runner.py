"""策略寻优引擎与执行入口"""

import numpy as np
import pandas as pd
from multiprocessing import Pool, cpu_count
from tqdm import tqdm
from typing import Dict, Any, Optional

from .signals import StrategyParams, generate_signals, calculate_weighted_scores
from .param_generator import ParamGenerator
from .report import report_seek, resport_test
from src.stocka.feed import get_kline


def run_test(data: pd.DataFrame, params: Dict[str, Any]) -> Dict[str, float]:
    """
    回测引擎核心函数

    Args:
        data: K线数据
        params: 策略参数字典

    Returns:
        性能评估结果字典
    """
    # 1. 初始化策略配置
    cfg = StrategyParams()
    for k, v in params.items():
        if hasattr(cfg, k):
            setattr(cfg, k, v)

    # 2. 生成买卖信号
    su_map, sd_map = generate_signals(data, cfg)

    # 3. 计算加权得分
    l_score, s_score = calculate_weighted_scores(su_map, sd_map, cfg.buy_weights, cfg.sell_weights)

    # 4. 生成买卖指令
    is_long_arr = (l_score >= cfg.buy_threshold)
    is_short_arr = (s_score >= cfg.sell_threshold)

    # 5. 模拟账户运行
    close_vals = data['close'].values
    net_history = np.zeros(len(data))
    cash = cfg.initial_cash
    pos = 0
    trades = 0

    for i in range(len(data)):
        if is_long_arr[i] and pos == 0:
            pos = int(cash / close_vals[i])
            cash -= pos * close_vals[i]
            trades += 1
        elif is_short_arr[i] and pos > 0:
            cash += pos * close_vals[i]
            pos = 0
            trades += 1
        net_history[i] = cash + pos * close_vals[i]

    return resport_test(net_history, trades)


def worker(args: tuple) -> Dict[str, Any]:
    """
    工作进程函数

    Args:
        args: (df_data, params) 元组

    Returns:
        合并后的结果字典
    """
    df_data, params = args
    return {**params, **run_test(df_data, params)}


def run_seek(
    market: str = "",
    symbol: str = "",
    period: str = "",
    count: int = 1000,
    show_log: bool = False,
    MAX_GRID_SIZE: int = 1000
) -> Optional[pd.Series]:
    """
    启动回测

    Args:
        market: 市场类型 (tdx/future/crypto)
        symbol: 交易对符号
        period: K线周期
        count: K线数量
        show_log: 是否显示K线数据日志
        MAX_GRID_SIZE: 最大网格大小

    Returns:
        最佳参数组合 (pd.Series)
    """
    # 1. 获取K线数据
    df = get_kline(market=market, symbol=symbol, period=period, count=count)

    if df is None:
        print(f"❌ 无法获取 {symbol} 的K线数据")
        return None

    # 2. 数据预处理
    for col in ['open', 'high', 'low', 'close', 'volume']:
        df[col] = pd.to_numeric(df[col], errors='coerce')

    df.dropna(subset=['close'], inplace=True)

    if show_log:
        print(df.to_string())

    # 3. 定义参数网格
    full_param_grid = {
        'ma_fast': list(range(5, 60, 1)),
        'ma_slow': list(range(30, 120, 1)),
        'macd_short': list(range(8, 26, 1)),
        'macd_long': list(range(12, 60, 1)),
        'macd_signal': list(range(5, 30, 1)),
        'obv_ma_period': list(range(5, 60, 1)),
        'breakout_days': list(range(2, 12, 1)),
        'ma_slope_period': list(range(2, 12, 1)),
        'up_streak_window': list(range(5, 12, 1)),
        'up_streak_days': list(range(3, 8, 1)),
        'down_streak_window': list(range(5, 12, 1)),
        'down_streak_days': list(range(3, 8, 1)),
        'increase_rate': [0.6, 0.7, 0.8, 0.9, 1.0, 1.1, 1.2, 1.3, 1.4, 1.5, 1.8, 2.0],
        'decrease_rate': [0.6, 0.7, 0.8, 0.9, 1.0, 1.1, 1.2, 1.3, 1.4, 1.5, 1.8, 2.0],
        'buy_threshold': [0.65, 0.75, 0.85, 0.95],
        'sell_threshold': [0.5, 0.65, 0.85, 0.95],
        #'buy_weights': ParamGenerator.get_weight_combos("buy", n_samples=500),
        #'sell_weights': ParamGenerator.get_weight_combos("sell", n_samples=500),
    }

    # 4. 生成参数组合
    valid_combos = ParamGenerator.generate_combos(full_param_grid, symbol, MAX_GRID_SIZE)

    # 5. 并行回测
    results = []
    with Pool(cpu_count()) as pool:
        tasks = [(df, p) for p in valid_combos]
        for res in tqdm(pool.imap_unordered(worker, tasks), total=len(valid_combos), desc="执行进度"):
            results.append(res)

    return report_seek(results, symbol, save_csv=True)
