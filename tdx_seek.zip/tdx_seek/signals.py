"""策略配置与信号生成模块"""

from dataclasses import dataclass, field
from typing import Dict, Any
import pandas as pd

from .plugins import BUY_SIGNALS, SELL_SIGNALS


@dataclass
class StrategyParams:
    """策略参数配置类"""

    trade_mode: str = "full"       # full: 全仓, one: 一手
    initial_cash: float = 100000.0

    # MA参数
    ma_fast: int = 20
    ma_slow: int = 60

    # MACD参数
    macd_short: int = 12
    macd_long: int = 26
    macd_signal: int = 9

    # OBV参数
    obv_ma_period: int = 30

    # 突破参数
    breakout_days: int = 3

    # 斜率参数
    ma_slope_period: int = 10

    # 连阳/连阴参数
    up_streak_window: int = 5
    up_streak_days: int = 3
    down_streak_window: int = 5
    down_streak_days: int = 3

    # 涨跌幅参数
    increase_rate: float = 0.8
    decrease_rate: float = 0.8

    # 权重阈值
    buy_threshold: float = 0.8
    sell_threshold: float = 0.7

    # 信号权重（key = 信号注册名，如 'ma_fast_above_slow'）
    buy_weights: Dict[str, float] = field(default_factory=lambda: {k: 1.0 for k in BUY_SIGNALS})
    sell_weights: Dict[str, float] = field(default_factory=lambda: {k: 1.0 for k in SELL_SIGNALS})

    def validate(self):
        """验证策略参数合法性"""
        errors = []

        if self.ma_fast >= self.ma_slow:
            errors.append(f"ma_fast ({self.ma_fast}) 必须小于 ma_slow ({self.ma_slow})")

        if self.macd_short >= self.macd_long:
            errors.append(f"macd_short ({self.macd_short}) 必须小于 macd_long ({self.macd_long})")

        if self.buy_threshold < 0 or self.buy_threshold > 1:
            errors.append(f"buy_threshold ({self.buy_threshold}) 必须在 [0, 1] 范围内")

        if self.sell_threshold < 0 or self.sell_threshold > 1:
            errors.append(f"sell_threshold ({self.sell_threshold}) 必须在 [0, 1] 范围内")

        if errors:
            raise ValueError("策略参数验证失败:\n" + "\n".join(errors))

    def update(self, params: Dict[str, Any]):
        """从字典更新策略参数"""
        for k, v in params.items():
            if hasattr(self, k):
                setattr(self, k, v)


def generate_signals(df: pd.DataFrame, cfg: StrategyParams) -> tuple:
    """
    生成买卖信号（流水线模式）
    
    返回 (bull_signals, bear_signals):
        bull_signals: {'ma_fast_above_slow': array, 'macd_dif_above_dea': array, ...}
        bear_signals: {'ma_fast_below_slow': array, 'macd_dif_below_dea': array, ...}
    """
    bull_signals = {name: func(df, cfg) for name, func in BUY_SIGNALS.items()}
    bear_signals = {name: func(df, cfg) for name, func in SELL_SIGNALS.items()}
    return bull_signals, bear_signals


def calculate_weighted_scores(
    bull_signals: dict,
    bear_signals: dict,
    buy_weights_dict: dict,
    sell_weights_dict: dict,
) -> tuple:
    """
    计算加权评分。

    Args:
        bull_signals: 买入信号字典（key=信号名, value=0/1数组）
        bear_signals: 卖出信号字典
        buy_weights_dict: 买入权重字典 {'ma_fast_above_slow': 1, ...}
        sell_weights_dict: 卖出权重字典 {'ma_fast_below_slow': 1, ...}

    Returns:
        (buy_score, sell_score): 两个 [0, 1] 范围的浮点数组
    """
    total_buy_weight = sum(buy_weights_dict.values())
    total_sell_weight = sum(sell_weights_dict.values())

    buy_score = (
        sum(bull_signals[k] * buy_weights_dict.get(k, 1.0) for k in bull_signals) / total_buy_weight
        if total_buy_weight > 0 else 0
    )
    sell_score = (
        sum(bear_signals[k] * sell_weights_dict.get(k, 1.0) for k in bear_signals) / total_sell_weight
        if total_sell_weight > 0 else 0
    )

    return buy_score, sell_score
