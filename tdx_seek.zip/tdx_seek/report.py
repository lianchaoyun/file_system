"""回测报告生成与性能指标计算"""

import os
import numpy as np
import pandas as pd
from typing import List, Dict, Any, Optional




def resport_test(net_values, trade_count=0) -> Dict[str, float]:
    """评估策略性能指标"""
    if len(net_values) < 2:
        return {'return': 0, 'ann_ret': 0, 'max_dd': 0, 'sharpe': 0, 'trades': 0}

    total_ret = (net_values[-1] / net_values[0]) - 1
    peak = np.maximum.accumulate(net_values)
    drawdowns = (net_values - peak) / peak
    max_dd = np.min(drawdowns) if np.any(peak > 0) else 0

    days = len(net_values)
    ann_ret = (1 + total_ret) ** (242 / days) - 1 if days > 0 else 0

    daily_returns = np.diff(net_values) / net_values[:-1]
    std = np.std(daily_returns)
    sharpe = (np.mean(daily_returns) / std) * np.sqrt(242) if std != 0 else 0

    return {
        'return': round(total_ret * 100, 2),
        'ann_ret': round(ann_ret * 100, 2),
        'max_dd': round(max_dd * 100, 2),
        'sharpe': round(sharpe, 2),
        'trades': int(trade_count)
    }


def report_seek(results: List[Dict[str, Any]], symbol: str = '', save_csv: bool = False) -> Optional[Dict[str, Any]]:
    """
    生成回测报告

    Args:
        results: 回测结果列表
        symbol: 交易对符号
        save_csv: 是否保存CSV

    Returns:
        最佳参数组合字典
    """
    if not results:
        return None

    final_df = pd.DataFrame(results).sort_values('sharpe', ascending=False)

    print("\n" + "=" * 25)
    print(f" 回测榜单 (Top 10)")
    print(final_df.head(10).to_string())
    print("=" * 25)

    if save_csv:
        from src.common.paths import PROJECT_ROOT_STR
        report_dir = os.path.join(PROJECT_ROOT_STR, 'data', 'stocka', 'report')
        os.makedirs(report_dir, exist_ok=True)
        final_df.to_csv(os.path.join(report_dir, f'fitting_{symbol}.csv'), index=False)

    return final_df.sort_values('sharpe', ascending=False).iloc[0]


def print_weights(cfg, su_map, sd_map, buy_scores, sell_scores, name=""):
    """打印信号权重明细（接收已计算好的数据，不重复获取）"""
    bar_idx = -2
    total_buy_w = sum(cfg.buy_weights.values())
    total_sell_w = sum(cfg.sell_weights.values())

    label = f" {name}" if name else ""
    print(f"\n{'='*52}\n  📊{label}  多={buy_scores[bar_idx]:.4f} 空={sell_scores[bar_idx]:.4f}\n{'='*52}")

    print("  【买入】")
    for k, w in cfg.buy_weights.items():
        v = int(su_map[k][bar_idx])
        contrib = v * w / total_buy_w if total_buy_w > 0 else 0
        print(f"  {'✅' if v else '  '} {k:<28} w={w:.2f}  +{contrib:.4f}")

    print("\n  【卖出】")
    for k, w in cfg.sell_weights.items():
        v = int(sd_map[k][bar_idx])
        contrib = v * w / total_sell_w if total_sell_w > 0 else 0
        print(f"  {'✅' if v else '  '} {k:<28} w={w:.2f}  +{contrib:.4f}")

    print("=" * 52)
