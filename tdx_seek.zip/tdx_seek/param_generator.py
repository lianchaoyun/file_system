"""参数生成器 - 支持网格搜索与随机搜索"""

import random
from itertools import product
from functools import reduce
from operator import mul
from typing import List, Dict, Any, Generator
import numpy as np

from .plugins import BUY_SIGNALS, SELL_SIGNALS


class ParamGenerator:
    """参数生成器"""

    def __init__(self, config: Dict[str, Any]):
        """初始化，将 range/list/ndarray 统一转化为 list"""
        self.config = {
            k: (list(v) if isinstance(v, (range, list, np.ndarray)) else [v])
            for k, v in config.items()
        }

    def count_total_combos(self) -> int:
        """计算网格搜索的总任务数"""
        lengths = [len(v) for v in self.config.values()]
        if not lengths:
            return 0
        return reduce(mul, lengths, 1)

    def get_grid_combos(self, limit: int = 1000000) -> Generator[Dict[str, Any], None, None]:
        """网格搜索：有规律地取出所有组合"""
        total = self.count_total_combos()

        if total > limit:
            raise ValueError(
                f"\n❌ [任务过载] 当前网格组合总数达 {total:,} 组，超过了安全限制 {limit:,}。\n"
                f"建议：\n"
                f"1. 增加参数步长 (例如 range(5, 60, 1) 改为 range(5, 60, 5))\n"
                f"2. 使用 get_random_combos(n=...) 进行随机抽样测试\n"
                f"3. 固定部分不敏感参数"
            )

        keys = self.config.keys()
        for combo in product(*self.config.values()):
            yield dict(zip(keys, combo))

    def get_random_combos(self, n: int = 100) -> List[Dict[str, Any]]:
        """随机搜索：随机取出 n 组参数组合"""
        keys = list(self.config.keys())
        combos = []
        for _ in range(n):
            item = {k: random.choice(self.config[k]) for k in keys}
            combos.append(item)
        return combos

    @staticmethod
    def get_weight_combos(prefix: str = "buy", n_samples: int = 500) -> List[Dict[str, int]]:
        """
        一键生成权重组合（key = 信号语义化名字，如 'ma_fast_above_slow'）

        Args:
            prefix: 'buy' 或 'sell'
            n_samples: 随机生成多少组配比
        """
        signal_map = BUY_SIGNALS if prefix == 'buy' else SELL_SIGNALS
        keys = list(signal_map.keys())
        values = [0, 1, 2, 3]
        return [{k: random.choice(values) for k in keys} for _ in range(n_samples)]

    @staticmethod
    def generate_combos(full_param_grid: Dict[str, Any], symbol: str = '', MAX_GRID_SIZE: int = 1000) -> List[Dict[str, Any]]:
        """
        智能生成参数组合（自动选择网格搜索或随机搜索）
        """
        gen = ParamGenerator(full_param_grid)
        total_planned = gen.count_total_combos()

        if total_planned == 0:
            return [{}]

        combos = list(
            gen.get_grid_combos(limit=MAX_GRID_SIZE)
        ) if total_planned <= MAX_GRID_SIZE else gen.get_random_combos(n=MAX_GRID_SIZE)

        # 过滤无效组合：ma_fast 必须小于 ma_slow
        valid_combos = [
            c for c in combos
            if not (c.get('ma_fast') and c.get('ma_slow') and c.get('ma_fast') >= c.get('ma_slow'))
        ]
        valid_combos = [
            c for c in valid_combos
            if not (c.get('macd_short') and c.get('macd_long') and c.get('macd_short') >= c.get('macd_long'))
        ]

        print(f"🚀 启动自动化探测 | 目标: {symbol} | 样本数: {len(valid_combos)}")
        return valid_combos
