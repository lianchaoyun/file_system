#!/usr/bin/env python3
"""生成带骨骼旋转动画的 glb（简单摆臂骨架），用于 M3 动画播放测试。

骨架：root(0) → bone(1，绕 Y 轴旋转动画) → tip(2，沿 X 偏移)。
输出：content/arm_anim.glb
"""
import json
import math
import os
import struct
import sys


def pad4(data: bytes, pad_byte: int = 0x00) -> bytes:
    return data + bytes([pad_byte]) * ((4 - len(data) % 4) % 4)


def build_glb(json_obj: dict, bin_data: bytes) -> bytes:
    json_bytes = pad4(json.dumps(json_obj, separators=(",", ":")).encode("utf-8"), 0x20)
    bin_bytes = pad4(bin_data, 0x00)
    header = struct.pack("<III", 0x46546C67, 2, 12 + 8 + len(json_bytes) + 8 + len(bin_bytes))
    return header + struct.pack("<II", len(json_bytes), 0x4E4F534A) + json_bytes + \
        struct.pack("<II", len(bin_bytes), 0x004E4942) + bin_bytes


def quat_y_axis(deg):
    r = math.radians(deg)
    return [0.0, math.sin(r / 2), 0.0, math.cos(r / 2)]  # glTF 四元数 [x,y,z,w]


def main():
    # 一个细长立方体（骨骼形状），蒙皮到 tip（关节 2）。
    # 顶点：8 顶点，简单位置 + 法线。
    positions = [
        (-0.1, -0.1, -0.1), (0.1, -0.1, -0.1), (0.1, 0.1, -0.1), (-0.1, 0.1, -0.1),
        (-0.1, -0.1, 0.1), (0.1, -0.1, 0.1), (0.1, 0.1, 0.1), (-0.1, 0.1, 0.1),
    ]
    normals = [(0, 0, 1)] * 8  # 简化法线
    joints = [[2, 0, 0, 0]] * 8   # 全部绑定到关节 2 (tip)
    weights = [[1.0, 0.0, 0.0, 0.0]] * 8
    indices = [
        0, 3, 2, 0, 2, 1, 4, 5, 6, 4, 6, 7,
        0, 4, 7, 0, 7, 3, 1, 2, 6, 1, 6, 5,
        0, 4, 5, 0, 5, 1, 3, 7, 6, 3, 6, 2,
    ]

    pos_bytes = b"".join(struct.pack("<3f", *p) for p in positions)
    nor_bytes = b"".join(struct.pack("<3f", *n) for n in normals)
    jt_bytes = b"".join(struct.pack("<4B", *j) for j in joints)
    wt_bytes = b"".join(struct.pack("<4f", *w) for w in weights)
    idx_bytes = b"".join(struct.pack("<I", i) for i in indices)

    # 逆绑定矩阵：3 个单位矩阵。
    identity = [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1]
    ibm_bytes = b"".join(struct.pack("<16f", *identity) for _ in range(3))

    # 动画：bone 绕 Y 轴旋转 0→90 度（4 个关键帧）。
    times = [0.0, 1.0, 2.0, 3.0]
    rots = [quat_y_axis(0), quat_y_axis(30), quat_y_axis(60), quat_y_axis(90)]
    time_bytes = b"".join(struct.pack("<f", t) for t in times)
    rot_bytes = b"".join(struct.pack("<4f", *r) for r in rots)

    # BIN 布局。
    offset = 0
    views = []
    for data in (pos_bytes, nor_bytes, jt_bytes, wt_bytes, idx_bytes, ibm_bytes, time_bytes, rot_bytes):
        views.append({"buffer": 0, "byteOffset": offset, "byteLength": len(data)})
        offset += len(data)
        offset = (offset + 3) // 4 * 4
    bin_data = b""
    for data, view in zip((pos_bytes, nor_bytes, jt_bytes, wt_bytes, idx_bytes, ibm_bytes, time_bytes, rot_bytes), views):
        bin_data += b"\x00" * (view["byteOffset"] - len(bin_data)) + data
    bin_data += b"\x00" * (offset - len(bin_data))

    gltf = {
        "asset": {"version": "2.0", "generator": "dollengine/gen_anim_glb"},
        "scene": 0,
        "scenes": [{"nodes": [0]}],
        "nodes": [
            {"name": "root"},
            {"name": "bone", "translation": [0.0, 0.5, 0.0]},
            {"name": "tip", "translation": [1.0, 0.0, 0.0], "mesh": 0},
        ],
        # 层级：root → bone → tip
        # root 无 children 显式列出，用 matrix 组织：
        # 注意：这里 root 应包含 bone，bone 应包含 tip
        "meshes": [
            {"name": "ArmMesh", "primitives": [{"attributes": {
                "POSITION": 0, "NORMAL": 1, "JOINTS_0": 2, "WEIGHTS_0": 3}, "indices": 4}]}
        ],
        "skins": [{"joints": [0, 1, 2], "inverseBindMatrices": 5}],
        "animations": [{
            "name": "Swing",
            "channels": [{"sampler": 0, "target": {"node": 1, "path": "rotation"}}],
            "samplers": [{"input": 6, "output": 7, "interpolation": "LINEAR"}],
        }],
        "accessors": [
            {"bufferView": 0, "componentType": 5126, "count": 8, "type": "VEC3",
             "min": [-0.1, -0.1, -0.1], "max": [0.1, 0.1, 0.1]},
            {"bufferView": 1, "componentType": 5126, "count": 8, "type": "VEC3"},
            {"bufferView": 2, "componentType": 5121, "count": 8, "type": "VEC4"},
            {"bufferView": 3, "componentType": 5126, "count": 8, "type": "VEC4"},
            {"bufferView": 4, "componentType": 5125, "count": 36, "type": "SCALAR"},
            {"bufferView": 5, "componentType": 5126, "count": 3, "type": "MAT4"},
            {"bufferView": 6, "componentType": 5126, "count": 4, "type": "SCALAR", "min": [0], "max": [3]},
            {"bufferView": 7, "componentType": 5126, "count": 4, "type": "VEC4"},
        ],
        "bufferViews": views,
        "buffers": [{"byteLength": offset}],
    }

    # 修正节点层级（root 包含 bone，bone 包含 tip）。
    gltf["nodes"][0]["children"] = [1]
    gltf["nodes"][1]["children"] = [2]

    out_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "content")
    os.makedirs(out_dir, exist_ok=True)
    out_path = os.path.join(out_dir, "arm_anim.glb")
    with open(out_path, "wb") as f:
        f.write(build_glb(gltf, bin_data))
    print(f"已生成 {out_path} ({os.path.getsize(out_path)} 字节)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
