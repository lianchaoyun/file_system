#!/usr/bin/env python3
"""查看 glb 的 skin 与 JOINTS/WEIGHTS 结构。"""
import json
import struct
import sys


def main(path):
    with open(path, "rb") as f:
        f.read(12)
        clen, _ = struct.unpack("<II", f.read(8))
        data = f.read(clen)
    j = json.loads(data.rstrip(b" \x00").decode("utf-8"))
    for i, s in enumerate(j.get("skins", [])):
        ibm = s.get("inverseBindMatrices")
        print(f"skin{i}: joints={len(s.get('joints', []))} ibmAccessor={ibm}")
        if ibm is not None:
            a = j["accessors"][ibm]
            print(f"  ibm count={a['count']} type={a['type']} compType={a['componentType']}")
    for m in j["meshes"]:
        for pr in m["primitives"]:
            attrs = pr.get("attributes", {})
            jt = attrs.get("JOINTS_0")
            wt = attrs.get("WEIGHTS_0")
            if jt is not None:
                a = j["accessors"][jt]
                w = j["accessors"][wt]
                print(f"  JOINTS_0: type={a['type']} compType={a['componentType']} count={a['count']}")
                print(f"  WEIGHTS_0: type={w['type']} compType={w['componentType']} count={w['count']}")
            break
        break
    # 挂 mesh 的 node 是否有 skin
    for i, n in enumerate(j["nodes"]):
        if n.get("skin") is not None:
            print(f"node{i} ({n.get('name')}): mesh={n.get('mesh')} skin={n.get('skin')}")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1]))
