#!/usr/bin/env python3
"""快速查看 glb 的网格属性/材质/层级结构（用于 M2 调试）。"""
import json
import struct
import sys


def main(path: str) -> int:
    with open(path, "rb") as f:
        magic, ver, length = struct.unpack("<III", f.read(12))
        clen, ctype = struct.unpack("<II", f.read(8))
        data = f.read(clen)
    j = json.loads(data.rstrip(b" \x00").decode("utf-8"))
    print(f"version={ver} size={length/1e6:.2f}MB")
    print(f"meshes={len(j.get('meshes', []))} nodes={len(j.get('nodes', []))} "
          f"materials={len(j.get('materials', []))} skins={len(j.get('skins', []))} "
          f"animations={len(j.get('animations', []))}")
    for mi, m in enumerate(j["meshes"]):
        for pi, pr in enumerate(m["primitives"]):
            attrs = list(pr.get("attributes", {}).keys())
            pos = pr["attributes"].get("POSITION")
            vcount = j["accessors"][pos]["count"] if pos is not None else 0
            icount = j["accessors"][pr["indices"]]["count"] if "indices" in pr else 0
            print(f"  mesh{mi}.prim{pi}: attrs={attrs} verts={vcount} indices={icount} "
                  f"material={pr.get('material')}")
    for i, mat in enumerate(j.get("materials", [])):
        pbr = mat.get("pbrMetallicRoughness", {})
        print(f"  mat{i}: name={mat.get('name', '?')} "
              f"baseColorFactor={pbr.get('baseColorFactor')} "
              f"baseColorTexture={pbr.get('baseColorTexture')}")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1]))
