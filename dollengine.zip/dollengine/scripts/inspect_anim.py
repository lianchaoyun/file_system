#!/usr/bin/env python3
"""查看 glb 的 animation 结构。"""
import json
import struct
import sys


def main(path):
    with open(path, "rb") as f:
        f.read(12)
        clen, _ = struct.unpack("<II", f.read(8))
        data = f.read(clen)
    j = json.loads(data.rstrip(b" \x00").decode("utf-8"))
    for ai, anim in enumerate(j.get("animations", [])):
        print(f"animation{ai}: name={anim.get('name')} channels={len(anim.get('channels', []))} "
              f"samplers={len(anim.get('samplers', []))}")
        # 采样器的时间范围
        for si, s in enumerate(anim.get("samplers", [])):
            inp = j["accessors"][s["input"]]
            out = j["accessors"][s["output"]]
            mn = inp.get("min", [None])[0]
            mx = inp.get("max", [None])[0]
            print(f"  sampler{si}: interp={s.get('interpolation')} "
                  f"t=[{mn}, {mx}] keys={inp['count']} outType={out['type']} outCount={out['count']}")
        # channel 的 path 分布
        paths = {}
        for c in anim.get("channels", []):
            p = c["target"]["path"]
            paths[p] = paths.get(p, 0) + 1
        print(f"  channel paths: {paths}")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1]))
