#!/usr/bin/env python3
"""生成示例 GLB：彩色立方体 + 父子节点层级。

用于 M2 GLB 导入器的单元测试与手动验证。
输出：content/sample_cube.glb
"""
import json
import struct
import os
import sys


def pad4(data: bytes, pad_byte: int = 0x00) -> bytes:
    return data + bytes([pad_byte]) * ((4 - len(data) % 4) % 4)


def build_glb(json_obj: dict, bin_data: bytes) -> bytes:
    # GLB 规范：JSON chunk 用空格 0x20 填充，BIN chunk 用 0x00 填充。
    json_bytes = pad4(json.dumps(json_obj, separators=(",", ":")).encode("utf-8"), 0x20)
    bin_bytes = pad4(bin_data, 0x00)
    header = struct.pack("<III", 0x46546C67, 2, 12 + 8 + len(json_bytes) + 8 + len(bin_bytes))
    json_chunk = struct.pack("<II", len(json_bytes), 0x4E4F534A) + json_bytes
    bin_chunk = struct.pack("<II", len(bin_bytes), 0x004E4942) + bin_bytes
    return header + json_chunk + bin_chunk


def main() -> int:
    # 8 顶点（位置 / 法线 / 颜色），法线用位置归一化近似。
    positions = [
        (-0.5, -0.5, -0.5),
        (-0.5, -0.5, 0.5),
        (-0.5, 0.5, 0.5),
        (-0.5, 0.5, -0.5),
        (0.5, -0.5, -0.5),
        (0.5, -0.5, 0.5),
        (0.5, 0.5, 0.5),
        (0.5, 0.5, -0.5),
    ]
    colors = [
        (1.0, 0.0, 0.0),
        (0.0, 1.0, 0.0),
        (0.0, 0.0, 1.0),
        (1.0, 1.0, 0.0),
        (1.0, 0.0, 1.0),
        (0.0, 1.0, 1.0),
        (1.0, 1.0, 1.0),
        (0.5, 0.5, 0.5),
    ]
    # 法线：位置归一化（单位立方体角点方向）。
    import math
    normals = []
    for p in positions:
        length = math.sqrt(p[0] * p[0] + p[1] * p[1] + p[2] * p[2])
        normals.append((p[0] / length, p[1] / length, p[2] / length))

    indices = [
        0, 3, 2, 0, 2, 1,  # 左面
        4, 5, 6, 4, 6, 7,  # 右面
        0, 4, 7, 0, 7, 3,  # 后面
        1, 2, 6, 1, 6, 5,  # 前面
        0, 4, 5, 0, 5, 1,  # 底面
        3, 7, 6, 3, 6, 2,  # 顶面
    ]

    pos_bytes = b"".join(struct.pack("<3f", *p) for p in positions)
    nor_bytes = b"".join(struct.pack("<3f", *n) for n in normals)
    col_bytes = b"".join(struct.pack("<3f", *c) for c in colors)
    idx_bytes = b"".join(struct.pack("<I", i) for i in indices)

    offset = 0
    pos_view = {"buffer": 0, "byteOffset": offset, "byteLength": len(pos_bytes)}
    offset += len(pos_bytes)
    nor_view = {"buffer": 0, "byteOffset": offset, "byteLength": len(nor_bytes)}
    offset += len(nor_bytes)
    col_view = {"buffer": 0, "byteOffset": offset, "byteLength": len(col_bytes)}
    offset += len(col_bytes)
    idx_view = {"buffer": 0, "byteOffset": offset, "byteLength": len(idx_bytes)}

    gltf = {
        "asset": {"version": "2.0", "generator": "dollengine/gen_sample_glb"},
        "scene": 0,
        "scenes": [{"nodes": [0]}],
        "nodes": [
            {"name": "Root", "children": [1]},
            {"name": "Cube", "mesh": 0, "translation": [0.0, 0.5, 0.0]},
        ],
        "meshes": [
            {
                "name": "CubeMesh",
                "primitives": [
                    {
                        "attributes": {"POSITION": 0, "NORMAL": 1, "COLOR_0": 2},
                        "indices": 3,
                        "material": 0,
                    }
                ],
            }
        ],
        "materials": [
            {
                "name": "CubeMat",
                "pbrMetallicRoughness": {
                    "baseColorFactor": [1.0, 1.0, 1.0, 1.0],
                    "metallicFactor": 0.0,
                    "roughnessFactor": 1.0,
                },
            }
        ],
        "accessors": [
            {"bufferView": 0, "componentType": 5126, "count": 8, "type": "VEC3",
             "min": [-0.5, -0.5, -0.5], "max": [0.5, 0.5, 0.5]},
            {"bufferView": 1, "componentType": 5126, "count": 8, "type": "VEC3"},
            {"bufferView": 2, "componentType": 5126, "count": 8, "type": "VEC3"},
            {"bufferView": 3, "componentType": 5125, "count": 36, "type": "SCALAR"},
        ],
        "bufferViews": [pos_view, nor_view, col_view, idx_view],
        "buffers": [{"byteLength": len(pos_bytes) + len(nor_bytes) + len(col_bytes) + len(idx_bytes)}],
    }

    out_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "content")
    os.makedirs(out_dir, exist_ok=True)
    out_path = os.path.join(out_dir, "sample_cube.glb")
    with open(out_path, "wb") as f:
        f.write(build_glb(gltf, pos_bytes + nor_bytes + col_bytes + idx_bytes))
    print(f"已生成 {out_path} ({os.path.getsize(out_path)} 字节)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
