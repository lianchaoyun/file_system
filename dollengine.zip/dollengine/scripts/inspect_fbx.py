#!/usr/bin/env python3
"""粗略检查 FBX 里是否含骨骼动画（搜索 FBX 节点关键字）。"""
import sys


def main(path):
    with open(path, "rb") as f:
        data = f.read()
    size_mb = len(data) / 1048576
    print(f"=== {path} ({size_mb:.2f} MB) ===")
    keywords = [
        (b"Kaydara FBX Binary", "FBX 二进制头"),
        (b"AnimationStack", "动画栈"),
        (b"AnimationLayer", "动画层"),
        (b"AnimCurveNode", "动画曲线节点"),
        (b"AnimCurve", "动画曲线"),
        (b"Deformer", "蒙皮变形器"),
        (b"Cluster", "蒙皮簇"),
        (b"LimbNode", "骨骼节点"),
        (b"BlendShape", "形变（morph）"),
    ]
    for needle, label in keywords:
        print(f"  {label:12s} ({needle.decode()}): {'有' if needle in data else '无'}")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1]))
