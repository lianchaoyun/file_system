"""在 Blender 里运行：诊断动画数据，并重新导出带骨骼动画的 glb。

用法：
1. Blender 打开 xiaowu.blend
2. 切到 Scripting（脚本）工作区
3. Open 打开这个文件 → Run Script（运行脚本）
4. 看底部控制台输出，检查导出的 glb

导出后可用：
  python scripts/inspect_anim.py "content/xiaowu_anim_ok.glb"
确认 channels 里出现 rotation/translation。
"""
import bpy

OUTPUT = r"D:\project\test\dollengine\content\xiaowu_anim_ok.glb"

print("\n================ 1. 对象动画数据 ================")
for obj in bpy.data.objects:
    ad = obj.animation_data
    if ad is None:
        print(f"  {obj.name} ({obj.type}): 无 animation_data")
        continue
    action = ad.action.name if ad.action else None
    print(f"  {obj.name} ({obj.type}): action={action}, nla_tracks={len(ad.nla_tracks)}")
    for track in ad.nla_tracks:
        strips = ", ".join(s.name for s in track.strips) or "(空)"
        print(f"      NLA: {track.name}  strips=[{strips}]  mute={track.mute}")

print("\n================ 2. 所有 Actions ================")
if not bpy.data.actions:
    print("  (没有任何 Action —— 这是动画没导出的根本原因)")
for action in bpy.data.actions:
    start, end = action.frame_range
    print(f"  {action.name}: frames {start:.1f} ~ {end:.1f}, fcurves={len(action.fcurves)}")

print("\n================ 3. 导出 glb ================")
# 优先用完整参数（含骨骼采样），Blender 版本不支持时退回最小参数。
full_kwargs = dict(
    filepath=OUTPUT,
    export_format='GLB',
    export_animations=True,
    export_animation_mode='ACTIONS',   # 导出所有 Action（而非仅当前帧）
    export_bake_animation=True,        # 烘焙骨骼动画
    export_force_sampling=True,        # 每帧采样，保证骨骼关键帧写进 glb
    export_frame_range=False,          # 用 Action 自身帧范围
    export_current_frame=False,
    export_optimize_animation_size=False,  # 不裁剪关键帧，避免动画被压成 1 帧
    export_apply=False,
)
try:
    bpy.ops.export_scene.gltf(**full_kwargs)
    print(f"  导出成功（完整参数）: {OUTPUT}")
except TypeError as exc:
    print(f"  完整参数不被支持（{exc}），改用最小参数重试")
    bpy.ops.export_scene.gltf(
        filepath=OUTPUT,
        export_format='GLB',
        export_animations=True,
    )
    print(f"  导出成功（最小参数）: {OUTPUT}")

print("\n请回到命令行执行：python scripts/inspect_anim.py \"content/xiaowu_anim_ok.glb\"")
print("若看到 channel paths 里有 rotation/translation，说明骨骼动画已正确导出。")
