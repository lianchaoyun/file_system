#!/usr/bin/env python3
"""检查 glb 的 morph targets。"""
import json
import struct
import sys


def main(path):
    with open(path, "rb") as f:
        f.read(12)
        clen, _ = struct.unpack("<II", f.read(8))
        data = f.read(clen)
    j = json.loads(data.rstrip(b" \x00").decode("utf-8"))
    for i, m in enumerate(j.get("meshes", [])):
        for k, pr in enumerate(m["primitives"]):
            tgt = pr.get("targets", [])
            exw = pr.get("extras", {})
            names = exw.get("targetNames") if isinstance(exw, dict) else None
            print(f"mesh{i} prim{k}: targets={len(tgt)} targetNames={names}")
            if tgt:
                print(f"  target attrs: {list(tgt[0].keys())}")
        break
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1]))
