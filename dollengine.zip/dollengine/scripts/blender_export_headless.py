"""Blender 无头模式导出脚本（由命令行用 --background --python 调用）。

用法：
  blender.exe --background "xiaowu.blend" --python blender_export_headless.py
"""
import bpy

OUTPUT = r"D:\project\test\dollengine\content\xiaowu_anim_ok.glb"

print("\n========== 1. 对象动画数据 ==========")
for obj in bpy.data.objects:
    ad = obj.animation_data
    if ad is None:
        print(f"  {obj.name} ({obj.type}): 无 animation_data")
        continue
    action = ad.action.name if ad.action else None
    print(f"  {obj.name} ({obj.type}): action={action}, nla_tracks={len(ad.nla_tracks)}")
    for track in ad.nla_tracks:
        strips = ", ".join(s.name for s in track.strips) or "(空)"
        print(f"      NLA: {track.name}  strips=[{strips}]  mute={track.mute}")

print("\n========== 2. Actions ==========")
if not bpy.data.actions:
    print("  (没有任何 Action)")
for action in bpy.data.actions:
    start, end = action.frame_range
    # Blender 5.x 的 Action 改用 layers/slots，不再有 fcurves 属性。
    print(f"  {action.name}: frames {start:.1f} ~ {end:.1f}")

print("\n========== 3. 导出 glb ==========")
kwargs = dict(
    filepath=OUTPUT,
    export_format='GLB',
    export_animations=True,
    export_animation_mode='ACTIONS',
    export_bake_animation=True,
    export_force_sampling=True,
    export_frame_range=False,
    export_current_frame=False,
    export_optimize_animation_size=False,
    export_apply=False,
)
try:
    bpy.ops.export_scene.gltf(**kwargs)
    print(f"导出成功（完整参数）: {OUTPUT}")
except TypeError as exc:
    print(f"完整参数不被支持: {exc}")
    bpy.ops.export_scene.gltf(
        filepath=OUTPUT,
        export_format='GLB',
        export_animations=True,
    )
    print(f"导出成功（最小参数）: {OUTPUT}")
