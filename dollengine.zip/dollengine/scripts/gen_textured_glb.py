#!/usr/bin/env python3
"""生成带棋盘格纹理的平面 glb（用于 M2 纹理渲染测试）。

输出：content/textured_plane.glb
"""
import json
import struct
import os
import sys
import zlib


def pad4(data: bytes, pad_byte: int = 0x00) -> bytes:
    return data + bytes([pad_byte]) * ((4 - len(data) % 4) % 4)


def png_chunk(ctype: bytes, data: bytes) -> bytes:
    c = ctype + data
    return struct.pack(">I", len(data)) + c + struct.pack(">I", zlib.crc32(c) & 0xFFFFFFFF)


def make_png(width: int, height: int, rgba: bytes) -> bytes:
    signature = b"\x89PNG\r\n\x1a\n"
    ihdr = struct.pack(">IIBBBBB", width, height, 8, 6, 0, 0, 0)  # 8bit RGBA
    raw = b"".join(b"\x00" + rgba[y * width * 4:(y + 1) * width * 4] for y in range(height))
    idat = zlib.compress(raw)
    return signature + png_chunk(b"IHDR", ihdr) + png_chunk(b"IDAT", idat) + png_chunk(b"IEND", b"")


def checkerboard(size: int, cell: int) -> bytes:
    rgba = bytearray()
    for y in range(size):
        for x in range(size):
            if (x // cell + y // cell) % 2 == 0:
                rgba += bytes([220, 60, 60, 255])   # 红
            else:
                rgba += bytes([240, 240, 240, 255])  # 白
    return bytes(rgba)


def build_glb(json_obj: dict, bin_data: bytes) -> bytes:
    json_bytes = pad4(json.dumps(json_obj, separators=(",", ":")).encode("utf-8"), 0x20)
    bin_bytes = pad4(bin_data, 0x00)
    header = struct.pack("<III", 0x46546C67, 2, 12 + 8 + len(json_bytes) + 8 + len(bin_bytes))
    json_chunk = struct.pack("<II", len(json_bytes), 0x4E4F534A) + json_bytes
    bin_chunk = struct.pack("<II", len(bin_bytes), 0x004E4942) + bin_bytes
    return header + json_chunk + bin_chunk


def main() -> int:
    # 平面（XZ，y=0），4 顶点，UV 0..1。
    positions = [
        (-1.0, 0.0, -1.0),
        (1.0, 0.0, -1.0),
        (1.0, 0.0, 1.0),
        (-1.0, 0.0, 1.0),
    ]
    normals = [(0.0, 1.0, 0.0)] * 4
    uvs = [(0.0, 0.0), (1.0, 0.0), (1.0, 1.0), (0.0, 1.0)]
    indices = [0, 1, 2, 0, 2, 3]

    pos_bytes = b"".join(struct.pack("<3f", *p) for p in positions)
    nor_bytes = b"".join(struct.pack("<3f", *n) for n in normals)
    uv_bytes = b"".join(struct.pack("<2f", *u) for u in uvs)
    idx_bytes = b"".join(struct.pack("<I", i) for i in indices)

    png = make_png(8, 8, checkerboard(8, 2))

    # BIN 布局：顶点数据 + 索引 + PNG 图像。
    offset = 0
    pos_view = {"buffer": 0, "byteOffset": offset, "byteLength": len(pos_bytes)}
    offset += len(pos_bytes)
    nor_view = {"buffer": 0, "byteOffset": offset, "byteLength": len(nor_bytes)}
    offset += len(nor_bytes)
    uv_view = {"buffer": 0, "byteOffset": offset, "byteLength": len(uv_bytes)}
    offset += len(uv_bytes)
    idx_view = {"buffer": 0, "byteOffset": offset, "byteLength": len(idx_bytes)}
    offset += len(idx_bytes)
    # PNG 需要 4 字节对齐
    offset = (offset + 3) // 4 * 4
    img_view = {"buffer": 0, "byteOffset": offset, "byteLength": len(png)}
    offset += len(png)
    offset = (offset + 3) // 4 * 4

    bin_data = pos_bytes + nor_bytes + uv_bytes + idx_bytes
    bin_data += b"\x00" * (img_view["byteOffset"] - len(bin_data)) + png
    bin_data += b"\x00" * (offset - len(bin_data))

    gltf = {
        "asset": {"version": "2.0", "generator": "dollengine/gen_textured_glb"},
        "scene": 0,
        "scenes": [{"nodes": [0]}],
        "nodes": [{"name": "TexturedPlane", "mesh": 0}],
        "meshes": [
            {
                "name": "Plane",
                "primitives": [
                    {
                        "attributes": {"POSITION": 0, "NORMAL": 1, "TEXCOORD_0": 2},
                        "indices": 3,
                        "material": 0,
                    }
                ],
            }
        ],
        "materials": [
            {
                "name": "CheckerMat",
                "pbrMetallicRoughness": {
                    "baseColorFactor": [1.0, 1.0, 1.0, 1.0],
                    "baseColorTexture": {"index": 0},
                    "metallicFactor": 0.0,
                    "roughnessFactor": 1.0,
                },
            }
        ],
        "textures": [{"source": 0}],
        "images": [{"bufferView": 4, "mimeType": "image/png"}],
        "accessors": [
            {"bufferView": 0, "componentType": 5126, "count": 4, "type": "VEC3",
             "min": [-1, 0, -1], "max": [1, 0, 1]},
            {"bufferView": 1, "componentType": 5126, "count": 4, "type": "VEC3"},
            {"bufferView": 2, "componentType": 5126, "count": 4, "type": "VEC2"},
            {"bufferView": 3, "componentType": 5125, "count": 6, "type": "SCALAR"},
        ],
        "bufferViews": [pos_view, nor_view, uv_view, idx_view, img_view],
        "buffers": [{"byteLength": offset}],
    }

    out_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "content")
    os.makedirs(out_dir, exist_ok=True)
    out_path = os.path.join(out_dir, "textured_plane.glb")
    with open(out_path, "wb") as f:
        f.write(build_glb(gltf, bin_data))
    print(f"已生成 {out_path} ({os.path.getsize(out_path)} 字节)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
