@echo off
setlocal

set "PROJECT_DIR=D:\project\test\dollengine"
set "CMAKE_BIN=C:\Program Files\Microsoft Visual Studio\18\Insiders\Common7\IDE\CommonExtensions\Microsoft\CMake\CMake\bin\cmake.exe"
set "EXE=%PROJECT_DIR%\build\msvc-x64\bin\Debug\dollengine.exe"

cd /d "%PROJECT_DIR%"
if errorlevel 1 (
    echo [ERROR] Project directory not found: %PROJECT_DIR%
    pause
    exit /b 1
)

if not exist "build\msvc-x64\CMakeCache.txt" (
    echo [1/3] Configuring CMake for the first time, this may take a few minutes...
    "%CMAKE_BIN%" --preset msvc-x64
    if errorlevel 1 goto :fail
) else (
    echo [1/3] CMake already configured, skip.
)

echo [2/3] Building...
"%CMAKE_BIN%" --build --preset debug
if errorlevel 1 goto :fail

echo [3/3] Launching dollengine...
echo.
"%EXE%"
if errorlevel 1 (
    echo.
    echo [WARN] Program exited with code %errorlevel%. Check build\msvc-x64\bin\Debug\logs
    pause
)
exit /b 0

:fail
echo.
echo [FAIL] Build failed. Please check the errors above.
pause
exit /b 1
