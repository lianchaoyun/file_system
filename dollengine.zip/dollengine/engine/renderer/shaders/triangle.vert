#version 450

layout(location = 0) in vec3 inPosition;
layout(location = 1) in vec3 inNormal;
layout(location = 2) in vec4 inColor;
layout(location = 3) in vec2 inUV;
layout(location = 4) in uvec4 inJoints;
layout(location = 5) in vec4 inWeights;

layout(location = 0) out vec3 fragColor;
layout(location = 1) out vec3 fragNormal;
layout(location = 2) out vec2 fragUV;

layout(push_constant) uniform PushConstants {
    mat4 mvp;
    vec4 baseColor;
} pc;

// 蒙皮矩阵数组（无蒙皮时 joints 全 0，weights=(1,0,0,0)，等价于单位矩阵）。
// binding 1 = vertex stage 的 uniform buffer（binding 0 是 fragment 的纹理采样器）。
layout(binding = 1) uniform SkinningMatrices {
    mat4 joints[256];
} skin;

void main() {
    mat4 skinMatrix =
        skin.joints[inJoints.x] * inWeights.x +
        skin.joints[inJoints.y] * inWeights.y +
        skin.joints[inJoints.z] * inWeights.z +
        skin.joints[inJoints.w] * inWeights.w;

    gl_Position = pc.mvp * (skinMatrix * vec4(inPosition, 1.0));

    // 法线用蒙皮矩阵的线性部分变换（M3 忽略非均匀缩放的精确法线）。
    vec3 skinnedNormal = mat3(skinMatrix) * inNormal;

    fragColor = (inColor * pc.baseColor).rgb;
    fragNormal = skinnedNormal;
    fragUV = inUV;
}
