#version 450

layout(binding = 0) uniform sampler2D baseColorSampler;

layout(location = 0) in vec3 fragColor;
layout(location = 1) in vec3 fragNormal;
layout(location = 2) in vec2 fragUV;

layout(location = 0) out vec4 outColor;

void main() {
    // 纹理采样（无纹理材质绑定白色占位纹理，结果等价于只用材质色）。
    const vec3 baseColor = fragColor * texture(baseColorSampler, fragUV).rgb;

    // 简单方向光 + 环境光（M3 换 PBR 光照）。
    const vec3 lightDir = normalize(vec3(0.5, 1.0, 0.7));
    const float diffuse = max(dot(normalize(fragNormal), lightDir), 0.0);
    outColor = vec4(baseColor * (0.35 + 0.65 * diffuse), 1.0);
}
