#include "VulkanRenderer.h"

#include <vulkan/vulkan.h>

#include <algorithm>
#include <cstddef>
#include <cstring>
#include <format>
#include <fstream>
#include <vector>

#include "Log.h"
#include "VkUtil.h"
#include "VulkanDevice.h"

namespace doll::renderer {

namespace {

/// 场景清屏颜色（Blender/DAZ 风格的深灰视口背景）。
constexpr float kSceneClearColor[4] = {0.18f, 0.18f, 0.20f, 1.0f};

/// 主通道清屏颜色（UI 之外的边角，通常被面板完全覆盖）。
constexpr float kMainClearColor[4] = {0.09f, 0.09f, 0.11f, 1.0f};

/// 读文件为字节串（加载 .spv）。
std::vector<char> readFile(const std::filesystem::path& path) {
    std::ifstream file(path, std::ios::ate | std::ios::binary);
    if (!file.is_open()) {
        return {};
    }
    const std::streamsize size = file.tellg();
    std::vector<char> buffer(static_cast<std::size_t>(size));
    file.seekg(0);
    file.read(buffer.data(), size);
    return buffer;
}

/// 加载并创建着色器模块，失败返回 VK_NULL_HANDLE。
VkShaderModule createShaderModule(VkDevice device, const std::filesystem::path& shaderDir,
                                  const char* filename) {
    const std::vector<char> code = readFile(shaderDir / filename);
    if (code.empty()) {
        DOLL_LOG_ERROR("vulkan", "着色器文件读取失败：{}", (shaderDir / filename).string());
        return VK_NULL_HANDLE;
    }
    VkShaderModuleCreateInfo createInfo{};
    createInfo.sType = VK_STRUCTURE_TYPE_SHADER_MODULE_CREATE_INFO;
    createInfo.codeSize = code.size();
    createInfo.pCode = reinterpret_cast<const std::uint32_t*>(code.data());
    VkShaderModule module = VK_NULL_HANDLE;
    if (vkCreateShaderModule(device, &createInfo, nullptr, &module) != VK_SUCCESS) {
        DOLL_LOG_ERROR("vulkan", "着色器模块创建失败：{}", filename);
        return VK_NULL_HANDLE;
    }
    return module;
}

/// 找第一个支持深度模板附件的格式。
VkFormat findDepthFormat(VkPhysicalDevice physicalDevice) {
    const VkFormat candidates[] = {
        VK_FORMAT_D32_SFLOAT,
        VK_FORMAT_D32_SFLOAT_S8_UINT,
        VK_FORMAT_D24_UNORM_S8_UINT,
    };
    for (const VkFormat format : candidates) {
        VkFormatProperties props;
        vkGetPhysicalDeviceFormatProperties(physicalDevice, format, &props);
        if (props.optimalTilingFeatures & VK_FORMAT_FEATURE_DEPTH_STENCIL_ATTACHMENT_BIT) {
            return format;
        }
    }
    return VK_FORMAT_UNDEFINED;
}

/// 找满足要求的内存类型索引。
std::uint32_t findMemoryType(VkPhysicalDevice physicalDevice, std::uint32_t typeFilter,
                             VkMemoryPropertyFlags properties) {
    VkPhysicalDeviceMemoryProperties memProps;
    vkGetPhysicalDeviceMemoryProperties(physicalDevice, &memProps);
    for (std::uint32_t i = 0; i < memProps.memoryTypeCount; ++i) {
        if ((typeFilter & (1u << i)) &&
            (memProps.memoryTypes[i].propertyFlags & properties) == properties) {
            return i;
        }
    }
    return UINT32_MAX;
}

/// 创建并绑定一块缓冲区（M1 用 HOST_VISIBLE 直接写，M2 再换 staging）。
Status createBuffer(VkDevice device, VkPhysicalDevice physicalDevice, VkDeviceSize size,
                    VkBufferUsageFlags usage, VkMemoryPropertyFlags properties,
                    VkBuffer* buffer, VkDeviceMemory* memory) {
    VkBufferCreateInfo info{};
    info.sType = VK_STRUCTURE_TYPE_BUFFER_CREATE_INFO;
    info.size = size;
    info.usage = usage;
    info.sharingMode = VK_SHARING_MODE_EXCLUSIVE;
    if (vkCreateBuffer(device, &info, nullptr, buffer) != VK_SUCCESS) {
        return Status::fail(ErrorCode::Graphics, "vkCreateBuffer 失败");
    }
    VkMemoryRequirements requirements;
    vkGetBufferMemoryRequirements(device, *buffer, &requirements);
    VkMemoryAllocateInfo allocInfo{};
    allocInfo.sType = VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO;
    allocInfo.allocationSize = requirements.size;
    allocInfo.memoryTypeIndex = findMemoryType(physicalDevice, requirements.memoryTypeBits, properties);
    if (allocInfo.memoryTypeIndex == UINT32_MAX) {
        return Status::fail(ErrorCode::Graphics, "找不到缓冲区所需的内存类型");
    }
    if (vkAllocateMemory(device, &allocInfo, nullptr, memory) != VK_SUCCESS) {
        return Status::fail(ErrorCode::Graphics, "vkAllocateMemory 失败");
    }
    vkBindBufferMemory(device, *buffer, *memory, 0);
    return Status::success();
}

/// 创建 2D 图像 + 显存 + 视图。
Status createImage(VkDevice device, VkPhysicalDevice physicalDevice, std::uint32_t width,
                   std::uint32_t height, VkFormat format, VkImageUsageFlags usage,
                   VkImageAspectFlags aspect, VkImage* image, VkDeviceMemory* memory,
                   VkImageView* view) {
    VkImageCreateInfo imageInfo{};
    imageInfo.sType = VK_STRUCTURE_TYPE_IMAGE_CREATE_INFO;
    imageInfo.imageType = VK_IMAGE_TYPE_2D;
    imageInfo.extent = {width, height, 1};
    imageInfo.mipLevels = 1;
    imageInfo.arrayLayers = 1;
    imageInfo.format = format;
    imageInfo.tiling = VK_IMAGE_TILING_OPTIMAL;
    imageInfo.initialLayout = VK_IMAGE_LAYOUT_UNDEFINED;
    imageInfo.usage = usage;
    imageInfo.samples = VK_SAMPLE_COUNT_1_BIT;
    imageInfo.sharingMode = VK_SHARING_MODE_EXCLUSIVE;
    if (vkCreateImage(device, &imageInfo, nullptr, image) != VK_SUCCESS) {
        return Status::fail(ErrorCode::Graphics, "vkCreateImage 失败");
    }

    VkMemoryRequirements requirements;
    vkGetImageMemoryRequirements(device, *image, &requirements);
    VkMemoryAllocateInfo allocInfo{};
    allocInfo.sType = VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO;
    allocInfo.allocationSize = requirements.size;
    allocInfo.memoryTypeIndex =
        findMemoryType(physicalDevice, requirements.memoryTypeBits, VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);
    if (allocInfo.memoryTypeIndex == UINT32_MAX) {
        return Status::fail(ErrorCode::Graphics, "找不到图像所需的内存类型");
    }
    if (vkAllocateMemory(device, &allocInfo, nullptr, memory) != VK_SUCCESS) {
        return Status::fail(ErrorCode::Graphics, "vkAllocateMemory 失败");
    }
    vkBindImageMemory(device, *image, *memory, 0);

    VkImageViewCreateInfo viewInfo{};
    viewInfo.sType = VK_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO;
    viewInfo.image = *image;
    viewInfo.viewType = VK_IMAGE_VIEW_TYPE_2D;
    viewInfo.format = format;
    viewInfo.subresourceRange.aspectMask = aspect;
    viewInfo.subresourceRange.levelCount = 1;
    viewInfo.subresourceRange.layerCount = 1;
    if (vkCreateImageView(device, &viewInfo, nullptr, view) != VK_SUCCESS) {
        return Status::fail(ErrorCode::Graphics, "vkCreateImageView 失败");
    }
    return Status::success();
}

} // namespace

VulkanRenderer::~VulkanRenderer() {
    shutdown();
}

Status VulkanRenderer::init(VulkanDevice* device, const std::filesystem::path& shaderDir,
                            int sceneWidth, int sceneHeight) {
    if (device == nullptr || device->device() == nullptr) {
        return Status::fail(ErrorCode::InvalidArgument, "VulkanRenderer::init: device 未初始化");
    }
    device_ = device;
    shaderDir_ = shaderDir;

    depthFormat_ = findDepthFormat(device_->physicalDevice());
    if (depthFormat_ == VK_FORMAT_UNDEFINED) {
        return Status::fail(ErrorCode::Graphics, "找不到可用的深度格式");
    }

    if (auto status = createSceneRenderPass(); !status) {
        return status;
    }
    if (auto status = createSceneTarget(sceneWidth, sceneHeight); !status) {
        return status;
    }
    if (auto status = createMainRenderPass(); !status) {
        return status;
    }
    if (auto status = createMainFramebuffers(); !status) {
        return status;
    }
    if (auto status = createTextureResources(); !status) {
        return status;
    }
    if (auto status = createGraphicsPipeline(); !status) {
        return status;
    }
    if (auto status = createGridResources(); !status) {
        return status;
    }
    if (auto status = createCommandPool(); !status) {
        return status;
    }
    if (auto status = createCommandBuffers(); !status) {
        return status;
    }
    return createSyncObjects();
}

Status VulkanRenderer::createSceneRenderPass() {
    VkAttachmentDescription color{};
    color.format = static_cast<VkFormat>(device_->imageFormat());
    color.samples = VK_SAMPLE_COUNT_1_BIT;
    color.loadOp = VK_ATTACHMENT_LOAD_OP_CLEAR;
    color.storeOp = VK_ATTACHMENT_STORE_OP_STORE;
    color.stencilLoadOp = VK_ATTACHMENT_LOAD_OP_DONT_CARE;
    color.stencilStoreOp = VK_ATTACHMENT_STORE_OP_DONT_CARE;
    color.initialLayout = VK_IMAGE_LAYOUT_UNDEFINED;
    // 渲染结束后直接转入 shader 可读，供 ImGui::Image 采样。
    color.finalLayout = VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL;

    VkAttachmentDescription depth{};
    depth.format = static_cast<VkFormat>(depthFormat_);
    depth.samples = VK_SAMPLE_COUNT_1_BIT;
    depth.loadOp = VK_ATTACHMENT_LOAD_OP_CLEAR;
    depth.storeOp = VK_ATTACHMENT_STORE_OP_DONT_CARE;
    depth.stencilLoadOp = VK_ATTACHMENT_LOAD_OP_DONT_CARE;
    depth.stencilStoreOp = VK_ATTACHMENT_STORE_OP_DONT_CARE;
    depth.initialLayout = VK_IMAGE_LAYOUT_UNDEFINED;
    depth.finalLayout = VK_IMAGE_LAYOUT_DEPTH_STENCIL_ATTACHMENT_OPTIMAL;

    VkAttachmentReference colorRef{};
    colorRef.attachment = 0;
    colorRef.layout = VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL;

    VkAttachmentReference depthRef{};
    depthRef.attachment = 1;
    depthRef.layout = VK_IMAGE_LAYOUT_DEPTH_STENCIL_ATTACHMENT_OPTIMAL;

    VkSubpassDescription subpass{};
    subpass.pipelineBindPoint = VK_PIPELINE_BIND_POINT_GRAPHICS;
    subpass.colorAttachmentCount = 1;
    subpass.pColorAttachments = &colorRef;
    subpass.pDepthStencilAttachment = &depthRef;

    VkSubpassDependency dependency{};
    dependency.srcSubpass = VK_SUBPASS_EXTERNAL;
    dependency.dstSubpass = 0;
    dependency.srcStageMask = VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT |
                              VK_PIPELINE_STAGE_EARLY_FRAGMENT_TESTS_BIT;
    dependency.srcAccessMask = 0;
    dependency.dstStageMask = VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT |
                              VK_PIPELINE_STAGE_EARLY_FRAGMENT_TESTS_BIT;
    dependency.dstAccessMask = VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT |
                               VK_ACCESS_DEPTH_STENCIL_ATTACHMENT_WRITE_BIT;

    const VkAttachmentDescription attachments[] = {color, depth};
    VkRenderPassCreateInfo createInfo{};
    createInfo.sType = VK_STRUCTURE_TYPE_RENDER_PASS_CREATE_INFO;
    createInfo.attachmentCount = 2;
    createInfo.pAttachments = attachments;
    createInfo.subpassCount = 1;
    createInfo.pSubpasses = &subpass;
    createInfo.dependencyCount = 1;
    createInfo.pDependencies = &dependency;

    const VkResult result = vkCreateRenderPass(device_->device(), &createInfo, nullptr, &sceneRenderPass_);
    if (result != VK_SUCCESS) {
        return Status::fail(ErrorCode::Graphics,
                            std::format("vkCreateRenderPass（场景）失败: {}", vkResultToString(result)));
    }
    DOLL_LOG_INFO("vulkan", "场景渲染通道已创建");
    return Status::success();
}

Status VulkanRenderer::createSceneTarget(int width, int height) {
    if (width <= 0 || height <= 0) {
        return Status::success();
    }
    sceneWidth_ = static_cast<std::uint32_t>(width);
    sceneHeight_ = static_cast<std::uint32_t>(height);

    // 颜色格式与交换链一致（UI 层用它建纹理描述符）。
    sceneColorFormat_ = device_->imageFormat();

    VkDevice device = device_->device();
    VkPhysicalDevice physicalDevice = device_->physicalDevice();

    if (auto status = createImage(device, physicalDevice, sceneWidth_, sceneHeight_,
                                  static_cast<VkFormat>(sceneColorFormat_),
                                  VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT | VK_IMAGE_USAGE_SAMPLED_BIT,
                                  VK_IMAGE_ASPECT_COLOR_BIT,
                                  &sceneColorImage_, &sceneColorMemory_, &sceneColorView_);
        !status) {
        return status;
    }
    if (auto status = createImage(device, physicalDevice, sceneWidth_, sceneHeight_,
                                  static_cast<VkFormat>(depthFormat_),
                                  VK_IMAGE_USAGE_DEPTH_STENCIL_ATTACHMENT_BIT,
                                  VK_IMAGE_ASPECT_DEPTH_BIT,
                                  &sceneDepthImage_, &sceneDepthMemory_, &sceneDepthView_);
        !status) {
        return status;
    }

    const VkImageView attachments[] = {sceneColorView_, sceneDepthView_};
    VkFramebufferCreateInfo createInfo{};
    createInfo.sType = VK_STRUCTURE_TYPE_FRAMEBUFFER_CREATE_INFO;
    createInfo.renderPass = sceneRenderPass_;
    createInfo.attachmentCount = 2;
    createInfo.pAttachments = attachments;
    createInfo.width = sceneWidth_;
    createInfo.height = sceneHeight_;
    createInfo.layers = 1;
    if (vkCreateFramebuffer(device, &createInfo, nullptr, &sceneFramebuffer_) != VK_SUCCESS) {
        return Status::fail(ErrorCode::Graphics, "vkCreateFramebuffer（场景）失败");
    }

    DOLL_LOG_INFO("vulkan", "离屏场景目标已创建（{}x{}）", sceneWidth_, sceneHeight_);
    return Status::success();
}

void VulkanRenderer::destroySceneTarget() {
    VkDevice device = device_->device();
    if (sceneFramebuffer_ != VK_NULL_HANDLE) {
        vkDestroyFramebuffer(device, sceneFramebuffer_, nullptr);
        sceneFramebuffer_ = VK_NULL_HANDLE;
    }
    if (sceneColorView_ != VK_NULL_HANDLE) {
        vkDestroyImageView(device, sceneColorView_, nullptr);
        sceneColorView_ = VK_NULL_HANDLE;
    }
    if (sceneColorImage_ != VK_NULL_HANDLE) {
        vkDestroyImage(device, sceneColorImage_, nullptr);
        sceneColorImage_ = VK_NULL_HANDLE;
    }
    if (sceneColorMemory_ != VK_NULL_HANDLE) {
        vkFreeMemory(device, sceneColorMemory_, nullptr);
        sceneColorMemory_ = VK_NULL_HANDLE;
    }
    if (sceneDepthView_ != VK_NULL_HANDLE) {
        vkDestroyImageView(device, sceneDepthView_, nullptr);
        sceneDepthView_ = VK_NULL_HANDLE;
    }
    if (sceneDepthImage_ != VK_NULL_HANDLE) {
        vkDestroyImage(device, sceneDepthImage_, nullptr);
        sceneDepthImage_ = VK_NULL_HANDLE;
    }
    if (sceneDepthMemory_ != VK_NULL_HANDLE) {
        vkFreeMemory(device, sceneDepthMemory_, nullptr);
        sceneDepthMemory_ = VK_NULL_HANDLE;
    }
    sceneWidth_ = 0;
    sceneHeight_ = 0;
}

Status VulkanRenderer::createMainRenderPass() {
    VkAttachmentDescription color{};
    color.format = static_cast<VkFormat>(device_->imageFormat());
    color.samples = VK_SAMPLE_COUNT_1_BIT;
    color.loadOp = VK_ATTACHMENT_LOAD_OP_CLEAR;
    color.storeOp = VK_ATTACHMENT_STORE_OP_STORE;
    color.stencilLoadOp = VK_ATTACHMENT_LOAD_OP_DONT_CARE;
    color.stencilStoreOp = VK_ATTACHMENT_STORE_OP_DONT_CARE;
    color.initialLayout = VK_IMAGE_LAYOUT_UNDEFINED;
    color.finalLayout = VK_IMAGE_LAYOUT_PRESENT_SRC_KHR;

    VkAttachmentReference colorRef{};
    colorRef.attachment = 0;
    colorRef.layout = VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL;

    VkSubpassDescription subpass{};
    subpass.pipelineBindPoint = VK_PIPELINE_BIND_POINT_GRAPHICS;
    subpass.colorAttachmentCount = 1;
    subpass.pColorAttachments = &colorRef;

    VkSubpassDependency dependency{};
    dependency.srcSubpass = VK_SUBPASS_EXTERNAL;
    dependency.dstSubpass = 0;
    dependency.srcStageMask = VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT;
    dependency.srcAccessMask = 0;
    dependency.dstStageMask = VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT;
    dependency.dstAccessMask = VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT;

    VkRenderPassCreateInfo createInfo{};
    createInfo.sType = VK_STRUCTURE_TYPE_RENDER_PASS_CREATE_INFO;
    createInfo.attachmentCount = 1;
    createInfo.pAttachments = &color;
    createInfo.subpassCount = 1;
    createInfo.pSubpasses = &subpass;
    createInfo.dependencyCount = 1;
    createInfo.pDependencies = &dependency;

    const VkResult result = vkCreateRenderPass(device_->device(), &createInfo, nullptr, &mainRenderPass_);
    if (result != VK_SUCCESS) {
        return Status::fail(ErrorCode::Graphics,
                            std::format("vkCreateRenderPass（主）失败: {}", vkResultToString(result)));
    }
    DOLL_LOG_INFO("vulkan", "主渲染通道已创建");
    return Status::success();
}

void VulkanRenderer::destroyMainFramebuffers() {
    for (const VkFramebuffer fb : mainFramebuffers_) {
        vkDestroyFramebuffer(device_->device(), fb, nullptr);
    }
    mainFramebuffers_.clear();
}

Status VulkanRenderer::createMainFramebuffers() {
    const auto& views = device_->imageViews();
    VkExtent2D extent{device_->imageWidth(), device_->imageHeight()};

    mainFramebuffers_.reserve(views.size());
    for (const VkImageView view : views) {
        VkFramebufferCreateInfo createInfo{};
        createInfo.sType = VK_STRUCTURE_TYPE_FRAMEBUFFER_CREATE_INFO;
        createInfo.renderPass = mainRenderPass_;
        createInfo.attachmentCount = 1;
        createInfo.pAttachments = &view;
        createInfo.width = extent.width;
        createInfo.height = extent.height;
        createInfo.layers = 1;

        VkFramebuffer framebuffer = VK_NULL_HANDLE;
        const VkResult result = vkCreateFramebuffer(device_->device(), &createInfo, nullptr, &framebuffer);
        if (result != VK_SUCCESS) {
            destroyMainFramebuffers();
            return Status::fail(ErrorCode::Graphics,
                                std::format("vkCreateFramebuffer（主）失败: {}", vkResultToString(result)));
        }
        mainFramebuffers_.push_back(framebuffer);
    }
    DOLL_LOG_INFO("vulkan", "主帧缓冲已创建（{} 个）", mainFramebuffers_.size());
    return Status::success();
}

Status VulkanRenderer::onSwapchainRecreated() {
    vkDeviceWaitIdle(device_->device());
    destroyMainFramebuffers();
    return createMainFramebuffers();
}

Status VulkanRenderer::resizeSceneTarget(int width, int height) {
    if (width <= 0 || height <= 0) {
        return Status::success();
    }
    if (width == static_cast<int>(sceneWidth_) && height == static_cast<int>(sceneHeight_)) {
        return Status::success();
    }
    vkDeviceWaitIdle(device_->device());
    destroySceneTarget();
    return createSceneTarget(width, height);
}

void VulkanRenderer::destroyMeshes() {
    VkDevice device = device_->device();
    for (auto& mesh : meshes_) {
        if (mesh.indexBuffer != VK_NULL_HANDLE) {
            vkDestroyBuffer(device, mesh.indexBuffer, nullptr);
        }
        if (mesh.indexMemory != VK_NULL_HANDLE) {
            vkFreeMemory(device, mesh.indexMemory, nullptr);
        }
        if (mesh.vertexBuffer != VK_NULL_HANDLE) {
            vkDestroyBuffer(device, mesh.vertexBuffer, nullptr);
        }
        if (mesh.vertexMemory != VK_NULL_HANDLE) {
            vkFreeMemory(device, mesh.vertexMemory, nullptr);
        }
    }
    meshes_.clear();
}

void VulkanRenderer::setMeshes(const std::vector<asset::MeshData>& meshes,
                               const std::vector<asset::MaterialData>& materials,
                               const std::vector<asset::TextureImage>& textures) {
    VkDevice device = device_->device();
    VkPhysicalDevice physicalDevice = device_->physicalDevice();

    // 上传材质颜色（baseColorFactor）与纹理索引（GPU 端 +1，0 是白纹理占位）。
    materialColors_.clear();
    materialColors_.reserve(materials.size());
    materialTextures_.clear();
    materialTextures_.reserve(materials.size());
    for (const auto& material : materials) {
        materialColors_.push_back(material.baseColorFactor);
        materialTextures_.push_back(material.baseColorTexture >= 0
                                        ? material.baseColorTexture + 1
                                        : -1);
    }

    // 等待空闲后销毁旧网格与旧纹理（白纹理保留）。
    vkDeviceWaitIdle(device);
    destroyMeshes();
    for (std::size_t i = 1; i < textures_.size(); ++i) {
        destroyTexture(textures_[i]);
    }
    textures_.resize(1); // 保留 index 0 的白纹理

    // 上传纹理。
    for (const auto& texture : textures) {
        if (texture.pixels.empty()) {
            continue;
        }
        textures_.push_back(createTexture(texture.pixels.data(), texture.width, texture.height));
    }

    meshes_.reserve(meshes.size());
    for (const auto& mesh : meshes) {
        GpuMesh gpu;
        gpu.materialIndex = mesh.materialIndex;
        gpu.indexCount = static_cast<std::uint32_t>(mesh.indices.size());

        const VkDeviceSize vertexSize = sizeof(asset::Vertex) * mesh.vertices.size();
        if (auto status = createBuffer(device, physicalDevice, vertexSize, VK_BUFFER_USAGE_VERTEX_BUFFER_BIT,
                                       VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT,
                                       &gpu.vertexBuffer, &gpu.vertexMemory);
            !status) {
            DOLL_LOG_ERROR("vulkan", "上传顶点缓冲失败：{}", status.error().message);
            destroyMeshes();
            return;
        }
        void* data = nullptr;
        vkMapMemory(device, gpu.vertexMemory, 0, vertexSize, 0, &data);
        std::memcpy(data, mesh.vertices.data(), static_cast<std::size_t>(vertexSize));
        vkUnmapMemory(device, gpu.vertexMemory);

        const VkDeviceSize indexSize = sizeof(std::uint32_t) * mesh.indices.size();
        if (indexSize > 0) {
            if (auto status = createBuffer(device, physicalDevice, indexSize, VK_BUFFER_USAGE_INDEX_BUFFER_BIT,
                                           VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT,
                                           &gpu.indexBuffer, &gpu.indexMemory);
                !status) {
                DOLL_LOG_ERROR("vulkan", "上传索引缓冲失败：{}", status.error().message);
                destroyMeshes();
                return;
            }
            data = nullptr;
            vkMapMemory(device, gpu.indexMemory, 0, indexSize, 0, &data);
            std::memcpy(data, mesh.indices.data(), static_cast<std::size_t>(indexSize));
            vkUnmapMemory(device, gpu.indexMemory);
        }

        meshes_.push_back(std::move(gpu));
    }

    DOLL_LOG_INFO("vulkan", "已上传 {} 个网格到 GPU", meshes_.size());
}

Status VulkanRenderer::createGraphicsPipeline() {
    VkShaderModule vertModule = createShaderModule(device_->device(), shaderDir_, "triangle.vert.spv");
    VkShaderModule fragModule = createShaderModule(device_->device(), shaderDir_, "triangle.frag.spv");
    if (vertModule == VK_NULL_HANDLE || fragModule == VK_NULL_HANDLE) {
        if (vertModule != VK_NULL_HANDLE) vkDestroyShaderModule(device_->device(), vertModule, nullptr);
        if (fragModule != VK_NULL_HANDLE) vkDestroyShaderModule(device_->device(), fragModule, nullptr);
        return Status::fail(ErrorCode::Graphics, "加载着色器模块失败");
    }

    VkPipelineShaderStageCreateInfo vertStage{};
    vertStage.sType = VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO;
    vertStage.stage = VK_SHADER_STAGE_VERTEX_BIT;
    vertStage.module = vertModule;
    vertStage.pName = "main";

    VkPipelineShaderStageCreateInfo fragStage{};
    fragStage.sType = VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO;
    fragStage.stage = VK_SHADER_STAGE_FRAGMENT_BIT;
    fragStage.module = fragModule;
    fragStage.pName = "main";

    const VkPipelineShaderStageCreateInfo stages[] = {vertStage, fragStage};

    VkVertexInputBindingDescription binding{};
    binding.binding = 0;
    binding.stride = sizeof(asset::Vertex);
    binding.inputRate = VK_VERTEX_INPUT_RATE_VERTEX;

    VkVertexInputAttributeDescription attributes[6]{};
    attributes[0].binding = 0;
    attributes[0].location = 0;
    attributes[0].format = VK_FORMAT_R32G32B32_SFLOAT;
    attributes[0].offset = offsetof(asset::Vertex, position);
    attributes[1].binding = 0;
    attributes[1].location = 1;
    attributes[1].format = VK_FORMAT_R32G32B32_SFLOAT;
    attributes[1].offset = offsetof(asset::Vertex, normal);
    attributes[2].binding = 0;
    attributes[2].location = 2;
    attributes[2].format = VK_FORMAT_R32G32B32A32_SFLOAT;
    attributes[2].offset = offsetof(asset::Vertex, color);
    attributes[3].binding = 0;
    attributes[3].location = 3;
    attributes[3].format = VK_FORMAT_R32G32_SFLOAT;
    attributes[3].offset = offsetof(asset::Vertex, uv);
    attributes[4].binding = 0;
    attributes[4].location = 4;
    attributes[4].format = VK_FORMAT_R32G32B32A32_UINT;
    attributes[4].offset = offsetof(asset::Vertex, joints);
    attributes[5].binding = 0;
    attributes[5].location = 5;
    attributes[5].format = VK_FORMAT_R32G32B32A32_SFLOAT;
    attributes[5].offset = offsetof(asset::Vertex, weights);

    VkPipelineVertexInputStateCreateInfo vertexInput{};
    vertexInput.sType = VK_STRUCTURE_TYPE_PIPELINE_VERTEX_INPUT_STATE_CREATE_INFO;
    vertexInput.vertexBindingDescriptionCount = 1;
    vertexInput.pVertexBindingDescriptions = &binding;
    vertexInput.vertexAttributeDescriptionCount = 6;
    vertexInput.pVertexAttributeDescriptions = attributes;

    VkPipelineInputAssemblyStateCreateInfo inputAssembly{};
    inputAssembly.sType = VK_STRUCTURE_TYPE_PIPELINE_INPUT_ASSEMBLY_STATE_CREATE_INFO;
    inputAssembly.topology = VK_PRIMITIVE_TOPOLOGY_TRIANGLE_LIST;
    inputAssembly.primitiveRestartEnable = VK_FALSE;

    VkPipelineViewportStateCreateInfo viewportState{};
    viewportState.sType = VK_STRUCTURE_TYPE_PIPELINE_VIEWPORT_STATE_CREATE_INFO;
    viewportState.viewportCount = 1;
    viewportState.scissorCount = 1;

    VkPipelineRasterizationStateCreateInfo rasterizer{};
    rasterizer.sType = VK_STRUCTURE_TYPE_PIPELINE_RASTERIZATION_STATE_CREATE_INFO;
    rasterizer.depthClampEnable = VK_FALSE;
    rasterizer.rasterizerDiscardEnable = VK_FALSE;
    rasterizer.polygonMode = VK_POLYGON_MODE_FILL;
    rasterizer.lineWidth = 1.0f;
    rasterizer.cullMode = VK_CULL_MODE_NONE;
    rasterizer.frontFace = VK_FRONT_FACE_COUNTER_CLOCKWISE;
    rasterizer.depthBiasEnable = VK_FALSE;

    VkPipelineMultisampleStateCreateInfo multisampling{};
    multisampling.sType = VK_STRUCTURE_TYPE_PIPELINE_MULTISAMPLE_STATE_CREATE_INFO;
    multisampling.sampleShadingEnable = VK_FALSE;
    multisampling.rasterizationSamples = VK_SAMPLE_COUNT_1_BIT;

    VkPipelineDepthStencilStateCreateInfo depthStencil{};
    depthStencil.sType = VK_STRUCTURE_TYPE_PIPELINE_DEPTH_STENCIL_STATE_CREATE_INFO;
    depthStencil.depthTestEnable = VK_TRUE;
    depthStencil.depthWriteEnable = VK_TRUE;
    depthStencil.depthCompareOp = VK_COMPARE_OP_LESS;
    depthStencil.minDepthBounds = 0.0f;
    depthStencil.maxDepthBounds = 1.0f;

    VkPipelineColorBlendAttachmentState colorBlendAttachment{};
    colorBlendAttachment.colorWriteMask = VK_COLOR_COMPONENT_R_BIT | VK_COLOR_COMPONENT_G_BIT |
                                          VK_COLOR_COMPONENT_B_BIT | VK_COLOR_COMPONENT_A_BIT;
    colorBlendAttachment.blendEnable = VK_FALSE;

    VkPipelineColorBlendStateCreateInfo colorBlending{};
    colorBlending.sType = VK_STRUCTURE_TYPE_PIPELINE_COLOR_BLEND_STATE_CREATE_INFO;
    colorBlending.attachmentCount = 1;
    colorBlending.pAttachments = &colorBlendAttachment;

    const VkDynamicState dynamicStates[] = {VK_DYNAMIC_STATE_VIEWPORT, VK_DYNAMIC_STATE_SCISSOR};
    VkPipelineDynamicStateCreateInfo dynamicState{};
    dynamicState.sType = VK_STRUCTURE_TYPE_PIPELINE_DYNAMIC_STATE_CREATE_INFO;
    dynamicState.dynamicStateCount = 2;
    dynamicState.pDynamicStates = dynamicStates;

    // push constant：mvp(mat4) + baseColor(vec4)，与 triangle.vert 一致。
    VkPushConstantRange pushRange{};
    pushRange.stageFlags = VK_SHADER_STAGE_VERTEX_BIT;
    pushRange.offset = 0;
    pushRange.size = sizeof(glm::mat4) + sizeof(glm::vec4);

    VkPipelineLayoutCreateInfo layoutInfo{};
    layoutInfo.sType = VK_STRUCTURE_TYPE_PIPELINE_LAYOUT_CREATE_INFO;
    layoutInfo.setLayoutCount = 1;
    layoutInfo.pSetLayouts = &descriptorSetLayout_;
    layoutInfo.pushConstantRangeCount = 1;
    layoutInfo.pPushConstantRanges = &pushRange;

    VkDevice device = device_->device();
    if (vkCreatePipelineLayout(device, &layoutInfo, nullptr, &pipelineLayout_) != VK_SUCCESS) {
        vkDestroyShaderModule(device, vertModule, nullptr);
        vkDestroyShaderModule(device, fragModule, nullptr);
        return Status::fail(ErrorCode::Graphics, "vkCreatePipelineLayout 失败");
    }

    VkGraphicsPipelineCreateInfo createInfo{};
    createInfo.sType = VK_STRUCTURE_TYPE_GRAPHICS_PIPELINE_CREATE_INFO;
    createInfo.stageCount = 2;
    createInfo.pStages = stages;
    createInfo.pVertexInputState = &vertexInput;
    createInfo.pInputAssemblyState = &inputAssembly;
    createInfo.pViewportState = &viewportState;
    createInfo.pRasterizationState = &rasterizer;
    createInfo.pMultisampleState = &multisampling;
    createInfo.pDepthStencilState = &depthStencil;
    createInfo.pColorBlendState = &colorBlending;
    createInfo.pDynamicState = &dynamicState;
    createInfo.layout = pipelineLayout_;
    createInfo.renderPass = sceneRenderPass_;
    createInfo.subpass = 0;

    const VkResult result =
        vkCreateGraphicsPipelines(device, VK_NULL_HANDLE, 1, &createInfo, nullptr, &pipeline_);

    vkDestroyShaderModule(device, vertModule, nullptr);
    vkDestroyShaderModule(device, fragModule, nullptr);

    if (result != VK_SUCCESS) {
        return Status::fail(ErrorCode::Graphics,
                            std::format("vkCreateGraphicsPipelines 失败: {}", vkResultToString(result)));
    }
    DOLL_LOG_INFO("vulkan", "图形管线已创建（立方体）");
    return Status::success();
}

Status VulkanRenderer::createGridResources() {
    // 生成 XZ 平面网格线（line list）。
    std::vector<glm::vec3> gridVertices;
    constexpr float extent = 10.0f;
    constexpr int divisions = 20;
    for (int i = 0; i <= divisions; ++i) {
        const float t = -extent + (2.0f * extent) * static_cast<float>(i) / divisions;
        gridVertices.emplace_back(-extent, 0.0f, t);
        gridVertices.emplace_back(extent, 0.0f, t);
        gridVertices.emplace_back(t, 0.0f, -extent);
        gridVertices.emplace_back(t, 0.0f, extent);
    }
    gridVertexCount_ = static_cast<std::uint32_t>(gridVertices.size());

    const VkDeviceSize size = sizeof(glm::vec3) * gridVertices.size();
    if (auto status = createBuffer(device_->device(), device_->physicalDevice(), size,
                                   VK_BUFFER_USAGE_VERTEX_BUFFER_BIT,
                                   VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT,
                                   &gridVertexBuffer_, &gridVertexMemory_);
        !status) {
        return status;
    }
    void* data = nullptr;
    vkMapMemory(device_->device(), gridVertexMemory_, 0, size, 0, &data);
    std::memcpy(data, gridVertices.data(), static_cast<std::size_t>(size));
    vkUnmapMemory(device_->device(), gridVertexMemory_);

    VkShaderModule vertModule = createShaderModule(device_->device(), shaderDir_, "grid.vert.spv");
    VkShaderModule fragModule = createShaderModule(device_->device(), shaderDir_, "grid.frag.spv");
    if (vertModule == VK_NULL_HANDLE || fragModule == VK_NULL_HANDLE) {
        if (vertModule != VK_NULL_HANDLE) vkDestroyShaderModule(device_->device(), vertModule, nullptr);
        if (fragModule != VK_NULL_HANDLE) vkDestroyShaderModule(device_->device(), fragModule, nullptr);
        return Status::fail(ErrorCode::Graphics, "加载网格着色器失败");
    }

    VkPipelineShaderStageCreateInfo vertStage{};
    vertStage.sType = VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO;
    vertStage.stage = VK_SHADER_STAGE_VERTEX_BIT;
    vertStage.module = vertModule;
    vertStage.pName = "main";

    VkPipelineShaderStageCreateInfo fragStage{};
    fragStage.sType = VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO;
    fragStage.stage = VK_SHADER_STAGE_FRAGMENT_BIT;
    fragStage.module = fragModule;
    fragStage.pName = "main";

    const VkPipelineShaderStageCreateInfo stages[] = {vertStage, fragStage};

    VkVertexInputBindingDescription binding{};
    binding.binding = 0;
    binding.stride = sizeof(glm::vec3);
    binding.inputRate = VK_VERTEX_INPUT_RATE_VERTEX;

    VkVertexInputAttributeDescription attribute{};
    attribute.binding = 0;
    attribute.location = 0;
    attribute.format = VK_FORMAT_R32G32B32_SFLOAT;
    attribute.offset = 0;

    VkPipelineVertexInputStateCreateInfo vertexInput{};
    vertexInput.sType = VK_STRUCTURE_TYPE_PIPELINE_VERTEX_INPUT_STATE_CREATE_INFO;
    vertexInput.vertexBindingDescriptionCount = 1;
    vertexInput.pVertexBindingDescriptions = &binding;
    vertexInput.vertexAttributeDescriptionCount = 1;
    vertexInput.pVertexAttributeDescriptions = &attribute;

    VkPipelineInputAssemblyStateCreateInfo inputAssembly{};
    inputAssembly.sType = VK_STRUCTURE_TYPE_PIPELINE_INPUT_ASSEMBLY_STATE_CREATE_INFO;
    inputAssembly.topology = VK_PRIMITIVE_TOPOLOGY_LINE_LIST;
    inputAssembly.primitiveRestartEnable = VK_FALSE;

    VkPipelineViewportStateCreateInfo viewportState{};
    viewportState.sType = VK_STRUCTURE_TYPE_PIPELINE_VIEWPORT_STATE_CREATE_INFO;
    viewportState.viewportCount = 1;
    viewportState.scissorCount = 1;

    VkPipelineRasterizationStateCreateInfo rasterizer{};
    rasterizer.sType = VK_STRUCTURE_TYPE_PIPELINE_RASTERIZATION_STATE_CREATE_INFO;
    rasterizer.depthClampEnable = VK_FALSE;
    rasterizer.rasterizerDiscardEnable = VK_FALSE;
    // LINE_LIST 拓扑本身就是线，polygonMode 用 FILL（LINE 需 fillModeNonSolid feature）。
    rasterizer.polygonMode = VK_POLYGON_MODE_FILL;
    rasterizer.lineWidth = 1.0f;
    rasterizer.cullMode = VK_CULL_MODE_NONE;
    rasterizer.frontFace = VK_FRONT_FACE_COUNTER_CLOCKWISE;
    rasterizer.depthBiasEnable = VK_FALSE;

    VkPipelineMultisampleStateCreateInfo multisampling{};
    multisampling.sType = VK_STRUCTURE_TYPE_PIPELINE_MULTISAMPLE_STATE_CREATE_INFO;
    multisampling.rasterizationSamples = VK_SAMPLE_COUNT_1_BIT;

    VkPipelineDepthStencilStateCreateInfo depthStencil{};
    depthStencil.sType = VK_STRUCTURE_TYPE_PIPELINE_DEPTH_STENCIL_STATE_CREATE_INFO;
    depthStencil.depthTestEnable = VK_TRUE;
    depthStencil.depthWriteEnable = VK_TRUE;
    depthStencil.depthCompareOp = VK_COMPARE_OP_LESS;

    VkPipelineColorBlendAttachmentState colorBlendAttachment{};
    colorBlendAttachment.colorWriteMask = VK_COLOR_COMPONENT_R_BIT | VK_COLOR_COMPONENT_G_BIT |
                                          VK_COLOR_COMPONENT_B_BIT | VK_COLOR_COMPONENT_A_BIT;
    colorBlendAttachment.blendEnable = VK_FALSE;

    VkPipelineColorBlendStateCreateInfo colorBlending{};
    colorBlending.sType = VK_STRUCTURE_TYPE_PIPELINE_COLOR_BLEND_STATE_CREATE_INFO;
    colorBlending.attachmentCount = 1;
    colorBlending.pAttachments = &colorBlendAttachment;

    const VkDynamicState dynamicStates[] = {VK_DYNAMIC_STATE_VIEWPORT, VK_DYNAMIC_STATE_SCISSOR};
    VkPipelineDynamicStateCreateInfo dynamicState{};
    dynamicState.sType = VK_STRUCTURE_TYPE_PIPELINE_DYNAMIC_STATE_CREATE_INFO;
    dynamicState.dynamicStateCount = 2;
    dynamicState.pDynamicStates = dynamicStates;

    VkPushConstantRange pushRange{};
    pushRange.stageFlags = VK_SHADER_STAGE_VERTEX_BIT;
    pushRange.offset = 0;
    pushRange.size = sizeof(glm::mat4) + sizeof(glm::vec4); // mvp + 线颜色

    VkPipelineLayoutCreateInfo layoutInfo{};
    layoutInfo.sType = VK_STRUCTURE_TYPE_PIPELINE_LAYOUT_CREATE_INFO;
    layoutInfo.setLayoutCount = 0;
    layoutInfo.pushConstantRangeCount = 1;
    layoutInfo.pPushConstantRanges = &pushRange;

    VkDevice device = device_->device();
    if (vkCreatePipelineLayout(device, &layoutInfo, nullptr, &gridPipelineLayout_) != VK_SUCCESS) {
        vkDestroyShaderModule(device, vertModule, nullptr);
        vkDestroyShaderModule(device, fragModule, nullptr);
        return Status::fail(ErrorCode::Graphics, "vkCreatePipelineLayout（网格）失败");
    }

    VkGraphicsPipelineCreateInfo createInfo{};
    createInfo.sType = VK_STRUCTURE_TYPE_GRAPHICS_PIPELINE_CREATE_INFO;
    createInfo.stageCount = 2;
    createInfo.pStages = stages;
    createInfo.pVertexInputState = &vertexInput;
    createInfo.pInputAssemblyState = &inputAssembly;
    createInfo.pViewportState = &viewportState;
    createInfo.pRasterizationState = &rasterizer;
    createInfo.pMultisampleState = &multisampling;
    createInfo.pDepthStencilState = &depthStencil;
    createInfo.pColorBlendState = &colorBlending;
    createInfo.pDynamicState = &dynamicState;
    createInfo.layout = gridPipelineLayout_;
    createInfo.renderPass = sceneRenderPass_;
    createInfo.subpass = 0;

    const VkResult result =
        vkCreateGraphicsPipelines(device, VK_NULL_HANDLE, 1, &createInfo, nullptr, &gridPipeline_);

    vkDestroyShaderModule(device, vertModule, nullptr);
    vkDestroyShaderModule(device, fragModule, nullptr);

    if (result != VK_SUCCESS) {
        return Status::fail(ErrorCode::Graphics,
                            std::format("vkCreateGraphicsPipelines（网格）失败: {}", vkResultToString(result)));
    }
    DOLL_LOG_INFO("vulkan", "地面网格管线已创建（{} 顶点）", gridVertexCount_);
    return Status::success();
}

void VulkanRenderer::destroyGridResources() {
    VkDevice device = device_->device();
    if (boneVertexBuffer_ != VK_NULL_HANDLE) {
        vkDestroyBuffer(device, boneVertexBuffer_, nullptr);
        boneVertexBuffer_ = VK_NULL_HANDLE;
    }
    if (boneVertexMemory_ != VK_NULL_HANDLE) {
        vkFreeMemory(device, boneVertexMemory_, nullptr);
        boneVertexMemory_ = VK_NULL_HANDLE;
    }
    boneVertexCount_ = 0;
    if (gridVertexBuffer_ != VK_NULL_HANDLE) {
        vkDestroyBuffer(device, gridVertexBuffer_, nullptr);
        gridVertexBuffer_ = VK_NULL_HANDLE;
    }
    if (gridVertexMemory_ != VK_NULL_HANDLE) {
        vkFreeMemory(device, gridVertexMemory_, nullptr);
        gridVertexMemory_ = VK_NULL_HANDLE;
    }
    if (gridPipeline_ != VK_NULL_HANDLE) {
        vkDestroyPipeline(device, gridPipeline_, nullptr);
        gridPipeline_ = VK_NULL_HANDLE;
    }
    if (gridPipelineLayout_ != VK_NULL_HANDLE) {
        vkDestroyPipelineLayout(device, gridPipelineLayout_, nullptr);
        gridPipelineLayout_ = VK_NULL_HANDLE;
    }
}

void VulkanRenderer::setBoneLines(const std::vector<glm::vec3>& lines) {
    VkDevice device = device_->device();
    VkPhysicalDevice physicalDevice = device_->physicalDevice();

    const auto destroyBuffer = [&]() {
        if (boneVertexBuffer_ != VK_NULL_HANDLE) {
            vkDestroyBuffer(device, boneVertexBuffer_, nullptr);
            boneVertexBuffer_ = VK_NULL_HANDLE;
        }
        if (boneVertexMemory_ != VK_NULL_HANDLE) {
            vkFreeMemory(device, boneVertexMemory_, nullptr);
            boneVertexMemory_ = VK_NULL_HANDLE;
        }
        boneVertexCount_ = 0;
    };

    if (lines.empty()) {
        vkDeviceWaitIdle(device);
        destroyBuffer();
        return;
    }

    const VkDeviceSize size = sizeof(glm::vec3) * lines.size();

    // 顶点数变化才重建缓冲，否则复用（每帧动画更新骨骼线，不能每帧重建）。
    if (static_cast<std::uint32_t>(lines.size()) != boneVertexCount_ ||
        boneVertexBuffer_ == VK_NULL_HANDLE) {
        vkDeviceWaitIdle(device);
        destroyBuffer();
        if (auto status = createBuffer(device, physicalDevice, size, VK_BUFFER_USAGE_VERTEX_BUFFER_BIT,
                                       VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT,
                                       &boneVertexBuffer_, &boneVertexMemory_);
            !status) {
            DOLL_LOG_ERROR("vulkan", "上传骨骼线失败：{}", status.error().message);
            return;
        }
        boneVertexCount_ = static_cast<std::uint32_t>(lines.size());
    }

    void* data = nullptr;
    vkMapMemory(device, boneVertexMemory_, 0, size, 0, &data);
    std::memcpy(data, lines.data(), static_cast<std::size_t>(size));
    vkUnmapMemory(device, boneVertexMemory_);
}

void VulkanRenderer::updateMeshVertices(std::size_t meshIndex,
                                        const std::vector<asset::Vertex>& vertices) {
    if (meshIndex >= meshes_.size() || vertices.empty()) {
        return;
    }
    auto& mesh = meshes_[meshIndex];
    if (mesh.vertexBuffer == VK_NULL_HANDLE || mesh.vertexMemory == VK_NULL_HANDLE) {
        return;
    }
    const VkDeviceSize size = sizeof(asset::Vertex) * vertices.size();
    VkDevice device = device_->device();
    vkDeviceWaitIdle(device);
    void* data = nullptr;
    vkMapMemory(device, mesh.vertexMemory, 0, size, 0, &data);
    std::memcpy(data, vertices.data(), static_cast<std::size_t>(size));
    vkUnmapMemory(device, mesh.vertexMemory);
}

void VulkanRenderer::setSkinMatrices(const std::vector<glm::mat4>& matrices) {
    if (skinMemory_ == VK_NULL_HANDLE) {
        return;
    }
    constexpr std::uint32_t kMaxJoints = 256;
    std::vector<glm::mat4> data(kMaxJoints, glm::mat4(1.0f));
    const std::size_t count = std::min(matrices.size(), static_cast<std::size_t>(kMaxJoints));
    std::copy_n(matrices.begin(), static_cast<std::ptrdiff_t>(count), data.begin());

    const VkDeviceSize size = sizeof(glm::mat4) * kMaxJoints;
    void* dst = nullptr;
    vkMapMemory(device_->device(), skinMemory_, 0, size, 0, &dst);
    std::memcpy(dst, data.data(), static_cast<std::size_t>(size));
    vkUnmapMemory(device_->device(), skinMemory_);
}

Status VulkanRenderer::createTextureResources() {
    VkDevice device = device_->device();

    VkDescriptorSetLayoutBinding bindings[2]{};
    bindings[0].binding = 0;
    bindings[0].descriptorType = VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER;
    bindings[0].descriptorCount = 1;
    bindings[0].stageFlags = VK_SHADER_STAGE_FRAGMENT_BIT;
    bindings[1].binding = 1;
    bindings[1].descriptorType = VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER;
    bindings[1].descriptorCount = 1;
    bindings[1].stageFlags = VK_SHADER_STAGE_VERTEX_BIT;

    VkDescriptorSetLayoutCreateInfo layoutInfo{};
    layoutInfo.sType = VK_STRUCTURE_TYPE_DESCRIPTOR_SET_LAYOUT_CREATE_INFO;
    layoutInfo.bindingCount = 2;
    layoutInfo.pBindings = bindings;
    if (vkCreateDescriptorSetLayout(device, &layoutInfo, nullptr, &descriptorSetLayout_) != VK_SUCCESS) {
        return Status::fail(ErrorCode::Graphics, "vkCreateDescriptorSetLayout 失败");
    }

    VkDescriptorPoolSize poolSizes[2]{};
    poolSizes[0].type = VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER;
    poolSizes[0].descriptorCount = 256;
    poolSizes[1].type = VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER;
    poolSizes[1].descriptorCount = 1;
    VkDescriptorPoolCreateInfo poolInfo{};
    poolInfo.sType = VK_STRUCTURE_TYPE_DESCRIPTOR_POOL_CREATE_INFO;
    poolInfo.maxSets = 256;
    poolInfo.poolSizeCount = 2;
    poolInfo.pPoolSizes = poolSizes;
    if (vkCreateDescriptorPool(device, &poolInfo, nullptr, &descriptorPool_) != VK_SUCCESS) {
        return Status::fail(ErrorCode::Graphics, "vkCreateDescriptorPool 失败");
    }

    // 蒙皮矩阵 UBO（256 个 mat4，默认全单位矩阵）。先创建，纹理 set 的 binding 1 引用它。
    constexpr std::uint32_t kMaxJoints = 256;
    const VkDeviceSize skinSize = sizeof(glm::mat4) * kMaxJoints;
    if (auto status = createBuffer(device, device_->physicalDevice(), skinSize,
                                   VK_BUFFER_USAGE_UNIFORM_BUFFER_BIT,
                                   VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT,
                                   &skinBuffer_, &skinMemory_);
        !status) {
        return status;
    }
    {
        std::vector<glm::mat4> identity(kMaxJoints, glm::mat4(1.0f));
        void* skinData = nullptr;
        vkMapMemory(device, skinMemory_, 0, skinSize, 0, &skinData);
        std::memcpy(skinData, identity.data(), static_cast<std::size_t>(skinSize));
        vkUnmapMemory(device, skinMemory_);
    }

    // 白色占位纹理（createTexture 同时写 binding 0 采样器 + binding 1 骨骼 UBO）。
    const std::uint8_t white[4] = {255, 255, 255, 255};
    TextureGpu whiteTex = createTexture(white, 1, 1);
    if (whiteTex.descriptorSet == VK_NULL_HANDLE) {
        return Status::fail(ErrorCode::Graphics, "创建白色占位纹理失败");
    }
    whiteDescriptorSet_ = whiteTex.descriptorSet;
    textures_.push_back(std::move(whiteTex));

    DOLL_LOG_INFO("vulkan", "纹理资源已创建");
    return Status::success();
}

TextureGpu VulkanRenderer::createTexture(const std::uint8_t* rgba, std::uint32_t width,
                                         std::uint32_t height) {
    TextureGpu result;
    VkDevice device = device_->device();
    VkPhysicalDevice physicalDevice = device_->physicalDevice();

    const VkDeviceSize imageSize = static_cast<VkDeviceSize>(width) * height * 4;

    // staging buffer
    VkBuffer stagingBuffer = VK_NULL_HANDLE;
    VkDeviceMemory stagingMemory = VK_NULL_HANDLE;
    if (auto status = createBuffer(device, physicalDevice, imageSize, VK_BUFFER_USAGE_TRANSFER_SRC_BIT,
                                   VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT,
                                   &stagingBuffer, &stagingMemory);
        !status) {
        return result;
    }
    void* data = nullptr;
    vkMapMemory(device, stagingMemory, 0, imageSize, 0, &data);
    std::memcpy(data, rgba, static_cast<std::size_t>(imageSize));
    vkUnmapMemory(device, stagingMemory);

    // 目标图像
    if (auto status = createImage(device, physicalDevice, width, height, VK_FORMAT_R8G8B8A8_UNORM,
                                  VK_IMAGE_USAGE_TRANSFER_DST_BIT | VK_IMAGE_USAGE_SAMPLED_BIT,
                                  VK_IMAGE_ASPECT_COLOR_BIT,
                                  &result.image, &result.memory, &result.view);
        !status) {
        vkDestroyBuffer(device, stagingBuffer, nullptr);
        vkFreeMemory(device, stagingMemory, nullptr);
        return result;
    }

    // 临时 command pool/buffer 做 layout 转换 + 拷贝。
    VkCommandPool pool = VK_NULL_HANDLE;
    VkCommandPoolCreateInfo poolInfo{};
    poolInfo.sType = VK_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO;
    poolInfo.queueFamilyIndex = device_->graphicsQueueFamily();
    vkCreateCommandPool(device, &poolInfo, nullptr, &pool);

    VkCommandBufferAllocateInfo allocInfo{};
    allocInfo.sType = VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO;
    allocInfo.commandPool = pool;
    allocInfo.level = VK_COMMAND_BUFFER_LEVEL_PRIMARY;
    allocInfo.commandBufferCount = 1;
    VkCommandBuffer cmd = VK_NULL_HANDLE;
    vkAllocateCommandBuffers(device, &allocInfo, &cmd);

    VkCommandBufferBeginInfo beginInfo{};
    beginInfo.sType = VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO;
    beginInfo.flags = VK_COMMAND_BUFFER_USAGE_ONE_TIME_SUBMIT_BIT;
    vkBeginCommandBuffer(cmd, &beginInfo);

    VkImageMemoryBarrier barrier{};
    barrier.sType = VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER;
    barrier.oldLayout = VK_IMAGE_LAYOUT_UNDEFINED;
    barrier.newLayout = VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL;
    barrier.srcQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED;
    barrier.dstQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED;
    barrier.image = result.image;
    barrier.subresourceRange.aspectMask = VK_IMAGE_ASPECT_COLOR_BIT;
    barrier.subresourceRange.levelCount = 1;
    barrier.subresourceRange.layerCount = 1;
    barrier.srcAccessMask = 0;
    barrier.dstAccessMask = VK_ACCESS_TRANSFER_WRITE_BIT;
    vkCmdPipelineBarrier(cmd, VK_PIPELINE_STAGE_TOP_OF_PIPE_BIT, VK_PIPELINE_STAGE_TRANSFER_BIT,
                         0, 0, nullptr, 0, nullptr, 1, &barrier);

    VkBufferImageCopy region{};
    region.imageSubresource.aspectMask = VK_IMAGE_ASPECT_COLOR_BIT;
    region.imageSubresource.layerCount = 1;
    region.imageExtent = {width, height, 1};
    vkCmdCopyBufferToImage(cmd, stagingBuffer, result.image, VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL, 1, &region);

    barrier.oldLayout = VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL;
    barrier.newLayout = VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL;
    barrier.srcAccessMask = VK_ACCESS_TRANSFER_WRITE_BIT;
    barrier.dstAccessMask = VK_ACCESS_SHADER_READ_BIT;
    vkCmdPipelineBarrier(cmd, VK_PIPELINE_STAGE_TRANSFER_BIT, VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT,
                         0, 0, nullptr, 0, nullptr, 1, &barrier);

    vkEndCommandBuffer(cmd);

    VkSubmitInfo submitInfo{};
    submitInfo.sType = VK_STRUCTURE_TYPE_SUBMIT_INFO;
    submitInfo.commandBufferCount = 1;
    submitInfo.pCommandBuffers = &cmd;
    vkQueueSubmit(device_->graphicsQueue(), 1, &submitInfo, VK_NULL_HANDLE);
    vkQueueWaitIdle(device_->graphicsQueue());

    vkDestroyCommandPool(device, pool, nullptr);
    vkDestroyBuffer(device, stagingBuffer, nullptr);
    vkFreeMemory(device, stagingMemory, nullptr);

    // 采样器
    VkSamplerCreateInfo samplerInfo{};
    samplerInfo.sType = VK_STRUCTURE_TYPE_SAMPLER_CREATE_INFO;
    samplerInfo.magFilter = VK_FILTER_LINEAR;
    samplerInfo.minFilter = VK_FILTER_LINEAR;
    samplerInfo.addressModeU = VK_SAMPLER_ADDRESS_MODE_REPEAT;
    samplerInfo.addressModeV = VK_SAMPLER_ADDRESS_MODE_REPEAT;
    samplerInfo.addressModeW = VK_SAMPLER_ADDRESS_MODE_REPEAT;
    samplerInfo.maxLod = 1.0f;
    vkCreateSampler(device, &samplerInfo, nullptr, &result.sampler);

    // 描述符集
    VkDescriptorSetAllocateInfo descAlloc{};
    descAlloc.sType = VK_STRUCTURE_TYPE_DESCRIPTOR_SET_ALLOCATE_INFO;
    descAlloc.descriptorPool = descriptorPool_;
    descAlloc.descriptorSetCount = 1;
    descAlloc.pSetLayouts = &descriptorSetLayout_;
    if (vkAllocateDescriptorSets(device, &descAlloc, &result.descriptorSet) != VK_SUCCESS) {
        return result;
    }

    VkDescriptorImageInfo imageInfo{};
    imageInfo.imageLayout = VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL;
    imageInfo.imageView = result.view;
    imageInfo.sampler = result.sampler;

    // 一个 descriptor set 同时写 binding 0（采样器）+ binding 1（骨骼 UBO）。
    VkDescriptorBufferInfo skinBufferInfo{};
    skinBufferInfo.buffer = skinBuffer_;
    skinBufferInfo.offset = 0;
    skinBufferInfo.range = sizeof(glm::mat4) * 256;

    VkWriteDescriptorSet writes[2]{};
    writes[0].sType = VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET;
    writes[0].dstSet = result.descriptorSet;
    writes[0].dstBinding = 0;
    writes[0].descriptorCount = 1;
    writes[0].descriptorType = VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER;
    writes[0].pImageInfo = &imageInfo;
    writes[1].sType = VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET;
    writes[1].dstSet = result.descriptorSet;
    writes[1].dstBinding = 1;
    writes[1].descriptorCount = 1;
    writes[1].descriptorType = VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER;
    writes[1].pBufferInfo = &skinBufferInfo;
    vkUpdateDescriptorSets(device, 2, writes, 0, nullptr);

    return result;
}

void VulkanRenderer::destroyTexture(TextureGpu& texture) {
    VkDevice device = device_->device();
    if (texture.sampler != VK_NULL_HANDLE) {
        vkDestroySampler(device, texture.sampler, nullptr);
    }
    if (texture.view != VK_NULL_HANDLE) {
        vkDestroyImageView(device, texture.view, nullptr);
    }
    if (texture.image != VK_NULL_HANDLE) {
        vkDestroyImage(device, texture.image, nullptr);
    }
    if (texture.memory != VK_NULL_HANDLE) {
        vkFreeMemory(device, texture.memory, nullptr);
    }
    texture = {};
}

void VulkanRenderer::destroyTextures() {
    for (auto& texture : textures_) {
        destroyTexture(texture);
    }
    textures_.clear();
    whiteDescriptorSet_ = VK_NULL_HANDLE;
    if (skinBuffer_ != VK_NULL_HANDLE) {
        vkDestroyBuffer(device_->device(), skinBuffer_, nullptr);
        skinBuffer_ = VK_NULL_HANDLE;
    }
    if (skinMemory_ != VK_NULL_HANDLE) {
        vkFreeMemory(device_->device(), skinMemory_, nullptr);
        skinMemory_ = VK_NULL_HANDLE;
    }
    if (descriptorPool_ != VK_NULL_HANDLE) {
        vkDestroyDescriptorPool(device_->device(), descriptorPool_, nullptr);
        descriptorPool_ = VK_NULL_HANDLE;
    }
    if (descriptorSetLayout_ != VK_NULL_HANDLE) {
        vkDestroyDescriptorSetLayout(device_->device(), descriptorSetLayout_, nullptr);
        descriptorSetLayout_ = VK_NULL_HANDLE;
    }
}

Status VulkanRenderer::createCommandPool() {
    VkCommandPoolCreateInfo createInfo{};
    createInfo.sType = VK_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO;
    createInfo.flags = VK_COMMAND_POOL_CREATE_RESET_COMMAND_BUFFER_BIT;
    createInfo.queueFamilyIndex = device_->graphicsQueueFamily();

    const VkResult result = vkCreateCommandPool(device_->device(), &createInfo, nullptr, &commandPool_);
    if (result != VK_SUCCESS) {
        return Status::fail(ErrorCode::Graphics,
                            std::format("vkCreateCommandPool 失败: {}", vkResultToString(result)));
    }
    return Status::success();
}

Status VulkanRenderer::createCommandBuffers() {
    VkCommandBufferAllocateInfo allocInfo{};
    allocInfo.sType = VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO;
    allocInfo.commandPool = commandPool_;
    allocInfo.level = VK_COMMAND_BUFFER_LEVEL_PRIMARY;
    allocInfo.commandBufferCount = kMaxFramesInFlight;

    commandBuffers_.resize(kMaxFramesInFlight);
    const VkResult result = vkAllocateCommandBuffers(device_->device(), &allocInfo, commandBuffers_.data());
    if (result != VK_SUCCESS) {
        return Status::fail(ErrorCode::Graphics,
                            std::format("vkAllocateCommandBuffers 失败: {}", vkResultToString(result)));
    }
    return Status::success();
}

Status VulkanRenderer::createSyncObjects() {
    VkSemaphoreCreateInfo semaphoreInfo{};
    semaphoreInfo.sType = VK_STRUCTURE_TYPE_SEMAPHORE_CREATE_INFO;

    VkFenceCreateInfo fenceInfo{};
    fenceInfo.sType = VK_STRUCTURE_TYPE_FENCE_CREATE_INFO;
    fenceInfo.flags = VK_FENCE_CREATE_SIGNALED_BIT;

    imageAvailable_.resize(kMaxFramesInFlight);
    inFlight_.resize(kMaxFramesInFlight);
    renderFinished_.resize(device_->imageViews().size());

    VkDevice device = device_->device();
    for (std::uint32_t i = 0; i < kMaxFramesInFlight; ++i) {
        if (vkCreateSemaphore(device, &semaphoreInfo, nullptr, &imageAvailable_[i]) != VK_SUCCESS ||
            vkCreateFence(device, &fenceInfo, nullptr, &inFlight_[i]) != VK_SUCCESS) {
            return Status::fail(ErrorCode::Graphics, "创建同步对象失败");
        }
    }
    for (std::size_t i = 0; i < renderFinished_.size(); ++i) {
        if (vkCreateSemaphore(device, &semaphoreInfo, nullptr, &renderFinished_[i]) != VK_SUCCESS) {
            return Status::fail(ErrorCode::Graphics, "创建同步对象失败");
        }
    }
    return Status::success();
}

void VulkanRenderer::destroyRenderFinished() {
    for (const VkSemaphore semaphore : renderFinished_) {
        vkDestroySemaphore(device_->device(), semaphore, nullptr);
    }
    renderFinished_.clear();
}

Status VulkanRenderer::recordCommandBuffer(VkCommandBuffer_T* cmd, std::uint32_t imageIndex) {
    VkCommandBufferBeginInfo beginInfo{};
    beginInfo.sType = VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO;

    if (vkBeginCommandBuffer(cmd, &beginInfo) != VK_SUCCESS) {
        return Status::fail(ErrorCode::Graphics, "vkBeginCommandBuffer 失败");
    }

    // ---- 通道 A：3D 场景 → 离屏图像（结束后自动转 shader 可读）----
    if (sceneFramebuffer_ != VK_NULL_HANDLE) {
        VkViewport viewport{};
        viewport.width = static_cast<float>(sceneWidth_);
        viewport.height = static_cast<float>(sceneHeight_);
        viewport.minDepth = 0.0f;
        viewport.maxDepth = 1.0f;
        vkCmdSetViewport(cmd, 0, 1, &viewport);

        VkRect2D scissor{};
        scissor.extent = {sceneWidth_, sceneHeight_};
        vkCmdSetScissor(cmd, 0, 1, &scissor);

        VkClearValue clearValues[2]{};
        std::copy(std::begin(kSceneClearColor), std::end(kSceneClearColor), clearValues[0].color.float32);
        clearValues[1].depthStencil = {1.0f, 0};

        VkRenderPassBeginInfo scenePass{};
        scenePass.sType = VK_STRUCTURE_TYPE_RENDER_PASS_BEGIN_INFO;
        scenePass.renderPass = sceneRenderPass_;
        scenePass.framebuffer = sceneFramebuffer_;
        scenePass.renderArea.offset = {0, 0};
        scenePass.renderArea.extent = {sceneWidth_, sceneHeight_};
        scenePass.clearValueCount = 2;
        scenePass.pClearValues = clearValues;

        vkCmdBeginRenderPass(cmd, &scenePass, VK_SUBPASS_CONTENTS_INLINE);

        // 1. 地面网格 + 骨骼线（复用同一条线管线，push 不同颜色）。
        struct LinePushConstants {
            glm::mat4 mvp;
            glm::vec4 color;
        };
        if (gridPipeline_ != VK_NULL_HANDLE) {
            vkCmdBindPipeline(cmd, VK_PIPELINE_BIND_POINT_GRAPHICS, gridPipeline_);
            if (gridVertexCount_ > 0) {
                const VkBuffer gridBuffers[] = {gridVertexBuffer_};
                const VkDeviceSize gridOffsets[] = {0};
                vkCmdBindVertexBuffers(cmd, 0, 1, gridBuffers, gridOffsets);
                const LinePushConstants gridPc{mvp_, glm::vec4(0.35f, 0.35f, 0.38f, 1.0f)};
                vkCmdPushConstants(cmd, gridPipelineLayout_, VK_SHADER_STAGE_VERTEX_BIT, 0,
                                   sizeof(LinePushConstants), &gridPc);
                vkCmdDraw(cmd, gridVertexCount_, 1, 0, 0);
            }
            if (boneLinesVisible_ && boneVertexCount_ > 0) {
                const VkBuffer boneBuffers[] = {boneVertexBuffer_};
                const VkDeviceSize boneOffsets[] = {0};
                vkCmdBindVertexBuffers(cmd, 0, 1, boneBuffers, boneOffsets);
                const LinePushConstants bonePc{mvp_, glm::vec4(0.2f, 0.9f, 0.4f, 1.0f)};
                vkCmdPushConstants(cmd, gridPipelineLayout_, VK_SHADER_STAGE_VERTEX_BIT, 0,
                                   sizeof(LinePushConstants), &bonePc);
                vkCmdDraw(cmd, boneVertexCount_, 1, 0, 0);
            }
        }

        // 2. 角色网格（逐个绘制，各自用对应材质颜色 + 纹理）。
        vkCmdBindPipeline(cmd, VK_PIPELINE_BIND_POINT_GRAPHICS, pipeline_);
        for (const auto& mesh : meshes_) {
            if (mesh.indexCount == 0 || mesh.vertexBuffer == VK_NULL_HANDLE) {
                continue;
            }
            glm::vec4 baseColor{1.0f};
            VkDescriptorSet descSet = whiteDescriptorSet_;
            if (mesh.materialIndex >= 0 &&
                static_cast<std::size_t>(mesh.materialIndex) < materialColors_.size()) {
                baseColor = materialColors_[static_cast<std::size_t>(mesh.materialIndex)];
                const std::int32_t texIndex =
                    materialTextures_[static_cast<std::size_t>(mesh.materialIndex)];
                if (texIndex >= 0 && static_cast<std::size_t>(texIndex) < textures_.size()) {
                    descSet = textures_[static_cast<std::size_t>(texIndex)].descriptorSet;
                }
            }

            struct PushConstants {
                glm::mat4 mvp;
                glm::vec4 baseColor;
            };
            const PushConstants pc{mvp_, baseColor};

            const VkBuffer vertexBuffers[] = {mesh.vertexBuffer};
            const VkDeviceSize offsets[] = {0};
            vkCmdBindVertexBuffers(cmd, 0, 1, vertexBuffers, offsets);
            vkCmdBindIndexBuffer(cmd, mesh.indexBuffer, 0, VK_INDEX_TYPE_UINT32);
            vkCmdBindDescriptorSets(cmd, VK_PIPELINE_BIND_POINT_GRAPHICS, pipelineLayout_,
                                    0, 1, &descSet, 0, nullptr);
            vkCmdPushConstants(cmd, pipelineLayout_, VK_SHADER_STAGE_VERTEX_BIT, 0, sizeof(PushConstants), &pc);
            vkCmdDrawIndexed(cmd, mesh.indexCount, 1, 0, 0, 0);
        }

        vkCmdEndRenderPass(cmd);
    }

    // ---- 通道 B：ImGui UI → 交换链 ----
    VkClearValue mainClear{};
    std::copy(std::begin(kMainClearColor), std::end(kMainClearColor), mainClear.color.float32);

    VkRenderPassBeginInfo mainPass{};
    mainPass.sType = VK_STRUCTURE_TYPE_RENDER_PASS_BEGIN_INFO;
    mainPass.renderPass = mainRenderPass_;
    mainPass.framebuffer = mainFramebuffers_[imageIndex];
    mainPass.renderArea.offset = {0, 0};
    mainPass.renderArea.extent = {device_->imageWidth(), device_->imageHeight()};
    mainPass.clearValueCount = 1;
    mainPass.pClearValues = &mainClear;

    vkCmdBeginRenderPass(cmd, &mainPass, VK_SUBPASS_CONTENTS_INLINE);
    if (uiRenderCallback_) {
        uiRenderCallback_(cmd);
    }
    vkCmdEndRenderPass(cmd);

    if (vkEndCommandBuffer(cmd) != VK_SUCCESS) {
        return Status::fail(ErrorCode::Graphics, "vkEndCommandBuffer 失败");
    }
    return Status::success();
}

void VulkanRenderer::waitIdle() {
    if (device_ != nullptr && device_->device() != nullptr) {
        vkDeviceWaitIdle(device_->device());
    }
}

VulkanRenderer::DrawResult VulkanRenderer::drawFrame() {
    VkDevice device = device_->device();

    vkWaitForFences(device, 1, &inFlight_[currentFrame_], VK_TRUE, UINT64_MAX);

    std::uint32_t imageIndex = 0;
    const VkResult acquireResult = vkAcquireNextImageKHR(
        device, device_->swapchain(), UINT64_MAX, imageAvailable_[currentFrame_], VK_NULL_HANDLE, &imageIndex);
    if (acquireResult == VK_ERROR_OUT_OF_DATE_KHR) {
        return DrawResult::OutOfDate;
    }
    if (acquireResult != VK_SUCCESS && acquireResult != VK_SUBOPTIMAL_KHR) {
        DOLL_LOG_ERROR("vulkan", "vkAcquireNextImageKHR 失败: {}", vkResultToString(acquireResult));
        return DrawResult::OutOfDate;
    }

    vkResetFences(device, 1, &inFlight_[currentFrame_]);
    vkResetCommandBuffer(commandBuffers_[currentFrame_], 0);
    if (auto status = recordCommandBuffer(commandBuffers_[currentFrame_], imageIndex); !status) {
        DOLL_LOG_ERROR("vulkan", "录制命令失败：{}", status.error().message);
        return DrawResult::Ok;
    }

    VkSemaphore waitSemaphores[] = {imageAvailable_[currentFrame_]};
    VkPipelineStageFlags waitStages[] = {VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT};
    VkSemaphore signalSemaphores[] = {renderFinished_[imageIndex]};

    VkSubmitInfo submitInfo{};
    submitInfo.sType = VK_STRUCTURE_TYPE_SUBMIT_INFO;
    submitInfo.waitSemaphoreCount = 1;
    submitInfo.pWaitSemaphores = waitSemaphores;
    submitInfo.pWaitDstStageMask = waitStages;
    submitInfo.commandBufferCount = 1;
    submitInfo.pCommandBuffers = &commandBuffers_[currentFrame_];
    submitInfo.signalSemaphoreCount = 1;
    submitInfo.pSignalSemaphores = signalSemaphores;

    if (vkQueueSubmit(device_->graphicsQueue(), 1, &submitInfo, inFlight_[currentFrame_]) != VK_SUCCESS) {
        DOLL_LOG_ERROR("vulkan", "vkQueueSubmit 失败");
        return DrawResult::Ok;
    }

    VkSwapchainKHR swapchains[] = {device_->swapchain()};
    VkPresentInfoKHR presentInfo{};
    presentInfo.sType = VK_STRUCTURE_TYPE_PRESENT_INFO_KHR;
    presentInfo.waitSemaphoreCount = 1;
    presentInfo.pWaitSemaphores = signalSemaphores;
    presentInfo.swapchainCount = 1;
    presentInfo.pSwapchains = swapchains;
    presentInfo.pImageIndices = &imageIndex;

    const VkResult presentResult = vkQueuePresentKHR(device_->presentQueue(), &presentInfo);

    currentFrame_ = (currentFrame_ + 1) % kMaxFramesInFlight;

    if (presentResult == VK_ERROR_OUT_OF_DATE_KHR || presentResult == VK_SUBOPTIMAL_KHR) {
        return DrawResult::OutOfDate;
    }
    if (presentResult != VK_SUCCESS) {
        DOLL_LOG_ERROR("vulkan", "vkQueuePresentKHR 失败: {}", vkResultToString(presentResult));
    }
    return DrawResult::Ok;
}

void VulkanRenderer::shutdown() {
    if (device_ == nullptr || device_->device() == nullptr) {
        return;
    }
    VkDevice device = device_->device();
    vkDeviceWaitIdle(device);

    for (std::uint32_t i = 0; i < kMaxFramesInFlight; ++i) {
        if (imageAvailable_[i] != VK_NULL_HANDLE) {
            vkDestroySemaphore(device, imageAvailable_[i], nullptr);
        }
        if (inFlight_[i] != VK_NULL_HANDLE) {
            vkDestroyFence(device, inFlight_[i], nullptr);
        }
    }
    imageAvailable_.clear();
    inFlight_.clear();
    destroyRenderFinished();

    if (commandPool_ != VK_NULL_HANDLE) {
        vkDestroyCommandPool(device, commandPool_, nullptr);
        commandPool_ = VK_NULL_HANDLE;
    }
    commandBuffers_.clear();
    destroyMainFramebuffers();
    destroySceneTarget();
    destroyMeshes();
    destroyGridResources();

    if (pipeline_ != VK_NULL_HANDLE) {
        vkDestroyPipeline(device, pipeline_, nullptr);
        pipeline_ = VK_NULL_HANDLE;
    }
    if (pipelineLayout_ != VK_NULL_HANDLE) {
        vkDestroyPipelineLayout(device, pipelineLayout_, nullptr);
        pipelineLayout_ = VK_NULL_HANDLE;
    }
    destroyTextures();
    if (mainRenderPass_ != VK_NULL_HANDLE) {
        vkDestroyRenderPass(device, mainRenderPass_, nullptr);
        mainRenderPass_ = VK_NULL_HANDLE;
    }
    if (sceneRenderPass_ != VK_NULL_HANDLE) {
        vkDestroyRenderPass(device, sceneRenderPass_, nullptr);
        sceneRenderPass_ = VK_NULL_HANDLE;
    }
    device_ = nullptr;
}

} // namespace doll::renderer
