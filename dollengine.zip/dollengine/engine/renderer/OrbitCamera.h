#pragma once

#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>

namespace doll::renderer {

/// 轨道相机：围绕目标点旋转（yaw/pitch）、滚轮推拉距离。
///
/// 纯数学，不碰 GPU；MVP 由 App 每帧算好传给渲染器。
struct OrbitCamera {
    float yaw = 90.0f;  // 水平角（度），90° = 从角色正面（+Z）看
    float pitch = -20.0f; // 俯仰角（度），限制 ±89° 避免翻转
    float distance = 3.0f;
    glm::vec3 target{0.0f, 0.0f, 0.0f};
    float fov = 45.0f;

    [[nodiscard]] glm::mat4 view() const {
        const float cy = glm::cos(glm::radians(yaw));
        const float sy = glm::sin(glm::radians(yaw));
        const float cp = glm::cos(glm::radians(pitch));
        const float sp = glm::sin(glm::radians(pitch));
        const glm::vec3 eye = target + glm::vec3(distance * cy * cp, distance * sp, distance * sy * cp);
        return glm::lookAt(eye, target, glm::vec3(0.0f, 1.0f, 0.0f));
    }

    [[nodiscard]] glm::mat4 proj(float aspect) const {
        glm::mat4 p = glm::perspective(glm::radians(fov), aspect, 0.1f, 100.0f);
        // Vulkan 的 NDC Y 轴向下（OpenGL 惯例是向上），不翻转画面会上下颠倒。
        p[1][1] *= -1.0f;
        return p;
    }

    [[nodiscard]] glm::mat4 mvp(float aspect) const {
        return proj(aspect) * view();
    }

    /// 未翻转 Y 的投影矩阵：ImGuizmo 按 OpenGL 惯例计算屏幕位置，
    /// 传翻转过的 `proj()` 会让 gizmo 上下颠倒。
    [[nodiscard]] glm::mat4 projForGizmo(float aspect) const {
        return glm::perspective(glm::radians(fov), aspect, 0.1f, 100.0f);
    }

    void orbit(float deltaYaw, float deltaPitch) {
        yaw += deltaYaw;
        pitch = glm::clamp(pitch + deltaPitch, -89.0f, 89.0f);
    }

    void zoom(float delta) {
        distance = glm::clamp(distance - delta, 0.5f, 20.0f);
    }

    /// 平移目标点（相机沿自身 right/up 移动，屏幕上表现为场景跟随鼠标）。
    void pan(float deltaX, float deltaY) {
        const glm::mat4 v = view();
        const glm::vec3 right(v[0][0], v[1][0], v[2][0]);
        const glm::vec3 up(v[0][1], v[1][1], v[2][1]);
        // 平移速度随距离缩放，保证屏幕上拖动的幅度感受一致。
        const float scale = distance * 0.002f;
        target -= right * (deltaX * scale);
        target += up * (deltaY * scale);
    }
};

} // namespace doll::renderer
