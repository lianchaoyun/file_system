#include "VulkanDevice.h"

#include <vulkan/vulkan.h>

#include <algorithm>
#include <format>
#include <set>
#include <string>
#include <vector>

#include "Log.h"
#include "VkUtil.h"

namespace doll::renderer {

namespace {

struct SwapchainSupportDetails {
    VkSurfaceCapabilitiesKHR capabilities{};
    std::vector<VkSurfaceFormatKHR> formats;
    std::vector<VkPresentModeKHR> presentModes;
};

SwapchainSupportDetails querySwapchainSupport(VkPhysicalDevice device, VkSurfaceKHR surface) {
    SwapchainSupportDetails details;
    vkGetPhysicalDeviceSurfaceCapabilitiesKHR(device, surface, &details.capabilities);

    uint32_t count = 0;
    vkGetPhysicalDeviceSurfaceFormatsKHR(device, surface, &count, nullptr);
    if (count > 0) {
        details.formats.resize(count);
        vkGetPhysicalDeviceSurfaceFormatsKHR(device, surface, &count, details.formats.data());
    }

    count = 0;
    vkGetPhysicalDeviceSurfacePresentModesKHR(device, surface, &count, nullptr);
    if (count > 0) {
        details.presentModes.resize(count);
        vkGetPhysicalDeviceSurfacePresentModesKHR(device, surface, &count, details.presentModes.data());
    }
    return details;
}

bool checkDeviceExtensionSupport(VkPhysicalDevice device) {
    uint32_t count = 0;
    vkEnumerateDeviceExtensionProperties(device, nullptr, &count, nullptr);
    std::vector<VkExtensionProperties> available(count);
    vkEnumerateDeviceExtensionProperties(device, nullptr, &count, available.data());

    bool hasSwapchain = false;
    for (const auto& ext : available) {
        if (std::string(ext.extensionName) == VK_KHR_SWAPCHAIN_EXTENSION_NAME) {
            hasSwapchain = true;
            break;
        }
    }
    return hasSwapchain;
}

VkSurfaceFormatKHR chooseSurfaceFormat(const std::vector<VkSurfaceFormatKHR>& formats) {
    for (const auto& f : formats) {
        if (f.format == VK_FORMAT_B8G8R8A8_UNORM &&
            f.colorSpace == VK_COLOR_SPACE_SRGB_NONLINEAR_KHR) {
            return f;
        }
    }
    return formats.empty() ? VkSurfaceFormatKHR{VK_FORMAT_B8G8R8A8_UNORM,
                                                VK_COLOR_SPACE_SRGB_NONLINEAR_KHR}
                           : formats.front();
}

VkPresentModeKHR choosePresentMode(const std::vector<VkPresentModeKHR>& modes) {
    for (const auto& m : modes) {
        if (m == VK_PRESENT_MODE_MAILBOX_KHR) {
            return m;
        }
    }
    return VK_PRESENT_MODE_FIFO_KHR; // FIFO 一定支持
}

VkExtent2D chooseExtent(const VkSurfaceCapabilitiesKHR& caps, int width, int height) {
    if (caps.currentExtent.width != UINT32_MAX) {
        return caps.currentExtent;
    }
    VkExtent2D actual{static_cast<uint32_t>(width), static_cast<uint32_t>(height)};
    actual.width = std::clamp(actual.width, caps.minImageExtent.width, caps.maxImageExtent.width);
    actual.height = std::clamp(actual.height, caps.minImageExtent.height, caps.maxImageExtent.height);
    return actual;
}

} // namespace

VulkanDevice::~VulkanDevice() {
    shutdown();
}

Status VulkanDevice::init(VkInstance_T* instance, VkSurfaceKHR_T* surface, int width, int height) {
    if (instance == nullptr || surface == nullptr) {
        return Status::fail(ErrorCode::InvalidArgument, "VulkanDevice::init: instance/surface 为空");
    }
    instance_ = instance;
    surface_ = surface;

    if (auto status = pickPhysicalDevice(); !status) {
        return status;
    }
    if (auto status = createLogicalDevice(); !status) {
        return status;
    }
    return createSwapchain(width, height);
}

void VulkanDevice::shutdown() {
    destroySwapchain();
    if (device_ != VK_NULL_HANDLE) {
        vkDestroyDevice(device_, nullptr);
        device_ = VK_NULL_HANDLE;
    }
    physicalDevice_ = nullptr;
    graphicsQueue_ = nullptr;
    presentQueue_ = nullptr;
}

Status VulkanDevice::recreateSwapchain(int width, int height) {
    if (width <= 0 || height <= 0) {
        return Status::success(); // 最小化，等恢复
    }
    vkDeviceWaitIdle(device_);
    destroySwapchain();
    return createSwapchain(width, height);
}

VulkanDevice::QueueFamilyIndices VulkanDevice::findQueueFamilies(VkPhysicalDevice_T* device) const {
    QueueFamilyIndices indices;

    uint32_t count = 0;
    vkGetPhysicalDeviceQueueFamilyProperties(device, &count, nullptr);
    std::vector<VkQueueFamilyProperties> families(count);
    vkGetPhysicalDeviceQueueFamilyProperties(device, &count, families.data());

    for (uint32_t i = 0; i < count; ++i) {
        if (families[i].queueFlags & VK_QUEUE_GRAPHICS_BIT) {
            indices.graphics = i;
        }
        VkBool32 presentSupport = VK_FALSE;
        vkGetPhysicalDeviceSurfaceSupportKHR(device, i, surface_, &presentSupport);
        if (presentSupport) {
            indices.present = i;
        }
        if (indices.complete()) {
            break;
        }
    }
    return indices;
}

bool VulkanDevice::isDeviceSuitable(VkPhysicalDevice_T* device, const QueueFamilyIndices& indices) {
    if (!indices.complete()) {
        return false;
    }
    if (!checkDeviceExtensionSupport(device)) {
        return false;
    }
    const auto support = querySwapchainSupport(device, surface_);
    return !support.formats.empty() && !support.presentModes.empty();
}

int VulkanDevice::rateDevice(VkPhysicalDevice_T* device) {
    VkPhysicalDeviceProperties props;
    vkGetPhysicalDeviceProperties(device, &props);

    int score = 0;
    if (props.deviceType == VK_PHYSICAL_DEVICE_TYPE_DISCRETE_GPU) {
        score += 1000;
    } else if (props.deviceType == VK_PHYSICAL_DEVICE_TYPE_INTEGRATED_GPU) {
        score += 100;
    }
    DOLL_LOG_INFO("vulkan", "候选物理设备：{}（类型 {}，评分 {}）",
                  props.deviceName, static_cast<int>(props.deviceType), score);
    return score;
}

Status VulkanDevice::pickPhysicalDevice() {
    uint32_t count = 0;
    vkEnumeratePhysicalDevices(instance_, &count, nullptr);
    if (count == 0) {
        return Status::fail(ErrorCode::Graphics, "未找到任何支持 Vulkan 的物理设备");
    }
    std::vector<VkPhysicalDevice> devices(count);
    vkEnumeratePhysicalDevices(instance_, &count, devices.data());

    VkPhysicalDevice best = VK_NULL_HANDLE;
    int bestScore = -1;
    for (const auto& device : devices) {
        const auto indices = findQueueFamilies(device);
        if (!isDeviceSuitable(device, indices)) {
            continue;
        }
        const int score = rateDevice(device);
        if (score > bestScore) {
            bestScore = score;
            best = device;
        }
    }

    if (best == VK_NULL_HANDLE) {
        return Status::fail(ErrorCode::Graphics, "没有物理设备同时满足图形/呈现队列与交换链支持");
    }

    physicalDevice_ = best;
    VkPhysicalDeviceProperties props;
    vkGetPhysicalDeviceProperties(best, &props);
    DOLL_LOG_INFO("vulkan", "已选择物理设备：{}", props.deviceName);
    return Status::success();
}

Status VulkanDevice::createLogicalDevice() {
    const auto indices = findQueueFamilies(physicalDevice_);
    graphicsQueueFamily_ = indices.graphics;
    presentQueueFamily_ = indices.present;

    const std::set<uint32_t> uniqueFamilies = {indices.graphics, indices.present};
    std::vector<VkDeviceQueueCreateInfo> queueInfos;
    const float priority = 1.0f;
    for (const uint32_t family : uniqueFamilies) {
        VkDeviceQueueCreateInfo info{};
        info.sType = VK_STRUCTURE_TYPE_DEVICE_QUEUE_CREATE_INFO;
        info.queueFamilyIndex = family;
        info.queueCount = 1;
        info.pQueuePriorities = &priority;
        queueInfos.push_back(info);
    }

    const std::vector<const char*> deviceExtensions = {VK_KHR_SWAPCHAIN_EXTENSION_NAME};
    VkDeviceCreateInfo createInfo{};
    createInfo.sType = VK_STRUCTURE_TYPE_DEVICE_CREATE_INFO;
    createInfo.queueCreateInfoCount = static_cast<uint32_t>(queueInfos.size());
    createInfo.pQueueCreateInfos = queueInfos.data();
    createInfo.enabledExtensionCount = static_cast<uint32_t>(deviceExtensions.size());
    createInfo.ppEnabledExtensionNames = deviceExtensions.data();

    const VkResult result = vkCreateDevice(physicalDevice_, &createInfo, nullptr, &device_);
    if (result != VK_SUCCESS) {
        return Status::fail(ErrorCode::Graphics,
                            std::format("vkCreateDevice 失败: {}", vkResultToString(result)));
    }

    vkGetDeviceQueue(device_, graphicsQueueFamily_, 0, &graphicsQueue_);
    vkGetDeviceQueue(device_, presentQueueFamily_, 0, &presentQueue_);
    DOLL_LOG_INFO("vulkan", "逻辑设备已创建（图形族 {}，呈现族 {}）",
                  graphicsQueueFamily_, presentQueueFamily_);
    return Status::success();
}

Status VulkanDevice::createSwapchain(int width, int height) {
    const auto support = querySwapchainSupport(physicalDevice_, surface_);

    const VkSurfaceFormatKHR surfaceFormat = chooseSurfaceFormat(support.formats);
    const VkPresentModeKHR presentMode = choosePresentMode(support.presentModes);
    const VkExtent2D extent = chooseExtent(support.capabilities, width, height);

    uint32_t imageCount = support.capabilities.minImageCount + 1;
    if (support.capabilities.maxImageCount > 0 && imageCount > support.capabilities.maxImageCount) {
        imageCount = support.capabilities.maxImageCount;
    }

    VkSwapchainCreateInfoKHR createInfo{};
    createInfo.sType = VK_STRUCTURE_TYPE_SWAPCHAIN_CREATE_INFO_KHR;
    createInfo.surface = surface_;
    createInfo.minImageCount = imageCount;
    createInfo.imageFormat = surfaceFormat.format;
    createInfo.imageColorSpace = surfaceFormat.colorSpace;
    createInfo.imageExtent = extent;
    createInfo.imageArrayLayers = 1;
    createInfo.imageUsage = VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT;

    const uint32_t families[] = {graphicsQueueFamily_, presentQueueFamily_};
    if (graphicsQueueFamily_ != presentQueueFamily_) {
        createInfo.imageSharingMode = VK_SHARING_MODE_CONCURRENT;
        createInfo.queueFamilyIndexCount = 2;
        createInfo.pQueueFamilyIndices = families;
    } else {
        createInfo.imageSharingMode = VK_SHARING_MODE_EXCLUSIVE;
    }
    createInfo.preTransform = support.capabilities.currentTransform;
    createInfo.compositeAlpha = VK_COMPOSITE_ALPHA_OPAQUE_BIT_KHR;
    createInfo.presentMode = presentMode;
    createInfo.clipped = VK_TRUE;
    createInfo.oldSwapchain = VK_NULL_HANDLE;

    const VkResult result = vkCreateSwapchainKHR(device_, &createInfo, nullptr, &swapchain_);
    if (result != VK_SUCCESS) {
        return Status::fail(ErrorCode::Graphics,
                            std::format("vkCreateSwapchainKHR 失败: {}", vkResultToString(result)));
    }

    swapchainImageFormat_ = surfaceFormat.format;
    swapchainExtent_ = {extent.width, extent.height};

    uint32_t count = 0;
    vkGetSwapchainImagesKHR(device_, swapchain_, &count, nullptr);
    swapchainImages_.resize(count);
    vkGetSwapchainImagesKHR(device_, swapchain_, &count, swapchainImages_.data());

    // 为每张交换链图像建视图。
    swapchainImageViews_.reserve(count);
    for (const VkImage image : swapchainImages_) {
        VkImageViewCreateInfo viewInfo{};
        viewInfo.sType = VK_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO;
        viewInfo.image = image;
        viewInfo.viewType = VK_IMAGE_VIEW_TYPE_2D;
        viewInfo.format = surfaceFormat.format;
        viewInfo.subresourceRange.aspectMask = VK_IMAGE_ASPECT_COLOR_BIT;
        viewInfo.subresourceRange.levelCount = 1;
        viewInfo.subresourceRange.layerCount = 1;

        VkImageView view = VK_NULL_HANDLE;
        const VkResult viewResult = vkCreateImageView(device_, &viewInfo, nullptr, &view);
        if (viewResult != VK_SUCCESS) {
            destroySwapchain();
            return Status::fail(ErrorCode::Graphics,
                                std::format("vkCreateImageView 失败: {}", vkResultToString(viewResult)));
        }
        swapchainImageViews_.push_back(view);
    }

    DOLL_LOG_INFO("vulkan", "交换链已创建：{}x{}，{} 张图像，格式 {}",
                  extent.width, extent.height, count, static_cast<int>(surfaceFormat.format));
    return Status::success();
}

void VulkanDevice::destroySwapchain() {
    for (const VkImageView view : swapchainImageViews_) {
        vkDestroyImageView(device_, view, nullptr);
    }
    swapchainImageViews_.clear();
    swapchainImages_.clear();
    if (swapchain_ != VK_NULL_HANDLE) {
        vkDestroySwapchainKHR(device_, swapchain_, nullptr);
        swapchain_ = VK_NULL_HANDLE;
    }
}

VkDevice_T* VulkanDevice::device() const noexcept { return device_; }
VkPhysicalDevice_T* VulkanDevice::physicalDevice() const noexcept { return physicalDevice_; }
VkQueue_T* VulkanDevice::graphicsQueue() const noexcept { return graphicsQueue_; }
VkQueue_T* VulkanDevice::presentQueue() const noexcept { return presentQueue_; }
VkSwapchainKHR_T* VulkanDevice::swapchain() const noexcept { return swapchain_; }
std::uint32_t VulkanDevice::imageFormat() const noexcept { return swapchainImageFormat_; }

} // namespace doll::renderer
