#pragma once

#include "Result.h"

#include <glm/glm.hpp>

#include <cstdint>
#include <filesystem>
#include <functional>
#include <vector>

#include "AssetData.h"

struct VkRenderPass_T;
struct VkFramebuffer_T;
struct VkCommandPool_T;
struct VkCommandBuffer_T;
struct VkSemaphore_T;
struct VkFence_T;
struct VkPipeline_T;
struct VkPipelineLayout_T;
struct VkImage_T;
struct VkDeviceMemory_T;
struct VkImageView_T;
struct VkBuffer_T;
struct VkSampler_T;
struct VkDescriptorSetLayout_T;
struct VkDescriptorPool_T;
struct VkDescriptorSet_T;

namespace doll::renderer {

class VulkanDevice;

/// GPU 纹理资源（图像 + 显存 + 视图 + 采样器 + 描述符）。
struct TextureGpu {
    VkImage_T* image = nullptr;
    VkDeviceMemory_T* memory = nullptr;
    VkImageView_T* view = nullptr;
    VkSampler_T* sampler = nullptr;
    VkDescriptorSet_T* descriptorSet = nullptr;
};

/// 编辑器渲染器，分两条渲染通道：
///
/// - **场景通道**（离屏）：把 3D 场景（立方体/角色）画进一张与「视口面板」
///   同尺寸的离屏颜色图像，渲染通道结束自动转到 shader 可读布局。
///   ImGui 通过 `ImGui::Image` 把它显示在视口面板里。
/// - **主通道**（交换链）：只画 ImGui UI（菜单/面板），面板内嵌场景纹理。
///
/// 深度缓冲属于场景通道（跟随视口尺寸）；主通道无深度。
class VulkanRenderer {
public:
    /// 一帧的提交结果。OutOfDate 表示交换链与窗口不匹配，需要重建。
    enum class DrawResult { Ok, OutOfDate };

    /// 同时在飞的最大帧数：CPU 可比 GPU 最多提前 2 帧。
    static constexpr std::uint32_t kMaxFramesInFlight = 2;

    VulkanRenderer() = default;
    ~VulkanRenderer();

    VulkanRenderer(const VulkanRenderer&) = delete;
    VulkanRenderer& operator=(const VulkanRenderer&) = delete;

    /// `shaderDir` 是 .spv 着色器所在目录；`sceneWidth/Height` 是离屏目标初始尺寸。
    Status init(VulkanDevice* device, const std::filesystem::path& shaderDir,
                int sceneWidth, int sceneHeight);
    void shutdown();

    /// 交换链重建后调用：重建主通道帧缓冲（UI）。
    Status onSwapchainRecreated();

    /// 视口面板尺寸变化后调用：重建离屏场景目标（颜色/深度/帧缓冲）。
    /// 宽或高为 0 时跳过（面板折叠），旧目标保留。
    Status resizeSceneTarget(int width, int height);

    [[nodiscard]] VkImageView_T* sceneColorView() const noexcept { return sceneColorView_; }
    [[nodiscard]] int sceneWidth() const noexcept { return static_cast<int>(sceneWidth_); }
    [[nodiscard]] int sceneHeight() const noexcept { return static_cast<int>(sceneHeight_); }

    /// 录制并提交一帧（场景 → 离屏；UI → 交换链），然后 present。
    DrawResult drawFrame();

    [[nodiscard]] VkRenderPass_T* mainRenderPass() const noexcept { return mainRenderPass_; }

    /// 设置本帧的 MVP 矩阵（push constant），在 drawFrame 前调用。
    void setMvp(const glm::mat4& mvp) { mvp_ = mvp; }

    /// 上传一组网格、材质与纹理到 GPU，替换当前场景内容。
    /// 传入空网格表示清空场景。每个网格按各自的材质颜色与纹理着色。
    void setMeshes(const std::vector<asset::MeshData>& meshes,
                   const std::vector<asset::MaterialData>& materials,
                   const std::vector<asset::TextureImage>& textures);

    /// 上传骨骼线（每 2 个顶点一条线段）用于骨架可视化；传空清空。
    void setBoneLines(const std::vector<glm::vec3>& lines);

    /// 骨骼线是否显示（M3 骨架可视化开关，关掉后不绘制但保留数据）。
    void setBoneLinesVisible(bool visible) { boneLinesVisible_ = visible; }

    /// 上传蒙皮矩阵（jointWorld * inverseBindMatrix）；传空回退到单位矩阵。
    void setSkinMatrices(const std::vector<glm::mat4>& matrices);

    /// 更新某个网格的顶点数据（morph 形变用）。顶点数必须与上传时一致。
    void updateMeshVertices(std::size_t meshIndex, const std::vector<asset::Vertex>& vertices);

    /// 等待设备空闲（所有在飞命令执行完）。销毁 UI 的 GPU 资源前必须调用。
    void waitIdle();

    /// 设置「主通道渲染过程中」的 UI 绘制回调（用于 ImGui）。
    /// renderer 不依赖 ImGui，由 App 把 ImGui 的 draw data 画进命令缓冲。
    using UiRenderCallback = std::function<void(VkCommandBuffer_T*)>;
    void setUiRenderCallback(UiRenderCallback callback) { uiRenderCallback_ = std::move(callback); }

private:
    Status createSceneRenderPass();
    Status createSceneTarget(int width, int height);
    void destroySceneTarget();
    Status createMainRenderPass();
    void destroyMainFramebuffers();
    Status createMainFramebuffers();
    void destroyMeshes();
    Status createGraphicsPipeline();
    Status createGridResources();
    void destroyGridResources();
    Status createTextureResources();
    void destroyTextures();
    TextureGpu createTexture(const std::uint8_t* rgba, std::uint32_t width, std::uint32_t height);
    void destroyTexture(TextureGpu& texture);
    Status createCommandPool();
    Status createCommandBuffers();
    Status createSyncObjects();
    void destroyRenderFinished();
    Status recordCommandBuffer(VkCommandBuffer_T* cmd, std::uint32_t imageIndex);

    VulkanDevice* device_ = nullptr;
    std::filesystem::path shaderDir_;

    // 场景离屏目标
    VkRenderPass_T* sceneRenderPass_ = nullptr;
    VkFramebuffer_T* sceneFramebuffer_ = nullptr;
    VkImage_T* sceneColorImage_ = nullptr;
    VkDeviceMemory_T* sceneColorMemory_ = nullptr;
    VkImageView_T* sceneColorView_ = nullptr;
    VkImage_T* sceneDepthImage_ = nullptr;
    VkDeviceMemory_T* sceneDepthMemory_ = nullptr;
    VkImageView_T* sceneDepthView_ = nullptr;
    std::uint32_t sceneWidth_ = 0;
    std::uint32_t sceneHeight_ = 0;
    std::uint32_t sceneColorFormat_ = 0;
    std::uint32_t depthFormat_ = 0;

    // 主通道（交换链，UI）
    VkRenderPass_T* mainRenderPass_ = nullptr;
    std::vector<VkFramebuffer_T*> mainFramebuffers_;

    // 场景资源
    VkPipeline_T* pipeline_ = nullptr;
    VkPipelineLayout_T* pipelineLayout_ = nullptr;
    glm::mat4 mvp_{1.0f};

    // 地面网格（Blender/DAZ 风格视口背景）与骨骼线（复用同一条线管线）
    VkPipeline_T* gridPipeline_ = nullptr;
    VkPipelineLayout_T* gridPipelineLayout_ = nullptr;
    VkBuffer_T* gridVertexBuffer_ = nullptr;
    VkDeviceMemory_T* gridVertexMemory_ = nullptr;
    std::uint32_t gridVertexCount_ = 0;
    VkBuffer_T* boneVertexBuffer_ = nullptr;
    VkDeviceMemory_T* boneVertexMemory_ = nullptr;
    std::uint32_t boneVertexCount_ = 0;
    bool boneLinesVisible_ = true;

    // 纹理（材质 baseColor 采样）
    std::vector<TextureGpu> textures_;
    VkDescriptorSetLayout_T* descriptorSetLayout_ = nullptr;
    VkDescriptorPool_T* descriptorPool_ = nullptr;
    /// 无纹理材质绑定的白色占位纹理（1x1 白，等价于只用材质色）。
    VkDescriptorSet_T* whiteDescriptorSet_ = nullptr;
    /// 蒙皮矩阵 UBO（顶点着色器 binding 1，被每个纹理 set 的 binding 1 引用）。
    VkBuffer_T* skinBuffer_ = nullptr;
    VkDeviceMemory_T* skinMemory_ = nullptr;

    /// 一份上传到 GPU 的网格（顶点/索引缓冲 + 材质索引）。
    struct GpuMesh {
        VkBuffer_T* vertexBuffer = nullptr;
        VkDeviceMemory_T* vertexMemory = nullptr;
        VkBuffer_T* indexBuffer = nullptr;
        VkDeviceMemory_T* indexMemory = nullptr;
        std::uint32_t indexCount = 0;
        std::int32_t materialIndex = -1;
    };
    std::vector<GpuMesh> meshes_;
    /// 每个材质的 baseColorFactor（push constant 用）。
    std::vector<glm::vec4> materialColors_;
    /// 每个材质的 baseColor 纹理在 textures_ 里的索引（-1 = 白纹理占位）。
    std::vector<std::int32_t> materialTextures_;

    VkCommandPool_T* commandPool_ = nullptr;
    std::vector<VkCommandBuffer_T*> commandBuffers_;
    /// 按帧槽位索引（CPU 最多提前 kMaxFramesInFlight 帧）。
    std::vector<VkSemaphore_T*> imageAvailable_;
    /// 按交换链图像索引：present 可能长期持有该信号量，按图像索引分配避免复用冲突。
    std::vector<VkSemaphore_T*> renderFinished_;
    std::vector<VkFence_T*> inFlight_;
    std::uint32_t currentFrame_ = 0;
    UiRenderCallback uiRenderCallback_;
};

} // namespace doll::renderer
