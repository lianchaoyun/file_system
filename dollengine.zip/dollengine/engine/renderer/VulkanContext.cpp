#include "VulkanContext.h"

#include <vulkan/vulkan.h>

#include <SDL3/SDL.h>
#include <SDL3/SDL_vulkan.h>

#include <cstring>
#include <format>
#include <string>
#include <vector>

#include "Log.h"
#include "VkUtil.h"

namespace doll::renderer {

namespace {

/// 校验层调试回调：把消息按严重级别写入日志。
/// 返回 VK_FALSE，让程序继续执行（不触发驱动内断点）。
VKAPI_ATTR VkBool32 VKAPI_CALL debugCallback(
    VkDebugUtilsMessageSeverityFlagBitsEXT severity,
    VkDebugUtilsMessageTypeFlagsEXT /*type*/,
    const VkDebugUtilsMessengerCallbackDataEXT* data,
    void* /*userData*/) {
    const char* message = (data != nullptr && data->pMessage != nullptr) ? data->pMessage : "";
    if (severity & VK_DEBUG_UTILS_MESSAGE_SEVERITY_ERROR_BIT_EXT) {
        DOLL_LOG_ERROR("vulkan", "校验层：{}", message);
    } else if (severity & VK_DEBUG_UTILS_MESSAGE_SEVERITY_WARNING_BIT_EXT) {
        DOLL_LOG_WARN("vulkan", "校验层：{}", message);
    } else {
        DOLL_LOG_DEBUG("vulkan", "校验层：{}", message);
    }
    return VK_FALSE;
}

} // namespace

VulkanContext::~VulkanContext() {
    shutdown();
}

Status VulkanContext::init(SDL_Window* window, bool enableValidation) {
    if (window == nullptr) {
        return Status::fail(ErrorCode::InvalidArgument, "VulkanContext::init: window 为空");
    }

    if (auto status = createInstance(enableValidation); !status) {
        return status;
    }
    if (validationEnabled_) {
        if (auto status = createDebugMessenger(); !status) {
            return status;
        }
    }
    return createSurface(window);
}

Status VulkanContext::createInstance(bool enableValidation) {
    // 1) SDL 要求的实例扩展（VK_KHR_surface + 平台 surface，如 win32_surface）。
    Uint32 sdlExtCount = 0;
    const char* const* sdlExtensions = SDL_Vulkan_GetInstanceExtensions(&sdlExtCount);
    if (sdlExtensions == nullptr) {
        return Status::fail(ErrorCode::Graphics,
                            std::string("SDL_Vulkan_GetInstanceExtensions 失败: ") + SDL_GetError());
    }
    std::vector<const char*> extensions(sdlExtensions, sdlExtensions + sdlExtCount);

    // 2) 校验层：可用才启用，并追加 VK_EXT_debug_utils 扩展。
    std::vector<const char*> layers;
    if (enableValidation) {
        Uint32 layerCount = 0;
        vkEnumerateInstanceLayerProperties(&layerCount, nullptr);
        std::vector<VkLayerProperties> available(layerCount);
        vkEnumerateInstanceLayerProperties(&layerCount, available.data());

        bool found = false;
        for (const auto& layer : available) {
            if (std::strcmp(layer.layerName, "VK_LAYER_KHRONOS_validation") == 0) {
                found = true;
                break;
            }
        }
        if (found) {
            layers.push_back("VK_LAYER_KHRONOS_validation");
            extensions.push_back(VK_EXT_DEBUG_UTILS_EXTENSION_NAME);
        } else {
            DOLL_LOG_WARN("vulkan", "未找到校验层 VK_LAYER_KHRONOS_validation，跳过校验（不影响运行）");
        }
        validationEnabled_ = found;
    }

    VkApplicationInfo appInfo{};
    appInfo.sType = VK_STRUCTURE_TYPE_APPLICATION_INFO;
    appInfo.pApplicationName = "dollengine";
    appInfo.applicationVersion = VK_MAKE_VERSION(1, 0, 0);
    appInfo.pEngineName = "Doll Engine";
    appInfo.engineVersion = VK_MAKE_VERSION(1, 0, 0);
    appInfo.apiVersion = VK_API_VERSION_1_3;

    VkInstanceCreateInfo createInfo{};
    createInfo.sType = VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO;
    createInfo.pApplicationInfo = &appInfo;
    createInfo.enabledExtensionCount = static_cast<uint32_t>(extensions.size());
    createInfo.ppEnabledExtensionNames = extensions.data();
    createInfo.enabledLayerCount = static_cast<uint32_t>(layers.size());
    createInfo.ppEnabledLayerNames = layers.data();

    const VkResult result = vkCreateInstance(&createInfo, nullptr, &instance_);
    if (result != VK_SUCCESS) {
        return Status::fail(ErrorCode::Graphics,
                            std::format("vkCreateInstance 失败: {}", vkResultToString(result)));
    }

    DOLL_LOG_INFO("vulkan", "Vulkan 实例已创建（{} 个实例扩展，{} 个校验层）",
                  extensions.size(), layers.size());
    return Status::success();
}

Status VulkanContext::createDebugMessenger() {
    const auto createFn = reinterpret_cast<PFN_vkCreateDebugUtilsMessengerEXT>(
        vkGetInstanceProcAddr(instance_, "vkCreateDebugUtilsMessengerEXT"));
    if (createFn == nullptr) {
        return Status::fail(ErrorCode::Graphics,
                            "vkGetInstanceProcAddr(vkCreateDebugUtilsMessengerEXT) 返回空");
    }

    VkDebugUtilsMessengerCreateInfoEXT createInfo{};
    createInfo.sType = VK_STRUCTURE_TYPE_DEBUG_UTILS_MESSENGER_CREATE_INFO_EXT;
    createInfo.messageSeverity = VK_DEBUG_UTILS_MESSAGE_SEVERITY_WARNING_BIT_EXT |
                                 VK_DEBUG_UTILS_MESSAGE_SEVERITY_ERROR_BIT_EXT;
    createInfo.messageType = VK_DEBUG_UTILS_MESSAGE_TYPE_GENERAL_BIT_EXT |
                             VK_DEBUG_UTILS_MESSAGE_TYPE_VALIDATION_BIT_EXT |
                             VK_DEBUG_UTILS_MESSAGE_TYPE_PERFORMANCE_BIT_EXT;
    createInfo.pfnUserCallback = debugCallback;

    const VkResult result = createFn(instance_, &createInfo, nullptr, &debugMessenger_);
    if (result != VK_SUCCESS) {
        return Status::fail(ErrorCode::Graphics,
                            std::format("vkCreateDebugUtilsMessengerEXT 失败: {}",
                                        vkResultToString(result)));
    }

    DOLL_LOG_INFO("vulkan", "校验层调试回调已注册");
    return Status::success();
}

Status VulkanContext::createSurface(SDL_Window* window) {
    VkSurfaceKHR surface = VK_NULL_HANDLE;
    if (!SDL_Vulkan_CreateSurface(window, instance_, nullptr, &surface)) {
        return Status::fail(ErrorCode::Graphics,
                            std::string("SDL_Vulkan_CreateSurface 失败: ") + SDL_GetError());
    }
    surface_ = surface;
    DOLL_LOG_INFO("vulkan", "Vulkan surface 已创建");
    return Status::success();
}

void VulkanContext::shutdown() {
    // 销毁顺序与创建相反：surface → debug messenger → instance。
    if (surface_ != VK_NULL_HANDLE) {
        vkDestroySurfaceKHR(instance_, surface_, nullptr);
        surface_ = VK_NULL_HANDLE;
    }
    if (debugMessenger_ != VK_NULL_HANDLE) {
        const auto destroyFn = reinterpret_cast<PFN_vkDestroyDebugUtilsMessengerEXT>(
            vkGetInstanceProcAddr(instance_, "vkDestroyDebugUtilsMessengerEXT"));
        if (destroyFn != nullptr) {
            destroyFn(instance_, debugMessenger_, nullptr);
        }
        debugMessenger_ = VK_NULL_HANDLE;
    }
    if (instance_ != VK_NULL_HANDLE) {
        vkDestroyInstance(instance_, nullptr);
        instance_ = VK_NULL_HANDLE;
    }
}

} // namespace doll::renderer
