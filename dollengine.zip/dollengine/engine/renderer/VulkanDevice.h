#pragma once

#include "Result.h"

#include <cstdint>
#include <vector>

struct VkInstance_T;
struct VkSurfaceKHR_T;
struct VkPhysicalDevice_T;
struct VkDevice_T;
struct VkQueue_T;
struct VkSwapchainKHR_T;
struct VkImage_T;
struct VkImageView_T;

namespace doll::renderer {

/// 物理设备 + 逻辑设备 + 队列 + 交换链。
///
/// 与 VulkanContext 分工：Context 管 instance/surface，这里管 device 与
/// swapchain。所有资源都有明确所有权，shutdown 按创建逆序销毁。
///
/// swapchain 依赖 surface 的像素尺寸；窗口 resize 时由 App 调用
/// `recreateSwapchain` 重建（M1 第 3 步加入渲染循环后，重建前需等待
/// 帧同步完成）。
class VulkanDevice {
public:
    VulkanDevice() = default;
    ~VulkanDevice();

    VulkanDevice(const VulkanDevice&) = delete;
    VulkanDevice& operator=(const VulkanDevice&) = delete;

    /// 选物理设备 → 建逻辑设备与队列 → 建交换链与图像视图。
    Status init(VkInstance_T* instance, VkSurfaceKHR_T* surface, int width, int height);
    void shutdown();

    /// 窗口尺寸变化时重建交换链。宽或高为 0（最小化）时跳过，等恢复。
    Status recreateSwapchain(int width, int height);

    [[nodiscard]] VkDevice_T* device() const noexcept;
    [[nodiscard]] VkPhysicalDevice_T* physicalDevice() const noexcept;
    [[nodiscard]] VkQueue_T* graphicsQueue() const noexcept;
    [[nodiscard]] VkQueue_T* presentQueue() const noexcept;
    [[nodiscard]] std::uint32_t graphicsQueueFamily() const noexcept { return graphicsQueueFamily_; }
    [[nodiscard]] std::uint32_t presentQueueFamily() const noexcept { return presentQueueFamily_; }
    [[nodiscard]] VkSwapchainKHR_T* swapchain() const noexcept;
    [[nodiscard]] const std::vector<VkImageView_T*>& imageViews() const noexcept {
        return swapchainImageViews_;
    }
    [[nodiscard]] std::uint32_t imageFormat() const noexcept;
    [[nodiscard]] std::uint32_t imageWidth() const noexcept { return swapchainExtent_.width; }
    [[nodiscard]] std::uint32_t imageHeight() const noexcept { return swapchainExtent_.height; }

private:
    struct QueueFamilyIndices {
        std::uint32_t graphics = UINT32_MAX;
        std::uint32_t present = UINT32_MAX;
        [[nodiscard]] bool complete() const noexcept {
            return graphics != UINT32_MAX && present != UINT32_MAX;
        }
    };

    QueueFamilyIndices findQueueFamilies(VkPhysicalDevice_T* device) const;
    bool isDeviceSuitable(VkPhysicalDevice_T* device, const QueueFamilyIndices& indices);
    int rateDevice(VkPhysicalDevice_T* device);
    Status pickPhysicalDevice();
    Status createLogicalDevice();

    Status createSwapchain(int width, int height);
    void destroySwapchain();

    VkInstance_T* instance_ = nullptr;
    VkSurfaceKHR_T* surface_ = nullptr;
    VkPhysicalDevice_T* physicalDevice_ = nullptr;
    VkDevice_T* device_ = nullptr;
    VkQueue_T* graphicsQueue_ = nullptr;
    VkQueue_T* presentQueue_ = nullptr;
    std::uint32_t graphicsQueueFamily_ = 0;
    std::uint32_t presentQueueFamily_ = 0;
    VkSwapchainKHR_T* swapchain_ = nullptr;
    std::vector<VkImage_T*> swapchainImages_;
    std::vector<VkImageView_T*> swapchainImageViews_;
    std::uint32_t swapchainImageFormat_ = 0;
    struct Extent {
        std::uint32_t width = 0;
        std::uint32_t height = 0;
    } swapchainExtent_;
};

} // namespace doll::renderer
