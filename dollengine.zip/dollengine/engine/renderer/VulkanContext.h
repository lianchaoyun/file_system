#pragma once

#include "Result.h"

struct SDL_Window;
struct VkInstance_T;
struct VkSurfaceKHR_T;
struct VkDebugUtilsMessengerEXT_T;

namespace doll::renderer {

/// Vulkan 实例 / 校验层 / 调试回调 / 窗口 surface 的建立与按序销毁。
///
/// 只负责「上下文级」资源：instance、debug messenger、surface。
/// 设备 / 交换链 / 渲染通道等在后续步骤（M1 第 2、3 步）单独封装，
/// 保持每个对象有明确的所有权和销毁顺序。
///
/// 不依赖 ImGui，也不依赖 SDL_Renderer；SDL 只用于拿到窗口所需的
/// 实例扩展（`SDL_Vulkan_GetInstanceExtensions`）和创建 surface。
class VulkanContext {
public:
    VulkanContext() = default;
    ~VulkanContext();

    VulkanContext(const VulkanContext&) = delete;
    VulkanContext& operator=(const VulkanContext&) = delete;

    /// 创建实例 →（可选）注册校验层调试回调 → 创建窗口 surface。
    /// 校验层不可用时降级为警告而不是失败：目标机器可能没装 SDK 校验层。
    Status init(SDL_Window* window, bool enableValidation = true);
    void shutdown();

    [[nodiscard]] VkInstance_T* instance() const noexcept { return instance_; }
    [[nodiscard]] VkSurfaceKHR_T* surface() const noexcept { return surface_; }
    [[nodiscard]] bool validationEnabled() const noexcept { return validationEnabled_; }

private:
    Status createInstance(bool enableValidation);
    Status createDebugMessenger();
    Status createSurface(SDL_Window* window);

    VkInstance_T* instance_ = nullptr;
    VkSurfaceKHR_T* surface_ = nullptr;
    VkDebugUtilsMessengerEXT_T* debugMessenger_ = nullptr;
    bool validationEnabled_ = false;
};

} // namespace doll::renderer
