#include "Log.h"

#include <chrono>
#include <cstdio>
#include <ctime>
#include <mutex>
#include <thread>

#ifdef _WIN32
#define NOMINMAX
#include <windows.h>
#endif

namespace doll::log {
namespace {

std::mutex g_mutex;
std::FILE* g_file = nullptr;
Level g_minLevel = Level::Trace;

const char* levelName(Level level) {
    switch (level) {
        case Level::Trace: return "TRACE";
        case Level::Debug: return "DEBUG";
        case Level::Info:  return "INFO ";
        case Level::Warn:  return "WARN ";
        case Level::Error: return "ERROR";
    }
    return "?????";
}

} // namespace

void init(const std::filesystem::path& logFile) {
    std::lock_guard lock(g_mutex);
#ifdef _WIN32
    // 源码与日志都是 UTF-8，控制台默认本地代码页（GBK）会把中文显示成乱码。
    SetConsoleOutputCP(CP_UTF8);
#endif
    if (g_file != nullptr) {
        std::fclose(g_file);
        g_file = nullptr;
    }
    std::error_code ec;
    if (!logFile.parent_path().empty()) {
        std::filesystem::create_directories(logFile.parent_path(), ec);
    }
#ifdef _WIN32
    fopen_s(&g_file, logFile.string().c_str(), "w");
#else
    g_file = std::fopen(logFile.string().c_str(), "w");
#endif
}

void shutdown() {
    std::lock_guard lock(g_mutex);
    if (g_file != nullptr) {
        std::fclose(g_file);
        g_file = nullptr;
    }
}

void setMinLevel(Level minLevel) {
    std::lock_guard lock(g_mutex);
    g_minLevel = minLevel;
}

bool shouldLog(Level level) noexcept {
    std::lock_guard lock(g_mutex);
    return level >= g_minLevel;
}

void write(Level level, std::string_view tag, std::string_view message) {
    // 时间戳与线程 id 在锁外计算，缩小临界区。
    const auto now = std::chrono::system_clock::now();
    const auto time = std::chrono::system_clock::to_time_t(now);
    const auto ms = std::chrono::duration_cast<std::chrono::milliseconds>(
                        now.time_since_epoch()) % 1000;

    std::tm tm{};
#ifdef _WIN32
    localtime_s(&tm, &time);
#else
    localtime_r(&time, &tm);
#endif

    char stamp[16];
    std::strftime(stamp, sizeof(stamp), "%H:%M:%S", &tm);

    const auto tid = static_cast<unsigned>(std::hash<std::thread::id>{}(std::this_thread::get_id()) & 0xFFFFu);

    char line[2048];
    const int n = std::snprintf(
        line, sizeof(line), "[%s.%03lld] [%s] [%.*s] [t%04X] %.*s\n", stamp,
        static_cast<long long>(ms.count()), levelName(level),
        static_cast<int>(tag.size()), tag.data(), tid,
        static_cast<int>(message.size()), message.data());

    std::lock_guard lock(g_mutex);
    if (n > 0) {
        const auto count = static_cast<size_t>(n);
        std::fwrite(line, 1, count, stdout);
        if (g_file != nullptr) {
            std::fwrite(line, 1, count, g_file);
            std::fflush(g_file);
        }
    }
}

} // namespace doll::log
