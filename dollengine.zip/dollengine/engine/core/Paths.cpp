#include "Paths.h"

#include <chrono>
#include <ctime>
#include <string>

#ifdef _WIN32
#include <windows.h>
#else
#include <unistd.h>
#endif

namespace doll::paths {
namespace {

std::filesystem::path computeExecutableDir() {
#ifdef _WIN32
    wchar_t buffer[MAX_PATH];
    const DWORD len = GetModuleFileNameW(nullptr, buffer, MAX_PATH);
    if (len == 0 || len >= MAX_PATH) {
        return std::filesystem::current_path();
    }
    return std::filesystem::path(std::wstring(buffer, len)).parent_path();
#else
    char buffer[4096];
    const ssize_t len = readlink("/proc/self/exe", buffer, sizeof(buffer) - 1);
    if (len <= 0) {
        return std::filesystem::current_path();
    }
    buffer[len] = '\0';
    return std::filesystem::path(buffer).parent_path();
#endif
}

} // namespace

std::filesystem::path executableDir() {
    // 启动后目录不会变，缓存一次。
    static const std::filesystem::path dir = computeExecutableDir();
    return dir;
}

std::filesystem::path assetRoot() {
    return executableDir() / "content";
}

std::filesystem::path logDir() {
    return executableDir() / "logs";
}

std::filesystem::path logFile() {
    const auto now = std::chrono::system_clock::now();
    const auto time = std::chrono::system_clock::to_time_t(now);

    std::tm tm{};
#ifdef _WIN32
    localtime_s(&tm, &time);
#else
    localtime_r(&time, &tm);
#endif

    char stamp[32];
    std::strftime(stamp, sizeof(stamp), "%Y%m%d-%H%M%S", &tm);
    return logDir() / (std::string("app-") + stamp + ".log");
}

} // namespace doll::paths
