#pragma once

#include <filesystem>

namespace doll::paths {

/// 可执行文件所在目录（与当前工作目录无关，避免从 IDE 启动时找不到资源）。
std::filesystem::path executableDir();

/// 资源根目录（UE5 风格 Content 目录）：`<exeDir>/content`。
std::filesystem::path assetRoot();

/// 日志目录：`<exeDir>/logs`。
std::filesystem::path logDir();

/// 本次运行的日志文件：`<exeDir>/logs/app-YYYYMMDD-HHMMSS.log`。
std::filesystem::path logFile();

} // namespace doll::paths
