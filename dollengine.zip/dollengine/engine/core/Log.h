#pragma once

#include <filesystem>
#include <format>
#include <string>
#include <string_view>

namespace doll::log {

/// 日志级别，数值越大越严重。
enum class Level { Trace = 0, Debug, Info, Warn, Error };

/// 初始化日志系统：控制台 + 文件双写，`logFile` 的父目录会自动创建。
/// 重复调用会先关闭旧文件句柄。
void init(const std::filesystem::path& logFile);

/// 关闭文件句柄。进程退出前调用，避免日志缓冲丢失。
void shutdown();

void setMinLevel(Level minLevel);

/// 当前级别是否会被输出（用于避免昂贵的格式化开销）。
bool shouldLog(Level level) noexcept;

void write(Level level, std::string_view tag, std::string_view message);

/// 格式化后写入。低于阈值时直接返回，不做格式化。
template <typename... Args>
void log(Level level, std::string_view tag, std::format_string<Args...> fmt, Args&&... args) {
    if (!shouldLog(level)) {
        return;
    }
    write(level, tag, std::format(fmt, std::forward<Args>(args)...));
}

} // namespace doll::log

#define DOLL_LOG_TRACE(tag, ...) ::doll::log::log(::doll::log::Level::Trace, tag, __VA_ARGS__)
#define DOLL_LOG_DEBUG(tag, ...) ::doll::log::log(::doll::log::Level::Debug, tag, __VA_ARGS__)
#define DOLL_LOG_INFO(tag, ...) ::doll::log::log(::doll::log::Level::Info, tag, __VA_ARGS__)
#define DOLL_LOG_WARN(tag, ...) ::doll::log::log(::doll::log::Level::Warn, tag, __VA_ARGS__)
#define DOLL_LOG_ERROR(tag, ...) ::doll::log::log(::doll::log::Level::Error, tag, __VA_ARGS__)
