#pragma once

#include <string>
#include <utility>
#include <variant>

#include "DollAssert.h"

namespace doll {

/// 错误分类。后续 GLB 导入失败、Vulkan 初始化失败都归到这些类别，界面上可以按类别给提示。
enum class ErrorCode { Ok, InvalidArgument, Io, Parse, Unsupported, Graphics, Unknown };

struct Error {
    ErrorCode code = ErrorCode::Unknown;
    std::string message;
};

/// 轻量 Result<T>：不用异常做正常流程控制，失败信息随值一起返回。
template <typename T>
class Result {
public:
    static Result success(T value) { return Result(std::move(value)); }
    static Result fail(ErrorCode code, std::string message) {
        return Result(Error{code, std::move(message)});
    }

    bool ok() const noexcept { return std::holds_alternative<T>(data_); }
    explicit operator bool() const noexcept { return ok(); }

    T& value() {
        DOLL_ASSERT(ok(), "Result::value() called on an error");
        return std::get<T>(data_);
    }
    const T& value() const {
        DOLL_ASSERT(ok(), "Result::value() called on an error");
        return std::get<T>(data_);
    }

    const Error& error() const {
        DOLL_ASSERT(!ok(), "Result::error() called on a success");
        return std::get<Error>(data_);
    }

private:
    explicit Result(T value) : data_(std::move(value)) {}
    explicit Result(Error error) : data_(std::move(error)) {}

    std::variant<T, Error> data_;
};

/// 无返回值的 Result，用作 `Status`。
template <>
class Result<void> {
public:
    static Result success() { return Result(true); }
    static Result fail(ErrorCode code, std::string message) {
        return Result(Error{code, std::move(message)});
    }

    bool ok() const noexcept { return ok_; }
    explicit operator bool() const noexcept { return ok_; }

    const Error& error() const {
        DOLL_ASSERT(!ok_, "Result::error() called on a success");
        return error_;
    }

private:
    explicit Result(bool ok) : ok_(ok) {}
    explicit Result(Error error) : ok_(false), error_(std::move(error)) {}

    bool ok_ = true;
    Error error_;
};

using Status = Result<void>;

} // namespace doll
