#include "DollAssert.h"

#include <cstdlib>

#include "Log.h"

namespace doll {

void fatal(const char* expr, const char* file, int line, std::string_view message) {
    if (expr != nullptr) {
        DOLL_LOG_ERROR("assert", "{}:{} 断言失败 `{}`: {}", file, line, expr, message);
    } else {
        DOLL_LOG_ERROR("assert", "{}:{} 致命错误: {}", file, line, message);
    }
    log::shutdown();
    std::abort();
}

} // namespace doll
