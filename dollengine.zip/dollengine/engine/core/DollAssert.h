#pragma once

#include <string_view>

namespace doll {

/// 记录致命错误并终止进程。
/// Release 下同样生效（写日志后 abort），避免"断言被静默关掉"导致的问题。
[[noreturn]] void fatal(const char* expr, const char* file, int line, std::string_view message);

} // namespace doll

#define DOLL_ASSERT(cond, msg) \
    do { \
        if (!(cond)) { \
            ::doll::fatal(#cond, __FILE__, __LINE__, msg); \
        } \
    } while (false)

#define DOLL_FATAL(msg) \
    do { \
        ::doll::fatal(nullptr, __FILE__, __LINE__, msg); \
    } while (false)
