#pragma once

#include <functional>
#include <memory>
#include <string>
#include <utility>
#include <vector>

namespace doll {

/// 一个可撤销/重做的命令。
class Command {
public:
    virtual ~Command() = default;
    virtual void redo() = 0;
    virtual void undo() = 0;
    [[nodiscard]] virtual std::string name() const = 0;
};

/// 命令历史：`doCommand` 执行并入撤销栈；`undo`/`redo` 在两栈之间移动。
/// 新命令会清空重做栈（标准行为：撤销后做新操作，旧的重做分支丢弃）。
class CommandHistory {
public:
    void doCommand(std::unique_ptr<Command> command) {
        command->redo();
        undoStack_.push_back(std::move(command));
        redoStack_.clear();
    }

    [[nodiscard]] bool canUndo() const { return !undoStack_.empty(); }
    [[nodiscard]] bool canRedo() const { return !redoStack_.empty(); }
    [[nodiscard]] std::size_t undoCount() const { return undoStack_.size(); }
    [[nodiscard]] std::size_t redoCount() const { return redoStack_.size(); }

    void undo() {
        if (undoStack_.empty()) {
            return;
        }
        auto command = std::move(undoStack_.back());
        undoStack_.pop_back();
        command->undo();
        redoStack_.push_back(std::move(command));
    }

    void redo() {
        if (redoStack_.empty()) {
            return;
        }
        auto command = std::move(redoStack_.back());
        redoStack_.pop_back();
        command->redo();
        undoStack_.push_back(std::move(command));
    }

    void clear() {
        undoStack_.clear();
        redoStack_.clear();
    }

private:
    std::vector<std::unique_ptr<Command>> undoStack_;
    std::vector<std::unique_ptr<Command>> redoStack_;
};

/// 通用的「值变更」命令：记录旧值/新值，redo 设新值、undo 设旧值。
/// 用于 M4 的属性编辑（变换、形变权重等），避免为每种属性手写命令类。
template <typename T>
class SetValueCommand final : public Command {
public:
    using Setter = std::function<void(const T&)>;

    SetValueCommand(std::string name, T oldValue, T newValue, Setter setter)
        : name_(std::move(name)),
          oldValue_(std::move(oldValue)),
          newValue_(std::move(newValue)),
          setter_(std::move(setter)) {}

    void redo() override { setter_(newValue_); }
    void undo() override { setter_(oldValue_); }
    [[nodiscard]] std::string name() const override { return name_; }

private:
    std::string name_;
    T oldValue_;
    T newValue_;
    Setter setter_;
};

} // namespace doll
