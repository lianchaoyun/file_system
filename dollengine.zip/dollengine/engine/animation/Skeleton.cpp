#include "Skeleton.h"

#include <glm/gtc/quaternion.hpp>

#define GLM_ENABLE_EXPERIMENTAL
#include <glm/gtx/matrix_decompose.hpp>

#include <algorithm>
#include <cmath>
#include <functional>
#include <limits>
#include <unordered_map>

namespace doll::animation {

namespace {

/// 从场景根 DFS 累加每个节点的全局变换。
/// `localOverride` 非空时用它替代 nodes[i].localTransform（动画采样后）。
std::vector<glm::mat4> computeNodeWorldTransformsImpl(
    const std::vector<asset::NodeData>& nodes,
    const std::vector<std::int32_t>& sceneRootNodes,
    const std::vector<glm::mat4>* localOverride = nullptr) {
    std::vector<glm::mat4> world(nodes.size(), glm::mat4(1.0f));

    std::function<void(std::int32_t, const glm::mat4&)> visit =
        [&](std::int32_t nodeIdx, const glm::mat4& parentWorld) {
            const auto& node = nodes[static_cast<std::size_t>(nodeIdx)];
            const glm::mat4 local = (localOverride != nullptr)
                                        ? (*localOverride)[static_cast<std::size_t>(nodeIdx)]
                                        : node.localTransform;
            const glm::mat4 w = parentWorld * local;
            world[static_cast<std::size_t>(nodeIdx)] = w;
            for (const std::int32_t child : node.children) {
                visit(child, w);
            }
        };

    for (const std::int32_t root : sceneRootNodes) {
        visit(root, glm::mat4(1.0f));
    }
    return world;
}

} // namespace

std::vector<glm::mat4> computeNodeWorldTransforms(
    const std::vector<asset::NodeData>& nodes,
    const std::vector<std::int32_t>& sceneRootNodes) {
    return computeNodeWorldTransformsImpl(nodes, sceneRootNodes);
}

std::vector<glm::mat4> computeJointWorldTransforms(
    const std::vector<asset::NodeData>& nodes,
    const std::vector<std::int32_t>& sceneRootNodes,
    const std::vector<std::int32_t>& skinJoints) {
    std::vector<glm::mat4> jointWorld(skinJoints.size(), glm::mat4(1.0f));

    std::unordered_map<std::int32_t, std::int32_t> jointIndex;
    jointIndex.reserve(skinJoints.size());
    for (std::size_t i = 0; i < skinJoints.size(); ++i) {
        jointIndex[skinJoints[i]] = static_cast<std::int32_t>(i);
    }

    const auto nodeWorld = computeNodeWorldTransformsImpl(nodes, sceneRootNodes);
    for (std::size_t i = 0; i < skinJoints.size(); ++i) {
        const std::int32_t nodeIdx = skinJoints[i];
        if (static_cast<std::size_t>(nodeIdx) < nodeWorld.size()) {
            jointWorld[i] = nodeWorld[static_cast<std::size_t>(nodeIdx)];
        }
    }
    return jointWorld;
}

std::vector<glm::mat4> computeSkinningMatrices(
    const std::vector<asset::NodeData>& nodes,
    const std::vector<std::int32_t>& sceneRootNodes,
    const asset::SkinData& skin) {
    const auto jointWorld = computeJointWorldTransforms(nodes, sceneRootNodes, skin.joints);
    std::vector<glm::mat4> matrices(skin.joints.size(), glm::mat4(1.0f));
    for (std::size_t i = 0; i < skin.joints.size(); ++i) {
        const glm::mat4 ibm = (i < skin.inverseBindMatrices.size())
                                  ? skin.inverseBindMatrices[i]
                                  : glm::mat4(1.0f);
        matrices[i] = jointWorld[i] * ibm;
    }
    return matrices;
}

std::vector<glm::mat4> sampleLocalTransforms(
    const std::vector<asset::NodeData>& nodes,
    const asset::AnimationData& animation,
    float time) {
    std::vector<glm::mat4> local(nodes.size());
    for (std::size_t i = 0; i < nodes.size(); ++i) {
        local[i] = nodes[i].localTransform;
    }

    for (const auto& channel : animation.channels) {
        if (channel.samplerIndex < 0 || channel.nodeIndex < 0) {
            continue;
        }
        if (static_cast<std::size_t>(channel.samplerIndex) >= animation.samplers.size()) {
            continue;
        }
        const auto& sampler = animation.samplers[static_cast<std::size_t>(channel.samplerIndex)];
        if (sampler.times.size() < 2) {
            continue;
        }
        const std::size_t nodeIdx = static_cast<std::size_t>(channel.nodeIndex);
        if (nodeIdx >= nodes.size()) {
            continue;
        }

        // 循环时间。
        const float duration = animation.duration;
        const float t = (duration > 0.0f) ? std::fmod(time, duration) : time;

        // 找插值区间（线性）。
        const auto& ts = sampler.times;
        std::size_t idx = 0;
        if (t <= ts.front()) {
            idx = 0;
        } else if (t >= ts.back()) {
            idx = ts.size() - 2;
        } else {
            while (idx + 2 < ts.size() && ts[idx + 1] < t) {
                ++idx;
            }
        }
        const float t0 = ts[idx];
        const float t1 = ts[idx + 1];
        // STEP：保持前一个关键帧的值（f=0）；CUBICSPLINE 暂按线性处理。
        const float f = (sampler.interpolation == asset::AnimationInterpolation::Step)
                            ? 0.0f
                            : ((t1 > t0) ? (t - t0) / (t1 - t0) : 0.0f);

        // 分解当前局部变换，更新被动画的分量。
        glm::vec3 scale(1.0f);
        glm::vec3 translation(0.0f);
        glm::vec3 skew(0.0f);
        glm::vec4 perspective(0.0f);
        glm::quat rotation(1.0f, 0.0f, 0.0f, 0.0f);
        glm::decompose(local[nodeIdx], scale, rotation, translation, skew, perspective);

        switch (channel.path) {
            case asset::AnimationPath::Translation:
                if (sampler.translations.size() == ts.size()) {
                    translation = glm::mix(sampler.translations[idx], sampler.translations[idx + 1], f);
                }
                break;
            case asset::AnimationPath::Rotation:
                if (sampler.rotations.size() == ts.size()) {
                    const glm::vec4 q0 = sampler.rotations[idx];
                    const glm::vec4 q1 = sampler.rotations[idx + 1];
                    const glm::quat a(q0.w, q0.x, q0.y, q0.z); // glTF [x,y,z,w] → glm (w,x,y,z)
                    const glm::quat b(q1.w, q1.x, q1.y, q1.z);
                    rotation = glm::slerp(a, b, f);
                }
                break;
            case asset::AnimationPath::Scale:
                if (sampler.scales.size() == ts.size()) {
                    scale = glm::mix(sampler.scales[idx], sampler.scales[idx + 1], f);
                }
                break;
            case asset::AnimationPath::Weights:
                break; // Morph 权重不作用于节点变换，M3 后续做 morph 渲染。
        }

        local[nodeIdx] = glm::translate(glm::mat4(1.0f), translation) *
                         glm::mat4_cast(rotation) *
                         glm::scale(glm::mat4(1.0f), scale);
    }

    return local;
}

std::vector<glm::mat4> computeJointWorldTransformsWithLocal(
    const std::vector<asset::NodeData>& nodes,
    const std::vector<std::int32_t>& sceneRootNodes,
    const std::vector<std::int32_t>& skinJoints,
    const std::vector<glm::mat4>& localTransforms) {
    std::vector<glm::mat4> jointWorld(skinJoints.size(), glm::mat4(1.0f));
    const auto nodeWorld = computeNodeWorldTransformsImpl(nodes, sceneRootNodes, &localTransforms);
    for (std::size_t i = 0; i < skinJoints.size(); ++i) {
        const std::int32_t nodeIdx = skinJoints[i];
        if (static_cast<std::size_t>(nodeIdx) < nodeWorld.size()) {
            jointWorld[i] = nodeWorld[static_cast<std::size_t>(nodeIdx)];
        }
    }
    return jointWorld;
}

std::vector<glm::mat4> computeSkinningMatricesWithLocal(
    const std::vector<asset::NodeData>& nodes,
    const std::vector<std::int32_t>& sceneRootNodes,
    const asset::SkinData& skin,
    const std::vector<glm::mat4>& localTransforms) {
    const auto jointWorld = computeJointWorldTransformsWithLocal(
        nodes, sceneRootNodes, skin.joints, localTransforms);
    std::vector<glm::mat4> matrices(skin.joints.size(), glm::mat4(1.0f));
    for (std::size_t i = 0; i < skin.joints.size(); ++i) {
        const glm::mat4 ibm = (i < skin.inverseBindMatrices.size())
                                  ? skin.inverseBindMatrices[i]
                                  : glm::mat4(1.0f);
        matrices[i] = jointWorld[i] * ibm;
    }
    return matrices;
}

void applyJointRotations(
    std::vector<glm::mat4>& local,
    const std::unordered_map<std::int32_t, glm::vec3>& jointRotations) {
    for (const auto& [nodeIdx, euler] : jointRotations) {
        if (nodeIdx < 0 || static_cast<std::size_t>(nodeIdx) >= local.size()) {
            continue;
        }
        glm::vec3 scale(1.0f);
        glm::vec3 translation(0.0f);
        glm::vec3 skew(0.0f);
        glm::vec4 perspective(0.0f);
        glm::quat rotation(1.0f, 0.0f, 0.0f, 0.0f);
        glm::decompose(local[static_cast<std::size_t>(nodeIdx)], scale, rotation, translation, skew, perspective);
        const glm::mat4 r = glm::mat4_cast(glm::quat(glm::radians(euler)));
        local[static_cast<std::size_t>(nodeIdx)] =
            glm::translate(glm::mat4(1.0f), translation) * r * glm::scale(glm::mat4(1.0f), scale);
    }
}

void insertKeyframe(asset::AnimationSamplerData& sampler, float time, asset::AnimationPath path) {
    if (sampler.times.size() < 2) {
        return;
    }
    const float t = std::clamp(time, sampler.times.front(), sampler.times.back());

    std::size_t idx = 0;
    while (idx < sampler.times.size() && sampler.times[idx] < t) {
        ++idx;
    }
    // 同位置已有关键帧则不重复插入。
    if (idx < sampler.times.size() && std::abs(sampler.times[idx] - t) < 1e-4f) {
        return;
    }
    if (idx == 0 || idx >= sampler.times.size()) {
        return;
    }

    const float t0 = sampler.times[idx - 1];
    const float t1 = sampler.times[idx];
    const float f = (t1 > t0) ? (t - t0) / (t1 - t0) : 0.0f;
    const auto pos = static_cast<std::ptrdiff_t>(idx);

    switch (path) {
        case asset::AnimationPath::Rotation: {
            if (sampler.rotations.size() != sampler.times.size()) {
                return;
            }
            const glm::vec4 q0 = sampler.rotations[idx - 1];
            const glm::vec4 q1 = sampler.rotations[idx];
            const glm::quat q = glm::slerp(glm::quat(q0.w, q0.x, q0.y, q0.z),
                                           glm::quat(q1.w, q1.x, q1.y, q1.z), f);
            sampler.rotations.insert(sampler.rotations.begin() + pos,
                                     glm::vec4(q.x, q.y, q.z, q.w));
            break;
        }
        case asset::AnimationPath::Translation: {
            if (sampler.translations.size() != sampler.times.size()) {
                return;
            }
            sampler.translations.insert(sampler.translations.begin() + pos,
                                        glm::mix(sampler.translations[idx - 1],
                                                 sampler.translations[idx], f));
            break;
        }
        case asset::AnimationPath::Scale: {
            if (sampler.scales.size() != sampler.times.size()) {
                return;
            }
            sampler.scales.insert(sampler.scales.begin() + pos,
                                  glm::mix(sampler.scales[idx - 1], sampler.scales[idx], f));
            break;
        }
        case asset::AnimationPath::Weights:
            return;
    }
    sampler.times.insert(sampler.times.begin() + pos, t);
}

bool removeNearestKeyframe(asset::AnimationSamplerData& sampler, float time) {
    // 至少保留 2 个关键帧，否则线性插值失去意义。
    if (sampler.times.size() <= 2) {
        return false;
    }
    std::size_t best = 0;
    float bestDist = std::numeric_limits<float>::max();
    for (std::size_t i = 0; i < sampler.times.size(); ++i) {
        const float dist = std::abs(sampler.times[i] - time);
        if (dist < bestDist) {
            bestDist = dist;
            best = i;
        }
    }
    const auto pos = static_cast<std::ptrdiff_t>(best);
    sampler.times.erase(sampler.times.begin() + pos);
    if (sampler.rotations.size() > best) {
        sampler.rotations.erase(sampler.rotations.begin() + pos);
    }
    if (sampler.translations.size() > best) {
        sampler.translations.erase(sampler.translations.begin() + pos);
    }
    if (sampler.scales.size() > best) {
        sampler.scales.erase(sampler.scales.begin() + pos);
    }
    if (sampler.weights.size() > best) {
        sampler.weights.erase(sampler.weights.begin() + pos);
    }
    return true;
}

std::vector<glm::vec3> buildBoneLines(
    const std::vector<asset::NodeData>& nodes,
    const std::vector<std::int32_t>& skinJoints,
    const std::vector<glm::mat4>& jointWorld) {
    // 每个节点的父索引。
    std::vector<std::int32_t> parent(nodes.size(), -1);
    for (std::size_t i = 0; i < nodes.size(); ++i) {
        for (const std::int32_t child : nodes[i].children) {
            parent[static_cast<std::size_t>(child)] = static_cast<std::int32_t>(i);
        }
    }
    // node → joint 数组索引。
    std::unordered_map<std::int32_t, std::int32_t> jointIndex;
    jointIndex.reserve(skinJoints.size());
    for (std::size_t i = 0; i < skinJoints.size(); ++i) {
        jointIndex[skinJoints[i]] = static_cast<std::int32_t>(i);
    }

    std::vector<glm::vec3> lines;
    lines.reserve(skinJoints.size() * 2);
    for (std::size_t i = 0; i < skinJoints.size(); ++i) {
        const std::int32_t nodeIdx = skinJoints[i];
        const glm::vec3 pos(jointWorld[i][3]);
        // 向上找最近的祖先关节。
        std::int32_t p = parent[static_cast<std::size_t>(nodeIdx)];
        while (p >= 0 && jointIndex.find(p) == jointIndex.end()) {
            p = parent[static_cast<std::size_t>(p)];
        }
        if (p >= 0) {
            const std::int32_t parentJoint = jointIndex[p];
            lines.push_back(glm::vec3(jointWorld[static_cast<std::size_t>(parentJoint)][3]));
            lines.push_back(pos);
        }
    }
    return lines;
}

} // namespace doll::animation
