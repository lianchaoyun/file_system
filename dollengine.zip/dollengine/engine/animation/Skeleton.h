#pragma once

#include <glm/glm.hpp>

#include <cstdint>
#include <unordered_map>
#include <vector>

#include "AssetData.h"

namespace doll::animation {

/// 计算蒙皮关节的全局（世界）变换，按 `skinJoints` 顺序返回。
/// bind pose：只累加节点的 localTransform，不应用逆绑定矩阵。
std::vector<glm::mat4> computeJointWorldTransforms(
    const std::vector<asset::NodeData>& nodes,
    const std::vector<std::int32_t>& sceneRootNodes,
    const std::vector<std::int32_t>& skinJoints);

/// 生成骨骼线（line list）：每个关节连接到它的父关节（最近祖先关节）。
/// 返回的顶点每 2 个组成一条线段。
std::vector<glm::vec3> buildBoneLines(
    const std::vector<asset::NodeData>& nodes,
    const std::vector<std::int32_t>& skinJoints,
    const std::vector<glm::mat4>& jointWorld);

/// 计算节点的全局变换（从场景根 DFS 累加），供通用节点层级使用。
std::vector<glm::mat4> computeNodeWorldTransforms(
    const std::vector<asset::NodeData>& nodes,
    const std::vector<std::int32_t>& sceneRootNodes);

/// 计算蒙皮矩阵：`jointWorld * inverseBindMatrix`，按 skin.joints 顺序返回。
/// 顶点用 `sum(weights[i] * skinning[i] * position)` 变换。
std::vector<glm::mat4> computeSkinningMatrices(
    const std::vector<asset::NodeData>& nodes,
    const std::vector<std::int32_t>& sceneRootNodes,
    const asset::SkinData& skin);

/// 采样动画在 `time` 时刻的节点局部变换（关键帧插值），返回修改后的 localTransform
/// 列表（未动画的节点保持原样）。time 会按 duration 循环。
std::vector<glm::mat4> sampleLocalTransforms(
    const std::vector<asset::NodeData>& nodes,
    const asset::AnimationData& animation,
    float time);

/// 动画采样后版本：用 localTransforms 替代节点局部变换计算关节全局变换。
std::vector<glm::mat4> computeJointWorldTransformsWithLocal(
    const std::vector<asset::NodeData>& nodes,
    const std::vector<std::int32_t>& sceneRootNodes,
    const std::vector<std::int32_t>& skinJoints,
    const std::vector<glm::mat4>& localTransforms);

/// 动画采样后版本：计算蒙皮矩阵。
std::vector<glm::mat4> computeSkinningMatricesWithLocal(
    const std::vector<asset::NodeData>& nodes,
    const std::vector<std::int32_t>& sceneRootNodes,
    const asset::SkinData& skin,
    const std::vector<glm::mat4>& localTransforms);

/// 应用关节旋转覆盖：把欧拉角（度）覆盖到 local 的旋转分量（保持 position/scale）。
/// 用于 M4 骨骼姿态编辑。
void applyJointRotations(
    std::vector<glm::mat4>& local,
    const std::unordered_map<std::int32_t, glm::vec3>& jointRotations);

/// 在采样器的 `time` 处插入关键帧（值取当前插值结果，视觉不跳变）。
/// 已存在同位置关键帧或路径不支持时不做修改。
void insertKeyframe(asset::AnimationSamplerData& sampler, float time, asset::AnimationPath path);

/// 删除采样器里最接近 `time` 的关键帧（至少保留 2 个）。
/// 返回是否真的删除了。
bool removeNearestKeyframe(asset::AnimationSamplerData& sampler, float time);

} // namespace doll::animation
