#pragma once

namespace doll::platform {

/// 一帧的输入快照。
///
/// M0 只有关闭与 ESC；后续编辑器快捷键（视口聚焦、面板开关）扩展在这里，
/// 避免面板直接读 SDL 事件队列。
struct InputSnapshot {
    bool quitRequested = false;
    bool escapePressed = false;
};

} // namespace doll::platform
