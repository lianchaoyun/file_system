#include "Window.h"

#include <SDL3/SDL.h>
#include <SDL3/SDL_vulkan.h>

#include "Log.h"

namespace doll::platform {

Window::~Window() {
    shutdown();
}

Status Window::init(const WindowConfig& config) {
    if (!SDL_Init(SDL_INIT_VIDEO)) {
        return Status::fail(ErrorCode::Graphics,
                            std::string("SDL_Init(SDL_INIT_VIDEO) 失败: ") + SDL_GetError());
    }

    SDL_WindowFlags flags = SDL_WINDOW_HIGH_PIXEL_DENSITY;
    if (config.resizable) {
        flags |= SDL_WINDOW_RESIZABLE;
    }
    if (config.vulkan) {
        flags |= SDL_WINDOW_VULKAN;
        // 显式加载 Vulkan loader：SDL_CreateWindow 内部失败时（loader 加载失败）
        // 会直接返回 null 且不设置错误信息，这里提前加载拿到可读错误。
        if (!SDL_Vulkan_LoadLibrary(nullptr)) {
            SDL_Quit();
            return Status::fail(ErrorCode::Graphics,
                                std::string("SDL_Vulkan_LoadLibrary 失败: ") + SDL_GetError());
        }
    }

    window_ = SDL_CreateWindow(config.title.c_str(), config.width, config.height, flags);
    if (window_ == nullptr) {
        SDL_Quit();
        return Status::fail(ErrorCode::Graphics,
                            std::string("SDL_CreateWindow 失败: ") + SDL_GetError());
    }

    // 高 DPI 修正：高 DPI 屏上窗口显示缩放 > 1，直接用逻辑尺寸会显得小
    //（如 200% 缩放下 1280 像素只有一半视觉宽度，四个面板挤成一团）。
    // 创建后按实际显示缩放把尺寸放大到逻辑尺寸。
    const float dpiScale = SDL_GetWindowDisplayScale(window_);
    if (dpiScale > 1.01f) {
        SDL_SetWindowSize(window_,
                          static_cast<int>(config.width * dpiScale),
                          static_cast<int>(config.height * dpiScale));
    }

    DOLL_LOG_INFO("platform", "窗口已创建：{}x{}「{}」（DPI 缩放 {:.2}）",
                  config.width, config.height, config.title, dpiScale);
    return Status::success();
}

void Window::shutdown() {
    if (window_ != nullptr) {
        SDL_DestroyWindow(window_);
        window_ = nullptr;
    }
}

void Window::pollEvents() {
    SDL_Event event;
    while (SDL_PollEvent(&event)) {
        // 先交给外部（ImGui 靠这些事件才有鼠标/键盘交互）；不转发的话
        // 面板拖拽、折叠箭头、输入控件全部没反应。
        if (eventCallback_) {
            eventCallback_(event);
        }
        switch (event.type) {
            case SDL_EVENT_QUIT:
                closeRequested_ = true;
                break;
            case SDL_EVENT_KEY_DOWN:
                if (event.key.key == SDLK_ESCAPE) {
                    closeRequested_ = true;
                }
                break;
            case SDL_EVENT_WINDOW_PIXEL_SIZE_CHANGED: {
                int w = 0;
                int h = 0;
                pixelSize(w, h);
                DOLL_LOG_DEBUG("platform", "像素尺寸变化：{}x{}", w, h);
                break;
            }
            default:
                break;
        }
    }
}

void Window::pixelSize(int& width, int& height) const {
    width = 0;
    height = 0;
    if (window_ != nullptr) {
        SDL_GetWindowSizeInPixels(window_, &width, &height);
    }
}

void Window::logicalSize(int& width, int& height) const {
    width = 0;
    height = 0;
    if (window_ != nullptr) {
        SDL_GetWindowSize(window_, &width, &height);
    }
}

} // namespace doll::platform
