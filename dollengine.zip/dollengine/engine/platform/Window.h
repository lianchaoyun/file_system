#pragma once

#include <SDL3/SDL.h>

#include <functional>
#include <string>

#include "Result.h"

namespace doll::platform {

struct WindowConfig {
    std::string title = "dollengine";
    int width = 1280;
    int height = 760;
    bool resizable = true;
    /// M0 用 SDL_Renderer 渲染 ImGui，不需要 Vulkan surface；M1 接入渲染器时设为 true。
    bool vulkan = false;
};

/// SDL3 窗口与事件循环封装。
///
/// 只负责窗口创建、事件轮询、像素尺寸查询与干净销毁；不碰渲染。
/// `SDL_Quit` 由 App 在退出时统一调用，这里不重复。
class Window {
public:
    Window() = default;
    ~Window();

    Window(const Window&) = delete;
    Window& operator=(const Window&) = delete;

    Status init(const WindowConfig& config);
    void shutdown();

    [[nodiscard]] SDL_Window* handle() const noexcept { return window_; }
    [[nodiscard]] bool shouldClose() const noexcept { return closeRequested_; }
    void requestClose() noexcept { closeRequested_ = true; }

    /// 事件回调：每个 SDL 事件都会先交给它，再走本类的 QUIT/ESC 处理。
    /// App 用它把事件转发给 ImGui —— platform 层不直接依赖 ImGui。
    using EventCallback = std::function<void(const SDL_Event&)>;
    void setEventCallback(EventCallback callback) { eventCallback_ = std::move(callback); }

    /// 轮询事件：先交给回调，再处理 QUIT、ESC 关闭与窗口像素尺寸变化。
    void pollEvents();

    /// 像素尺寸（高 DPI 下用于渲染目标，不要用逻辑尺寸）。
    void pixelSize(int& width, int& height) const;

    /// 逻辑尺寸（ImGui 的 DisplaySize 用这个）。
    void logicalSize(int& width, int& height) const;

private:
    SDL_Window* window_ = nullptr;
    bool closeRequested_ = false;
    EventCallback eventCallback_;
};

} // namespace doll::platform
