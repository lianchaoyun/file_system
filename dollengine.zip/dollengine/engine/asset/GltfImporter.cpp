#include "GltfImporter.h"

#include "AssetData.h"
#include "Log.h"

#include <fastgltf/core.hpp>
#include <fastgltf/glm_element_traits.hpp>
#include <fastgltf/tools.hpp>
#include <fastgltf/types.hpp>
#include <fastgltf/util.hpp>

#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/quaternion.hpp>

#include <algorithm>
#include <cstring>
#include <format>
#include <string>
#include <vector>

#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

namespace doll::asset {

namespace {

/// 把 fastgltf 的 TRS/矩阵变换转成 glm::mat4。
glm::mat4 nodeLocalTransform(const fastgltf::Node& node) {
    if (const auto* trs = std::get_if<fastgltf::TRS>(&node.transform)) {
        const glm::mat4 t = glm::translate(glm::mat4(1.0f),
            glm::vec3(trs->translation.x(), trs->translation.y(), trs->translation.z()));
        // gltf 四元数分量顺序是 [x,y,z,w]，glm::quat 构造是 (w,x,y,z)。
        const glm::mat4 r = glm::mat4_cast(glm::quat(
            trs->rotation.w(), trs->rotation.x(), trs->rotation.y(), trs->rotation.z()));
        const glm::mat4 s = glm::scale(glm::mat4(1.0f),
            glm::vec3(trs->scale.x(), trs->scale.y(), trs->scale.z()));
        return t * r * s;
    }
    if (const auto* m = std::get_if<fastgltf::math::fmat4x4>(&node.transform)) {
        // fastgltf 与 glm 的 mat4 都是列主序 16 个 float，直接拷贝。
        glm::mat4 result;
        std::memcpy(&result[0][0], m, sizeof(glm::mat4));
        return result;
    }
    return glm::mat4(1.0f);
}

/// 提取 image 的原始字节（PNG/JPEG 等，未解码）。
std::vector<std::byte> extractImageBytes(const fastgltf::Asset& asset,
                                         const fastgltf::Image& image) {
    const auto readBufferView = [&asset](std::size_t viewIndex) -> std::vector<std::byte> {
        const auto& view = asset.bufferViews[viewIndex];
        const auto& buffer = asset.buffers[view.bufferIndex];
        return std::visit(fastgltf::visitor{
            [](auto) { return std::vector<std::byte>{}; },
            [&](const fastgltf::sources::ByteView& bv) {
                return std::vector<std::byte>(
                    bv.bytes.begin() + view.byteOffset,
                    bv.bytes.begin() + view.byteOffset + view.byteLength);
            },
            [&](const fastgltf::sources::Vector& vec) {
                return std::vector<std::byte>(
                    vec.bytes.begin() + view.byteOffset,
                    vec.bytes.begin() + view.byteOffset + view.byteLength);
            },
            [&](const fastgltf::sources::Array& arr) {
                return std::vector<std::byte>(
                    arr.bytes.begin() + view.byteOffset,
                    arr.bytes.begin() + view.byteOffset + view.byteLength);
            },
        }, buffer.data);
    };

    return std::visit(fastgltf::visitor{
        [](auto) { return std::vector<std::byte>{}; },
        [&](const fastgltf::sources::BufferView& view) { return readBufferView(view.bufferViewIndex); },
        [&](const fastgltf::sources::Vector& vec) {
            return std::vector<std::byte>(vec.bytes.begin(), vec.bytes.end());
        },
        [&](const fastgltf::sources::Array& arr) {
            return std::vector<std::byte>(arr.bytes.begin(), arr.bytes.end());
        },
        [&](const fastgltf::sources::ByteView& bv) {
            return std::vector<std::byte>(bv.bytes.begin(), bv.bytes.end());
        },
    }, image.data);
}

/// 提取一个网格 primitive 的顶点与索引。
Result<MeshData> extractMesh(const fastgltf::Asset& asset, const fastgltf::Primitive& primitive) {
    MeshData mesh;

    const auto findAccessor = [&primitive](const char* attr) -> std::int64_t {
        const auto it = primitive.findAttribute(attr);
        return it == primitive.attributes.end() ? -1 : static_cast<std::int64_t>(it->accessorIndex);
    };

    const std::int64_t positionIdx = findAccessor("POSITION");
    if (positionIdx < 0) {
        return Result<MeshData>::fail(ErrorCode::Unsupported, "网格缺少 POSITION 属性");
    }
    const auto& positionAccessor = asset.accessors[static_cast<std::size_t>(positionIdx)];
    const std::size_t vertexCount = positionAccessor.count;

    const std::int64_t normalIdx = findAccessor("NORMAL");
    const std::int64_t colorIdx = findAccessor("COLOR_0");
    const std::int64_t uvIdx = findAccessor("TEXCOORD_0");
    const std::int64_t jointsIdx = findAccessor("JOINTS_0");
    const std::int64_t weightsIdx = findAccessor("WEIGHTS_0");

    // 先读位置，确定顶点数量并预分配。
    mesh.vertices.reserve(vertexCount);
    fastgltf::iterateAccessor<glm::vec3>(
        asset, positionAccessor,
        [&](glm::vec3 pos) { mesh.vertices.push_back(Vertex{pos}); });

    // 法线（可选）。
    if (normalIdx >= 0) {
        const auto& accessor = asset.accessors[static_cast<std::size_t>(normalIdx)];
        std::size_t i = 0;
        fastgltf::iterateAccessor<glm::vec3>(asset, accessor,
            [&](glm::vec3 n) {
                if (i < mesh.vertices.size()) mesh.vertices[i].normal = n;
                ++i;
            });
    }
    // 顶点色（可选，VEC3；VEC4 版本后续按 accessor.type 分支处理）。
    if (colorIdx >= 0) {
        const auto& accessor = asset.accessors[static_cast<std::size_t>(colorIdx)];
        std::size_t i = 0;
        fastgltf::iterateAccessor<glm::vec3>(asset, accessor,
            [&](glm::vec3 c) {
                if (i < mesh.vertices.size()) mesh.vertices[i].color = glm::vec4(c, 1.0f);
                ++i;
            });
    }
    // UV（可选）。
    if (uvIdx >= 0) {
        const auto& accessor = asset.accessors[static_cast<std::size_t>(uvIdx)];
        std::size_t i = 0;
        fastgltf::iterateAccessor<glm::vec2>(asset, accessor,
            [&](glm::vec2 uv) {
                if (i < mesh.vertices.size()) mesh.vertices[i].uv = uv;
                ++i;
            });
    }
    // 蒙皮关节索引（可选，VEC4，UNSIGNED_BYTE/SHORT）。
    if (jointsIdx >= 0) {
        const auto& accessor = asset.accessors[static_cast<std::size_t>(jointsIdx)];
        std::size_t i = 0;
        fastgltf::iterateAccessor<glm::uvec4>(asset, accessor,
            [&](glm::uvec4 j) {
                if (i < mesh.vertices.size()) mesh.vertices[i].joints = j;
                ++i;
            });
    }
    // 蒙皮权重（可选，VEC4 FLOAT 或归一化分量）。
    if (weightsIdx >= 0) {
        const auto& accessor = asset.accessors[static_cast<std::size_t>(weightsIdx)];
        std::size_t i = 0;
        fastgltf::iterateAccessor<glm::vec4>(asset, accessor,
            [&](glm::vec4 w) {
                if (i < mesh.vertices.size()) mesh.vertices[i].weights = w;
                ++i;
            });
    }

    // 索引（可选：无索引时按顺序顶点）。
    if (primitive.indicesAccessor.has_value()) {
        const auto& accessor = asset.accessors[*primitive.indicesAccessor];
        mesh.indices.reserve(accessor.count);
        fastgltf::iterateAccessor<std::uint32_t>(asset, accessor,
            [&](std::uint32_t idx) { mesh.indices.push_back(idx); });
    } else {
        mesh.indices.resize(vertexCount);
        for (std::size_t i = 0; i < vertexCount; ++i) {
            mesh.indices[i] = static_cast<std::uint32_t>(i);
        }
    }

    // 形变目标（只取前几个，数据量大只做演示）。
    constexpr std::size_t kMaxMorphTargets = 4;
    const std::size_t morphCount = std::min(primitive.targets.size(), kMaxMorphTargets);
    mesh.morphTargets.reserve(morphCount);
    for (std::size_t t = 0; t < morphCount; ++t) {
        const auto& target = primitive.targets[t];
        const auto it = std::find_if(target.begin(), target.end(),
            [](const fastgltf::Attribute& a) { return a.name == "POSITION"; });
        if (it == target.end()) {
            continue;
        }
        MorphTarget morph;
        morph.name = std::format("morph {}", t);
        const auto& accessor = asset.accessors[it->accessorIndex];
        morph.positionDeltas.reserve(accessor.count);
        fastgltf::iterateAccessor<glm::vec3>(asset, accessor,
            [&](glm::vec3 d) { morph.positionDeltas.push_back(d); });
        mesh.morphTargets.push_back(std::move(morph));
    }

    if (primitive.materialIndex.has_value()) {
        mesh.materialIndex = static_cast<std::int32_t>(*primitive.materialIndex);
    }
    return Result<MeshData>::success(std::move(mesh));
}

} // namespace

Result<AssetData> GltfImporter::load(const std::filesystem::path& path) {
    auto dataResult = fastgltf::GltfDataBuffer::FromPath(path);
    if (dataResult.error() != fastgltf::Error::None) {
        return Result<AssetData>::fail(ErrorCode::Io,
            std::format("读取 glb 失败: {}", fastgltf::getErrorMessage(dataResult.error())));
    }
    auto& data = dataResult.get();

    fastgltf::Parser parser;
    auto assetResult = parser.loadGltfBinary(data, path.parent_path(), fastgltf::Options::None);
    if (assetResult.error() != fastgltf::Error::None) {
        return Result<AssetData>::fail(ErrorCode::Parse,
            std::format("解析 glb 失败: {}", fastgltf::getErrorMessage(assetResult.error())));
    }
    const auto& asset = assetResult.get();

    AssetData result;

    // 材质。
    result.materials.reserve(asset.materials.size());
    for (const auto& mat : asset.materials) {
        MaterialData material;
        material.name = mat.name;
        const auto& pbr = mat.pbrData;
        material.baseColorFactor = glm::vec4(pbr.baseColorFactor[0], pbr.baseColorFactor[1],
                                             pbr.baseColorFactor[2], pbr.baseColorFactor[3]);
        material.metallicFactor = pbr.metallicFactor;
        material.roughnessFactor = pbr.roughnessFactor;
        if (pbr.baseColorTexture.has_value()) {
            material.baseColorTexture =
                static_cast<std::int32_t>(pbr.baseColorTexture->textureIndex);
        }
        result.materials.push_back(std::move(material));
    }

    // 网格。记录每个原始 mesh 在 result.meshes 里的起始位置，供后续按 node 关联 skin。
    std::vector<std::size_t> meshStartIndex;
    meshStartIndex.reserve(asset.meshes.size());
    result.meshes.reserve(asset.meshes.size());
    for (const auto& mesh : asset.meshes) {
        meshStartIndex.push_back(result.meshes.size());
        for (const auto& primitive : mesh.primitives) {
            auto extracted = extractMesh(asset, primitive);
            if (!extracted) {
                return Result<AssetData>::fail(extracted.error().code, extracted.error().message);
            }
            MeshData meshData = std::move(extracted.value());
            meshData.name = mesh.name;
            result.meshes.push_back(std::move(meshData));
        }
    }

    // fastgltf 0.9 把 skinIndex 挂在 Node 上（而非 primitive），从挂 mesh 的 node 推断。
    for (const auto& node : asset.nodes) {
        if (!node.meshIndex.has_value() || !node.skinIndex.has_value()) {
            continue;
        }
        const std::size_t meshIdx = *node.meshIndex;
        if (meshIdx >= meshStartIndex.size()) {
            continue;
        }
        const std::size_t begin = meshStartIndex[meshIdx];
        const std::size_t end = (meshIdx + 1 < meshStartIndex.size())
                                    ? meshStartIndex[meshIdx + 1]
                                    : result.meshes.size();
        for (std::size_t i = begin; i < end; ++i) {
            result.meshes[i].skinIndex = static_cast<std::int32_t>(*node.skinIndex);
        }
    }

    // 纹理图像（stb_image 解码 PNG/JPEG → RGBA8）。
    result.textures.reserve(asset.images.size());
    for (const auto& image : asset.images) {
        const std::vector<std::byte> bytes = extractImageBytes(asset, image);
        TextureImage texture;
        texture.name = image.name;
        if (!bytes.empty()) {
            int width = 0;
            int height = 0;
            int channels = 0;
            stbi_uc* pixels = stbi_load_from_memory(
                reinterpret_cast<const stbi_uc*>(bytes.data()), static_cast<int>(bytes.size()),
                &width, &height, &channels, 4);
            if (pixels != nullptr) {
                texture.width = static_cast<std::uint32_t>(width);
                texture.height = static_cast<std::uint32_t>(height);
                texture.pixels.assign(pixels, pixels + static_cast<std::size_t>(width) * height * 4);
                stbi_image_free(pixels);
            } else {
                DOLL_LOG_WARN("asset", "纹理解码失败：{}", image.name);
            }
        }
        result.textures.push_back(std::move(texture));
    }

    // 节点层级。
    result.nodes.reserve(asset.nodes.size());
    for (const auto& node : asset.nodes) {
        NodeData nodeData;
        nodeData.name = node.name;
        nodeData.localTransform = nodeLocalTransform(node);
        if (node.meshIndex.has_value()) {
            nodeData.meshIndex = static_cast<std::int32_t>(*node.meshIndex);
        }
        nodeData.children.reserve(node.children.size());
        for (const std::size_t child : node.children) {
            nodeData.children.push_back(static_cast<std::int32_t>(child));
        }
        result.nodes.push_back(std::move(nodeData));
    }

    // 蒙皮（关节节点索引 + 逆绑定矩阵）。
    result.skins.reserve(asset.skins.size());
    for (const auto& skin : asset.skins) {
        SkinData skinData;
        skinData.name = skin.name;
        skinData.joints.reserve(skin.joints.size());
        for (const std::size_t joint : skin.joints) {
            skinData.joints.push_back(static_cast<std::int32_t>(joint));
        }
        if (skin.inverseBindMatrices.has_value()) {
            const auto& accessor = asset.accessors[*skin.inverseBindMatrices];
            skinData.inverseBindMatrices.reserve(accessor.count);
            fastgltf::iterateAccessor<glm::mat4>(asset, accessor,
                [&](glm::mat4 m) { skinData.inverseBindMatrices.push_back(m); });
        }
        result.skins.push_back(std::move(skinData));
    }

    // 动画（channels + samplers）。
    result.animations.reserve(asset.animations.size());
    for (const auto& anim : asset.animations) {
        AnimationData animation;
        animation.name = anim.name;

        for (const auto& channel : anim.channels) {
            AnimationChannelData ch;
            ch.samplerIndex = static_cast<std::int32_t>(channel.samplerIndex);
            if (channel.nodeIndex.has_value()) {
                ch.nodeIndex = static_cast<std::int32_t>(*channel.nodeIndex);
            }
            switch (channel.path) {
                case fastgltf::AnimationPath::Translation:
                    ch.path = AnimationPath::Translation;
                    break;
                case fastgltf::AnimationPath::Rotation:
                    ch.path = AnimationPath::Rotation;
                    break;
                case fastgltf::AnimationPath::Scale:
                    ch.path = AnimationPath::Scale;
                    break;
                case fastgltf::AnimationPath::Weights:
                    ch.path = AnimationPath::Weights;
                    break;
            }
            animation.channels.push_back(ch);
        }

        // 每个 sampler 的输出类型由引用它的 channel 的 path 决定。
        std::vector<AnimationPath> samplerPath(anim.samplers.size(), AnimationPath::Translation);
        for (const auto& ch : animation.channels) {
            if (ch.samplerIndex >= 0 &&
                static_cast<std::size_t>(ch.samplerIndex) < samplerPath.size()) {
                samplerPath[static_cast<std::size_t>(ch.samplerIndex)] = ch.path;
            }
        }

        for (std::size_t si = 0; si < anim.samplers.size(); ++si) {
            const auto& sampler = anim.samplers[si];
            AnimationSamplerData sd;
            const auto& inputAccessor = asset.accessors[sampler.inputAccessor];
            sd.times.reserve(inputAccessor.count);
            fastgltf::iterateAccessor<float>(asset, inputAccessor,
                [&](float t) { sd.times.push_back(t); });

            switch (sampler.interpolation) {
                case fastgltf::AnimationInterpolation::Linear:
                    sd.interpolation = AnimationInterpolation::Linear;
                    break;
                case fastgltf::AnimationInterpolation::Step:
                    sd.interpolation = AnimationInterpolation::Step;
                    break;
                case fastgltf::AnimationInterpolation::CubicSpline:
                    sd.interpolation = AnimationInterpolation::CubicSpline;
                    break;
            }

            // CUBICSPLINE 的输出是 [inTangent, value, outTangent] 三元组，
            // 只取中间的 value（tangent 暂不使用）。
            const bool cubic = (sd.interpolation == AnimationInterpolation::CubicSpline);
            const auto& outputAccessor = asset.accessors[sampler.outputAccessor];
            std::size_t elementIndex = 0;
            switch (samplerPath[si]) {
                case AnimationPath::Translation:
                    fastgltf::iterateAccessor<glm::vec3>(asset, outputAccessor,
                        [&](glm::vec3 v) {
                            if (!cubic || elementIndex % 3 == 1) {
                                sd.translations.push_back(v);
                            }
                            ++elementIndex;
                        });
                    break;
                case AnimationPath::Rotation:
                    fastgltf::iterateAccessor<glm::vec4>(asset, outputAccessor,
                        [&](glm::vec4 v) {
                            if (!cubic || elementIndex % 3 == 1) {
                                sd.rotations.push_back(v);
                            }
                            ++elementIndex;
                        });
                    break;
                case AnimationPath::Scale:
                    fastgltf::iterateAccessor<glm::vec3>(asset, outputAccessor,
                        [&](glm::vec3 v) {
                            if (!cubic || elementIndex % 3 == 1) {
                                sd.scales.push_back(v);
                            }
                            ++elementIndex;
                        });
                    break;
                case AnimationPath::Weights:
                    fastgltf::iterateAccessor<float>(asset, outputAccessor,
                        [&](float v) {
                            if (!cubic || elementIndex % 3 == 1) {
                                sd.weights.push_back(v);
                            }
                            ++elementIndex;
                        });
                    break;
            }
            animation.samplers.push_back(std::move(sd));
        }

        for (const auto& sd : animation.samplers) {
            if (!sd.times.empty()) {
                animation.duration = std::max(animation.duration, sd.times.back());
            }
        }

        result.animations.push_back(std::move(animation));
    }

    // 场景根节点。
    if (asset.defaultScene.has_value() && *asset.defaultScene < asset.scenes.size()) {
        const auto& scene = asset.scenes[*asset.defaultScene];
        result.sceneRootNodes.reserve(scene.nodeIndices.size());
        for (const std::size_t node : scene.nodeIndices) {
            result.sceneRootNodes.push_back(static_cast<std::int32_t>(node));
        }
    }

    DOLL_LOG_INFO("asset", "已加载 glb：{}（{} 网格，{} 材质，{} 节点）",
                  path.string(), result.meshes.size(), result.materials.size(), result.nodes.size());
    return Result<AssetData>::success(std::move(result));
}

} // namespace doll::asset
