#pragma once

#include "Result.h"

#include <filesystem>

namespace doll::asset {

struct AssetData;

/// glb 导入器：用 fastgltf 解析二进制 glTF，转成引擎自己的 `AssetData`。
///
/// 只做 CPU 侧解析与数据提取，不碰 GPU；GPU 上传在渲染层（M2 第 2 步）。
/// 解析失败返回带可读错误信息的 `Result`。
class GltfImporter {
public:
    static Result<AssetData> load(const std::filesystem::path& path);
};

} // namespace doll::asset
