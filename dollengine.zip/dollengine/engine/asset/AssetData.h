#pragma once

#include <glm/glm.hpp>

#include <cstdint>
#include <string>
#include <vector>

namespace doll::asset {

/// 网格顶点：位置 + 法线 + 颜色 + 纹理坐标 + 蒙皮关节权重。
struct Vertex {
    glm::vec3 position{0.0f};
    glm::vec3 normal{0.0f, 0.0f, 1.0f};
    glm::vec4 color{1.0f, 1.0f, 1.0f, 1.0f};
    glm::vec2 uv{0.0f};
    /// 影响该顶点的 4 个关节索引（无蒙皮时全 0）。
    glm::uvec4 joints{0, 0, 0, 0};
    /// 对应关节的权重（无蒙皮时 weights.x=1，其余 0）。
    glm::vec4 weights{1.0f, 0.0f, 0.0f, 0.0f};
};

/// 一个形变目标（morph target）：每个顶点一个位置偏移。
struct MorphTarget {
    std::string name;
    std::vector<glm::vec3> positionDeltas;
};

/// 一个网格（一次 draw 的几何数据）。
struct MeshData {
    std::string name;
    std::vector<Vertex> vertices;
    std::vector<std::uint32_t> indices;
    std::int32_t materialIndex = -1;
    /// 蒙皮索引（-1 表示静态网格，不做蒙皮）。
    std::int32_t skinIndex = -1;
    /// 形变目标（M4 形变滑块；只提取前几个用于演示）。
    std::vector<MorphTarget> morphTargets;
};

/// 蒙皮：关节节点索引 + 逆绑定矩阵（把顶点从网格空间转到关节空间）。
struct SkinData {
    std::string name;
    std::vector<std::int32_t> joints;
    std::vector<glm::mat4> inverseBindMatrices;
};

/// 动画通道的目标属性。
enum class AnimationPath { Translation, Rotation, Scale, Weights };

/// 一个动画通道：某个节点的某个属性的动画。
struct AnimationChannelData {
    std::int32_t nodeIndex = -1; // Weights path 时无意义
    AnimationPath path = AnimationPath::Translation;
    std::int32_t samplerIndex = -1;
};

/// 关键帧插值模式（对应 glTF 的 interpolation）。
enum class AnimationInterpolation { Linear, Step, CubicSpline };

/// 一个动画采样器：关键帧时间 + 输出数据（按 path 只填一种）。
struct AnimationSamplerData {
    std::vector<float> times;
    std::vector<glm::vec3> translations;
    std::vector<glm::vec4> rotations; // 四元数 [x,y,z,w]
    std::vector<glm::vec3> scales;
    std::vector<float> weights;
    AnimationInterpolation interpolation = AnimationInterpolation::Linear;
};

/// 一个动画：若干通道 + 采样器。
struct AnimationData {
    std::string name;
    std::vector<AnimationChannelData> channels;
    std::vector<AnimationSamplerData> samplers;
    float duration = 0.0f;
};

/// PBR 材质（M2 第 1 步只提取基础颜色因子，纹理在后续步骤）。
struct MaterialData {
    std::string name;
    glm::vec4 baseColorFactor{1.0f, 1.0f, 1.0f, 1.0f};
    float metallicFactor = 1.0f;
    float roughnessFactor = 1.0f;
    std::int32_t baseColorTexture = -1;
};

/// 纹理图像（RGBA8，解压后的像素）。
struct TextureImage {
    std::string name;
    std::vector<std::uint8_t> pixels;
    std::uint32_t width = 0;
    std::uint32_t height = 0;
};

/// 场景层级节点。
struct NodeData {
    std::string name;
    std::int32_t meshIndex = -1; // -1 表示纯层级节点（无网格）
    std::vector<std::int32_t> children;
    glm::mat4 localTransform{1.0f};
};

/// 一份 glb 资产的内存表示（与 fastgltf 解耦，便于 GPU 上传与测试）。
struct AssetData {
    std::vector<MeshData> meshes;
    std::vector<MaterialData> materials;
    std::vector<TextureImage> textures;
    std::vector<NodeData> nodes;
    std::vector<SkinData> skins;
    std::vector<AnimationData> animations;
    std::vector<std::int32_t> sceneRootNodes;
};

} // namespace doll::asset
