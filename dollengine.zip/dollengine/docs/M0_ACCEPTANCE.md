# M0 验收记录

> 实测时间：2026-10-26
> 环境：Windows / VS 2026 Insiders（MSVC 19.51）/ CMake 4.3.1 / Vulkan SDK 1.4.363（`D:\app\vulkan`）

## 验收项与结果

| 验收项 | 结果 | 证据 |
|---|---|---|
| CMake 预设一键构建 | ✅ | `cmake --preset msvc-x64` + `cmake --build --preset debug` 成功，生成 `dollengine.exe` |
| Catch2 + CTest 全绿 | ✅ | `100% tests passed, 0 tests failed out of 8` |
| 窗口可开关 | ✅ | 运行 4 秒保持运行，`Stop-Process` 正常退出 |
| ImGui 四面板可停靠 | ✅ | 日志：`ImGui 初始化完成（SDL3 + SDLRenderer3，docking）`、`默认停靠布局已构建（视口 / 层级 / 属性 / 资源）`、`应用初始化完成（4 个面板）` |
| 日志落盘 | ✅ | `logs/app-YYYYMMDD-HHMMSS.log`，中文正常 |
| 退出干净 | ✅ | 无崩溃、无资源泄漏告警 |

## 产物

- `build/msvc-x64/bin/Debug/dollengine.exe`
- `build/msvc-x64/bin/Debug/SDL3.dll`（vcpkg 自动复制）
- `build/msvc-x64/lib/Debug/DollCore.lib`、`DollPlatform.lib`
- `build/msvc-x64/bin/Debug/logs/app-*.log`

## 复现命令

```powershell
$bin = "C:\Program Files\Microsoft Visual Studio\18\Insiders\Common7\IDE\CommonExtensions\Microsoft\CMake\CMake\bin"
cd D:\project\test\dollengine
& "$bin\cmake.exe" --preset msvc-x64
& "$bin\cmake.exe" --build --preset debug
& "$bin\ctest.exe" --test-dir build\msvc-x64 -C Debug --output-on-failure
.\build\msvc-x64\bin\Debug\dollengine.exe
```

## 依赖版本

| 依赖 | 版本 |
|---|---|
| SDL3 | 3.4.18 |
| ImGui | 1.93.0（`docking-experimental`） |
| fastgltf | 0.9.1 |
| GLM | 1.0.3 |
| Catch2 | 3.16.1 |
| Vulkan SDK | 1.4.363（`D:\app\vulkan`，M1 使用） |
| CMake | 4.3.1 |
| MSVC | 19.51（VS 2026 Insiders） |

## 实施中解决的坑（给后续阶段）

1. **`engine/core/Assert.h` 与系统 `<assert.h>` 撞名**：Windows 大小写不敏感，导致 `<assert.h>` 的 include guard 被占、`assert` 宏缺失，ImGui 头编译失败。已重命名为 `DollAssert.h`。
2. **ImGui backend 源文件 vcpkg 不安装**：从 vcpkg buildtrees 复制 `imgui_impl_sdl3.cpp` / `imgui_impl_sdlrenderer3.cpp` 到 `third_party/imgui_backends`。
3. **Catch2 中文测试名 + CTest filter 编码不匹配**：`TEST_CASE` 名用英文，断言内容可保留中文。
4. **日志中文乱码**：`SetConsoleOutputCP(CP_UTF8)`。
5. **Windows 文件占用**：测试中 `ifstream` 析构关闭后再 `remove`。

## 已知限制

- M0 的 ImGui 走 SDL_Renderer3（临时路径），M1 换成 Vulkan backend 时删除。
- 无 Vulkan 校验层、无深度测试（M1 接入）。
- `character/animation/clothing/physics` 等模块按计划在对应里程碑创建。
