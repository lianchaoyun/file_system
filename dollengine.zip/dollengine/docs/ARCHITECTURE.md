# dollengine / Doll Engine 架构

## 分层

```
apps/dollengine        编辑器：App / ImGuiLayer / Panels
Editor Services        命令 / 选择 / Undo（M4 起）
engine/core            DollCore：Log / Result / Assert / Paths
engine/platform        DollPlatform：SDL3 窗口 / 输入
engine/renderer        DollRenderer：Vulkan / PBR / Shadow（M1 起）
engine/asset           DollAssetPipeline：GLB 导入 / 校验 / 缓存（M2 起）
engine/scene           DollScene：节点 / 层级 / 变换（M2 起）
engine/character       DollCharacter：骨架 / 蒙皮 / Morph（M3 起）
engine/animation       DollAnimation：采样 / 混合 / 关键帧（M3 起）
engine/clothing        DollClothing：装备槽位 / 隐藏区域（M6 起）
engine/physics         DollPhysics：刚体 / 动态骨骼 / 布料（M6 起）
engine/project         DollProject：项目存档 / 迁移（M7 起）
```

依赖方向（M0 即生效）：

- `apps/dollengine` → `engine/core` + `engine/platform` + ImGui
- `engine/platform` → `engine/core`，**不依赖** ImGui / Vulkan
- `engine/core` → 不依赖任何第三方（Catch2 只在测试目标里链接）
- 面板（`panels/`）只操作编辑器上下文数据，不触碰平台与渲染对象

## 每帧数据更新顺序（固定）

1. 编辑器输入与参数修改
2. 动画采样与混合
3. Morph Targets + 骨骼姿态计算
4. 物理模拟与姿态修正
5. 更新 GPU 数据并渲染

顺序可以随布料需求调整，但必须写清楚依赖，避免动画/骨骼/物理互相覆盖。

## 核心数据原则

1. `CharacterAsset` 是只读的基础资产；`CharacterInstance` 保存每个场景实例独立的姿态、Morph 权重、服装、动画与物理状态。
2. 编辑器通过命令和明确接口修改数据，UI 不直接改 GPU 资源。
3. 渲染器只读取最终渲染数据，不拥有角色业务逻辑。
4. 项目存档独立于 GLB，带版本号，可迁移。
5. 不支持的 GLB 功能必须报告，不得静默丢弃。
6. 影响绑定和资源兼容性的编辑操作必须明确提示。

## GPU 资源所有权（M1 起生效）

- 所有 Vulkan 资源由 `DollRenderer` 统一持有。
- 使用显式 `destroy()` + `vkDeviceWaitIdle`，按依赖链逆序释放（见下方参考笔记 A2）。
- 不做隐蔽的隐式析构释放。

## 参考笔记（M0 规划阶段对既有代码的审查）

> 来源：`D:\project\test\vulkan_triangle_demo`（C++ + Vulkan 三角形 demo）。
> Bevy/Rust 版 dollengine 目录在 M0 规划时已为空，C 节的资产结论来自此前对该角色 glb 的实测解析。

### A. 可直接复用的 Vulkan 流程

初始化顺序（`main.cpp:80-84`）：

```
createInstance → createSurface → pickPhysicalDevice → createDevice →
createSwapchain → createImageViews → createRenderPass → createPipeline →
createFramebuffers → createCommandPool → createCommandBuffers → createSync
```

资源释放顺序（`main.cpp:341-360`）必须遵守三条约束：

- device 级对象全部先于 `vkDestroyDevice` 销毁；
- 依赖链 `framebuffers → imageViews → swapchain`、`framebuffers → renderPass`、`pipeline → pipelineLayout/renderPass` 逆序销毁；
- surface 依赖 instance + window，顺序是 `device → surface → instance → window`。

关键默认值（需保留）：

- swapchain 格式优先 `VK_FORMAT_B8G8R8A8_SRGB`，present mode 优先 `MAILBOX` 回退 `FIFO`；
- `minImageCount + 1` 并 clamp 到 `maxImageCount`；
- graphics 与 present 队列不同族时用 `VK_SHARING_MODE_CONCURRENT`。

shader 编译约定（`CMakeLists.txt:20-33`）：

- `SHADER_DIR` 宏指向 `${CMAKE_CURRENT_BINARY_DIR}/shaders`，glslc 输出到同一目录；
- 未来 shader 增多时，把 `add_custom_command(TARGET ... PRE_BUILD)` 改成 `OUTPUT + add_custom_target(shaders ALL)`，实现时间戳增量。

### B. 必须改写：GLFW → SDL3

| 位置 | 原（GLFW） | 新（SDL3） |
|---|---|---|
| 初始化 | `glfwInit` + `GLFW_NO_API` | `SDL_Init(SDL_INIT_VIDEO)` + `SDL_WINDOW_VULKAN` |
| 实例扩展 | `glfwGetRequiredInstanceExtensions` | `SDL_Vulkan_GetInstanceExtensions`（必须在 `SDL_CreateWindow` 之后调用） |
| surface | `glfwCreateWindowSurface(instance, window, ...)` | `SDL_Vulkan_CreateSurface(window, instance, ...)`（**参数顺序反了，返回 bool**） |
| 像素尺寸 | `glfwGetFramebufferSize` | `SDL_GetWindowSizeInPixels`（不能用逻辑尺寸版本） |
| 主循环 | `glfwWindowShouldClose` | 自己维护 `running`，监听 `SDL_EVENT_QUIT` |
| 重建触发 | — | `SDL_EVENT_WINDOW_PIXEL_SIZE_CHANGED`（像素尺寸事件） |
| 清理 | `glfwDestroyWindow` + `glfwTerminate` | `SDL_DestroyWindow` + `SDL_Quit` |
| CMake | GLFW 预编译静态库 | `find_package(SDL3 CONFIG REQUIRED)` + `SDL3::SDL3` |

### C. M2/M3 可沿用的资产约定

- 角色元数据 `character.ron` 字段：`schema_version` / `id` / `name` / `model` / `animation` / `scale`（手写），以及扫描器回填的 `dir` / `animations` / `bones`。
- glb 资产命名：`#Scene0`（场景）、`#AnimationN`（第 N 个动画）。
- 动画名格式：`骨架|动作|图层` 三段式，显示名取第二段（如 `xianwu_an01`）。
- 骨骼树：`skin.joints` 给出 joint 列表，`nodes[].children` 反推父子关系；`parent` 存的是 **joint 数组里的位置索引**（不是 node 索引）。
- 材质：典型角色 glb 有 7 个材质槽（`Fingernails` / `Toenails` / `Legs` / `Mouth Cavity` / `Arms` / `Head` / `Body`），服装烘焙在 `Body` 材质里，没有独立服装网格。
- **M2 必须修正的默认值**：demo 管线用 `VK_FRONT_FACE_CLOCKWISE`，而 glTF 规范是 **CCW 为正面**；导入 GLB 时改成 `VK_FRONT_FACE_COUNTER_CLOCKWISE`，否则模型内外翻转。
