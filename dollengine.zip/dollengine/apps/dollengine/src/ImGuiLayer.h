#pragma once

#include "Result.h"

#include <cstdint>

struct SDL_Window;
union SDL_Event; // SDL3 里 SDL_Event 是 union，不是 struct
struct VkInstance_T;
struct VkPhysicalDevice_T;
struct VkDevice_T;
struct VkQueue_T;
struct VkRenderPass_T;
struct VkCommandBuffer_T;
struct VkImageView_T;
struct VkDescriptorSet_T;

namespace doll::ui {

/// ImGui 上下文与后端的唯一封装点（SDL3 + Vulkan）。
///
/// 只负责 ImGui 的创建/销毁、事件转发、帧推进与把 draw data 画进给定的
/// 命令缓冲。真正的 Vulkan 渲染循环由 renderer 层负责，这里不碰交换链。
class ImGuiLayer {
public:
    /// 初始化 ImGui Vulkan backend 所需的上下文句柄（由 App 从 renderer 层取出传入）。
    struct VulkanInitInfo {
        VkInstance_T* instance = nullptr;
        VkPhysicalDevice_T* physicalDevice = nullptr;
        VkDevice_T* device = nullptr;
        std::uint32_t queueFamily = 0;
        VkQueue_T* queue = nullptr;
        VkRenderPass_T* renderPass = nullptr;
        std::uint32_t imageCount = 0;
    };

    ImGuiLayer() = default;
    ~ImGuiLayer();

    ImGuiLayer(const ImGuiLayer&) = delete;
    ImGuiLayer& operator=(const ImGuiLayer&) = delete;

    Status init(SDL_Window* window, const VulkanInitInfo& info);
    void shutdown();

    /// 把 SDL 事件交给 ImGui。必须在窗口事件轮询时对每个事件调用。
    static void processEvent(const SDL_Event* event);

    /// 开始一帧（NewFrame）。
    void beginFrame();

    /// 结束 UI 录制，生成 draw data。
    void render();

    /// 把 draw data 画进指定命令缓冲。必须在 render pass 内、`render()` 之后调用。
    void renderDrawData(VkCommandBuffer_T* commandBuffer);

    /// 把 Vulkan 图像视图注册为 ImGui 纹理（shader 只读布局），返回描述符。
    /// 用于把离屏场景图像显示进视口面板。
    [[nodiscard]] VkDescriptorSet_T* addTexture(VkImageView_T* imageView);
    void removeTexture(VkDescriptorSet_T* descriptorSet);

    [[nodiscard]] bool wantCaptureMouse() const;

private:
    bool initialized_ = false;
};

} // namespace doll::ui
