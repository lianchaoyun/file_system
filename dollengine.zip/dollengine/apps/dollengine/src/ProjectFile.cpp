#include "ProjectFile.h"

#include "Log.h"

#include <nlohmann/json.hpp>

#include <format>
#include <fstream>

namespace doll::editor {

namespace {

using json = nlohmann::json;

json vec3ToJson(const glm::vec3& v) {
    return json::array({v.x, v.y, v.z});
}

glm::vec3 vec3FromJson(const json& j) {
    return glm::vec3(j.at(0).get<float>(), j.at(1).get<float>(), j.at(2).get<float>());
}

const char* interpolationToString(asset::AnimationInterpolation interpolation) {
    switch (interpolation) {
        case asset::AnimationInterpolation::Step:
            return "STEP";
        case asset::AnimationInterpolation::CubicSpline:
            return "CUBICSPLINE";
        default:
            return "LINEAR";
    }
}

asset::AnimationInterpolation interpolationFromString(const std::string& text) {
    if (text == "STEP") {
        return asset::AnimationInterpolation::Step;
    }
    if (text == "CUBICSPLINE") {
        return asset::AnimationInterpolation::CubicSpline;
    }
    return asset::AnimationInterpolation::Linear;
}

} // namespace

Status saveProject(const std::filesystem::path& path, const ProjectData& data) {
    json root;
    root["version"] = 1;
    root["model"] = data.modelPath;
    root["objectTransform"] = {
        {"position", vec3ToJson(data.position)},
        {"rotation", vec3ToJson(data.rotation)},
        {"scale", vec3ToJson(data.scale)},
    };

    json joints = json::object();
    for (const auto& [nodeIndex, rotation] : data.jointRotations) {
        joints[std::to_string(nodeIndex)] = vec3ToJson(rotation);
    }
    root["jointRotations"] = joints;

    root["morphWeights"] = json::array({data.morphWeights[0], data.morphWeights[1],
                                        data.morphWeights[2], data.morphWeights[3]});

    json edits = json::array();
    for (const auto& edit : data.samplerEdits) {
        json item;
        item["index"] = edit.index;
        item["interpolation"] = interpolationToString(edit.interpolation);
        item["times"] = edit.times;
        if (!edit.rotations.empty()) {
            json rotations = json::array();
            for (const auto& r : edit.rotations) {
                rotations.push_back(json::array({r.x, r.y, r.z, r.w}));
            }
            item["rotations"] = rotations;
        }
        if (!edit.translations.empty()) {
            json translations = json::array();
            for (const auto& t : edit.translations) {
                translations.push_back(vec3ToJson(t));
            }
            item["translations"] = translations;
        }
        if (!edit.scales.empty()) {
            json scales = json::array();
            for (const auto& s : edit.scales) {
                scales.push_back(vec3ToJson(s));
            }
            item["scales"] = scales;
        }
        edits.push_back(std::move(item));
    }
    root["samplerEdits"] = edits;

    std::ofstream file(path);
    if (!file.is_open()) {
        return Status::fail(ErrorCode::Io, std::format("无法写入项目文件：{}", path.string()));
    }
    file << root.dump(2);
    DOLL_LOG_INFO("project", "项目已保存：{}（{} 个采样器编辑）", path.string(),
                  data.samplerEdits.size());
    return Status::success();
}

Result<ProjectData> loadProject(const std::filesystem::path& path) {
    std::ifstream file(path);
    if (!file.is_open()) {
        return Result<ProjectData>::fail(ErrorCode::Io,
                                         std::format("无法读取项目文件：{}", path.string()));
    }

    json root;
    try {
        file >> root;
    } catch (const std::exception& error) {
        return Result<ProjectData>::fail(ErrorCode::Parse,
                                         std::format("解析项目文件失败：{}", error.what()));
    }

    ProjectData data;
    data.modelPath = root.value("model", "");

    if (root.contains("objectTransform")) {
        const auto& transform = root["objectTransform"];
        if (transform.contains("position")) {
            data.position = vec3FromJson(transform["position"]);
        }
        if (transform.contains("rotation")) {
            data.rotation = vec3FromJson(transform["rotation"]);
        }
        if (transform.contains("scale")) {
            data.scale = vec3FromJson(transform["scale"]);
        }
    }

    if (root.contains("jointRotations")) {
        for (const auto& [key, value] : root["jointRotations"].items()) {
            try {
                data.jointRotations[std::stoi(key)] = vec3FromJson(value);
            } catch (const std::exception&) {
                // 脏数据跳过。
            }
        }
    }

    if (root.contains("morphWeights")) {
        const auto& weights = root["morphWeights"];
        const std::size_t count = std::min<std::size_t>(weights.size(), data.morphWeights.size());
        for (std::size_t i = 0; i < count; ++i) {
            data.morphWeights[i] = weights[i].get<float>();
        }
    }

    if (root.contains("samplerEdits")) {
        for (const auto& item : root["samplerEdits"]) {
            ProjectData::SamplerEdit edit;
            edit.index = item.value("index", -1);
            edit.interpolation = interpolationFromString(item.value("interpolation", "LINEAR"));
            if (item.contains("times")) {
                edit.times = item["times"].get<std::vector<float>>();
            }
            if (item.contains("rotations")) {
                for (const auto& r : item["rotations"]) {
                    edit.rotations.emplace_back(r.at(0).get<float>(), r.at(1).get<float>(),
                                                r.at(2).get<float>(), r.at(3).get<float>());
                }
            }
            if (item.contains("translations")) {
                for (const auto& t : item["translations"]) {
                    edit.translations.push_back(vec3FromJson(t));
                }
            }
            if (item.contains("scales")) {
                for (const auto& s : item["scales"]) {
                    edit.scales.push_back(vec3FromJson(s));
                }
            }
            data.samplerEdits.push_back(std::move(edit));
        }
    }

    DOLL_LOG_INFO("project", "项目已加载：{}（{} 个采样器编辑）", path.string(),
                  data.samplerEdits.size());
    return Result<ProjectData>::success(std::move(data));
}

} // namespace doll::editor
