#include "ImGuiLayer.h"

#include <SDL3/SDL.h>
#include <imgui.h>
#include <imgui_impl_sdl3.h>
#include <imgui_impl_vulkan.h>

#include <vulkan/vulkan.h>

#include <string>

#include "Log.h"
#include "Paths.h"

namespace doll::ui {

ImGuiLayer::~ImGuiLayer() {
    shutdown();
}

Status ImGuiLayer::init(SDL_Window* window, const VulkanInitInfo& info) {
    if (window == nullptr || info.instance == nullptr || info.device == nullptr ||
        info.physicalDevice == nullptr || info.queue == nullptr || info.renderPass == nullptr) {
        return Status::fail(ErrorCode::InvalidArgument, "ImGuiLayer::init: 参数不完整");
    }

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();

    ImGuiIO& io = ImGui::GetIO();
    io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;
    io.ConfigFlags |= ImGuiConfigFlags_DockingEnable;

    // 布局持久化文件放到 exe 旁，避免依赖启动时的工作目录。
    static const std::string iniPath = (doll::paths::executableDir() / "imgui.ini").string();
    io.IniFilename = iniPath.c_str();
    ImGui::LoadIniSettingsFromDisk(iniPath.c_str());

    ImGui::StyleColorsDark();

    // 高 DPI：按窗口显示比例缩放 UI。
    const float scale = SDL_GetWindowDisplayScale(window);
    if (scale > 0.0f) {
        ImGui::GetStyle().ScaleAllSizes(scale);
    }

    // 加载中文字体：ImGui 内置字体只有 ASCII，中文会显示成 ?。
    const float fontSize = 16.0f * (scale > 0.0f ? scale : 1.0f);
    ImFontConfig fontConfig;
    fontConfig.OversampleH = 2;
    fontConfig.OversampleV = 2;
    const char* const fontCandidates[] = {
        "C:/Windows/Fonts/msyh.ttc",
        "C:/Windows/Fonts/msyh.ttf",
        "C:/Windows/Fonts/simhei.ttf",
        "C:/Windows/Fonts/simsun.ttc",
    };
    bool fontLoaded = false;
    for (const char* path : fontCandidates) {
        if (io.Fonts->AddFontFromFileTTF(path, fontSize, &fontConfig,
                                          io.Fonts->GetGlyphRangesChineseSimplifiedCommon()) != nullptr) {
            fontLoaded = true;
            DOLL_LOG_INFO("ui", "已加载中文字体：{}", path);
            break;
        }
    }
    if (!fontLoaded) {
        DOLL_LOG_WARN("ui", "未找到中文字体，界面中文会显示为 ?");
    }

    // 平台后端（SDL3）+ 渲染后端（Vulkan）。
    if (!ImGui_ImplSDL3_InitForVulkan(window)) {
        ImGui::DestroyContext();
        return Status::fail(ErrorCode::Graphics, "ImGui_ImplSDL3_InitForVulkan 失败");
    }

    ImGui_ImplVulkan_InitInfo vulkanInfo{};
    vulkanInfo.ApiVersion = VK_API_VERSION_1_3;
    vulkanInfo.Instance = info.instance;
    vulkanInfo.PhysicalDevice = info.physicalDevice;
    vulkanInfo.Device = info.device;
    vulkanInfo.QueueFamily = info.queueFamily;
    vulkanInfo.Queue = info.queue;
    vulkanInfo.DescriptorPoolSize = 8; // 让 backend 自动建 descriptor pool
    vulkanInfo.MinImageCount = 2;
    vulkanInfo.ImageCount = info.imageCount;
    vulkanInfo.PipelineInfoMain.RenderPass = info.renderPass;
    vulkanInfo.PipelineInfoMain.Subpass = 0;
    vulkanInfo.PipelineInfoMain.MSAASamples = VK_SAMPLE_COUNT_1_BIT;

    if (!ImGui_ImplVulkan_Init(&vulkanInfo)) {
        ImGui_ImplSDL3_Shutdown();
        ImGui::DestroyContext();
        return Status::fail(ErrorCode::Graphics, "ImGui_ImplVulkan_Init 失败");
    }

    initialized_ = true;
    DOLL_LOG_INFO("ui", "ImGui 初始化完成（SDL3 + Vulkan，docking）");
    return Status::success();
}

void ImGuiLayer::processEvent(const SDL_Event* event) {
    ImGui_ImplSDL3_ProcessEvent(event);
}

void ImGuiLayer::shutdown() {
    if (!initialized_) {
        return;
    }
    ImGui_ImplVulkan_Shutdown();
    ImGui_ImplSDL3_Shutdown();
    ImGui::DestroyContext();
    initialized_ = false;
}

void ImGuiLayer::beginFrame() {
    ImGui_ImplVulkan_NewFrame();
    ImGui_ImplSDL3_NewFrame();
    ImGui::NewFrame();
}

void ImGuiLayer::render() {
    ImGui::Render();
}

void ImGuiLayer::renderDrawData(VkCommandBuffer_T* commandBuffer) {
    ImGui_ImplVulkan_RenderDrawData(ImGui::GetDrawData(), commandBuffer);
}

VkDescriptorSet_T* ImGuiLayer::addTexture(VkImageView_T* imageView) {
    if (imageView == VK_NULL_HANDLE) {
        return VK_NULL_HANDLE;
    }
    // 场景图像在渲染通道结束时就已转到 shader 只读布局。
    return ImGui_ImplVulkan_AddTexture(imageView, VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL);
}

void ImGuiLayer::removeTexture(VkDescriptorSet_T* descriptorSet) {
    if (descriptorSet != VK_NULL_HANDLE) {
        ImGui_ImplVulkan_RemoveTexture(descriptorSet);
    }
}

bool ImGuiLayer::wantCaptureMouse() const {
    return ImGui::GetIO().WantCaptureMouse;
}

} // namespace doll::ui
