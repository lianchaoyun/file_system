#pragma once

#include <array>
#include <cstdint>
#include <filesystem>
#include <string>
#include <unordered_map>
#include <vector>

#include <glm/glm.hpp>

#include "AssetData.h"
#include "Result.h"

namespace doll::editor {

/// 项目文件（*.dollproj）：保存编辑状态。模型本体从 modelPath 重新加载，
/// 文件里只存「编辑增量」（变换 / 姿态 / 形变权重 / 被改过的动画采样器）。
struct ProjectData {
    std::string modelPath;

    // 对象变换
    glm::vec3 position{0.0f};
    glm::vec3 rotation{0.0f};
    glm::vec3 scale{1.0f};

    // 姿态（关节旋转覆盖）
    std::unordered_map<std::int32_t, glm::vec3> jointRotations;

    // 形变权重
    std::array<float, 4> morphWeights{0.0f, 0.0f, 0.0f, 0.0f};

    /// 被编辑过的动画采样器快照（只存改过的，避免项目文件膨胀）。
    struct SamplerEdit {
        std::int32_t index = -1;
        asset::AnimationInterpolation interpolation = asset::AnimationInterpolation::Linear;
        std::vector<float> times;
        std::vector<glm::vec4> rotations;
        std::vector<glm::vec3> translations;
        std::vector<glm::vec3> scales;
    };
    std::vector<SamplerEdit> samplerEdits;
};

/// 保存项目到 JSON 文件。
Status saveProject(const std::filesystem::path& path, const ProjectData& data);

/// 从 JSON 文件加载项目。
Result<ProjectData> loadProject(const std::filesystem::path& path);

} // namespace doll::editor
