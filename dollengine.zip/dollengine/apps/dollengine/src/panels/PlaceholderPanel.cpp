#include "IPanel.h"

#include <algorithm>
#include <cstdint>
#include <memory>

#include <imgui.h>
#include <ImGuizmo.h>

#include <glm/gtc/type_ptr.hpp>
#define GLM_ENABLE_EXPERIMENTAL
#include <glm/gtx/matrix_decompose.hpp>

#include "EditorContext.h"
#include "Skeleton.h"

namespace doll::editor {
namespace {

/// 从节点 localTransform 分解欧拉角旋转（度，XYZ）。
glm::vec3 nodeEulerRotation(const doll::asset::NodeData& node) {
    glm::vec3 scale(1.0f);
    glm::vec3 translation(0.0f);
    glm::vec3 skew(0.0f);
    glm::vec4 perspective(0.0f);
    glm::quat rotation(1.0f, 0.0f, 0.0f, 0.0f);
    glm::decompose(node.localTransform, scale, rotation, translation, skew, perspective);
    return glm::degrees(glm::eulerAngles(rotation));
}

class ViewportPanel final : public IPanel {
public:
    const char* name() const override { return "视口"; }

    void draw(EditorContext& context) override {
        // 把内容区尺寸报给 App（用于对齐离屏渲染目标）。
        const ImVec2 size = ImGui::GetContentRegionAvail();
        context.viewportWidth = static_cast<int>(size.x);
        context.viewportHeight = static_cast<int>(size.y);

        if (context.viewportTexture == 0 || size.x <= 0.0f || size.y <= 0.0f) {
            ImGui::TextDisabled("（视口尚未就绪）");
            return;
        }
        ImGui::Image(context.viewportTexture, size);

        // 变换 gizmo（选中对象时显示）。
        bool gizmoActive = false;
        if (context.selectedObject != "（未选择）") {
            const float aspect = size.x / size.y;
            const glm::mat4 view = context.camera.view();
            // ImGuizmo 按 OpenGL 惯例算屏幕位置，必须用未翻转 Y 的投影矩阵，
            // 否则 gizmo 会上下颠倒（脚底的原点被画到头顶）。
            const glm::mat4 proj = context.camera.projForGizmo(aspect);
            // gizmo 画在角色中心（pivot），而不是模型原点（glTF 角色原点通常在脚底）。
            glm::mat4 model = glm::translate(glm::mat4(1.0f), context.objectPivot) *
                              context.objectTransform.toMatrix();

            ImGuizmo::SetOrthographic(false);
            ImGuizmo::BeginFrame();
            const ImVec2 imagePos = ImGui::GetItemRectMin();
            ImGuizmo::SetRect(imagePos.x, imagePos.y, size.x, size.y);
            ImGuizmo::SetDrawlist();

            ImGuizmo::OPERATION op = ImGuizmo::TRANSLATE;
            if (context.gizmoMode == EditorContext::GizmoMode::Rotate) {
                op = ImGuizmo::ROTATE;
            } else if (context.gizmoMode == EditorContext::GizmoMode::Scale) {
                op = ImGuizmo::SCALE;
            }

            const bool changed = ImGuizmo::Manipulate(
                glm::value_ptr(view), glm::value_ptr(proj), op, ImGuizmo::LOCAL,
                glm::value_ptr(model));

            // 拖动开始记旧值、结束提交命令（可撤销/重做）。
            const bool usingGizmo = ImGuizmo::IsUsing();
            if (usingGizmo && !gizmoWasUsing_) {
                gizmoOldTransform_ = context.objectTransform;
            }
            if (changed) {
                glm::vec3 scale(1.0f);
                glm::vec3 translation(0.0f);
                glm::vec3 skew(0.0f);
                glm::vec4 perspective(0.0f);
                glm::quat rotation(1.0f, 0.0f, 0.0f, 0.0f);
                glm::decompose(model, scale, rotation, translation, skew, perspective);
                // gizmo 世界位置 = pivot + 对象偏移，所以要去掉 pivot 才是对象位移。
                context.objectTransform.position = translation - context.objectPivot;
                context.objectTransform.rotation = glm::degrees(glm::eulerAngles(rotation));
                context.objectTransform.scale = scale;
            }
            if (!usingGizmo && gizmoWasUsing_) {
                context.commandHistory.doCommand(std::make_unique<doll::SetValueCommand<Transform>>(
                    "变换", gizmoOldTransform_, context.objectTransform,
                    [&context](const Transform& t) { context.objectTransform = t; }));
            }
            gizmoWasUsing_ = usingGizmo;
            gizmoActive = usingGizmo;
        } else {
            gizmoWasUsing_ = false;
        }

        // 相机交互：仅当鼠标悬停在视口画面内、且不在操作 gizmo 时响应。
        if (ImGui::IsItemHovered() && !gizmoActive) {
            ImGuiIO& io = ImGui::GetIO();
            if (ImGui::IsMouseDragging(ImGuiMouseButton_Left)) {
                constexpr float sensitivity = 0.3f;
                // 操纵杆式：向右拖 → 物体向左转（相机绕物体转的方向跟手走）。
                context.camera.orbit(io.MouseDelta.x * sensitivity,
                                     -io.MouseDelta.y * sensitivity);
            }
            if (ImGui::IsMouseDragging(ImGuiMouseButton_Middle)) {
                // 中键拖拽 = 平移场景。
                context.camera.pan(io.MouseDelta.x, io.MouseDelta.y);
            }
            if (io.MouseWheel != 0.0f) {
                context.camera.zoom(io.MouseWheel * 0.5f);
            }
        }
    }

private:
    bool gizmoWasUsing_ = false;
    Transform gizmoOldTransform_;
};

class HierarchyPanel final : public IPanel {
public:
    const char* name() const override { return "层级"; }

    void draw(EditorContext& context) override {
        if (context.sceneNodes.empty()) {
            ImGui::TextUnformatted("（未加载场景）");
            return;
        }
        for (const std::int32_t root : context.sceneRootNodes) {
            drawNode(context, root);
        }
    }

private:

    void drawNode(EditorContext& context, std::int32_t nodeIndex) {
        const auto& node = context.sceneNodes[static_cast<std::size_t>(nodeIndex)];
        const char* label = node.name.empty() ? "（未命名）" : node.name.c_str();

        ImGuiTreeNodeFlags flags =
            ImGuiTreeNodeFlags_OpenOnArrow | ImGuiTreeNodeFlags_OpenOnDoubleClick;
        if (node.children.empty()) {
            flags |= ImGuiTreeNodeFlags_Leaf;
        }

        // 用节点索引作为 ImGui ID，避免重名节点冲突。
        const bool open = ImGui::TreeNodeEx(reinterpret_cast<void*>(static_cast<intptr_t>(nodeIndex)),
                                            flags, "%s", label);
        if (ImGui::IsItemClicked()) {
            context.selectedObject = node.name;
            context.selectedNodeIndex = nodeIndex;
        }
        if (open) {
            for (const std::int32_t child : node.children) {
                drawNode(context, child);
            }
            ImGui::TreePop();
        }
    }
};

/// 动画面板：播放控制 + 姿态预设（M5 时间轴/关键帧编辑会加在这里）。
class AnimationPanel final : public IPanel {
public:
    const char* name() const override { return "动画"; }

    void draw(EditorContext& context) override {
        // 播放控制。
        if (ImGui::Button(context.animationPlaying ? "暂停" : "播放")) {
            context.animationPlaying = !context.animationPlaying;
        }
        ImGui::SameLine();
        ImGui::Text("%.2fs", context.animationTime);
        ImGui::SameLine();
        if (context.animationName.empty()) {
            ImGui::TextDisabled("（模型无动画）");
        } else if (context.animationPlayable) {
            ImGui::Text("%s", context.animationName.c_str());
        } else {
            ImGui::TextDisabled("%s（无骨骼关键帧）", context.animationName.c_str());
        }
        ImGui::Separator();

        // 骨骼选择器：列出有 rotation 动画通道的骨骼，并自动默认选中第一根，
        // 否则时间轴上的关键帧没有目标、永远是空的。
        if (!context.animations.empty() && !context.sceneNodes.empty()) {
            const auto& anim = context.animations[0];
            std::vector<std::int32_t> animatedBones;
            for (const auto& channel : anim.channels) {
                if (channel.path != asset::AnimationPath::Rotation || channel.nodeIndex < 0) {
                    continue;
                }
                if (std::find(animatedBones.begin(), animatedBones.end(), channel.nodeIndex) ==
                    animatedBones.end()) {
                    animatedBones.push_back(channel.nodeIndex);
                }
            }
            if (!animatedBones.empty()) {
                if (std::find(animatedBones.begin(), animatedBones.end(),
                              context.selectedNodeIndex) == animatedBones.end()) {
                    context.selectedNodeIndex = animatedBones.front();
                }
                int currentIndex = 0;
                for (int i = 0; i < static_cast<int>(animatedBones.size()); ++i) {
                    if (animatedBones[static_cast<std::size_t>(i)] == context.selectedNodeIndex) {
                        currentIndex = i;
                        break;
                    }
                }
                const auto& selectedNode =
                    context.sceneNodes[static_cast<std::size_t>(context.selectedNodeIndex)];
                ImGui::SetNextItemWidth(200.0f);
                if (ImGui::BeginCombo("##bone", selectedNode.name.c_str())) {
                    for (int i = 0; i < static_cast<int>(animatedBones.size()); ++i) {
                        const auto& node = context.sceneNodes[static_cast<std::size_t>(
                            animatedBones[static_cast<std::size_t>(i)])];
                        const bool isSelected = (i == currentIndex);
                        if (ImGui::Selectable(node.name.c_str(), isSelected)) {
                            context.selectedNodeIndex = animatedBones[static_cast<std::size_t>(i)];
                        }
                        if (isSelected) {
                            ImGui::SetItemDefaultFocus();
                        }
                    }
                    ImGui::EndCombo();
                }
                ImGui::SameLine();
                ImGui::TextDisabled("骨骼（%zu 根有动画，绿条是关键帧）", animatedBones.size());
            }
        }

        // 当前选中骨骼的 rotation 动画通道（关键帧显示/编辑的目标）。
        asset::AnimationSamplerData* activeSampler = nullptr;
        std::int32_t activeSamplerIndex = -1;
        if (context.selectedNodeIndex >= 0 && !context.animations.empty()) {
            auto& anim = context.animations[0];
            for (const auto& channel : anim.channels) {
                if (channel.nodeIndex != context.selectedNodeIndex ||
                    channel.path != asset::AnimationPath::Rotation) {
                    continue;
                }
                if (channel.samplerIndex >= 0 &&
                    static_cast<std::size_t>(channel.samplerIndex) < anim.samplers.size()) {
                    activeSamplerIndex = channel.samplerIndex;
                    activeSampler =
                        &anim.samplers[static_cast<std::size_t>(channel.samplerIndex)];
                }
                break;
            }
        }

        // 时间轴 scrub：拖播放头，角色摆到对应姿势（拖动时自动暂停）。
        if (context.animationDuration > 0.0f) {
            const float width = ImGui::GetContentRegionAvail().x;
            const ImVec2 size(std::max(width, 1.0f), 20.0f);
            ImGui::InvisibleButton("##timeline", size);
            const ImVec2 p0 = ImGui::GetItemRectMin();
            const ImVec2 p1 = ImGui::GetItemRectMax();

            ImDrawList* dl = ImGui::GetWindowDrawList();
            dl->AddRectFilled(p0, p1, IM_COL32(32, 32, 38, 255), 3.0f);

            const float ratio =
                glm::clamp(context.animationTime / context.animationDuration, 0.0f, 1.0f);
            const float x = p0.x + (p1.x - p0.x) * ratio;
            dl->AddRectFilled(p0, ImVec2(x, p1.y), IM_COL32(58, 104, 168, 255), 3.0f);

            // 关键帧标记（绿色竖条）。
            if (activeSampler != nullptr) {
                for (const float keyTime : activeSampler->times) {
                    const float kr =
                        glm::clamp(keyTime / context.animationDuration, 0.0f, 1.0f);
                    const float kx = p0.x + (p1.x - p0.x) * kr;
                    dl->AddRectFilled(ImVec2(kx - 2.5f, p0.y + 3.0f),
                                      ImVec2(kx + 2.5f, p1.y - 3.0f),
                                      IM_COL32(120, 200, 120, 255), 1.0f);
                }
            }

            dl->AddLine(ImVec2(x, p0.y), ImVec2(x, p1.y), IM_COL32(255, 190, 70, 255), 2.0f);

            if (ImGui::IsItemActive()) {
                const float mx = ImGui::GetIO().MousePos.x;
                const float r = glm::clamp((mx - p0.x) / (p1.x - p0.x), 0.0f, 1.0f);
                context.animationTime = r * context.animationDuration;
                context.animationPlaying = false;
            }
            ImGui::TextDisabled("%.2fs / %.2fs", context.animationTime, context.animationDuration);

            // 关键帧增删（针对选中骨骼的 rotation 通道，可撤销）。
            if (activeSampler != nullptr) {
                ImGui::Text("关键帧：%zu 个", activeSampler->times.size());
                const int32_t samplerIndex = activeSamplerIndex;
                const auto applySampler = [&context, samplerIndex](
                                              const asset::AnimationSamplerData& value) {
                    if (!context.animations.empty() && samplerIndex >= 0 &&
                        static_cast<std::size_t>(samplerIndex) <
                            context.animations[0].samplers.size()) {
                        context.animations[0].samplers[static_cast<std::size_t>(samplerIndex)] =
                            value;
                        // 标记为已编辑，项目文件只保存这些采样器。
                        context.markSamplerDirty(samplerIndex);
                    }
                };

                if (ImGui::Button("添加关键帧")) {
                    auto newSampler = *activeSampler;
                    doll::animation::insertKeyframe(newSampler, context.animationTime,
                                                    asset::AnimationPath::Rotation);
                    context.commandHistory.doCommand(
                        std::make_unique<doll::SetValueCommand<asset::AnimationSamplerData>>(
                            "添加关键帧", *activeSampler, newSampler, applySampler));
                }
                ImGui::SameLine();
                if (ImGui::Button("删除最近关键帧")) {
                    auto newSampler = *activeSampler;
                    if (doll::animation::removeNearestKeyframe(newSampler,
                                                               context.animationTime)) {
                        context.commandHistory.doCommand(
                            std::make_unique<doll::SetValueCommand<asset::AnimationSamplerData>>(
                                "删除关键帧", *activeSampler, newSampler, applySampler));
                    }
                }

                // 插值模式（LINEAR 平滑过渡 / STEP 阶跃跳变）。
                const char* interpolationNames[] = {"LINEAR", "STEP"};
                int currentInterpolation =
                    (activeSampler->interpolation == asset::AnimationInterpolation::Step) ? 1 : 0;
                ImGui::SetNextItemWidth(120.0f);
                if (ImGui::Combo("##interpolation", &currentInterpolation, interpolationNames, 2)) {
                    auto newSampler = *activeSampler;
                    newSampler.interpolation = (currentInterpolation == 1)
                                                   ? asset::AnimationInterpolation::Step
                                                   : asset::AnimationInterpolation::Linear;
                    context.commandHistory.doCommand(
                        std::make_unique<doll::SetValueCommand<asset::AnimationSamplerData>>(
                            "插值模式", *activeSampler, newSampler, applySampler));
                }
                ImGui::SameLine();
                ImGui::TextDisabled("插值");
            } else if (context.selectedNodeIndex >= 0) {
                ImGui::TextDisabled("（选中骨骼没有 rotation 动画通道）");
            } else {
                ImGui::TextDisabled("（在层级树选中骨骼后可编辑关键帧）");
            }
        } else if (!context.animationName.empty()) {
            ImGui::TextDisabled("（该动画无时长，无法 scrub）");
        }

        ImGui::Separator();

        // 姿态预设（M4）：保存/恢复关节旋转覆盖。
        if (ImGui::CollapsingHeader("姿态预设", ImGuiTreeNodeFlags_DefaultOpen)) {
            ImGui::InputTextWithHint("##presetname", "预设名称", presetNameBuf_,
                                     sizeof(presetNameBuf_));
            ImGui::SameLine();
            if (ImGui::Button("保存预设") && presetNameBuf_[0] != '\0') {
                EditorContext::PosePreset preset;
                preset.name = presetNameBuf_;
                preset.jointRotations = context.jointRotations;
                context.posePresets.push_back(std::move(preset));
                presetNameBuf_[0] = '\0';
            }
            for (std::size_t i = 0; i < context.posePresets.size(); ++i) {
                if (ImGui::Selectable(context.posePresets[i].name.c_str())) {
                    context.jointRotations = context.posePresets[i].jointRotations;
                }
            }
            if (context.posePresets.empty()) {
                ImGui::TextDisabled("（无预设。摆好姿态后命名保存）");
            }
        }
    }

private:
    char presetNameBuf_[64] = {};
};

class InspectorPanel final : public IPanel {
public:
    const char* name() const override { return "属性"; }

    void draw(EditorContext& context) override {
        ImGui::Text("选中：%s", context.selectedObject.c_str());
        ImGui::Separator();

        if (context.selectedObject == "（未选择）") {
            ImGui::TextDisabled("（未选中对象，从层级树或内容面板选择）");
            return;
        }

        // 关节旋转编辑（选中骨骼节点时，M4 姿态编辑）。
        if (context.selectedNodeIndex >= 0 &&
            static_cast<std::size_t>(context.selectedNodeIndex) < context.sceneNodes.size()) {
            const std::int32_t nodeIdx = context.selectedNodeIndex;
            glm::vec3 rotation = nodeEulerRotation(context.sceneNodes[static_cast<std::size_t>(nodeIdx)]);
            if (const auto it = context.jointRotations.find(nodeIdx); it != context.jointRotations.end()) {
                rotation = it->second;
            }

            ImGui::TextUnformatted("关节旋转（度）");
            ImGui::DragFloat3("##jointrot", &rotation.x, 1.0f);
            if (ImGui::IsItemActivated()) {
                editOldJointRotation_ = rotation;
            }
            // 实时更新覆盖，视口里的姿态跟着变。
            context.jointRotations[nodeIdx] = rotation;
            if (ImGui::IsItemDeactivatedAfterEdit()) {
                context.commandHistory.doCommand(std::make_unique<doll::SetValueCommand<glm::vec3>>(
                    "关节旋转", editOldJointRotation_, rotation,
                    [&context, nodeIdx](const glm::vec3& v) {
                        context.jointRotations[nodeIdx] = v;
                    }));
            }
            ImGui::Separator();
        }

        // 变换编辑：编辑开始时记旧值，结束时提交命令（可撤销/重做）。
        ImGui::TextUnformatted("变换");
        ImGui::Separator();

        ImGui::TextUnformatted("位置");
        ImGui::DragFloat3("##position", &context.objectTransform.position.x, 0.01f);
        if (ImGui::IsItemActivated()) {
            editOldPosition_ = context.objectTransform.position;
        }
        if (ImGui::IsItemDeactivatedAfterEdit()) {
            context.commandHistory.doCommand(std::make_unique<doll::SetValueCommand<glm::vec3>>(
                "移动", editOldPosition_, context.objectTransform.position,
                [&context](const glm::vec3& v) { context.objectTransform.position = v; }));
        }

        ImGui::TextUnformatted("旋转（度）");
        ImGui::DragFloat3("##rotation", &context.objectTransform.rotation.x, 1.0f);
        if (ImGui::IsItemActivated()) {
            editOldRotation_ = context.objectTransform.rotation;
        }
        if (ImGui::IsItemDeactivatedAfterEdit()) {
            context.commandHistory.doCommand(std::make_unique<doll::SetValueCommand<glm::vec3>>(
                "旋转", editOldRotation_, context.objectTransform.rotation,
                [&context](const glm::vec3& v) { context.objectTransform.rotation = v; }));
        }

        ImGui::TextUnformatted("缩放");
        ImGui::DragFloat3("##scale", &context.objectTransform.scale.x, 0.01f);
        if (ImGui::IsItemActivated()) {
            editOldScale_ = context.objectTransform.scale;
        }
        if (ImGui::IsItemDeactivatedAfterEdit()) {
            context.commandHistory.doCommand(std::make_unique<doll::SetValueCommand<glm::vec3>>(
                "缩放", editOldScale_, context.objectTransform.scale,
                [&context](const glm::vec3& v) { context.objectTransform.scale = v; }));
        }

        // 形变滑块（M4，只有模型有 morph target 时显示）。
        if (context.morphTargetCount > 0) {
            ImGui::Separator();
            ImGui::TextUnformatted("形变");
            for (std::size_t i = 0; i < context.morphTargetCount; ++i) {
                ImGui::PushID(static_cast<int>(i));
                ImGui::Text("morph %zu", i);
                if (ImGui::SliderFloat("##w", &context.morphWeights[i], 0.0f, 1.0f, "%.2f")) {
                    context.morphDirty = true;
                }
                ImGui::PopID();
            }
        }

        ImGui::Separator();
        ImGui::TextDisabled("撤销 %zu / 重做 %zu",
                            context.commandHistory.undoCount(),
                            context.commandHistory.redoCount());
    }

private:
    glm::vec3 editOldPosition_{0.0f};
    glm::vec3 editOldRotation_{0.0f};
    glm::vec3 editOldScale_{1.0f};
    glm::vec3 editOldJointRotation_{0.0f};
};

class AssetsPanel final : public IPanel {
public:
    const char* name() const override { return "内容"; }

    void draw(EditorContext& context) override {
        // 顶部搜索框（内容跨帧保留）。
        static char search[128] = "";
        ImGui::SetNextItemWidth(-1.0f);
        ImGui::InputTextWithHint("##search", "搜索资产...", search, sizeof(search));
        ImGui::Spacing();

        if (context.contentAssets.empty()) {
            ImGui::TextDisabled("（content 目录无 glb 资产）");
            return;
        }

        const std::string filter = search;

        constexpr float kCellWidth = 104.0f;
        const float available = ImGui::GetContentRegionAvail().x;
        const int columns = std::max(1, static_cast<int>(available / kCellWidth));

        int index = 0;
        for (const auto& asset : context.contentAssets) {
            if (!filter.empty() && asset.name.find(filter) == std::string::npos) {
                continue;
            }
            drawAssetTile(context, asset, index);
            if ((index + 1) % columns != 0) {
                ImGui::SameLine();
            }
            ++index;
        }
    }

private:
    /// 自绘一个资产卡片：深色圆角块 + 立方体线框图标 + 居中文件名。
    static void drawAssetTile(EditorContext& context, const EditorContext::AssetEntry& asset,
                              int index) {
        ImGui::PushID(index);

        constexpr float kThumb = 84.0f;
        constexpr float kCellW = 100.0f;
        constexpr float kCellH = 116.0f;

        ImGui::InvisibleButton("##tile", ImVec2(kCellW, kCellH));
        const bool hovered = ImGui::IsItemHovered();
        const bool selected = (context.selectedObject == asset.name);
        if (hovered && ImGui::IsMouseDoubleClicked(ImGuiMouseButton_Left)) {
            context.pendingLoadPath = asset.path;
        }
        if (ImGui::IsItemClicked()) {
            context.selectedObject = asset.name;
        }
        // UE5 风格：悬停显示完整文件名。
        if (hovered) {
            ImGui::BeginTooltip();
            ImGui::TextUnformatted(asset.name.c_str());
            ImGui::EndTooltip();
        }

        ImDrawList* dl = ImGui::GetWindowDrawList();
        const ImVec2 p0 = ImGui::GetItemRectMin();
        const ImVec2 p1 = ImGui::GetItemRectMax();

        // 缩略图区域。
        const ImVec2 t0(p0.x + 5, p0.y + 5);
        const ImVec2 t1(p1.x - 5, p0.y + 5 + kThumb);

        const ImU32 bg = selected ? IM_COL32(52, 84, 128, 255)
                         : hovered ? IM_COL32(56, 56, 64, 255)
                                   : IM_COL32(42, 42, 48, 255);
        dl->AddRectFilled(t0, t1, bg, 5.0f);
        if (selected) {
            dl->AddRect(t0, t1, IM_COL32(96, 160, 240, 255), 5.0f, 0, 2.0f);
        } else if (hovered) {
            dl->AddRect(t0, t1, IM_COL32(110, 110, 122, 255), 5.0f, 0, 1.5f);
        }

        // 类型角标。
        dl->AddText(ImVec2(t0.x + 5, t0.y + 3), IM_COL32(140, 145, 160, 255), "GLB");

        // 立方体线框图标（等距投影，象征 3D 模型）。
        const float cx = (t0.x + t1.x) * 0.5f;
        const float cy = (t0.y + t1.y) * 0.5f;
        constexpr float w = 17.0f;
        constexpr float h = 23.0f;
        const ImU32 lineCol =
            selected ? IM_COL32(180, 210, 250, 255) : IM_COL32(150, 155, 170, 255);
        const ImVec2 top(cx, cy - h);
        const ImVec2 left(cx - w, cy - h * 0.5f);
        const ImVec2 right(cx + w, cy - h * 0.5f);
        const ImVec2 mid(cx, cy);
        const ImVec2 bl(cx - w, cy + h * 0.5f);
        const ImVec2 br(cx + w, cy + h * 0.5f);
        const ImVec2 bottom(cx, cy + h);
        dl->AddLine(top, left, lineCol);
        dl->AddLine(top, right, lineCol);
        dl->AddLine(left, mid, lineCol);
        dl->AddLine(right, mid, lineCol);
        dl->AddLine(left, bl, lineCol);
        dl->AddLine(right, br, lineCol);
        dl->AddLine(mid, bl, lineCol);
        dl->AddLine(mid, br, lineCol);
        dl->AddLine(bl, bottom, lineCol);
        dl->AddLine(br, bottom, lineCol);

        // 文件名（底部，居中，超宽省略）。
        const ImVec2 n0(p0.x + 2, t1.y + 3);
        const ImVec2 n1(p1.x - 2, p1.y - 1);
        std::string label = asset.name;
        const float maxWidth = n1.x - n0.x;
        if (ImGui::CalcTextSize(label.c_str()).x > maxWidth) {
            while (!label.empty() &&
                   ImGui::CalcTextSize((label + "...").c_str()).x > maxWidth) {
                label.pop_back();
            }
            label += "...";
        }
        const ImVec2 textSize = ImGui::CalcTextSize(label.c_str());
        dl->AddText(ImVec2((n0.x + n1.x - textSize.x) * 0.5f, n0.y),
                    IM_COL32(212, 212, 218, 255), label.c_str());

        ImGui::PopID();
    }
};

} // namespace

std::vector<std::unique_ptr<IPanel>> createPlaceholderPanels() {
    std::vector<std::unique_ptr<IPanel>> panels;
    panels.push_back(std::make_unique<ViewportPanel>());
    panels.push_back(std::make_unique<HierarchyPanel>());
    panels.push_back(std::make_unique<AnimationPanel>());
    panels.push_back(std::make_unique<InspectorPanel>());
    panels.push_back(std::make_unique<AssetsPanel>());
    return panels;
}

} // namespace doll::editor
