#pragma once

#include <memory>
#include <vector>

namespace doll::editor {

struct EditorContext;

/// 编辑器面板接口。
///
/// `name()` 同时作为 ImGui 窗口标题和 dock 布局的稳定 key，不要动态改。
/// `draw()` 只读写 EditorContext，不触碰 GPU / 平台对象。
class IPanel {
public:
    virtual ~IPanel() = default;
    virtual const char* name() const = 0;
    virtual void draw(EditorContext& context) = 0;
};

/// 创建 M0 的四个占位面板（视口 / 层级 / 属性 / 资源）。
std::vector<std::unique_ptr<IPanel>> createPlaceholderPanels();

} // namespace doll::editor
