#pragma once

#include <glm/gtc/quaternion.hpp>
#include <glm/gtc/matrix_transform.hpp>

#include <imgui.h>

#include <algorithm>
#include <array>
#include <cstdint>
#include <string>
#include <unordered_map>
#include <vector>

#include "OrbitCamera.h"

#include "AssetData.h"
#include "Command.h"

namespace doll::editor {

/// 变换：位置 + 欧拉角旋转（度）+ 缩放。
struct Transform {
    glm::vec3 position{0.0f};
    glm::vec3 rotation{0.0f}; // 欧拉角（度），XYZ 顺序
    glm::vec3 scale{1.0f};

    /// 变换 → 模型矩阵（T * R * S）。
    [[nodiscard]] glm::mat4 toMatrix() const {
        const glm::mat4 t = glm::translate(glm::mat4(1.0f), position);
        const glm::mat4 r = glm::mat4_cast(glm::quat(glm::radians(rotation)));
        const glm::mat4 s = glm::scale(glm::mat4(1.0f), scale);
        return t * r * s;
    }
};

/// 编辑器共享状态。
///
/// M0 只有占位字段；M1 加入视口纹理与尺寸；M2 扩展资产列表、M4 扩展选中
/// 对象与命令历史。面板只读写这里的数据，不直接碰 GPU / SDL 对象。
struct EditorContext {
    std::string selectedObject = "（未选择）";
    bool showViewport = true;
    bool showHierarchy = true;
    bool showInspector = true;
    bool showAssets = true;
    /// 是否显示动画面板。
    bool showAnimation = true;
    /// 是否显示骨骼线（M3 骨架可视化；眼睛/手指骨骼会穿出体表）。
    bool showBones = false;

    /// 当前选中对象的变换（M4 属性面板编辑，渲染时应用为 model 矩阵）。
    Transform objectTransform;
    /// 角色包围盒中心（gizmo 锚点）。加载时计算，gizmo 画在这里而不是脚底原点。
    glm::vec3 objectPivot{0.0f};
    /// 命令历史（M4 撤销/重做）。
    doll::CommandHistory commandHistory;
    /// 变换 gizmo 模式（M4 第 3 步）。
    enum class GizmoMode { Translate, Rotate, Scale };
    GizmoMode gizmoMode = GizmoMode::Translate;

    /// 离屏场景图像的 ImGui 纹理句柄（App 每次重建场景目标后更新）。
    ImTextureID viewportTexture = 0;
    /// 视口面板内容区尺寸（面板每帧写入，App 用来对齐离屏目标）。
    int viewportWidth = 0;
    int viewportHeight = 0;
    /// 轨道相机（视口面板在鼠标悬停时直接驱动它）。
    doll::renderer::OrbitCamera camera;
    /// 场景节点层级（M2 加载 glb 后填充，层级面板递归显示）。
    std::vector<doll::asset::NodeData> sceneNodes;
    /// 场景根节点索引。
    std::vector<std::int32_t> sceneRootNodes;

    /// Content 浏览器里的一个资产条目。
    struct AssetEntry {
        std::string path;  // 完整路径
        std::string name;  // 文件名（不含扩展名）
    };
    /// content 目录里扫描到的资产列表。
    std::vector<AssetEntry> contentAssets;
    /// 双击资产后设置的待加载路径，App 每帧检查并加载（加载后清空）。
    std::string pendingLoadPath;
    /// 动画播放状态（M3 动画播放控制）。
    bool animationPlaying = true;
    float animationTime = 0.0f;
    /// 当前模型的动画名称（空 = 无动画）。
    std::string animationName;
    /// 动画是否可播放（存在骨骼通道且关键帧 ≥ 2）。false 时播放也不会有变化。
    bool animationPlayable = false;
    /// 当前动画总时长（秒）；0 表示无动画。
    float animationDuration = 0.0f;
    /// 当前模型的动画数据（M5 关键帧编辑直接修改这里）。
    std::vector<doll::asset::AnimationData> animations;
    /// 被编辑过的动画采样器索引（项目文件只保存这些，避免文件膨胀）。
    std::vector<std::int32_t> dirtySamplers;

    /// 标记某个采样器被编辑过（去重）。
    void markSamplerDirty(std::int32_t index) {
        if (index < 0) {
            return;
        }
        if (std::find(dirtySamplers.begin(), dirtySamplers.end(), index) ==
            dirtySamplers.end()) {
            dirtySamplers.push_back(index);
        }
    }
    /// 当前选中的节点索引（-1 = 未选中节点；M4 骨骼姿态编辑用）。
    std::int32_t selectedNodeIndex = -1;
    /// 骨骼关节旋转覆盖（姿态编辑）。key=节点索引，value=欧拉角（度，XYZ）。
    /// 只有被编辑过的关节才在 map 里；其余用节点原始 localTransform。
    std::unordered_map<std::int32_t, glm::vec3> jointRotations;

    /// 一个姿态预设：命名 + 一组关节旋转覆盖。
    struct PosePreset {
        std::string name;
        std::unordered_map<std::int32_t, glm::vec3> jointRotations;
    };
    /// 已保存的姿态预设列表（M4）。
    std::vector<PosePreset> posePresets;
    /// 预设名称输入框内容。
    std::string newPresetName;

    /// 形变权重（M4 形变滑块）：最多 4 个 morph target，各 mesh 共用这组权重。
    std::array<float, 4> morphWeights{0.0f, 0.0f, 0.0f, 0.0f};
    /// 形变权重是否需要重算并更新 GPU（滑块拖动时置位）。
    bool morphDirty = false;
    /// 当前模型的 morph target 数量（加载时填充，UI 只显示有效滑块）。
    std::size_t morphTargetCount = 0;
};

} // namespace doll::editor
