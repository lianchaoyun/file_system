#pragma once

#include <filesystem>
#include <memory>
#include <vector>

#include "Result.h"

#include "AssetData.h"

struct SDL_Renderer;

namespace doll::platform { class Window; }
namespace doll::ui { class ImGuiLayer; }
namespace doll::renderer { class VulkanContext; class VulkanDevice; class VulkanRenderer; }
namespace doll::editor { class IPanel; struct EditorContext; }

namespace doll {

/// 应用生命周期：初始化窗口/渲染器/ImGui → 主循环 → 清理。
///
/// M0 的 ImGui 用 SDL_Renderer 渲染；M1 把 ImGuiLayer 换成 Vulkan backend 即可，
/// App 与面板代码不用改。
class App {
public:
    App();
    ~App();

    App(const App&) = delete;
    App& operator=(const App&) = delete;

    Status init();
    void run();
    void shutdown();

private:
    void buildDefaultDockLayout(unsigned int dockspaceId);
    void drawDockSpace();
    void drawMenuBar();
    void scanContentDirectory();
    void loadGlb(const std::filesystem::path& path);
    void saveProjectFile();
    void loadProjectFile();

    std::unique_ptr<platform::Window> window_;
    std::unique_ptr<renderer::VulkanContext> vulkan_;
    std::unique_ptr<renderer::VulkanDevice> device_;
    std::unique_ptr<renderer::VulkanRenderer> renderer_;
    std::unique_ptr<ui::ImGuiLayer> imgui_;
    std::unique_ptr<editor::EditorContext> context_;
    std::vector<std::unique_ptr<editor::IPanel>> panels_;
    bool dockLayoutBuilt_ = false;
    bool resetLayoutRequested_ = false;
    bool aboutPopupRequested_ = false;
    int lastWidth_ = 0;
    int lastHeight_ = 0;
    int lastViewportW_ = 0;
    int lastViewportH_ = 0;
    /// 当前模型的蒙皮数据（每帧动画采样用）。动画数据在 EditorContext::animations。
    std::vector<asset::SkinData> skins_;
    /// 原始网格数据（含 morph targets），形变重算用。
    std::vector<asset::MeshData> loadedMeshes_;
    /// 当前模型的路径（保存项目时写进文件，加载时据此重新读模型）。
    std::string currentModelPath_;
    /// 上一帧时间戳（动画推进用）。
    std::uint64_t lastTickMs_ = 0;
};

} // namespace doll
