#include <SDL3/SDL.h>

#include "App.h"
#include "Log.h"
#include "Paths.h"

int main() {
    // 日志先于一切：后续初始化失败才有地方看。
    doll::log::init(doll::paths::logFile());
    DOLL_LOG_INFO("app", "dollengine 启动，日志：{}", doll::paths::logFile().string());

    int exitCode = 0;
    {
        doll::App app;
        if (auto status = app.init(); !status) {
            DOLL_LOG_ERROR("app", "初始化失败（code={}）：{}",
                           static_cast<int>(status.error().code), status.error().message);
            exitCode = 1;
        } else {
            app.run();
        }
        app.shutdown();
    }

    DOLL_LOG_INFO("app", "dollengine 退出");
    SDL_Quit();
    doll::log::shutdown();
    return exitCode;
}
