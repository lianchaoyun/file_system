#include "App.h"

#include <algorithm>
#include <cassert>
#include <cstring>

#include <SDL3/SDL.h>
#include <imgui.h>
#include <imgui_internal.h>

#include "ImGuiLayer.h"
#include "Log.h"
#include "Paths.h"
#include "ProjectFile.h"
#include "VulkanContext.h"
#include "VulkanDevice.h"
#include "VulkanRenderer.h"
#include "Window.h"

#include "AssetData.h"
#include "GltfImporter.h"
#include "Skeleton.h"

#include <filesystem>
#include "panels/EditorContext.h"
#include "panels/IPanel.h"

namespace doll {

namespace {

/// 面板名 → 可见性开关；返回 nullptr 表示没有对应的开关。
bool* panelVisibility(editor::EditorContext& context, const char* name) {
    if (std::strcmp(name, "视口") == 0) return &context.showViewport;
    if (std::strcmp(name, "层级") == 0) return &context.showHierarchy;
    if (std::strcmp(name, "属性") == 0) return &context.showInspector;
    if (std::strcmp(name, "内容") == 0) return &context.showAssets;
    if (std::strcmp(name, "动画") == 0) return &context.showAnimation;
    return nullptr;
}

} // namespace

App::App() = default;

App::~App() {
    shutdown();
}

Status App::init() {
    window_ = std::make_unique<platform::Window>();
    platform::WindowConfig config;
    config.title = "dollengine";
    config.vulkan = true; // M1：窗口需要带 SDL_WINDOW_VULKAN 标志才能创建 surface
    if (auto status = window_->init(config); !status) {
        return status;
    }

    // M1：从第 2 步起 Vulkan 独占窗口，移除 M0 的 SDL_Renderer 临时渲染路径。
    // SDL_Renderer（D3D 后端）会占用 HWND，导致 Vulkan 交换链报
    // VK_ERROR_NATIVE_WINDOW_IN_USE_KHR。ImGui 在第 5 步换成 Vulkan backend 再接入。

    context_ = std::make_unique<editor::EditorContext>();
    panels_ = editor::createPlaceholderPanels();

    // M1 第 1 步：Vulkan 实例 / 校验层 / surface 的建立与销毁。
    vulkan_ = std::make_unique<renderer::VulkanContext>();
    if (auto status = vulkan_->init(window_->handle()); !status) {
        return status;
    }

    // M1 第 2 步：物理设备 + 逻辑设备 + 队列 + 交换链。
    int pw = 0;
    int ph = 0;
    window_->pixelSize(pw, ph);
    device_ = std::make_unique<renderer::VulkanDevice>();
    if (auto status = device_->init(vulkan_->instance(), vulkan_->surface(), pw, ph); !status) {
        return status;
    }
    lastWidth_ = pw;
    lastHeight_ = ph;

    // M1 第 3~6 步：双渲染通道（场景离屏 + UI 主通道）。
    renderer_ = std::make_unique<renderer::VulkanRenderer>();
    if (auto status = renderer_->init(device_.get(), doll::paths::executableDir() / "shaders",
                                      pw, ph);
        !status) {
        return status;
    }

    // M2：扫描 content 目录，默认加载最大的 glb 资产（角色模型远大于测试立方体）。
    scanContentDirectory();
    if (!context_->contentAssets.empty()) {
        std::size_t largestIndex = 0;
        std::uintmax_t largestSize = 0;
        for (std::size_t i = 0; i < context_->contentAssets.size(); ++i) {
            std::error_code ec;
            const auto size = std::filesystem::file_size(context_->contentAssets[i].path, ec);
            if (!ec && size > largestSize) {
                largestSize = size;
                largestIndex = i;
            }
        }
        loadGlb(context_->contentAssets[largestIndex].path);
    }

    // M1 第 5 步：ImGui 换 Vulkan backend，接回 UI。
    ui::ImGuiLayer::VulkanInitInfo imguiInfo;
    imguiInfo.instance = vulkan_->instance();
    imguiInfo.physicalDevice = device_->physicalDevice();
    imguiInfo.device = device_->device();
    imguiInfo.queueFamily = device_->graphicsQueueFamily();
    imguiInfo.queue = device_->graphicsQueue();
    imguiInfo.renderPass = renderer_->mainRenderPass();
    imguiInfo.imageCount = static_cast<std::uint32_t>(device_->imageViews().size());

    imgui_ = std::make_unique<ui::ImGuiLayer>();
    if (auto status = imgui_->init(window_->handle(), imguiInfo); !status) {
        return status;
    }

    // SDL 事件转发给 ImGui（拖拽停靠/折叠/输入都靠它）。
    window_->setEventCallback([](const SDL_Event& event) {
        doll::ui::ImGuiLayer::processEvent(&event);
    });

    // ImGui 的 draw data 画在主通道（UI）内。
    renderer_->setUiRenderCallback([this](VkCommandBuffer_T* commandBuffer) {
        imgui_->renderDrawData(commandBuffer);
    });

    // 把离屏场景图像注册为 ImGui 纹理，视口面板用它显示 3D 画面。
    context_->viewportTexture =
        reinterpret_cast<ImTextureID>(imgui_->addTexture(renderer_->sceneColorView()));

    DOLL_LOG_INFO("app", "应用初始化完成（{} 个面板）", panels_.size());
    return Status::success();
}

void App::run() {
    while (!window_->shouldClose()) {
        window_->pollEvents();
        if (window_->shouldClose()) {
            break;
        }

        // Content 浏览器双击资产 → 加载对应 glb（替换当前场景）。
        if (!context_->pendingLoadPath.empty()) {
            loadGlb(context_->pendingLoadPath);
            context_->pendingLoadPath.clear();
        }

        // 窗口像素尺寸变化 → 重建交换链（最小化时跳过，等恢复）。
        int w = 0;
        int h = 0;
        window_->pixelSize(w, h);
        if (w != lastWidth_ || h != lastHeight_) {
            if (w > 0 && h > 0) {
                device_->recreateSwapchain(w, h);
                if (auto status = renderer_->onSwapchainRecreated(); !status) {
                    DOLL_LOG_ERROR("app", "重建帧缓冲失败：{}", status.error().message);
                }
            }
            lastWidth_ = w;
            lastHeight_ = h;
        }

        if (w <= 0 || h <= 0) {
            continue; // 最小化：不渲染
        }

        // 视口面板尺寸变化（用上一帧面板报告的尺寸）→ 重建离屏场景目标并更新
        // 纹理句柄。必须在 UI 绘制之前换纹理，否则本帧 draw data 会引用已释放
        // 的旧 descriptor set。
        if (context_->viewportWidth != lastViewportW_ || context_->viewportHeight != lastViewportH_) {
            const int vw = context_->viewportWidth;
            const int vh = context_->viewportHeight;
            if (vw > 0 && vh > 0) {
                if (auto status = renderer_->resizeSceneTarget(vw, vh); !status) {
                    DOLL_LOG_ERROR("app", "重建离屏场景目标失败：{}", status.error().message);
                } else {
                    imgui_->removeTexture(reinterpret_cast<VkDescriptorSet_T*>(context_->viewportTexture));
                    context_->viewportTexture =
                        reinterpret_cast<ImTextureID>(imgui_->addTexture(renderer_->sceneColorView()));
                }
            }
            lastViewportW_ = vw;
            lastViewportH_ = vh;
        }

        // ImGui 帧开始 → 绘制 UI → 生成 draw data。
        imgui_->beginFrame();
        drawMenuBar();
        drawDockSpace();
        for (auto& panel : panels_) {
            if (bool* visible = panelVisibility(*context_, panel->name()); !visible || !*visible) {
                continue;
            }
            if (ImGui::Begin(panel->name())) {
                panel->draw(*context_);
            }
            ImGui::End();
        }

        // 姿态更新：动画采样 + 关节旋转覆盖 → 蒙皮矩阵 + 骨骼线。
        {
            const std::uint64_t now = SDL_GetTicks();
            const float deltaSec = (lastTickMs_ != 0)
                                       ? static_cast<float>(now - lastTickMs_) / 1000.0f
                                       : 0.0f;
            lastTickMs_ = now;

            if (context_->animationPlaying && !context_->animations.empty()) {
                context_->animationTime += deltaSec;
            }

            if (!skins_.empty()) {
                // 基础局部变换：有动画就始终按当前时间采样。
                // 暂停时时间不推进（角色停在当前帧），scrub 时按新时间重采样。
                std::vector<glm::mat4> local;
                if (!context_->animations.empty()) {
                    local = doll::animation::sampleLocalTransforms(
                        context_->sceneNodes, context_->animations[0], context_->animationTime);
                } else {
                    local.reserve(context_->sceneNodes.size());
                    for (const auto& node : context_->sceneNodes) {
                        local.push_back(node.localTransform);
                    }
                }
                // 关节旋转覆盖（M4 姿态编辑）。
                doll::animation::applyJointRotations(local, context_->jointRotations);
                // 蒙皮矩阵 + 骨骼线。
                renderer_->setSkinMatrices(doll::animation::computeSkinningMatricesWithLocal(
                    context_->sceneNodes, context_->sceneRootNodes, skins_[0], local));
                const auto jointWorld = doll::animation::computeJointWorldTransformsWithLocal(
                    context_->sceneNodes, context_->sceneRootNodes, skins_[0].joints, local);
                renderer_->setBoneLines(doll::animation::buildBoneLines(
                    context_->sceneNodes, skins_[0].joints, jointWorld));
            }
        }

        // 形变：权重改变时按 morph target 重算顶点并更新 GPU。
        if (context_->morphDirty && !loadedMeshes_.empty()) {
            context_->morphDirty = false;
            for (std::size_t mi = 0; mi < loadedMeshes_.size(); ++mi) {
                const auto& src = loadedMeshes_[mi];
                if (src.morphTargets.empty()) {
                    continue;
                }
                std::vector<asset::Vertex> verts = src.vertices;
                for (std::size_t t = 0; t < src.morphTargets.size() && t < 4; ++t) {
                    const float weight = context_->morphWeights[t];
                    if (weight == 0.0f) {
                        continue;
                    }
                    const auto& deltas = src.morphTargets[t].positionDeltas;
                    const std::size_t n = std::min(deltas.size(), verts.size());
                    for (std::size_t i = 0; i < n; ++i) {
                        verts[i].position += deltas[i] * weight;
                    }
                }
                renderer_->updateMeshVertices(mi, verts);
            }
        }

        // 快捷键：Ctrl+Z/Y 撤销重做；W/E/R 切换 gizmo 模式。
        {
            ImGuiIO& io = ImGui::GetIO();
            if (io.KeyCtrl && ImGui::IsKeyPressed(ImGuiKey_Z, false)) {
                context_->commandHistory.undo();
            }
            if (io.KeyCtrl && ImGui::IsKeyPressed(ImGuiKey_Y, false)) {
                context_->commandHistory.redo();
            }
            if (!io.KeyCtrl && ImGui::IsKeyPressed(ImGuiKey_W, false)) {
                context_->gizmoMode = editor::EditorContext::GizmoMode::Translate;
            }
            if (!io.KeyCtrl && ImGui::IsKeyPressed(ImGuiKey_E, false)) {
                context_->gizmoMode = editor::EditorContext::GizmoMode::Rotate;
            }
            if (!io.KeyCtrl && ImGui::IsKeyPressed(ImGuiKey_R, false)) {
                context_->gizmoMode = editor::EditorContext::GizmoMode::Scale;
            }
        }

        // 纵横比按视口面板（离屏目标）尺寸算，否则画面会被拉伸。
        // 相机由视口面板在鼠标悬停时驱动，存在 EditorContext。
        if (renderer_->sceneWidth() > 0 && renderer_->sceneHeight() > 0) {
            const glm::mat4 projView = context_->camera.mvp(
                static_cast<float>(renderer_->sceneWidth()) /
                static_cast<float>(renderer_->sceneHeight()));
            // model 矩阵来自属性面板编辑的变换（M4）。
            renderer_->setMvp(projView * context_->objectTransform.toMatrix());
        }

        // 骨骼线显示开关（M3 骨架可视化；眼睛/手指骨骼会穿出体表，默认关）。
        renderer_->setBoneLinesVisible(context_->showBones);

        imgui_->render();

        // draw/present 一帧（立方体 + ImGui）；交换链过期（resize 抖动）时重建再来。
        if (renderer_->drawFrame() == renderer::VulkanRenderer::DrawResult::OutOfDate) {
            device_->recreateSwapchain(w, h);
            if (auto status = renderer_->onSwapchainRecreated(); !status) {
                DOLL_LOG_ERROR("app", "重建帧缓冲失败：{}", status.error().message);
            }
        }
    }
}

void App::scanContentDirectory() {
    context_->contentAssets.clear();
    const auto root = doll::paths::assetRoot();
    if (!std::filesystem::exists(root)) {
        return;
    }
    for (const auto& entry : std::filesystem::recursive_directory_iterator(root)) {
        if (!entry.is_regular_file()) {
            continue;
        }
        const std::string ext = entry.path().extension().string();
        if (ext != ".glb" && ext != ".gltf") {
            continue;
        }
        editor::EditorContext::AssetEntry asset;
        asset.path = entry.path().string();
        asset.name = entry.path().stem().string();
        context_->contentAssets.push_back(std::move(asset));
    }
    DOLL_LOG_INFO("app", "扫描 content 目录：{} 个资产", context_->contentAssets.size());
}

void App::loadGlb(const std::filesystem::path& path) {
    auto asset = doll::asset::GltfImporter::load(path);
    if (!asset) {
        DOLL_LOG_WARN("app", "加载模型失败：{}（{}）", path.string(), asset.error().message);
        return;
    }
    auto& data = asset.value();
    renderer_->setMeshes(data.meshes, data.materials, data.textures);

    // 骨架可视化 + 蒙皮：计算关节全局变换、骨骼线、蒙皮矩阵（必须在 move nodes 之前）。
    if (!data.skins.empty()) {
        const auto& skin = data.skins[0];
        const auto jointWorld = doll::animation::computeJointWorldTransforms(
            data.nodes, data.sceneRootNodes, skin.joints);
        renderer_->setBoneLines(doll::animation::buildBoneLines(data.nodes, skin.joints, jointWorld));
        renderer_->setSkinMatrices(doll::animation::computeSkinningMatrices(
            data.nodes, data.sceneRootNodes, skin));
    } else {
        renderer_->setBoneLines({});
        renderer_->setSkinMatrices({});
    }

    context_->sceneNodes = std::move(data.nodes);
    context_->sceneRootNodes = std::move(data.sceneRootNodes);
    context_->selectedObject = "（未选择）";
    // 保存动画与蒙皮数据，供每帧动画采样。
    context_->animations = std::move(data.animations);
    skins_ = std::move(data.skins);
    context_->animationTime = 0.0f;

    // 统计动画可播放性：需要非 weights 通道（骨骼）且关键帧 ≥ 2 帧。
    context_->animationName.clear();
    context_->animationPlayable = false;
    context_->animationDuration = context_->animations.empty() ? 0.0f : context_->animations[0].duration;
    if (!context_->animations.empty()) {
        const auto& anim = context_->animations[0];
        context_->animationName = anim.name;
        for (const auto& channel : anim.channels) {
            if (channel.path == asset::AnimationPath::Weights || channel.samplerIndex < 0) {
                continue;
            }
            if (static_cast<std::size_t>(channel.samplerIndex) < anim.samplers.size() &&
                anim.samplers[static_cast<std::size_t>(channel.samplerIndex)].times.size() >= 2) {
                context_->animationPlayable = true;
                break;
            }
        }
    }
    // 加载新模型：重置变换、姿态编辑与命令历史（撤销栈指向旧对象的 setter，不能跨对象复用）。
    context_->objectTransform = editor::Transform{};
    context_->jointRotations.clear();
    context_->selectedNodeIndex = -1;
    context_->commandHistory.clear();

    // 保存原始网格（morph 重算用）并统计 morph target 数量。
    loadedMeshes_ = data.meshes;
    std::size_t morphCount = 0;
    for (const auto& mesh : loadedMeshes_) {
        morphCount = std::max(morphCount, mesh.morphTargets.size());
    }
    context_->morphTargetCount = std::min<std::size_t>(morphCount, 4);
    context_->morphWeights = {};
    context_->morphDirty = false;

    // 计算包围盒，让相机对准中心并自动取景。
    if (!data.meshes.empty() && !data.meshes[0].vertices.empty()) {
        glm::vec3 minPos = data.meshes[0].vertices[0].position;
        glm::vec3 maxPos = minPos;
        for (const auto& mesh : data.meshes) {
            for (const auto& v : mesh.vertices) {
                minPos = glm::min(minPos, v.position);
                maxPos = glm::max(maxPos, v.position);
            }
        }
        const glm::vec3 center = (minPos + maxPos) * 0.5f;
        const float radius = glm::length(maxPos - minPos) * 0.5f;
        context_->camera.target = center;
        // gizmo 锚点：角色中心（模型原点通常在脚底，直接用原点 gizmo 会画在脚下）。
        context_->objectPivot = center;
        context_->camera.distance =
            radius / glm::tan(glm::radians(context_->camera.fov * 0.5f)) * 1.25f;
        DOLL_LOG_INFO("app", "模型包围盒中心 ({:.2f},{:.2f},{:.2f})，半径 {:.2f}",
                      center.x, center.y, center.z, radius);
    }

    currentModelPath_ = path.string();
    DOLL_LOG_INFO("app", "已加载模型：{}", path.string());
}

void App::saveProjectFile() {
    editor::ProjectData data;
    data.modelPath = currentModelPath_;
    data.position = context_->objectTransform.position;
    data.rotation = context_->objectTransform.rotation;
    data.scale = context_->objectTransform.scale;
    data.jointRotations = context_->jointRotations;
    data.morphWeights = context_->morphWeights;

    // 只保存被编辑过的采样器，避免项目文件过大。
    if (!context_->animations.empty()) {
        const auto& samplers = context_->animations[0].samplers;
        for (const std::int32_t index : context_->dirtySamplers) {
            if (index < 0 || static_cast<std::size_t>(index) >= samplers.size()) {
                continue;
            }
            const auto& sampler = samplers[static_cast<std::size_t>(index)];
            editor::ProjectData::SamplerEdit edit;
            edit.index = index;
            edit.interpolation = sampler.interpolation;
            edit.times = sampler.times;
            edit.rotations = sampler.rotations;
            edit.translations = sampler.translations;
            edit.scales = sampler.scales;
            data.samplerEdits.push_back(std::move(edit));
        }
    }

    const auto path = doll::paths::executableDir() / "project.dollproj";
    if (auto status = editor::saveProject(path, data); !status) {
        DOLL_LOG_ERROR("app", "保存项目失败：{}", status.error().message);
    }
}

void App::loadProjectFile() {
    const auto path = doll::paths::executableDir() / "project.dollproj";
    auto project = editor::loadProject(path);
    if (!project) {
        DOLL_LOG_WARN("app", "加载项目失败：{}", project.error().message);
        return;
    }
    const auto& data = project.value();

    // 先重新加载模型（loadGlb 会重置编辑状态），再套用编辑数据。
    if (!data.modelPath.empty()) {
        loadGlb(data.modelPath);
    }
    context_->objectTransform.position = data.position;
    context_->objectTransform.rotation = data.rotation;
    context_->objectTransform.scale = data.scale;
    context_->jointRotations = data.jointRotations;
    context_->morphWeights = data.morphWeights;
    context_->morphDirty = true;

    // 还原被编辑过的动画采样器。
    if (!context_->animations.empty()) {
        auto& samplers = context_->animations[0].samplers;
        for (const auto& edit : data.samplerEdits) {
            if (edit.index < 0 || static_cast<std::size_t>(edit.index) >= samplers.size()) {
                continue;
            }
            auto& sampler = samplers[static_cast<std::size_t>(edit.index)];
            sampler.interpolation = edit.interpolation;
            sampler.times = edit.times;
            sampler.rotations = edit.rotations;
            sampler.translations = edit.translations;
            sampler.scales = edit.scales;
            context_->markSamplerDirty(edit.index);
        }
    }
    DOLL_LOG_INFO("app", "项目已还原：{}", path.string());
}

void App::shutdown() {
    panels_.clear();
    context_.reset();
    // 先等所有在飞命令完成，再销毁 ImGui 的 GPU 资源（其 buffer/descriptor/
    // pipeline 被命令缓冲引用，不等的话校验层会报「in use by command buffer」）。
    if (renderer_) {
        renderer_->waitIdle();
    }
    if (imgui_) {
        imgui_->shutdown();
        imgui_.reset();
    }
    // Vulkan 销毁顺序：renderer 依赖 device，先销毁 renderer；
    // device 依赖 instance/surface；surface 依赖窗口。
    if (renderer_) {
        renderer_->shutdown();
        renderer_.reset();
    }
    if (device_) {
        device_->shutdown();
        device_.reset();
    }
    if (vulkan_) {
        vulkan_->shutdown();
        vulkan_.reset();
    }
    if (window_) {
        window_->shutdown();
        window_.reset();
    }
}

void App::buildDefaultDockLayout(const ImGuiID dockspaceId) {
    ImGui::DockBuilderRemoveNode(dockspaceId);
    ImGui::DockBuilderAddNode(dockspaceId, ImGuiDockNodeFlags_DockSpace);
    ImGui::DockBuilderSetNodeSize(dockspaceId, ImGui::GetMainViewport()->WorkSize);

    ImGuiID center = dockspaceId;
    const ImGuiID left = ImGui::DockBuilderSplitNode(center, ImGuiDir_Left, 0.19f, nullptr, &center);
    const ImGuiID right = ImGui::DockBuilderSplitNode(center, ImGuiDir_Right, 0.24f, nullptr, &center);
    const ImGuiID bottom = ImGui::DockBuilderSplitNode(center, ImGuiDir_Down, 0.32f, nullptr, &center);

    ImGui::DockBuilderDockWindow("视口", center);
    ImGui::DockBuilderDockWindow("层级", left);
    ImGui::DockBuilderDockWindow("属性", right);
    // 内容与动画停靠到同一个节点 → 自动变成 Tab 切换。
    ImGui::DockBuilderDockWindow("内容", bottom);
    ImGui::DockBuilderDockWindow("动画", bottom);
    ImGui::DockBuilderFinish(dockspaceId);

    DOLL_LOG_DEBUG("ui", "默认停靠布局已构建（视口 / 层级 / 属性 / 内容+动画 Tab）");
}

void App::drawDockSpace() {
    const ImGuiViewport* viewport = ImGui::GetMainViewport();
    // 必须每帧强制对齐 WorkPos/WorkSize：首帧时菜单栏尚未渲染，WorkPos 还是 (0,0)，
    // 若只在首帧设置，DockSpaceHost 会被 ini 缓存固定在 (0,0) 并盖住菜单栏。
    ImGui::SetNextWindowPos(viewport->WorkPos, ImGuiCond_Always);
    ImGui::SetNextWindowSize(viewport->WorkSize, ImGuiCond_Always);
    ImGui::SetNextWindowViewport(viewport->ID);

    constexpr ImGuiWindowFlags flags =
        ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoResize |
        ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoBringToFrontOnFocus |
        ImGuiWindowFlags_NoNavFocus | ImGuiWindowFlags_NoDocking;

    ImGui::PushStyleVar(ImGuiStyleVar_WindowRounding, 0.0f);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowBorderSize, 0.0f);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(0.0f, 0.0f));
    ImGui::Begin("DockSpaceHost", nullptr, flags);
    ImGui::PopStyleVar(3);

    const ImGuiID dockspaceId = ImGui::GetID("DollDockSpace");
    if (resetLayoutRequested_) {
        // 必须在 DockSpace() 之前、且处于 DockSpaceHost 的 ID 上下文内重建
        buildDefaultDockLayout(dockspaceId);
        resetLayoutRequested_ = false;
    }
    if (!dockLayoutBuilt_) {
        // 首次运行（还没有布局文件）才构建默认布局；之后启动由 imgui.ini 恢复
        // 用户上次拖拽的布局，不再覆盖。
        // 注意不能用 DockBuilderGetNode 判断：在 DockSpace() 调用之前，ini 里
        // 的节点还在排队未恢复，GetNode 永远返回 null。
        static const bool hasLayoutFile =
            std::filesystem::exists(doll::paths::executableDir() / "imgui.ini");
        if (!hasLayoutFile) {
            buildDefaultDockLayout(dockspaceId);
        }
        dockLayoutBuilt_ = true;
    }

    ImGui::DockSpace(dockspaceId, ImVec2(0.0f, 0.0f), ImGuiDockNodeFlags_None);
    ImGui::End();
}

void App::drawMenuBar() {
    // 注意：BeginMainMenuBar 返回 false 时并没有进入窗口，不能再调 EndMainMenuBar，
    // 否则窗口栈失衡，后续控件会全部落进 ImGui 的 Debug##Default 隐藏窗口。
    if (!ImGui::BeginMainMenuBar()) {
        return;
    }

    if (ImGui::BeginMenu("文件(F)")) {
        ImGui::BeginDisabled();
        ImGui::MenuItem("新建场景", "Ctrl+N");
        ImGui::EndDisabled();
        if (ImGui::MenuItem("打开项目", "Ctrl+O")) {
            loadProjectFile();
        }
        if (ImGui::MenuItem("保存项目", "Ctrl+S")) {
            saveProjectFile();
        }
        ImGui::Separator();
        if (ImGui::MenuItem("退出", "Alt+F4")) {
            SDL_Event quit{};
            quit.type = SDL_EVENT_QUIT;
            SDL_PushEvent(&quit);
        }
        ImGui::EndMenu();
    }

    if (ImGui::BeginMenu("编辑(E)")) {
        // M4 接入命令历史后启用
        ImGui::BeginDisabled();
        ImGui::MenuItem("撤销", "Ctrl+Z");
        ImGui::MenuItem("重做", "Ctrl+Y");
        ImGui::EndDisabled();
        ImGui::EndMenu();
    }

    if (ImGui::BeginMenu("视图(V)")) {
        ImGui::MenuItem("视口", nullptr, &context_->showViewport);
        ImGui::MenuItem("层级", nullptr, &context_->showHierarchy);
        ImGui::MenuItem("属性", nullptr, &context_->showInspector);
        ImGui::MenuItem("内容", nullptr, &context_->showAssets);
        ImGui::MenuItem("动画", nullptr, &context_->showAnimation);
        ImGui::Separator();
        ImGui::MenuItem("显示骨骼", nullptr, &context_->showBones);
        ImGui::Separator();
        if (ImGui::MenuItem("重置布局")) {
            resetLayoutRequested_ = true;
        }
        ImGui::EndMenu();
    }

    if (ImGui::BeginMenu("帮助(H)")) {
        if (ImGui::MenuItem("打开日志目录")) {
            SDL_OpenURL(doll::paths::logDir().string().c_str());
        }
        ImGui::Separator();
        if (ImGui::MenuItem("关于 dollengine")) {
            aboutPopupRequested_ = true;
        }
        ImGui::EndMenu();
    }

    if (aboutPopupRequested_) {
        ImGui::OpenPopup("关于##about");
        aboutPopupRequested_ = false;
    }
    if (ImGui::BeginPopupModal("关于##about", nullptr, ImGuiWindowFlags_AlwaysAutoResize)) {
        ImGui::Text("dollengine M0 骨架");
        ImGui::TextDisabled("ImGui + SDL3 + SDLRenderer");
        ImGui::Separator();
        if (ImGui::Button("关闭", ImVec2(80.0f, 0.0f))) {
            ImGui::CloseCurrentPopup();
        }
        ImGui::EndPopup();
    }

    ImGui::EndMainMenuBar();
}

} // namespace doll
