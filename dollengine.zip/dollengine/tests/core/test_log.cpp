#include <catch2/catch_test_macros.hpp>

#include <filesystem>
#include <fstream>
#include <iterator>
#include <string>

#include "Log.h"

TEST_CASE("Log level filtering", "[core][log]") {
    doll::log::setMinLevel(doll::log::Level::Warn);
    REQUIRE_FALSE(doll::log::shouldLog(doll::log::Level::Trace));
    REQUIRE_FALSE(doll::log::shouldLog(doll::log::Level::Info));
    REQUIRE(doll::log::shouldLog(doll::log::Level::Warn));
    REQUIRE(doll::log::shouldLog(doll::log::Level::Error));
    doll::log::setMinLevel(doll::log::Level::Trace);
}

TEST_CASE("Log writes to file", "[core][log]") {
    const auto path = std::filesystem::temp_directory_path() / "doll_core_test_log.log";
    std::filesystem::remove(path);

    doll::log::init(path);
    doll::log::setMinLevel(doll::log::Level::Trace);
    DOLL_LOG_INFO("test", "编号 {} 写入成功", 42);
    doll::log::shutdown();

    REQUIRE(std::filesystem::exists(path));

    {
        std::ifstream file(path);
        const std::string content((std::istreambuf_iterator<char>(file)),
                                  std::istreambuf_iterator<char>());
        REQUIRE(content.find("编号 42 写入成功") != std::string::npos);
        REQUIRE(content.find("[test]") != std::string::npos);
    } // file 析构关闭后再删，否则 Windows 上文件被占用会抛异常

    std::filesystem::remove(path);
}
