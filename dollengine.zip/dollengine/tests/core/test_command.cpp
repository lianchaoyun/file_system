#include <catch2/catch_test_macros.hpp>

#include <memory>

#include "Command.h"

using namespace doll;

TEST_CASE("SetValueCommand redo undo", "[core]") {
    int value = 0;
    SetValueCommand<int> cmd("set", 0, 42, [&](const int& v) { value = v; });
    cmd.redo();
    REQUIRE(value == 42);
    cmd.undo();
    REQUIRE(value == 0);
}

TEST_CASE("CommandHistory undo redo", "[core]") {
    int value = 0;
    CommandHistory history;
    history.doCommand(std::make_unique<SetValueCommand<int>>(
        "set 1", 0, 1, [&](const int& v) { value = v; }));
    history.doCommand(std::make_unique<SetValueCommand<int>>(
        "set 2", 1, 2, [&](const int& v) { value = v; }));
    REQUIRE(value == 2);
    REQUIRE(history.undoCount() == 2);

    history.undo();
    REQUIRE(value == 1);
    REQUIRE(history.canRedo());

    history.undo();
    REQUIRE(value == 0);
    REQUIRE_FALSE(history.canUndo());

    history.redo();
    REQUIRE(value == 1);
    history.redo();
    REQUIRE(value == 2);
    REQUIRE_FALSE(history.canRedo());
}

TEST_CASE("new command clears redo stack", "[core]") {
    int value = 0;
    CommandHistory history;
    history.doCommand(std::make_unique<SetValueCommand<int>>(
        "set 1", 0, 1, [&](const int& v) { value = v; }));
    history.undo();
    REQUIRE(history.canRedo());

    history.doCommand(std::make_unique<SetValueCommand<int>>(
        "set 2", 0, 2, [&](const int& v) { value = v; }));
    REQUIRE_FALSE(history.canRedo());
    REQUIRE(value == 2);
}
