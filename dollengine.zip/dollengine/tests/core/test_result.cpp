#include <catch2/catch_test_macros.hpp>

#include "Result.h"

using namespace doll;

TEST_CASE("Result success path", "[core][result]") {
    const auto result = Result<int>::success(42);
    REQUIRE(result.ok());
    REQUIRE(static_cast<bool>(result));
    REQUIRE(result.value() == 42);
}

TEST_CASE("Result failure carries error", "[core][result]") {
    const auto result = Result<int>::fail(ErrorCode::Io, "文件读取失败");
    REQUIRE_FALSE(result.ok());
    REQUIRE_FALSE(static_cast<bool>(result));
    REQUIRE(result.error().code == ErrorCode::Io);
    REQUIRE(result.error().message == "文件读取失败");
}

TEST_CASE("Status success and failure", "[core][result]") {
    const auto ok = Status::success();
    REQUIRE(ok.ok());

    const auto failed = Status::fail(ErrorCode::Graphics, "设备初始化失败");
    REQUIRE_FALSE(failed.ok());
    REQUIRE(failed.error().code == ErrorCode::Graphics);
    REQUIRE(failed.error().message == "设备初始化失败");
}
