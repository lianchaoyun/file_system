#include <catch2/catch_test_macros.hpp>

#include <filesystem>

#include "Paths.h"

TEST_CASE("Executable dir is not empty", "[core][paths]") {
    REQUIRE_FALSE(doll::paths::executableDir().empty());
}

TEST_CASE("Asset and log dirs under executable dir", "[core][paths]") {
    const auto exeDir = doll::paths::executableDir();
    REQUIRE(doll::paths::assetRoot() == exeDir / "content");
    REQUIRE(doll::paths::logDir() == exeDir / "logs");
}

TEST_CASE("Log file has timestamped name", "[core][paths]") {
    const auto file = doll::paths::logFile();
    REQUIRE(file.extension() == ".log");
    REQUIRE(file.parent_path() == doll::paths::logDir());
    REQUIRE(file.filename().string().rfind("app-", 0) == 0);
}
