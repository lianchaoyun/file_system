#include <catch2/catch_approx.hpp>
#include <catch2/catch_test_macros.hpp>

#include "AssetData.h"
#include "GltfImporter.h"
#include "Paths.h"

using namespace doll;

TEST_CASE("load sample cube glb", "[asset]") {
    const auto path = paths::assetRoot() / "sample_cube.glb";
    auto result = asset::GltfImporter::load(path);
    if (!result.ok()) {
        UNSCOPED_INFO("加载失败：" << result.error().message);
    }
    REQUIRE(result.ok());

    const auto& data = result.value();

    // 网格：1 个，8 顶点 36 索引。
    REQUIRE(data.meshes.size() == 1);
    REQUIRE(data.meshes[0].vertices.size() == 8);
    REQUIRE(data.meshes[0].indices.size() == 36);
    REQUIRE(data.meshes[0].materialIndex == 0);

    // 材质：1 个。
    REQUIRE(data.materials.size() == 1);
    REQUIRE(data.materials[0].name == "CubeMat");

    // 节点层级：Root → Cube。
    REQUIRE(data.nodes.size() == 2);
    REQUIRE(data.sceneRootNodes.size() == 1);
    REQUIRE(data.sceneRootNodes[0] == 0);
    REQUIRE(data.nodes[0].name == "Root");
    REQUIRE(data.nodes[0].children.size() == 1);
    REQUIRE(data.nodes[0].children[0] == 1);
    REQUIRE(data.nodes[1].name == "Cube");
    REQUIRE(data.nodes[1].meshIndex == 0);

    // 顶点数据：位置在立方体范围内，法线是单位向量（位置归一化）。
    const auto& v0 = data.meshes[0].vertices[0];
    REQUIRE(v0.position.x == Catch::Approx(-0.5f));
    REQUIRE(glm::length(v0.normal) == Catch::Approx(1.0f).epsilon(0.01f));
}

TEST_CASE("invalid glb reports readable error", "[asset]") {
    // 用自身可执行文件当输入（前 4 字节不是 glTF 魔数），应报可读错误。
    const auto path = paths::executableDir() / "DollAssetTests.exe";
    auto result = asset::GltfImporter::load(path);
    REQUIRE_FALSE(result.ok());
    REQUIRE_FALSE(result.error().message.empty());
}

TEST_CASE("load textured glb extracts texture", "[asset]") {
    const auto path = paths::assetRoot() / "textured_plane.glb";
    auto result = asset::GltfImporter::load(path);
    REQUIRE(result.ok());
    const auto& data = result.value();
    // 1 个纹理，8x8 RGBA，材质引用了该纹理。
    REQUIRE(data.textures.size() == 1);
    REQUIRE(data.textures[0].width == 8);
    REQUIRE(data.textures[0].height == 8);
    REQUIRE(data.textures[0].pixels.size() == 8 * 8 * 4);
    REQUIRE(data.materials.size() == 1);
    REQUIRE(data.materials[0].baseColorTexture == 0);
}

TEST_CASE("load skinned glb extracts skin data", "[asset]") {
    const auto path = paths::assetRoot() / "xiaowu_blender.glb";
    auto result = asset::GltfImporter::load(path);
    if (!result.ok()) {
        UNSCOPED_INFO("加载失败：" << result.error().message);
    }
    REQUIRE(result.ok());
    const auto& data = result.value();

    // 1 个蒙皮，138 骨骼关节，逆绑定矩阵数量一致（MAT4 FLOAT）。
    REQUIRE(data.skins.size() == 1);
    REQUIRE(data.skins[0].joints.size() == 138);
    REQUIRE(data.skins[0].inverseBindMatrices.size() == 138);

    // 蒙皮网格的顶点应有关节权重，且 skinIndex 已按挂载 node 推断。
    bool foundSkinned = false;
    for (const auto& mesh : data.meshes) {
        if (mesh.skinIndex >= 0) {
            foundSkinned = true;
            REQUIRE_FALSE(mesh.vertices.empty());
            REQUIRE(mesh.vertices[0].weights.x > 0.0f);
        }
    }
    REQUIRE(foundSkinned);
}

TEST_CASE("load animated glb extracts animation", "[asset]") {
    const auto path = paths::assetRoot() / "arm_anim.glb";
    auto result = asset::GltfImporter::load(path);
    REQUIRE(result.ok());
    const auto& data = result.value();

    // 1 个动画：bone 绕 Y 轴旋转，4 关键帧，时长 3 秒。
    REQUIRE(data.animations.size() == 1);
    const auto& anim = data.animations[0];
    REQUIRE(anim.channels.size() == 1);
    REQUIRE(anim.channels[0].nodeIndex == 1);
    REQUIRE(anim.channels[0].path == asset::AnimationPath::Rotation);
    REQUIRE(anim.samplers.size() == 1);
    REQUIRE(anim.samplers[0].times.size() == 4);
    REQUIRE(anim.samplers[0].rotations.size() == 4);
    REQUIRE(anim.duration == Catch::Approx(3.0f));
}
