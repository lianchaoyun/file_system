#include <catch2/catch_test_macros.hpp>

#include "AssetData.h"
#include "GltfImporter.h"
#include "Paths.h"
#include "Skeleton.h"

using namespace doll;

TEST_CASE("sample animation produces changing joint transforms", "[animation]") {
    const auto path = paths::assetRoot() / "arm_anim.glb";
    auto result = asset::GltfImporter::load(path);
    REQUIRE(result.ok());
    const auto& data = result.value();

    REQUIRE_FALSE(data.animations.empty());
    REQUIRE_FALSE(data.skins.empty());

    const auto& anim = data.animations[0];

    // 至少有一个非 weights（骨骼）通道。
    bool foundBoneChannel = false;
    for (const auto& channel : anim.channels) {
        if (channel.path != asset::AnimationPath::Weights) {
            foundBoneChannel = true;
        }
    }
    REQUIRE(foundBoneChannel);

    // 不同时刻采样，bone（node 1）的局部变换应不同——播放器确实在驱动骨骼。
    const auto localAt0 = animation::sampleLocalTransforms(data.nodes, anim, 0.0f);
    const auto localAt15 = animation::sampleLocalTransforms(data.nodes, anim, 1.5f);
    REQUIRE(localAt0[1] != localAt15[1]);
}
