"""
快速验证 Ollama 连接是否正常
"""
import asyncio
from openai import AsyncOpenAI


async def test_ollama_connection():
    """测试 Ollama 是否可用"""
    client = AsyncOpenAI(
        base_url="http://127.0.0.1:11434/v1",
        api_key="ollama",
    )

    print("正在连接 Ollama ...")
    print(f"地址: http://127.0.0.1:11434/v1")

    try:
        # 1. 列出可用模型
        models = await client.models.list()
        print("\n[OK] 连接成功! 可用模型:")
        for m in models.data:
            print(f"  - {m.id}")

        # 2. 测试对话
        print("\n正在测试对话 ...")
        response = await client.chat.completions.create(
            model="deepseek-r1:7b",
            messages=[{"role": "user", "content": "你好，请用一句话介绍自己"}],
            max_tokens=4096,
            timeout=120,
        )
        choice = response.choices[0]
        msg = choice.message
        # deepseek-r1 把思考过程放在 reasoning，最终回答在 content
        if hasattr(msg, 'reasoning'):
            print(f"\n[推理过程] {msg.reasoning[:300]}...")
        print(f"\n[回复内容] {msg.content}")
        print(f"[结束原因] {choice.finish_reason}, tokens={response.usage}")

    except Exception as e:
        print(f"\n[ERROR] 连接失败: {e}")
        print("请确保 Ollama 正在运行: ollama serve")


if __name__ == "__main__":
    asyncio.run(test_ollama_connection())
