"""
MetaGPT Demo - 使用本地 Ollama 运行一个简单的软件开发任务
"""
import asyncio
from pathlib import Path
from metagpt.roles import Architect, Engineer, ProductManager, ProjectManager
from metagpt.team import Team
from metagpt.config2 import Config


async def main():
    config = Config.from_yaml_file(Path("config/config2.yaml"))
    config.default()

    company = Team()
    company.hire(
        [
            ProductManager(),
            Architect(),
            ProjectManager(),
            Engineer(),
        ]
    )

    company.invest(10.0)  # 预算 $10

    history = await company.run(
        n_round=5,
        idea="写一个 Python 命令行待办事项工具，支持增删查改"
    )
    print("\n" + "=" * 50)
    print("项目完成！")
    print("=" * 50)


if __name__ == "__main__":
    asyncio.run(main())
