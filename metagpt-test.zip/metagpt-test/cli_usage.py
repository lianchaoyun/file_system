"""
MetaGPT CLI 使用示例
"""
import asyncio
from metagpt.software_company import generate_repo


async def main():
    await generate_repo(
        idea="写一个简单的 Python 计算器程序",
        investment=3.0,
        n_round=5,
    )


if __name__ == "__main__":
    asyncio.run(main())
