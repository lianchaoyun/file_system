"""
命令行待办事项工具 — 支持增删查改
数据持久化到本地 JSON 文件
"""
import json
import os
import sys
from datetime import datetime
from dataclasses import dataclass, asdict
from typing import Optional

# Windows 控制台 UTF-8 支持
if sys.platform == "win32":
    import io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding="utf-8")

DATA_FILE = os.path.join(os.path.dirname(__file__), "tasks.json")


@dataclass
class TodoTask:
    id: int
    title: str
    description: str = ""
    status: str = "pending"  # pending / done
    created_at: str = ""
    updated_at: str = ""


class TodoManager:
    def __init__(self, filepath: str = DATA_FILE):
        self.filepath = filepath
        self.tasks: list[TodoTask] = []
        self._next_id = 1
        self._load()

    def _load(self):
        if os.path.exists(self.filepath):
            with open(self.filepath, "r", encoding="utf-8") as f:
                data = json.load(f)
            self.tasks = [TodoTask(**t) for t in data.get("tasks", [])]
            self._next_id = data.get("next_id", 1)

    def _save(self):
        with open(self.filepath, "w", encoding="utf-8") as f:
            json.dump({
                "tasks": [asdict(t) for t in self.tasks],
                "next_id": self._next_id,
            }, f, ensure_ascii=False, indent=2)

    def add(self, title: str, description: str = "") -> TodoTask:
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        task = TodoTask(
            id=self._next_id,
            title=title,
            description=description,
            status="pending",
            created_at=now,
            updated_at=now,
        )
        self._next_id += 1
        self.tasks.append(task)
        self._save()
        print(f"✅ 已添加: [{task.id}] {task.title}")
        return task

    def list(self, status: Optional[str] = None, keyword: Optional[str] = None):
        result = self.tasks
        if status:
            result = [t for t in result if t.status == status]
        if keyword:
            kw = keyword.lower()
            result = [t for t in result if kw in t.title.lower() or kw in t.description.lower()]
        if not result:
            print("📭 暂无待办事项")
            return
        print(f"\n{'ID':<6}{'状态':<8}{'标题':<30}{'更新时间'}")
        print("-" * 70)
        for t in result:
            icon = "✅" if t.status == "done" else "⏳"
            print(f"{t.id:<6}{icon + ' ' + t.status:<8}{t.title[:28]:<30}{t.updated_at}")

    def delete(self, task_id: int) -> bool:
        for i, t in enumerate(self.tasks):
            if t.id == task_id:
                removed = self.tasks.pop(i)
                self._save()
                print(f"🗑️  已删除: [{removed.id}] {removed.title}")
                return True
        print(f"❌ 未找到 ID={task_id} 的任务")
        return False

    def update(self, task_id: int, title: Optional[str] = None,
               description: Optional[str] = None, status: Optional[str] = None) -> bool:
        for t in self.tasks:
            if t.id == task_id:
                if title is not None:
                    t.title = title
                if description is not None:
                    t.description = description
                if status is not None:
                    t.status = status
                t.updated_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                self._save()
                print(f"✏️  已更新: [{t.id}] {t.title}")
                return True
        print(f"❌ 未找到 ID={task_id} 的任务")
        return False

    def search(self, keyword: str):
        self.list(keyword=keyword)

    def done(self, task_id: int):
        self.update(task_id, status="done")


def print_help():
    print("""
📋 待办事项 CLI 工具
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  add <标题> [描述]              添加新任务
  list [pending|done] [关键词]   列出任务（可按状态筛选）
  search <关键词>                搜索任务
  delete <ID>                    删除任务
  update <ID> <标题> [描述]      更新任务
  done <ID>                      标记任务为完成
  help                           显示此帮助
  quit                           退出
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
""")


def main():
    manager = TodoManager()
    print_help()

    while True:
        try:
            raw = input("todo> ").strip()
            if not raw:
                continue
            parts = raw.split()
            cmd = parts[0].lower()

            if cmd == "quit":
                print("👋 再见！")
                break
            elif cmd == "help":
                print_help()
            elif cmd == "add":
                if len(parts) < 2:
                    print("用法: add <标题> [描述]")
                    continue
                title = parts[1]
                desc = " ".join(parts[2:]) if len(parts) > 2 else ""
                manager.add(title, desc)
            elif cmd == "list":
                status = None
                keyword = None
                for p in parts[1:]:
                    if p in ("pending", "done"):
                        status = p
                    else:
                        keyword = p
                manager.list(status=status, keyword=keyword)
            elif cmd == "search":
                if len(parts) < 2:
                    print("用法: search <关键词>")
                    continue
                manager.search(" ".join(parts[1:]))
            elif cmd == "delete":
                if len(parts) < 2 or not parts[1].isdigit():
                    print("用法: delete <ID>")
                    continue
                manager.delete(int(parts[1]))
            elif cmd == "update":
                if len(parts) < 3:
                    print("用法: update <ID> <新标题> [新描述]")
                    continue
                if not parts[1].isdigit():
                    print("ID 必须是数字")
                    continue
                tid = int(parts[1])
                title = parts[2]
                desc = " ".join(parts[3:]) if len(parts) > 3 else None
                manager.update(tid, title=title, description=desc)
            elif cmd == "done":
                if len(parts) < 2 or not parts[1].isdigit():
                    print("用法: done <ID>")
                    continue
                manager.done(int(parts[1]))
            else:
                print(f"未知命令: {cmd}，输入 help 查看帮助")
        except KeyboardInterrupt:
            print("\n👋 再见！")
            break
        except Exception as e:
            print(f"⚠️ 错误: {e}")


if __name__ == "__main__":
    main()
