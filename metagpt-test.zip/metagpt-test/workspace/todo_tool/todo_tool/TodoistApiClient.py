<<<<<<< SEARCH
=======
"""Interface for interacting with Todoist API"""

from typing import Optional, Dict, Any
import requests
from todoist_client import TodoistAuth

class TodoistApiClient:
    """Manages interactions with the Todoist API using HTTP requests"""
    
    def __init__(self, base_url: str = 'http://localhost:5000'):
        """
        Initialize the TodoistApiClient with a base URL
        
        Args:
            base_url (str): The base URL for Todoist API. Defaults to 'http://localhost:5000'.
        """
        self.base_url = base_url
        self.auth = requests.auth.HTTPBasicAuth('user', 'password')
        
    def add_task(self, task_data: Dict[str, Any]) -> bool:
        """Add a new task to Todoist via the API
        
        Args:
            task_data (Dict): Dictionary containing task information
            
        Returns:
            bool: True if successful, False otherwise
        """
        try:
            payload = {
                'text': task_data.get('text', ''),
                'priority': task_data.get('priority', 0)
            }
            
            headers = {
                'Content-Type': 'application/json',
                'Authorization': self.auth.authstr()
            }
            
            response = requests.post(
                f'{self.base_url}/api/tasks',
                json=payload,
                headers=headers
            )
            
            if response.status_code == 201:
                return True
                
        except requests.exceptions.RequestException as e:
            print(f"Error adding task: {e}")
            return False
            
        return False
    
    def delete_task(self, task_id: str) -> bool:
        """Delete a task from Todoist via the API
        
        Args:
            task_id (str): The ID of the task to delete
            
        Returns:
            bool: True if successful, False otherwise
        """
        try:
            response = requests.delete(
                f'{self.base_url}/api/tasks/{task_id}',
                headers={'Authorization': self.auth.authstr()}
            )
            
            if response.status_code == 204:
                return True
                
        except requests.exceptions.RequestException as e:
            print(f"Error deleting task: {e}")
            return False
            
        return False
>>>>>>> REPLACE
