<<<<<<< SEARCH
=======
"""Handles data storage and manipulation using SQLite"""

import sqlite3
from typing import Optional, Tuple, Dict, Any
from todoist_client import TodoistApiClient

class DataHandler:
    """Handles data storage and manipulation"""
    
    def __init__(self):
        self.conn = sqlite3.connect('task_list.db')
        self.create_tables()
        
    def create_tables(self) -> None:
        """Create necessary database tables if they don't exist"""
        with self.conn:
            self.conn.execute("CREATE TABLE IF NOT EXISTS tasks "
                             "(id INTEGER PRIMARY KEY AUTOINCREMENT, "
                             "text TEXT NOT NULL, "
                             "status TEXT NOT NULL, "
                             "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)")
    
    def save_to_db(self, model: PyTorchModel, todoist_client: TodoistApiClient, todos: Dict) -> None:
        """Save tasks to SQLite database"""
        try:
            # Get base64 encoded string from last task
            base64_str = todos[-1]['base64'] if todos else ''
            
            for index, task in enumerate(todos):
                # Generate description using model
                description = model.generate_description(task['text'])
                
                # Add new task to Todoist via API client
                todoist_client.add_task({
                    'text': task['text'],
                    'base64': base64_str if index == len(todos) - 1 else '',
                    'status': 'PENDING'
                })
                
                # Save to SQLite database
                self.conn.execute("INSERT INTO tasks (id, text, status, created_at) VALUES (?, ?, ?, ?)",
                                 (index + 1, task['text'], 'PENDING', str(task.get('created_at', None))))
                
            # Update base64 string for next iteration
            todos.append({'base64': base64_str})
            
        except Exception as e:
            print(f"Error saving to database: {e}")
    
    def load_from_db(self, conn: sqlite3.Connection) -> Dict:
        """Load tasks from database and update Todoist"""
        try:
            with conn:
                todos = self.conn.execute("SELECT * FROM tasks").fetchall()
                
                for task in todos:
                    # Update status on Todoist
                    if task[2] == 'PENDING':
                        todoist_client.delete_task(task[3])
                        new_task = todoist_client.add_task({
                            'text': task[1],
                            'base64': '',  # Reset base64 for new task
                            'status': 'PENDING'
                        })
                        conn.execute("UPDATE tasks SET id=?, text=?, base64=?, status=? WHERE id=?", 
                                    (new_task[0], new_task[1], new_task[2], 'PENDING', new_task[0]))
                    
                    else:
                        # Reset task if complete
                        conn.execute("UPDATE tasks SET text=?, base64=?, status=? WHERE id=?", 
                                    (task[1], '', 'PENDING', task[0]))

        except Exception as e:
            print(f"Error loading from database: {e}")
            
    def close(self) -> None:
        """Close database connection"""
        self.conn.close()
>>>>>>> REPLACE
